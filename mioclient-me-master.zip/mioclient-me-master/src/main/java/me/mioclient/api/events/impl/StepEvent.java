package me.mioclient.api.events.impl;

import me.mioclient.api.events.Event;

public class StepEvent extends Event {

    public StepEvent(int stage) {
        super(stage);
    }
}
