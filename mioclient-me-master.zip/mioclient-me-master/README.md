mio Meo mioclient.me 1.12.2 anarchy skid
![alt text](https://media.discordapp.net/attachments/948645855471206480/1021555272851914782/mioclientLogoBig_offsetFix.png?width=427&height=427)
