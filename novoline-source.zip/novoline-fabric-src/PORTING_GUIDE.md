# Novoline 1.8.9 → Fabric 1.21.11 porting guide

Original source (1.8.9 jar-mod): `~/repos/Minecraft-Skid-Assistant/Novoline/`
Port target (Fabric mod, Yarn mappings): `~/repos/Minecraft-Skid-Assistant/Novoline-Fabric/src/main/java/`
Mapped modern sources for reference: `~/mc-src/` (1.21.11 merged Yarn sources).

**The goal is a 1:1 port**: same package paths, same class names, same logic. Change only what the
1.8.9→1.21.11 API delta forces you to. Do NOT port ViaVersion or the `protection`/integrity code.

## Core replacements

| 1.8.9 | 1.21.11 (Yarn) |
|---|---|
| `net.minecraft.client.Minecraft` / `Minecraft.getInstance()` | `net.minecraft.client.MinecraftClient` / `MinecraftClient.getInstance()` |
| `mc.thePlayer` | `mc.player` (`ClientPlayerEntity`) |
| `mc.theWorld` | `mc.world` (`ClientWorld`) |
| `mc.fontRendererObj` | `mc.textRenderer` — but prefer `cc.novoline.utils.fonts` API (already ported) |
| `mc.getNetHandler()` | `mc.getNetworkHandler()` (`ClientPlayNetworkHandler`); `.getConnection()` = `ClientConnection` |
| `mc.getNetHandler().getNetworkManager()` | `mc.getNetworkHandler().getConnection()` |
| `mc.displayGuiScreen(x)` | `mc.setScreen(x)` |
| `mc.currentScreen` | `mc.currentScreen` (same) |
| `mc.entityRenderer` | `mc.gameRenderer` |
| `mc.getRenderGlobal()` | `mc.worldRenderer` |
| `mc.playerController` | `mc.interactionManager` (`ClientPlayerInteractionManager`) |
| `mc.timer.elapsedPartialTicks` | `mc.getRenderTickCounter().getTickProgress(true)` |
| `mc.gameSettings.guiScale` | `mc.options.getGuiScale().getValue()` |
| `net.minecraft.util.Vec3` | `net.minecraft.util.math.Vec3d` |
| `net.minecraft.util.AxisAlignedBB` | `net.minecraft.util.math.Box` |
| `net.minecraft.util.EnumFacing` | `net.minecraft.util.math.Direction` |
| `net.minecraft.util.MovingObjectPosition` | `net.minecraft.util.hit.HitResult` / `BlockHitResult` / `EntityHitResult` |
| `entity.posX/posY/posZ` | `entity.getX()/getY()/getZ()` |
| `entity.prevPosX…` | `entity.prevX/prevY/prevZ` |
| `entity.lastTickPosX…` | `entity.lastX/lastY/lastZ` |
| `entity.rotationYaw/rotationPitch` | `entity.getYaw()/getPitch()`; set via `setYaw()/setPitch()` |
| `entity.prevRotationYaw/Pitch` | `entity.prevYaw/prevPitch` — WAIT: on 1.21 `prevYaw` is private-ish; use `entity.prevYaw` (public) |
| `player.onGround` | `player.isOnGround()` |
| `entity.fallDistance` | `entity.fallDistance` (field, same name) |
| `entity.motionX/Y/Z` | `entity.getVelocity()` → `Vec3d`; set via `entity.setVelocity(x,y,z)` |
| `entity.isSprinting()` | `entity.isSprinting()` (same) |
| `entity.getEntityBoundingBox()` / `entity.boundingBox` | `entity.getBoundingBox()` |
| `entity.getEyeHeight()` | `entity.getStandingEyeHeight()` |
| `entity.getDistance(x,y,z)` | `entity.squaredDistanceTo` or compute manually; `entity.distanceTo(other)` for entities |
| `Entity.isInvisible()` | `entity.isInvisible()` (same) |
| `MathHelper.wrapAngleTo180_float(f)` | `MathHelper.wrapDegrees(f)` |
| `MathHelper.sqrt_double(d)` | `Math.sqrt(d)` |
| `IChatComponent` / `ChatComponentText` | `Text` / `Text.literal()` / `MutableText` |
| `component.getFormattedText()` | `component.getString()` |
| `EnumChatFormatting` | `net.minecraft.util.Formatting` |
| `player.addChatMessage(c)` | `player.sendMessage(c, false)` |
| `player.sendChatMessage(s)` | `player.networkHandler.sendChatMessage(s)` — the `.command` intercept is already wired in `ClientPlayNetworkHandlerMixin` |
| `player.sendQueue.addToSendQueue(p)` | `player.networkHandler.sendPacket(p)` or `Novoline.getInstance().sendPacket(p)` |
| `world.getEntityByID(id)` / `loadedEntityList` | `mc.world.getEntityById(id)` / `mc.world.getEntities()` |
| `world.getBlockState(pos)` / `world.getBlock(pos)` | `world.getBlockState(pos)` (same) / `world.getBlockState(pos).getBlock()` |
| `mc.objectMouseOver` | `mc.crosshairTarget` (`HitResult`) |
| `world.rayTraceBlocks(a,b,c,d,e)` | `world.raycast(new RaycastContext(start, end, ShapeType.COLLIDER, FluidHandling.NONE, player))` |
| `ScaledResolution` (patched) | `cc.novoline.utils.ScaledResolution` (already ported — same methods) |
| `Gui.drawRect` / `Gui.drawTexturedModalRect` | inside a Screen/Render2DEvent: `context.fill(...)` / `context.drawTexture(...)`; elsewhere use `RenderUtils.drawRect` etc. |
| `I18n.format(...)` | `I18n.translate(...)` |

## Rendering — THE BIG ONE

There is no immediate mode. Two contexts exist, both bridged through `cc.novoline.utils.RenderUtils`:

**2D / HUD** — only callable while a `DrawContext` is set (inside `Render2DEvent` handlers it is set for you;
inside a `Screen.render` you must call `RenderUtils.setContext(context)` first):

- Filled quad: `RenderUtils.drawRect(x1,y1,x2,y2,color)` / `guiQuad(pipeline, x1,y1,x2,y2,color)`
- Gradient quad: `RenderUtils.guiQuadGradient(x1,y1,x2,y2, c1,c2,c3,c4)` (per-corner colors)
- Triangles/polys: `RenderUtils.guiShape(pipeline, float[]{x,y,...}, int[]{colors...})` — triangles are
  emitted as degenerate quads automatically; pass vertex coords as flat `x,y` pairs
- Textured quad: `RenderUtils.guiTexturedQuad(textureId, pipeline, x1,y1,x2,y2, u1,v1,u2,v2, color)`
- Pipeline constants: `RenderPipelines.GUI` (colored quads) / `RenderPipelines.GUI_TEXTURED`
- Scissor: `context.enableScissor(x1,y1,x2,y2)` / `context.disableScissor()` (screen-space coords)
- Vanilla text: `context.drawTextWithShadow(mc.textRenderer, text, x, y, color)` / `context.drawText(...)`
- Custom fonts: `SimpleFontManager.getInstance().getFont(Fonts.SF.SF_18.SF_18)` — actually just call the
  enum directly: `Fonts.SF.SF_18.SF_18.drawString(text, x, y, color)`; `font.getWidth(s)`,
  `font.getHeight()`, `font.getCenter(...)` keep working. Coordinates are floats (the renderer halves
  pixels via matrix scale — same visual size as 1.8.9 usage).
- `GlStateManager.*` calls → DELETE unless they map to a DrawContext/RenderUtils equivalent.
  Matrix transforms: `context.getMatrices().pushMatrix()`, `.translate(x,y)`, `.scale(sx,sy)`, `.popMatrix()`
  (it's a `Matrix3x2fStack`, not MatrixStack).

**3D / world** — only inside `Render3DEvent` handlers (RenderUtils world context is set for you):

- `RenderUtils.drawFilledBox(box, color)` / `drawOutlinedBoundingBox(box, color)` /
  `drawSolidBlockESP(pos, color)` / `drawOutlinedEntityESP(...)` / `drawLine(...)`
- Boxes must be absolute world coords; camera offset is applied internally.
- Custom geometry: `RenderUtils.submitWorld(RenderLayer layer, (entry, consumer) -> {...})` where
  `consumer.vertex(entry, x, y, z).color(...)` with camera-relative coords, or use
  `RenderUtils.vertex(entry, consumer, x, y, z)` (absolute) / `boxVertices(...)`.
- Useful layers: `RenderLayers.debugQuads()`, `RenderLayers.debugFilledBox()`, `RenderLayers.lines()`.

## Input

- `org.lwjgl.input.Keyboard` shim exists (`org/lwjgl/input/Keyboard.java` in the port):
  `getEventKey()`, `getEventKeyState()`, `isKeyDown(lwjgl2Code)`, `create()`/`poll()` no-ops,
  `fromGlfw(glfw)`, `toGlfw(lwjgl2)`. Module keybind dispatch is already wired.
- `org.lwjgl.input.Mouse` shim: `getX()/getY()`, `isButtonDown(btn)`, `addScrollDelta()`,
  `getDWheel()`, `getButtonCount()`, `getEventButton()`, `getEventButtonState()`, `isGrabbed()`.
- KeyPressed handlers on Screen use GLFW codes — convert with `Keyboard.fromGlfw(key)` when comparing
  against `ModuleKeybind.getKey()` (which stores LWJGL2 codes).
- `Input` mutation (GuiMove etc.): cast `player.input` to `cc.novoline.utils.NovolineInput` —
  `novoline$setMoveForward(f)`, `novoline$setMoveStrafe(f)`, `novoline$setJump(b)`, `novoline$setSneak(b)`.
- `KeyBinding.setKeyBindState`, `KeyBinding.isKeyDown()` still exist;
  `GameSettings.keyBind*` → `mc.options.{forwardKey,leftKey,backKey,rightKey,jumpKey,sneakKey,sprintKey,...}`.

## Events & network

All event classes are already ported under `cc.novoline.events.events` with identical names/fields.
Hooks already live in `cc.novoline.mixin.*`: motion (PRE/POST MotionUpdateEvent with packets), MoveEvent,
JumpEvent, SlowdownEvent, PlayerUpdateEvent, LivingUpdateEvent, TickUpdateEvent, Render2DEvent,
Render3DEvent, KeyPressEvent, SneakEvent, PushBlockEvent, StepConfirmEvent, PacketEvent (IN/OUT),
RightClickEvent, LoadWorldEvent, DisplayChestGuiEvent.

- `PacketEvent.getPacket() / setPacket()`, `getType()`, `getDirection() (INCOMING/OUTGOING)`,
  `isIncoming()/isOutgoing()`. Send without re-firing the event:
  `Novoline.getInstance().sendPacketNoEvent(packet)` — implemented via a ThreadLocal on the connection mixin.
- Modern packet names: `PlayerMoveC2SPacket.{OnGroundOnly(xyz), PositionAndOnGround(xyz+yaw/pitch),
  LookAndOnGround, Full}`, `HandSwingC2SPacket(Hand)`, `ClientCommandC2SPacket(player, MODE)` (sprint/sneak),
  `PlayerActionC2SPacket(Action, pos, dir)` (was C07), `PlayerInteractBlockC2SPacket(hand, BlockHitResult, seq)`
  (was C07/C08), `PlayerInteractEntityC2SPacket.attack/interact(entity, sneaking)`, `UpdateSelectedSlotC2SPacket(slot)`,
  `UpdateSignC2SPacket`, `CloseHandledScreenC2SPacket`, `ClientStatusC2SPacket`.
- S2C: `EntityVelocityUpdateS2CPacket` (was S12), `ExplosionS2CPacket` (S27), `GameMessageS2CPacket` (S02),
  `EntitySpawnS2CPacket` (S0E), `PlaySoundS2CPacket`, `PlayerPositionLookS2CPacket` (S08),
  `EntityTrackerUpdateS2CPacket` (S1C), `ChunkDeltaUpdateS2CPacket`, `BlockChangeS2CPacket`,
  `EntityStatusS2CPacket` (S1B), `EntityPositionS2CPacket`, `EntityS2CPacket` base (S14 family),
  `EntityEquipmentUpdateS2CPacket`, `TeamsS2CPacket`, `OpenScreenS2CPacket` (S2D/S2E window open).

## Game systems

- `player.inventory.mainInventory[i]` → `player.getInventory().getStack(i)`; hotbar index i<9 = `getStack(i)`;
  `player.inventory.getCurrentItem()`/`getHeldItem()` → `player.getInventory().getSelectedStack()` / `player.getMainHandStack()`
- `player.inventoryContainer` → `player.playerScreenHandler`; `player.openContainer` → `player.currentScreenHandler`;
  `container.getSlot(i).getStack()` same-ish on `ScreenHandler`; click → `mc.interactionManager.clickSlot(syncId, slot, button, SlotActionType, player)`
- `itemStack.stackSize` → `stack.getCount()`; `itemStack.getItemDamage()` → `stack.getDamage()`;
  `Item.itemsList`/`getIdFromItem` → `Registries.ITEM`; `stack.hasDisplayName()` → `stack.contains(DataComponentTypes.CUSTOM_NAME)`
- Potion effects: `player.getActivePotionEffect(Potion.moveSpeed)` → `player.getStatusEffect(StatusEffects.SPEED)`;
  `getActivePotionEffects()` → `getStatusEffects()`; amplifier via `StatusEffectInstance.getAmplifier()`
- Enchantments: `EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, stack)` →
  `EnchantmentHelper.getLevel(world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(Enchantments.SHARPNESS), stack)` — or use `EnchantmentHelper.apply` helpers; if awkward, note it.
- `Block.getIdFromBlock` → `Registries.BLOCK`; `block instanceof BlockChest` same; `Blocks.bed` → `Blocks.WHITE_BED` etc. per-material.
- `mc.getSession().getUsername()` → `mc.getSession().getUsername()` (still exists)
- `Minecraft.getMinecraft().displayWidth/Height` → `mc.getWindow().getFramebufferWidth()/getFramebufferHeight()`
- `TickEvent`/`ClientTickEvent` → `TickUpdateEvent` on the Novoline bus (already wired from `MinecraftClientMixin.tick`).

## Screens (GUI port)

- `GuiScreen` → `Screen`, extend `Screen` with ctor `super(Text.literal("title"))`.
- `initGui()` → `init()`, `drawScreen(mx,my,pt)` → `render(context,mx,my,delta)` (call `RenderUtils.setContext(context)` first),
  `mouseClicked(mx,my,btn)` → same but doubles, `keyTyped(char,key)` → `keyPressed(key,scan,mods)` + `charTyped(chr,mods)`,
  `onGuiClosed()` → `removed()`, `doesGuiPauseGame()` → `shouldPause()` (return false to keep rendering world),
  `mouseReleased` → `mouseReleased(x,y,btn)`, `handleMouseInput`/scroll → `mouseScrolled(x,y,h,v)`.
- `GuiTextField` → `TextFieldWidget` (`new TextFieldWidget(mc.textRenderer, x, y, w, h, Text.empty())`).
- `drawDefaultBackground` → `renderBackground(context, mx, my, delta)` (or `super.render`).
- For bind-setting in GUIs: call `PlayerUtils.onBindInGui()` from `keyPressed` — it reads the LWJGL2 shim.
- `mc.displayGuiScreen(null)` → `mc.setScreen(null)` or `close()`.

## Rules for port agents

1. Keep package path, class name, method names and logic identical to the original. Comments survive.
2. If something has NO equivalent (e.g. a packet type that no longer exists), implement the closest
   modern equivalent and add `// PORT: <what changed>` plus list it in your structured output `notes`.
3. NEVER edit files outside your assigned list — report needed shared changes in `notes` instead
   (e.g. "needs a mixin hook on X"). If you must read shared files: `cc.novoline.utils.RenderUtils`,
   `RotationUtil`, `PlayerUtils`, `ServerUtils`, `ScaledResolution`, `NovolineInput`, `Novoline.java`,
   `modules/AbstractModule.java`, `modules/ModuleManager.java`, the `events/` package.
4. No GLFW/GL11/glPushMatrix calls may remain. No `net.minecraft.client.Minecraft`, `EntityPlayerSP`,
   `ScaledResolution` (vanilla), `GuiScreen`, `Gui.drawRect`, `ChatComponentText`, `EnumChatFormatting`.
5. Try compiling ONLY your files: `cd ~/repos/Minecraft-Skid-Assistant/Novoline-Fabric && ./gradlew compileJava`
   will fail on other unfinished files — check errors mention ONLY other files, not yours. If javac errors
   hit your files, fix them.
6. Copy any non-code assets (json/png/etc. next to your classes) into
   `Novoline-Fabric/src/main/resources/` preserving paths; note them in `resources`.
