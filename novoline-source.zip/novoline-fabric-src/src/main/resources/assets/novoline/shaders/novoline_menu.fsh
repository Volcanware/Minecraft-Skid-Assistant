/*
 * Original shader from: https://www.shadertoy.com/view/NscXR8
 * PORT: 1.21 core shaders are GLSL 150 with std140 uniform blocks;
 * the glslsandbox loose uniforms (time/resolution/mouse) now live in
 * the MenuData UBO, fed per-frame by NovoMainMenu.
 */

#version 150

layout(std140) uniform MenuData {
    float Time;
    vec2 Resolution;
    vec2 Mouse;
};

out vec4 fragColor;

// shadertoy emulation
#define iTime Time
#define iResolution vec3(Resolution, 1.0)

// --------[ Original ShaderToy begins here ]---------- //
// 240 chars by Xor (with aspect ratio fix)
void mainImage(out vec4 O, vec2 I)
{
    vec3 p=iResolution,d = -.5*vec3(I+I-p.xy,p)/p.x,c = d-d, i=c;
    for(int x=0;x<200;++x) {
        if (i.x>=1.) break;
        p = c,
        p.z -= iTime+(i.x+=.01),
        p.xy *= mat2(sin((p.z*=.1)+vec4(0,11,33,0)));
        c += length(sin(p.yx)+cos(p.xz+iTime))*d;
    }
    O = vec4(10,0,2.5,9)/length(c);
}
// --------[ Original ShaderToy ends here ]---------- //

void main(void)
{
    mainImage(fragColor, gl_FragCoord.xy);
    fragColor.a = 1.;
}
