#version 330

uniform sampler2D InSampler;
uniform sampler2D PrevSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform PhosphorConfig {
    vec3 Phosphor;
};

in vec2 texCoord;

out vec4 fragColor;

void main(){
    vec4 curr = texture(InSampler, texCoord);
    vec4 prev = texture(PrevSampler, texCoord);
    fragColor = vec4(max(curr.rgb, prev.rgb * Phosphor), curr.a);
}
