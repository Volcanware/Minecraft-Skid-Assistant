package org.lwjgl.input;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/**
 * LWJGL2 Keyboard API shim over GLFW (LWJGL3). Keeps the old LWJGL2 keycode
 * constants so ported 1.8.9 code compiles and binds keep working; the codes
 * are translated to GLFW keycodes at the input boundary.
 */
public final class Keyboard {

    public static final int KEY_NONE = 0;
    public static final int KEY_ESCAPE = 1, KEY_1 = 2, KEY_2 = 3, KEY_3 = 4, KEY_4 = 5, KEY_5 = 6,
            KEY_6 = 7, KEY_7 = 8, KEY_8 = 9, KEY_9 = 10, KEY_0 = 11, KEY_MINUS = 12, KEY_EQUALS = 13,
            KEY_BACK = 14, KEY_TAB = 15, KEY_Q = 16, KEY_W = 17, KEY_E = 18, KEY_R = 19, KEY_T = 20,
            KEY_Y = 21, KEY_U = 22, KEY_I = 23, KEY_O = 24, KEY_P = 25, KEY_LBRACKET = 26,
            KEY_RBRACKET = 27, KEY_RETURN = 28, KEY_LCONTROL = 29, KEY_A = 30, KEY_S = 31, KEY_D = 32,
            KEY_F = 33, KEY_G = 34, KEY_H = 35, KEY_J = 36, KEY_K = 37, KEY_L = 38, KEY_SEMICOLON = 39,
            KEY_APOSTROPHE = 40, KEY_GRAVE = 41, KEY_LSHIFT = 42, KEY_BACKSLASH = 43, KEY_Z = 44,
            KEY_X = 45, KEY_C = 46, KEY_V = 47, KEY_B = 48, KEY_N = 49, KEY_M = 50, KEY_COMMA = 51,
            KEY_PERIOD = 52, KEY_SLASH = 53, KEY_RSHIFT = 54, KEY_MULTIPLY = 55, KEY_LMENU = 56,
            KEY_SPACE = 57, KEY_CAPITAL = 58, KEY_F1 = 59, KEY_F2 = 60, KEY_F3 = 61, KEY_F4 = 62,
            KEY_F5 = 63, KEY_F6 = 64, KEY_F7 = 65, KEY_F8 = 66, KEY_F9 = 67, KEY_F10 = 68,
            KEY_NUMLOCK = 69, KEY_SCROLL = 70, KEY_NUMPAD7 = 71, KEY_NUMPAD8 = 72, KEY_NUMPAD9 = 73,
            KEY_SUBTRACT = 74, KEY_NUMPAD4 = 75, KEY_NUMPAD5 = 76, KEY_NUMPAD6 = 77, KEY_ADD = 78,
            KEY_NUMPAD1 = 79, KEY_NUMPAD2 = 80, KEY_NUMPAD3 = 81, KEY_NUMPAD0 = 82, KEY_DECIMAL = 83,
            KEY_F11 = 87, KEY_F12 = 88, KEY_F13 = 100, KEY_F14 = 101, KEY_F15 = 102, KEY_F16 = 103,
            KEY_F17 = 104, KEY_F18 = 105, KEY_KANA = 112, KEY_CONVERT = 121, KEY_NOCONVERT = 123,
            KEY_YEN = 125, KEY_NUMPADEQUALS = 141, KEY_CIRCUMFLEX = 144, KEY_AT = 145, KEY_COLON = 146,
            KEY_UNDERLINE = 147, KEY_KANJI = 148, KEY_STOP = 149, KEY_AX = 150, KEY_UNLABELED = 151,
            KEY_NUMPADENTER = 156, KEY_RCONTROL = 157, KEY_NUMPADCOMMA = 179, KEY_DIVIDE = 181,
            KEY_SYSRQ = 183, KEY_RMENU = 184, KEY_PAUSE = 197, KEY_HOME = 199, KEY_UP = 200,
            KEY_PRIOR = 201, KEY_LEFT = 203, KEY_RIGHT = 205, KEY_END = 207, KEY_DOWN = 208,
            KEY_NEXT = 209, KEY_INSERT = 210, KEY_DELETE = 211, KEY_LWIN = 219, KEY_RWIN = 220,
            KEY_APPS = 221, KEY_POWER = 222, KEY_SLEEP = 223;

    private static final int[] LWJGL2_TO_GLFW = new int[224];
    private static final Map<Integer, Integer> GLFW_TO_LWJGL2 = new HashMap<>();

    static {
        LWJGL2_TO_GLFW[KEY_ESCAPE] = GLFW.GLFW_KEY_ESCAPE;
        LWJGL2_TO_GLFW[KEY_1] = GLFW.GLFW_KEY_1;
        LWJGL2_TO_GLFW[KEY_2] = GLFW.GLFW_KEY_2;
        LWJGL2_TO_GLFW[KEY_3] = GLFW.GLFW_KEY_3;
        LWJGL2_TO_GLFW[KEY_4] = GLFW.GLFW_KEY_4;
        LWJGL2_TO_GLFW[KEY_5] = GLFW.GLFW_KEY_5;
        LWJGL2_TO_GLFW[KEY_6] = GLFW.GLFW_KEY_6;
        LWJGL2_TO_GLFW[KEY_7] = GLFW.GLFW_KEY_7;
        LWJGL2_TO_GLFW[KEY_8] = GLFW.GLFW_KEY_8;
        LWJGL2_TO_GLFW[KEY_9] = GLFW.GLFW_KEY_9;
        LWJGL2_TO_GLFW[KEY_0] = GLFW.GLFW_KEY_0;
        LWJGL2_TO_GLFW[KEY_MINUS] = GLFW.GLFW_KEY_MINUS;
        LWJGL2_TO_GLFW[KEY_EQUALS] = GLFW.GLFW_KEY_EQUAL;
        LWJGL2_TO_GLFW[KEY_BACK] = GLFW.GLFW_KEY_BACKSPACE;
        LWJGL2_TO_GLFW[KEY_TAB] = GLFW.GLFW_KEY_TAB;
        LWJGL2_TO_GLFW[KEY_Q] = GLFW.GLFW_KEY_Q;
        LWJGL2_TO_GLFW[KEY_W] = GLFW.GLFW_KEY_W;
        LWJGL2_TO_GLFW[KEY_E] = GLFW.GLFW_KEY_E;
        LWJGL2_TO_GLFW[KEY_R] = GLFW.GLFW_KEY_R;
        LWJGL2_TO_GLFW[KEY_T] = GLFW.GLFW_KEY_T;
        LWJGL2_TO_GLFW[KEY_Y] = GLFW.GLFW_KEY_Y;
        LWJGL2_TO_GLFW[KEY_U] = GLFW.GLFW_KEY_U;
        LWJGL2_TO_GLFW[KEY_I] = GLFW.GLFW_KEY_I;
        LWJGL2_TO_GLFW[KEY_O] = GLFW.GLFW_KEY_O;
        LWJGL2_TO_GLFW[KEY_P] = GLFW.GLFW_KEY_P;
        LWJGL2_TO_GLFW[KEY_LBRACKET] = GLFW.GLFW_KEY_LEFT_BRACKET;
        LWJGL2_TO_GLFW[KEY_RBRACKET] = GLFW.GLFW_KEY_RIGHT_BRACKET;
        LWJGL2_TO_GLFW[KEY_RETURN] = GLFW.GLFW_KEY_ENTER;
        LWJGL2_TO_GLFW[KEY_LCONTROL] = GLFW.GLFW_KEY_LEFT_CONTROL;
        LWJGL2_TO_GLFW[KEY_A] = GLFW.GLFW_KEY_A;
        LWJGL2_TO_GLFW[KEY_S] = GLFW.GLFW_KEY_S;
        LWJGL2_TO_GLFW[KEY_D] = GLFW.GLFW_KEY_D;
        LWJGL2_TO_GLFW[KEY_F] = GLFW.GLFW_KEY_F;
        LWJGL2_TO_GLFW[KEY_G] = GLFW.GLFW_KEY_G;
        LWJGL2_TO_GLFW[KEY_H] = GLFW.GLFW_KEY_H;
        LWJGL2_TO_GLFW[KEY_J] = GLFW.GLFW_KEY_J;
        LWJGL2_TO_GLFW[KEY_K] = GLFW.GLFW_KEY_K;
        LWJGL2_TO_GLFW[KEY_L] = GLFW.GLFW_KEY_L;
        LWJGL2_TO_GLFW[KEY_SEMICOLON] = GLFW.GLFW_KEY_SEMICOLON;
        LWJGL2_TO_GLFW[KEY_APOSTROPHE] = GLFW.GLFW_KEY_APOSTROPHE;
        LWJGL2_TO_GLFW[KEY_GRAVE] = GLFW.GLFW_KEY_GRAVE_ACCENT;
        LWJGL2_TO_GLFW[KEY_LSHIFT] = GLFW.GLFW_KEY_LEFT_SHIFT;
        LWJGL2_TO_GLFW[KEY_BACKSLASH] = GLFW.GLFW_KEY_BACKSLASH;
        LWJGL2_TO_GLFW[KEY_Z] = GLFW.GLFW_KEY_Z;
        LWJGL2_TO_GLFW[KEY_X] = GLFW.GLFW_KEY_X;
        LWJGL2_TO_GLFW[KEY_C] = GLFW.GLFW_KEY_C;
        LWJGL2_TO_GLFW[KEY_V] = GLFW.GLFW_KEY_V;
        LWJGL2_TO_GLFW[KEY_B] = GLFW.GLFW_KEY_B;
        LWJGL2_TO_GLFW[KEY_N] = GLFW.GLFW_KEY_N;
        LWJGL2_TO_GLFW[KEY_M] = GLFW.GLFW_KEY_M;
        LWJGL2_TO_GLFW[KEY_COMMA] = GLFW.GLFW_KEY_COMMA;
        LWJGL2_TO_GLFW[KEY_PERIOD] = GLFW.GLFW_KEY_PERIOD;
        LWJGL2_TO_GLFW[KEY_SLASH] = GLFW.GLFW_KEY_SLASH;
        LWJGL2_TO_GLFW[KEY_RSHIFT] = GLFW.GLFW_KEY_RIGHT_SHIFT;
        LWJGL2_TO_GLFW[KEY_MULTIPLY] = GLFW.GLFW_KEY_KP_MULTIPLY;
        LWJGL2_TO_GLFW[KEY_LMENU] = GLFW.GLFW_KEY_LEFT_ALT;
        LWJGL2_TO_GLFW[KEY_SPACE] = GLFW.GLFW_KEY_SPACE;
        LWJGL2_TO_GLFW[KEY_CAPITAL] = GLFW.GLFW_KEY_CAPS_LOCK;
        LWJGL2_TO_GLFW[KEY_F1] = GLFW.GLFW_KEY_F1;
        LWJGL2_TO_GLFW[KEY_F2] = GLFW.GLFW_KEY_F2;
        LWJGL2_TO_GLFW[KEY_F3] = GLFW.GLFW_KEY_F3;
        LWJGL2_TO_GLFW[KEY_F4] = GLFW.GLFW_KEY_F4;
        LWJGL2_TO_GLFW[KEY_F5] = GLFW.GLFW_KEY_F5;
        LWJGL2_TO_GLFW[KEY_F6] = GLFW.GLFW_KEY_F6;
        LWJGL2_TO_GLFW[KEY_F7] = GLFW.GLFW_KEY_F7;
        LWJGL2_TO_GLFW[KEY_F8] = GLFW.GLFW_KEY_F8;
        LWJGL2_TO_GLFW[KEY_F9] = GLFW.GLFW_KEY_F9;
        LWJGL2_TO_GLFW[KEY_F10] = GLFW.GLFW_KEY_F10;
        LWJGL2_TO_GLFW[KEY_NUMLOCK] = GLFW.GLFW_KEY_NUM_LOCK;
        LWJGL2_TO_GLFW[KEY_SCROLL] = GLFW.GLFW_KEY_SCROLL_LOCK;
        LWJGL2_TO_GLFW[KEY_NUMPAD7] = GLFW.GLFW_KEY_KP_7;
        LWJGL2_TO_GLFW[KEY_NUMPAD8] = GLFW.GLFW_KEY_KP_8;
        LWJGL2_TO_GLFW[KEY_NUMPAD9] = GLFW.GLFW_KEY_KP_9;
        LWJGL2_TO_GLFW[KEY_SUBTRACT] = GLFW.GLFW_KEY_KP_SUBTRACT;
        LWJGL2_TO_GLFW[KEY_NUMPAD4] = GLFW.GLFW_KEY_KP_4;
        LWJGL2_TO_GLFW[KEY_NUMPAD5] = GLFW.GLFW_KEY_KP_5;
        LWJGL2_TO_GLFW[KEY_NUMPAD6] = GLFW.GLFW_KEY_KP_6;
        LWJGL2_TO_GLFW[KEY_ADD] = GLFW.GLFW_KEY_KP_ADD;
        LWJGL2_TO_GLFW[KEY_NUMPAD1] = GLFW.GLFW_KEY_KP_1;
        LWJGL2_TO_GLFW[KEY_NUMPAD2] = GLFW.GLFW_KEY_KP_2;
        LWJGL2_TO_GLFW[KEY_NUMPAD3] = GLFW.GLFW_KEY_KP_3;
        LWJGL2_TO_GLFW[KEY_NUMPAD0] = GLFW.GLFW_KEY_KP_0;
        LWJGL2_TO_GLFW[KEY_DECIMAL] = GLFW.GLFW_KEY_KP_DECIMAL;
        LWJGL2_TO_GLFW[KEY_F11] = GLFW.GLFW_KEY_F11;
        LWJGL2_TO_GLFW[KEY_F12] = GLFW.GLFW_KEY_F12;
        LWJGL2_TO_GLFW[KEY_F13] = GLFW.GLFW_KEY_F13;
        LWJGL2_TO_GLFW[KEY_F14] = GLFW.GLFW_KEY_F14;
        LWJGL2_TO_GLFW[KEY_F15] = GLFW.GLFW_KEY_F15;
        LWJGL2_TO_GLFW[KEY_F16] = GLFW.GLFW_KEY_F16;
        LWJGL2_TO_GLFW[KEY_F17] = GLFW.GLFW_KEY_F17;
        LWJGL2_TO_GLFW[KEY_F18] = GLFW.GLFW_KEY_F18;
        LWJGL2_TO_GLFW[KEY_NUMPADEQUALS] = GLFW.GLFW_KEY_KP_EQUAL;
        LWJGL2_TO_GLFW[KEY_NUMPADENTER] = GLFW.GLFW_KEY_KP_ENTER;
        LWJGL2_TO_GLFW[KEY_RCONTROL] = GLFW.GLFW_KEY_RIGHT_CONTROL;
        LWJGL2_TO_GLFW[KEY_DIVIDE] = GLFW.GLFW_KEY_KP_DIVIDE;
        LWJGL2_TO_GLFW[KEY_SYSRQ] = GLFW.GLFW_KEY_PRINT_SCREEN;
        LWJGL2_TO_GLFW[KEY_RMENU] = GLFW.GLFW_KEY_RIGHT_ALT;
        LWJGL2_TO_GLFW[KEY_PAUSE] = GLFW.GLFW_KEY_PAUSE;
        LWJGL2_TO_GLFW[KEY_HOME] = GLFW.GLFW_KEY_HOME;
        LWJGL2_TO_GLFW[KEY_UP] = GLFW.GLFW_KEY_UP;
        LWJGL2_TO_GLFW[KEY_PRIOR] = GLFW.GLFW_KEY_PAGE_UP;
        LWJGL2_TO_GLFW[KEY_LEFT] = GLFW.GLFW_KEY_LEFT;
        LWJGL2_TO_GLFW[KEY_RIGHT] = GLFW.GLFW_KEY_RIGHT;
        LWJGL2_TO_GLFW[KEY_END] = GLFW.GLFW_KEY_END;
        LWJGL2_TO_GLFW[KEY_DOWN] = GLFW.GLFW_KEY_DOWN;
        LWJGL2_TO_GLFW[KEY_NEXT] = GLFW.GLFW_KEY_PAGE_DOWN;
        LWJGL2_TO_GLFW[KEY_INSERT] = GLFW.GLFW_KEY_INSERT;
        LWJGL2_TO_GLFW[KEY_DELETE] = GLFW.GLFW_KEY_DELETE;
        LWJGL2_TO_GLFW[KEY_LWIN] = GLFW.GLFW_KEY_LEFT_SUPER;
        LWJGL2_TO_GLFW[KEY_RWIN] = GLFW.GLFW_KEY_RIGHT_SUPER;
        LWJGL2_TO_GLFW[KEY_APPS] = GLFW.GLFW_KEY_MENU;

        for (int i = 0; i < LWJGL2_TO_GLFW.length; i++) {
            int glfw = LWJGL2_TO_GLFW[i];
            if (glfw != 0) GLFW_TO_LWJGL2.put(glfw, i);
        }
    }

    private Keyboard() {
    }

    /** LWJGL2 scancode -> GLFW keycode. Returns GLFW_KEY_UNKNOWN for unmapped keys. */
    public static int toGlfw(int lwjgl2Key) {
        if (lwjgl2Key <= KEY_NONE || lwjgl2Key >= LWJGL2_TO_GLFW.length) return GLFW.GLFW_KEY_UNKNOWN;
        int k = LWJGL2_TO_GLFW[lwjgl2Key];
        return k == 0 ? GLFW.GLFW_KEY_UNKNOWN : k;
    }

    /** GLFW keycode -> LWJGL2 scancode, or KEY_NONE. */
    public static int fromGlfw(int glfwKey) {
        return GLFW_TO_LWJGL2.getOrDefault(glfwKey, KEY_NONE);
    }

    public static boolean isKeyDown(int lwjgl2Key) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getWindow() == null) return false;
        int glfw = toGlfw(lwjgl2Key);
        if (glfw == GLFW.GLFW_KEY_UNKNOWN) return false;
        return GLFW.glfwGetKey(mc.getWindow().getHandle(), glfw) == GLFW.GLFW_PRESS;
    }

    public static String getKeyName(int lwjgl2Key) {
        if (lwjgl2Key == KEY_NONE) return "None";
        int glfw = toGlfw(lwjgl2Key);
        if (glfw == GLFW.GLFW_KEY_UNKNOWN) return "Unknown";
        String name = InputUtil.Type.KEYSYM.createFromCode(glfw).getLocalizedText().getString();
        return name == null || name.isEmpty() ? "Unknown" : name;
    }

    /** Current event key as an LWJGL2 code — driven by our key hook. */
    public static int getEventKey() {
        return eventKey;
    }

    public static boolean getEventKeyState() {
        return eventKeyState;
    }

    /** Set from our keyboard hook before events fire. */
    public static void setEventKey(int lwjgl2Key, boolean state) {
        eventKey = lwjgl2Key;
        eventKeyState = state;
    }

    private static int eventKey = KEY_NONE;
    private static boolean eventKeyState;
}
