package org.lwjgl.input;

import net.minecraft.client.MinecraftClient;

/**
 * LWJGL2 Mouse API shim over GLFW. getX()/getY() return coordinates in the
 * LWJGL2 convention (bottom-left origin, in "scaled" GUI units) so the ported
 * GUI code keeps working unchanged.
 */
public final class Mouse {

    private static double scrollDelta;
    private static int eventButton = -1;
    private static boolean eventButtonState;

    private Mouse() {
    }

    /** Called by our mouse scroll hook (GLFW scroll, in pixels of scroll delta). */
    public static void addScrollDelta(double delta) {
        scrollDelta += delta;
    }

    /** LWJGL2 DWheel: accumulated wheel delta consumed on read (120 per notch). */
    public static int getDWheel() {
        int d = (int) scrollDelta;
        scrollDelta -= d;
        return d;
    }

    /** LWJGL2 X: cursor X in scaled GUI coords (left origin). */
    public static int getX() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getWindow() == null) return 0;
        return (int) (mc.mouse.getX() * mc.getWindow().getScaledWidth() / mc.getWindow().getWidth());
    }

    /** LWJGL2 Y: bottom-left origin in scaled GUI coords. */
    public static int getY() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getWindow() == null) return 0;
        int scaled = mc.getWindow().getScaledHeight();
        return scaled - 1 - (int) (mc.mouse.getY() * scaled / mc.getWindow().getHeight());
    }

    public static boolean isButtonDown(int button) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getWindow() == null || button < 0) return false;
        return org.lwjgl.glfw.GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), button)
                == org.lwjgl.glfw.GLFW.GLFW_PRESS;
    }

    public static String getButtonName(int button) {
        return button < 0 ? "None" : "BUTTON" + button;
    }

    public static int getEventButton() {
        return eventButton;
    }

    public static boolean getEventButtonState() {
        return eventButtonState;
    }

    public static void setEventButton(int button, boolean state) {
        eventButton = button;
        eventButtonState = state;
    }
}
