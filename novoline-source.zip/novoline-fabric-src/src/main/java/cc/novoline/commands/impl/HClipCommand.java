package cc.novoline.commands.impl;

import cc.novoline.Novoline;
import cc.novoline.commands.CommandException;
import cc.novoline.commands.NovoCommand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;

public final class HClipCommand extends NovoCommand {

    public HClipCommand(@NotNull Novoline novoline) {
        super(novoline, "hc", "hclip");
    }

    @Override
    public void process(String[] args) throws CommandException {
        if (args.length != 1) {
            notifyError("Use .hclip (distance)");
            return;
        }

        final ClientPlayerEntity p = MinecraftClient.getInstance().player;
        final double distance = getDouble(args[0]);

        /* Moves the player horizontally in the facing direction (yaw only),
           by player pos — negative distances go backwards. */
        Vec3d dir = Vec3d.fromPolar(0.0F, p.getYaw());
        p.setPosition(p.getX() + dir.x * distance, p.getY(), p.getZ() + dir.z * distance);
    }
}
