package cc.novoline.commands.impl;

import cc.novoline.Novoline;
import cc.novoline.commands.CommandException;
import cc.novoline.commands.NovoCommand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.jetbrains.annotations.NotNull;

public final class YawCommand extends NovoCommand {

    public YawCommand(@NotNull Novoline novoline) {
        super(novoline, "yaw", "Sets your yaw");
    }

    @Override
    public void process(String[] args) throws CommandException {
        if (args.length != 1) {
            notifyError("Use .yaw (degrees)");
            return;
        }

        final ClientPlayerEntity p = MinecraftClient.getInstance().player;
        p.setYaw((float) getDouble(args[0]));
    }
}
