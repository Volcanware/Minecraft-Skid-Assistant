package cc.novoline.commands.impl;

import cc.novoline.Novoline;
import cc.novoline.commands.CommandException;
import cc.novoline.commands.NovoCommand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;

public final class DisconnectCommand extends NovoCommand {

    public DisconnectCommand(@NotNull Novoline novoline) {
        super(novoline, "disconnect", "Disconnects from the current world/server");
    }

    @Override
    public void process(String[] args) throws CommandException {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) {
            mc.disconnect(Text.literal("Disconnected"));
        }
    }
}
