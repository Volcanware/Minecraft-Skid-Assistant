package cc.novoline.commands.impl;

import cc.novoline.Novoline;
import cc.novoline.commands.CommandException;
import cc.novoline.commands.NovoCommand;
import cc.novoline.utils.java.Checks;
import io.netty.buffer.Unpooled;

import java.util.Locale;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketByteBuf;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Range;

public class TestCommand extends NovoCommand {

	public TestCommand(@NotNull Novoline novoline) {
		super(novoline, "test");
	}

	@Override
	public void process(String[] args) throws CommandException {
		MinecraftClient mc = novoline.getMinecraft();

		if(mc.player != null) {
			ClientPlayNetworkHandler sendQueue = mc.player.networkHandler;
			ClientConnection networkManager = sendQueue.getConnection();

			// PORT: ViaVersion is not ported — ViaNetworkManager no longer exists, so the
			// via-less branch below is the only reachable one.
			if(args.length < 1) {
				send("No args");
				return;
			}

			String s = args[0].toLowerCase(Locale.ROOT);
			PacketByteBuf packetBuffer;

			switch(s) {
				case "a":
					packetBuffer = constructPacket(10, 0x27, buf -> buf.writeEnumConstant(EnumHand.OFF_HAND));
					break;
				case "b":
					packetBuffer = constructPacket(10, 0x2A, buf -> buf.writeEnumConstant(EnumHand.OFF_HAND));
					break;
				default:
					send("Unexpected value: " + s);
					return;
			}

			packetBuffer.release(); // PORT: no raw-packet channel without ViaVersion
			send("No via");
		}
	}

	public static void sendPacketWithoutConversion(@NotNull PacketByteBuf packetBuffer) {
		Checks.notNull(packetBuffer, "Packet buffer");

		MinecraftClient mc = MinecraftClient.getInstance();
		if(mc.player == null) throw new IllegalStateException("mc.player is null");

		// PORT: ViaVersion is not ported — there is no ViaNetworkManager/UserConnection to
		// send a raw packet through. Mirrors the original "No via" failure path.
		throw new IllegalStateException("No via");
	}

	@Contract("_, _, _ -> new")
	public static @NotNull PacketByteBuf constructPacket(@Range(from = 0, to = Integer.MAX_VALUE) int bufferCapacity,
														@Range(from = 0, to = Integer.MAX_VALUE) int packetId,
														@NotNull Consumer<? super PacketByteBuf> transformations) {
		PacketByteBuf packetBuffer = new PacketByteBuf(Unpooled.buffer(bufferCapacity));
		transformations.accept(packetBuffer);
		return packetBuffer;
	}

	public enum EnumHand {

		MAIN_HAND,
		OFF_HAND
    }
}
