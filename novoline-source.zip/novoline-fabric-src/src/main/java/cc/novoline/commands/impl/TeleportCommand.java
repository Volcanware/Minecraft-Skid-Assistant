package cc.novoline.commands.impl;

import cc.novoline.Novoline;
import cc.novoline.commands.NovoCommand;
import cc.novoline.events.EventManager;
import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.events.events.MoveEvent;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import cc.novoline.utils.Timer;
import cc.novoline.utils.notifications.NotificationType;
import cc.novoline.utils.pathfinding.AStarCustomPathfinder;
import cc.novoline.utils.pathfinding.Vec3;
import net.minecraft.block.AbstractSignBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.PlantBlock;
import net.minecraft.block.TallPlantBlock;
import net.minecraft.block.VineBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TeleportCommand extends NovoCommand {

    public static boolean cancel;
    private float tempYDiff = 0, tempXDiff = 0, tempZDiff = 0;
    private MinecraftClient mc = MinecraftClient.getInstance();
    private Vec3 tpVec = new Vec3(0, 0, 0);
    private Timer timer = new Timer();
    private boolean airFreeze, playerTP;

    public TeleportCommand(@NotNull Novoline novoline) {
        super(novoline, "teleport", Arrays.asList("tp", "teleport"));
    }

    public PlayerEntity player;

    @Override
    public void process(String[] args) {
        if (args.length < 4 || !args[3].equals("goteleportnigga") || !ServerUtils.serverIs(Servers.PIT) && !ServerUtils.serverIs(Servers.BW)) {
            novoline.getNotificationManager().pop("Teleport", "Disabled!", NotificationType.ERROR);
            return;
        }

        EventManager.register(this);
        double posX = mc.player.getX(), posY = mc.player.getY(), posZ = mc.player.getZ();
        playerTP = false;
        player = null;

        switch (args.length) {
            case 4:
                novoline.getNotificationManager().pop("Teleporting to " + args[0] + "/" + args[1] + "/" + args[2], 5100, NotificationType.INFO);
            case 3:
                novoline.getNotificationManager().pop("Teleporting to " + args[0] + "/" + args[1] + "/" + args[2], 5100, NotificationType.INFO);
                sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(new Vec3d(posX, posY + 0.41999998688698, posZ), false, mc.player.horizontalCollision));
                sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(new Vec3d(posX, posY + 0.7531999805212, posZ), false, mc.player.horizontalCollision));
                break;
            case 1:
                for (Entity entity : mc.world.getEntities()) {
                    if (entity.getName().getString().equalsIgnoreCase(args[0]) && entity instanceof PlayerEntity) {
                        novoline.getNotificationManager().pop("Teleporting to player " + args[0], 5100, NotificationType.INFO);
                        sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(new Vec3d(posX, posY + 0.41999998688698, posZ), false, mc.player.horizontalCollision));
                        sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(new Vec3d(posX, posY + 0.7531999805212, posZ), false, mc.player.horizontalCollision));
                        playerTP = true;
                        player = (PlayerEntity) entity;
                        break;
                    }
                }
                if (!playerTP) {
                    novoline.getNotificationManager().pop("Unable to locate a player " + args[0] + " in your world", 1000, NotificationType.INFO);
                }
                break;
            default:
                if (!playerTP) {
                    novoline.getNotificationManager().pop("Unable to parse the coordinates!", "Please specify a valid coordinates!", 5000, NotificationType.ERROR);
                }
        }
        airFreeze = false;
        cancel = true;
        tempYDiff = 0;
        tempXDiff = 0;
        tempZDiff = 0;
        if (args.length != 1) {
            tpVec = new Vec3(Integer.parseInt(args[0]), Integer.parseInt(args[1]), Integer.parseInt(args[2]));
        }
        toRender.clear();
    }

    // PORT: NetHandlerPlayClient#sendPacketNoEvent was a jar patch; mirrors AbstractModule#sendPacketNoEvent.
    private void sendPacketNoEvent(@NotNull Packet<?> packet) {
        if (mc.player != null) {
            novoline.getNoEventSend().set(true);
            try {
                mc.player.networkHandler.sendPacket(packet);
            } finally {
                novoline.getNoEventSend().remove();
            }
        }
    }

    protected final Vec3d getVectorForRotation(float pitch, float yaw) {
        float f = MathHelper.cos((float) (Math.toRadians(-yaw) - Math.PI));
        float f1 = MathHelper.sin((float) (Math.toRadians(-yaw) - Math.PI));
        float f2 = -MathHelper.cos((float) Math.toRadians(-pitch));
        float f3 = MathHelper.sin((float) Math.toRadians(-pitch));
        return new Vec3d(f1 * f2, f3, f * f2);
    }

    @EventTarget
    public void onPacketReceived(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (cancel && event.getPacket() instanceof PlayerPositionLookS2CPacket) {
                cancel = false;
            }

        } else {
            if (event.getPacket() instanceof PlayerMoveC2SPacket && cancel) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onMove(MoveEvent moveEvent) {
        // Фризить игрока в воздухе на некоторое время во избежании morepackets
        if (airFreeze) {
            mc.player.setVelocity(0, 0, 0);
            moveEvent.setX(mc.player.getVelocity().x);
            moveEvent.setY(mc.player.getVelocity().y);
            moveEvent.setZ(mc.player.getVelocity().z);

            if (timer.delay(5000)) {
                airFreeze = false;
                EventManager.unregister(this);
            }
        }
    }

    List<Vec3> toRender = new ArrayList<>();

    public static void blockESPBox(BlockPos blockPos) {
        // PORT: GL11/RenderGlobal immediate mode is gone; RenderUtils takes absolute coords
        // (camera offset applied internally). Only usable inside Render3DEvent world context.
        cc.novoline.utils.RenderUtils.drawOutlinedBoundingBox(new net.minecraft.util.math.Box(
                blockPos.getX(), blockPos.getY(), blockPos.getZ(),
                blockPos.getX() + 1.0, blockPos.getY() + 1.0, blockPos.getZ() + 1.0));
    }


    @EventTarget
    public void onHypixelPre(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            // todo: если что-то меняешь, то посылать пакет на x + 0.5, y + 0.0125, z + 0.5, а не прямо на точку!!!

            // PORT: EntityPlayerSP#isMoving was a jar patch; checks movement input directly
            if (mc.player.input.getMovementInput().lengthSquared() != 0) {
                EventManager.unregister(this);


                if (cancel) {
                    novoline.getNotificationManager().pop("Teleport cancelled due to movement!", 5000, NotificationType.WARNING);
                    airFreeze = true;
                    cancel = false;
                }
            }

            if (!airFreeze) {
                if (playerTP) {
                    teleportToLocation(new Vec3(mc.player.getX(), mc.player.getY(), mc.player.getZ()), new Vec3(player.getX(), player.getY(), player.getZ()), true, true);
                } else {
                    teleportToLocation(new Vec3(mc.player.getX(), mc.player.getY(), mc.player.getZ()), new Vec3(tpVec.getX(), tpVec.getY(), tpVec.getZ()), true, true);
                }
            }
        }
    }

    // Если точка в пути "соприкосается" с блоком, то нужно обязательно послать пакет
    private boolean blocksAround(BlockPos pos) {
        // PORT: tallgrass/double_plant/yellow_flower/red_flower were flattened; all plants are passable
        return !mc.world.getBlockState(pos).isAir() &&
                !(mc.world.getBlockState(pos).getBlock() instanceof PlantBlock) &&
                !(mc.world.getBlockState(pos).getBlock() instanceof TallPlantBlock);
    }


    public void teleportToLocation(Vec3 startVec, Vec3 endVec, boolean setPosition, boolean freeze) {
        // Добавлять все точки для посылания пакетов на эти точки
        for (Vec3 vec3 : computePath(startVec, endVec)) {
            sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(new Vec3d(vec3.getX(), vec3.getY(), vec3.getZ()), vec3.getY() % 0.125 == 0, mc.player.horizontalCollision));
        }

        // Последний пакет на точку для подстраховки
        sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(new Vec3d(endVec.getX(), endVec.getY(), endVec.getZ()), endVec.getY() % 0.125 == 0, mc.player.horizontalCollision));

        if (setPosition) {
            // PORT: EntityPlayerSP#setPositionAndUpdate is gone; position packet was already sent above
            mc.player.setPosition(endVec.getX(), endVec.getY(), endVec.getZ());
        }

        // Сброс таймера фриза
        if (freeze) {
            timer.reset();
            airFreeze = true;
        } else {
            EventManager.unregister(this);
        }
    }

    private ArrayList<Vec3> computePath(Vec3 topFrom, Vec3 to) {
        // PORT: no BlockPos(Vec3d) ctor — ofFloored matches BlockPos(Vec3) semantics
        if (!canPassThrow(BlockPos.ofFloored(topFrom.getX(), topFrom.getY(), topFrom.getZ()))) {
            topFrom = topFrom.addVector(0, 1, 0);
        }
        AStarCustomPathfinder pathfinder = new AStarCustomPathfinder(topFrom, to);
        pathfinder.compute();

        int i = 0;
        Vec3 lastLoc = null;
        Vec3 lastDashLoc = null;
        ArrayList<Vec3> path = new ArrayList<>();
        ArrayList<Vec3> pathFinderPath = pathfinder.getPath();
        for (Vec3 pathElm : pathFinderPath) {
            if (i == 0 || i == pathFinderPath.size() - 1) {
                if (lastLoc != null) {
                    path.add(lastLoc.addVector(0.5, 0, 0.5));
                }
                path.add(pathElm.addVector(0.5, 0, 0.5));
                lastDashLoc = pathElm;
            } else {
                boolean canContinue = true;
                if (pathElm.squareDistanceTo(lastDashLoc) > 5 * 5) {
                    canContinue = false;
                } else {
                    double smallX = Math.min(lastDashLoc.getX(), pathElm.getX());
                    double smallY = Math.min(lastDashLoc.getY(), pathElm.getY());
                    double smallZ = Math.min(lastDashLoc.getZ(), pathElm.getZ());
                    double bigX = Math.max(lastDashLoc.getX(), pathElm.getX());
                    double bigY = Math.max(lastDashLoc.getY(), pathElm.getY());
                    double bigZ = Math.max(lastDashLoc.getZ(), pathElm.getZ());
                    cordsLoop:
                    for (int x = (int) smallX; x <= bigX; x++) {
                        for (int y = (int) smallY; y <= bigY; y++) {
                            for (int z = (int) smallZ; z <= bigZ; z++) {
                                if (!AStarCustomPathfinder.checkPositionValidity(x, y, z, false)) {
                                    canContinue = false;
                                    break cordsLoop;
                                }
                            }
                        }
                    }
                }
                if (!canContinue) {
                    path.add(lastLoc.addVector(0.5, 0, 0.5));
                    lastDashLoc = lastLoc;
                }
            }
            lastLoc = pathElm;
            i++;
        }
        return path;
    }

    private boolean canPassThrow(BlockPos pos) {
        // PORT: Material is gone; plants/vine/signs via block classes, flowing_water folded into WATER
        Block block = mc.world.getBlockState(new BlockPos(pos.getX(), pos.getY(), pos.getZ())).getBlock();
        return mc.world.getBlockState(pos).isAir() || block instanceof PlantBlock || block instanceof TallPlantBlock
                || block instanceof VineBlock || block == Blocks.LADDER
                || block == Blocks.WATER || block instanceof AbstractSignBlock;
    }
}
