package cc.novoline.commands;

public class NumberInvalidException extends CommandException {

    public NumberInvalidException(String message, Object... objects) {
        super(message, objects);
    }
}
