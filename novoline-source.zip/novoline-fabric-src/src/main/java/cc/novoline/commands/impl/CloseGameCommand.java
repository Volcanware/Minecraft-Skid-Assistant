package cc.novoline.commands.impl;

import cc.novoline.Novoline;
import cc.novoline.commands.CommandException;
import cc.novoline.commands.NovoCommand;
import net.minecraft.client.MinecraftClient;
import org.jetbrains.annotations.NotNull;

public final class CloseGameCommand extends NovoCommand {

    public CloseGameCommand(@NotNull Novoline novoline) {
        super(novoline, "closegame", "Closes the game", java.util.Arrays.asList("quit", "close", "exit"));
    }

    @Override
    public void process(String[] args) throws CommandException {
        MinecraftClient.getInstance().scheduleStop();
    }
}
