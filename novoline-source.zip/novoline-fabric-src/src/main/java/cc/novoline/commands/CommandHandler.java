package cc.novoline.commands;

import cc.novoline.utils.messages.TextMessage;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static cc.novoline.utils.messages.MessageFactory.text;
import static net.minecraft.util.Formatting.RED;

/**
 * Client-side command handler. Commands are dispatched from the chat-send hook
 * when the message starts with the configured prefix.
 */
public class CommandHandler {

    private static final Logger LOGGER = LogManager.getLogger();
    protected final Map<String, NovoCommand> commandMap = new HashMap<>();
    private final Set<NovoCommand> commandSet = new LinkedHashSet<>();
    private final String prefix;

    public CommandHandler(@NotNull String prefix) {
        this.prefix = prefix;
    }

    /** @return true if the message was consumed as a command. */
    public boolean executeCommand(String rawCommand) {
        rawCommand = rawCommand.trim();
        if (!rawCommand.startsWith(this.prefix)) {
            return false;
        }
        rawCommand = rawCommand.substring(this.prefix.length());
        if (rawCommand.isEmpty()) {
            return true;
        }

        String[] args = rawCommand.split(" ");
        final String s = args[0];
        args = dropFirstString(args);
        final NovoCommand command = this.commandMap.get(s);

        if (command == null) {
            sendError("commands.generic.notFound");
        } else {
            tryExecute(command, args, rawCommand);
        }

        return true;
    }

    protected boolean tryExecute(NovoCommand command, String[] args, String input) {
        try {
            command.processCommand(args);
            return true;
        } catch (CommandException e) {
            sendError(e.getMessage());
        } catch (Throwable t) {
            LOGGER.warn("Unexpected error occurred while processing command: \"" + input + "\"");
            sendError("commands.generic.exception");
        }
        return false;
    }

    private void sendError(String message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(text(message, RED).toText(), false);
        }
    }

    public void registerCommand(NovoCommand command) {
        this.commandMap.put(command.getCommandName(), command);
        this.commandSet.add(command);

        for (String s : command.getCommandAliases()) {
            final NovoCommand existing = this.commandMap.get(s);
            if (existing == null || !existing.getCommandName().equals(s)) {
                this.commandMap.put(s, command);
            }
        }
    }

    /**
     * Takes a string array and returns a string array, containing only an empty string if the
     * param array is empty or only has a single element.
     */
    public static String[] dropFirstString(@NotNull String[] input) {
        List<String> var1 = new ObjectArrayList<>();

        for (int var2 = 1; var2 < input.length; ++var2) {
            var1.add(input[var2]);
        }

        return var1.toArray(new String[0]);
    }

    public String getPrefix() {
        return prefix;
    }

    public Set<NovoCommand> getCommands() {
        return commandSet;
    }

    /**
     * Performs a "default" command lookup for the given command.
     */
    public @Nullable NovoCommand getCommandByName(String name) {
        return commandMap.get(name);
    }

    /**
     * @return all possible commands that start with the given prefix.
     */
    public @Nullable List<String> getTabCompletionOptions(String input) {
        List<String> matches = new ObjectArrayList<>();
        String base = input.startsWith(prefix) ? input.substring(prefix.length()) : input;
        for (String name : commandMap.keySet()) {
            if (name.startsWith(base)) matches.add(name);
        }
        return matches;
    }
}
