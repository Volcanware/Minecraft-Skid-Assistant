package cc.novoline.commands.impl;

import cc.novoline.Novoline;
import cc.novoline.commands.CommandException;
import cc.novoline.commands.NovoCommand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.jetbrains.annotations.NotNull;

public final class PitchCommand extends NovoCommand {

    public PitchCommand(@NotNull Novoline novoline) {
        super(novoline, "pitch", "Sets your pitch");
    }

    @Override
    public void process(String[] args) throws CommandException {
        if (args.length != 1) {
            notifyError("Use .pitch (degrees)");
            return;
        }

        final ClientPlayerEntity p = MinecraftClient.getInstance().player;
        p.setPitch((float) getDouble(args[0]));
    }
}
