package cc.novoline.commands.impl;

import cc.novoline.Novoline;
import cc.novoline.commands.CommandException;
import cc.novoline.commands.NovoCommand;
import cc.novoline.events.EventManager;
import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.utils.NovolineRenderLayers;
import cc.novoline.utils.RenderUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.world.ClientChunkManager;
import net.minecraft.registry.Registries;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.jetbrains.annotations.NotNull;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class LocateBlockCommand extends NovoCommand {

    /** pos -> block id we were tracking; removed when mined or its chunk unloads */
    private static final Map<BlockPos, Identifier> tracked = new ConcurrentHashMap<>();
    private static boolean listenerRegistered;

    public LocateBlockCommand(@NotNull Novoline novoline) {
        super(novoline, "locateblock", "Locates the closest matching block",
                java.util.Collections.singleton("findblock"));
    }

    @Override
    public void process(String[] args) throws CommandException {
        if (args.length < 1 || args.length > 2) {
            notifyError("Use .locateblock <minecraft:block_id> [esp]");
            return;
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        Identifier id;
        try {
            id = Identifier.of(args[0].contains(":") ? args[0] : "minecraft:" + args[0]);
        } catch (Exception e) {
            notifyError(args[0] + " is not a valid block id");
            return;
        }

        Block target = Registries.BLOCK.get(id);
        if (target == net.minecraft.block.Blocks.AIR && !id.equals(Identifier.of("minecraft", "air"))) {
            notifyError("Unknown block: " + id);
            return;
        }

        BlockPos found = findClosest(target);
        if (found == null) {
            send("No " + id + " found in loaded chunks", Formatting.RED);
            return;
        }

        double dist = Math.sqrt(mc.player.getBlockPos().getSquaredDistance(found));
        send("Closest " + id + ": " + found.getX() + ", " + found.getY() + ", " + found.getZ()
                + " (" + String.format("%.1f", dist) + " blocks)", Formatting.GREEN);

        if (args.length == 2 && args[1].equalsIgnoreCase("esp")) {
            tracked.put(found, id);
            registerEspListener();
            send("ESP marker placed until it is mined or the chunk unloads", Formatting.GRAY);
        }
    }

    private BlockPos findClosest(Block target) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;

        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                WorldChunk chunk = (WorldChunk) ((ClientChunkManager) mc.world.getChunkManager())
                        .getChunk(pcx + dx, pcz + dz);
                if (chunk == null) continue;

                ChunkSection[] sections = chunk.getSectionArray();
                for (int s = 0; s < sections.length; s++) {
                    ChunkSection section = sections[s];
                    if (section == null || section.isEmpty()) continue;
                    int baseY = chunk.getBottomY() + (s << 4);

                    for (int lx = 0; lx < 16; lx++) {
                        for (int ly = 0; ly < 16; ly++) {
                            for (int lz = 0; lz < 16; lz++) {
                                if (section.getBlockState(lx, ly, lz).getBlock() != target) continue;
                                BlockPos pos = new BlockPos((pcx + dx) * 16 + lx, baseY + ly, (pcz + dz) * 16 + lz);
                                double dist = mc.player.getBlockPos().getSquaredDistance(pos);
                                if (dist < bestDist) {
                                    bestDist = dist;
                                    best = pos;
                                }
                            }
                        }
                    }
                }
            }
        }
        return best;
    }

    private static void registerEspListener() {
        if (listenerRegistered) return;
        listenerRegistered = true;

        EventManager.register(new Object() {
            @EventTarget
            public void onRender3D(Render3DEvent event) {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.world == null || mc.player == null || tracked.isEmpty()) return;

                Iterator<Map.Entry<BlockPos, Identifier>> it = tracked.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<BlockPos, Identifier> e = it.next();
                    BlockPos pos = e.getKey();

                    WorldChunk chunk = (WorldChunk) ((ClientChunkManager) mc.world.getChunkManager())
                            .getChunk(pos.getX() >> 4, pos.getZ() >> 4);
                    if (chunk == null) {
                        it.remove();
                        continue;
                    }

                    BlockState state = mc.world.getBlockState(pos);
                    if (state.getBlock() != Registries.BLOCK.get(e.getValue())) {
                        it.remove();
                        continue;
                    }

                    Box box = new Box(pos);
                    RenderUtils.submitWorld(NovolineRenderLayers.noDepthQuads(), (entry, consumer) ->
                            RenderUtils.boxVertices(consumer, entry.getPositionMatrix(), box, 0x8CFF5555));
                    RenderUtils.submitWorld(RenderLayers.debugQuads(), (entry, consumer) ->
                            RenderUtils.boxVertices(consumer, entry.getPositionMatrix(), box, 0xBFFF5555));
                }
            }
        });
    }
}
