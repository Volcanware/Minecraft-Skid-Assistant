package cc.novoline.commands.impl;

import cc.novoline.Novoline;
import cc.novoline.commands.CommandException;
import cc.novoline.commands.NovoCommand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.jetbrains.annotations.NotNull;

public final class VClipCommand extends NovoCommand {

    /* constructors */
    public VClipCommand(@NotNull Novoline novoline) {
        super(novoline, "vc", "vclip");
    }

    /* methods */
    @Override
    public void process(String[] args) throws CommandException {
        if (args.length != 1) {
            notifyError("Use .vclip (height)");
            return;
        }

        final ClientPlayerEntity p = MinecraftClient.getInstance().player;
        final double height = getDouble(args[0]);

        // PORT: EntityPlayerSP#setPositionAndUpdate is gone; setPosition updates pos + bounding box
        // and the position packet is sent by tickMovement on the next tick.
        p.setPosition(p.getX(), p.getY() + height, p.getZ());
    }

}
