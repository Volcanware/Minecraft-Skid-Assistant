package cc.novoline.commands.impl;

import cc.novoline.Novoline;
import cc.novoline.commands.CommandException;
import cc.novoline.commands.NovoCommand;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;

public final class HelpCommand extends NovoCommand {

    public HelpCommand(@NotNull Novoline novoline) {
        super(novoline, "help", "Lists all commands");
    }

    @Override
    public void process(String[] args) throws CommandException {
        send("Commands:", Formatting.GOLD);
        novoline.getNovoCommandHandler().getCommands().stream()
                .sorted((a, b) -> a.getCommandName().compareToIgnoreCase(b.getCommandName()))
                .forEach(command -> {
                    String desc = command.getDescription() != null ? command.getDescription() : "";
                    send(Formatting.GRAY + " ." + command.getCommandName()
                            + Formatting.DARK_GRAY + " - "
                            + Formatting.WHITE + desc);
                });
    }
}
