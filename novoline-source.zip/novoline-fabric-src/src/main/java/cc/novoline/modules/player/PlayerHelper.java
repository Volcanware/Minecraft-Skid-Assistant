package cc.novoline.modules.player;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.NotNull;

/**
 * Ports of the methods Novoline 1.8.9 patched directly onto EntityPlayerSP/Entity:
 * updateTool, isBlockUnder, drop, shiftClick, swap, getSlotByItem.
 */
public final class PlayerHelper {

    private PlayerHelper() {
    }

    public static void updateTool(@NotNull MinecraftClient mc, @NotNull BlockPos pos) {
        ClientPlayerEntity player = mc.player;

        if (player == null || mc.world == null) {
            return;
        }

        BlockState state = mc.world.getBlockState(pos);
        float strength = 1.0F;
        int slot = -1;

        PlayerInventory inventory = player.getInventory();

        for (int i = 0; i < 9; ++i) {
            ItemStack itemStack = inventory.getStack(i);

            if (!itemStack.isEmpty() && itemStack.getMiningSpeedMultiplier(state) > strength) {
                slot = i;
                strength = itemStack.getMiningSpeedMultiplier(state);
            }
        }

        if (slot != -1 && inventory.getStack(inventory.getSelectedSlot()) != inventory.getStack(slot)) {
            inventory.setSelectedSlot(slot);
        }
    }

    public static int getSlotByItem(@NotNull ClientPlayerEntity player, @NotNull Item item) {
        PlayerInventory inventory = player.getInventory();

        for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getStack(i);

            if (!stack.isEmpty() && stack.getItem() == item) {
                return i;
            }
        }

        return -1;
    }

    public static void drop(@NotNull MinecraftClient mc, int slot) {
        windowClick(mc, slot, 1, SlotActionType.THROW);
    }

    public static void shiftClick(@NotNull MinecraftClient mc, int slot) {
        windowClick(mc, slot, 0, SlotActionType.QUICK_MOVE);
    }

    public static void swap(@NotNull MinecraftClient mc, int inventorySlot, int hotbarSlot) {
        windowClick(mc, inventorySlot, hotbarSlot, SlotActionType.SWAP);
    }

    public static void windowClick(@NotNull MinecraftClient mc, int slot, int button, @NotNull SlotActionType type) {
        if (mc.player != null) {
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot, button, type, mc.player);
        }
    }

    public static boolean isBlockUnder(@NotNull ClientPlayerEntity player) {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.world == null) {
            return false;
        }

        for (int i = (int) (player.getY() - 1.0); i > mc.world.getBottomY(); --i) {
            BlockPos pos = BlockPos.ofFloored(player.getX(), i, player.getZ());
            if (mc.world.getBlockState(pos).isAir()) continue;
            return true;
        }

        return false;
    }
}
