package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render2DEvent;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.ColorProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.configurations.property.object.StringProperty;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.ScaledResolution;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector4d;
import org.joml.Vector4f;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static cc.novoline.gui.screen.setting.Manager.put;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createColor;
import static java.awt.Color.BLACK;

public final class ChestESP extends AbstractModule {

    /* properties @off */
    @Property("color")
    private final ColorProperty color = createColor(0xFFFF00C5);
    @Property("mode")
    private final StringProperty mode = PropertyFactory.createString("Outline").acceptableValues("Outline", "Filled", "Chams", "Box");
    @Property("color-visible")
    private final ColorProperty visible = createColor(new Color(255, 101, 101).getRGB());
    @Property("color-hidden")
    private final ColorProperty hidden = createColor(new Color(165, 163, 165).getRGB());

    /* getters */
    public StringProperty getMode() {
        return mode;
    }

    /* constructors @on */
    public ChestESP(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "ChestESP", "Chest ESP", Keyboard.KEY_NONE, EnumModuleType.VISUALS);
        put(new Setting("CHEST_ESP_MODE", "Mode", SettingType.COMBOBOX, this, mode));
        put(new Setting("CHESTESP_COLOR", "Color", SettingType.COLOR_PICKER, this, this.color, null, () -> !mode.get().equalsIgnoreCase("Chams")));
        put(new Setting("CHESTESP_COLOR", "Visible", SettingType.COLOR_PICKER, this, this.visible, null, () -> mode.get().equalsIgnoreCase("Chams")));
        put(new Setting("CHESTESP_COLOR", "Hidden", SettingType.COLOR_PICKER, this, this.hidden, null, () -> mode.get().equalsIgnoreCase("Chams")));
    }

    /* methods */
    /**
     * The box to draw for a chest block entity — a double-wide box when the
     * chest merges with a +x/-z neighbor, null when this half's partner already
     * owns the merged box (or on unexpected adjacency).
     */
    private @Nullable Box getChestBox(@NotNull BlockEntity blockEntity) {
        final double posX = blockEntity.getPos().getX(), posY = blockEntity.getPos().getY(), posZ = blockEntity.getPos().getZ();
        final Block block = this.mc.world.getBlockState(new BlockPos((int) posX, (int) posY, (int) posZ)).getBlock();
        final Block x1 = this.mc.world.getBlockState(new BlockPos((int) (posX + 1.0), (int) posY, (int) posZ)).getBlock(), // @off
                x2 = this.mc.world.getBlockState(new BlockPos((int) (posX - 1.0), (int) posY, (int) posZ)).getBlock(),
                z1 = this.mc.world.getBlockState(new BlockPos((int) posX, (int) posY, (int) (posZ + 1.0))).getBlock(),
                z2 = this.mc.world.getBlockState(new BlockPos((int) posX, (int) posY, (int) (posZ - 1.0))).getBlock(); // @on

        if (x1 == block) {
            return renderOutlineZero(posX, posY, posZ);
        } else if (z2 == block) {
            return renderOutlineFirst(posX, posY, posZ);
        } else if (x2 != block && z1 != block) {
            return renderOutlineSecond(posX, posY, posZ);
        }
        return null;
    }

    /** Filled mode — translucent quads on the render-command queue. */
    private void renderFilled(@NotNull BlockEntity blockEntity) {
        Box box = getChestBox(blockEntity);
        if (box == null) return;
        final float[] colors = this.getColorForTileEntity();
        int color = toRGBAHex(colors[0] / 255.0f, colors[1] / 255.0f, colors[2] / 255.0f, 0.2f);
        RenderUtils.submitWorld(RenderLayers.debugQuads(), (entry, consumer) ->
                RenderUtils.boxVertices(consumer, entry.getPositionMatrix(), box, color));
    }

    /** Outline mode — line box edges in the configured color. */
    private void renderOutline(@NotNull BlockEntity blockEntity) {
        Box box = getChestBox(blockEntity);
        if (box == null) return;
        int color = new Color(this.color.getAwtColor().getRed(), this.color.getAwtColor().getGreen(),
                this.color.getAwtColor().getBlue(), 200).getRGB();
        RenderUtils.submitWorld(RenderLayers.lines(), (entry, consumer) ->
                RenderUtils.boxOutlineVertices(consumer, entry.getPositionMatrix(), box, color));
    }

    /**
     * Chams mode: the 1.8.9 stencil buffer approach is replaced by two quads
     * passes — a no-depth pass tinted "hidden" (shows through walls) plus a
     * normal-depth pass tinted "visible" (unoccluded parts take that color).
     */
    private void renderChams(@NotNull BlockEntity blockEntity) {
        Box box = getChestBox(blockEntity);
        if (box == null) return;
        int hiddenColor = new Color(hidden.getAwtColor().getRed(), hidden.getAwtColor().getGreen(), hidden.getAwtColor().getBlue(), 100).getRGB();
        int visibleColor = new Color(visible.getAwtColor().getRed(), visible.getAwtColor().getGreen(), visible.getAwtColor().getBlue(), 100).getRGB();
        // occluded pass — visible through walls
        RenderUtils.submitWorld(cc.novoline.utils.NovolineRenderLayers.noDepthQuads(), (entry, consumer) ->
                RenderUtils.boxVertices(consumer, entry.getPositionMatrix(), box, hiddenColor));
        // normal pass — only the unoccluded pixels land on top
        RenderUtils.submitWorld(RenderLayers.debugQuads(), (entry, consumer) ->
                RenderUtils.boxVertices(consumer, entry.getPositionMatrix(), box, visibleColor));
    }

    // PORT: RenderManager.renderPos* is gone — RenderUtils subtracts the camera
    // position inside boxVertices, so the boxes are built in absolute world coords.
    private @NotNull Box renderOutlineSecond(double posX, double posY, double posZ) {
        return new Box(posX + 0.05000000074505806, posY,
                posZ + 0.05000000074505806,
                posX + 0.949999988079071,
                posY + 0.8999999761581421,
                posZ + 0.949999988079071);
    }

    private @NotNull Box renderOutlineFirst(double posX, double posY, double posZ) {
        return new Box(posX + 0.05000000074505806, posY,
                posZ + 0.05000000074505806 - 1.0,
                posX + 0.949999988079071,
                posY + 0.8999999761581421,
                posZ + 0.949999988079071);
    }

    private @NotNull Box renderOutlineZero(double posX, double posY, double posZ) {
        return new Box(posX + 0.05000000074505806, posY,
                posZ + 0.05000000074505806,
                posX + 1.9500000476837158,
                posY + 0.8999999761581421,
                posZ + 0.949999988079071);
    }

    public float[] getColorForTileEntity() {
        final Color color = this.color.getAwtColor();
        return new float[]{(float) color.getRed(), color.getGreen(), color.getBlue(), 200.0f};
    }

    public int toRGBAHex(float r, float g, float b, float a) {
        return ((int) (a * 255.0f) & 255) << 24 | ((int) (r * 255.0f) & 255) << 16 | ((int) (g * 255.0f) & 255) << 8 | (int) (b * 255.0f) & 255;
    }

    /**
     * world.getBlockEntities() is always empty on the client world in 1.21.11 —
     * block entities live per-chunk. Scans loaded chunks around the player.
     */
    private List<BlockEntity> scanChestEntities() {
        List<BlockEntity> out = new ArrayList<>();
        if (this.mc.world == null || this.mc.player == null) return out;
        int pcx = this.mc.player.getBlockPos().getX() >> 4;
        int pcz = this.mc.player.getBlockPos().getZ() >> 4;
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                net.minecraft.world.chunk.WorldChunk chunk =
                        (net.minecraft.world.chunk.WorldChunk)
                                ((net.minecraft.client.world.ClientChunkManager) this.mc.world.getChunkManager())
                                        .getChunk(pcx + dx, pcz + dz);
                if (chunk != null) {
                    out.addAll(chunk.getBlockEntities().values());
                }
            }
        }
        return out;
    }

    /* events */
    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (mode.equals("Filled") || mode.equals("Chams") || mode.equals("Outline")) {
            for (BlockEntity blockEntity : scanChestEntities()) {
                if (blockEntity instanceof ChestBlockEntity || blockEntity instanceof EnderChestBlockEntity) {
                    if (!blockEntity.isRemoved() && this.mc.world.getBlockState(blockEntity.getPos()) != null) {
                        if (mode.equals("Filled")) {
                            renderFilled(blockEntity);
                        } else if (mode.equals("Chams")) {
                            renderChams(blockEntity);
                        } else {
                            renderOutline(blockEntity);
                        }
                    }
                }
            }
        } else if (mode.equals("Box")) {
            boxPositions.clear();

            // PORT: world->screen projection is done here during the world pass —
            // inside Render3DEvent the view/projection matrices are still the
            // camera's, so the GLU.gluProject equivalent (viewProjection * corner)
            // produces valid screen coordinates. Drawn later in on2D.
            ScaledResolution resolution = new ScaledResolution(mc);
            viewProjection = new Matrix4f()
                    .set(mc.gameRenderer.getBasicProjectionMatrix(((cc.novoline.mixin.GameRendererAccessor) mc.gameRenderer).novoline$getFov(mc.gameRenderer.getCamera(), mc.getRenderTickCounter().getTickProgress(true), true)))
                    .mul(event.getMatrixStack().peek().getPositionMatrix());
            cameraPos = RenderUtils.cameraPos();

            for (BlockEntity collectedEntity : scanChestEntities()) {
                if (!(collectedEntity instanceof ChestBlockEntity)) continue;
                BlockPos pos = collectedEntity.getPos();
                Box box = new Box(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1);
                List<Vector3d> vectors = Arrays.asList(new Vector3d(box.minX, box.minY, box.minZ),
                        new Vector3d(box.minX, box.maxY, box.minZ), new Vector3d(box.maxX, box.minY, box.minZ),
                        new Vector3d(box.maxX, box.maxY, box.minZ), new Vector3d(box.minX, box.minY, box.maxZ),
                        new Vector3d(box.minX, box.maxY, box.maxZ), new Vector3d(box.maxX, box.minY, box.maxZ),
                        new Vector3d(box.maxX, box.maxY, box.maxZ));

                Vector4d position = null;

                for (Vector3d vector : vectors) {
                    vector = project2D(resolution, vector.x - cameraPos.x,
                            vector.y - cameraPos.y,
                            vector.z - cameraPos.z);

                    if (vector != null && vector.z >= 0.0 && vector.z < 1.0) {
                        if (position == null) {
                            position = new Vector4d(vector.x, vector.y, vector.z, 0.0);
                        }

                        position.x = Math.min(vector.x, position.x);
                        position.y = Math.min(vector.y, position.y);
                        position.z = Math.max(vector.x, position.z);
                        position.w = Math.max(vector.y, position.w);
                    }
                }

                if (position != null) {
                    boxPositions.add(position);
                }
            }
        }
    }

    @EventTarget
    public void on2D(Render2DEvent event) {
        if (mode.equals("Box")) {
            for (Vector4d position : boxPositions) {
                double posX = position.x, // @off
                        posY = position.y,
                        endPosX = position.z,
                        endPosY = position.w;
                RenderUtils.drawCornerBox(posX, posY, endPosX, endPosY, 3, BLACK);

                RenderUtils.drawCornerBox(posX, posY, endPosX, endPosY, 1, color.getAwtColor()); // @on
            }
        }
    }

    // PORT: replaces the IntBuffer/FloatBuffer GL state capture — the matrices are
    // read once per frame in onRender3D instead of glGetFloat during projection.
    private final List<Vector4d> boxPositions = new ArrayList<>();
    private Matrix4f viewProjection = new Matrix4f();
    private Vec3d cameraPos = Vec3d.ZERO;

    private Vector3d project2D(ScaledResolution scaledResolution, double x, double y, double z) {
        Vector4f clip = viewProjection.transform(new Vector4f((float) x, (float) y, (float) z, 1.0F));

        if (clip.w <= 0.0F) {
            return null;
        }

        double ndcX = clip.x / clip.w, ndcY = clip.y / clip.w, ndcZ = clip.z / clip.w;
        double winX = (ndcX * 0.5D + 0.5D) * mc.getWindow().getFramebufferWidth();
        double winY = (0.5D - ndcY * 0.5D) * mc.getWindow().getFramebufferHeight();

        return new Vector3d(winX / scaledResolution.getScaleFactor(),
                winY / scaledResolution.getScaleFactor(), (ndcZ + 1.0D) * 0.5D);
    }

    public void pre3D() {
        // PORT: called by the (pending) chest/ender-chest renderer mixins before a
        // chams/outline pass — the stencil FBO + GL attribute stack have no direct
        // equivalent; outline needs a RenderLayer-based approach (see hooks_needed).
        checkSetupFBO();
    }

    public void checkSetupFBO() {
        final Framebuffer framebuffer = mc.getFramebuffer();

        // PORT: Framebuffer depth/stencil attachment juggling (EXT renderbuffers)
        // is obsolete — modern framebuffers manage depth attachments internally.
        if (framebuffer != null && framebuffer.getDepthAttachment() != null) {
            setupFBO(framebuffer);
        }
    }

    public void setupFBO(Framebuffer fbo) {
        // PORT: stencil-buffer setup via EXTFramebufferObject is obsolete — see pre3D.
    }

    public void setupStencil() {
        // PORT: stencil write pass — see pre3D / hooks_needed.
    }

    public void setupStencil2() {
        // PORT: stencil read pass — see pre3D / hooks_needed.
    }


    public void setupStencilFirst() {
        // PORT: see setupStencil.
    }

    public void setupStencilSecond() {
        // PORT: see setupStencil2.
    }

    public void renderOutline(int color) {
        // PORT: called by the (pending) chest renderer mixin to tint + depth-pull
        // the occluded pass — polygon offset / lightmap override need the
        // RenderLayer-based approach described in hooks_needed.
        setColor(color);
    }

    public void setColor(int i) {
        float f = (float) (i >> 24 & 255) / 255f;
        float f0 = (float) (i >> 16 & 255) / 255f;
        float f1 = (float) (i >> 8 & 255) / 255f;
        float f2 = (float) (i & 255) / 255f;
        if (f == 0.0f) {
            f = 1f;
        }
        // PORT: glColor4f is gone — vertex colors are baked per-vertex; kept so the
        // renderer mixin can pack this tint into emitted vertices.
        RenderUtils.setColor(new Color(f0, f1, f2, f));
    }

    public void post3D() {
        // PORT: counterpart state restore for pre3D — see hooks_needed.
    }

    public ColorProperty getHidden() {
        return hidden;
    }

    public ColorProperty getVisible() {
        return visible;
    }
}
