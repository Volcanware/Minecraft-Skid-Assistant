package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

import static net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode.START_SPRINTING;
import static net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode.STOP_SPRINTING;

public final class Sprint extends AbstractModule {

    private boolean sprinting;

    /* constructors @on */
    public Sprint(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Sprint", "Sprint", Keyboard.KEY_NONE, EnumModuleType.MOVEMENT);
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.OUTGOING)) {
            if (event.getPacket() instanceof ClientCommandC2SPacket) {
                ClientCommandC2SPacket packet = (ClientCommandC2SPacket) event.getPacket();

                if (packet.getMode().name().toLowerCase().contains("sprint")) {
                    if (mc.player.isOnGround()) {
                        if (packet.getMode().equals(START_SPRINTING)) {
                            sprinting = true;
                        } else if (packet.getMode().equals(STOP_SPRINTING)) {
                            sprinting = false;
                        }
                    }

                    event.setCancelled(true);
                }
            }
        }
    }

    /* events */
    @EventTarget
    public void onMotion(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            mc.player.setSprinting(MoveUtils.isMoving(mc.player));

            if (mc.player.isOnGround() && !isEnabled(Scaffold.class)) {
                if (mc.player.isSprinting() != sprinting) {
                    ClientCommandC2SPacket packetEntity = new ClientCommandC2SPacket(mc.player, mc.player.isSprinting() ? START_SPRINTING : STOP_SPRINTING);
                    sendPacketNoEvent(packetEntity);
                    sprinting = mc.player.isSprinting();
                }
            }
        }
    }
}
