package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import org.jetbrains.annotations.NotNull;

public class FastSneak extends AbstractModule {

    public FastSneak(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.MOVEMENT, "FastSneak", "Fast Sneak");
    }

    @EventTarget
    public void onPre(MotionUpdateEvent event) {
        if (MoveUtils.sneaking(mc.player) && MoveUtils.isMoving(mc.player)) {
            // PORT: C0BPacketEntityAction START/STOP_SNEAKING no longer exist; the server
            // reads sneaking state from PlayerInputC2SPacket, so we send that instead.
            if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
                sendPacketNoEvent(MoveUtils.sneakPacket(mc.player, false));
            } else {
                sendPacketNoEvent(MoveUtils.sneakPacket(mc.player, true));
            }
        }
    }
}
