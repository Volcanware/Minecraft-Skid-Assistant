package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.events.events.MoveEvent;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.modules.exploits.Disabler;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.Hand;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Flight extends AbstractModule {

    private int tick;
    private boolean wait;
    private int key;
    private short id;
    private List<Packet<?>> listPosition = new CopyOnWriteArrayList();
    private List<Packet<?>> listPing = new CopyOnWriteArrayList();

    @Property("dmg-mode")
    private final StringProperty dmg_mode = PropertyFactory.createString("Normal").acceptableValues("Fast", "Normal");
    @Property("speed")
    private final DoubleProperty speed = PropertyFactory.createDouble(2.5D).maximum(9.0D).minimum(1.0D);
    @Property("viewbobbing")
    private final FloatProperty view_bobbing = PropertyFactory.createFloat(60.0F).minimum(0.0F).maximum(100.0F);
    @Property("pearl")
    private final BooleanProperty pearl = PropertyFactory.booleanFalse();

    public Flight(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.MOVEMENT, "Flight", "Flight");
        //   Manager.put(new Setting("FLY_DMG_MODE", "Damage", SettingType.COMBOBOX, this, dmg_mode));
        Manager.put(new Setting("FLY_SPEED", "Speed", SettingType.SLIDER, this, speed, 0.1));
        Manager.put(new Setting("FLY_VB", "Viewbobbing", SettingType.SLIDER, this, view_bobbing, 5.0F));
        Manager.put(new Setting("FLY_PEARL", "Pearl boost", SettingType.CHECKBOX, this, pearl));
    }

    @Override
    public void onDisable() {
        if (tick > 0) {
            mc.player.setVelocity(0, -0.41999998688698, 0);
            MoveUtils.setTimerSpeed(1.0F);
        }

        getModule(Disabler.class).getTimer().reset();
        wait = false;
        tick = 0;
    }


    @Override
    public void onEnable() {
        checkModule(Speed.class, Scaffold.class);

        if (mc.player.isOnGround() && pearl.get() && pearlSlot() != -1) {
            wait = true;
            throwPearl();
            mc.player.setVelocity(mc.player.getVelocity().x, MoveUtils.getBaseMotionY(mc.player), mc.player.getVelocity().z);
        }

        setSuffix("Vanilla");
    }

    public int pearlSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);

            if (stack != null && stack.getItem() == Items.ENDER_PEARL && (!ServerUtils.serverIs(Servers.SW) ||
                    ServerUtils.inGameSeconds() >= 30 || !stack.getName().getString().contains("\u00A7"))) {
                return i;
            }
        }

        return -1;
    }

    private void throwPearl() {
        sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(pearlSlot()));
        sendPacketNoEvent(new PlayerMoveC2SPacket.LookAndOnGround(mc.player.getYaw(), 90, mc.player.isOnGround(), mc.player.horizontalCollision));
        sendPacketNoEvent(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
        sendPacketNoEvent(new PlayerMoveC2SPacket.LookAndOnGround(mc.player.getYaw(), mc.player.getPitch(), mc.player.isOnGround(), mc.player.horizontalCollision));
        sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().getSelectedSlot()));
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (event.getPacket() instanceof PlayerPositionLookS2CPacket) {
                if (wait) {
                    wait = false;
                } else if (tick > 3) {
                    checkModule(getClass());
                }
            }
        }
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        if (!wait && MoveUtils.isMoving(mc.player)) {
            tick++;
        }

        setSuffix("Vanilla");
    }

    private int getPacketsSize() {
        int jumps = mc.player.hasStatusEffect(StatusEffects.JUMP_BOOST) ? mc.player.getStatusEffect(StatusEffects.JUMP_BOOST).getAmplifier() + 1 : 0;
        int hypixel = ServerUtils.serverIs(Servers.UHC) || ServerUtils.serverIs(Servers.SG) || ServerUtils.serverIs(Servers.MW) ? 1 : 0;
        double fallHeight = 3 + jumps + hypixel, amp = 0.125;

        return (int) (fallHeight / amp) * 2 + 2;
    }

    @EventTarget
    public void onPre(MotionUpdateEvent event) {
        if (event.getState() == MotionUpdateEvent.State.PRE) {
            // PORT: 1.8.9's mc.player.cameraYaw (view-bobbing camera roll) has no modern
            // field; needs a GameRenderer bobView mixin hook in shared infra.
            // mc.player.cameraYaw = view_bobbing.get() / 1000.0F;

            if (MoveUtils.jumping(mc.player)) {
                mc.player.setVelocity(mc.player.getVelocity().x, 1.8, mc.player.getVelocity().z);
            } else if (MoveUtils.sneaking(mc.player)) {
                mc.player.setVelocity(mc.player.getVelocity().x, -1.8, mc.player.getVelocity().z);
            } else if (!mc.player.isOnGround()) {
                mc.player.setVelocity(mc.player.getVelocity().x, 0.0, mc.player.getVelocity().z);
            }
        }
    }

    @EventTarget
    public void onMove(MoveEvent event) {
        event.setMoveSpeed(wait ? 0 : speed.get());
    }

    public DoubleProperty getSpeed() {
        return speed;
    }

    public int getTick() {
        return tick;
    }
}
