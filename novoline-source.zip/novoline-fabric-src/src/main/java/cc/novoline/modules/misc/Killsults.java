package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.LoadWorldEvent;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.combat.KillAura;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import cc.novoline.utils.Timer;
import cc.novoline.utils.tasks.FutureTask;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.NotNull;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

import static cc.novoline.gui.screen.setting.SettingType.CHECKBOX;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.booleanFalse;

public final class Killsults extends AbstractModule {

    /* fields */
    private List<PlayerEntity> lastTargets = new CopyOnWriteArrayList<>();
    private List<String> killsults = new CopyOnWriteArrayList<>();
    private final Timer timer = new Timer();
    private Path path = Paths.get(novoline.getPathString() + "Killsults.novo");
    private int order;
    private boolean spectator;

    /* properties @off */
    @Property("random-order")
    private final BooleanProperty randomOrder = booleanFalse();

    /* constructors @on */
    public Killsults(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Killsults", "Killsults", EnumModuleType.MISC, "Insults your opponents");
        Manager.put(new Setting("KS_RANDOM", "Random Order", CHECKBOX, this, this.randomOrder));
    }

    /* methods */
    @Override
    public void onDisable() {
        if (!lastTargets.isEmpty()) {
            lastTargets.clear();
        }

        spectator = false;
        order = 0;
    }

    @Override
    public void onEnable() {
        loadSults();
    }

    public void loadSults() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(path.toString()));
            List<String> list = reader.lines().collect(Collectors.toList());

            if (!list.isEmpty()) {
                for (String str : list) {
                    if (!killsults.contains(str)) {
                        killsults.add(str);
                    }
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    private int delay() {
        String name = mc.player.getDisplayName().getString();
        return name.contains("VIP") || name.contains("MVP") ? 1100 : 3100;
    }

    public int neededDelay() {
        return (int) (delay() - MathHelper.clamp(timer.getCurrentMS() - timer.getLastMS(), 0, delay()));
    }

    private void sendSultMessage(PlayerEntity player) {
        if (randomOrder.get()) {
            order = ThreadLocalRandom.current().nextInt(0, killsults.size());
        } else {
            order++;

            if (order >= killsults.size()) {
                order = 0;
            }
        }

        String fromList = killsults.get(order);
        String string = fromList.replace("§", "").replace("%s", player.getName().getString());
        char[] chars = string.toCharArray();
        StringBuilder sult = new StringBuilder();

        for (char aChar : chars) {
            sult.append(aChar);

            for (int i = 0; i < ThreadLocalRandom.current().nextInt(0, 3); i++) {
                sult.append('ֽ');
            }
        }

        // PORT: C01PacketChatMessage is gone — the network handler signs and sends the chat packet
        // itself; the noEventSend flag preserves sendPacketNoEvent semantics
        novoline.getNoEventSend().set(true);
        try {
            mc.player.networkHandler.sendChatMessage(sult.toString());
        } finally {
            novoline.getNoEventSend().remove();
        }
        lastTargets.remove(player);
        timer.reset();
    }

    /* events */
    @EventTarget
    public void onMessage(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            // PORT: S2FPacketSetSlot -> ScreenHandlerSlotUpdateS2CPacket
            if (event.getPacket() instanceof ScreenHandlerSlotUpdateS2CPacket) {
                ScreenHandlerSlotUpdateS2CPacket packet = (ScreenHandlerSlotUpdateS2CPacket) event.getPacket();
                ItemStack stack = packet.getStack();

                // PORT: modern Text stores colour in Style, not as a "§" code — a custom name
                // component is the closest equivalent of a formatted display name
                if (stack.getName().getString().contains("Spectator")
                        && (stack.getName().getString().contains("§") || stack.contains(DataComponentTypes.CUSTOM_NAME))) {
                    spectator = true;
                }
            }

            if (!ServerUtils.serverIs(Servers.PRE) && !ServerUtils.serverIs(Servers.LOBBY)) {
                // PORT: S38PacketPlayerListItem#REMOVE_PLAYER was split into PlayerRemoveS2CPacket
                // (a bare list of UUIDs) in modern versions
                if (!spectator && event.getPacket() instanceof PlayerRemoveS2CPacket) {
                    PlayerRemoveS2CPacket packet = (PlayerRemoveS2CPacket) event.getPacket();

                    for (UUID uuid : packet.profileIds()) {
                        PlayerEntity player = (PlayerEntity) mc.world.getEntity(uuid);
                        PlayerListEntry playerData = mc.getNetworkHandler().getPlayerListEntry(uuid);

                        if (player != null && !player.equals(mc.player)) {
                            if ((playerData == null || playerData.getProfile().name() == null) && player.getHealth() < player.getMaxHealth() && lastTargets.contains(player)) {
                                if (timer.delay(delay())) {
                                    sendSultMessage(player);
                                } else {
                                    novoline.getTaskManager().queue(new FutureTask(neededDelay()) {
                                        @Override
                                        public void execute() {
                                            sendSultMessage(player);
                                        }

                                        @Override
                                        public void run() {

                                        }
                                    });
                                }
                            }
                        }
                    }
                }

            } else if (spectator) {
                spectator = false;
            }
        }
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        if (!lastTargets.isEmpty()) {
            lastTargets.clear();
        }

        spectator = false;
        order = 0;
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (isEnabled(KillAura.class) && getModule(KillAura.class).shouldAttack()) {
            KillAura killAura = getModule(KillAura.class);

            if (killAura.getTarget() != null && killAura.getTarget() instanceof PlayerEntity) {
                PlayerEntity target = (PlayerEntity) killAura.getTarget();

                if (!lastTargets.contains(target)) {
                    lastTargets.add(target);
                }
            }
        }
    }

    public List<String> getKillsults() {
        return killsults;
    }

    public Path getPath() {
        return path;
    }
}
