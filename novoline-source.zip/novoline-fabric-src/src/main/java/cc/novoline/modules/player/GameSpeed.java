package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.FloatProperty;
import cc.novoline.modules.move.MoveUtils;
import net.minecraft.entity.effect.StatusEffects;
import org.jetbrains.annotations.NotNull;

public class GameSpeed extends AbstractModule {

    @Property("value")
    private final FloatProperty value = FloatProperty.of(1.3F).minimum(0.1F).maximum(10.0F);

    public GameSpeed(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.PLAYER, "GameSpeed", "Game Speed");
        Manager.put(new Setting("GAMESPEED_VALUE", "Value", SettingType.SLIDER, this, value, 0.1));
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        // PORT: mc.timer.timerSpeed -> MoveUtils.timerSpeed (timer field gone; consumed by the
        //       RenderTickCounter hook the modules-move batch filed)
        if (mc.player == null || mc.world == null) {
            MoveUtils.timerSpeed = 1.0F;
            return;
        }
        if (mc.player.hasStatusEffect(StatusEffects.SPEED)) {
            MoveUtils.timerSpeed = value.get() + 0.2F * (mc.player.getStatusEffect(StatusEffects.SPEED).getAmplifier() + 1);
        } else {
            MoveUtils.timerSpeed = value.get();
        }
    }

    @Override
    public void onDisable() {
        MoveUtils.timerSpeed = 1.0F;
    }
}
