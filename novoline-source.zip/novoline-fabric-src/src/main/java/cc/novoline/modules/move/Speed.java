package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.*;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.FloatProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.input.Keyboard;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class Speed extends AbstractModule {

    /* fields */
    private boolean shouldBoost, expBoost;
    private double moveSpeed, lastDist, baseSpeed, boostSpeed;


    @Property("lag-back")
    private final BooleanProperty lag_back = PropertyFactory.booleanFalse();
    @Property("timer-boost")
    private final BooleanProperty timerboost = PropertyFactory.booleanFalse();
    @Property("dmg-boost")
    private final BooleanProperty dmg_boost = PropertyFactory.booleanFalse();
    @Property("amount")
    private final FloatProperty amount = PropertyFactory.createFloat(1.0F).minimum(0.1F).maximum(5.0F);

    /* constructors @on */
    public Speed(ModuleManager moduleManager) {
        super(moduleManager, "Speed", "Speed", Keyboard.KEY_NONE, EnumModuleType.MOVEMENT, "Increases your in-game speed");
        Manager.put(new Setting("SPEED_LAG_CHECK", "Lagback check", SettingType.CHECKBOX, this, lag_back));
        Manager.put(new Setting("SPEED_TIMER_BOOST", "Timer Boost", SettingType.CHECKBOX, this, timerboost));
        Manager.put(new Setting("SPEED_BOOST", "Damage Boost", SettingType.CHECKBOX, this, dmg_boost));
        Manager.put(new Setting("SPEED_AMOUNT", "Amount", SettingType.SLIDER, this, amount, 0.1));
    }

    @EventTarget
    public void onJump(JumpEvent event) {
        if (MoveUtils.isMoving(mc.player)) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        setSuffix("Watchdog");
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        /* lastDist is measured AFTER amount is applied to the move — divide it
           back out or moveSpeed compounds exponentially every tick. */
        lastDist = MoveUtils.getLastTickDistance(mc.player) / amount.get();
        baseSpeed = MoveUtils.getBaseMoveSpeed(mc.player, 0.16) * (MoveUtils.isInLiquid(mc.player) ? 0.5 : MoveUtils.sneaking(mc.player) && !isEnabled(FastSneak.class) ? 0.8 : 1.0);
    }

    @EventTarget
    public void onSetting(SettingEvent event) {
        if (event.getSettingName().equals("SPEED_TIMER_BOOST") && !timerboost.get()) {
            MoveUtils.setTimerSpeed(1.0F);
        }
    }

    @EventTarget
    public void onMotion(MotionUpdateEvent event) {
        if (event.getState() == MotionUpdateEvent.State.PRE) {
            if (ServerUtils.isHypixel()) {
                if (MoveUtils.getLastTickDistance(mc.player) > 0) {
                    if (!isEnabled(Scaffold.class)) {
                        if (round(event.getY(), 3) % 1 % 0.125 == 0) {
                            event.setY(round(event.getY(), 3));
                            event.setOnGround(true);
                        }

                    } else if (mc.player.isOnGround()) {
                        event.setY(event.getY() + 0.015625);
                    }
                }
            }
        }
    }

    private void setTimer(float speed) {
        if (timerboost.get()) {
            MoveUtils.setTimerSpeed(mc.player.fallDistance > 2 ? 1.0F : speed);
        }
    }

    @EventTarget
    public void onMove(MoveEvent event) {
        if (MoveUtils.isMoving(mc.player)) {
            if (mc.player.isOnGround()) {
                setTimer(1.0F);
                double motionY = MoveUtils.getBaseMotionY(mc.player, isEnabled(Scaffold.class) ? 0.41999998688698 : 0.39999998688698);
                mc.player.setVelocity(mc.player.getVelocity().x, motionY, mc.player.getVelocity().z);
                event.setY(motionY);
                moveSpeed = baseSpeed * flightMagicCon1;

            } else if (shouldBoost) {
                setTimer(ServerUtils.serverIs(Servers.SW) || ServerUtils.serverIs(Servers.LOBBY) ? 1.0F : 0.9F);
                moveSpeed = lastDist - 0.819999 * (lastDist - baseSpeed);

            } else {
                setTimer(ServerUtils.serverIs(Servers.SW) || ServerUtils.serverIs(Servers.LOBBY) ? 1.2F : 1.1F);
                moveSpeed = lastDist - lastDist / bunnyDivFriction;
            }

            if (dmg_boost.get() && expBoost && !mc.player.hasStatusEffect(StatusEffects.POISON) && !mc.player.isOnFire()) {
                moveSpeed += boostSpeed;
                expBoost = false;
            }

            /* Clamp: keeps runaway values (collisions, teleports feeding lastDist)
               from overflowing entity positions. */
            event.setMoveSpeed(Math.min(Math.max(moveSpeed, baseSpeed) * amount.get(), 2.0));
            shouldBoost = mc.player.isOnGround();
        }
    }

    @EventTarget
    public void onReceive(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (lag_back.get() && event.getPacket() instanceof PlayerPositionLookS2CPacket) {
                checkModule(getClass());
            }

            if (event.getPacket() instanceof ExplosionS2CPacket) {
                ExplosionS2CPacket explosion = (ExplosionS2CPacket) event.getPacket();

                if (explosion.blockCount() == 0) {
                    // PORT: 1.8.9's S27 motion fields were the decoded knockback delta;
                    // the modern packet carries the same delta as Optional<Vec3d>
                    // playerKnockback(). The /8500 divisor is kept 1:1.
                    Vec3d knockback = explosion.playerKnockback().orElse(Vec3d.ZERO);
                    boostSpeed = Math.hypot(mc.player.getVelocity().x + knockback.x / 8500,
                            mc.player.getVelocity().z + knockback.z / 8500);
                    expBoost = true;
                }
            }
        }
    }

    @Override
    public void onEnable() {
        setSuffix("Watchdog");
        checkModule(Flight.class);

        moveSpeed = MoveUtils.getBaseMoveSpeed(mc.player);
        MoveUtils.resetLastTickDistance(mc.player);
    }

    @Override
    public void onDisable() {
        MoveUtils.setTimerSpeed(1.0F);
    }

    // PORT: net.minecraft.util.math.MathHelper has no round(value, places); this replicates
    // the custom method Novoline added to the 1.8.9 MathHelper.
    private static double round(double value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}
