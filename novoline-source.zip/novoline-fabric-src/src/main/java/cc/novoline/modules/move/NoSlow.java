package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.events.events.SlowdownEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.combat.KillAura;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.FloatProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.jetbrains.annotations.NotNull;

import static cc.novoline.modules.configurations.property.object.PropertyFactory.booleanFalse;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.booleanTrue;

public final class NoSlow extends AbstractModule {

    /* properties @off */
    @Property("vanilla")
    private final BooleanProperty vanilla = booleanFalse();
    @Property("web-mode")
    private final cc.novoline.modules.configurations.property.object.StringProperty web_mode =
            PropertyFactory.createString("Off").acceptableValues("Off", "Normal", "Boost");
    @Property("web-on-ground")
    private final BooleanProperty web_on_ground = booleanFalse();
    @Property("web-speed")
    private final FloatProperty web_speed = PropertyFactory.createFloat(2.0F).minimum(0.1F).maximum(10.0F);

    /* constructors @on */
    public NoSlow(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "NoSlow", "No Slow", EnumModuleType.MOVEMENT, "No slow down when using items");
        Manager.put(new Setting("NS_VANILLA", "Vanilla", SettingType.CHECKBOX, this, this.vanilla));
        Manager.put(new Setting("NS_WEB_MODE", "Web Mode", SettingType.COMBOBOX, this, this.web_mode));
        Manager.put(new Setting("NS_WEB_ON_GROUND", "Web On Ground Only", SettingType.CHECKBOX, this, this.web_on_ground, () -> isWebEnabled()));
        Manager.put(new Setting("NS_WEB_SPEED", "Web Speed", SettingType.SLIDER, this, this.web_speed, 0.1, () -> web_mode.get().equalsIgnoreCase("Boost")));
    }

    public boolean isWebEnabled() {
        return !web_mode.get().equalsIgnoreCase("Off");
    }

    public boolean isWebOnGroundOnly() {
        return web_on_ground.get();
    }

    public float getWebSpeed() {
        return web_mode.get().equalsIgnoreCase("Boost") ? web_speed.get() : 1.0F;
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        setSuffix(vanilla.get() ? "Vanilla" : "NCP");
    }

    /* events */
    @EventTarget
    public void onBlock(MotionUpdateEvent event) {
        // PORT: SwordItem was removed in the flattening; swords are Items in the
        // minecraft:swords tag now.
        if (mc.player.getMainHandStack() != null && mc.player.getMainHandStack().isIn(ItemTags.SWORDS)
                && mc.options.useKey.isPressed() && !getModule(KillAura.class).shouldBlock()) {
            if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
                sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, Direction.DOWN));
            } else {
                // PORT: C08PacketPlayerBlockPlacement(stack) was the "use held item" packet;
                // the modern equivalent is PlayerInteractItemC2SPacket. Sequence is not
                // tracked client-side for item use, so 0 is passed.
                sendPacket(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
            }
        }
    }

    @EventTarget
    public void onSlowDown(SlowdownEvent event) {
        event.setCancelled(true);
    }

    @Override
    public void onEnable() {
        setSuffix(vanilla.get() ? "Vanilla" : "NCP");
    }
}
