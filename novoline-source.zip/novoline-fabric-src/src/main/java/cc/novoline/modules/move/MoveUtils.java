package cc.novoline.modules.move;

import net.minecraft.block.Block;
import net.minecraft.block.FluidBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Replicates the custom helper methods Novoline added to EntityPlayerSP / Minecraft in the
 * 1.8.9 jar mod so the ported movement modules keep their original logic unchanged.
 */
public final class MoveUtils {

    // PORT: 1.8.9 had mc.timer.timerSpeed, a client tick-rate multiplier. 1.21's
    // RenderTickCounter has no public equivalent; changing it needs a mixin hook in
    // shared infra (GameRenderer/RenderTickCounter). Until then the value is stored
    // here but does not accelerate the client.
    public static float timerSpeed = 1.0F;

    private MoveUtils() {
    }

    public static float getTimerSpeed() {
        return timerSpeed;
    }

    public static void setTimerSpeed(float timerSpeed) {
        MoveUtils.timerSpeed = timerSpeed;
    }

    // == movementInput() helpers ==

    public static boolean isMoving(ClientPlayerEntity player) {
        return player.forwardSpeed != 0.0F || player.sidewaysSpeed != 0.0F;
    }

    public static float moveForward(ClientPlayerEntity player) {
        return player.input.getMovementInput().y;
    }

    public static float moveStrafe(ClientPlayerEntity player) {
        return player.input.getMovementInput().x;
    }

    public static boolean jumping(ClientPlayerEntity player) {
        return player.input.playerInput.jump();
    }

    public static boolean sneaking(ClientPlayerEntity player) {
        return player.input.playerInput.sneak();
    }

    public static boolean isJumping(ClientPlayerEntity player) {
        return player.input.playerInput.jump();
    }

    // == velocity helpers ==

    public static void setSpeed(ClientPlayerEntity player, double speed) {
        final double forward = moveForward(player), strafe = moveStrafe(player);
        double yaw = player.getYaw();
        final boolean isMovingForward = forward > 0.0, isMovingBackward = forward < 0.0,
                isMovingRight = strafe > 0.0, isMovingLeft = strafe < 0.0,
                isMovingSideways = isMovingLeft || isMovingRight, isMovingStraight = isMovingForward || isMovingBackward;

        if (isMoving(player)) {
            if (isMovingForward && !isMovingSideways) {
                yaw += 0.0;
            } else if (isMovingBackward && !isMovingSideways) {
                yaw += 180;
            } else if (isMovingForward && isMovingLeft) {
                yaw += 45;
            } else if (isMovingForward) {
                yaw -= 45;
            } else if (!isMovingStraight && isMovingLeft) {
                yaw += 90;
            } else if (!isMovingStraight && isMovingRight) {
                yaw -= 90;
            } else if (isMovingBackward && isMovingLeft) {
                yaw += 126;
            } else if (isMovingBackward) {
                yaw -= 126;
            }

            yaw = Math.toRadians(yaw);
            player.setVelocity(-Math.sin(yaw) * speed, player.getVelocity().y, Math.cos(yaw) * speed);
        } else {
            player.setVelocity(0, player.getVelocity().y, 0);
        }
    }

    public static void setMotion(ClientPlayerEntity player, double speed) {
        Vec3d velocity = player.getVelocity();
        player.setVelocity(velocity.x * speed, velocity.y, velocity.z * speed);
    }

    // == move speed helpers ==

    /* PORT: faithful to the 1.8.9 EntityPlayerSP methods — `multiplier` scales the
       speed-potion boost (1 + multiplier * amplifier), it is NOT a flat multiplier on
       base speed. Returning baseSpeed * 0.16 here made every caller ~6x too slow. */
    public static double getBaseMoveSpeed(ClientPlayerEntity player) {
        double baseSpeed = getBySprinting(player);
        if (player.hasStatusEffect(StatusEffects.SPEED)) {
            int amplifier = player.getStatusEffect(StatusEffects.SPEED).getAmplifier() + 1
                    - (player.hasStatusEffect(StatusEffects.SLOWNESS)
                    ? player.getStatusEffect(StatusEffects.SLOWNESS).getAmplifier() + 1 : 0);
            baseSpeed *= 1.0 + 0.2 * amplifier;
        }
        return baseSpeed;
    }

    public static double getBaseMoveSpeed(ClientPlayerEntity player, double multiplier) {
        double baseSpeed = getBySprinting(player);
        if (player.hasStatusEffect(StatusEffects.SPEED)) {
            int amplifier = player.getStatusEffect(StatusEffects.SPEED).getAmplifier() + 1
                    - (player.hasStatusEffect(StatusEffects.SLOWNESS)
                    ? player.getStatusEffect(StatusEffects.SLOWNESS).getAmplifier() + 1 : 0);
            baseSpeed *= 1.0 + multiplier * amplifier;
        }
        return baseSpeed;
    }

    public static double getBaseMoveSpeed(ClientPlayerEntity player, double multiplier, int amplifier) {
        double baseSpeed = getBySprinting(player);
        if (player.hasStatusEffect(StatusEffects.SPEED)) {
            baseSpeed *= 1.0 + multiplier * amplifier;
        }
        return baseSpeed;
    }

    public static double getBySprinting(ClientPlayerEntity player) {
        return getBySprinting(player, player.isSprinting());
    }

    public static double getBySprinting(ClientPlayerEntity player, boolean sprint) {
        return sprint ? 0.28700000047683716 : 0.22300000488758087;
    }

    public static double getBaseMotionY(ClientPlayerEntity player) {
        return getBaseMotionY(player, 0.419999986886978);
    }

    public static double getBaseMotionY(ClientPlayerEntity player, double motionY) {
        if (player.hasStatusEffect(StatusEffects.JUMP_BOOST)) {
            return motionY + (player.getStatusEffect(StatusEffects.JUMP_BOOST).getAmplifier() + 1) * 0.1;
        }

        return motionY;
    }

    // == liquid / ground helpers ==

    public static boolean isInLiquid(ClientPlayerEntity player) {
        final World world = player.getEntityWorld();
        final Box box = player.getBoundingBox();

        for (int x = floor(box.minX); x < floor(box.maxX + 1.0D); ++x) {
            for (int z = floor(box.minZ); z < floor(box.maxZ + 1.0D); ++z) {
                final BlockPos pos = new BlockPos(x, (int) box.minY, z);
                final Block block = world.getBlockState(pos).getBlock();

                if (block instanceof FluidBlock) return true;
            }
        }

        return false;
    }

    public static boolean isOnLiquid(ClientPlayerEntity player) {
        final World world = player.getEntityWorld();
        final Box box = player.getBoundingBox().offset(0.0D, -0.01D, 0.0D).expand(-0.001D, 0.0D, -0.001D);

        boolean onLiquid = false;
        final int y = (int) box.minY;

        for (int x = floor(box.minX); x < floor(box.maxX + 1.0D); ++x) {
            for (int z = floor(box.minZ); z < floor(box.maxZ + 1.0D); ++z) {
                if (world.getBlockState(new BlockPos(x, y, z)).getBlock() instanceof FluidBlock) {
                    onLiquid = true;
                }
            }
        }

        return onLiquid;
    }

    public static boolean isOnGround(ClientPlayerEntity player, double height) {
        return player.getEntityWorld()
                .getBlockCollisions(player, player.getBoundingBox().offset(0.0D, -height, 0.0D))
                .iterator().hasNext();
    }

    // == distance helpers ==

    public static double getDistance2D(Entity entity, Entity entityIn) {
        double x = Math.abs(entityIn.getX() - entity.getX());
        double z = Math.abs(entityIn.getZ() - entity.getZ());
        return Math.sqrt(x * x + z * z);
    }

    public static double getDistanceY(ClientPlayerEntity player, double y) {
        return Math.abs(player.getY() - y);
    }

    /* PORT: 1.8.9 read prevPosX/prevPosZ (previous tick). Entity#lastX is the
       teleport/render anchor — it stays stale for a whole session, and writing to
       it corrupts render interpolation. Track per-tick deltas keyed on age instead. */
    private static int lastTrackedAge = -1;
    private static double lastTrackedX, lastTrackedZ, lastTrackedDist;

    public static double getLastTickDistance(ClientPlayerEntity player) {
        if (player.age != lastTrackedAge) {
            lastTrackedDist = lastTrackedAge < 0 ? 0.0
                    : Math.hypot(player.getX() - lastTrackedX, player.getZ() - lastTrackedZ);
            lastTrackedX = player.getX();
            lastTrackedZ = player.getZ();
            lastTrackedAge = player.age;
        }
        return lastTrackedDist;
    }

    public static void resetLastTickDistance(ClientPlayerEntity player) {
        lastTrackedX = player.getX();
        lastTrackedZ = player.getZ();
        lastTrackedAge = player.age;
        lastTrackedDist = 0.0;
    }

    // == inventory helpers ==

    public static void swap(ClientPlayerEntity player, int inventorySlot, int hotBarSlot) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.interactionManager.clickSlot(player.playerScreenHandler.syncId, inventorySlot, hotBarSlot,
                SlotActionType.SWAP, player);
    }

    public static int getSlotByItem(ClientPlayerEntity player, Item item) {
        for (int i = 9; i <= 44; ++i) {
            ItemStack stack = player.getInventory().getStack(i);

            if (stack.getItem() == item) return i;
        }

        return -1;
    }

    public static int floor(double value) {
        int i = (int) value;
        return value < (double) i ? i - 1 : i;
    }

    /**
     * Sends the player's sneaking state to the server. Replaces the removed
     * C0BPacketEntityAction START/STOP_SNEAKING packets, which were folded into
     * PlayerInputC2SPacket.
     */
    public static PlayerInputC2SPacket sneakPacket(ClientPlayerEntity player, boolean sneak) {
        net.minecraft.util.PlayerInput input = player.input.playerInput;
        return new PlayerInputC2SPacket(
                new net.minecraft.util.PlayerInput(input.forward(), input.backward(), input.left(),
                        input.right(), input.jump(), sneak, input.sprint()));
    }
}
