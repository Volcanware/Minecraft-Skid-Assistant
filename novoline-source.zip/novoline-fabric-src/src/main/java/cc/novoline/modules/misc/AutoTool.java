package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

public final class AutoTool extends AbstractModule {

    @Property("switch-back")
    private BooleanProperty switch_back = PropertyFactory.booleanTrue();

    private int oldSlot;
    private int tick;

    /* constructors */
    public AutoTool(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "AutoTool", "Auto Tool", Keyboard.KEY_NONE, EnumModuleType.MISC, "Switches to the best tool");
        Manager.put(new Setting("AT_SWITCH_BACK", "Switch Back", SettingType.CHECKBOX, this, switch_back));
    }

    /* methods */
    @EventTarget
    public void onPre(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (mc.interactionManager.isBreakingBlock()) {
                tick++;

                if (tick == 1) {
                    oldSlot = mc.player.getInventory().getSelectedSlot();
                }

                // PORT: EntityPlayerSP.updateTool (jar-mod patch) inlined; objectMouseOver -> crosshairTarget.
                if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
                    updateTool(((BlockHitResult) mc.crosshairTarget).getBlockPos());
                }
            } else if (tick > 0) {
                if (switch_back.get()) {
                    mc.player.getInventory().setSelectedSlot(oldSlot);
                }

                tick = 0;
            }
        }
    }

    // PORT: 1:1 with the patched EntityPlayerSP#updateTool — picks the hotbar stack with the
    // best mining speed against the targeted block (getStrVsBlock -> getMiningSpeedMultiplier).
    private void updateTool(BlockPos pos) {
        BlockState state = mc.world.getBlockState(pos);
        float strength = 1.0F;
        int slot = -1;

        for (int i = 0; i < 9; ++i) {
            ItemStack itemStack = mc.player.getInventory().getStack(i);

            if (!itemStack.isEmpty() && itemStack.getMiningSpeedMultiplier(state) > strength) {
                slot = i;
                strength = itemStack.getMiningSpeedMultiplier(state);
            }
        }

        if (slot != -1 && mc.player.getInventory().getSelectedStack() != mc.player.getInventory().getStack(slot)) {
            mc.player.getInventory().setSelectedSlot(slot);
        }
    }
}
