/*
package cc.novoline.modules.player;

import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import org.jetbrains.annotations.NotNull;

public class AbortBreaking extends AbstractModule {

    public AbortBreaking(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.PLAYER, "AbortBreaking", "Abort Breaking");
    }
}
*/
