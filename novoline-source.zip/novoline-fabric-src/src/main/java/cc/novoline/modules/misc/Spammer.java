package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.IntProperty;
import cc.novoline.modules.configurations.property.object.StringProperty;
import cc.novoline.utils.Channels;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Timer;
import org.jetbrains.annotations.NotNull;


import static cc.novoline.gui.screen.setting.Manager.put;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createInt;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createString;

public final class Spammer extends AbstractModule {


    /* fields */
    private final Timer timer = new Timer();

    /* properties @off */
    @Property("text")
    private final StringProperty text = createString("Buy novoline");
    @Property("delay")
    private final IntProperty delay = createInt(3_000).minimum(100).maximum(15_000);

    /* constructors @on */
    public Spammer(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Spammer", "Spammer", EnumModuleType.MISC, "Spams whatever text you set with whatever delay");
        put(new Setting("SPAMMER_TEXT", "Text", SettingType.TEXTBOX, this, "Spam text", text));
        put(new Setting("SPAMMER_DELAY", "Delay (in ms)", SettingType.SLIDER, this, delay, 100));
    }

    /* events */
    @EventTarget
    public void onUpdate(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (timer.check(delay.get())) {
                /* 1.8.9 injected 05fc between chars (invisible in that font) to dodge
                   spam dedup. Modern equivalent: trailing non-breaking spaces —
                   NBSP exists in unifont as a blank glyph (zero-width chars render
                   as missing-glyph boxes) but still makes each send unique. */
                StringBuilder msg = new StringBuilder(text.get());
                for (int i = 0, n = java.util.concurrent.ThreadLocalRandom.current().nextInt(1, 5); i < n; i++) {
                    msg.append('\u00A0');
                }

                // PORT: C01PacketChatMessage no longer exists — chat goes through sendChatCommand /
                // sendChatMessage (signing handled by the network handler). The noEventSend flag is set
                // manually to keep sendPacketNoEvent semantics.
                if (text.get().startsWith("/")) {
                    mc.player.networkHandler.sendChatCommand(text.get().substring(1));
                } else if (!ServerUtils.isHypixel() || !ServerUtils.channelIs(Channels.PM)) {
                    novoline.getNoEventSend().set(true);
                    try {
                        mc.player.networkHandler.sendChatMessage(msg.toString());
                    } finally {
                        novoline.getNoEventSend().remove();
                    }
                }

                timer.reset();
            }
        }
    }

}
