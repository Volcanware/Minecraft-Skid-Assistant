package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.*;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.utils.*;
import cc.novoline.utils.Timer;
import cc.novoline.utils.fonts.impl.Fonts;
import cc.novoline.utils.notifications.NotificationType;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SnowBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.World;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class Scaffold extends AbstractModule {

    private List<Block> invalid, blacklistedBlocks;

    /* fields */
    private final Timer timer = new Timer();
    private BlockData blockData;
    private BlockPos blockBelow;
    private int floorY, oldSlot, towerTick;
    private boolean canDisable, canPlace;
    private float yaw, pitch;

    /* properties @off */
    @Property("addons")
    private final ListProperty<String> addons = PropertyFactory.createList("Swapper", "Silent", "Tower").acceptableValues("Swing Item", "Safe Walk", "Swapper", "Silent", "Tower");
    @Property("tower-move")
    private final BooleanProperty tower_move = PropertyFactory.createBoolean(false);
    @Property("keep_y")
    private final BooleanProperty keep_y = PropertyFactory.createBoolean(false);
    @Property("mode")
    private final StringProperty keep_y_mode = PropertyFactory.createString("Always").acceptableValues("Always", "Speed Only");
    @Property("render-rotations")
    private BooleanProperty render_rotations = PropertyFactory.createBoolean(true);
    @Property("slot")
    private final IntProperty slot = PropertyFactory.createInt(6).minimum(1).maximum(9);

    /* constructors @on */
    public Scaffold(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Scaffold", "Scaffold", Keyboard.KEY_NONE, EnumModuleType.MOVEMENT);
        Manager.put(new Setting("SF_ADDONS", "Addons", SettingType.SELECTBOX, this, addons));
        Manager.put(new Setting("SF_TOWER_MOVE", "Tower Move", SettingType.CHECKBOX, this, tower_move));
        Manager.put(new Setting("SF_RENDER_ROTS", "Render Rotations", SettingType.CHECKBOX, this, render_rotations));
        Manager.put(new Setting("SF_KEEP_Y", "KeepY", SettingType.CHECKBOX, this, keep_y));
        Manager.put(new Setting("SF_KEEP_Y_MODE", "KeepY Mode", SettingType.COMBOBOX, this, keep_y_mode, keep_y::get));
        Manager.put(new Setting("SF_SLOT", "Swap Slot", SettingType.SLIDER, this, slot, 1));

        // PORT: meta-driven 1.8.9 ids were expanded to their flattened modern blocks;
        // flowing_water/flowing_lava folded into WATER/LAVA (same FluidBlock, LEVEL>0).
        invalid = Arrays.asList(Blocks.ANVIL, Blocks.AIR, Blocks.WATER, Blocks.FIRE, Blocks.WATER, Blocks.LAVA,
                Blocks.SKELETON_SKULL, Blocks.SKELETON_WALL_SKULL, Blocks.WITHER_SKELETON_SKULL, Blocks.WITHER_SKELETON_WALL_SKULL,
                Blocks.PLAYER_HEAD, Blocks.PLAYER_WALL_HEAD, Blocks.ZOMBIE_HEAD, Blocks.ZOMBIE_WALL_HEAD,
                Blocks.CREEPER_HEAD, Blocks.CREEPER_WALL_HEAD, Blocks.DRAGON_HEAD, Blocks.DRAGON_WALL_HEAD,
                Blocks.PIGLIN_HEAD, Blocks.PIGLIN_WALL_HEAD,
                Blocks.TRAPPED_CHEST, Blocks.LAVA, // @off
                Blocks.CHEST, Blocks.ENCHANTING_TABLE, Blocks.ENDER_CHEST, Blocks.CRAFTING_TABLE);
        blacklistedBlocks = Arrays.asList(Blocks.AIR, Blocks.WATER, Blocks.WATER, Blocks.LAVA,
                Blocks.OAK_SLAB, Blocks.SPRUCE_SLAB, Blocks.BIRCH_SLAB, Blocks.JUNGLE_SLAB, Blocks.ACACIA_SLAB, Blocks.DARK_OAK_SLAB,
                Blocks.CHEST, Blocks.LAVA,
                Blocks.ENCHANTING_TABLE,
                Blocks.WHITE_CARPET, Blocks.ORANGE_CARPET, Blocks.MAGENTA_CARPET, Blocks.LIGHT_BLUE_CARPET,
                Blocks.YELLOW_CARPET, Blocks.LIME_CARPET, Blocks.PINK_CARPET, Blocks.GRAY_CARPET,
                Blocks.LIGHT_GRAY_CARPET, Blocks.CYAN_CARPET, Blocks.PURPLE_CARPET, Blocks.BLUE_CARPET,
                Blocks.BROWN_CARPET, Blocks.GREEN_CARPET, Blocks.RED_CARPET, Blocks.BLACK_CARPET,
                Blocks.GLASS_PANE,
                Blocks.SKELETON_SKULL, Blocks.SKELETON_WALL_SKULL, Blocks.WITHER_SKELETON_SKULL, Blocks.WITHER_SKELETON_WALL_SKULL,
                Blocks.PLAYER_HEAD, Blocks.PLAYER_WALL_HEAD, Blocks.ZOMBIE_HEAD, Blocks.ZOMBIE_WALL_HEAD,
                Blocks.CREEPER_HEAD, Blocks.CREEPER_WALL_HEAD, Blocks.DRAGON_HEAD, Blocks.DRAGON_WALL_HEAD,
                Blocks.PIGLIN_HEAD, Blocks.PIGLIN_WALL_HEAD,
                Blocks.WHITE_STAINED_GLASS_PANE, Blocks.ORANGE_STAINED_GLASS_PANE, Blocks.MAGENTA_STAINED_GLASS_PANE,
                Blocks.LIGHT_BLUE_STAINED_GLASS_PANE, Blocks.YELLOW_STAINED_GLASS_PANE, Blocks.LIME_STAINED_GLASS_PANE,
                Blocks.PINK_STAINED_GLASS_PANE, Blocks.GRAY_STAINED_GLASS_PANE, Blocks.LIGHT_GRAY_STAINED_GLASS_PANE,
                Blocks.CYAN_STAINED_GLASS_PANE, Blocks.PURPLE_STAINED_GLASS_PANE, Blocks.BLUE_STAINED_GLASS_PANE,
                Blocks.BROWN_STAINED_GLASS_PANE, Blocks.GREEN_STAINED_GLASS_PANE, Blocks.RED_STAINED_GLASS_PANE,
                Blocks.BLACK_STAINED_GLASS_PANE,
                Blocks.IRON_BARS, Blocks.SNOW, Blocks.ICE, Blocks.PACKED_ICE,
                Blocks.COAL_ORE, Blocks.DIAMOND_ORE, Blocks.EMERALD_ORE, Blocks.TRAPPED_CHEST, Blocks.TNT,
                Blocks.TORCH, Blocks.WALL_TORCH, Blocks.ANVIL,
                Blocks.NOTE_BLOCK, Blocks.JUKEBOX, Blocks.GOLD_ORE, Blocks.IRON_ORE, Blocks.LAPIS_ORE,
                Blocks.REDSTONE_ORE, Blocks.NETHER_QUARTZ_ORE,
                Blocks.OAK_PRESSURE_PLATE, Blocks.STONE_PRESSURE_PLATE,
                Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE, Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE,
                Blocks.STONE_BUTTON, Blocks.OAK_BUTTON, Blocks.LEVER,
                Blocks.SHORT_GRASS, Blocks.TALL_GRASS, Blocks.FERN, Blocks.TRIPWIRE, Blocks.TRIPWIRE_HOOK,
                Blocks.RAIL, Blocks.LILY_PAD,
                Blocks.POPPY, Blocks.BLUE_ORCHID, Blocks.ALLIUM, Blocks.AZURE_BLUET,
                Blocks.RED_TULIP, Blocks.ORANGE_TULIP, Blocks.WHITE_TULIP, Blocks.PINK_TULIP, Blocks.OXEYE_DAISY,
                Blocks.RED_MUSHROOM, Blocks.BROWN_MUSHROOM, Blocks.VINE, Blocks.OAK_TRAPDOOR, Blocks.DANDELION,
                Blocks.LADDER, Blocks.FURNACE, Blocks.SAND, Blocks.RED_SAND, Blocks.CACTUS,
                Blocks.DISPENSER, Blocks.DROPPER, Blocks.CRAFTING_TABLE, Blocks.PUMPKIN,
                Blocks.OAK_SAPLING, Blocks.SPRUCE_SAPLING, Blocks.BIRCH_SAPLING, Blocks.JUNGLE_SAPLING,
                Blocks.ACACIA_SAPLING, Blocks.DARK_OAK_SAPLING,
                Blocks.COBBLESTONE_WALL, Blocks.MOSSY_COBBLESTONE_WALL,
                Blocks.OAK_FENCE, Blocks.ACTIVATOR_RAIL, Blocks.DETECTOR_RAIL, Blocks.POWERED_RAIL,
                Blocks.REDSTONE_TORCH, Blocks.REDSTONE_WALL_TORCH,
                Blocks.ACACIA_STAIRS, Blocks.BIRCH_STAIRS, Blocks.BRICK_STAIRS, Blocks.DARK_OAK_STAIRS,
                Blocks.JUNGLE_STAIRS, Blocks.NETHER_BRICK_STAIRS, Blocks.OAK_STAIRS,
                Blocks.QUARTZ_STAIRS, Blocks.RED_SANDSTONE_STAIRS, Blocks.SANDSTONE_STAIRS,
                Blocks.SPRUCE_STAIRS, Blocks.STONE_BRICK_STAIRS, Blocks.COBBLESTONE_STAIRS,
                Blocks.STONE_SLAB, Blocks.SMOOTH_STONE_SLAB, Blocks.PETRIFIED_OAK_SLAB, Blocks.COBBLESTONE_SLAB,
                Blocks.BRICK_SLAB, Blocks.STONE_BRICK_SLAB, Blocks.NETHER_BRICK_SLAB, Blocks.QUARTZ_SLAB,
                Blocks.RED_SANDSTONE_SLAB,
                Blocks.COBWEB, Blocks.GRAVEL, Blocks.DAYLIGHT_DETECTOR, Blocks.SOUL_SAND,
                Blocks.PISTON, Blocks.MOVING_PISTON,
                Blocks.PISTON_HEAD, Blocks.STICKY_PISTON, Blocks.IRON_TRAPDOOR, Blocks.ENDER_CHEST,
                Blocks.END_PORTAL, Blocks.END_PORTAL_FRAME,
                Blocks.WHITE_BANNER, Blocks.ORANGE_BANNER, Blocks.MAGENTA_BANNER, Blocks.LIGHT_BLUE_BANNER,
                Blocks.YELLOW_BANNER, Blocks.LIME_BANNER, Blocks.PINK_BANNER, Blocks.GRAY_BANNER,
                Blocks.LIGHT_GRAY_BANNER, Blocks.CYAN_BANNER, Blocks.PURPLE_BANNER, Blocks.BLUE_BANNER,
                Blocks.BROWN_BANNER, Blocks.GREEN_BANNER, Blocks.RED_BANNER, Blocks.BLACK_BANNER,
                Blocks.WHITE_WALL_BANNER, Blocks.ORANGE_WALL_BANNER, Blocks.MAGENTA_WALL_BANNER,
                Blocks.LIGHT_BLUE_WALL_BANNER, Blocks.YELLOW_WALL_BANNER, Blocks.LIME_WALL_BANNER,
                Blocks.PINK_WALL_BANNER, Blocks.GRAY_WALL_BANNER, Blocks.LIGHT_GRAY_WALL_BANNER,
                Blocks.CYAN_WALL_BANNER, Blocks.PURPLE_WALL_BANNER, Blocks.BLUE_WALL_BANNER,
                Blocks.BROWN_WALL_BANNER, Blocks.GREEN_WALL_BANNER, Blocks.RED_WALL_BANNER, Blocks.BLACK_WALL_BANNER,
                Blocks.DEAD_BUSH, Blocks.SLIME_BLOCK,
                Blocks.ACACIA_FENCE_GATE, Blocks.BIRCH_FENCE_GATE, Blocks.DARK_OAK_FENCE_GATE,
                Blocks.JUNGLE_FENCE_GATE, Blocks.SPRUCE_FENCE_GATE, Blocks.OAK_FENCE_GATE); // @on
    }

    private boolean hotBarContainBlock() {
        int i = 36;

        while (i < 45) {
            try {
                final ItemStack slotStack = mc.player.playerScreenHandler.getSlot(i).getStack();

                if (slotStack == null || slotStack.getItem() == null || !(slotStack
                        .getItem() instanceof BlockItem) || !isValid(slotStack.getItem())) {
                    i++;
                    continue;
                }

                return true;
            } catch (Exception ignored) {
            }
        }

        return false;
    }

    private boolean isValid(Item item) {
        if (!(item instanceof BlockItem)) {
            return false;
        } else {
            final BlockItem itemBlock = (BlockItem) item;
            final Block block = itemBlock.getBlock();

            return !getBlacklistedBlocks().contains(block);
        }
    }

    private int getBiggestBlockSlotInv() {
        int slot = -1, size = 0;

        if (getBlockCount() == 0) {
            return -1;
        }

        for (int i = 9; i < 36; i++) {
            final Slot s = mc.player.playerScreenHandler.getSlot(i);

            if (s.hasStack()) {
                final Item item = s.getStack().getItem();
                final ItemStack is = s.getStack();

                if (item instanceof BlockItem && isValid(item) && is.getCount() > size) {
                    size = is.getCount();
                    slot = i;
                }
            }
        }

        return slot;
    }

    private int getBiggestBlockSlotHotbar() {
        int slot = -1, size = 0;

        if (getBlockCount() == 0) {
            return -1;
        }

        for (int i = 36; i < 45; i++) {
            final Slot s = mc.player.playerScreenHandler.getSlot(i);

            if (s.hasStack()) {
                final Item item = s.getStack().getItem();
                final ItemStack is = s.getStack();

                if (item instanceof BlockItem && isValid(item) && is.getCount() > size) {
                    size = is.getCount();
                    slot = i;
                }
            }
        }

        return slot;
    }

    public boolean isAirBlock(Block block) {
        if (block.getDefaultState().isReplaceable()) {
            return !(block instanceof SnowBlock) || !(block.getDefaultState().get(SnowBlock.LAYERS) * 0.125 > 0.125);
        }

        return false;
    }

    public double[] getExpandCoords(double y) {
        BlockPos underPos = BlockPos.ofFloored(mc.player.getX(), y, mc.player.getZ());
        Block underBlock = mc.world.getBlockState(underPos).getBlock();
        float forward = MoveUtils.moveForward(mc.player), strafe = MoveUtils.moveStrafe(mc.player), yaw = mc.player.getYaw();
        double xCalc = -999, zCalc = -999, dist = 0, expandDist = blockBelow != null && MoveUtils.getDistanceY(mc.player, blockBelow.getY()) == 1.0 ? 0.0 : 0.0;

        while (!isAirBlock(underBlock)) {
            xCalc = mc.player.getX();
            zCalc = mc.player.getZ();
            dist++;
            if (dist > expandDist) dist = expandDist;
            xCalc += (forward * 0.45 * MathHelper.cos((float) Math.toRadians(yaw + 90.0f)) + strafe * 0.45 * MathHelper.sin((float) Math.toRadians(yaw + 90.0f))) * dist;
            zCalc += (forward * 0.45 * MathHelper.sin((float) Math.toRadians(yaw + 90.0f)) - strafe * 0.45 * MathHelper.cos((float) Math.toRadians(yaw + 90.0f))) * dist;
            if (dist == expandDist) break;
            underPos = BlockPos.ofFloored(xCalc, y, zCalc);
            underBlock = mc.world.getBlockState(underPos).getBlock();
        }

        return new double[]{xCalc, zCalc};
    }

    @EventTarget
    public void onPre2(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (addons.contains("Swapper")) {
                if (timer.delay(250)) {
                    final int bestInvSlot = getBiggestBlockSlotInv(), bestHotBarSlot = getBiggestBlockSlotHotbar();
                    int bestSlot = bestHotBarSlot > 0 ? bestHotBarSlot : bestInvSlot, spoofSlot = 42;

                    if (bestHotBarSlot > 0 && bestInvSlot > 0 && mc.player.playerScreenHandler.getSlot(bestInvSlot)
                            .hasStack() && mc.player.playerScreenHandler.getSlot(bestHotBarSlot)
                            .hasStack() && mc.player.playerScreenHandler.getSlot(bestHotBarSlot)
                            .getStack().getCount() < mc.player.playerScreenHandler.getSlot(bestInvSlot).getStack().getCount()) {
                        bestSlot = bestInvSlot;
                    }

                    if (hotBarContainBlock()) {
                        for (int a = 36; a < 45; a++) {
                            if (mc.player.playerScreenHandler.getSlot(a).hasStack()) {
                                final Item item = mc.player.playerScreenHandler.getSlot(a).getStack().getItem();

                                if (item instanceof BlockItem && isValid(item)) {
                                    spoofSlot = a;
                                    break;
                                }
                            }
                        }

                    } else {
                        for (int a = 36; a < 45; a++) {
                            if (!mc.player.playerScreenHandler.getSlot(a).hasStack()) {
                                spoofSlot = a;
                                break;
                            }
                        }
                    }

                    if (mc.player.playerScreenHandler.getSlot(spoofSlot).id != bestSlot) {
                        if (hotBarContainBlock()) {
                            MoveUtils.swap(mc.player, bestSlot, spoofSlot - 36);
                        } else {
                            MoveUtils.swap(mc.player, bestSlot, slot.get() - 1);
                        }
                    }

                    timer.reset();
                }

            } else {
                if (getBlockCountHotBar() <= 0) {
                    MoveUtils.swap(mc.player, getBiggestBlockSlotInv(), slot.get() - 1);
                }
            }
        }
    }

    private boolean towering() {
        return addons.contains("Tower") && !MoveUtils.isMoving(mc.player) && mc.options.jumpKey.isPressed() && !mc.player.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.JUMP_BOOST);
    }

    private boolean keepY() {
        return keep_y.get() && (keep_y_mode.equals("Always") || keep_y_mode.equals("Speed Only") && isEnabled(Speed.class) && !mc.options.jumpKey.isPressed());
    }

    private boolean towerMoving() {
        return tower_move.get() && !keepY() && mc.options.jumpKey.isPressed() && MoveUtils.isMoving(mc.player);
    }

    @EventTarget
    public void onJump(JumpEvent event) {
        if (towering() || towerMoving()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onPreUpdate(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (towerMoving()) {
                towerMove();
            }

            if (towering() || towerMoving()) {
                // PORT: 1.8.9's cameraPitch/cameraYaw (view-bobbing) have no modern field;
                // needs a GameRenderer bobView mixin hook in shared infra.
            } else if (blockBelow != null && MoveUtils.getDistanceY(mc.player, blockBelow.getY()) == 1.0) {
                // PORT: mc.player.cameraYaw = 0.1F;
                mc.player.setOnGround(true);
                mc.player.setVelocity(mc.player.getVelocity().x, 0.0, mc.player.getVelocity().z);
                event.setOnGround(true);
            }
        }
    }

    @EventTarget
    public void onMove(MoveEvent event) {
        if (MoveUtils.isMoving(mc.player) && MoveUtils.isOnGround(mc.player, 0.0001)) {
            //   event.setMoveSpeed(mc.player.getBaseMoveSpeed() * 0.2);
        }
    }

    private void towerMove() {
        if (MoveUtils.isOnGround(mc.player, 0.76) && !MoveUtils.isOnGround(mc.player, 0.75)
                && mc.player.getVelocity().y > 0.23 && mc.player.getVelocity().y < 0.25) {
            mc.player.setVelocity(mc.player.getVelocity().x, Math.round(mc.player.getY()) - mc.player.getY(), mc.player.getVelocity().z);
        }

        if (MoveUtils.isOnGround(mc.player, 0.0001)) {
            mc.player.setVelocity(mc.player.getVelocity().x, 0.41999998688698, mc.player.getVelocity().z);
            MoveUtils.setMotion(mc.player, 0.9);

        } else if (mc.player.getY() >= Math.round(mc.player.getY()) - 0.0001 && mc.player.getY() <= Math.round(mc.player.getY()) + 0.0001
                && !mc.options.sneakKey.isPressed()) {
            mc.player.setVelocity(mc.player.getVelocity().x, 0.0, mc.player.getVelocity().z);
        }
    }

    private void tower() {
        mc.player.setSprinting(false);
        MoveUtils.setSpeed(mc.player, 0.0);
        towerMove();
    }

    @EventTarget
    public void onPost(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (blockData != null) {
                PigEntity entity = new PigEntity(EntityType.PIG, mc.world);
                entity.setPosition(blockData.position.getX() + 0.5, blockData.position.getY() + 0.5, blockData.position.getZ() + 0.5);
                float[] rots = RotationUtil.getAngles(entity);
                this.yaw = rots[0];
                this.pitch = rots[1];
            }

            event.setYaw(MoveUtils.isMoving(mc.player) ? getYawBackward() : this.yaw);
            event.setPitch(MoveUtils.isMoving(mc.player) ? this.pitch : 90);

            if (towering()) {
                tower();
            }
        }
    }

    @EventTarget
    public void onRightClick(RightClickEvent event) {
        if (blockData != null && (!towering() || canPlace)) {
            placeBlock();
        }
    }

    @EventTarget
    public void onTower(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.OUTGOING)) {
            if (addons.contains("Silent")) {
                if (event.getPacket() instanceof UpdateSelectedSlotC2SPacket) {
                    UpdateSelectedSlotC2SPacket packet = (UpdateSelectedSlotC2SPacket) event.getPacket();

                    if (packet.getSelectedSlot() != neededSlot()) {
                        event.setCancelled(true);
                    }
                }
            }

            if (event.getPacket() instanceof PlayerMoveC2SPacket) {
                PlayerMoveC2SPacket packet = (PlayerMoveC2SPacket) event.getPacket();

                if (towering()) {
                    canPlace = !packet.changesPosition();
                }
            }
        }
    }

    public float getYawBackward() {
        float yaw = MathHelper.wrapDegrees(mc.player.getYaw());

        float strafe = MoveUtils.moveStrafe(mc.player), forward = MoveUtils.moveForward(mc.player);

        if (forward != 0) {
            if (strafe < 0) {
                yaw += forward < 0 ? 135 : 45;
            } else if (strafe > 0) {
                yaw -= forward < 0 ? 135 : 45;
            } else if (strafe == 0 && forward < 0) {
                yaw -= 180;
            }

        } else {
            if (strafe < 0) {
                yaw += 90;
            } else if (strafe > 0) {
                yaw -= 90;
            }
        }

        return MathHelper.wrapDegrees(yaw - 180);
    }

    private void placeBlock() {
        // PORT-FIX: always push the slot packet before interact — the server's
        // tracked slot lags a tick otherwise and interactBlock places nothing.
        sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(neededSlot()));
        if (!addons.contains("Silent") && mc.player.getInventory().getSelectedSlot() != neededSlot()) {
            mc.player.getInventory().setSelectedSlot(neededSlot());
        }

        BlockPos pos = blockData.position;
        Direction facing = blockData.facing;
        Vec3d vector = getVec3(pos, facing);

        // PORT: onPlayerRightClick took the stack to place explicitly; interactBlock reads
        // the client's held stack instead, so mirror the selection to neededSlot for the
        // call (the server-side slot is already correct from the packet/assignment above).
        int previousSlot = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(neededSlot());
        ActionResult result = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(vector, facing, pos, false));
        mc.player.getInventory().setSelectedSlot(previousSlot);

        if (result.isAccepted()) {
            if (addons.contains("Swing Item")) {
                mc.player.swingHand(Hand.MAIN_HAND);
            } else {
                sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            }
        }
    }

    @EventTarget
    public void onPre(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (!keepY() || mc.player.isOnGround()) {
                floorY = MathHelper.floor(mc.player.getY());
            }

            double yPos = floorY - 1;
            boolean air = isAirBlock(mc.world.getBlockState(BlockPos.ofFloored(mc.player.getX(), yPos, mc.player.getZ())).getBlock());
            double xPos = air ? mc.player.getX() : getExpandCoords(yPos)[0], zPos = air ? mc.player.getZ() : getExpandCoords(yPos)[1];
            blockBelow = BlockPos.ofFloored(xPos, yPos, zPos);

            BlockState below = mc.world.getBlockState(blockBelow);
            boolean setBlockData = below.isReplaceable() || below.isAir();
            blockData = setBlockData ? getBlockData(blockBelow) : null;
        }
    }

    public int getBlockCount() {
        int blockCount = 0;

        for (int i = 0; i < 45; ++i) {
            if (!mc.player.playerScreenHandler.getSlot(i).hasStack()) continue;

            final ItemStack is = mc.player.playerScreenHandler.getSlot(i).getStack();
            final Item item = is.getItem();

            if (!(is.getItem() instanceof BlockItem) || getBlacklistedBlocks().contains(((BlockItem) item).getBlock())) {
                continue;
            }

            blockCount += is.getCount();
        }

        return blockCount;
    }

    private int getBlockCountHotBar() {
        int blockCount = 0;

        for (int i = 36; i < 45; ++i) {
            if (!mc.player.playerScreenHandler.getSlot(i).hasStack()) continue;

            final ItemStack is = mc.player.playerScreenHandler.getSlot(i).getStack();
            final Item item = is.getItem();

            if (!(is.getItem() instanceof BlockItem) || getBlacklistedBlocks().contains(((BlockItem) item).getBlock())) {
                continue;
            }

            blockCount += is.getCount();
        }

        return blockCount;
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (getBlockCount() == 0) {
            novoline.getNotificationManager().pop("Scaffold warning", "No blocks in inventory", NotificationType.WARNING);
            toggle();
        }
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        // PORT: no glPushMatrix / ScaleUtils.scale in the new pipeline — DrawContext draws
        // in scaled GUI coordinates directly.
        ItemStack stack = mc.player.getInventory().getStack(neededSlot());

        if (stack != null && stack.getItem() instanceof BlockItem && isValid(stack.getItem())) {
            ScaledResolution sr = new ScaledResolution(mc);
            float width = Fonts.SF.SF_18.SF_18.stringWidth("/" + getBlockCount());
            float x = sr.getScaledWidthStatic(mc) / 2 - width / 2, y = sr.getScaledHeightStatic(mc) / 2;

            event.getContext().drawItem(stack, (int) (x - 5.0F), (int) (y + 11));
            Fonts.SF.SF_18.SF_18.drawString(Integer.toString(getBlockCount()), x + 11.0F, y + 16, 0xFFFFFF, true);
        }
    }

    private BlockData getBlockData(BlockPos pos) {
        if (isPosSolid(pos.add(0, -1, 0))) {
            return new BlockData(pos.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos.add(-1, 0, 0))) {
            return new BlockData(pos.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos.add(1, 0, 0))) {
            return new BlockData(pos.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos.add(0, 0, 1))) {
            return new BlockData(pos.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos.add(0, 0, -1))) {
            return new BlockData(pos.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos1 = pos.add(-1, 0, 0);

        if (isPosSolid(pos1.add(0, -1, 0))) {
            return new BlockData(pos1.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos1.add(-1, 0, 0))) {
            return new BlockData(pos1.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos1.add(1, 0, 0))) {
            return new BlockData(pos1.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos1.add(0, 0, 1))) {
            return new BlockData(pos1.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos1.add(0, 0, -1))) {
            return new BlockData(pos1.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos2 = pos.add(1, 0, 0);

        if (isPosSolid(pos2.add(0, -1, 0))) {
            return new BlockData(pos2.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos2.add(-1, 0, 0))) {
            return new BlockData(pos2.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos2.add(1, 0, 0))) {
            return new BlockData(pos2.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos2.add(0, 0, 1))) {
            return new BlockData(pos2.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos2.add(0, 0, -1))) {
            return new BlockData(pos2.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos3 = pos.add(0, 0, 1);

        if (isPosSolid(pos3.add(0, -1, 0))) {
            return new BlockData(pos3.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos3.add(-1, 0, 0))) {
            return new BlockData(pos3.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos3.add(1, 0, 0))) {
            return new BlockData(pos3.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos3.add(0, 0, 1))) {
            return new BlockData(pos3.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos3.add(0, 0, -1))) {
            return new BlockData(pos3.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos4 = pos.add(0, 0, -1);

        if (isPosSolid(pos4.add(0, -1, 0))) {
            return new BlockData(pos4.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos4.add(-1, 0, 0))) {
            return new BlockData(pos4.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos4.add(1, 0, 0))) {
            return new BlockData(pos4.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos4.add(0, 0, 1))) {
            return new BlockData(pos4.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos4.add(0, 0, -1))) {
            return new BlockData(pos4.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos19 = pos.add(-2, 0, 0);

        if (isPosSolid(pos1.add(0, -1, 0))) {
            return new BlockData(pos1.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos1.add(-1, 0, 0))) {
            return new BlockData(pos1.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos1.add(1, 0, 0))) {
            return new BlockData(pos1.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos1.add(0, 0, 1))) {
            return new BlockData(pos1.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos1.add(0, 0, -1))) {
            return new BlockData(pos1.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos29 = pos.add(2, 0, 0);

        if (isPosSolid(pos2.add(0, -1, 0))) {
            return new BlockData(pos2.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos2.add(-1, 0, 0))) {
            return new BlockData(pos2.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos2.add(1, 0, 0))) {
            return new BlockData(pos2.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos2.add(0, 0, 1))) {
            return new BlockData(pos2.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos2.add(0, 0, -1))) {
            return new BlockData(pos2.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos39 = pos.add(0, 0, 2);

        if (isPosSolid(pos3.add(0, -1, 0))) {
            return new BlockData(pos3.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos3.add(-1, 0, 0))) {
            return new BlockData(pos3.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos3.add(1, 0, 0))) {
            return new BlockData(pos3.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos3.add(0, 0, 1))) {
            return new BlockData(pos3.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos3.add(0, 0, -1))) {
            return new BlockData(pos3.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos49 = pos.add(0, 0, -2);

        if (isPosSolid(pos4.add(0, -1, 0))) {
            return new BlockData(pos4.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos4.add(-1, 0, 0))) {
            return new BlockData(pos4.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos4.add(1, 0, 0))) {
            return new BlockData(pos4.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos4.add(0, 0, 1))) {
            return new BlockData(pos4.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos4.add(0, 0, -1))) {
            return new BlockData(pos4.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos5 = pos.add(0, -1, 0);

        if (isPosSolid(pos5.add(0, -1, 0))) {
            return new BlockData(pos5.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos5.add(-1, 0, 0))) {
            return new BlockData(pos5.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos5.add(1, 0, 0))) {
            return new BlockData(pos5.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos5.add(0, 0, 1))) {
            return new BlockData(pos5.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos5.add(0, 0, -1))) {
            return new BlockData(pos5.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos6 = pos5.add(1, 0, 0);

        if (isPosSolid(pos6.add(0, -1, 0))) {
            return new BlockData(pos6.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos6.add(-1, 0, 0))) {
            return new BlockData(pos6.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos6.add(1, 0, 0))) {
            return new BlockData(pos6.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos6.add(0, 0, 1))) {
            return new BlockData(pos6.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos6.add(0, 0, -1))) {
            return new BlockData(pos6.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos7 = pos5.add(-1, 0, 0);

        if (isPosSolid(pos7.add(0, -1, 0))) {
            return new BlockData(pos7.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos7.add(-1, 0, 0))) {
            return new BlockData(pos7.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos7.add(1, 0, 0))) {
            return new BlockData(pos7.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos7.add(0, 0, 1))) {
            return new BlockData(pos7.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos7.add(0, 0, -1))) {
            return new BlockData(pos7.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos8 = pos5.add(0, 0, 1);

        if (isPosSolid(pos8.add(0, -1, 0))) {
            return new BlockData(pos8.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos8.add(-1, 0, 0))) {
            return new BlockData(pos8.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos8.add(1, 0, 0))) {
            return new BlockData(pos8.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos8.add(0, 0, 1))) {
            return new BlockData(pos8.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos8.add(0, 0, -1))) {
            return new BlockData(pos8.add(0, 0, -1), Direction.SOUTH);
        }

        BlockPos pos9 = pos5.add(0, 0, -1);

        if (isPosSolid(pos9.add(0, -1, 0))) {
            return new BlockData(pos9.add(0, -1, 0), Direction.UP);
        } else if (isPosSolid(pos9.add(-1, 0, 0))) {
            return new BlockData(pos9.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos9.add(1, 0, 0))) {
            return new BlockData(pos9.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos9.add(0, 0, 1))) {
            return new BlockData(pos9.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos9.add(0, 0, -1))) {
            return new BlockData(pos9.add(0, 0, -1), Direction.SOUTH);
        }
        return null;
    }

    private boolean isPosSolid(BlockPos pos) {
        final Block block = mc.world.getBlockState(pos).getBlock();
        return !invalid.contains(block);
    }

    private BlockData getBlockDataDownwards(BlockPos pos) {
        // region Main
        if (isPosSolid(pos.add(0, 1, 0))) {
            return new BlockData(pos.add(0, 1, 0), Direction.DOWN);
        } else if (isPosSolid(pos.add(0, 0, 1))) {
            return new BlockData(pos.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(pos.add(0, 1, 1))) {
            return new BlockData(pos.add(0, 1, 1), Direction.DOWN);
        } else if (isPosSolid(pos.add(-1, 0, 0))) {
            return new BlockData(pos.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos.add(-1, 1, 0))) {
            return new BlockData(pos.add(-1, 1, 0), Direction.DOWN);
        } else if (isPosSolid(pos.add(1, 0, 0))) {
            return new BlockData(pos.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(pos.add(1, 1, 0))) {
            return new BlockData(pos.add(1, 1, 0), Direction.DOWN);
        } else if (isPosSolid(pos.add(0, 0, -1))) {
            return new BlockData(pos.add(0, 0, -1), Direction.SOUTH);
        } else if (isPosSolid(pos.add(0, 1, -1))) {
            return new BlockData(pos.add(0, 1, -1), Direction.DOWN);
        }

        // region East
        final BlockPos add = pos.add(-1, 0, 0);

        if (isPosSolid(add.add(-1, 0, 0))) {
            return new BlockData(add.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(add.add(-1, 1, 0))) {
            return new BlockData(add.add(-1, 1, 0), Direction.DOWN);
        } else if (isPosSolid(add.add(1, 0, 0))) {
            return new BlockData(add.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(add.add(1, 1, 0))) {
            return new BlockData(add.add(1, 1, 0), Direction.DOWN);
        } else if (isPosSolid(add.add(0, 0, -1))) {
            return new BlockData(add.add(0, 0, -1), Direction.SOUTH);
        } else if (isPosSolid(add.add(0, 1, -1))) {
            return new BlockData(add.add(0, 1, -1), Direction.DOWN);
        } else if (isPosSolid(add.add(0, 0, 1))) {
            return new BlockData(add.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(add.add(0, 1, 1))) {
            return new BlockData(add.add(0, 1, 1), Direction.DOWN);
        }

        // region West
        final BlockPos add2 = pos.add(1, 0, 0);

        if (isPosSolid(add2.add(-1, 0, 0))) {
            return new BlockData(add2.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(add2.add(-1, 1, 0))) {
            return new BlockData(add2.add(-1, 1, 0), Direction.DOWN);
        } else if (isPosSolid(add2.add(1, 0, 0))) {
            return new BlockData(add2.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(add2.add(1, 1, 0))) {
            return new BlockData(add2.add(1, 1, 0), Direction.DOWN);
        } else if (isPosSolid(add2.add(0, 0, -1))) {
            return new BlockData(add2.add(0, 0, -1), Direction.SOUTH);
        } else if (isPosSolid(add2.add(0, 1, -1))) {
            return new BlockData(add2.add(0, 1, -1), Direction.DOWN);
        } else if (isPosSolid(add2.add(0, 0, 1))) {
            return new BlockData(add2.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(add2.add(0, 1, 1))) {
            return new BlockData(add2.add(0, 1, 1), Direction.DOWN);
        }

        // region South
        final BlockPos add3 = pos.add(0, 0, -1);

        if (isPosSolid(add3.add(-1, 0, 0))) {
            return new BlockData(add3.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(pos.add(-1, 1, 0))) {
            return new BlockData(add3.add(-1, 1, 0), Direction.DOWN);
        } else if (isPosSolid(add3.add(1, 0, 0))) {
            return new BlockData(add3.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(add3.add(1, 1, 0))) {
            return new BlockData(add3.add(1, 1, 0), Direction.DOWN);
        } else if (isPosSolid(add3.add(0, 0, -1))) {
            return new BlockData(add3.add(0, 0, -1), Direction.SOUTH);
        } else if (isPosSolid(add3.add(0, 1, -1))) {
            return new BlockData(add3.add(0, 1, -1), Direction.DOWN);
        } else if (isPosSolid(add3.add(0, 0, 1))) {
            return new BlockData(add3.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(add3.add(0, 1, 1))) {
            return new BlockData(add3.add(0, 1, 1), Direction.DOWN);
        }

        // region North
        final BlockPos add4 = pos.add(0, 0, 1);

        if (isPosSolid(add4.add(-1, 0, 0))) {
            return new BlockData(add4.add(-1, 0, 0), Direction.EAST);
        } else if (isPosSolid(add4.add(-1, 1, 0))) {
            return new BlockData(add4.add(-1, 1, 0), Direction.DOWN);
        } else if (isPosSolid(add4.add(1, 0, 0))) {
            return new BlockData(add4.add(1, 0, 0), Direction.WEST);
        } else if (isPosSolid(add4.add(1, 1, 0))) {
            return new BlockData(add4.add(1, 1, 0), Direction.DOWN);
        } else if (isPosSolid(add4.add(0, 0, -1))) {
            return new BlockData(add4.add(0, 0, -1), Direction.SOUTH);
        } else if (isPosSolid(add4.add(0, 1, -1))) {
            return new BlockData(add4.add(0, 1, -1), Direction.DOWN);
        } else if (isPosSolid(add4.add(0, 0, 1))) {
            return new BlockData(add4.add(0, 0, 1), Direction.NORTH);
        } else if (isPosSolid(add4.add(0, 1, 1))) {
            return new BlockData(add4.add(0, 1, 1), Direction.DOWN);
        }

        return null;
    }

    private int neededSlot() {
        for (int i = 0; i < 9; ++i) {
            if (mc.player.getInventory().getStack(i) != null && !mc.player.getInventory().getStack(i).isEmpty()
                    && mc.player.getInventory().getStack(i).getCount() != 0) {
                Item item = mc.player.getInventory().getStack(i).getItem();

                if (isValid(item)) {
                    return i;
                }
            }
        }

        return mc.player.getInventory().getSelectedSlot();
    }

    @Override
    public void onEnable() {
        setSuffix("Watchdog");

        if (getBlockCount() == 0) {
            canDisable = false;
            return;
        } else {
            canDisable = true;
        }

        oldSlot = mc.player.getInventory().getSelectedSlot();

        if (mc.world != null) {
            floorY = MathHelper.floor(mc.player.getY());
        }
    }

    @Override
    public void onDisable() {
        if (canDisable) {
            if (addons.contains("Silent")) {
                sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().getSelectedSlot()));
            } else {
                mc.player.getInventory().setSelectedSlot(oldSlot);
            }

            if (!MoveUtils.sneaking(mc.player)) {
                sendPacketNoEvent(MoveUtils.sneakPacket(mc.player, false));
            }

            canDisable = false;
        }
    }

    // PORT: replicates the custom MathHelper.getVec3 Novoline added in 1.8.9 — a random
    // hit vector inside the clicked face of the block.
    private Vec3d getVec3(BlockPos pos, Direction facing) {
        Vec3d vector = Vec3d.ofCenter(pos);
        double random = ThreadLocalRandom.current().nextDouble();

        if (facing == Direction.NORTH) {
            vector = vector.add(random - 0.5, 0, 0);
        } else if (facing == Direction.SOUTH) {
            vector = vector.add(random - 0.5, 0, 1.0 - 0.5);
        } else if (facing == Direction.WEST) {
            vector = vector.add(0, 0, random - 0.5);
        } else if (facing == Direction.EAST) {
            vector = vector.add(1.0 - 0.5, 0, random - 0.5);
        }

        if (facing == Direction.UP) {
            vector = vector.add(random - 0.5, 0.5, random - 0.5);
        } else {
            vector = vector.add(0, random - 0.5, 0);
        }

        return vector;
    }

    private class BlockData {

        private BlockPos position;
        private Direction facing;

        public BlockData(BlockPos position, Direction facing) {
            this.position = position;
            this.facing = facing;
        }
    }

    public BlockData getBlockData() {
        return blockData;
    }

    public List<Block> getBlacklistedBlocks() {
        return blacklistedBlocks;
    }

    public BlockPos getBlockBelow() {
        return blockBelow;
    }

    public ListProperty<String> getAddons() {
        return addons;
    }

    public float getYaw() {
        return yaw;
    }

    public float getPitch() {
        return pitch;
    }

    public boolean renderRotations() {
        return render_rotations.get();
    }

    public boolean safeWalk() {
        return addons.contains("Safe Walk");
    }
}
