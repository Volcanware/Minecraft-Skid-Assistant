package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.events.events.SettingEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.configurations.property.object.StringProperty;
import net.minecraft.client.gui.screen.option.VideoOptionsScreen;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.jetbrains.annotations.NotNull;

import static cc.novoline.modules.EnumModuleType.VISUALS;

public final class Brightness extends AbstractModule {

    private double oldGamma;

    /* properties */
    @Property("mode")
    private final StringProperty mode = PropertyFactory.createString("Gamma").acceptableValues("Gamma", "Effect");

    /* constructors */
    public Brightness(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Brightness", VISUALS, "It's too dark in here");
        Manager.put(new Setting("BN_MODE", "Mode", SettingType.COMBOBOX, this, mode));
    }

    /* methods */

    @Override
    public void onEnable() {
        setSuffix(mode.get());

        if (mode.equals("Gamma")) {
            if (mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            }

            oldGamma = mc.options.getGamma().getValue();
            // PORT: SimpleOption clamps to [0,1] — set the backing value directly via accessor
            ((cc.novoline.mixin.SimpleOptionAccessor<Double>) (Object) mc.options.getGamma()).novoline$setValue(10_000.0D);
        }
    }

    @Override
    public void onDisable() {
        if (mode.equals("Effect")) {
            this.mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        } else {
            mc.options.getGamma().setValue(oldGamma);
        }
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        setSuffix(mode.get());
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mode.equals("Effect")) {
            this.mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 5201, 1));
        } else if (mc.currentScreen instanceof VideoOptionsScreen && mc.options.getGamma().getValue() != 10_000.0D) {
            ((cc.novoline.mixin.SimpleOptionAccessor<Double>) (Object) mc.options.getGamma()).novoline$setValue(10_000.0D);
        }
    }

    @EventTarget
    public void onSetting(SettingEvent event) {
        if (event.getSettingName().equals("BN_MODE")) {
            if (mode.equals("Gamma")) {
                if (mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                    mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
                }

                oldGamma = mc.options.getGamma().getValue();
                ((cc.novoline.mixin.SimpleOptionAccessor<Double>) (Object) mc.options.getGamma()).novoline$setValue(10_000.0D);

            } else if (mc.options.getGamma().getValue() != oldGamma) {
                mc.options.getGamma().setValue(oldGamma);
            }
        }
    }

    public StringProperty getMode() {
        return mode;
    }
}
