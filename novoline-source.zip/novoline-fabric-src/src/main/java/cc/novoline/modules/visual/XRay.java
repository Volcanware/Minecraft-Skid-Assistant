package cc.novoline.modules.visual;

import cc.novoline.Novoline;
import cc.novoline.events.EventTarget;
import cc.novoline.events.events.SettingEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.utils.ColorUtils;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.Timer;
import com.google.common.collect.Lists;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import static cc.novoline.gui.screen.setting.SettingType.*;
import static cc.novoline.modules.EnumModuleType.VISUALS;
import static org.lwjgl.input.Keyboard.KEY_NONE;

public final class XRay extends AbstractModule {

    /* fields */
    public static int alpha;
    public static boolean isEnabled;
    // PORT: kept as legacy numeric block ids (1.8.9 registry ids); translated to modern blocks below
    public static List<Integer> blockIdList = Lists.newArrayList(10, 11, 8, 9, 14, 15, 16, 21, 41, 42, 46, 48, 52, 56, 57, 61, 62, 73, 74, 84, 89, 103, 116, 117, 118, 120, 129, 133, 137, 145, 152, 153, 154);
    /** 1.8.9 numeric id -> modern Block, for the ids in blockIdList. */
    private static final java.util.Map<Integer, Block> LEGACY_BLOCKS = buildLegacyBlocks();
    public static List<BlockPos> blockPosList = new CopyOnWriteArrayList<>();
    private Timer timer = new Timer();

    /* properties @off */
    @Property("opacity")
    private final IntProperty opacity = PropertyFactory.createInt(160).minimum(0).maximum(255);
    @Property("esp")
    private final BooleanProperty esp = PropertyFactory.booleanTrue();
    @Property("tracers")
    private final BooleanProperty tracers = PropertyFactory.booleanTrue();
    @Property("esp-ores")
    private final ListProperty ores = PropertyFactory.createList("Diamond").acceptableValues("Redstone", "Diamond", "Emerald", "Lapis", "Iron", "Coal", "Gold");
    @Property("distance")
    private final IntProperty distance = PropertyFactory.createInt(42).minimum(16).maximum(64);
    @Property("chunk-update")
    private final BooleanProperty update = PropertyFactory.booleanFalse();
    @Property("delay")
    private DoubleProperty delay = PropertyFactory.createDouble(10.0).minimum(1.0).maximum(30.0);

    /* constructors @on */
    public XRay(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "XRay", "XRay", KEY_NONE, VISUALS);
        Manager.put(new Setting("ESP_ORES", "ESP Ores", SELECTBOX, this, this.ores, () -> esp.get() || tracers.get()));
        Manager.put(new Setting("OPACITY", "Opacity", SLIDER, this, this.opacity, 5));
        Manager.put(new Setting("XRAY_DISTANCE", "Distance", SLIDER, this, this.distance, 4));
        Manager.put(new Setting("XR_TRACERS", "Tracers", CHECKBOX, this, this.tracers));
        Manager.put(new Setting("XR_ESP", "ESP", CHECKBOX, this, this.esp));
        Manager.put(new Setting("XR_UPDATE", "Chunks Update", CHECKBOX, this, this.update));
        Manager.put(new Setting("XR_DELAY", "Update Delay", SLIDER, this, this.delay, 0.5));
    }

    @Override
    public void onEnable() {
        onToggle(true);
    }

    @Override
    public void onDisable() {
        onToggle(false);
        timer.reset();
    }

    private void onToggle(boolean enabled) {
        blockPosList.clear();
        mc.worldRenderer.reload(); // PORT: renderGlobal.loadRenderers -> worldRenderer.reload
        isEnabled = enabled;
    }

    private static java.util.Map<Integer, Block> buildLegacyBlocks() {
        java.util.Map<Integer, Block> map = new java.util.HashMap<>();
        map.put(8, Blocks.WATER); map.put(9, Blocks.WATER);
        map.put(10, Blocks.LAVA); map.put(11, Blocks.LAVA);
        map.put(14, Blocks.GOLD_ORE); map.put(15, Blocks.IRON_ORE); map.put(16, Blocks.COAL_ORE);
        map.put(21, Blocks.LAPIS_ORE); map.put(41, Blocks.GOLD_BLOCK); map.put(42, Blocks.IRON_BLOCK);
        map.put(46, Blocks.TNT); map.put(48, Blocks.MOSSY_COBBLESTONE); map.put(52, Blocks.SPAWNER);
        map.put(56, Blocks.DIAMOND_ORE); map.put(57, Blocks.DIAMOND_BLOCK);
        map.put(61, Blocks.FURNACE); map.put(62, Blocks.FURNACE);
        map.put(73, Blocks.REDSTONE_ORE); map.put(74, Blocks.REDSTONE_ORE);
        map.put(84, Blocks.JUKEBOX); map.put(89, Blocks.GLOWSTONE); map.put(103, Blocks.MELON);
        map.put(116, Blocks.ENCHANTING_TABLE); map.put(117, Blocks.BREWING_STAND); map.put(118, Blocks.CAULDRON);
        map.put(120, Blocks.END_PORTAL_FRAME); map.put(129, Blocks.EMERALD_ORE); map.put(133, Blocks.EMERALD_BLOCK);
        map.put(137, Blocks.COMMAND_BLOCK); map.put(145, Blocks.ANVIL);
        map.put(152, Blocks.REDSTONE_BLOCK); map.put(153, Blocks.NETHER_QUARTZ_ORE); map.put(154, Blocks.HOPPER);
        return java.util.Collections.unmodifiableMap(map);
    }

    /** Used by the AbstractBlockState isSideInvisible mixin: whitelisted blocks stay visible. */
    public static boolean isXrayBlock(Block block) {
        for (Integer id : blockIdList) {
            Block legacy = LEGACY_BLOCKS.get(id);
            if (legacy == block) return true;
        }
        return false;
    }

    @EventTarget
    public void update(TickUpdateEvent event) {
        if (alpha != opacity.get()) {
            mc.worldRenderer.reload();
            alpha = opacity.get();

        } else if (update.get()) {
            if (timer.delay(1000 * delay.get())) {
                mc.worldRenderer.reload();
                timer.reset();
            }
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent e) {
        if (esp.get()) {
            for (BlockPos pos : blockPosList) {
                if (getDistance(pos.getX(), pos.getZ()) <= distance.get()) { // PORT: patched 2-arg getDistance -> inline XZ distance
                    Block block = mc.world.getBlockState(pos).getBlock();

                    if (block == Blocks.DIAMOND_ORE && ores.contains("Diamond")) {
                        render3D(pos, 0, 255, 255);
                    } else if (block == Blocks.IRON_ORE && ores.contains("Iron")) {
                        render3D(pos, 225, 225, 225);
                    } else if (block == Blocks.LAPIS_ORE && ores.contains("Lapis")) {
                        render3D(pos, 0, 0, 255);
                    } else if (block == Blocks.REDSTONE_ORE && ores.contains("Redstone")) {
                        render3D(pos, 255, 0, 0);
                    } else if (block == Blocks.COAL_ORE && ores.contains("Coal")) {
                        render3D(pos, 0, 30, 30);
                    } else if (block == Blocks.EMERALD_ORE && ores.contains("Emerald")) {
                        render3D(pos, 0, 255, 0);
                    } else if (block == Blocks.GOLD_ORE && ores.contains("Gold")) {
                        render3D(pos, 255, 255, 0);
                    }
                }
            }
        }
    }

    private double getDistance(double x, double z) {
        double dx = mc.player.getX() - x;
        double dz = mc.player.getZ() - z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private void render3D(BlockPos pos, int red, int green, int blue) {
        if (esp.get()) {
            RenderUtils.drawSolidBlockESP(pos, ColorUtils.getColor(red, green, blue));
        }

        if (tracers.get()) {
            RenderUtils.drawLine(pos, ColorUtils.getColor(red, green, blue));
        }
    }

    @EventTarget
    public void onSetting(SettingEvent event) {
        if (event.getSettingName().equals("XR_ESP") || event.getSettingName().equals("XR_TRACERS")) {
            blockPosList.clear();
            mc.worldRenderer.reload();
        }
    }

    public static boolean showESP() {
        return Novoline.getInstance().getModuleManager().getModule(XRay.class).esp.get();
    }

    public static int getDistance() {
        return Novoline.getInstance().getModuleManager().getModule(XRay.class).distance.get();
    }
}
