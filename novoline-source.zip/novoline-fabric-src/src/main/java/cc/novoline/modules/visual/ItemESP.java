package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render2DEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.player.AutoArmor;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.ScaleUtils;
import cc.novoline.utils.ScaledResolution;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.joml.Vector3d;
import org.joml.Vector4d;

import static cc.novoline.modules.configurations.property.object.PropertyFactory.booleanFalse;
import static java.awt.Color.BLACK;
import static net.minecraft.util.Formatting.*;

public final class ItemESP extends AbstractModule {

    /* properties @off */
    @Property("names")
    private final BooleanProperty names = booleanFalse();
    @Property("needed-only")
    private final BooleanProperty neededOnly = booleanFalse();
    // PORT: GL matrix buffers replaced by JOML matrices computed in project2D.


    /* constructors @on */
    public ItemESP(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "ItemESP", "Item ESP", Keyboard.KEY_NONE, EnumModuleType.VISUALS, "");
        Manager.put(new Setting("NAMES", "Names", SettingType.CHECKBOX, this, names));
        Manager.put(new Setting("NEEDED_ONLY", "Needed Only", SettingType.CHECKBOX, this, neededOnly));
    }

    @EventTarget
    public void onRender(Render2DEvent er) {
        for (Entity o : this.mc.world.getEntities()) {
            if (o instanceof ItemEntity) {
                // PORT: IBakedModel ground-transform scale was read into f2 and unused — dropped.
                float f1 = MathHelper.sin(((float) ((ItemEntity) o).getItemAge() + er.getPartialTicks()) / 10.0F + ((ItemEntity) o).uniqueOffset) * 0.1F + 0.1F;
                final double x = RenderUtils.interpolate(o.getX(), o.lastX, er.getPartialTicks()), // @off
                        y = RenderUtils.interpolate(o.getY() + f1, o.lastY + f1, er.getPartialTicks()),
                        z = RenderUtils.interpolate(o.getZ(), o.lastZ, er.getPartialTicks()),
                        width = o.getWidth() / 1.4,
                        height = o.getHeight() + 0.2; // @on

                Box aabb = new Box(x - width, y, z - width, x + width, y + height, z + width);
                List<Vector3d> vectors = Arrays.asList(new Vector3d(aabb.minX, aabb.minY, aabb.minZ),
                        new Vector3d(aabb.minX, aabb.maxY, aabb.minZ), new Vector3d(aabb.maxX, aabb.minY, aabb.minZ),
                        new Vector3d(aabb.maxX, aabb.maxY, aabb.minZ), new Vector3d(aabb.minX, aabb.minY, aabb.maxZ),
                        new Vector3d(aabb.minX, aabb.maxY, aabb.maxZ), new Vector3d(aabb.maxX, aabb.minY, aabb.maxZ),
                        new Vector3d(aabb.maxX, aabb.maxY, aabb.maxZ));

                // PORT: entityRenderer.setupCameraTransform/setupOverlayRendering removed — camera matrices
                // are computed inside project2D and 2D drawing happens on the DrawContext.
                Vector4d position = null;

                ScaledResolution resolution = new ScaledResolution(mc);

                for (Vector3d vector : vectors) {
                    vector = project2D(resolution, vector.x - this.mc.gameRenderer.getCamera().getCameraPos().getX(),
                            vector.y - this.mc.gameRenderer.getCamera().getCameraPos().getY(),
                            vector.z - this.mc.gameRenderer.getCamera().getCameraPos().getZ(),
                            er.getPartialTicks());

                    if (vector != null && vector.z >= 0.0 && vector.z < 1.0) {
                        if (position == null) {
                            position = new Vector4d(vector.x, vector.y, vector.z, 0.0);
                        }

                        position.x = Math.min(vector.x, position.x);
                        position.y = Math.min(vector.y, position.y);
                        position.z = Math.max(vector.x, position.z);
                        position.w = Math.max(vector.y, position.w);
                    }
                }

                if (position != null && (!neededOnly.get() || isItemSpecial((ItemEntity) o))) {
                    double posX = position.x, // @off
                            posY = position.y,
                            endPosX = position.z,
                            endPosY = position.w;

                    // region BOX
                    RenderUtils.drawCornerBox(posX, posY, endPosX, endPosY, isItemSpecial((ItemEntity) o) ? 4 : 3, BLACK);
                    RenderUtils.drawCornerBox(posX, posY, endPosX, endPosY, isItemSpecial((ItemEntity) o) ? 2 : 1, getItemColor((ItemEntity) o));
                    // endregion

                    // region name
                    if (names.get()) {
                        float amp = 1;
                        switch (mc.options.getGuiScale().getValue()) {
                            case 0:
                                amp = 0.5F;
                                break;
                            case 1:
                                amp = 2.0F;
                                break;
                            case 3:
                                amp = 0.6666666666666667F;
                        }

                        // PORT-FIX: project2D already yields scaled screen coords —
                        // inverse of the scale(0.5*amp) below keeps text anchored
                        // (same transform fix as PlayerESP).
                        double inv = 1.0 / (0.5 * amp);
                        double[] scaledPositions = new double[]{posX * inv, posY * inv, endPosX * inv, endPosY * inv};

                        er.getContext().getMatrices().pushMatrix(); // PORT: glPushMatrix/glScalef -> Matrix3x2fStack
                        er.getContext().getMatrices().scale(0.5f * amp, 0.5f * amp);
                        double _width = Math.abs(scaledPositions[2] - scaledPositions[0]);
                        float v = (float) (mc.textRenderer.fontHeight * 2) - mc.textRenderer.fontHeight / 2;
                        String itemName = getDisplayName(((ItemEntity) o).getStack());

                        // PORT: fontRendererCrack -> mc.textRenderer; drawStringWithShadow -> context.drawText(shadow)
                        er.getContext().drawText(mc.textRenderer, itemName,
                                (int) (scaledPositions[0] + _width / 2 -
                                        mc.textRenderer.getWidth(itemName) / 2),
                                (int) (scaledPositions[3] + v),
                                getItemColor((ItemEntity) o).brighter().getRGB(), true);
                        er.getContext().getMatrices().popMatrix();
                        // endregion
                    }
                }
            }
        }
    }


    private boolean isItemSpecial(ItemEntity o) {
        boolean special = isArmor(o.getStack()) ||
                isSkull(o.getStack()) //
                        && !getDisplayName(o.getStack()).equalsIgnoreCase("Zombie Head") //
                        && !getDisplayName(o.getStack()).equalsIgnoreCase("Creeper Head") //
                        && !getDisplayName(o.getStack()).equalsIgnoreCase("Skeleton Skull") //
                        && !getDisplayName(o.getStack()).equalsIgnoreCase("Wither Skeleton Skull") //
                        && !getDisplayName(o.getStack()).equalsIgnoreCase(GREEN + "Frog's Hat")
                || o.getStack().isOf(Items.GOLDEN_APPLE) || o.getStack().isOf(Items.ENCHANTED_GOLDEN_APPLE);


        if (isArmor(o.getStack())) {
            final AutoArmor armorModule = getModule(AutoArmor.class);


            for (int type = 1; type < 5; type++) {
                EquipmentSlot strType; // PORT: armor type is now EquippableComponent.slot, not the unlocalized name

                switch (type) {
                    case 1:
                        strType = EquipmentSlot.HEAD;
                        break;
                    case 2:
                        strType = EquipmentSlot.CHEST;
                        break;
                    case 3:
                        strType = EquipmentSlot.LEGS;
                        break;
                    case 4:
                        strType = EquipmentSlot.FEET;
                        break;
                    default:
                        strType = null;
                        break;
                }


                if (mc.player.playerScreenHandler.getSlot(4 + type).hasStack()) {
                    ItemStack is = mc.player.playerScreenHandler.getSlot(4 + type).getStack();
                    if (armorSlot(is) == strType && armorSlot(o.getStack()) == strType) {
                        return getProtection(o.getStack()) > getProtection(mc.player.playerScreenHandler.getSlot(4 + type).getStack());
                    }
                }
            }
            return !hasItem(o.getStack());
        } else if (o.getStack().isIn(ItemTags.SWORDS)) {
            for (int i = 9; i < 45; i++) {
                if (mc.player.playerScreenHandler.getSlot(i).hasStack()) {
                    if (mc.player.playerScreenHandler.getSlot(i).getStack().isIn(ItemTags.SWORDS)) {
                        return getDamage(o.getStack()) > getDamage(mc.player.playerScreenHandler.getSlot(i).getStack());
                    }
                }
            }
            return !hasItem(o.getStack());
        } else if (o.getStack().isIn(ItemTags.PICKAXES)) {
            for (int i = 9; i < 45; i++) {
                if (mc.player.playerScreenHandler.getSlot(i).hasStack()) {
                    if (mc.player.playerScreenHandler.getSlot(i).getStack().isIn(ItemTags.PICKAXES)) {
                        return getToolEffect(o.getStack()) > getToolEffect(mc.player.playerScreenHandler.getSlot(i).getStack());
                    }
                }
            }
            return !hasItem(o.getStack());
        } else if (o.getStack().isIn(ItemTags.SHOVELS)) {
            for (int i = 9; i < 45; i++) {
                if (mc.player.playerScreenHandler.getSlot(i).hasStack()) {
                    if (mc.player.playerScreenHandler.getSlot(i).getStack().isIn(ItemTags.SHOVELS)) {
                        return getToolEffect(o.getStack()) > getToolEffect(mc.player.playerScreenHandler.getSlot(i).getStack());
                    }
                }
            }
            return !hasItem(o.getStack());
        } else if (o.getStack().isIn(ItemTags.AXES)) {
            for (int i = 9; i < 45; i++) {
                if (mc.player.playerScreenHandler.getSlot(i).hasStack()) {
                    if (mc.player.playerScreenHandler.getSlot(i).getStack().isIn(ItemTags.AXES)) {
                        return getToolEffect(o.getStack()) > getToolEffect(mc.player.playerScreenHandler.getSlot(i).getStack());
                    }
                }
            }
            return !hasItem(o.getStack());
        }
        return special;
    }

    // PORT: ItemArmor is gone — wearable armor is detected through the EQUIPPABLE component.
    private static EquipmentSlot armorSlot(@NotNull ItemStack stack) {
        EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);
        return equippable == null ? null : equippable.slot();
    }

    private static boolean isArmor(@NotNull ItemStack stack) {
        EquipmentSlot slot = armorSlot(stack);
        return slot == EquipmentSlot.HEAD || slot == EquipmentSlot.CHEST
                || slot == EquipmentSlot.LEGS || slot == EquipmentSlot.FEET;
    }

    // PORT: ItemSkull is gone — skulls are BlockItems wrapping AbstractSkullBlock.
    private static boolean isSkull(@NotNull ItemStack stack) {
        return stack.getItem() instanceof BlockItem
                && ((BlockItem) stack.getItem()).getBlock() instanceof AbstractSkullBlock;
    }

    // PORT: tool/sword/armor attribute values live in ATTRIBUTE_MODIFIERS, not on the Item class.
    private static double attributeValue(@NotNull ItemStack stack,
                                         net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> attribute,
                                         EquipmentSlot slot) {
        AttributeModifiersComponent modifiers =
                stack.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT);
        return modifiers.applyOperations(attribute, 0.0, slot);
    }

    private int getEnchantmentLevel(@NotNull RegistryKey<Enchantment> enchantment, @NotNull ItemStack stack) {
        // PORT: enchantment ids -> RegistryKey lookup via the world registry
        if (mc.world == null) return 0;
        return EnchantmentHelper.getLevel(
                mc.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(enchantment), stack);
    }

    // PORT: ItemStack.getDisplayName() returned a legacy-formatted string; rebuild it from Text styles.
    private static String getDisplayName(@NotNull ItemStack stack) {
        StringBuilder sb = new StringBuilder();
        stack.getName().visit((style, string) -> {
            if (!style.isEmpty()) {
                net.minecraft.text.TextColor color = style.getColor();
                if (color != null) {
                    for (net.minecraft.util.Formatting formatting : net.minecraft.util.Formatting.values()) {
                        if (formatting.isColor() && formatting.getColorValue() == color.getRgb()) {
                            sb.append('§').append(formatting.getCode());
                            break;
                        }
                    }
                }
                if (style.isBold()) sb.append("§l");
                if (style.isItalic()) sb.append("§o");
                if (style.isUnderlined()) sb.append("§n");
                if (style.isStrikethrough()) sb.append("§m");
                if (style.isObfuscated()) sb.append("§k");
            }
            sb.append(string);
            return Optional.empty();
        }, net.minecraft.text.Style.EMPTY);
        return sb.toString();
    }

    private float getProtection(@NotNull ItemStack stack) {
        float protection = 0;

        if (isArmor(stack)) {
            double reduceAmount = attributeValue(stack, EntityAttributes.ARMOR, armorSlot(stack));

            protection += reduceAmount + (100 - reduceAmount) * getEnchantmentLevel(
                    Enchantments.PROTECTION, stack) * 0.0075D;
            protection += getEnchantmentLevel(Enchantments.BLAST_PROTECTION, stack) / 100d;
            protection += getEnchantmentLevel(Enchantments.FIRE_PROTECTION, stack) / 100d;
            protection += getEnchantmentLevel(Enchantments.THORNS, stack) / 100d;
            protection += getEnchantmentLevel(Enchantments.UNBREAKING, stack) / 50d;
            protection += getEnchantmentLevel(Enchantments.PROJECTILE_PROTECTION, stack) / 100d;
        }

        return protection;
    }

    private float getDamage(@NotNull ItemStack stack) {
        float damage = 0;
        final Item item = stack.getItem();

        if (stack.contains(DataComponentTypes.TOOL)) {
            damage += attributeValue(stack, EntityAttributes.ATTACK_DAMAGE, EquipmentSlot.MAINHAND);
        } else if (stack.isIn(ItemTags.SWORDS)) {
            damage += attributeValue(stack, EntityAttributes.ATTACK_DAMAGE, EquipmentSlot.MAINHAND);
        }

        damage += getEnchantmentLevel(Enchantments.SHARPNESS, stack) * 1.25F + getEnchantmentLevel(
                Enchantments.FIRE_ASPECT, stack) * 0.01F;
        return damage;
    }

    private float getToolEffect(@NotNull ItemStack stack) {
        final Item item = stack.getItem();

        if (!stack.contains(DataComponentTypes.TOOL)) {
            return 0;
        }

        final String name = item.getTranslationKey();
        float value;

        if (stack.isIn(ItemTags.PICKAXES)) {
            value = stack.getMiningSpeedMultiplier(Blocks.STONE.getDefaultState());
            if (name.toLowerCase().contains("gold")) value -= 5;
        } else if (stack.isIn(ItemTags.SHOVELS)) {
            value = stack.getMiningSpeedMultiplier(Blocks.DIRT.getDefaultState());
            if (name.toLowerCase().contains("gold")) value -= 5;
        } else if (stack.isIn(ItemTags.AXES)) {
            value = stack.getMiningSpeedMultiplier(Blocks.OAK_LOG.getDefaultState());
            if (name.toLowerCase().contains("gold")) value -= 5;
        } else return 1f;

        value += getEnchantmentLevel(Enchantments.EFFICIENCY, stack) * 0.0075D;
        value += getEnchantmentLevel(Enchantments.UNBREAKING, stack) / 100.0D;

        return value;
    }


    private boolean hasItem(@NotNull ItemStack is) {
        // PORT: armorInventory[0..2] -> equipped armor slots
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST}) {
            ItemStack armor = mc.player.getEquippedStack(slot);
            if (!armor.isEmpty()) {
                if (armor.getItem() == is.getItem()) {
                    return true;
                }
            }
        }
        for (int i = 9; i < 45; i++) {
            if (mc.player.playerScreenHandler.getSlot(i).hasStack()) {
                final ItemStack is1 = mc.player.playerScreenHandler.getSlot(i).getStack();
                if (is.getItem() == is1.getItem()) {
                    return true;
                }
            }
        }
        return false;
    }

    private Color getItemColor(ItemEntity o) {

        String displayName = getDisplayName(o.getStack());
        if (displayName.equalsIgnoreCase(GOLD + "Excalibur") || displayName.equalsIgnoreCase("aDragon Sword")
                || displayName.equalsIgnoreCase(GREEN + "Cornucopia")
                || displayName.equalsIgnoreCase(RED + "Bloodlust") || displayName.equalsIgnoreCase(RED + "Artemis' Bow")
                || displayName.equalsIgnoreCase(GREEN + "Miner's Blessing") || displayName.equalsIgnoreCase(GOLD + "Axe of Perun")
                || displayName.equalsIgnoreCase(GOLD + "Cornucopia")) {
            HUD hud = getModule(HUD.class);
            return new Color(hud.getArrayRainbow((int) (System.currentTimeMillis() / 100000), 255));
        }

        if (!isItemSpecial(o)) {
            return new Color(255, 255, 255);
        }

        if (isArmor(o.getStack())) {
            return new Color(75, 189, 193);
        } else if (o.getStack().isOf(Items.GOLDEN_APPLE) || o.getStack().isOf(Items.ENCHANTED_GOLDEN_APPLE)) {
            return new Color(255, 199, 71);
        } else if (isSkull(o.getStack()) && isItemSpecial(o)) {
            return new Color(255, 199, 71);
        } else if (o.getStack().isIn(ItemTags.SWORDS)) {
            return new Color(255, 117, 117);
        } else if (o.getStack().isIn(ItemTags.PICKAXES)) {
            return new Color(130, 219, 82);
        } else if (o.getStack().isIn(ItemTags.SHOVELS)) {
            return new Color(130, 219, 82);
        } else if (o.getStack().isIn(ItemTags.AXES)) {
            return new Color(130, 219, 82);
        } else {

            return new Color(255, 255, 255);
        }
    }


    private Vector3d project2D(ScaledResolution scaledResolution, double x, double y, double z, float partialTicks) {
        // PORT: glGetFloat(modelView/projection) + GLU.gluProject -> JOML matrices from the game camera.
        // View matrix uses the CONJUGATED camera rotation, matching GameRenderer#renderWorld.
        Camera camera = mc.gameRenderer.getCamera();
        Matrix4f modelView = new Matrix4f().rotation(camera.getRotation().conjugate(new Quaternionf()));
        /* PORT: must use the live FOV (sprint/effect modifiers included) — the
           options value projects with the wrong frustum so boxes sit offset
           from the items on screen. */
        float fov = ((cc.novoline.mixin.GameRendererAccessor) mc.gameRenderer)
                .novoline$getFov(camera, partialTicks, true);
        Matrix4f projection = mc.gameRenderer.getBasicProjectionMatrix(fov);
        // PORT-FIX: discard points behind the camera — w-flipped projection can
        // still yield in-range NDC z, smearing labels onto the horizon.
        if (modelView.transform((float) x, (float) y, (float) z, 1.0F, new Vector4f()).z() > 0.0F) {
            return null;
        }
        Matrix4f mvp = projection.mul(modelView, new Matrix4f());
        int[] viewport = {0, 0, mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight()};
        Vector4f vector = mvp.project((float) x, (float) y, (float) z, viewport, new Vector4f());

        return new Vector3d(vector.x() / scaledResolution.getScaleFactor(),
                (mc.getWindow().getFramebufferHeight() - vector.y()) / scaledResolution.getScaleFactor(), vector.z());
    }


}
