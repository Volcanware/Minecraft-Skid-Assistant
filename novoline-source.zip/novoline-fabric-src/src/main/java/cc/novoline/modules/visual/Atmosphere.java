package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.DoubleProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.configurations.property.object.StringProperty;
import org.jetbrains.annotations.NotNull;

import static cc.novoline.modules.EnumModuleType.VISUALS;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createDouble;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createString;

public final class Atmosphere extends AbstractModule {

    /* properties @off */
    @Property("time")
    private final DoubleProperty time = createDouble(12.0).minimum(1.0).maximum(24.0);
    @Property("weather-mode")
    private final StringProperty weather_mode = createString("Clean").acceptableValues("Clean", "Rain", "Thunder", "Snowfall", "Snowstorm");
    @Property("weather-control")
    private final BooleanProperty weather_control = PropertyFactory.booleanFalse();

    // PORT: read by the pending world-time hook — the 1.8.9 jar-mod patched
    // WorldInfo to force this value; the port needs a mixin on the client
    // world's time-of-day getter (see notes/hooks_needed).
    public long getTime() {
        return time.get().longValue() * 1000L;
    }

    /* constructors @on */
    public Atmosphere(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Atmosphere", VISUALS);
        Manager.put(new Setting("WORLD_TIME", "Hour", SettingType.SLIDER, this, this.time, 0.5));
        Manager.put(new Setting("WEATHER_CONTROL", "Weather control", SettingType.CHECKBOX, this, weather_control));
        Manager.put(new Setting("WEATHER_MODE", "Weather state", SettingType.COMBOBOX, this, weather_mode, weather_control::get));
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (weather_control.get()) {
            switch (weather_mode.get()) {
                case "Snowfall":
                case "Rain":
                    mc.world.setRainGradient(1.0F);
                    mc.world.setThunderGradient(0.0F);
                    break;
                case "Snowstorm":
                case "Thunder":
                    mc.world.setRainGradient(1.0F);
                    mc.world.setThunderGradient(1.0F);
                    break;
                default:
                    mc.world.setRainGradient(0.0F);
                    mc.world.setThunderGradient(0.0F);
            }
        }
    }

    public StringProperty getWeather_mode() {
        return weather_mode;
    }

}
