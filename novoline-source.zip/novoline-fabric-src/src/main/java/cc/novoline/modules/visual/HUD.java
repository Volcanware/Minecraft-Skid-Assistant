package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render2DEvent;
import cc.novoline.events.events.SettingEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.modules.move.MoveUtils;
import cc.novoline.utils.PlayerUtils;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.ScaleUtils;
import cc.novoline.utils.ScaledResolution;
import cc.novoline.utils.fonts.impl.Fonts;
import cc.novoline.utils.notifications.NotificationRenderer;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix3x2fStack;
import org.lwjgl.input.Keyboard;

import java.awt.Color;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static cc.novoline.gui.screen.setting.SettingType.*;
import static cc.novoline.modules.PlayerManager.EnumPlayerType.TARGET;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.*;
import static java.lang.Integer.compare;
import static net.minecraft.util.Formatting.*;

public final class HUD extends AbstractModule {

    // PORT: 1.8.9 armorInventory indices 0..3 map to FEET, LEGS, CHEST, HEAD equipment slots.
    private static final EquipmentSlot[] ARMOR_SLOTS = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
    private final Dimension screenSize = cc.novoline.utils.AwtCompat.screenSize();
    private int colorDelay = 11;
    private int colorLength = 110;
    private int displayWidth = 0, displayHeight = 0;
    private List<String> lastMessages = new CopyOnWriteArrayList<>();
    private cc.novoline.utils.fonts.api.FontRenderer font = Fonts.SF.SF_21.SF_21;
    private boolean setFont;

    /* properties @off */
    @Property("client-name")
    private final StringProperty clientName = createString("Novoline");
    @Property("scoreboard")
    private final IntProperty scoreboard = createInt(0).minimum(-150).maximum(200);
    @Property("scale")
    private final FloatProperty fontScale = createFloat(1f).minimum(0.4f).maximum(3f);
    @Property("hud-elements")
    private final ListProperty<String> hudElements = createList("ModuleList", "UserInfo", "ArmorHUD", "Scoreboard", "Bossbar", "PotionHUD", "Coords", "Name", "Time", "FPS")
            .acceptableValues("ModuleList", "UserInfo", "HotBar", "TargetsList", "ArmorHUD", "Scoreboard", "Bossbar", "PotionHUD", "Coords", "Speed", "Name", "Time", "FPS", "Inventory");
    @Property("hud-font")
    private final StringProperty hudFont = createString("Client").acceptableValues("Client", "Vanilla");
    @Property("suffix-type")
    private final StringProperty suffixType = createString("Simple").acceptableValues("Simple", "Dash", "Bracket", "None");
    @Property("background-alpha")
    private final IntProperty backgroundAlpha = createInt(50).minimum(1).maximum(255);
    @Property("background-mode")
    private final StringProperty backgroundMode = createString("Bar").acceptableValues("Outline", "Simple", "Split", "Bar");
    @Property("hud-mode")
    private final StringProperty hudMode = createString("Static").acceptableValues("Rainbow", "Astolfo", "Static", "Dynamic", "Type");
    @Property("color")
    private final ColorProperty color = createColor(0xFF8A8AFF);
    @Property("inv-x")
    private final IntProperty invx = PropertyFactory.createInt((int) screenSize.getWidth() / 4).minimum(1).maximum((int) screenSize.getWidth() / 2);
    @Property("inv-y")
    private final IntProperty invy = PropertyFactory.createInt((int) screenSize.getHeight() / 4).minimum(1).maximum((int) screenSize.getHeight() / 2);
    @Property("tlist-x")
    private final IntProperty tlx = PropertyFactory.createInt((int) screenSize.getWidth() / 4).minimum(1).maximum((int) screenSize.getWidth() / 2);
    @Property("tlist-y")
    private final IntProperty tly = PropertyFactory.createInt((int) screenSize.getHeight() / 4).minimum(1).maximum((int) screenSize.getHeight() / 2);
    @Property("notifications-sounds")
    private final BooleanProperty nSounds = PropertyFactory.booleanFalse();

    /* constructors @on */
    public HUD(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "HUD", "HUD", Keyboard.KEY_NONE, EnumModuleType.VISUALS, "Literally overlay", null);
        Manager.put(new Setting("CLIENT_NAME", "Client Name", TEXTBOX, this, "Client name", clientName, () -> hudElements.get().contains("Name")));
        Manager.put(new Setting("HUDELEMENTS", "Elements", SELECTBOX, this, hudElements));
        Manager.put(new Setting("HUD_FONT", "Font", COMBOBOX, this, hudFont));
        Manager.put(new Setting("SUFFIX_TYPE", "Suffix", COMBOBOX, this, suffixType, () -> hudElements.get().contains("ModuleList")));
        Manager.put(new Setting("BACKGROUND_MODE", "Background", COMBOBOX, this, backgroundMode));
        Manager.put(new Setting("POTION_MODE", "ModuleList", COMBOBOX, this, hudMode, () -> hudElements.get().contains("ModuleList")));
        Manager.put(new Setting("HUD_COLOR", "Color", COLOR_PICKER, this, color, null));
        Manager.put(new Setting("FONT_SCALE", "HUD Scale", SLIDER, this, fontScale, 0.1, () -> hudElements.get().contains("ModuleList") && hudFont.equals("Client")));
        Manager.put(new Setting("SCOREBOARD_POS", "Scoreboard Height", SLIDER, this, scoreboard, 5, () -> hudElements.get().contains("Scoreboard")));
        Manager.put(new Setting("BACKGROUND_ALPHA", "Background Alpha", SLIDER, this, backgroundAlpha, 5, () -> hudElements.get().contains("ModuleList")));
        Manager.put(new Setting("NOTIFICATION-SOUNDS", "Notification sounds", CHECKBOX, this, nSounds));
    }

    @Override
    public void onEnable() {
    }

    public List<String> getLastMessages() {
        return lastMessages;
    }

    public int getArrayStatic(int counter, int alpha) {
        final float[] hudHSB = color.getHSB();
        Color color = Color.getHSBColor(hudHSB[0], hudHSB[1], hudHSB[2]);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
    }

    public FloatProperty getFontScale() {
        return fontScale;
    }

    public float getScale() {
        float s = 1 / getFontScale().get();
        switch (mc.options.getGuiScale().getValue()) { // PORT: gameSettings.guiScale
            case 0:
                return s / 2;
            case 1:
                return s / 0.5f;
            case 3:
                return s / 1.5f;
            default:
                return s;
        }
    }

    public int getArrayDynamic(float counter, int alpha) {
        float brightness = 1.0F - MathHelper.abs(MathHelper.sin(counter % 6000F / 6000F * Math.PI * 2.0F) * 0.6F);
        final float[] hudHSB = color.getHSB();
        Color color = Color.getHSBColor(hudHSB[0], hudHSB[1], brightness);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
    }

    public int getArrayRainbow(int counter, int alpha) {
        final int width = colorLength;

        double rainbowState = Math.ceil(System.currentTimeMillis() - (long) counter * width) / colorDelay;
        rainbowState %= 360;

        final float[] colors = color.getHSB();
        Color color = Color.getHSBColor((float) (rainbowState / 360), colors[1], colors[2]);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
    }

    public int getArrayType(int counter, float hue, int alpha) {
        final float[] hsb = color.getHSB();
        Color color = Color.getHSBColor(hue, hsb[1], hsb[2]);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
    }

    public int getArrayAstolfo(int counter, int alpha) {
        final int width = colorLength;
        double rainbowState = Math.ceil(System.currentTimeMillis() - (long) counter * width) / colorDelay;
        rainbowState %= 360;
        final float hue = (float) (rainbowState / 360) < 0.5 ? -((float) (rainbowState / 360)) : (float) (rainbowState / 360);
        final float[] colors = color.getHSB();
        Color color = Color.getHSBColor(hue, colors[1], colors[2]);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
    }

    public int getHUDColor() {
        final float[] hsb = color.getHSB();
        return Color.getHSBColor(hsb[0], hsb[1], hsb[2]).getRGB();
    }

    // PORT: F3 debug toggle — gameSettings.showDebugInfo -> debugHud.shouldShowDebugHud
    private boolean showDebugInfo() {
        return mc.getDebugHud().shouldShowDebugHud();
    }

    @EventTarget
    public void drawHUD(@NotNull Render2DEvent event) {

        Matrix3x2fStack matrices = event.getContext().getMatrices(); // PORT: glPushMatrix -> Matrix3x2fStack
        matrices.pushMatrix();
        ScaleUtils.scale(mc);
        if (mc.currentScreen == null) {
            NotificationRenderer.draw(event.getContext());
        }
        matrices.popMatrix();
        matrices.pushMatrix();
        matrices.scale(fontScale.get(), fontScale.get());

        if (!isExhibition()) {
            if (hudElements.contains("FPS")) drawFPS(event);
            if (hudElements.contains("Time") && !showDebugInfo()) drawTime(event);
        }

        if (hudElements.contains("ArmorHUD")) drawArmorHUD(event);
        if (hudElements.contains("PotionHUD")) drawPotionHUD(event);


        if (hudElements.contains("UserInfo")) drawUserInfo(event);
        if (hudElements.contains("Name") && !showDebugInfo()) drawName(event);
        if (hudElements.contains("Coords")) drawCoordinates(event);
        if (hudElements.contains("Speed")) drawSpeed(event);

        if (hudElements.contains("TargetsList")) drawTargetsList(event);

        if (hudElements.contains("ModuleList") && !showDebugInfo()) {

            drawArrayList(event);

        }
        if (hudElements.contains("Inventory")) drawInventory(event.getContext());

        matrices.popMatrix(); // PORT: glColor4f reset dropped — colors are per-vertex now
    }



    public IntProperty getInvx() {
        return invx;
    }

    public IntProperty getInvy() {
        return invy;
    }


    public void drawInventory(@NotNull DrawContext context) {
        if (!(mc.currentScreen instanceof ChatScreen)) {
            int x = invx.get();
            int y = invy.get();
            RenderUtils.drawRect(x, y, x + 167, y + 73, new Color(29, 29, 29, 255).getRGB()); // PORT: Gui.drawRect
            RenderUtils.drawRect(x + 1, y + 13, x + 166, y + 72, new Color(40, 40, 40, 255).getRGB());
            context.drawText(mc.textRenderer, "Your Inventory", x + 3, y + 3, 0xffffffff, true); // PORT: fontRendererCrack


            boolean hasStacks = false;
            for (int i1 = 9; i1 < mc.player.playerScreenHandler.slots.size() - 9; ++i1) { // PORT: inventoryContainer.inventorySlots
                Slot slot = mc.player.playerScreenHandler.slots.get(i1);
                if (slot.hasStack()) hasStacks = true;
                int i = slot.x; // PORT: xDisplayPosition -> x
                int j = slot.y;
                context.drawItem(slot.getStack(), x + i - 4, y + j - 68);
                context.drawStackOverlay(mc.textRenderer, slot.getStack(), x + i - 4, y + j - 68);
            }
            if (mc.currentScreen instanceof InventoryScreen) {
                context.drawText(mc.textRenderer, "Already in inventory",
                        x + 167 / 2 - mc.textRenderer.getWidth("Already in inventory") / 2,
                        y + 72 / 2,
                        0xffffffff,
                        true);
            } else if (!hasStacks) {
                context.drawText(mc.textRenderer, "Empty...",
                        x + 167 / 2 - mc.textRenderer.getWidth("Empty...") / 2,
                        y + 72 / 2,
                        0xffffffff,
                        true);
            }
            // PORT: enableGUIStandardItemLighting / depth toggles dropped — DrawContext.drawItem manages state.
        }
    }


    private int getArrayListColor(int counter, int alpha, float hue, float brightnesscounter) {
        int color = getArrayRainbow(counter, alpha);

        switch (hudMode.get().toLowerCase()) {
            case "type":
                color = getArrayType(counter, hue, alpha);
                break;

            case "astolfo":
                color = getArrayAstolfo(counter, alpha);
                break;

            case "static":
                color = getArrayStatic(counter, alpha);
                break;

            case "dynamic":
                color = getArrayDynamic(brightnesscounter, alpha);
        }

        return color;
    }

    public List<AbstractModule> getModules() {
        final net.minecraft.client.font.TextRenderer font = mc.textRenderer; // PORT: fontRendererObj
        final String hudFont = this.hudFont.get();
        Stream<AbstractModule> stream = novoline.getModuleManager().getAbstractModules().stream();

        if (hudFont.equalsIgnoreCase("Vanilla")) {
            stream = stream.sorted((mod1, mod2) -> compare(font.getWidth(mod2.getFinalDisplayName()),
                    font.getWidth(mod1.getFinalDisplayName())));
        } else {
            stream = stream.sorted((mod1, mod2) -> compare(this.font.stringWidth(mod2.getFinalDisplayName()),
                    this.font.stringWidth(mod1.getFinalDisplayName())));
        }
        return stream.filter(m -> !m.isHidden()).collect(Collectors.toList());
    }

    public float getHeight(AbstractModule module) {
        float y = 2;
        for (AbstractModule abstractModule : getModules()) {
            if (abstractModule == module) {
                return y;
            }

            if (hudFont.equalsIgnoreCase("Vanilla")) {
                y += mc.textRenderer.fontHeight + 2;
            } else {
                y += font.getHeight() + 1;
            }
        }

        return 2;
    }

    @EventTarget
    public void onUpdate(Render2DEvent eventUpdate) {
        float y = hudFont.equalsIgnoreCase("Vanilla") ? -mc.textRenderer.fontHeight + 1 : -font.getHeight() + 1;

        for (AbstractModule m : getModules()) {
            double clamp = MathHelper.clamp(mc.getCurrentFps() / 30, 1, 9999); // PORT: getDebugFPS

            if (m.isEnabled()) {
                m.offsetX = (float) (m.offsetX + (hudFont.equalsIgnoreCase("Vanilla") ?
                        mc.textRenderer.getWidth(m.getFinalDisplayName()) : font.stringWidth(m.getFinalDisplayName()) - m.offsetX) * (0.2 / clamp));
            } else if (m.offsetX < 0) {
                novoline.getModuleManager().getAbstractModules().remove(m);
            } else if (m.offsetX > -2) {
                m.offsetX = (float) (m.offsetX + (-2 - m.offsetX) * (0.2 / clamp));
            }
            m.offsetX = MathHelper.clamp(m.offsetX, -2, hudFont.equalsIgnoreCase("Vanilla") ?
                    mc.textRenderer.getWidth(m.getFinalDisplayName()) : font.stringWidth(m.getFinalDisplayName()));

            if (hudFont.equalsIgnoreCase("Vanilla")) {
                y += mc.textRenderer.fontHeight + 1.0F;
            } else {
                y += font.getHeight() + 1F;
            }

            m.offsetY = (float) (m.offsetY + (y - m.offsetY) * (0.2 / clamp));
        }
    }

    private void drawArrayList(@NotNull Render2DEvent event) {
        int counter = 1;
        float j = Util.getMeasuringTimeMs(); // PORT: Minecraft.getSystemTime
        float y;
        final cc.novoline.utils.fonts.api.FontRenderer cFont = font;
        final String hudFont = this.hudFont.get();

        final List<AbstractModule> modules = getModules();

        if (getModule(HUD.class).isEnabled() && hudElements.get().contains("ModuleList")) {
            for (AbstractModule module : modules) {
                /* PORT: snap the row edge to a whole gui pixel — lerped offsetY
                   leaves sub-pixel seams between adjacent background rects that
                   rasterize as visible gaps/dark double-drawn lines (very
                   noticeable at GUI scale 2+). */
                y = Math.round(module.offsetY);
                /* Позиция для рисования шрифта */
                float x = (new ScaledResolution(mc).getScaledWidthStatic(mc) * getScale()) - module.offsetX - 2.0F;
                /* Цвет бг */
                int bgColor = new Color(0, 0, 0, backgroundAlpha.get()).getRGB();
                /* Цвет шрифта */
                int modColor = getArrayListColor(counter, 255, module.categoryColor(), j);
                /* Ширина окна майна */
                float width = new ScaledResolution(mc).getScaledWidthStatic(mc) * getScale();
                /* Высота Шрифта */
                float fontHeight = hudFont.equalsIgnoreCase("Vanilla") ? mc.textRenderer.fontHeight : cFont.getHeight();
                /* Отступы */
                float bgMargin = backgroundMode.get().equalsIgnoreCase("bar") ? 2.5f : 1.5f;

                if (backgroundMode.get().equalsIgnoreCase("outline") || backgroundMode.get().equalsIgnoreCase("split")) {
                    RenderUtils.drawRect( // PORT: Gui.drawRect
                            width - (module.offsetX + 6) - bgMargin,
                            y - (modules.indexOf(module) == 0 ? 2 : 0),
                            width - (module.offsetX + 5) - bgMargin,
                            y + fontHeight + 2, modColor);
                }
                if (backgroundMode.get().equalsIgnoreCase("outline")) {
                    float difference;

                    if (modules.indexOf(module) == modules.size() - 1) {
                        // нижняя часть
                        RenderUtils.drawRect(
                                width - (module.offsetX + 6) - bgMargin,
                                y + fontHeight + 2,
                                width,
                                y + fontHeight + 3, modColor);
                    } else {
                        if (hudFont.equalsIgnoreCase("Vanilla")) {
                            difference = Math.abs(mc.textRenderer.getWidth(modules.get(modules.indexOf(module)).getFinalDisplayName()) -
                                    mc.textRenderer.getWidth(modules.get(modules.indexOf(module) + 1).getFinalDisplayName()));
                        } else {
                            difference = Math.abs(cFont.stringWidth(modules.get(modules.indexOf(module)).getFinalDisplayName()) -
                                    cFont.stringWidth(modules.get(modules.indexOf(module) + 1).getFinalDisplayName()));
                        }

                        // нижняя часть
                        RenderUtils.drawRect(
                                width - (module.offsetX + 5) - bgMargin,
                                y + fontHeight + 1,
                                width - (module.offsetX + 5) - bgMargin + difference,
                                y + fontHeight + 2, modColor);
                    }
                }
                // end outline

                // сам бг
                RenderUtils.drawRect(
                        width - (module.offsetX + 4) - bgMargin - (backgroundMode.equalsIgnoreCase("outline") || backgroundMode.equalsIgnoreCase("split") ? 1 : 0),
                        y - (modules.indexOf(module) == 0 ? 3 : 0),
                        width,
                        y + fontHeight + (modules.indexOf(module) == modules.size() - 1 ? 2 : 1), bgColor);

                // Текст

                if (hudFont.equalsIgnoreCase("Vanilla")) {
                    event.getContext().drawText(mc.textRenderer, module.getFinalDisplayName(), (int) (x - bgMargin), (int) (y + 1.0F), modColor, true);
                } else {
                    cFont.drawString(module.getFinalDisplayName(), x - bgMargin, y + 1.0F, modColor, true);
                }

                if (backgroundMode.get().equalsIgnoreCase("Bar")) {
                    RenderUtils.drawRect(width - 1.0F, y - 1, width, y + fontHeight + (modules.indexOf(module) == modules.size() - 1 ? 2 : 1), modColor);
                }
                j -= 300;
                counter++;
            }
        }
    }


    private void drawArmorHUD(@NotNull Render2DEvent event) {
        final int color = getHUDColor();
        Matrix3x2fStack matrices = event.getContext().getMatrices();
        matrices.pushMatrix();

        final List<ItemStack> stuff = new ObjectArrayList<>();
        final boolean onWater = mc.player.isAlive() && mc.player.isTouchingWater(); // PORT: isInsideOfMaterial(water)

        for (int index = 3; index >= 0; --index) {
            final ItemStack armor = mc.player.getEquippedStack(ARMOR_SLOTS[index]);

            if (!armor.isEmpty()) stuff.add(armor);
        }

        if (!mc.player.getMainHandStack().isEmpty()) stuff.add(mc.player.getMainHandStack()); // PORT: getCurrentEquippedItem

        int split = -3;
        int split2 = -3;

        for (ItemStack item : stuff) {
            if (mc.world != null) {
                split += 16;
                split2 += 32;
            }

            final int damage = item.getMaxDamage() - item.getDamage(); // PORT: getItemDamage
            final String hudFont = this.hudFont.get();

            final ScaledResolution resolution = new ScaledResolution(mc);
            final int scaledWidth = (int) (resolution.getScaledWidthStatic(mc) * getScale());
            final int scaledHeight = (int) (resolution.getScaledHeightStatic(mc) * getScale());

            if (!item.isStackable()) {
                if (!(item.getItem() instanceof PotionItem)) {
                    if (hudFont.equalsIgnoreCase("Client")) {
                        float v1 = (float) (scaledHeight - (onWater ? 68 : 58));
                        Fonts.SFTHIN.SFTHIN_10.SFTHIN_10.drawString(String.valueOf(damage), split + scaledWidth / 2F - 1.5F, v1, color, true);
                    } else {
                        matrices.pushMatrix();
                        matrices.scale(0.5f, 0.5f);
                        event.getContext().drawText(mc.textRenderer, String.valueOf(damage), (int) (split2 + scaledWidth - 4F),
                                (int) (scaledHeight * 2 - (onWater ? 139 : 119)), color, true);
                        matrices.scale(2.0f, 2.0f);
                        matrices.popMatrix();
                    }
                }
            }

            matrices.pushMatrix();

            // PORT: RenderItem.zLevel is gone — DrawContext draws items at a fixed z; alpha/blend/depth flags
            // are managed by the gui pipeline.
            event.getContext().drawItem(item, split + (int) (scaledWidth / 2F) - 4,
                    (int) (scaledHeight - (onWater ? 66.5F : 56.5F)));

            if (item.isStackable()) {
                if (hudFont.equalsIgnoreCase("Client")) {
                    float v1 = (float) (scaledHeight - (onWater ? 68 : 58));
                    Fonts.SFTHIN.SFTHIN_10.SFTHIN_10.drawString(String.valueOf(item.getCount()), split + scaledWidth / 2F - 1.5F, v1, color, true);
                } else {
                    matrices.pushMatrix();
                    matrices.scale(0.5f, 0.5f);
                    event.getContext()
                            .drawText(mc.textRenderer, String.valueOf(item.getCount()), (int) (split2 + scaledWidth - 4F),
                                    (int) (scaledHeight * 2 - (onWater ? 139 : 119)), color, true);
                    matrices.scale(2.0f, 2.0f);
                    matrices.popMatrix();
                }
            }

            matrices.popMatrix();
            item.getEnchantments(); // PORT: getEnchantmentTagList
        }

        matrices.popMatrix();
    }

    private void drawUserInfo(@NotNull Render2DEvent render2DEvent) {
        String build = "Build - " + RESET + novoline.getVersion();
        final String info = GRAY + build + GRAY + " | " + "UID - " + WHITE + "Volcan";

        ScaledResolution resolution = new ScaledResolution(mc);

        if (hudFont.equalsIgnoreCase("Client")) {
            font.drawString(info, (float) ((resolution.getScaledWidthStatic(mc) * getScale()) - font.stringWidth(info) - 2),
                    (float) ((resolution.getScaledHeightStatic(mc) * getScale()) - font.getHeight() - 2), 0xFFFFFF, true);
        } else {
            render2DEvent.getContext().drawText(mc.textRenderer, info, (int) ((resolution.getScaledWidthStatic(mc) * getScale()) - mc.textRenderer.getWidth(info) - 1),
                    (int) ((resolution.getScaledHeightStatic(mc) * getScale()) - mc.textRenderer.fontHeight - 1), 0xFFFFFF, true);
        }
    }

    private void drawPotionHUD(@NotNull Render2DEvent event) {
        float y = 0;
        int counter = 1;
        float j = Util.getMeasuringTimeMs();

        for (StatusEffectInstance effect : mc.player.getStatusEffects()) { // PORT: getActivePotionEffects
            final StatusEffect potion = effect.getEffectType().value(); // PORT: Potion.potionTypes[id]
            final StringBuilder pTypeBuilder = new StringBuilder(I18n.translate(potion.getTranslationKey())); // PORT: potion.getName -> getTranslationKey

            switch (effect.getAmplifier()) {
                case 1:
                    pTypeBuilder.append(" II");
                    break;
                case 2:
                    pTypeBuilder.append(" III");
                    break;
                case 3:
                    pTypeBuilder.append(" IV");
                    break;
                case 4:
                    pTypeBuilder.append(" V");
                    break;
            }

            // PORT: Potion.getDurationString -> StatusEffectUtil.getDurationText
            String duration = StatusEffectUtil.getDurationText(effect, 1.0F,
                    mc.world == null ? 20.0F : mc.world.getTickManager().getTickRate()).getString();
            if (effect.getDuration() < 600 && effect.getDuration() > 300) {
                pTypeBuilder.append("§7§6 ").append(duration);
            } else if (effect.getDuration() < 300) {
                pTypeBuilder.append("§7§c ").append(duration);
            } else if (effect.getDuration() > 600) {
                pTypeBuilder.append("§7§7 ").append(duration);
            }

            final int yChat = mc.inGameHud.getChatHud().isChatFocused() && !hudElements // PORT: getChatOpen -> isChatFocused
                    .contains("HotBar") && !hudElements.contains("UserInfo") ? 5 : -10;
            final String pType = String.valueOf(pTypeBuilder);
            final Color color = new Color(potion.getColor()); // PORT: getLiquidColor -> getColor
            final float[] newColor = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), new float[3]);

            int rgbColor = getArrayListColor(counter, 255, newColor[0], j);

            final ScaledResolution resolution = new ScaledResolution(mc);
            final int scaledWidth = (int) (resolution.getScaledWidthStatic(mc) * getScale()), scaledHeight = (int) (resolution.getScaledHeightStatic(mc) * getScale());

            if (hudFont.equalsIgnoreCase("Client")) {
                float v1 = scaledHeight - font.getHeight() + y - (hudElements.contains("UserInfo") ? font.getHeight() + 14 : 12.5F) - yChat;
                font.drawString(pType, (float) (scaledWidth - font.stringWidth(pType) - 2), v1, rgbColor, true);
            } else {
                event.getContext().drawText(mc.textRenderer, pType, (int) (scaledWidth - mc.textRenderer.getWidth(pType) - 1),
                        (int) (scaledHeight - mc.textRenderer.fontHeight + y - (hudElements.contains("HotBar") ? 35 :
                                hudElements.contains("UserInfo") ? 23.5F : 13F) - yChat), rgbColor, true);
            }

            counter++;
            j -= 300;
            y -= hudFont.equals("Vanilla") ? mc.textRenderer.fontHeight + 1 : font.getHeight() + 1;
        }
    }

    private void drawCoordinates(@NotNull Render2DEvent event) {
        String xyz = String.format("§rXYZ:§f %.0f %.0f %.0f", mc.player.getX(), mc.player.getBoundingBox().minY, mc.player.getZ());
        ScaledResolution resolution = new ScaledResolution(mc);

        if (hudFont.equalsIgnoreCase("Client")) {
            font.drawString(xyz, (float) 1, (resolution.getScaledHeightStatic(mc) * getScale()) - (hudFont.equals("Vanilla") ? mc.textRenderer.fontHeight + 1 : font.getHeight() * 1.2f), getHUDColor(), true);
        } else {
            event.getContext().drawText(mc.textRenderer, xyz, 2, (int) ((resolution.getScaledHeightStatic(mc) * getScale()) - 10F), getHUDColor(), true);
        }
    }

    private void drawFPS(@NotNull Render2DEvent event) {
        ScaledResolution resolution = new ScaledResolution(mc);
        final float y = (resolution.getScaledHeightStatic(mc) * getScale()) - (hudElements.get().contains("Coords") ? hudElements.get().contains("Speed") ? hudFont.equals("Vanilla") ? mc.textRenderer.fontHeight * 3 + 2 : font.getHeight() * 3.2f + 3 : hudFont.equals("Vanilla") ? mc.textRenderer.fontHeight * 2 + 2 : font.getHeight() * 2.2f + 1 : hudElements.contains("Speed") ? hudFont.equals("Vanilla") ? mc.textRenderer.fontHeight * 2 + 2 : font.getHeight() * 2.2f + 2 : hudFont.equals("Vanilla") ? mc.textRenderer.fontHeight + 2 : font.getHeight() * 1.2f + 1);
        final String fpsFont = RESET + "FPS: " + WHITE + mc
                .getCurrentFps(), fpsVanilla = RESET + "FPS: " + WHITE + mc.getCurrentFps(); // PORT: getDebugFPS

        if (hudFont.equalsIgnoreCase("Client")) {
            font.drawString(fpsFont, (float) 1, y, getHUDColor(), true);
        } else {
            event.getContext().drawText(mc.textRenderer, fpsVanilla, 2, (int) y, getHUDColor(), true);
        }
    }

    private void drawSpeed(@NotNull Render2DEvent event) {
        ScaledResolution resolution = new ScaledResolution(mc);
        final float y = (resolution.getScaledHeightStatic(mc) * getScale()) - (hudElements.get().contains("Coords") ? hudFont.equals("Vanilla") ? mc.textRenderer.fontHeight * 2 + 2 : font.getHeight() * 2.2f + 2 : hudFont.equals("Vanilla") ? mc.textRenderer.fontHeight * 2 + 2 : font.getHeight() * 1.2f + 1);
        // PORT: getLastTickDistance -> distance moved this tick; mc.timer.timerSpeed -> MoveUtils holder
        String speed = String.format("%.2f", getLastTickDistance() * 20 * (MoveUtils.timerSpeed < 1 ? 1 : MoveUtils.timerSpeed));

        if (hudFont.equalsIgnoreCase("Client")) {
            font.drawString("Speed: " + Formatting.WHITE + speed + " b/s", (float) 1, y, getHUDColor(), true);
        } else {
            event.getContext().drawText(mc.textRenderer, "Speed: " + Formatting.WHITE + speed + " b/s", 2, (int) y, getHUDColor(), true);
        }
    }

    // PORT: EntityPlayerSP#getLastTickDistance was a jar patch — horizontal distance moved last tick.
    // Entity#lastX is the teleport anchor, not last tick's pos — use the MoveUtils tracker.
    private double getLastTickDistance() {
        return MoveUtils.getLastTickDistance(mc.player);
    }

    private void drawName(@NotNull Render2DEvent event) {
        long j = Util.getMeasuringTimeMs();
        final String clientName = this.clientName.get();
        String name = !clientName.isEmpty() ? clientName.charAt(0) + clientName.substring(1) : "N" + "ovoline";

        int x = 1;


        if (hudFont.equalsIgnoreCase("Client")) {
            for (int i = 0; i < name.length(); i++) {
                Fonts.SF.SF_20.SF_20.drawString(String.valueOf(name.charAt(i)), x, 4.5F, getArrayDynamic(j, 255), true);
                x += Fonts.SF.SF_20.SF_20.charWidth(name.charAt(i));
                j -= 300;
            }

        } else {
            for (int i = 0; i < name.length(); i++) {
                event.getContext().drawText(mc.textRenderer, String.valueOf(name.charAt(i)), x, (int) 4.5F, getArrayDynamic(j, 255), true);
                x += mc.textRenderer.getWidth(String.valueOf(name.charAt(i))); // PORT: getCharWidth
                j -= 300;
            }
        }
    }

    private void drawTime(@NotNull Render2DEvent event) {
        int x = 3, pos = 1;

        final String clientName_ = this.clientName.get();
        String name = !clientName_.isEmpty() ? clientName_.charAt(0) + clientName_.substring(1) : "N" + "ovoline";

        if (hudFont.equalsIgnoreCase("Client")) {
            for (int i = 0; i < name.length(); i++) {
                pos += Fonts.SF.SF_20.SF_20.charWidth(name.charAt(i));
            }

            if (hudElements.get().contains("Name")) {
                final String clientName = this.clientName.get();
                x = !clientName.isEmpty() ? pos + 2 : 40;
            }
            Fonts.SF.SF_20.SF_20.drawString(GRAY + "(" + WHITE + dateFormat.format(new Date()) + GRAY + ")", (float) x, 4.0F, getHUDColor(), true);
        } else {
            for (int i = 0; i < name.length(); i++) {
                pos += mc.textRenderer.getWidth(String.valueOf(name.charAt(i)));
            }

            if (hudElements.get().contains("Name")) {
                final String clientName = this.clientName.get();
                x = !clientName.isEmpty() ? pos + 2 : 44;
            }
            event.getContext().drawText(mc.textRenderer, GRAY + "(" + WHITE + dateFormat.format(new Date()) + GRAY + ")", x, (int) 4.5F,
                            getHUDColor(), true);
        }
    }


    public void renderTargetsList(@NotNull DrawContext context) {
        int yHeight = 13;
        int x = tlx.get();
        int y = tly.get();
        final List<Entity> targets = getLoadedTargets();
        int width = 0;

        for (Entity target : targets) {
            yHeight += mc.textRenderer.fontHeight + 1;
            int stringWidth = mc.textRenderer.getWidth(target.getName().getString());

            if (stringWidth > width) {
                width = stringWidth;
            }
        }

        width = Math.max(100, width + 25);
        width += width == 100 ? 0 : 30;
        yHeight -= mc.textRenderer.fontHeight + 1;

        if (targets.isEmpty()) {
            yHeight -= 2;
        }

        RenderUtils.drawRect(x, y - 13, x + width, y + yHeight, new Color(29, 29, 29, 255).getRGB());
        RenderUtils.drawRect(x + 1, y, x + width - 1, y + yHeight - 1, new Color(40, 40, 40, 255).getRGB());
        context.drawText(mc.textRenderer, "Your Targets", x + 3, y - 10, 0xffffffff, true);
        int yOffset = y;

        for (Entity target : targets) {
            context.drawText(mc.textRenderer, target.getName().getString(), x + 3, yOffset + 2, new Color(200, 200, 200, 255).getRGB(), true);
            String s = (int) PlayerUtils.lerpDistanceTo(mc.player, target) + "m"; // PORT: getDistanceToEntity
            context.drawText(mc.textRenderer, s, x + width - 1 - mc.textRenderer.getWidth(s) - 1, yOffset + 2, new Color(200, 200, 200, 255).getRGB(), true);
            yOffset += mc.textRenderer.fontHeight + 1;
        }
    }

    public double[] getTargetListWidthAndHeight() {
        final List<Entity> targets = getLoadedTargets();
        int yHeight = 13;
        int width = 0;

        for (Entity target : targets) {
            yHeight += mc.textRenderer.fontHeight + 1;
            int stringWidth = mc.textRenderer.getWidth(target.getName().getString());

            if (stringWidth > width) {
                width = stringWidth;
            }
        }

        width = Math.max(100, width + 25);
        width += width == 100 ? 0 : 30;
        yHeight -= mc.textRenderer.fontHeight + 1;
        return new double[]{width, yHeight};
    }


    private void drawTargetsList(@NotNull Render2DEvent event) {
        if (!(mc.currentScreen instanceof ChatScreen)) {
            renderTargetsList(event.getContext());
        }
    }

    public IntProperty getTlx() {
        return tlx;
    }

    public IntProperty getTly() {
        return tly;
    }

    private List<Entity> getLoadedTargets() {
        final List<String> players = novoline.getPlayerManager().whoHas(TARGET);
        List<Entity> entities = new ObjectArrayList<>(); // PORT: getLoadedEntityList
        for (Entity e : mc.world.getEntities()) {
            if (players.contains(e.getName().getString().toLowerCase())) entities.add(e);
        }
        return entities;
    }

    private int getLongestName() {
        final List<Entity> loadedTargets = getLoadedTargets();
        int lenght = 0;

        for (Entity entity : loadedTargets) {
            if (Fonts.SF.SF_16.SF_16.stringWidth(entity.getName().getString()) > lenght) {
                lenght = Fonts.SF.SF_16.SF_16.stringWidth(entity.getName().getString());
            }
        }

        return lenght + 35;
    }

    private boolean isExhibition() {
        return clientName.get().equalsIgnoreCase("Exhibition");
    }

    public StringProperty getClientName() {
        return clientName;
    }

    public IntProperty getScoreboard() {
        return scoreboard;
    }

    public ListProperty<String> getHudElements() {
        return hudElements;
    }

    public StringProperty getHudFont() {
        return hudFont;
    }

    public StringProperty getSuffixType() {
        return suffixType;
    }

    public IntProperty getBackgroundAlpha() {
        return backgroundAlpha;
    }

    public StringProperty getBackgroundMode() {
        return backgroundMode;
    }

    public BooleanProperty getnSounds() {
        return nSounds;
    }

    public StringProperty getHudMode() {
        return hudMode;
    }

    public Color getColor() {
        float[] hsb = color.getHSB();
        return Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
    }

    public boolean getChatStyle() {
        return false;
    }

    public boolean getScoreBoardStyle() {
        return false;
    }
}
