/*
package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.FloatProperty;
import cc.novoline.modules.move.MoveUtils;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import org.jetbrains.annotations.NotNull;

import static cc.novoline.modules.configurations.property.object.PropertyFactory.booleanTrue;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createFloat;

public final class GameSpeed extends AbstractModule {

    */
/* properties @off *//*

    @Property("timer-speed")
    private final FloatProperty timerSpeed = createFloat(1.0F).minimum(0.3F).maximum(5.0F);
    @Property("lagback")
    private final BooleanProperty lagback = booleanTrue();

    */
/* constructors @on *//*

    public GameSpeed(@NotNull ModuleManager moduleManager) {
        super(moduleManager, EnumModuleType.MISC, "GameSpeed", "Game Speed");
        Manager.put(new Setting("TIMERSPEED", "Timer Speed", SettingType.SLIDER, this, this.timerSpeed, 0.05));
        Manager.put(new Setting("GS_LAGBACK", "Lagback check", SettingType.CHECKBOX, this, lagback));
    }

    */
/* methods *//*

    @Override
    public void onDisable() {
        MoveUtils.timerSpeed = 1;
    }

    */
/* events *//*

    @EventTarget
    public void onPreUpdate(MotionUpdateEvent event) {
        if(event.getState().equals(MotionUpdateEvent.State.PRE)) {
            MoveUtils.timerSpeed = timerSpeed.get();
        }
    }

    @EventTarget
    public void onReceive(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (event.getPacket() instanceof PlayerPositionLookS2CPacket) {
                if (lagback.get()) {
                    checkModule(getClass());
                }
            }
        }
    }

}
*/
