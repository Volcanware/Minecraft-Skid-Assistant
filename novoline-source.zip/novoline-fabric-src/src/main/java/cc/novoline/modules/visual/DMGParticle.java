package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.LivingUpdateEvent;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

public class DMGParticle extends AbstractModule {

    private final HashMap<LivingEntity, Float> healthMap = new HashMap<>();
    /* COW list: onLivingUpdate adds while onRender iterates — ArrayList threw CME. */
    private final List<Particles> particles = new CopyOnWriteArrayList<>();

    public DMGParticle(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "DamageParticles", "Damage Particles", EnumModuleType.VISUALS, "");
    }

    @EventTarget
    public void onLivingUpdate(@NotNull LivingUpdateEvent e) {
        LivingEntity entity = (LivingEntity) e.getEntity();
        if (entity == this.mc.player) return;
        if (!this.healthMap.containsKey(entity)) this.healthMap.put(entity, entity.getHealth());
        float floatValue = this.healthMap.get(entity);
        float health = entity.getHealth();
        if (floatValue != health) {
            boolean heal = health > floatValue;
            boolean crit = entity.timeUntilRegen < 18 || mc.player.getVelocity().y < 0 && !mc.player.isOnGround();
            String color = heal ? "§a" : crit ? "§c" : "§e";
            String text = floatValue - health < 0.0f ? color + roundToPlace((floatValue - health) * -1.0f, 1) : color + roundToPlace(floatValue - health, 1);
            Location location = new Location(entity);
            location.setY(entity.getBoundingBox().minY + (entity.getBoundingBox().maxY - entity.getBoundingBox().minY) / 2.0);
            location.setX(location.getX() - 0.5 + new Random(System.currentTimeMillis()).nextInt(5) * 0.1);
            location.setZ(location.getZ() - 0.5 + new Random(System.currentTimeMillis() + 1).nextInt(5) * 0.1);
            this.particles.add(new Particles(location, text));
            this.healthMap.remove(entity);
            this.healthMap.put(entity, entity.getHealth());
        }
    }

    @EventTarget
    public void onRender(@NotNull Render3DEvent e) {
        // PORT: renderManager.renderPos*/playerView* -> GameRenderer camera; billboard transform on MatrixStack;
        // GL polygon offset / depth mask are gone -> TextLayerType.SEE_THROUGH renders through walls like before.
        MatrixStack matrices = e.getMatrixStack();
        Camera camera = mc.gameRenderer.getCamera();
        Vec3d cameraPos = camera.getCameraPos();
        VertexConsumerProvider vertexConsumers = mc.getBufferBuilders().getEntityVertexConsumers();

        for (Particles p : this.particles) {
            double n = p.location.getX() - cameraPos.getX();
            double n2 = p.location.getY() - cameraPos.getY();
            double n3 = p.location.getZ() - cameraPos.getZ();
            matrices.push();
            matrices.translate((float) n, (float) n2, (float) n3);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
            float textY = mc.options.getPerspective().isFrontView() ? -1.0F : 1.0F;
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch() * textY));
            final double size = 0.03;
            matrices.scale((float) -size, (float) -size, (float) size);
            Matrix4f matrix = matrices.peek().getPositionMatrix();
            mc.textRenderer.draw(p.text, -(mc.textRenderer.getWidth(p.text) / 2.0F),
                    -(mc.textRenderer.fontHeight - 1.0F), 0, true, matrix, vertexConsumers,
                    TextRenderer.TextLayerType.SEE_THROUGH, 0, LightmapTextureManager.MAX_LIGHT_COORDINATE);
            matrices.pop();
        }

        if (vertexConsumers instanceof VertexConsumerProvider.Immediate) {
            ((VertexConsumerProvider.Immediate) vertexConsumers).draw();
        }
    }

    public static double roundToPlace(double p_roundToPlace_0_, int p_roundToPlace_2_) {
        if (p_roundToPlace_2_ < 0) throw new IllegalArgumentException();
        return new BigDecimal(p_roundToPlace_0_).setScale(p_roundToPlace_2_, RoundingMode.HALF_UP).doubleValue();
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent eventUpdate) {
        // PORT: forEach + remove throws ConcurrentModificationException on removal — removeIf is the same intent.
        this.particles.removeIf(update -> {
            ++update.ticks;
            if (update.ticks <= 10) update.location.setY(update.location.getY() + update.ticks * 0.005);
            return update.ticks > 20;
        });
    }

    public static class Particles {
        public int ticks;
        public Location location;
        public String text;

        public Particles(final Location location, final String text) {
            this.location = location;
            this.text = text;
            this.ticks = 0;
        }

    }

    public static class Location {
        private double x;
        private double y;
        private double z;
        private float yaw;
        private float pitch;

        public Location(double x, double y, double z, float yaw, float pitch) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
            this.pitch = pitch;
        }

        public Location(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = 0.0F;
            this.pitch = 0.0F;
        }

        public Location(@NotNull BlockPos pos) {
            this.x = pos.getX();
            this.y = pos.getY();
            this.z = pos.getZ();
            this.yaw = 0.0F;
            this.pitch = 0.0F;
        }

        public Location(int x, int y, int z) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = 0.0F;
            this.pitch = 0.0F;
        }

        public Location(@NotNull LivingEntity entity) {
            this.x = entity.getX();
            this.y = entity.getY();
            this.z = entity.getZ();
            this.yaw = 0.0f;
            this.pitch = 0.0f;
        }

        public Location add(int x, int y, int z) {
            this.x += x;
            this.y += y;
            this.z += z;
            return this;
        }

        public Location add(double x, double y, double z) {
            this.x += x;
            this.y += y;
            this.z += z;
            return this;
        }

        public Location subtract(int x, int y, int z) {
            this.x -= x;
            this.y -= y;
            this.z -= z;
            return this;
        }

        public Location subtract(double x, double y, double z) {
            this.x -= x;
            this.y -= y;
            this.z -= z;
            return this;
        }

        public Block getBlock() {
            return MinecraftClient.getInstance().world.getBlockState(this.toBlockPos()).getBlock();
        }

        public double getX() {
            return this.x;
        }

        public Location setX(double x) {
            this.x = x;
            return this;
        }

        public double getY() {
            return this.y;
        }

        public Location setY(double y) {
            this.y = y;
            return this;
        }

        public double getZ() {
            return this.z;
        }

        public Location setZ(double z) {
            this.z = z;
            return this;
        }

        public float getYaw() {
            return this.yaw;
        }

        public Location setYaw(float yaw) {
            this.yaw = yaw;
            return this;
        }

        public float getPitch() {
            return this.pitch;
        }

        public Location setPitch(float pitch) {
            this.pitch = pitch;
            return this;
        }

        public static Location fromBlockPos(BlockPos blockPos) {
            return new Location(blockPos.getX(), blockPos.getY(), blockPos.getZ());
        }

        public BlockPos toBlockPos() {
            return BlockPos.ofFloored(this.getX(), this.getY(), this.getZ());
        }

        public double distanceTo(@NotNull Location loc) {
            double dx = loc.x - this.x;
            double dz = loc.z - this.z;
            double dy = loc.y - this.y;
            return Math.sqrt(dx * dx + dy * dy + dz * dz);
        }

        public double distanceToY(@NotNull Location loc) {
            double dy = loc.y - this.y;
            return Math.sqrt(dy * dy);
        }
    }

}
