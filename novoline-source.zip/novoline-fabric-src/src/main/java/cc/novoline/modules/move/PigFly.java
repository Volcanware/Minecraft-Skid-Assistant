package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.VehicleMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;

import cc.novoline.mixin.PlayerInteractEntityC2SPacketAccessor;

public class PigFly extends AbstractModule {

    private Entity entity;

    public PigFly(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.MOVEMENT, "PigFly", "Pig Fly");
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.OUTGOING)) {
            if (event.getPacket() instanceof PlayerInteractEntityC2SPacket) {
                PlayerInteractEntityC2SPacket packet = (PlayerInteractEntityC2SPacket) event.getPacket();

                if (isInteract(packet)) {
                    Entity target = entityFromWorld(packet);

                    if (target instanceof PigEntity) {
                        entity = target;
                    }
                }
            }

        } else {

        }
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {

    }

    @EventTarget
    public void onMotion(MotionUpdateEvent event) {
        if (entity != null && event.getState().equals(MotionUpdateEvent.State.PRE)) {
            sendPacketNoEvent(VehicleMoveC2SPacket.fromVehicle(entity));
            event.setOnGround(false);
        }
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {

    }

    private boolean isInteract(PlayerInteractEntityC2SPacket packet) {
        boolean[] interact = {false};
        packet.handle(new PlayerInteractEntityC2SPacket.Handler() {
            @Override
            public void interact(Hand hand) {
                interact[0] = true;
            }

            @Override
            public void interactAt(Hand hand, Vec3d pos) {
            }

            @Override
            public void attack() {
            }
        });
        return interact[0];
    }

    private Entity entityFromWorld(PlayerInteractEntityC2SPacket packet) {
        return mc.world.getEntityById(((PlayerInteractEntityC2SPacketAccessor) packet).novoline$getEntityId());
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
        entity = null;
    }
}
