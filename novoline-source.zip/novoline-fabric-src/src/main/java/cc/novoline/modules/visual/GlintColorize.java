package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.ColorProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.ResourceTexture;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class GlintColorize extends AbstractModule {

    /* In 1.21.11 the enchantment glint is a textured quad with no tint uniform —
       the color comes from the texture itself. Recolor by swapping the two glint
       textures in the TextureManager for tinted copies (covers item + armor glint). */
    private static final Identifier ITEM_GLINT = Identifier.ofVanilla("textures/misc/enchanted_glint_item.png");
    private static final Identifier ARMOR_GLINT = Identifier.ofVanilla("textures/misc/enchanted_glint_armor.png");

    private int offset = 0;
    private final Map<Identifier, NativeImage> originalImages = new HashMap<>();
    private int lastAppliedColor = -1;

    @Property("glint-color")
    private final ColorProperty color = PropertyFactory.createColor(0xFF8A8AFF);
    @Property("rainbow")
    private final BooleanProperty rainbow = PropertyFactory.booleanFalse();

    public GlintColorize(@NotNull ModuleManager novoline) {
        super(novoline, "GlintColorize", "Glint Colorize", Keyboard.KEY_NONE, EnumModuleType.VISUALS);
        Manager.put(new Setting("GLINT_COLOR", "Glint color", SettingType.COLOR_PICKER, this, color, null, () -> !rainbow.get()));
        Manager.put(new Setting("GLINT_RAINBOW", "Rainbow", SettingType.CHECKBOX, this, rainbow));
    }

    @EventTarget
    public void onTick(TickUpdateEvent e) {
        if (rainbow.get()) {
            offset++;
            if (offset > 255) offset = 0;
        } else if (offset != 0) offset = 0;

        int now = glintColor();
        if (now != lastAppliedColor) {
            applyTint(now);
            lastAppliedColor = now;
        }
    }

    @Override
    public void onEnable() {
        captureOriginals();
        lastAppliedColor = -1; // force re-apply next tick
        applyTint(glintColor());
    }

    @Override
    public void onDisable() {
        restoreOriginals();
    }

    private void captureOriginals() {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (Identifier id : new Identifier[]{ITEM_GLINT, ARMOR_GLINT}) {
            if (!originalImages.containsKey(id)) {
                try (InputStream in = mc.getResourceManager().getResource(id).orElseThrow().getInputStream()) {
                    originalImages.put(id, NativeImage.read(in)); // kept open for tinting; closed with the game
                } catch (Exception e) {
                    getLogger().error("GlintColorize: could not read {}", id, e);
                }
            }
        }
    }

    /* registerTexture() closes the replaced texture, so the original texture
       objects we capture are dead (null GL view) after the first tint — they
       can never be restored. Re-register a fresh ResourceTexture instead: the
       ReloadableTexture overload reloads the image from the resource pack. */
    private void restoreOriginals() {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (Identifier id : originalImages.keySet()) {
            try {
                mc.getTextureManager().registerTexture(id, new ResourceTexture(id));
            } catch (Exception ignored) {
            }
        }
        originalImages.clear();
        lastAppliedColor = -1;
    }

    private void applyTint(int tintArgb) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (originalImages.isEmpty()) {
            return;
        }
        originalImages.forEach((id, base) -> {
            try {
                NativeImage tinted = base.applyToCopy(pixel -> tintPixel(pixel, tintArgb));
                mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(() -> "novoline_glint", tinted));
            } catch (Exception e) {
                getLogger().error("GlintColorize: tint failed for {}", id, e);
            }
        });
    }

    private static int tintPixel(int argb, int tintArgb) {
        int a = argb >>> 24;
        int r = (argb >>> 16) & 0xFF;
        int g = (argb >>> 8) & 0xFF;
        int b = argb & 0xFF;
        int tr = (tintArgb >>> 16) & 0xFF;
        int tg = (tintArgb >>> 8) & 0xFF;
        int tb = tintArgb & 0xFF;
        return (a << 24) | ((r * tr / 255) << 16) | ((g * tg / 255) << 8) | (b * tb / 255);
    }

    public int glintColor() {
        float[] colorPicker = this.color.getHSB();
        float hue = rainbow.get() ? offset / 255.0F : colorPicker[0];
        final Color color = Color.getHSBColor(hue, colorPicker[1], colorPicker[2]);
        return color.getRGB();
    }

    public ColorProperty getColor() {
        return color;
    }

    public BooleanProperty getRainbow() {
        return rainbow;
    }

    public int getOffset() {
        return offset;
    }
}
