package cc.novoline.modules.combat;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.DoubleProperty;
import static cc.novoline.utils.PlayerUtils.lerpDistanceTo;
import cc.novoline.utils.RotationUtil;
import cc.novoline.utils.Timer;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static cc.novoline.gui.screen.setting.Manager.put;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.booleanFalse;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createDouble;

public final class AimAssist extends AbstractModule {

    /* fields */
    private static float yaw;
    private static float pitch;
    private static Entity target;
    private static List<Entity> targets = new ObjectArrayList<>(0);

    private final Timer timer = new Timer();
    private final Comparator<Entity> angleComparator = Comparator.comparingDouble(entity -> getRotationsNeeded(entity)[0]);
    private int index;

    /* properties @off */
    @Property("reach")
    private final DoubleProperty reach = createDouble(3.0D).minimum(1.0D).maximum(6.0D);
    @Property("aim-delay")
    private final DoubleProperty aimDelay = createDouble(0.0D).minimum(0.0D).maximum(1000.0D);
    @Property("height")
    private final DoubleProperty height = createDouble(3.5D).minimum(-8.0D).maximum(8.0D);
    @Property("horizontal-left")
    private final DoubleProperty horizontalLeft = createDouble(1.0D).minimum(0.0D).maximum(5.0D);
    @Property("horizontal-right")
    private final DoubleProperty horizontalRight = createDouble(1.0D).minimum(0.0D).maximum(5.0D);
    @Property("vertical-up")
    private final DoubleProperty verticalUp = createDouble(1.0D).minimum(0.0D).maximum(5.0D);
    @Property("vertical-down")
    private final DoubleProperty verticalDown = createDouble(1.0D).minimum(0.0D).maximum(5.0D);
    @Property("only-axe-sword")
    private final BooleanProperty onlyAxeSword = booleanFalse();
    @Property("ray-trace")
    private final BooleanProperty rayTrace = booleanFalse();
    @Property("click-aim")
    private final BooleanProperty clickAim = booleanFalse();

    /* constructors @on */
    public AimAssist(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "AimAssist", "Aim Assist", Keyboard.KEY_NONE, EnumModuleType.COMBAT, "Helps you to aim");
        put(new Setting("REACH", "Reach", SettingType.SLIDER, this, this.reach, 0.1));
        put(new Setting("AIM_DELAY", "Aim Delay", SettingType.SLIDER, this, this.aimDelay, 50));
        put(new Setting("HEIGHT", "Height", SettingType.SLIDER, this, this.height, 1));
        put(new Setting("H_LEFT", "Horizontal Left", SettingType.SLIDER, this, this.horizontalLeft, 0.1));
        put(new Setting("H_RIGHT", "Horizontal Right", SettingType.SLIDER, this, this.horizontalRight, 0.1));
        put(new Setting("V_UP", "Vertical Up", SettingType.SLIDER, this, this.verticalUp, 0.1));
        put(new Setting("V_DOWN", "Vertical Down", SettingType.SLIDER, this, this.verticalDown, 0.1));
        put(new Setting("ONLY_AXESWORD", "Only Sword/Axe", SettingType.CHECKBOX, this, this.onlyAxeSword));
        put(new Setting("RAYTRACE", "Raytrace", SettingType.CHECKBOX, this, this.rayTrace));
        put(new Setting("CLICKAIM", "Click Aim", SettingType.CHECKBOX, this, this.clickAim));
    }


    private List<Entity> loadTargets() {
        return StreamSupport.stream(this.mc.world.getEntities().spliterator(), false)
                .filter(e -> lerpDistanceTo(this.mc.player, e) <= this.reach.get() && this.qualifies(e))
                .sorted(Comparator.comparingDouble(o -> lerpDistanceTo(this.mc.player, ((Entity) o))).reversed())
                .collect(Collectors.toCollection(ObjectArrayList::new));
    }

    private boolean qualifies(Entity entity) {
        return entity != this.mc.player && entity.isAlive() && !this.novoline.getPlayerManager()
                .hasType(entity.getName().getString(), PlayerManager.EnumPlayerType.FRIEND) && entity instanceof PlayerEntity;
    }

    @EventTarget
    private void onPreUpdate(MotionUpdateEvent event) {
        if(event.getState().equals(MotionUpdateEvent.State.PRE)) {
            targets = this.loadTargets();
            targets.sort(this.angleComparator);

            if (target instanceof PlayerEntity || target instanceof HostileEntity || target instanceof AnimalEntity) {
                target = null;
            }

            if (this.mc.player.age % 50 == 0 && targets.size() > 1) ++this.index;
            if (this.clickAim.get() && !Mouse.isButtonDown(0)) return;

            if (!targets.isEmpty()) {
                if (this.index >= targets.size()) this.index = 0;

                target = targets.get(this.index);
                final double[] rotationPosition = getRotationsNeeded(target);

                if (this.timer.delay(this.aimDelay.get())) {
                    pitch = (float) (rotationPosition[1] + this.height.get());
                    yaw = (float) rotationPosition[0];

                    this.timer.reset();
                }

                final boolean notOnlyAxeSword = !this.onlyAxeSword.get();
                final ItemStack held = this.mc.player.getMainHandStack();

                if (this.rayTrace.get()) {
                    if (this.mc.player.canSee(target) && (notOnlyAxeSword || held.isIn(ItemTags.SWORDS) || held.isIn(ItemTags.AXES))) {
                        aim();
                    }
                } else if (notOnlyAxeSword) {
                    aim();
                } else if (held.isIn(ItemTags.SWORDS) || held.isIn(ItemTags.AXES)) {
                    aim();
                }
            }
        }
    }

    private void aim() {
        final ClientPlayerEntity player = this.mc.player;

        final float yaw = player.getYaw(), // @off
                pitch = player.getPitch(); // @on

        if (yaw < AimAssist.yaw) {
            player.setYaw(player.getYaw() + this.horizontalRight.get().floatValue());
        } else if (player.getYaw() > AimAssist.yaw) {
            player.setYaw(player.getYaw() - this.horizontalLeft.get().floatValue());
        }

        if (pitch < AimAssist.pitch) {
            player.setPitch(player.getPitch() + this.verticalDown.get().floatValue());
        } else if (player.getPitch() > AimAssist.pitch) {
            player.setPitch(player.getPitch() - this.verticalUp.get().floatValue());
        }
    }

    public static double[] getRotationsNeeded(Entity entity) {
        if (entity == null) return null;

        final ClientPlayerEntity player = MinecraftClient.getInstance().player;
        final double diffX = entity.getX() - player.getX(), // @off
                diffY = ((LivingEntity) entity).getY() + entity.getStandingEyeHeight() * 0.9 - (player.getY() + player.getStandingEyeHeight()),
                diffZ = entity.getZ() - player.getZ(); // @on

        return RotationUtil.getDistance(diffX, diffZ, diffY);
    }

}
