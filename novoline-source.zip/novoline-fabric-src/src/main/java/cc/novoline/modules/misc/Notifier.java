package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.SpawnCheckEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.IntProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;

public final class Notifier extends AbstractModule {

    @Property("additional_y")
    private IntProperty add_y = PropertyFactory.createInt(10).minimum(10).maximum(90);

    /* constructors */
    public Notifier(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Notifier", EnumModuleType.MISC, "alert you if player in your chunks");
        Manager.put(new Setting("NF_ADD_Y", "Addition Y", SettingType.SLIDER, this, add_y, 5));
    }

    /* methods */
    public boolean isServerBot(Entity entity) {
        // PORT: getFormattedText carried the "§8" colour code inline; modern Text stores colour in
        // Style, so also match a plain "[NPC]" prefix for style-encoded display names
        String displayName = entity.getDisplayName().getString();
        return displayName.contains("§8[NPC]") || displayName.contains("[NPC]");
    }

    /* events */
    @EventTarget
    public void onCheck(SpawnCheckEvent e) {
        if (e.getEntity() instanceof PlayerEntity && e.getEntity().getId() != mc.player.getId() && !isServerBot(e.getEntity())) {
            int x = (int) e.getEntity().getX(), y = (int) e.getEntity().getY(), z = (int) e.getEntity().getZ();
            String tp = mc.isInSingleplayer() ? "/tp " : ".tp ", playerName = e.getEntity().getName().getString().toLowerCase();

            MutableText message = Text.literal("§dNotifier§r§7 » ");
            MutableText textName = Text.literal("§3Name: §r");
            MutableText name = Text.literal(playerName);

            // PORT: ClickEvent/HoverEvent are records in 1.21.11 — ClickEvent.RunCommand dispatches
            // through runClickEventCommand, not sendChatMessage (see hooks)
            name = name.setStyle(name.getStyle().withHoverEvent(new HoverEvent.ShowText(Text.literal(tp + playerName))));
            name = name.setStyle(name.getStyle().withClickEvent(new ClickEvent.RunCommand(tp + playerName)));

            MutableText textCoords = Text.literal(" §3Coords: §r");
            MutableText coords = Text.literal("§bX:§r " + x + " §bY:§r " + y + " §bZ:§r " + z);
            String coordsCommand = tp + x + " " + y + " " + z;

            coords = coords.setStyle(coords.getStyle().withHoverEvent(new HoverEvent.ShowText(Text.literal(coordsCommand))));
            coords = coords.setStyle(coords.getStyle().withClickEvent(new ClickEvent.RunCommand(coordsCommand)));

            message.append(textName).append(name).append(textCoords).append(coords);
            mc.inGameHud.getChatHud().addMessage(message);
        }
    }
}
