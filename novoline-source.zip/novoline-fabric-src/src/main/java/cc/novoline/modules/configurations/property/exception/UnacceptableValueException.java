package cc.novoline.modules.configurations.property.exception;
import org.jetbrains.annotations.NotNull;

import cc.novoline.modules.configurations.property.Property;

/**
 * @author xDelsy
 */
public final class UnacceptableValueException extends PropertyException {

    public UnacceptableValueException(@NotNull Property<?> property) {
        super(property);
    }

    public UnacceptableValueException(String message, @NotNull Property<?> property) {
        super(message, property);
    }

    public UnacceptableValueException(String message, Throwable cause, @NotNull Property<?> property) {
        super(message, cause, property);
    }

    public UnacceptableValueException(Throwable cause, @NotNull Property<?> property) {
        super(cause, property);
    }

}
