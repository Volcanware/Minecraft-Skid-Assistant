package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render2DEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.utils.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.GolemEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.awt.*;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static java.lang.Math.toRadians;
import static net.minecraft.util.math.MathHelper.*;

/**
 * @author Artyom Popov
 * @since October 10, 2020 @ 4:50 PM
 */
public final class Arrows extends AbstractModule {

    @Property("only_invisible")
    private final BooleanProperty onlyInvisibles = PropertyFactory.booleanTrue();
    @Property("radius")
    private final IntProperty radius = PropertyFactory.createInt(150).minimum(55).maximum(165);
    @Property("color")
    private final ColorProperty color = PropertyFactory.createColor(0xFF_00_00_FF);
    @Property("targets")
    private final ListProperty<String> targets = PropertyFactory.createList("Players").acceptableValues("Players", "Animals", "Mobs");
    @Property("filters")
    private final ListProperty<String> filters = PropertyFactory.createList("Teams").acceptableValues("Teams");
    @Property("targets-only")
    private final BooleanProperty targetsOnly = PropertyFactory.booleanFalse();
    @Property("color-type")
    private final StringProperty colorType = PropertyFactory.createString("Static").acceptableValues("Static", "Team", "Rainbow");
    @Property("rainbow-type")
    private final StringProperty rainbowType = PropertyFactory.createString("Static").acceptableValues("Static", "Cycle");
    @Property("alpha-type")
    private final StringProperty alphaType = PropertyFactory.createString("Distance").acceptableValues("Distance", "Pulse", "Static");
    @Property("alpha")
    private final IntProperty alpha = PropertyFactory.createInt(255).minimum(0).maximum(255);

    public Arrows(ModuleManager moduleManager) {
        super(moduleManager, "Arrows", EnumModuleType.VISUALS, "Shows arrows to players");
        Manager.put(new Setting("ARROWS_ONLY_VISIBLES", "Not in FOV only", SettingType.CHECKBOX, this, onlyInvisibles));
        Manager.put(new Setting("ARROWS_TARGETS_ONLY", "Targets Only", SettingType.CHECKBOX, this, targetsOnly));
        Manager.put(new Setting("ARROWS_RADIUS", "Radius", SettingType.SLIDER, this, radius, 1));
        Manager.put(new Setting("ARROWS_TARGETS", "Targets", SettingType.SELECTBOX, this, targets));
        Manager.put(new Setting("ARROWS_FILTER", "Filters", SettingType.SELECTBOX, this, filters, () -> targets.contains("Players")));
        Manager.put(new Setting("ARROWS_COLORTYPE", "Color Type", SettingType.COMBOBOX, this, colorType));
        Manager.put(new Setting("ARROWS_RAINBOWTYPE", "Rainbow Type", SettingType.COMBOBOX, this, rainbowType,
                () -> colorType.get().equalsIgnoreCase("Rainbow")));
        Manager.put(new Setting("ARROWS_COLOR", "Color", SettingType.COLOR_PICKER, this, color, null,
                () -> colorType.get().equalsIgnoreCase("Static")));
        Manager.put(new Setting("ARROWS_ALPHA", "Alpha Type", SettingType.COMBOBOX, this, this.alphaType));
        Manager.put(new Setting("ARROWS_ALPHA_SLIDER", "Alpha", SettingType.SLIDER, this, alpha, 10,
                () -> alphaType.get().equalsIgnoreCase("Static")));

    }

    public static AbstractModule create(ModuleManager moduleManager) {
        return new Arrows(moduleManager);
    }
    //endregion

    private static final int HALF_PI_DEGREES_INT = 90;
    private static final float TWO_PI_DEGREES_FLOAT = 360.0F;
    private static final float RGB_MAX_FLOAT = 255.0F;
    private static double WIDTH = 0.03D;
    private static double HEIGHT = 5;
    private int alph = 1;
    private boolean invert;

    protected final Vec3d getVectorForRotation(float pitch, float yaw) {
        float f = MathHelper.cos((float) (Math.toRadians(-yaw) - (float) Math.PI));
        float f1 = MathHelper.sin((float) (Math.toRadians(-yaw) - (float) Math.PI));
        float f2 = -MathHelper.cos((float) Math.toRadians(-pitch));
        float f3 = MathHelper.sin((float) Math.toRadians(-pitch));
        return new Vec3d(f1 * f2, f3, f * f2);
    }

    @EventTarget
    public void onRender(Render2DEvent event) {
        //region не вносить под for -> хуже перфоманс
        MinecraftClient minecraft = mc;
        ClientPlayerEntity player = minecraft.player;
        float playerYaw = player.getYaw();
        WIDTH = 0.03D * (135D / radius.get().doubleValue());

        // PORT: the ported Render2DEvent carries the DrawContext instead of the
        // resolution; the patched ScaledResolution is rebuilt here.
        ScaledResolution resolution = new ScaledResolution(mc);
        double width = resolution.getScaledWidthStatic(mc);
        double height = resolution.getScaledHeightStatic(mc);
        double centerX = width / 2.0D;
        double centerY = height / 2.0D;


        boolean onlyInvisibles = this.onlyInvisibles.get();
        int radius = this.radius.get();
        ColorProperty color = this.color;

        //endregion

        int counter = 1;

        DrawContext context = event.getContext();
        // PORT: ScaleUtils.scale(mc) replacement — the Novoline "static" screen
        // size differs from the effective scaled size, so geometry is drawn in
        // static units under a matrix scale (same factor ScaleUtils applied).
        float scaleX = (float) (resolution.getScaledWidth_double() / width);
        float scaleY = (float) (resolution.getScaledHeight_double() / height);

        for (Entity entity : StreamSupport.stream(minecraft.world.getEntities().spliterator(), false).sorted(Comparator.comparingDouble(entity ->
                toRadians(((
                        RotationUtil.getYawToPoint(
                                entity.getX(), entity.getZ()) +
                                TWO_PI_DEGREES_FLOAT) %
                        TWO_PI_DEGREES_FLOAT - playerYaw +
                        TWO_PI_DEGREES_FLOAT) %
                        TWO_PI_DEGREES_FLOAT -
                        HALF_PI_DEGREES_INT)
        )).collect(Collectors.toList())) {
            if (!isValidTarget(entity)) continue;
            if (RenderUtils.isInViewFrustrum(entity) && onlyInvisibles) continue;
            if (targetsOnly.get() && !novoline.getPlayerManager().hasType(entity.getName().getString(), PlayerManager.EnumPlayerType.TARGET))
                continue;

            double distEntity2Player = entity.distanceTo(player);

            RenderUtils.start2D();
            context.getMatrices().pushMatrix();
            context.getMatrices().scale(scaleX, scaleY);

            float alpha = 0;
            switch (alphaType.get()) {
                case "Static":
                    alpha = this.alpha.get() / RGB_MAX_FLOAT;
                    break;
                case "Distance":
                    alpha = 1.0F - clamp(color.getAlpha() / RGB_MAX_FLOAT * (float) distEntity2Player * 3.0F, 0, 255) / RGB_MAX_FLOAT;
                    break;
                case "Pulse":
                    alpha = alph / RGB_MAX_FLOAT;
            }

            Color temp = new Color(102, 201, 255, 255);

            switch (colorType.get()) {
                case "Static":
                    temp = color.getAwtColor();
                    break;
                case "Rainbow":
                    temp = new Color(getArrayRainbow(rainbowType.get().equalsIgnoreCase("Static") ? 1 : counter, 255));
                    break;
                case "Team":
                    if (PlayerUtils.inTeam(mc.player, entity)) {
                        temp = new Color(0, 231, 255, 255);
                    } else if (novoline.getPlayerManager().hasType(entity.getName().getString(), PlayerManager.EnumPlayerType.FRIEND)) {
                        temp = new Color(169, 255, 43, 255);
                    } else if (novoline.getPlayerManager().hasType(entity.getName().getString(), PlayerManager.EnumPlayerType.TARGET)) {
                        temp = new Color(255, 59, 5, 255);
                    } else {
                        temp = new Color(255, 255, 255, 255);
                    }
            }

            int argb = temp.getRGB() & 0xFFFFFF | (int) (alpha * RGB_MAX_FLOAT) << 24;

            float yawToEntity = (RotationUtil.getYawToPoint(entity.lastX + (entity.getX() - entity.lastX) * mc.getRenderTickCounter().getTickProgress(true), entity.lastZ + (entity.getZ() - entity.lastZ) * mc.getRenderTickCounter().getTickProgress(true)) + TWO_PI_DEGREES_FLOAT) % TWO_PI_DEGREES_FLOAT;
            float yawDiff = (yawToEntity - playerYaw + TWO_PI_DEGREES_FLOAT) % TWO_PI_DEGREES_FLOAT - HALF_PI_DEGREES_INT;
            double yawDiffRad = toRadians(yawDiff);

            // PORT: GL_TRIANGLE_STRIP fan (tip + two base verts + tip) -> same vertex
            // stream emitted as one quad on the GUI quads pipeline.
            float tipX = (float) (centerX + cos((float) yawDiffRad) * radius), tipY = (float) (centerY + sin((float) yawDiffRad) * radius);
            float baseX1 = (float) (centerX + cos((float) (yawDiffRad + WIDTH)) * (radius - HEIGHT)), baseY1 = (float) (centerY + sin((float) (yawDiffRad + WIDTH)) * (radius - HEIGHT));
            float baseX2 = (float) (centerX + cos((float) (yawDiffRad - WIDTH)) * (radius - HEIGHT)), baseY2 = (float) (centerY + sin((float) (yawDiffRad - WIDTH)) * (radius - HEIGHT));
            RenderUtils.guiShape(new float[]{tipX, tipY, baseX1, baseY1, baseX2, baseY2, tipX, tipY},
                    new int[]{argb, argb, argb, argb}, 0, 0, (int) width, (int) height, RenderPipelines.GUI);

            context.getMatrices().popMatrix();
            RenderUtils.stop2D();
            counter++;
        }

        if (!invert && alph < 255) {
            alph++;
        } else {
            invert = true;
        }
        if (invert && alph > 0) {
            alph--;
        } else {
            invert = false;
        }

    }

    //region TODO: переписать чеки на валидность таргета
    @SuppressWarnings({"ChainOfInstanceofChecks", "InstanceofConcreteClass", "MethodWithMultipleReturnPoints", "OverlyComplexMethod"})
    public boolean isValidTarget(Entity target) {
        ListProperty<String> targets = this.targets;
        boolean invisibleTarget = targets.contains("Invisibles");
        ClientPlayerEntity player = mc.player;

        if (target.isAlive() && player.getHealth() > 0.0F && !novoline.getPlayerManager().hasType(target.getName().getString(), PlayerManager.EnumPlayerType.FRIEND)) {
            if (target instanceof HostileEntity || target instanceof SlimeEntity || target instanceof GolemEntity) {
                return targets.contains("Mobs")
                        && !(target.isInvisible() && !invisibleTarget);
            }

            if (target instanceof AnimalEntity || target instanceof VillagerEntity) {
                return targets.contains("Animals")
                        && !(target.isInvisible() && !invisibleTarget);
            }

            if (target instanceof PlayerEntity) {
                ListProperty<String> filters = this.filters;

                return targets.contains("Players")
                        && target != player
                        && (!filters.contains("Teams") || !PlayerUtils.inTeam(player, target))
                        && !(target.isInvisible() && !invisibleTarget)
                        && !isAutismShopKeeperCheck(target);
            }
        }

        return false;
    }

    private static boolean hasArmor(PlayerEntity e) {
        ItemStack boots = e.getEquippedStack(EquipmentSlot.FEET);
        ItemStack leggings = e.getEquippedStack(EquipmentSlot.LEGS);
        ItemStack chestplate = e.getEquippedStack(EquipmentSlot.CHEST);
        ItemStack helmet = e.getEquippedStack(EquipmentSlot.HEAD);
        return !boots.isEmpty() || !leggings.isEmpty() || !chestplate.isEmpty() || !helmet.isEmpty();
    }

    private boolean isAutismShopKeeperCheck(Entity target) {
        Text component = target.getDisplayName();

        // PORT: IChatComponent#getFormattedText() has no equivalent — the
        // closest is walking the styled contents and re-emitting legacy
        // formatting codes for named text colors.
        String formatted = getFormattedText(component);
        String unFormatted = component.getString();

        boolean first = !formatted.substring(0, formatted.length() - 2).contains("\u00A7");
        boolean second = formatted.substring(formatted.length() - 2).contains("\u00A7");

        return ServerUtils.isHypixel() && ServerUtils.serverIs(Servers.BW) && first && second;
    }

    private static String getFormattedText(Text component) {
        StringBuilder builder = new StringBuilder();
        component.visit((style, string) -> {
            TextColor color = style.getColor();
            if (color != null) {
                Formatting formatting = Formatting.byName(color.getName());
                if (formatting != null) builder.append(formatting);
            }
            builder.append(string);
            return Optional.empty();
        }, Style.EMPTY);
        return builder.toString();
    }

    public int getArrayRainbow(int counter, int alpha) {
        final int width = 50;

        double rainbowState = Math.ceil(System.currentTimeMillis() - (long) counter * width) / 10;
        rainbowState %= 360;

        final float[] colors = color.getHSB();
        Color color = Color.getHSBColor((float) (rainbowState / 360), colors[1], colors[2]);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
    }

    //endregion
}
