package cc.novoline.modules.visual;

import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.EventTarget;
import cc.novoline.events.events.*;
import cc.novoline.gui.screen.click.DiscordGUI;
import cc.novoline.gui.screen.dropdown.DropdownGUI;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.combat.KillAura;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.DoubleProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.configurations.property.object.StringProperty;
import cc.novoline.modules.exploits.Blink;
import cc.novoline.modules.exploits.Teleport;
import cc.novoline.modules.move.MoveUtils;
import cc.novoline.modules.player.BedBreaker;
import cc.novoline.modules.player.ChestStealer;
import cc.novoline.modules.player.InvManager;
import cc.novoline.utils.Channels;
import cc.novoline.utils.ScaledResolution;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import cc.novoline.utils.Timer;
import cc.novoline.utils.notifications.NotificationType;
import cc.novoline.utils.pathfinding.AStarCustomPathfinder;
import cc.novoline.utils.pathfinding.Vec3;
import cc.novoline.utils.tasks.FutureTask;
import net.minecraft.block.AbstractSignBlock;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PlantBlock;
import net.minecraft.block.VineBlock;
import net.minecraft.block.enums.BedPart;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.WritableBookItem;
import net.minecraft.network.packet.c2s.handshake.HandshakeC2SPacket;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Optional;

import static cc.novoline.utils.notifications.NotificationType.WARNING;

public final class ClickGUI extends AbstractModule {

    /* fields */
    private boolean setLanguage, wasPre, mwPort, hubbed, notify;
    private Timer swapLobbyStopwatch = new Timer();
    private int ticks, startingIn;
    private Servers currentServer = Servers.NONE;
    private Channels channel = Channels.ALL;
    private int[] coords = new int[]{};

    /* properties @off */
    @Property("design")
    public final StringProperty design = PropertyFactory.createString("Dropdown").acceptableValues("Material", "Legacy", "Dropdown");
    @Property("blur")
    private final BooleanProperty blur = PropertyFactory.booleanFalse();
    @Property("close_previous")
    private final BooleanProperty closePrevious = PropertyFactory.booleanFalse();


    /* constructors @on */
    public ClickGUI(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "ClickGUI", "Click Gui", Keyboard.KEY_RSHIFT, EnumModuleType.VISUALS, "");
        Manager.put(new Setting("CGUI_DESIGN", "Design", SettingType.COMBOBOX, this, design));
        Manager.put(new Setting("BLUR", "Blur", SettingType.CHECKBOX, this, blur));
        Manager.put(new Setting("BLUR", "Close Previous", SettingType.CHECKBOX, this, closePrevious));
    }

    /* methods */
    @Override
    public void onEnable() {
        if (design.get().equalsIgnoreCase("Dropdown")) {
            mc.setScreen(novoline.getDropDownGUI());
        } else {
            mc.setScreen(novoline.getDiscordGUI());
        }

        toggle();
    }

    @Override
    public void onDisable() {
        EventManager.register(this);
    }

    public int getGUIColor() {
        return getModule(HUD.class).getColor().getRGB();
    }

    @EventTarget
    public void onBind(@NotNull BindEvent event) {
        mc.player.networkHandler.sendChatMessage(".bind " + event.getModule().getName() + " " + event.getKeyName());
    }

    @EventTarget
    public void onConnection(@NotNull PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.OUTGOING)) {
            if (event.getPacket() instanceof HandshakeC2SPacket) { // PORT: C00Handshake
                notify = !mc.isInSingleplayer() && mc.getCurrentServerEntry() != null
                        && mc.getCurrentServerEntry().address.toLowerCase().contains("hypixel");
            }

            if (notify) {
                if (event.getPacket() instanceof PlayerMoveC2SPacket) { // PORT: C03PacketPlayer
                    if (ServerUtils.isHypixel()) {
                        setLanguage = true;
                        novoline.getNotificationManager().pop("Novoline", "Hypixel bypasses enabled!", NotificationType.INFO);
                    } else {
                        novoline.getNotificationManager().pop("Novoline", "Hypixel bypasses disabled! Contact staff", 6_000, NotificationType.ERROR);
                    }

                    notify = false;
                }
            }
        }
    }

    @EventTarget
    public void onTick(TickUpdateEvent tick) {
        if (mc.world == null) {
            for (Class mClass : new Class[]{KillAura.class, ChestStealer.class, InvManager.class, Blink.class}) {
                if (getModule(mClass).isEnabled()) {
                    getModule(mClass).toggle();
                }
            }

            if (MoveUtils.timerSpeed != 1) { // PORT: mc.timer.timerSpeed holder lives on MoveUtils
                MoveUtils.timerSpeed = 1;
            }

            if (mc.getNetworkHandler() != null && !mc.getNetworkHandler().getSeenPlayers().isEmpty()) { // PORT: playerInfoMap -> seenPlayers
                mc.getNetworkHandler().getSeenPlayers().clear();
            }

        } else {
            if (setLanguage && ServerUtils.isHypixel() && ServerUtils.serverIs(Servers.LOBBY)) {
                sendPacketNoEvent(new CommandExecutionC2SPacket("language english")); // PORT: "/language english" is a command in 1.21
                setLanguage = false;
            }
        }
    }

    @EventTarget
    public void onSpawn(@NotNull SpawnCheckEvent event) {
        if (event.getEntity() instanceof PlayerEntity && novoline.getPlayerManager().hasType(event.getEntity().getName().getString(), PlayerManager.EnumPlayerType.TARGET)) {
            novoline.getNotificationManager().pop("target detected: " + event.getEntity().getName().getString(), 3000, NotificationType.WARNING);
        }
    }

    @EventTarget
    public void onSetting(@NotNull SettingEvent setting) {
        if (setting.getSettingName().equals("RANGE") || setting.getSettingName().equals("BLOCK_RANGE") || setting.getSettingName().equals("WALL_RANGE")) {
            DoubleProperty range = getModule(KillAura.class).getRange();
            DoubleProperty wallRange = getModule(KillAura.class).getWallRange();

            if (wallRange.get() > range.get()) {
                wallRange.set(range.get());
            }
        }

        switch (setting.getSettingName()) {
            case "TPMODE":
                if (getModule(Teleport.class).isEnabled()) {
                    getModule(Teleport.class).toggle();
                }

                break;

            case "BLOCK_RANGE":
            case "RANGE":
                DoubleProperty range = getModule(KillAura.class).getRange();
                DoubleProperty blockRange = getModule(KillAura.class).getBlockRange();

                if (blockRange.get() < range.get()) {
                    range.set(blockRange.get());
                } else if (range.get() > blockRange.get()) {
                    blockRange.set(range.get());
                }

                break;

            case "CGUI_DESIGN":
                if (design.equalsIgnoreCase("Dropdown")) {
                    if (mc.currentScreen instanceof DiscordGUI) {
                        mc.player.closeScreen();
                    }

                    if (mc.currentScreen == null) {
                        mc.setScreen(Novoline.getInstance().getDropDownGUI());
                    }
                }

                if (design.equalsIgnoreCase("Material") || design.equalsIgnoreCase("Legacy")) {
                    if (mc.currentScreen instanceof DropdownGUI) {
                        mc.player.closeScreen();
                    }

                    if (mc.currentScreen == null) {
                        mc.setScreen(Novoline.getInstance().getDiscordGUI());
                    }
                }

                break;

            case "TH_X": {
                KillAura killAura = getModule(KillAura.class);
                final ScaledResolution sr = new ScaledResolution(mc);

                if (killAura.getThx().get() > sr.getScaledWidth() - 50) {
                    killAura.getThx().set(sr.getScaledWidth() - 50);
                }

                break;
            }

            case "TH_Y": {
                KillAura killAura = getModule(KillAura.class);
                final ScaledResolution sr = new ScaledResolution(mc);

                if (killAura.getThy().get() > sr.getScaledHeight() - 50) {
                    killAura.getThy().set(sr.getScaledHeight() - 50);
                }

                break;
            }

            case "FLIGHT_HYPIXEL_MODE": {
                if (setting.getStringProperty().equals("Normal")) {
                    Novoline.getInstance().getNotificationManager().pop("Unsafe fly mode!", "Please consider using safe mode to avoid setting off staff alerts!", 10000, WARNING);
                }

                break;
            }

            case "KA_FILTER": {
                if (setting.getListProperty().contains("Teams") && getModule(KillAura.class).getTarget() != null) {
                    getModule(KillAura.class).setTarget(null);
                }

                break;
            }

            case "FLIGHT_SW_BOOST": {
                if (setting.getSettingType() == SettingType.CHECKBOX && setting.getBooleanProperty().get()) {
                    novoline.getNotificationManager().pop(setting.getModule().getDisplayName(), "You need bow and arrows in order to use " + setting.getDisplayName(), 3_000, NotificationType.INFO);
                }

                break;
            }
        }
    }

    @EventTarget
    public void onReceive(@NotNull PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (event.getPacket() instanceof CloseScreenS2CPacket) { // PORT: S2EPacketCloseWindow
                if (mc.currentScreen instanceof DiscordGUI || mc.currentScreen instanceof ChatScreen || mc.currentScreen instanceof DropdownGUI) {
                    event.setCancelled(true);
                }
            }

            if (event.getPacket() instanceof DisconnectS2CPacket && !novoline.getTaskManager().getFutureTasks().isEmpty()) { // PORT: S00PacketDisconnect
                novoline.getTaskManager().getFutureTasks().clear();
            }

            if (ServerUtils.isHypixel() && event.getPacket() instanceof ScoreboardDisplayS2CPacket) { // PORT: S3DPacketDisplayScoreboard
                ScoreboardDisplayS2CPacket packet = (ScoreboardDisplayS2CPacket) event.getPacket();
                String serverName = packet.getName();

                if (serverName.equalsIgnoreCase("Mw")) {
                    currentServer = Servers.MW;
                } else if (serverName.equalsIgnoreCase("§e§lHYPIXEL")) {
                    currentServer = Servers.UHC;
                } else if (serverName.equalsIgnoreCase("SForeboard")) {
                    currentServer = Servers.SW;
                } else if (serverName.equalsIgnoreCase("BForeboard")) {
                    currentServer = Servers.BW;
                } else if (serverName.equalsIgnoreCase("PreScoreboard")) {
                    currentServer = Servers.PRE;
                } else if (serverName.equalsIgnoreCase("Duels")) {
                    currentServer = Servers.DUELS;
                } else if (serverName.equalsIgnoreCase("Pit")) {
                    currentServer = Servers.PIT;
                } else if (serverName.equalsIgnoreCase("Blitz SG")) {
                    currentServer = Servers.SG;
                } else if (serverName.equalsIgnoreCase("MurderMystery")) {
                    currentServer = Servers.MM;
                } else if (!serverName.contains("health") && !serverName.contains("✫")) {
                    currentServer = Servers.NONE;
                }
            }
        }
    }

    @EventTarget
    public void inGameTime(TickUpdateEvent event) {
        if (ServerUtils.isHypixel() && !ServerUtils.serverIs(Servers.PRE) && !ServerUtils.serverIs(Servers.LOBBY) && !ServerUtils.serverIs(Servers.NONE)) {
            ticks++;

        } else if (ticks > 0) {
            ticks = 0;
        }
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mwPort) {
            sendPacketNoEvent(new CommandExecutionC2SPacket("hub")); // PORT: "/hub" is a command in 1.21
            hubbed = true;
            mwPort = false;
        }
        if (ServerUtils.serverIs(Servers.PRE)) {
            wasPre = true;
        } else if (wasPre && ServerUtils.serverIs(Servers.BW)) {
            novoline.getNotificationManager().pop("Bedwars", "Using fly may result in a ban, wait", 15000, WARNING);
            getModule(BedBreaker.class).setWhiteListed(null);

            Novoline.getInstance().getTaskManager().queue(new FutureTask(500) {
                @Override
                public void execute() {
                    for (int x = -20; x < 21; x++) {
                        for (int z = -20; z < 21; z++) {
                            for (int y = -10; y < 12; y++) {
                                BlockPos pos = BlockPos.ofFloored(mc.player.getX() - x, mc.player.getY() + y, mc.player.getZ() - z);
                                BlockState state = mc.world.getBlockState(pos);
                                if (state.getBlock() instanceof BedBlock && state.get(BedBlock.PART) == BedPart.HEAD) { // PORT: Blocks.bed covers all 16 colors now
                                    getModule(BedBreaker.class).setWhiteListed(pos);
                                    novoline.getNotificationManager().pop("Whitelisted your own bed!", "Whitelisted bed at " + pos.toString(), 3000, NotificationType.INFO);
                                }
                            }
                        }
                    }
                }

                @Override
                public void run() {

                }
            });

            wasPre = false;
        }

        for (int i = 0; i < 9; i++) {
            if (!mc.player.getInventory().getStack(i).isEmpty()) {
                if (mc.player.getInventory().getStack(i).getCount() == 0) {
                    mc.player.getInventory().removeStack(i);
                }
            }
        }
    }

    @EventTarget
    public void onAutoDisable(@NotNull PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.OUTGOING)) {
            if (ServerUtils.isHypixel()) {
                if (event.getPacket() instanceof ChatMessageC2SPacket) { // PORT: C01PacketChatMessage
                    ChatMessageC2SPacket packet = (ChatMessageC2SPacket) event.getPacket();

                    if (packet.chatMessage().startsWith("/language")) {
                        event.setCancelled(true);
                    }
                }

                // PORT: command packets carry the slash command without the "/"
                if (event.getPacket() instanceof CommandExecutionC2SPacket
                        && ((CommandExecutionC2SPacket) event.getPacket()).command().startsWith("language")) {
                    event.setCancelled(true);
                }

                // PORT: ViaVersion is not ported — the original checked ViaFabric.clientSideVersion == novoline.viaVersion()
                if (ServerUtils.isHypixel()) {
                    if (event.getPacket() instanceof PlayerInteractBlockC2SPacket) { // PORT: C08PacketPlayerBlockPlacement carries no stack — the used item is the held stack
                        PlayerInteractBlockC2SPacket packet = (PlayerInteractBlockC2SPacket) event.getPacket();
                        ItemStack stack = mc.player.getStackInHand(packet.getHand());

                        if (!stack.isEmpty() && isSkull(stack) && stack.getCount() == 1) {
                            sendPacketNoEvent(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch())); // PORT: use-item packet replaces C08(stack)
                            mc.interactionManager.clickSlot(0, 36 + mc.player.getInventory().getSelectedSlot(), 2, SlotActionType.CLONE, mc.player);
                            event.setCancelled(true);
                        }
                    }
                }
            }

        } else {
            if (ServerUtils.isHypixel()) {
                if (event.getPacket() instanceof GameMessageS2CPacket) { // PORT: S02PacketChat
                    GameMessageS2CPacket packet = (GameMessageS2CPacket) event.getPacket();
                    String formattedText = formattedText(packet.content());

                    if (formattedText.equals("§r§aSelected language: §r§eEnglish§r")) {
                        event.setCancelled(true);
                    } else if (formattedText.startsWith("§aOpened a chat conversation with")) {
                        channel = Channels.PM;
                        novoline.getNotificationManager().pop("Hypixel", "You are now in the " + channelName() + " channel", 3_000, NotificationType.INFO);
                        event.setCancelled(true);
                    } else if (formattedText.equals("§aYou are now in the §r§6ALL§r§a channel§r")) {
                        channel = Channels.ALL;
                        novoline.getNotificationManager().pop("Hypixel", "You are now in the " + channelName() + " channel", 3_000, NotificationType.INFO);
                        event.setCancelled(true);
                    } else if (formattedText.equals("§aYou are now in the §r§6PARTY§r§a channel§r")) {
                        channel = Channels.PARTY;
                        novoline.getNotificationManager().pop("Hypixel", "You are now in the " + channelName() + " channel", 3_000, NotificationType.INFO);
                        event.setCancelled(true);
                    } else if (formattedText.equals("§aYou are now in the §r§6GUILD§r§a channel§r")) {
                        channel = Channels.GUILD;
                        novoline.getNotificationManager().pop("Hypixel", "You are now in the " + channelName() + " channel", 3_000, NotificationType.INFO);
                        event.setCancelled(true);
                    } else if (!channel.equals(Channels.GUILD) && formattedText.startsWith("§r§2Guild")) {
                        channel = Channels.GUILD;
                        novoline.getNotificationManager().pop("Hypixel", "You are now in the " + channelName() + " channel", 3_000, NotificationType.INFO);
                    } else if (!channel.equals(Channels.PARTY) && formattedText.startsWith("§r§9Party")) {
                        channel = Channels.PARTY;
                        novoline.getNotificationManager().pop("Hypixel", "You are now in the " + channelName() + " channel", 3_000, NotificationType.INFO);
                    } else if (!channel.equals(Channels.PM) && formattedText.startsWith("§dTo")) {
                        channel = Channels.PM;
                        novoline.getNotificationManager().pop("Hypixel", "You are now in the " + channelName() + " channel", 3_000, NotificationType.INFO);
                    } else if (channel.equals(Channels.PARTY) && formattedText.contains(mc.player.getName().getString()) && formattedText.endsWith("§r§ehas disbanded the party!§r")) {
                        sendPacketNoEvent(new CommandExecutionC2SPacket("chat all")); // PORT: "/chat all" is a command
                    } else if (!channel.equals(Channels.ALL) && formattedText.equals("§cThe conversation you were in expired and you have been moved back to the ALL channel.§r")) {
                        channel = Channels.ALL;
                        novoline.getNotificationManager().pop("Hypixel", "You are now in the " + channelName() + " channel", 3_000, NotificationType.INFO);
                    }
                }

                if (event.getPacket() instanceof OpenScreenS2CPacket) { // PORT: S2DPacketOpenWindow
                    OpenScreenS2CPacket packet = (OpenScreenS2CPacket) event.getPacket();
                    String title = formattedText(packet.getName());

                    if (title.contains("Select Language")) {
                        mc.interactionManager.clickSlot(packet.getSyncId(), 49, 0, SlotActionType.PICKUP, mc.player);
                        event.setCancelled(true);
                    }
                }

                if (event.getPacket() instanceof TitleS2CPacket) { // PORT: S45PacketTitle — only the TITLE subtype exists now
                    final TitleS2CPacket packet = (TitleS2CPacket) event.getPacket();
                    final String text = packet.text().getString();

                    if (text.equals("VICTORY!") || text.equals("GAME OVER!")) {
                        if (isEnabled(KillAura.class) && getModule(KillAura.class).getAutoDisable().contains("Game End")) {
                            Novoline.getInstance().getNotificationManager().pop(getModule(KillAura.class).getName() + " was disabled, because game has ended", 1_500, WARNING);
                            getModule(KillAura.class).toggle();
                        }

                        if (isEnabled(InvManager.class) && getModule(InvManager.class).getAutoDisable().contains("Game End")) {
                            Novoline.getInstance().getNotificationManager().pop(getModule(InvManager.class).getName() +
                                    " was disabled, because game has ended", 1_500, WARNING);
                            getModule(InvManager.class).toggle();
                        }

                        if (isEnabled(ChestStealer.class) && getModule(ChestStealer.class).getAutoDisable().contains("Game End")) {
                            Novoline.getInstance().getNotificationManager().pop(getModule(ChestStealer.class).getName() +
                                    " was disabled, because game has ended", 1_500, WARNING);
                            getModule(ChestStealer.class).toggle();
                        }
                    }
                }

                if (event.getPacket() instanceof ScreenHandlerSlotUpdateS2CPacket) { // PORT: S2FPacketSetSlot
                    ScreenHandlerSlotUpdateS2CPacket packet = (ScreenHandlerSlotUpdateS2CPacket) event.getPacket();

                    if (formattedText(packet.getStack().getName()).contains("§") && packet.getStack().getName().getString().contains("Spectator")) {
                        if (isEnabled(KillAura.class) && getModule(KillAura.class).getAutoDisable().contains("Death")) {
                            Novoline.getInstance().getNotificationManager().pop(getModule(KillAura.class).getName() +
                                    " was disabled, because of player death", 1_500, WARNING);
                            getModule(KillAura.class).toggle();
                        }

                        if (isEnabled(InvManager.class) && getModule(InvManager.class).getAutoDisable().contains("Death")) {
                            Novoline.getInstance().getNotificationManager().pop(getModule(InvManager.class).getName() +
                                    " was disabled, because of player death", 1_500, WARNING);
                            getModule(InvManager.class).toggle();
                        }

                        if (isEnabled(ChestStealer.class) && getModule(ChestStealer.class).getAutoDisable().contains("Death")) {
                            Novoline.getInstance().getNotificationManager().pop(getModule(ChestStealer.class).getName() +
                                    " was disabled, because of player death", 1_500, WARNING);
                            getModule(ChestStealer.class).toggle();
                        }
                    }

                    if (ServerUtils.serverIs(Servers.LOBBY)) {
                        if (packet.getStack().getItem() instanceof WritableBookItem) { // PORT: ItemEditableBook
                            event.setCancelled(true);
                        }
                    }
                }
            }
        }
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {

        if (getModule(KillAura.class).isEnabled() && getModule(KillAura.class).getAutoDisable().contains("World Change")) {
            novoline.getNotificationManager().pop(getModule(KillAura.class).getName() + " was disabled, because world changed", 1_500, WARNING);
            getModule(KillAura.class).toggle();
        }

        if (getModule(InvManager.class).isEnabled() && getModule(InvManager.class).getAutoDisable().contains("World Change")) {
            novoline.getNotificationManager().pop(getModule(InvManager.class).getName() + " was disabled, because world changed", 1_500, WARNING);
            getModule(InvManager.class).toggle();
        }

        if (getModule(ChestStealer.class).isEnabled() && getModule(ChestStealer.class).getAutoDisable().contains("World Change")) {
            novoline.getNotificationManager().pop(getModule(ChestStealer.class).getName() + " was disabled, because world changed", 1_500, WARNING);
            getModule(ChestStealer.class).toggle();
        }

        if (ServerUtils.isHypixel() && mc.getNetworkHandler() != null && !mc.getNetworkHandler().getSeenPlayers().isEmpty()) { // PORT: playerInfoMap -> seenPlayers
            mc.getNetworkHandler().getSeenPlayers().clear();
        }

        if (!getModule(ChestStealer.class).getChestIds().isEmpty()) {
            getModule(ChestStealer.class).getChestIds().clear();
        }

        if (mc.isInSingleplayer() && !currentServer.equals(Servers.NONE)) {
            currentServer = Servers.NONE;
        }

        if (hubbed) {
            sendPacketNoEvent(new CommandExecutionC2SPacket("back")); // PORT: "/back" is a command
            hubbed = false;
            novoline.getTaskManager().queue(new FutureTask(2000) {
                @Override
                public void execute() {
                    ArrayList<cc.novoline.utils.pathfinding.Vec3> vec3s = computePath(new cc.novoline.utils.pathfinding.Vec3(mc.player.getX(), mc.player.getY(), mc.player.getZ()), new cc.novoline.utils.pathfinding.Vec3(coords[0], coords[1], coords[2]));

                    for (cc.novoline.utils.pathfinding.Vec3 vec3 : vec3s) {
                        sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(vec3.mc(), false, mc.player.horizontalCollision)); // PORT: C04PacketPlayerPosition
                    }
                    sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(new Vec3d(coords[0], coords[1], coords[2]), false, mc.player.horizontalCollision));
                    mc.player.setPosition(coords[0], coords[1], coords[2]);
                    novoline.getNotificationManager().pop("Done", "Teleporting to " + coords[0] + "/" + coords[1] + "/" + coords[2], 3000, NotificationType.INFO);
                }

                @Override
                public void run() {

                }
            });
        }
    }

    private ArrayList<Vec3> computePath(cc.novoline.utils.pathfinding.Vec3 topFrom, cc.novoline.utils.pathfinding.Vec3 to) {
        if (!canPassThrow(BlockPos.ofFloored(topFrom.mc()))) {
            topFrom = topFrom.addVector(0, 1, 0);
        }
        AStarCustomPathfinder pathfinder = new AStarCustomPathfinder(topFrom, to);
        pathfinder.compute();

        int i = 0;
        cc.novoline.utils.pathfinding.Vec3 lastLoc = null;
        cc.novoline.utils.pathfinding.Vec3 lastDashLoc = null;
        ArrayList<cc.novoline.utils.pathfinding.Vec3> path = new ArrayList<>();
        ArrayList<cc.novoline.utils.pathfinding.Vec3> pathFinderPath = pathfinder.getPath();
        for (cc.novoline.utils.pathfinding.Vec3 pathElm : pathFinderPath) {
            if (i == 0 || i == pathFinderPath.size() - 1) {
                if (lastLoc != null) {
                    path.add(lastLoc.addVector(0.5, 0, 0.5));
                }
                path.add(pathElm.addVector(0.5, 0, 0.5));
                lastDashLoc = pathElm;
            } else {
                boolean canContinue = true;
                if (pathElm.squareDistanceTo(lastDashLoc) > 3 * 3) {
                    canContinue = false;
                } else {
                    double smallX = Math.min(lastDashLoc.getX(), pathElm.getX());
                    double smallY = Math.min(lastDashLoc.getY(), pathElm.getY());
                    double smallZ = Math.min(lastDashLoc.getZ(), pathElm.getZ());
                    double bigX = Math.max(lastDashLoc.getX(), pathElm.getX());
                    double bigY = Math.max(lastDashLoc.getY(), pathElm.getY());
                    double bigZ = Math.max(lastDashLoc.getZ(), pathElm.getZ());
                    cordsLoop:
                    for (int x = (int) smallX; x <= bigX; x++) {
                        for (int y = (int) smallY; y <= bigY; y++) {
                            for (int z = (int) smallZ; z <= bigZ; z++) {
                                if (!AStarCustomPathfinder.checkPositionValidity(x, y, z, false)) {
                                    canContinue = false;
                                    break cordsLoop;
                                }
                            }
                        }
                    }
                }
                if (!canContinue) {
                    path.add(lastLoc.addVector(0.5, 0, 0.5));
                    lastDashLoc = lastLoc;
                }
            }
            lastLoc = pathElm;
            i++;
        }
        return path;
    }

    private boolean canPassThrow(@NotNull BlockPos pos) {
        BlockState state = MinecraftClient.getInstance().world.getBlockState(new BlockPos(pos.getX(), pos.getY(), pos.getZ()));
        Block block = state.getBlock();
        return state.isAir() || block instanceof PlantBlock || block instanceof VineBlock || block == Blocks.LADDER
                || state.getFluidState().isIn(FluidTags.WATER) || block instanceof AbstractSignBlock; // PORT: Material.plants/vine -> block classes; wall/standing sign -> AbstractSignBlock
    }

    // PORT: ItemSkull is gone — skulls are BlockItems wrapping AbstractSkullBlock.
    private static boolean isSkull(@NotNull ItemStack stack) {
        return stack.getItem() instanceof BlockItem
                && ((BlockItem) stack.getItem()).getBlock() instanceof AbstractSkullBlock;
    }

    // PORT: IChatComponent.getFormattedText() — rebuilds the legacy §-coded string from Text styles.
    private static String formattedText(@NotNull Text text) {
        StringBuilder sb = new StringBuilder();
        text.visit((style, string) -> {
            if (!style.isEmpty()) {
                sb.append('§').append('r');
                TextColor color = style.getColor();
                if (color != null) {
                    for (Formatting formatting : Formatting.values()) {
                        if (formatting.isColor() && formatting.getColorValue() != null && formatting.getColorValue() == color.getRgb()) {
                            sb.append('§').append(formatting.getCode());
                            break;
                        }
                    }
                }
                if (style.isBold()) sb.append('§').append('l');
                if (style.isItalic()) sb.append('§').append('o');
                if (style.isUnderlined()) sb.append('§').append('n');
                if (style.isStrikethrough()) sb.append('§').append('m');
                if (style.isObfuscated()) sb.append('§').append('k');
            }
            sb.append(string);
            return Optional.empty();
        }, Style.EMPTY);
        return sb.toString();
    }

    public BooleanProperty getBlur() {
        return blur;
    }

    public BooleanProperty getClosePrevious() {
        return closePrevious;
    }

    public Servers getCurrentServer() {
        return currentServer;
    }

    public void setCurrentServer(Servers server) {
        currentServer = server;
    }

    public Channels getChannel() {
        return channel;
    }

    public String channelName() {
        return channel.equals(Channels.PM) ? "Conversation" : StringUtils.capitalize(channel.name().toLowerCase());
    }

    public int getTicks() {
        return ticks;
    }

    public void setMwPort(boolean mwPort) {
        this.mwPort = mwPort;
    }

    public boolean isMwPort() {
        return mwPort;
    }

    public void setCoords(int[] coords) {
        this.coords = coords;
    }
}
