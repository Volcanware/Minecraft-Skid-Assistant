package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.IntProperty;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import cc.novoline.utils.Timer;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static cc.novoline.gui.screen.setting.Manager.put;
import static cc.novoline.gui.screen.setting.SettingType.CHECKBOX;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.booleanFalse;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createInt;

public class AutoArmor extends AbstractModule {

    /* fields */
    private final Timer timer = new Timer();

    /* properties @off */
    @Property("equip-delay")
    private final IntProperty equipDelay = createInt(3).minimum(1).maximum(10);
    @Property("open-inventory")
    private final BooleanProperty open_inv = booleanFalse();

    /* constructors @on */
    public AutoArmor(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "AutoArmor", "Auto Armor", EnumModuleType.PLAYER, "Equips armor for you");
        put(new Setting("Equip_Delay", "Delay", SettingType.SLIDER, this, equipDelay, 1));
        put(new Setting("AA_OPEN_INV", "Open Inventory", CHECKBOX, this, this.open_inv));
    }

    /* methods */
    // PORT: ItemArmor.damageReduceAmount -> sum of the stack's ARMOR attribute modifiers on its equip slot
    private float armorValue(@NotNull ItemStack stack) {
        EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);
        AttributeModifiersComponent modifiers = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);

        if (equippable == null || modifiers == null) {
            return 0;
        }

        float[] armor = {0.0F};
        modifiers.applyModifiers(equippable.slot(), (attribute, modifier) -> {
            if (attribute.value() == EntityAttributes.ARMOR.value()) {
                armor[0] += (float) modifier.value();
            }
        });
        return armor[0];
    }

    // PORT: ItemArmor check -> equippable item with a positive armor value (excludes elytra/pumpkins/heads, like unlocalized-name checks did)
    private boolean isArmorOf(@NotNull ItemStack stack, @NotNull EquipmentSlot slot) {
        EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);
        return equippable != null && equippable.slot() == slot && armorValue(stack) > 0;
    }

    // PORT: EnchantmentHelper.getEnchantmentLevel(id, stack) -> registry-backed EnchantmentHelper.getLevel
    private int enchantLevel(@NotNull RegistryKey<Enchantment> key, @NotNull ItemStack stack) {
        return EnchantmentHelper.getLevel(
                mc.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(key), stack);
    }

    private float getProtection(@NotNull ItemStack stack) {
        float protection = 0;

        float armorValue = armorValue(stack);
        if (armorValue > 0) {
            protection += armorValue + (100 - armorValue) * enchantLevel(Enchantments.PROTECTION, stack) * 0.0075D;
            protection += enchantLevel(Enchantments.BLAST_PROTECTION, stack) / 100d;
            protection += enchantLevel(Enchantments.FIRE_PROTECTION, stack) / 100d;
            protection += enchantLevel(Enchantments.THORNS, stack) / 100d;
            protection += enchantLevel(Enchantments.UNBREAKING, stack) / 50d;
            protection += enchantLevel(Enchantments.PROJECTILE_PROTECTION, stack) / 100d;
        }

        return protection;
    }

    @EventTarget
    public void onEvent(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (!(mc.currentScreen instanceof InventoryScreen) && open_inv.get() || ServerUtils.serverIs(Servers.PRE) || ServerUtils.serverIs(Servers.LOBBY) || getModule(ChestStealer.class).isStealing()) {
                return;
            }

            if (mc.currentScreen == null || mc.currentScreen instanceof InventoryScreen || mc.currentScreen instanceof ChatScreen) {
                for (int type = 1; type < 5; type++) {
                    if (mc.player.playerScreenHandler.getSlot(4 + type).hasStack()) {
                        ItemStack slotStack = mc.player.playerScreenHandler.getSlot(4 + type).getStack();

                        if (isBestArmor(slotStack, type)) {
                            continue;
                        } else {
                            PlayerHelper.drop(mc, 4 + type);
                        }
                    }

                    for (int i = 9; i < 45; i++) {
                        if (mc.player.playerScreenHandler.getSlot(i).hasStack()) {
                            ItemStack slotStack = mc.player.playerScreenHandler.getSlot(i).getStack();

                            if (isBestArmor(slotStack, type) && getProtection(slotStack) > 0) {
                                if (timer.check(equipDelay.get() * 50)) {
                                    PlayerHelper.shiftClick(mc, i);
                                    timer.reset();
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public boolean isWorking() {
        return !timer.check(equipDelay.get() * 100);
    }

    private static @Nullable EquipmentSlot slotFor(int type) {
        // PORT: 1.8.9 matched armor pieces via unlocalized-name suffixes ("helmet" etc.)
        switch (type) {
            case 1:
                return EquipmentSlot.HEAD;
            case 2:
                return EquipmentSlot.CHEST;
            case 3:
                return EquipmentSlot.LEGS;
            case 4:
                return EquipmentSlot.FEET;
            default:
                return null;
        }
    }

    boolean isBestArmor(@NotNull ItemStack stack, int type) {
        EquipmentSlot slot = slotFor(type);

        if (slot == null || !isArmorOf(stack, slot)) {
            return false;
        }

        float protection = getProtection(stack);

        for (int i = 5; i < 45; i++) {
            if (mc.player.playerScreenHandler.getSlot(i).hasStack()) {
                ItemStack is = mc.player.playerScreenHandler.getSlot(i).getStack();
                if (getProtection(is) > protection && isArmorOf(is, slot)) return false;
            }
        }

        return true;
    }

    //region Lombok
    public IntProperty getEquipDelay() {
        return equipDelay;
    }
    //endregion
}
