package cc.novoline.modules.player;

import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

/**
 * Lets block breaking continue while an item is in use (eating, bow draw,
 * shield). Vanilla gates handleBlockBreaking on !player.isUsingItem(); the
 * MinecraftClientMixin bypasses that gate while this module is enabled.
 */
public final class MultiTask extends AbstractModule {

    public MultiTask(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "MultiTask", "Multi Task", Keyboard.KEY_NONE, EnumModuleType.PLAYER, "Break blocks while using items");
    }
}
