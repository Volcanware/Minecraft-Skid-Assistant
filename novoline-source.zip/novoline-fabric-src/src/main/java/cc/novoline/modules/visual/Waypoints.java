package cc.novoline.modules.visual;

import cc.novoline.Novoline;
import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render2DEvent;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.RotationUtil;
import cc.novoline.utils.ScaledResolution;
import cc.novoline.utils.Timer;
import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts;
import cc.novoline.utils.java.Checks;
import com.google.common.reflect.TypeToken;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import ninja.leaping.configurate.ConfigurationNode;
import ninja.leaping.configurate.objectmapping.ObjectMappingException;
import ninja.leaping.configurate.objectmapping.serialize.TypeSerializer;
import ninja.leaping.configurate.objectmapping.serialize.TypeSerializerCollection;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static java.lang.Math.abs;
import static java.lang.Math.sqrt;
import static java.util.Objects.requireNonNull;

public final class Waypoints extends AbstractModule {

    /* fields */
    private final List<Waypoint> waypoints = new ObjectArrayList<>();
    private static FontRenderer SF_16 = Fonts.SF.SF_16.SF_16;
    private static Timer tpTimer = new Timer();

    /* constructors */
    public Waypoints(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Waypoints", EnumModuleType.VISUALS, null, "waypoints");
        addWaypointsFromConfig();
    }

    /* methods */
    private void addWaypointsFromConfig() {
        try {
            // PORT: configurate 3.x getList() takes the element TypeToken (not TypeToken<List<T>>)
            this.waypoints.addAll(this.config.getRootNode().getNode("waypoints").getList(new TypeToken<Waypoint>() {
            }, new ArrayList<Waypoint>()));
        } catch (ObjectMappingException e) {
            throw new RuntimeException("An error occurred while deserialization of the waypoints file", e);
        }
    }

    @Override
    protected void addCustomSerializers(@NotNull TypeSerializerCollection collection) {
        collection.registerType(Serializer.TYPE_TOKEN, new Serializer());
    }

    /* events */
    @EventTarget
    public void onRender2D(Render2DEvent event) {
        this.waypoints.forEach(Waypoint::render);
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        Vec3d camPos = RenderUtils.cameraPos();
        for (final Waypoint waypoint : this.waypoints) {
            final float x = (float) (waypoint.getX() + 0 * event.getPartialTicks() - camPos.x), // @off
                    y = (float) (waypoint.getY() + 0 * event.getPartialTicks() - camPos.y),
                    z = (float) (waypoint.getZ() + 0 * event.getPartialTicks() - camPos.z); // @on

            waypoint.setPositions(waypoint.convertTo2D(x, y, z));
        }
    }

    /* unimportant shit */
    public void addWaypoint(@NotNull Waypoint waypoint) {
        this.waypoints.add(waypoint);

        try {
            updateConfigNode();
        } catch (ObjectMappingException e) {
            this.logger.warn("An error occurred while saving friends list", e);
        }
    }

    public boolean removeWaypoint(String name) {
        Checks.notBlank(name, "name");

        final boolean b = this.waypoints.removeIf(w -> w.getName().equalsIgnoreCase(name));

        if (b) {
            try {
                updateConfigNode();
            } catch (ObjectMappingException e) {
                this.logger.warn("An error occurred while saving friends list", e);
            }
        }

        return b;
    }

    private void updateConfigNode() throws ObjectMappingException {
        this.config.getRootNode().getNode("waypoints").setValue(new TypeToken<List<Waypoint>>() {
        }, this.waypoints);
    }

    @Nullable
    public Waypoint getWaypointByName(String name) {
        return this.waypoints.stream().filter(waypoint -> waypoint.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    //region Lombok
    private final List<Waypoint> waypointsView = Collections.unmodifiableList(this.waypoints);

    public List<Waypoint> getWaypoints() {
        return this.waypointsView;
    }
    //endregion

    /* PORT: ScaleUtils.scale(mc) inlined - scales the 2D matrix for non-auto gui scales */
    private static void scale(MinecraftClient mc) {
        if (!(mc.currentScreen instanceof cc.novoline.gui.screen.click.DiscordGUI)) {
            switch (mc.options.getGuiScale().getValue()) {
                case 0:
                    RenderUtils.context().getMatrices().scale(0.5F, 0.5F);
                    break;
                case 1:
                    RenderUtils.context().getMatrices().scale(2.0F, 2.0F);
                    break;
                case 3:
                    RenderUtils.context().getMatrices().scale(0.6666666666666667F, 0.6666666666666667F);
            }
        }
    }

    /**
     * @author xDelsy
     */
    public static final class Waypoint {

        private transient double[] positions = {0, 0, 0};

        private final String name;
        private final int x;
        private final int y;
        private final int z;

        public Waypoint(String name, int x, int y, int z) {
            this.name = name;
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public static Waypoints.Waypoint of(String name, int x, int y, int z) {
            Checks.notBlank(name, "name");
            return new Waypoint(name, x, y, z);
        }

        public void render() {
            final ScaledResolution resolution = new ScaledResolution(MinecraftClient.getInstance());
            DrawContext context = RenderUtils.context();

            if (isInView() && this.positions != null) {
                context.getMatrices().pushMatrix();
                context.getMatrices().translate((float) (this.positions[0] / resolution.getScaleFactor()),
                        (float) (this.positions[1] / resolution.getScaleFactor()));
                scale(MinecraftClient.getInstance());

                float amp = 1;
                switch (MinecraftClient.getInstance().options.getGuiScale().getValue()) {
                    case 0:
                        amp = 0.5F;
                        break;
                    case 1:
                        amp = 2.0F;
                        break;
                    case 3:
                        amp = 0.6666666666666667F;
                }

                float width = resolution.getScaledWidth() / 2F;
                float height = resolution.getScaledHeight() / 2F;

                float sizePerPixelX = SF_16.stringWidth(this.name + " " + getDistance() + "m") / 2F;
                float sizePerPixelY = 15 * 0.75F;
                float xBnd1 = width / amp + sizePerPixelX;
                float xBnd2 = width / amp - sizePerPixelX;
                float yBnd1 = height / amp - sizePerPixelY;
                float yBnd2 = height / amp + sizePerPixelY;


/*                if (MinecraftClient.getInstance().options.getPerspective().isFirstPerson() && this.positions[0] >= xBnd2 * 2 && this.positions[0] <= xBnd1 * 2 &&
                        this.positions[1] >= yBnd1 * 2 && this.positions[1] <= yBnd2 * 2) {
                    SF_16.drawString("Middle click to teleport!", -(SF_16.stringWidth("Middle click to teleport") / 2F), -18, 0xffffffff, true);
                    if (Mouse.isButtonDown(2)) {
                        if (tpTimer.delay(1000)) {
                            String command = MinecraftClient.getInstance().isInSingleplayer() ? "/tp" : ".tp";
                            String coords = MinecraftClient.getInstance().isInSingleplayer() ? " " + x + " " + y + " " + z : " " + x + " " + z;
                            MinecraftClient.getInstance().player.networkHandler.sendChatMessage(command + coords);
                            tpTimer.reset();
                        }
                    }
                }*/

                context.getMatrices().translate(0.0F, -2.5F);
                // PORT: depth state handled by the GUI pipeline
                RenderUtils.guiQuad(-(SF_16.stringWidth(this.name + " " + getDistance() + "m") / 2) - 2, -5,
                        SF_16.stringWidth(this.name + " " + getDistance() + "m") / 2 + 2, 10,
                        new Color(0, 0, 0, 100).getRGB());
                RenderUtils.guiQuad(-(SF_16.stringWidth(this.name + " " + getDistance() + "m") / 2) - 2, -6,
                        SF_16.stringWidth(this.name + " " + getDistance() + "m") / 2 + 2, -5,
                        requireNonNull(
                                Novoline.getInstance().getModuleManager().getModule(HUD.class).getColor())
                                .getRGB());
                SF_16.drawString(this.name + " " + Formatting.GRAY + getDistance() + "m",
                        -(SF_16.stringWidth(this.name + " " + getDistance() + "m") / 2F), 0, 0xffffffff);
                context.getMatrices().popMatrix();
            }
        }

        public int getDistance() {
            final int diffX = (int) abs(MinecraftClient.getInstance().player.getX() - this.getX()), // @off
                    diffY = (int) abs(MinecraftClient.getInstance().player.getY() - this.getY()),
                    diffZ = (int) abs(MinecraftClient.getInstance().player.getZ() - this.getZ()); // @on

            return (int) sqrt(diffX * diffX + diffY * diffY + diffZ * diffZ);
        }

        public boolean isInView() {
            MinecraftClient mc = MinecraftClient.getInstance();
            final int perspective = mc.options.getPerspective().ordinal();
            final float angle = RotationUtil.getRotationFromPosition(this.getX(), this.getZ(), this.getY())[0], // @off
                    angle2 = RotationUtil.getRotationFromPosition(this.getX(), this.getZ(), this.getY())[1],
                    cameraYaw = (perspective == 0 ? mc.getCameraEntity().getYaw() : mc.gameRenderer.getCamera().getYaw()) + (float) (perspective == 2 ? 180 : 0);

            return RotationUtil.getDistanceBetweenAngles(angle, RotationUtil.getNewAngle(cameraYaw)) < 90.0F
                    && RotationUtil
                    .getDistanceBetweenAngles(angle2, perspective == 0 ? mc.player.getPitch() : mc.gameRenderer.getCamera().getPitch()) < 90.0F; // @on
        }

        public double[] convertTo2D(double x, double y, double z) {
            // PORT: GLU.gluProject replaced by a JOML projection; (x,y,z) arrive camera-relative
            MinecraftClient mc = MinecraftClient.getInstance();
            Camera camera = mc.gameRenderer.getCamera();

            Matrix4f view = new Matrix4f()
                    .rotationX(camera.getPitch() * MathHelper.RADIANS_PER_DEGREE)
                    .rotateY((camera.getYaw() + 180.0F) * MathHelper.RADIANS_PER_DEGREE);
            Matrix4f projection = new Matrix4f(mc.gameRenderer.getBasicProjectionMatrix(((cc.novoline.mixin.GameRendererAccessor) mc.gameRenderer).novoline$getFov(camera, mc.getRenderTickCounter().getTickProgress(true), true)));

            int[] viewport = {0, 0, mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight()};
            Vector4f screenCoords = new Vector4f();
            // PORT: GLU.gluProject replaced by a JOML projection; it essentially always succeeded,
            // so the JOML result (which returns the dest vector, not a boolean) is taken unconditionally.
            projection.mul(view)
                    .project((float) x, (float) y, (float) z, viewport, screenCoords);
            return new double[]{screenCoords.x, mc.getWindow().getFramebufferHeight() - screenCoords.y, screenCoords.z};
        }

        //region Lombok-alternative
        public void setPositions(double[] positions) {
            this.positions = positions;
        }

        public String getName() {
            return this.name;
        }

        public int getX() {
            return this.x;
        }

        public int getY() {
            return this.y;
        }

        public int getZ() {
            return this.z;
        }
        //endregion

    }

    public static class Serializer implements TypeSerializer<Waypoint> {

        public static final TypeToken<Waypoint> TYPE_TOKEN = TypeToken.of(Waypoint.class);

        @Override
        public Waypoint deserialize(@NotNull TypeToken<?> type, @NotNull ConfigurationNode node) {
            final String name = node.getNode("name").getString(); // @off
            final int x = node.getNode("x").getInt(),
                    y = node.getNode("y").getInt(),
                    z = node.getNode("z").getInt(); // @on

            return Waypoint.of(name, x, y, z);
        }

        @Override
        public void serialize(@NotNull TypeToken<?> type, Waypoint obj, @NotNull ConfigurationNode node) {
            if (obj == null) return;

            node.getNode("name").setValue(obj.getName());
            node.getNode("x").setValue(obj.getX());
            node.getNode("y").setValue(obj.getY());
            node.getNode("z").setValue(obj.getZ());
        }
    }

    public List<Waypoint> getWaypointsList() {
        return waypoints;
    }
}
