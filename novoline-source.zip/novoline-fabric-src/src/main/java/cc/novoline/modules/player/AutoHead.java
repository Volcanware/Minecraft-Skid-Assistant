package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.DoubleProperty;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import cc.novoline.utils.Timer;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import org.jetbrains.annotations.NotNull;

import static cc.novoline.modules.configurations.property.object.PropertyFactory.booleanFalse;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createDouble;

public class AutoHead extends AbstractModule {

    private Timer timer = new Timer();

    @Property("health")
    private final DoubleProperty health = createDouble(14.0D).minimum(1.0D).maximum(20.0D);
    @Property("force-absorption")
    private final BooleanProperty force_absorption = booleanFalse();
    @Property("check-regen")
    private final BooleanProperty check_regen = booleanFalse();

    public AutoHead(@NotNull ModuleManager moduleManager) {
        super(moduleManager, EnumModuleType.COMBAT, "AutoHead", "Auto Head");
        Manager.put(new Setting("AH_FORCE_ABS", "Force absorption", SettingType.CHECKBOX, this, force_absorption));
        Manager.put(new Setting("AH_CHECK_REGEN", "Check Regen", SettingType.CHECKBOX, this, check_regen, () -> !force_absorption.get()));
        Manager.put(new Setting("AH_HEALTH", "Health", SettingType.SLIDER, this, health, 1.0D, () -> !force_absorption.get()));
    }

    // PORT: ItemSkull check -> item whose placed block is an AbstractSkullBlock (Items.skull is split per-type now)
    private static boolean isSkull(@NotNull ItemStack stack) {
        return stack.getItem() instanceof BlockItem && ((BlockItem) stack.getItem()).getBlock() instanceof AbstractSkullBlock;
    }

    public int headSlot() {
        for (int i = 0; i < 9; i++) { // PORT: was mc.player.getSlotByItem(Items.skull)
            if (isSkull(mc.player.getInventory().getStack(i))) {
                return i;
            }
        }
        return -1;
    }

    @EventTarget
    public void onMotion(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.POST)) {
            if (!ServerUtils.serverIs(Servers.LOBBY) && !ServerUtils.serverIs(Servers.PRE) && shouldUse(headSlot())) {
                ItemStack stack = mc.player.getInventory().getStack(headSlot());

                if (!stack.isEmpty() && isSkull(stack)) {
                    if (timer.delay(500)) {
                        sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(headSlot()));
                        // PORT: C08PacketPlayerBlockPlacement -> PlayerInteractItemC2SPacket; sequence 0 = no pending block updates to defer
                        sendPacketNoEvent(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
                        sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().getSelectedSlot()));

                        // PORT: ViaFabric is not ported; kept the stackSize == 1 half of the original condition
                        if (stack.getCount() == 1) {
                            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, 36 + headSlot(), 2, SlotActionType.CLONE, mc.player);
                        }

                        timer.reset();
                    }
                }
            }
        }
    }

    private boolean shouldUse(int slot) {
        return slot != -1 && (force_absorption.get() ? mc.player.getAbsorptionAmount() <= 0 : mc.player.getHealth() < health.get() && (!check_regen.get() || !mc.player.hasStatusEffect(StatusEffects.REGENERATION)));
    }
}
