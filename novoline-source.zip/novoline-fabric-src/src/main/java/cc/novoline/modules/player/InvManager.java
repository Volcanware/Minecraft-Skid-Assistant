package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.IntProperty;
import cc.novoline.modules.configurations.property.object.ListProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.move.Scaffold;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import cc.novoline.utils.Timer;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.Blocks;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StainedGlassPaneBlock;
import net.minecraft.block.TallPlantBlock;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import org.jetbrains.annotations.NotNull;

import static cc.novoline.gui.screen.setting.SettingType.*;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.*;
import static net.minecraft.util.Formatting.*;

public final class InvManager extends AbstractModule {

    /* fields */
    private final Timer timer = new Timer();

    /* properties @off */
    @Property("inventory-cleaner")
    private final BooleanProperty inventoryCleaner = booleanTrue();
    @Property("open-inventory")
    private final BooleanProperty open_inv = booleanFalse();
    @Property("delay")
    private final IntProperty delay = createInt(1).minimum(1).maximum(10);
    @Property("arrows")
    private final IntProperty arrows = createInt(128).minimum(64).maximum(512);
    @Property("blocks")
    private final IntProperty blocks = createInt(128).minimum(0).maximum(512);
    @Property("pickaxe-slot")
    private final IntProperty pickAxeSlot = createInt(7).minimum(1).maximum(9);
    @Property("axe-slot")
    private final IntProperty axeSlot = createInt(8).minimum(1).maximum(9);
    @Property("shovel-slot")
    private final IntProperty shovelSlot = createInt(9).minimum(1).maximum(9);
    @Property("weapon-slot")
    private final IntProperty swordSlot = createInt(1).minimum(1).maximum(9);
    @Property("bow-slot")
    private final IntProperty bowSlot = createInt(2).minimum(1).maximum(9);
    @Property("head-slot")
    private final IntProperty headSlot = createInt(3).minimum(1).maximum(9);
    @Property("gapple-slot")
    private final IntProperty gappleSlot = createInt(3).minimum(1).maximum(9);
    @Property("autodisable")
    private final ListProperty<String> autoDisable = PropertyFactory.createList("Death").acceptableValues("World Change", "Game End", "Death");
    @Property("keep-items")
    private final ListProperty<String> items = createList("Sword", "Bow").acceptableValues("Sword", "Bow", "PickAxe", "Axe", "Shovel", "Golden Apple", "Head", "Buckets");
    @Property("filters")
    private final ListProperty<String> materials = createList("Sticks").acceptableValues("Ores", "Sticks");

    /* constructors @on */
    public InvManager(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "InventoryManager", "Inventory Manager", EnumModuleType.PLAYER, "Manages inventory");
        Manager.put(new Setting("IM_CLEANER", "Cleaner", CHECKBOX, this, inventoryCleaner));
        Manager.put(new Setting("IM_OPEN_INV", "Open Inventory", CHECKBOX, this, open_inv));
        Manager.put(new Setting("IM_DELAY", "Delay", SLIDER, this, delay, 1, inventoryCleaner::get));
        Manager.put(new Setting("IM_BLOCKS", "Blocks", SLIDER, this, blocks, 64, inventoryCleaner::get));
        Manager.put(new Setting("IM_ARROWS", "Arrows", SLIDER, this, arrows, 64, () -> items.contains("Bow")));
        Manager.put(new Setting("IM_KEEP_ITEMS", "Keep Items", SELECTBOX, this, items));
        Manager.put(new Setting("IM_WEAPON_SLOT", "Sword Slot", SLIDER, this, swordSlot, 1, () -> items.contains("Sword")));
        Manager.put(new Setting("IM_BOW_SLOT", "Bow Slot", SLIDER, this, bowSlot, 1, () -> items.contains("Bow")));
        Manager.put(new Setting("IM_PICKAXE_SLOT", "Pickaxe Slot", SLIDER, this, pickAxeSlot, 1, () -> items.contains("PickAxe")));
        Manager.put(new Setting("IM_AXE_SLOT", "Axe Slot", SLIDER, this, axeSlot, 1, () -> items.contains("Axe")));
        Manager.put(new Setting("IM_SHOVEL_SLOT", "Shovel Slot", SLIDER, this, shovelSlot, 1, () -> items.contains("Shovel")));
        Manager.put(new Setting("IM_GAPPLE_SLOT", "Golden Apple Slot", SLIDER, this, gappleSlot, 1, () -> items.contains("Golden Apple")));
        Manager.put(new Setting("IM_HEAD_SLOT", "Head Slot", SLIDER, this, headSlot, 1, () -> items.contains("Head")));
        Manager.put(new Setting("IM_MATERIALS", "Keep Materials", SELECTBOX, this, materials));
        Manager.put(new Setting("IM_AUTO_DISABLE", "Disable On", SELECTBOX, this, autoDisable));
    }

    // PORT: getSlotFromPlayerContainer(i).getHasStack()/getStack() -> playerScreenHandler.slots.get(i)
    private boolean hasSlotStack(int i) {
        return mc.player.playerScreenHandler.slots.get(i).hasStack();
    }

    private ItemStack slotStack(int i) {
        return mc.player.playerScreenHandler.slots.get(i).getStack();
    }

    // PORT: jar-modded EntityPlayerSP.swap(invSlot, hotbarSlot) -> clickSlot SWAP
    private void swap(int slotIndex, int hotbarSlot) {
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slotIndex, hotbarSlot,
                SlotActionType.SWAP, mc.player);
    }

    // PORT: jar-modded EntityPlayerSP.drop(slot) -> clickSlot THROW (button 1 = whole stack, like the patch)
    private void drop(int slotIndex) {
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slotIndex, 1,
                SlotActionType.THROW, mc.player);
    }

    // PORT: Item.getIdFromItem -> item identity against the 1.8.9 id table (numeric ids gone)
    private static boolean is(Item item, Item... items) {
        for (Item i : items) {
            if (item == i) return true;
        }
        return false;
    }

    // PORT: ItemSkull -> BlockItem backed by an AbstractSkullBlock
    private static boolean isSkull(ItemStack stack) {
        return stack.getItem() instanceof BlockItem
                && ((BlockItem) stack.getItem()).getBlock() instanceof AbstractSkullBlock;
    }

    private static boolean isPotionItem(ItemStack stack) {
        return stack.isOf(Items.POTION) || stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION);
    }

    private int level(RegistryKey<Enchantment> key, ItemStack stack) {
        return mc.world == null ? 0 : EnchantmentHelper.getLevel(mc.world.getRegistryManager()
                .getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(key), stack);
    }

    /* methods */
    private boolean isBestSword(ItemStack stack) {
        final float damage = getDamage(stack);

        for (int i = 9; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack is = slotStack(i);
                if (getDamage(is) > damage && is.isIn(ItemTags.SWORDS)) {
                    return false;
                }
            }
        }

        return stack.isIn(ItemTags.SWORDS);
    }

    private boolean isHead(@NotNull ItemStack stack) {
        return isSkull(stack) && stack.getName().getString().contains("Head") && !stack
                .getName().getString().equalsIgnoreCase("Wither Skeleton Skull") && !stack.getName().getString()
                .equalsIgnoreCase("Zombie Head") && !stack.getName().getString().equalsIgnoreCase("Creeper Head") && !stack
                .getName().getString().equalsIgnoreCase("Skeleton Skull");
    }

    private boolean isGoldenApple(@NotNull ItemStack stack) {
        return stack.isOf(Items.GOLDEN_APPLE) || stack.isOf(Items.ENCHANTED_GOLDEN_APPLE);
    }

    @EventTarget
    public void onPreUpdate(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (!(mc.currentScreen instanceof InventoryScreen) && open_inv.get() || ServerUtils.serverIs(Servers.PRE) || ServerUtils.serverIs(Servers.LOBBY)
                    || isEnabled(AutoArmor.class) && getModule(AutoArmor.class).isWorking() || getModule(ChestStealer.class).isStealing()) {
                return;
            }

            if (mc.currentScreen == null || mc.currentScreen instanceof InventoryScreen || mc.currentScreen instanceof ChatScreen) {
                final int swordSlot = this.swordSlot.get() - 1, pickAxeSlot = this.pickAxeSlot.get() - 1,
                        bowSlot = this.bowSlot.get() - 1, shovelSlot = this.shovelSlot.get() - 1,
                        axeSlot = this.axeSlot.get() - 1, headSlot = this.headSlot.get() - 1, gappleSlot = this.gappleSlot.get() - 1;

                boolean pickAxe = items.contains("PickAxe"), shovel = items.contains("Shovel"),
                        axe = items.contains("Axe"), sword = items.contains("Sword"),
                        bow = items.contains("Bow"), head = items.contains("Head"), gapple = items.contains("Golden Apple");

                int tickDelay = delay.get() * 50;

                for (int slotIndex = 9; slotIndex < 45; slotIndex++) {
                    ItemStack stack = slotStack(slotIndex);
                    if (!stack.isEmpty()) {
                        if (timer.check(tickDelay)) {
                            if (isBestSword(stack) && sword && shouldSwap(swordSlot)[0]) {
                                swap(slotIndex, swordSlot);
                                timer.reset();
                            } else if (isBestPickaxe(stack) && pickAxe && shouldSwap(pickAxeSlot)[2]) {
                                swap(slotIndex, pickAxeSlot);
                                timer.reset();
                            } else if (isBestAxe(stack) && axe && shouldSwap(axeSlot)[1]) {
                                swap(slotIndex, axeSlot);
                                timer.reset();
                            } else if (isBestBow(stack) && bow && shouldSwap(bowSlot)[5] && !stack.getName().getString().toLowerCase().contains("kit selector")) {
                                swap(slotIndex, bowSlot);
                                timer.reset();
                            } else if (isHead(stack) && head && shouldSwap(headSlot)[4]) {
                                swap(slotIndex, headSlot);
                                timer.reset();
                            } else if (isBestShovel(stack) && shovel && shouldSwap(shovelSlot)[3]) {
                                swap(slotIndex, shovelSlot);
                                timer.reset();
                            } else if (isGoldenApple(stack) && gapple && shouldSwap(gappleSlot)[6]) {
                                swap(slotIndex, gappleSlot);
                                timer.reset();
                            }
                        }
                    }
                }

                for (int slotIndex = 9; slotIndex < 45; slotIndex++) {
                    if (!hasSlotStack(slotIndex)) {
                        continue;
                    }

                    ItemStack stack = slotStack(slotIndex);

                    if (!stack.isEmpty()) {
                        if (shouldDrop(stack) && inventoryCleaner.get()) {
                            if (timer.delay(tickDelay)) {
                                drop(slotIndex);
                                timer.reset();
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean[] shouldSwap(int slot) {
        return new boolean[]{
                !hasSlotStack(slot + 36) || !isBestSword(slotStack(slot + 36)),
                !hasSlotStack(slot + 36) || !isBestAxe(slotStack(slot + 36)),
                !hasSlotStack(slot + 36) || !isBestPickaxe(slotStack(slot + 36)),
                !hasSlotStack(slot + 36) || !isBestShovel(slotStack(slot + 36)),
                !hasSlotStack(slot + 36) || !isHead(slotStack(slot + 36)),
                !hasSlotStack(slot + 36) || !isBestBow(slotStack(slot + 36)),
                !hasSlotStack(slot + 36) || !isGoldenApple(slotStack(slot + 36))};
    }

    public boolean isWorking() {
        return !timer.check(delay.get() * 150);
    }

    private float getDamage(@NotNull ItemStack stack) {
        float damage = 0;
        final Item item = stack.getItem();

        if (stack.contains(DataComponentTypes.TOOL) || stack.isIn(ItemTags.SWORDS)) {
            // PORT: ItemTool.getDamage / ItemSword.getAttackDamage -> total ATTACK_DAMAGE
            //       attribute modifiers on the main hand
            AttributeModifiersComponent modifiers = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
            if (modifiers != null) {
                damage += (float) modifiers.applyOperations(EntityAttributes.ATTACK_DAMAGE, 0.0, EquipmentSlot.MAINHAND);
            }
        }

        damage += level(Enchantments.SHARPNESS, stack) * 1.25F + level(Enchantments.FIRE_ASPECT, stack) * 0.01F;
        return damage;
    }

    private int getBlocksCounter() {
        int blockCount = 0;

        for (int i = 0; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack stack = slotStack(i);
                final Item item = stack.getItem();

                if (stack.getItem() instanceof BlockItem && !getModule(Scaffold.class).getBlacklistedBlocks().contains(((BlockItem) item).getBlock())) {
                    blockCount += stack.getCount();
                }
            }
        }

        return blockCount;
    }

    private int getArrowsCounter() {
        int arrowCount = 0;

        for (int i = 0; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack is = slotStack(i);
                if (is.getItem() == Items.ARROW) arrowCount += is.getCount();
            }
        }

        return arrowCount;
    }

    private int getIronIngotsCounter() {
        int count = 0;

        for (int i = 0; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack stack = slotStack(i);
                if (stack.getItem() == Items.IRON_INGOT) count += stack.getCount();
            }
        }

        return count;
    }

    private int getCoalCounter() {
        int count = 0;

        for (int i = 0; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack stack = slotStack(i);
                if (stack.getItem() == Items.COAL) count += stack.getCount();
            }
        }

        return count;
    }

    private int getSwordsCounter() {
        int count = 0;

        for (int i = 0; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack stack = slotStack(i);
                if (stack.isIn(ItemTags.SWORDS) && isBestSword(stack)) count += stack.getCount();
            }
        }

        return count;
    }

    private int getBowsCounter() {
        int count = 0;

        for (int i = 0; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack stack = slotStack(i);
                if (stack.getItem() instanceof BowItem && isBestBow(stack)) count += stack.getCount();
            }
        }

        return count;
    }

    private int getPickaxexCounter() {
        int count = 0;

        for (int i = 0; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack stack = slotStack(i);
                if (stack.isIn(ItemTags.PICKAXES) && isBestPickaxe(stack)) count += stack.getCount();
            }
        }

        return count;
    }

    private int getAxesCounter() {
        int count = 0;

        for (int i = 0; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack stack = slotStack(i);
                if (stack.isIn(ItemTags.AXES) && isBestAxe(stack)) count += stack.getCount();
            }
        }

        return count;
    }

    private int getHeadsCounter() {
        int count = 0;

        for (int i = 0; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack stack = slotStack(i);
                if (isSkull(stack) && isBestShovel(stack)) count += stack.getCount();
            }
        }

        return count;
    }

    private int getShovelsCounter() {
        int count = 0;

        for (int i = 0; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack stack = slotStack(i);
                if (stack.isIn(ItemTags.SHOVELS) && isBestShovel(stack)) count += stack.getCount();
            }
        }

        return count;
    }

    private boolean isBestPickaxe(ItemStack stack) {
        final Item item = stack.getItem();

        if (!stack.isIn(ItemTags.PICKAXES)) {
            return false;
        }

        final float value = getToolEffect(stack);

        for (int i = 9; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack slotStack = slotStack(i);
                if (getToolEffect(slotStack) > value && slotStack.isIn(ItemTags.PICKAXES)) return false;
            }
        }

        return true;
    }

    private boolean shouldDrop(ItemStack stack) {
        final Item item = stack.getItem();
        final String displayName = stack.getName().getString();

        if (item == Items.CRAFTING_TABLE || displayName.toLowerCase().contains(OBFUSCATED + "||") // @off
                || displayName.contains(GREEN + "Game Menu " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(AQUA + "" + BOLD + "Spectator Settings " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(AQUA + "" + BOLD + "Play Again " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(GREEN + "" + BOLD + "Teleporter " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(GREEN + "SkyWars Challenges " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(GREEN + "Collectibles " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(GREEN + "Kit Selector " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(GREEN + "Kill Effect Selector " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(WHITE + "Players: " + RED + "Hidden " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(GREEN + "Shop " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(WHITE + "Players: " + RED + "Visible " + GRAY + "(Right Click)")
                || displayName.equalsIgnoreCase(GOLD + "Excalibur") || displayName.equalsIgnoreCase("aDragon Sword")
                || displayName.equalsIgnoreCase(GREEN + "Cornucopia")
                || displayName.equalsIgnoreCase(RED + "Bloodlust") || displayName.equalsIgnoreCase(RED + "Artemis' Bow")
                || displayName.equalsIgnoreCase(GREEN + "Miner's Blessing") || displayName.equalsIgnoreCase(GOLD + "Axe of Perun")
                || displayName.equalsIgnoreCase(GOLD + "Cornucopia") || item == Items.ENCHANTING_TABLE || item == Items.ANVIL
                || is(item, Items.IRON_ORE, Items.GOLD_ORE) && materials.contains("Ores") || displayName.equalsIgnoreCase("§aAndúril")
                || item == Items.FLINT_AND_STEEL || item == Items.TNT) { // @on
            return false;
        }

        boolean pickAxe = items.contains("PickAxe"), shovel = items.contains("Shovel"),
                axe = items.contains("Axe"), sword = items.contains("Sword"),
                bow = items.contains("Bow"), head = items.contains("Head");

        final int swordSlot = this.swordSlot.get() - 1, pickAxeSlot = this.pickAxeSlot.get() - 1,
                bowSlot = this.bowSlot.get() - 1, shovelSlot = this.shovelSlot.get() - 1,
                axeSlot = this.axeSlot.get() - 1, headSlot = this.headSlot.get() - 1;

        if ((isBestShovel(stack) && getShovelsCounter() < 2 || stack.isIn(ItemTags.SHOVELS) && stack == mc.player.getInventory().getStack(shovelSlot)) && shovel ||
                (isBestBow(stack) && getBowsCounter() < 2 || stack.getItem() instanceof BowItem && stack == mc.player.getInventory().getStack(bowSlot)) && bow ||
                (isHead(stack) && getHeadsCounter() < 2 || isSkull(stack) && stack == mc.player.getInventory().getStack(headSlot)) && head ||
                (isBestAxe(stack) && getAxesCounter() < 2 || stack.isIn(ItemTags.AXES) && stack == mc.player.getInventory().getStack(axeSlot)) && axe ||
                (isBestPickaxe(stack) && getPickaxexCounter() < 2 || stack.isIn(ItemTags.PICKAXES) && stack == mc.player.getInventory().getStack(pickAxeSlot)) && pickAxe ||
                (isBestSword(stack) && getSwordsCounter() < 2 || stack.isIn(ItemTags.SWORDS) && stack == mc.player.getInventory().getStack(swordSlot)) && sword) {
            return false;
        }

        if (isArmorItem(stack)) {
            final AutoArmor armorModule = getModule(AutoArmor.class);

            for (int type = 1; type < 5; type++) {
                if (hasSlotStack(4 + type)) {
                    final ItemStack slotStack = slotStack(4 + type);
                    if (armorModule.isBestArmor(slotStack, type)) continue;
                }

                if (armorModule.isBestArmor(stack, type)) return false;
            }
        }

        if (item instanceof BlockItem && (getBlocksCounter() > blocks.get() // @off
                || getModule(Scaffold.class).getBlacklistedBlocks().contains(((BlockItem) item).getBlock()))
                || isPotionItem(stack) && isBadPotion(stack) || stack.contains(DataComponentTypes.FOOD)
                && !isGoldenApple(stack) && item != Items.BREAD && item
                != Items.PUMPKIN_PIE && item != Items.BAKED_POTATO && item != Items.COOKED_CHICKEN
                && item != Items.CARROT && item != Items.APPLE && item != Items.BEEF
                && item != Items.COOKED_BEEF && item != Items.PORKCHOP && item != Items.COOKED_PORKCHOP
                && item != Items.MUSHROOM_STEW && item != Items.COOKED_COD && item != Items.MELON_SLICE
                || stack.isIn(ItemTags.HOES) || stack.contains(DataComponentTypes.TOOL) || stack.isIn(ItemTags.SWORDS) || isArmorItem(stack)) { // @on
            return true;
        }

        final String unlocalizedName = item.getTranslationKey();

        return !materials.contains("Sticks") && unlocalizedName.contains("stick") || unlocalizedName.contains("egg") // @off
                || getIronIngotsCounter() > 64 && item == Items.IRON_INGOT || getCoalCounter() > 64 && item == Items.COAL
                || unlocalizedName.contains("string") || unlocalizedName.contains("flint")
                || unlocalizedName.contains("compass") || unlocalizedName.contains("dye")
                || unlocalizedName.contains("feather")
                || unlocalizedName.contains("chest") && !displayName.toLowerCase().contains("collect")
                || unlocalizedName.contains("snow") || unlocalizedName.contains("torch")
                || unlocalizedName.contains("seeds") || unlocalizedName.contains("leather")
                || unlocalizedName.contains("reeds") || unlocalizedName.contains("record")
                || unlocalizedName.contains("snowball") || item == Items.GLASS_BOTTLE
                || item instanceof BlockItem && ((BlockItem) item).getBlock() instanceof SlabBlock || item == Items.NETHER_BRICK_FENCE || item == Items.VINE
                || item == Items.BUCKET || item == Items.WATER_BUCKET && !items.contains("Buckets") || item == Items.LAVA_BUCKET
                || item == Items.LILY_PAD || stack.isIn(ItemTags.FENCES)
                || item == Items.FIREWORK_ROCKET || stack.isIn(ItemTags.FENCE_GATES) || item == Items.CACTUS
                || item == Items.DEAD_BUSH || unlocalizedName.contains("gravel")
                || unlocalizedName.contains("flower") || unlocalizedName.contains("tallgrass")
                || item instanceof BowItem || item == Items.ARROW && getArrowsCounter() > (items.contains("Bow") ? arrows.get() : 0)
                || item instanceof BlockItem && ((BlockItem) item).getBlock() instanceof TallPlantBlock
                || item == Items.BOOK || item == Items.PAPER
                || item instanceof BlockItem && ((BlockItem) item).getBlock() instanceof StainedGlassPaneBlock
                || item == Items.IRON_BARS || item == Items.GLASS_PANE || item == Items.PAINTING
                || stack.isIn(ItemTags.SIGNS) || item == Items.ITEM_FRAME || item == Items.ARMOR_STAND
                || stack.isIn(ItemTags.WOOL_CARPETS) || unlocalizedName.contains("cobblestone_wall") || item == Items.DISPENSER
                || item == Items.NOTE_BLOCK || item == Items.LEVER || item == Items.STONE_PRESSURE_PLATE
                || item == Items.OAK_PRESSURE_PLATE || item == Items.STONE_BUTTON
                || item == Items.OAK_TRAPDOOR || item == Items.REDSTONE_LAMP
                || item == Items.TRIPWIRE_HOOK || item == Items.OAK_BUTTON || item == Items.HEAVY_WEIGHTED_PRESSURE_PLATE
                || item == Items.LIGHT_WEIGHTED_PRESSURE_PLATE || item == Items.DAYLIGHT_DETECTOR || item == Items.REDSTONE_BLOCK
                || item == Items.HOPPER || item == Items.DROPPER || item == Items.IRON_TRAPDOOR
                || item == Items.ENCHANTED_BOOK
                || item == Items.REDSTONE || item == Items.REPEATER || item == Items.COMPARATOR
                || stack.isIn(ItemTags.RAILS) || item == Items.REDSTONE_TORCH
                || item == Items.MINECART
                || item == Items.CHEST_MINECART || item == Items.FURNACE_MINECART || item == Items.CARROT_ON_A_STICK
                || item == Items.TNT_MINECART || item == Items.HOPPER_MINECART || item == Items.BEACON
                || item == Items.BONE || item == Items.FIRE_CHARGE
                || item == Items.WRITABLE_BOOK || item == Items.MAP || item == Items.FIREWORK_STAR
                || item == Items.GOLDEN_HORSE_ARMOR || item == Items.DIAMOND_HORSE_ARMOR
                || item == Items.BOWL || item == Items.GUNPOWDER || item == Items.CLAY_BALL
                || item == Items.BRICK || item == Items.GLOWSTONE_DUST || item == Items.SUGAR
                || item == Items.BLAZE_ROD || item == Items.NETHER_WART || item == Items.NETHER_BRICK
                || item == Items.QUARTZ || item == Items.PRISMARINE_SHARD || item == Items.PRISMARINE_CRYSTALS
                || item == Items.RABBIT_HIDE || item == Items.GHAST_TEAR || item == Items.FERMENTED_SPIDER_EYE
                || item == Items.BLAZE_POWDER || item == Items.MAGMA_CREAM || item == Items.BREWING_STAND
                || item == Items.CAULDRON || item == Items.GLISTERING_MELON_SLICE || item == Items.RABBIT_FOOT
                || item == Items.FISHING_ROD || item == Items.CLOCK || item == Items.LEAD
                || isSkull(stack) || item == Items.NAME_TAG || item == Items.SLIME_BALL
                || unlocalizedName.contains("sapling") || unlocalizedName.contains("stairs")
                || unlocalizedName.contains("door") || unlocalizedName.contains("infested")
                || unlocalizedName.contains("sand") || unlocalizedName.contains("piston"); // @on
    }

    // PORT: ItemArmor -> EQUIPPABLE component on an armor slot
    private static boolean isArmorItem(ItemStack stack) {
        var equippable = stack.get(DataComponentTypes.EQUIPPABLE);
        return equippable != null && switch (equippable.slot()) {
            case HEAD, CHEST, LEGS, FEET -> true;
            default -> false;
        };
    }

    private boolean isBestShovel(@NotNull ItemStack stack) {
        final Item item = stack.getItem();

        if (!stack.isIn(ItemTags.SHOVELS)) {
            return false;
        }

        final float value = getToolEffect(stack);

        for (int i = 9; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack is = slotStack(i);
                if (getToolEffect(is) > value && is.isIn(ItemTags.SHOVELS)) return false;
            }
        }

        return true;
    }

    private boolean isBestAxe(@NotNull ItemStack stack) {
        final Item item = stack.getItem();

        if (!stack.isIn(ItemTags.AXES)) {
            return false;
        }

        final float value = getToolEffect(stack);

        for (int i = 9; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack is = slotStack(i);
                if (getToolEffect(is) > value && is.isIn(ItemTags.AXES) && !isBestSword(stack)) return false;
            }
        }

        return true;
    }

    private float getToolEffect(@NotNull ItemStack stack) {
        final Item item = stack.getItem();

        if (!stack.contains(DataComponentTypes.TOOL)) {
            return 0;
        }

        final String name = item.getTranslationKey();
        float value;

        if (stack.isIn(ItemTags.PICKAXES)) {
            // PORT: getStrVsBlock(stack, Blocks.stone) -> getMiningSpeedMultiplier(state)
            value = stack.getMiningSpeedMultiplier(Blocks.STONE.getDefaultState());
            if (name.toLowerCase().contains("gold")) value -= 5;
        } else if (stack.isIn(ItemTags.SHOVELS)) {
            value = stack.getMiningSpeedMultiplier(Blocks.DIRT.getDefaultState());
            if (name.toLowerCase().contains("gold")) value -= 5;
        } else if (stack.isIn(ItemTags.AXES)) {
            value = stack.getMiningSpeedMultiplier(Blocks.OAK_LOG.getDefaultState());
            if (name.toLowerCase().contains("gold")) value -= 5;
        } else return 1f;

        value += level(Enchantments.EFFICIENCY, stack) * 0.0075D;
        value += level(Enchantments.UNBREAKING, stack) / 100.0D;

        return value;
    }

    private float getBowEffect(ItemStack stack) {
        return (float) (1 + level(Enchantments.POWER, stack) + level(Enchantments.FLAME, stack) + level(Enchantments.INFINITY, stack));
    }

    private boolean isBadPotion(ItemStack stack) {
        if (stack != null && isPotionItem(stack)) {
            final PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
            return contents == null || !contents.hasEffects() || isBadPotionEffect(stack, stack);
        }

        return false;
    }

    // PORT: (ItemStack, ItemPotion) -> (ItemStack, ItemStack); pot param now carries the stack itself
    public boolean isBadPotionEffect(ItemStack stack, ItemStack pot) {
        final PotionContentsComponent contents = pot.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;

        for (final StatusEffectInstance effect : contents.getEffects()) {
            // PORT: potion.isBadEffect() -> !isBeneficial()
            if (!effect.getEffectType().value().isBeneficial()) {
                return true;
            }
        }

        return false;
    }

    private boolean isBestBow(@NotNull ItemStack stack) {
        final Item item = stack.getItem();
        if (!(item instanceof BowItem)) return false;
        final float value = getBowEffect(stack);

        for (int i = 9; i < 45; i++) {
            if (hasSlotStack(i)) {
                final ItemStack slotStack = slotStack(i);
                if (getBowEffect(slotStack) > value && slotStack.getItem() instanceof BowItem) return false;
            }
        }

        return true;
    }

    @Override
    public void onDisable() {
        timer.reset();
    }

    public BooleanProperty getInventoryCleaner() {
        return inventoryCleaner;
    }

    public BooleanProperty getOpen_inv() {
        return open_inv;
    }

    public IntProperty getDelay() {
        return delay;
    }

    public IntProperty getBlocks() {
        return blocks;
    }

    public ListProperty<String> getItems() {
        return items;
    }

    public IntProperty getPickAxeSlot() {
        return pickAxeSlot;
    }

    public IntProperty getAxeSlot() {
        return axeSlot;
    }

    public IntProperty getShovelSlot() {
        return shovelSlot;
    }

    public IntProperty getSwordSlot() {
        return swordSlot;
    }

    public IntProperty getBowSlot() {
        return bowSlot;
    }

    public IntProperty getHeadSlot() {
        return headSlot;
    }

    public ListProperty<String> getAutoDisable() {
        return autoDisable;
    }

}
