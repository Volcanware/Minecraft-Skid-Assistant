package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MoveEvent;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.combat.KillAura;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.RotationUtil;
import static cc.novoline.utils.PlayerUtils.lerpDistanceTo;
import cc.novoline.utils.Timer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import static cc.novoline.gui.screen.setting.SettingType.*;
import static cc.novoline.modules.PlayerManager.EnumPlayerType.TARGET;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createColor;
import static java.lang.System.currentTimeMillis;

public final class TargetStrafe extends AbstractModule {

    private static final double DOUBLED_PI = Math.PI * 2.0D;
    private static final double POINT_MULTIPLIER = 3.5;

    /* fields */
    private int position;
    private int direction = 1;


    /* properties @off */
    @Property("range")
    private final DoubleProperty radius = PropertyFactory.createDouble(2D).minimum(0.5D).maximum(4.5D);
    @Property("safe-radius")
    private final DoubleProperty safeRadius = PropertyFactory.createDouble(2D).minimum(0.5D).maximum(4.5D);
    @Property("attack-radius")
    private final DoubleProperty attackRadius = PropertyFactory.createDouble(2D).minimum(0.5D).maximum(4.5D);
    @Property("points-multiplier")
    private final DoubleProperty pointsMultiplier = PropertyFactory.createDouble(2D).minimum(1D).maximum(3.5D);
    @Property("switch-hurt-tick")
    private final IntProperty switchHurtTick = PropertyFactory.createInt(8).minimum(5).maximum(15);
    @Property("dynamic-range")
    private final BooleanProperty dynamicRange = PropertyFactory.booleanFalse();
    @Property("only-target")
    private final BooleanProperty target = PropertyFactory.booleanFalse();
    @Property("points")
    private final BooleanProperty points = PropertyFactory.booleanFalse();
    @Property("space")
    private final BooleanProperty space = PropertyFactory.booleanFalse();
    @Property("controllable")
    private final BooleanProperty controllable = PropertyFactory.booleanFalse();
    @Property("behind")
    private final BooleanProperty behind = PropertyFactory.booleanFalse();
    @Property("autothirdperson")
    private final BooleanProperty autoThirdPerson = PropertyFactory.booleanFalse();
    @Property("color")
    private final ColorProperty color = createColor(0xFF8A8AFF);
    @Property("modules")
    private final ListProperty modules = PropertyFactory.createList("Fly").acceptableValues("Fly", "Speed");
    @Property("avoid-edges")
    private final BooleanProperty avoidEdges = PropertyFactory.booleanFalse();
    @Property("height")
    private final IntProperty height = PropertyFactory.createInt(5).minimum(4).maximum(10);

    private boolean inverted, thirded;
    private final Timer timer = new Timer();

    /* constructors @on */
    public TargetStrafe(@NotNull ModuleManager moduleManager) {
        super(moduleManager, EnumModuleType.COMBAT, "TargetStrafe", "Target Strafe");
        Manager.put(new Setting("TS_RADIUS", "Radius", SettingType.SLIDER, this, radius, 0.1, () -> !dynamicRange.get()));
        Manager.put(new Setting("TS_PMULTIPLIER", "Points Multiplier", SettingType.SLIDER, this, pointsMultiplier, 0.1));
        Manager.put(new Setting("TS_DYNAMIC", "Dynamic Radius", SettingType.CHECKBOX, this, dynamicRange, () -> !behind.get()));
        Manager.put(new Setting("TS_SAFE_RADIUS", "Safe Radius", SettingType.SLIDER, this, safeRadius, 0.1, () -> dynamicRange.get()));
        Manager.put(new Setting("TS_ATTACK_RADIUS", "Attack Radius", SettingType.SLIDER, this, attackRadius, 0.1, () -> dynamicRange.get()));
        Manager.put(new Setting("TS_DYNAMIC_SWITCH_TICK", "Switch Hurt Tick", SettingType.SLIDER, this, switchHurtTick, 1, () -> dynamicRange.get()));
        Manager.put(new Setting("TS_TAR", "Only target", SettingType.CHECKBOX, this, target));
        Manager.put(new Setting("TS_SPACE", "On jump key", SettingType.CHECKBOX, this, space));
        Manager.put(new Setting("TS_CONTROL", "Controllable", SettingType.CHECKBOX, this, controllable));
        Manager.put(new Setting("TS_BEHIND", "Behind", SettingType.CHECKBOX, this, behind, () -> !dynamicRange.get()));
        Manager.put(new Setting("POINTS", "Draw circle", SettingType.CHECKBOX, this, points));
        Manager.put(new Setting("ATP", "Auto Third Person", SettingType.CHECKBOX, this, autoThirdPerson));
        Manager.put(new Setting("TS_CIRCLE_COLOR", "Circle color", COLOR_PICKER, this, color, null, points::get));
        Manager.put(new Setting("TS_MODS", "Support", SELECTBOX, this, modules));
        Manager.put(new Setting("TS_EDGES", "Stop on Edges", CHECKBOX, this, avoidEdges));
        Manager.put(new Setting("TS_EDGES_MIN_AMOUNT", "Maximum Height", SLIDER, this, height, 1, avoidEdges::get));
    }

    private float dist = 0;

    @EventTarget
    public void onTick(TickUpdateEvent tickUpdateEvent) {
        if (MoveUtils.moveStrafe(mc.player) < 0) {
            direction = -1;
        } else if (MoveUtils.moveStrafe(mc.player) > 0) {
            direction = 1;
        }

        if (isCollided()) {
            if (timer.delay(200)) {
                inverted = !inverted;
                position = inverted ? position - 1 : position + 1;
            }
            timer.reset();
        }

        KillAura killAura = getModule(KillAura.class);
        Entity target = killAura.getTarget();

        if (target == null) {
            return;
        }

        double rad = getRadius(target);
        int positionsCount = (int) (Math.PI * rad);

        double radianPerPosition = DOUBLED_PI / (float) positionsCount;
        double posX = MathHelper.sin((float) (radianPerPosition * (position + 1) * rad * (controllable.get() ? direction : 1))),
                posY = MathHelper.cos((float) (radianPerPosition * (position + 1))) * rad;
        if (!isVoidBelow(target.getX() + posX, target.getY(), target.getZ() + posY)) {
            inverted = !inverted;
        }


        dist = 0.7F;

        if (autoThirdPerson.get()) {
            if (!(killAura.isEnabled() && killAura.getTarget() != null && killAura.shouldAttack() && shouldTarget())) {
                setThirded(false);
                mc.options.setPerspective(Perspective.FIRST_PERSON);
            }
        }

    }

    /* methods */
    public void circleStrafe(MoveEvent event, double movementSpeed, Entity target) {
        double rad = getRadius(target);
        int positionsCount = (int) ((int) (Math.PI * rad) * pointsMultiplier.get());

        double radianPerPosition = DOUBLED_PI / (float) positionsCount, // @off
                posX = MathHelper.sin((float) (radianPerPosition * position)) * rad * (controllable.get() ? direction : 1),
                posY = MathHelper.cos((float) (radianPerPosition * position)) * rad;// @on

        Vec3d myPos = new Vec3d(mc.player.getX(), mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()), mc.player.getZ());
        Vec3d rotVec = getVectorForRotation(90, 0);
        Vec3d multiplied = myPos.add(rotVec.x * height.get(), rotVec.y * height.get(), rotVec.z * height.get());
        HitResult hitResult = mc.world.raycast(new RaycastContext(myPos, multiplied, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, mc.player));

        if (!avoidEdges.get() || hitResult != null) {
            if (autoThirdPerson.get()) {
                setThirded(true);
                mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            }
            if (behind.get()) {
                double xPos = target.getX() + -Math.sin(Math.toRadians(target.getYaw())) * -2, zPos = target.getZ() + Math.cos(Math.toRadians(target.getYaw())) * -2;
                event.setX(movementSpeed * -MathHelper.sin((float) Math.toRadians(RotationUtil.getRotations(xPos, target.getY(), zPos)[0])));
                event.setZ(movementSpeed * MathHelper.cos((float) Math.toRadians(RotationUtil.getRotations(xPos, target.getY(), zPos)[0])));
            } else {
                event.setX(movementSpeed * -MathHelper
                        .sin((float) Math.toRadians(RotationUtil.getRotations(target.getX() + posX, target.getY(), target.getZ() + posY)[0])));
                event.setZ(movementSpeed * MathHelper
                        .cos((float) Math.toRadians(RotationUtil.getRotations(target.getX() + posX, target.getY(), target.getZ() + posY)[0])));
            }
        } else {
            event.setX(0);
            event.setZ(0);
        }

        double x = Math.abs(target.getX() + posX - mc.player.getX());
        double z = Math.abs(target.getZ() + posY - mc.player.getZ());
        double sqrt = Math.sqrt(x * x + z * z);

        if (sqrt <= dist) {
            position = position + (inverted ? -1 : 1) % positionsCount;
        } else if (sqrt > 3) {
            position = getClosestPoint(target);
        }
    }

    private double getRadius(Entity target) {
        if (dynamicRange.get()) {
            if (target.timeUntilRegen <= switchHurtTick.get().intValue()) {
                return attackRadius.get().doubleValue();
            } else {
                return safeRadius.get().doubleValue();
            }
        } else {
            return radius.get().doubleValue();
        }
    }


    protected final Vec3d getVectorForRotation(float pitch, float yaw) {
        float f = MathHelper.cos((float) (Math.toRadians(-yaw) - (float) Math.PI));
        float f1 = MathHelper.sin((float) (Math.toRadians(-yaw) - (float) Math.PI));
        float f2 = -MathHelper.cos((float) Math.toRadians(-pitch));
        float f3 = MathHelper.sin((float) Math.toRadians(-pitch));
        return new Vec3d(f1 * f2, f3, f * f2);
    }

    private boolean isVoidBelow(double x, double y, double z) {
        for (int i = (int) y; i > 0; i--) {
            if (!mc.world.getBlockState(BlockPos.ofFloored(x, i, z)).isAir()) {
                return true;
            }
        }
        return false;
    }

    private int getClosestPoint(Entity target) {
        return getPoints(target).stream().sorted(Comparator.comparingDouble(Point::getDistanceToPlayer)).collect(Collectors.toList()).get(0).poscount;
    }

    private boolean isCollided() {
        return mc.world
                .getBlockCollisions(mc.player, mc.player.getBoundingBox().offset(0, 0, -0.5))
                .iterator().hasNext() || mc.world
                .getBlockCollisions(mc.player, mc.player.getBoundingBox().offset(0.5, 0, 0.0))
                .iterator().hasNext() || mc.world
                .getBlockCollisions(mc.player, mc.player.getBoundingBox().offset(0, 0, 0.5))
                .iterator().hasNext() || mc.world
                .getBlockCollisions(mc.player, mc.player.getBoundingBox().offset(-0.5, 0, 0.0))
                .iterator().hasNext();
    }

    private boolean space() {
        return !space.get() || mc.options.jumpKey.isPressed();
    }

    public boolean support() {
        return space() && modules.contains("Speed") && isEnabled(Speed.class);
    }

    public boolean shouldTarget() {
        return isEnabled(KillAura.class) && getModule(KillAura.class).getTarget() != null && mc.player
                .canSee(getModule(KillAura.class).getTarget()) && (!this.target.get() || novoline
                .getPlayerManager().hasType(getModule(KillAura.class).getTarget().getName().getString(), TARGET)) //
                && MoveUtils.getDistance2D(mc.player, getModule(KillAura.class).getTarget()) < getModule(KillAura.class)
                .getRange().get() + 2 && mc.player.getY() >= getModule(KillAura.class).getTarget().getY() - 3.4//
                && getModule(KillAura.class).getTarget().isAlive() && MoveUtils
                .isMoving(mc.player) && mc.player.getY() <= getModule(KillAura.class)
                .getTarget().getY() + 3.4 && support();
    }

    public void setInverted(boolean inverted) {
        this.inverted = inverted;
    }

    public boolean isInverted() {
        return inverted;
    }

    private List<Point> getPoints(Entity target) {
        List<Point> points = new CopyOnWriteArrayList<>();
        double rad = getRadius(target);
        final int positionsCount = (int) ((int) (Math.PI * rad) * pointsMultiplier.get());
        for (int i = 0; i <= positionsCount; i++) {
            double radianPerPosition = DOUBLED_PI / (float) positionsCount, // @off
                    posX = MathHelper.sin((float) (radianPerPosition * i)) * rad,
                    posY = MathHelper.cos((float) (radianPerPosition * i)) * rad; // @on
            points.add(new Point(target.getX() + posX, target.getZ() + posY, i));
        }
        return points;
    }

    @EventTarget
    public void onRender3D(Render3DEvent render3DEvent) {
        KillAura aura = getModule(KillAura.class);
        RenderUtils.pre3D();

        if (aura.getTarget() != null &&
                points.get() &&
                lerpDistanceTo(mc.player, aura.getTarget()) < aura.getRange().get() &&
                aura.getTarget().isAlive() &&
                shouldTarget()) {

            renderCicle(5, aura, render3DEvent, 0xFF000000);
            renderCicle(2, aura, render3DEvent, color.getAwtColor().getRGB());
        }
        RenderUtils.post3D();
    }


    private void renderCicle(long lw, KillAura aura, Render3DEvent render3DEvent, int argb) {
        // PORT: GL11.glLineWidth has no modern equivalent; RenderLayers.lines() renders at
        // the pipeline's line width, so the lw parameter no longer thickens the circle.
        double rad = getRadius(aura.getTarget());
        double piDivider = Math.PI * 2 / (Math.PI * rad * pointsMultiplier.get());
        Entity target = aura.getTarget();
        Vec3d camera = RenderUtils.cameraPos();
        double partialTicks = render3DEvent.getPartialTicks();

        List<Vec3d> strip = new ArrayList<>();
        for (double d = 0; d < Math.PI * 2; d += piDivider) {
            strip.add(new Vec3d( // @off
                    target.lastX + (target.getX() - target.lastX) * partialTicks + Math.sin(d) * rad - camera.x,
                    target.lastY + (target.getY() - target.lastY) * partialTicks - camera.y,
                    target.lastZ + (target.getZ() - target.lastZ) * partialTicks + Math.cos(d) * rad - camera.z)); // @on
        }
        strip.add(new Vec3d( // @off
                target.lastX + (target.getX() - target.lastX) * partialTicks + Math.sin(0) * rad - camera.x,
                target.lastY + (target.getY() - target.lastY) * partialTicks - camera.y,
                target.lastZ + (target.getZ() - target.lastZ) * partialTicks + Math.cos(0) * rad - camera.z)); // @on

        RenderUtils.submitWorld(RenderLayers.lines(), (entry, vc) -> {
            Matrix4f m = entry.getPositionMatrix();
            for (int i = 0; i + 1 < strip.size(); i++) {
                Vec3d a = strip.get(i), b = strip.get(i + 1);
                Vector4f va = m.transform(new Vector4f((float) a.x, (float) a.y, (float) a.z, 1.0F));
                Vector4f vb = m.transform(new Vector4f((float) b.x, (float) b.y, (float) b.z, 1.0F));
                vc.vertex(va.x, va.y, va.z).color(argb);
                vc.vertex(vb.x, vb.y, vb.z).color(argb);
            }
        });
    }


    private int getArrayRainbowHue(int counter) {
        final int delay = 100 * 5, // @off
                width = 190; // @on
        final float brightness = (counter * (0.2F - 0.001F * width) + (currentTimeMillis() % delay) / (float) delay) % 1F;
        final float[] hudHSB = color.getHSB();
        return Color.getHSBColor(hudHSB[0], hudHSB[1], brightness < 0.4F ? 0.9F - brightness : brightness).getRGB();
    }

    public BooleanProperty getTarget() {
        return this.target;
    }

    public BooleanProperty isOnSpace() {
        return space;
    }

    public boolean isThirded() {
        return thirded;
    }

    public void setThirded(boolean thirded) {
        this.thirded = thirded;
    }

    //endregion

    public static class Point {

        public double x;
        public double z;
        public int poscount;

        public Point(double x, double z, int poscount) {
            this.x = x;
            this.z = z;
            this.poscount = poscount;
        }

        public double getDistanceToPlayer() {
            double x2 = Math.abs(MinecraftClient.getInstance().player.getX() - x);
            double z2 = Math.abs(MinecraftClient.getInstance().player.getZ() - z);
            return Math.sqrt(x2 * x2 + z2 * z2);
        }

    }

}
