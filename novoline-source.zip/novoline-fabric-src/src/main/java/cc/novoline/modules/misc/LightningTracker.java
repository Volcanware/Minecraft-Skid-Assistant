package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.IntProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.visual.Waypoints;
import cc.novoline.utils.DebugUtil;
import cc.novoline.utils.notifications.NotificationType;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;

public class LightningTracker extends AbstractModule {

    @Property("auto-waypoint")
    BooleanProperty auto_waypoint = PropertyFactory.booleanFalse();
    @Property("additional_y")
    private IntProperty add_y = PropertyFactory.createInt(10).minimum(10).maximum(90);

    public LightningTracker(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.MISC, "LightningTracker", "Lightning Tracker");
        Manager.put(new Setting("LT_ADD_Y", "Addition Y", SettingType.SLIDER, this, add_y, 5));
        Manager.put(new Setting("LT_AUTO_WP", "Auto waypoint", SettingType.CHECKBOX, this, auto_waypoint));
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            // PORT: S29PacketSoundEffect -> PlaySoundS2CPacket (sound is a RegistryEntry<SoundEvent>)
            if (event.getPacket() instanceof PlaySoundS2CPacket) {
                PlaySoundS2CPacket packet = (PlaySoundS2CPacket) event.getPacket();

                if (packet.getSound().value() == SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER) {
                    int x = (int) packet.getX(), y = (int) packet.getY() + add_y.get(), z = (int) packet.getZ();

                    novoline.getNotificationManager().pop(getDisplayName(), "Lightning detected " + x + " " + y + " " + z, 3_000, NotificationType.INFO);
                    String command = mc.isInSingleplayer() ? "/tp " : ".tp ", coords = x + " " + y + " " + z;
                    MutableText coordinates = Text.literal(coords);

                    // PORT: ClickEvent/HoverEvent are records in 1.21.11; RunCommand dispatches through
                    // runClickEventCommand instead of sendChatMessage (see hooks)
                    coordinates.setStyle(coordinates.getStyle().withHoverEvent(new HoverEvent.ShowText(Text.literal(command + coords))));
                    coordinates.setStyle(coordinates.getStyle().withClickEvent(new ClickEvent.RunCommand(command + coords)));
                    MutableText message = DebugUtil.prefix(getDisplayName()).toText().append("Lightning detected ");

                    message.append(coordinates);
                    mc.inGameHud.getChatHud().addMessage(message);
                    Waypoints waypoints = getModule(Waypoints.class);

                    if (auto_waypoint.get()) {
                        for (Waypoints.Waypoint waypoint : waypoints.getWaypointsList()) {
                            if (waypoint.getName().equals("Lightning") && waypoint.getX() == x && waypoint.getY() == y && waypoint.getZ() == z) {
                                return;
                            }
                        }

                        waypoints.addWaypoint(new Waypoints.Waypoint("Lightning", x, y, z));
                    }
                }
            }
        }
    }
}
