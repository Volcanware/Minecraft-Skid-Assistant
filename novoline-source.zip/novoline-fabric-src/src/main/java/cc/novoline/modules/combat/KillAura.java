package cc.novoline.modules.combat;


import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.EventTarget;
import cc.novoline.events.events.*;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.modules.exploits.Blink;
import cc.novoline.modules.exploits.Teleport;
import cc.novoline.modules.move.Scaffold;
import cc.novoline.modules.player.Freecam;
import cc.novoline.utils.Timer;
import cc.novoline.utils.*;
import cc.novoline.utils.fonts.impl.Fonts;
import cc.novoline.utils.notifications.NotificationType;
import cc.novoline.utils.pathfinding.AStarCustomPathfinder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.GolemEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import org.jetbrains.annotations.NotNull;

import java.awt.*;
import cc.novoline.mixin.PlayerInteractEntityC2SPacketAccessor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static cc.novoline.gui.screen.setting.SettingType.COLOR_PICKER;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createColor;
import static cc.novoline.utils.PlayerUtils.lerpDistanceTo;

public final class KillAura extends AbstractModule {

    /* fields */
    private Entity target;
    private int switchIndex;
    private List<Entity> targetList = new CopyOnWriteArrayList<>();
    private final Timer timerAttack = new Timer(), timerSwitch = new Timer(), lossTimer = new Timer();
    private final Dimension screenSize = cc.novoline.utils.AwtCompat.screenSize();
    private float yaw, pitch, iyaw, ipitch, prevIYaw, prevIPitch, alpha;
    private final List<Packet<?>> toDispatch = new ArrayList<>();
    private boolean blinking, blocking;

    /* properties @off */
    @Property("mode")
    private final StringProperty mode = PropertyFactory.createString("Switch").acceptableValues("Switch", "Single", "MW Infinite");
    @Property("switch-delay")
    private final FloatProperty switchDelay = PropertyFactory.createFloat(400.0F).minimum(50.0F).maximum(1000.0F);
    @Property("rejoin")
    private final IntProperty rejoin = PropertyFactory.createInt(3500).minimum(3100).maximum(5000);
    @Property("aps")
    private final DoubleProperty aps = PropertyFactory.createDouble(5.0D).minimum(1.0D).maximum(18.0D);
    @Property("range")
    private final DoubleProperty range = PropertyFactory.createDouble(3.5D).minimum(1.0D).maximum(7.0D);
    @Property("wall-range")
    private final DoubleProperty wallRange = PropertyFactory.createDouble(3.5D).minimum(1.0D).maximum(7.0D);
    @Property("block-range")
    private final DoubleProperty blockRange = PropertyFactory.createDouble(3.5D).minimum(1.0D).maximum(10.0D);
    @Property("fov-check")
    private final IntProperty fovCheck = PropertyFactory.createInt(180).minimum(1).maximum(180);
    @Property("rotations-smoothness")
    private final IntProperty smoothness = PropertyFactory.createInt(60).minimum(1).maximum(100);
    @Property("targets")
    private final ListProperty<String> targets = PropertyFactory.createList("Players").acceptableValues("Players", "Animals", "Mobs", "Invisibles");
    @Property("aura-sort")
    private final StringProperty sort = PropertyFactory.createString("Distance").acceptableValues("Distance", "Health", "Armor", "FOV", "HurtTime");
    @Property("filters")
    private final ListProperty<String> filters = PropertyFactory.createList("Teams").acceptableValues("Teams", "Users", "Armor");
    @Property("particles")
    private final ListProperty<String> particles = PropertyFactory.createList("Enchant").acceptableValues("Enchant", "Critical");
    @Property("auto-block")
    private final BooleanProperty autoBlock = PropertyFactory.booleanFalse();
    @Property("target-hud")
    private final BooleanProperty targetHud = PropertyFactory.booleanFalse();
    @Property("autodisable")
    private final ListProperty<String> autoDisable = PropertyFactory.createList("Death").acceptableValues("World Change", "Game End", "Death");
    @Property("blink")
    private final BooleanProperty blink = PropertyFactory.booleanFalse();
    @Property("raytrace")
    private final BooleanProperty raytrace = PropertyFactory.booleanFalse();
    @Property("lag-check")
    private final BooleanProperty lagCheck = PropertyFactory.booleanFalse();
    @Property("visualize-range")
    private final BooleanProperty visRange = PropertyFactory.booleanFalse();
    @Property("color")
    private final ColorProperty color = createColor(0xFFFFFFFF);
    @Property("th-x")
    private final IntProperty thx = PropertyFactory.createInt((int) screenSize.getWidth() / 4).minimum(1).maximum((int) screenSize.getWidth() / 2);
    @Property("th-y")
    private final IntProperty thy = PropertyFactory.createInt((int) screenSize.getHeight() / 4).minimum(1).maximum((int) screenSize.getHeight() / 2);
    //  @Property("hvh")
    //  private final KeyBindProperty hvh = PropertyFactory.keyboardKeyBinding(Keyboard.KEY_N);


    /* constructors @on */
    public KillAura(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Killaura", "Kill Aura", EnumModuleType.COMBAT, "Automatically attacks entities around you");
        Manager.put(new Setting("AURA_MODE", "Mode", SettingType.COMBOBOX, this, mode));
        Manager.put(new Setting("AURA_SORT", "Sort by", SettingType.COMBOBOX, this, sort, () -> mode().equalsIgnoreCase("Single") || mode.equalsIgnoreCase("MW Infinite")));
        Manager.put(new Setting("AURA_REJOIN_DELAY", "Rejoin Delay", SettingType.SLIDER, this, rejoin, 100, () -> mode.get().equals("MW Infinite")));
        Manager.put(new Setting("SWITCH_DELAY", "Switch Delay", SettingType.SLIDER, this, switchDelay, 50, () -> mode().equalsIgnoreCase("Switch")));
        Manager.put(new Setting("APS", "APS", SettingType.SLIDER, this, aps, 1.0D));
        Manager.put(new Setting("RANGE", "Range", SettingType.SLIDER, this, range, 0.1));
        Manager.put(new Setting("BLOCK_RANGE", "Block Range", SettingType.SLIDER, this, blockRange, 0.1));
        Manager.put(new Setting("WALL_RANGE", "Wall Range", SettingType.SLIDER, this, wallRange, 0.1));
        Manager.put(new Setting("AURA_FOV", "FOV Check", SettingType.SLIDER, this, fovCheck, 1));
        Manager.put(new Setting("AURA_FOV", "Angle Smoothing", SettingType.SLIDER, this, smoothness, 5));
        Manager.put(new Setting("TARGETS", "Targets", SettingType.SELECTBOX, this, targets));
        Manager.put(new Setting("KA_FILTER", "Filters", SettingType.SELECTBOX, this, filters));
        Manager.put(new Setting("KA_PARTICLES", "Particles", SettingType.SELECTBOX, this, particles));
        Manager.put(new Setting("KA_LAG_CHECK", "Lag Check", SettingType.CHECKBOX, this, lagCheck));
        Manager.put(new Setting("KA_RAY_TRACE", "Ray Trace", SettingType.CHECKBOX, this, raytrace));
        Manager.put(new Setting("KA_VIS_RANGE", "Visualize Range", SettingType.CHECKBOX, this, visRange));
        Manager.put(new Setting("KA_RANGE_COLOR", "Range Color", COLOR_PICKER, this, color, null, visRange::get));
        Manager.put(new Setting("KA_BLINK", "Blink", SettingType.CHECKBOX, this, blink));
        Manager.put(new Setting("AUTOBLOCK", "AutoBlock", SettingType.CHECKBOX, this, autoBlock));
        Manager.put(new Setting("TAR_HUD", "Target HUD", SettingType.CHECKBOX, this, targetHud));
        Manager.put(new Setting("KADISABLE", "Disable On", SettingType.SELECTBOX, this, autoDisable));
        //  Manager.put(new Setting("KA_HVH", "HVH preset", SettingType.BINDABLE, this, hvh));
    }

    //methods
    @Override
    public void onDisable() {
        yaw = iyaw = mc.player.getYaw();
        pitch = ipitch = mc.player.getPitch();
        target = null;
        targetList.clear();
        dispatchPackets();
    }

    @Override
    public void onEnable() {
        setSuffix(mode.get());
        alpha = 0;
        iyaw = mc.player.getYaw();
        ipitch = mc.player.getPitch();
        lossTimer.reset();

        if (blink.get()) {
            toDispatch.clear();
            blinking = true;
        } else {
            blinking = false;
        }
    }

    private boolean hasArmor(@NotNull PlayerEntity e) {
        return !e.getEquippedStack(EquipmentSlot.FEET).isEmpty() || !e.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
                || !e.getEquippedStack(EquipmentSlot.CHEST).isEmpty() || !e.getEquippedStack(EquipmentSlot.HEAD).isEmpty();
    }

    private boolean heldSword() {
        // PORT: ItemSword is flattened away; swords are the ItemTags.SWORDS tag
        return !mc.player.getMainHandStack().isEmpty() && mc.player.getMainHandStack().isIn(net.minecraft.registry.tag.ItemTags.SWORDS);
    }

    private boolean isInFOV() {
        if (target != null) {
            float[] rotationPosition = RotationUtil.getAngles((LivingEntity) target);
            int pitchByPos = (int) rotationPosition[1], yawByPos = (int) rotationPosition[0], yaw = (int) mc.player.getYaw(),
                    pitch = (int) mc.player.getPitch(),
                    // PORT-FIX: angles wrap — |170 - -170| = 340 deg looked like >180 and
                    // blocked shouldAttack at fovCheck=180. Take the wrapped difference.
                    differenceYaw = Math.abs((int) MathHelper.wrapDegrees(yaw - yawByPos)),
                    differencePitch = Math.abs(pitch - pitchByPos);

            return differenceYaw <= fovCheck.get() && differencePitch <= fovCheck.get();
        }

        return false;
    }

    public boolean serverLag() {
        return lagCheck.get() && lossTimer.getLastDelay() >= 100;
    }

    public boolean shouldAttack() {
        return target != null && target.isAlive() && lerpDistanceTo(mc.player, target) <=
                (mc.player.canSee(target) ? range() : wallRange()) && isInFOV() && !isEnabled(Scaffold.class);
    }

    public boolean shouldRotate() {
        return shouldAttack() && !serverLag() && !isEnabled(Scaffold.class) && !mc.interactionManager.isBreakingBlock();
    }

    public boolean shouldBlock() {
        return autoBlock.get() && target != null && heldSword() && target.isAlive() && isEnabled() && !mc.interactionManager.isBreakingBlock() &&
                lerpDistanceTo(mc.player, target) <= (mc.player.canSee(target) ? blockRange() : wallRange()) && !isEnabled(Scaffold.class);
    }

    private boolean isAutismShopKeeperCheck(Entity target) {
        Text component = target.getDisplayName();
        String formatted = getFormattedText(component);
        String unFormatted = component.getString();
        boolean first = !formatted.substring(0, formatted.length() - 2).contains("\u00A7");
        boolean second = formatted.substring(formatted.length() - 2).contains("\u00A7");
        return ServerUtils.isHypixel() && ServerUtils.serverIs(Servers.BW) && first && second;
    }

    // PORT: IChatComponent#getFormattedText emits \u00A7 formatting codes; rebuilt over Text style visits
    //       (shared framework helper should ideally live in a util — copied from AutoHypixel's approach).
    static String getFormattedText(Text text) {
        if (text == null) {
            return "";
        }

        StringBuilder builder = new StringBuilder();
        text.visit((style, string) -> {
            TextColor color = style.getColor();

            if (color != null) {
                Formatting formatting = formattingByRgb(color.getRgb());

                if (formatting != null) {
                    builder.append('\u00A7').append(formatting.getCode());
                }
            }

            if (style.isBold()) builder.append("\u00A7l");
            if (style.isItalic()) builder.append("\u00A7o");
            if (style.isUnderlined()) builder.append("\u00A7n");
            if (style.isStrikethrough()) builder.append("\u00A7m");
            if (style.isObfuscated()) builder.append("\u00A7k");
            builder.append(string).append("\u00A7r");
            return Optional.empty();
        }, Style.EMPTY);
        return builder.toString();
    }

    private static Formatting formattingByRgb(int rgb) {
        for (Formatting formatting : Formatting.values()) {
            Integer colorValue = formatting.getColorValue();

            if (formatting.isColor() && colorValue != null && colorValue == rgb) {
                return formatting;
            }
        }

        return null;
    }

    private double getYawDifference(Entity e) {
        final float[] rotationPosition = RotationUtil.getAngles((LivingEntity) e);
        final float yaw = (int) rotationPosition[0], differenceYaw;
        differenceYaw = mc.player.getYaw() > yaw ? mc.player.getYaw() - yaw : yaw - mc.player.getYaw();
        return differenceYaw;
    }

    private boolean goBack;
    private Timer swapLobbyStopwatch = new Timer();

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        if (goBack) {
            // PORT: C01PacketChatMessage("/back") — slash commands ride CommandExecutionC2SPacket (no leading slash)
            sendPacketNoEvent(new CommandExecutionC2SPacket("back"));
            goBack = false;
        }
    }

    @EventTarget
    public void targetSwitching(MotionUpdateEvent e) {
        if (e.getState().equals(MotionUpdateEvent.State.PRE)) {

            if (mode.get().equals("MW Infinite")) {
                if (swapLobbyStopwatch.delay(rejoin.get())) {
                    sendPacketNoEvent(new CommandExecutionC2SPacket("hub"));
                    goBack = true;
                    swapLobbyStopwatch.reset();
                }
            }

            double clamp = MathHelper.clamp(mc.getCurrentFps() / 30, 1, 9999);

            if (alpha < 1) {
                alpha = (float) (alpha + (1 - alpha) * (0.99F / clamp));
            }

            alpha = MathHelper.clamp(alpha, 0, 1);

            if (!mc.player.getInventory().getStack(0).isEmpty()) {
                if (mc.player.getInventory().getStack(0).getItem() == Items.COMPASS) {
                    if (mc.player.getInventory().getStack(0).getName().getString().contains("Teleporter")) {
                        target = null;
                    }
                }
            }

            if (targetsInRange() > 0) {
                targetList = getTargetsFromRange();
            } else {
                targetList = getEntityList(sort.get());
            }

            if (target != null && !target.isAlive()) {
                target = null;
            }

            if (targetList != null && !targetList.isEmpty()) {
                if (timerSwitch.delay(switchDelay.get())) {
                    switchAndReset();
                }

                if (!isContainsTarget(mode().equalsIgnoreCase("Switch"))) {
                    if (target != null) {
                        if (lerpDistanceTo(mc.player, target) > range() && targetsInRange() > 0) {
                            target = getTargetFromRange();
                        } else if (lerpDistanceTo(mc.player, target) > blockRange()) {
                            target = null;
                            switchAndReset();
                        } else if (!target.isAlive() && ((LivingEntity) target).getHealth() <= 0) {
                            target = null;
                            switchAndReset();
                        } else if (mode().equalsIgnoreCase("Switch")) {
                            target = targetList.get(switchIndex % targetList.size());
                        }

                    } else {
                        target = targetList.get(mode().equalsIgnoreCase("Switch") ? switchIndex % targetList.size() : 0);
                    }

                } else {
                    for (Entity entity : targetList) {
                        if (novoline.getPlayerManager().hasType(entity.getName().getString(), PlayerManager.EnumPlayerType.TARGET)) {
                            target = entity;
                        }
                    }
                }
            }

            prevIPitch = ipitch;
            prevIYaw = iyaw;
        }
    }

    public float getPrevIPitch() {
        return prevIPitch;
    }

    public float getPrevIYaw() {
        return prevIYaw;
    }

    private void switchAndReset() {
        if (targetList != null && !targetList.isEmpty()) {
            switchIndex = (switchIndex + 1) % targetList.size();
        }
        timerSwitch.reset();
    }

    private boolean rayTraycing(Entity target) {
        return !raytrace.get() || novoline.getPlayerManager().hasType(target.getName().getString(), PlayerManager.EnumPlayerType.TARGET) || getPosition() != null || mc.interactionManager.isBreakingBlock();
    }

    private void attackEntity(Entity target) {
        if (timerAttack.delay(1000L / aps.get().longValue())) {
            EventManager.call(new AttackEvent());

            ArrayList<cc.novoline.utils.pathfinding.Vec3> vec3s = computePath(new cc.novoline.utils.pathfinding.Vec3(mc.player.getX(), mc.player.getY(), mc.player.getZ()), new cc.novoline.utils.pathfinding.Vec3(target.getX(), target.getY(), target.getZ()));

            if (mode.equals("MW Infinite")) {
                for (cc.novoline.utils.pathfinding.Vec3 vec3 : vec3s) {
                    sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(vec3.getX(), vec3.getY(), vec3.getZ(), true, mc.player.horizontalCollision));
                    sendPacketNoEvent(new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision));
                }
            }

            if (shouldBlock()) {
                sendPacketNoEvent(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, Direction.DOWN));
                //   print(mc.player.age, "unBlock");
                blocking = false;
            }

            mc.player.swingHand(Hand.MAIN_HAND);
            sendPacket(PlayerInteractEntityC2SPacket.attack(target, mc.player.isSneaking()));

            if (mode.equals("MW Infinite")) {
                Collections.reverse(vec3s);

                for (cc.novoline.utils.pathfinding.Vec3 vec3 : vec3s) {
                    sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(vec3.getX(), vec3.getY(), vec3.getZ(), true, mc.player.horizontalCollision));
                    sendPacketNoEvent(new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision));
                }
            }

            if (particles.contains("Enchant")) {
                mc.player.addEnchantedHitParticles(target);
            }

            if (particles.contains("Critical")) {
                mc.player.addCritParticles(target);
            }

            timerAttack.reset();
        }
    }

    @EventTarget
    public void onMotions(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (shouldBlock() || blocking /*&& mc.player.age % 2 != 0*/) {
                sendPacketNoEvent(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, Direction.DOWN));
                //print(mc.player.age, "unBlock");
                blocking = false;
            }

        } else {
            if (shouldAttack() && rayTraycing(target) && !serverLag()) {
                attackEntity(target);
            }

            if (shouldBlock()) {
                interactAutoBlock();
                mc.player.getMainHandStack().use(mc.world, mc.player, Hand.MAIN_HAND);

                //  if (mc.player.age % 2 == 0) {
                sendPacketNoEvent(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
                //print(mc.player.age, "Block");
                blocking = true;
                //   }
            }
        }
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        setSuffix(mode());
    }

    @EventTarget
    public void onSlowDown(SlowdownEvent event) {
        if (shouldBlock()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onSend(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.OUTGOING)) {
            if (blinking) {
                if (event.getPacket() instanceof PlayerMoveC2SPacket) {
                    PlayerMoveC2SPacket packet = (PlayerMoveC2SPacket) event.getPacket();

                    if (packet.changesPosition()) {
                        toDispatch.add(event.getPacket());
                        event.setCancelled(true);
                    }
                }

                if (event.getPacket() instanceof PlayerInteractEntityC2SPacket) {
                    PlayerInteractEntityC2SPacket packet = (PlayerInteractEntityC2SPacket) event.getPacket();
                    Entity packetEntity = getPacketEntity(packet);

                    if (isAttack(packet) && packetEntity != null && packetEntity.equals(target)) {
                        dispatchPackets();
                        blinking = false;
                    }
                }

                if (toDispatch.size() > 60) {
                    dispatchPackets();
                    novoline.getNotificationManager().pop(getDisplayName(), "Packet buffer overloaded!", 2000, NotificationType.ERROR);
                    blinking = false;
                }
            }

            if (shouldBlock() || blocking) {
                if (event.getPacket() instanceof PlayerActionC2SPacket) {
                    PlayerActionC2SPacket packet = (PlayerActionC2SPacket) event.getPacket();

                    if (packet.getAction().equals(PlayerActionC2SPacket.Action.RELEASE_USE_ITEM)) {
                        event.setCancelled(true);
                    }
                }

                // PORT: C08PacketPlayerBlockPlacement.getPlacedBlockDirection() == 255 was the
                // use-item variant -> PlayerInteractItemC2SPacket in modern versions
                if (event.getPacket() instanceof PlayerInteractItemC2SPacket) {
                    event.setCancelled(true);
                }
            }

        } else {
            lossTimer.reset();
        }
    }

    // PORT: C02PacketUseEntity's action+entity are private behind a handler callback; the entity id
    //       is reflected out of the private field, the action by dispatching through the handler.
    private static boolean isAttack(PlayerInteractEntityC2SPacket packet) {
        boolean[] attack = new boolean[1];
        packet.handle(new PlayerInteractEntityC2SPacket.Handler() {
            @Override
            public void interact(Hand hand) {
            }

            @Override
            public void interactAt(Hand hand, Vec3d vec3d) {
            }

            @Override
            public void attack() {
                attack[0] = true;
            }
        });
        return attack[0];
    }

    private static Entity getPacketEntity(PlayerInteractEntityC2SPacket packet) {
        int entityId = ((PlayerInteractEntityC2SPacketAccessor) packet).novoline$getEntityId();
        return MinecraftClient.getInstance().world.getEntityById(entityId);
    }


    @EventTarget
    public void Rotations(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (shouldRotate()) {
                float frac = MathHelper.clamp(1f - smoothness.get() / 100f, 0.1f, 1f);
                float[] rotations = RotationUtil.getAngles((LivingEntity) target);

                iyaw = iyaw + (rotations[0] - iyaw) * frac;
                ipitch = ipitch + (rotations[1] - ipitch) * frac;

                event.setYaw(yaw = iyaw);
                event.setPitch(pitch = ipitch);

            } else {
                iyaw = mc.player.getYaw();
                ipitch = mc.player.getPitch();
            }
        }
    }

    public float getIYaw() {
        return iyaw;
    }

    public float getIPitch() {
        return ipitch;
    }

    private boolean interactable(Block block) {
        return block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST || block == Blocks.CRAFTING_TABLE
                || block == Blocks.FURNACE || block == Blocks.ENDER_CHEST || block == Blocks.ENCHANTING_TABLE;
    }

    private void interactAutoBlock() {
        if (mc.options.useKey.isPressed()) {
            if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY
                    && ((EntityHitResult) mc.crosshairTarget).getEntity() != null) {
                sendPacket(PlayerInteractEntityC2SPacket.interact(((EntityHitResult) mc.crosshairTarget).getEntity(), mc.player.isSneaking(), Hand.MAIN_HAND));

            } else if (mc.crosshairTarget instanceof BlockHitResult
                    && interactable(mc.world.getBlockState(((BlockHitResult) mc.crosshairTarget).getBlockPos()).getBlock())) {
                // PORT: onPlayerRightClick(pos, facing-toward-player, hitVec) -> interactBlock(BlockHitResult);
                //       the hit result already carries the hit face.
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, (BlockHitResult) mc.crosshairTarget);
            }
        }
    }

    public boolean isValidEntity(@NotNull Entity target) {
        final boolean mobsTarget = targets.contains("Mobs"), animalsTarget = targets.contains("Animals"), //
                playersTarget = targets.contains("Players"), invisibleTarget = targets.contains("Invisibles");

        if (target.isAlive() && mc.player.getHealth() > 0.0F && !novoline.getPlayerManager()
                .hasType(target.getName().getString(), PlayerManager.EnumPlayerType.FRIEND)) {
            if (target instanceof HostileEntity || target instanceof SlimeEntity || target instanceof GolemEntity) {
                return mobsTarget && !(target.isInvisible() && !invisibleTarget);
            }

            if (target instanceof AnimalEntity || target instanceof VillagerEntity) {
                return animalsTarget && !(target.isInvisible() && !invisibleTarget);
            }

            if (target instanceof PlayerEntity) {
                return playersTarget
                        && target != mc.player
                        && (!filters.contains("Armor")
                        || hasArmor((PlayerEntity) target))
                        && (!filters.contains("Teams")
                        || !PlayerUtils
                        .inTeam(mc.player, target))
                        && !(target.isInvisible() && !invisibleTarget) &&
                        !isAutismShopKeeperCheck(target)
                        && (!filters.contains("Users"))
                        && target != getModule(Freecam.class).getFreecamEntity()
                        && target != getModule(Blink.class).getBlinkEntity()
                        && target != getModule(Teleport.class).getTeleportEntity();
            }
        }

        return false;
    }

    private boolean isContainsTarget(boolean isSwitch) {
        for (Entity entity : getEntityList(sort.get()).stream()
                .filter(entity -> lerpDistanceTo(mc.player, entity) < range())
                .collect(Collectors.toCollection(ObjectArrayList::new))) {
            if (novoline.getPlayerManager().hasType(entity.getName().getString(), PlayerManager.EnumPlayerType.TARGET)) {
                return true;
            }
        }

        return false;
    }

    private List<Entity> getEntityList(String sort) {
        List<Entity> list = StreamSupport.stream(mc.world.getEntities().spliterator(), false).filter(this::isValidEntity).collect(Collectors.toList());

        if (mode().equalsIgnoreCase("Single")) {
            switch (sort) {
                case "Distance":
                    list = list.stream().sorted(Comparator.comparing(o -> o.distanceTo(mc.player)))
                            .collect(Collectors.toCollection(ObjectArrayList::new));
                    break;
                case "Armor":
                    list = list.stream().sorted(Comparator.comparing(
                            o -> o instanceof PlayerEntity ? getProtection((PlayerEntity) o) :
                                    99999)).collect(Collectors.toCollection(ObjectArrayList::new));
                    break;
                case "Health":
                    list = list.stream().sorted(Comparator.comparing(o -> ((LivingEntity) o).getHealth()))
                            .collect(Collectors.toCollection(ObjectArrayList::new));
                    break;
                case "FOV":
                    list = list.stream().sorted(Comparator.comparing(this::getYawDifference))
                            .collect(Collectors.toCollection(ObjectArrayList::new));
                    break;
                case "HurtTime":
                    list = list.stream().sorted(Comparator.comparing(o -> o.timeUntilRegen))
                            .collect(Collectors.toCollection(ObjectArrayList::new));
                    break;
            }
        }
        if (mode.get().equals("MW Infinite")) {
            return list.stream().filter(this::isInReach).filter(e -> getFormattedText(e.getDisplayName()).startsWith("ยง")).collect(Collectors.toList());
        } else {
            return list.stream().filter(this::isInReach).collect(Collectors.toList());
        }
    }

    private List<Entity> getTargetsFromRange() {
        return getEntityList(sort.get()).stream().filter(e -> lerpDistanceTo(mc.player, e) <= range()).collect(Collectors.toList());
    }

    private int targetsInRange() {
        int i = 0;

        if (getEntityList(sort.get()).isEmpty()) {
            return 0;

        } else {
            for (Entity entity : getEntityList(sort.get())) {
                if (lerpDistanceTo(mc.player, entity) <= range()) {
                    i++;
                }
            }

            return i;
        }
    }

    private Entity getTargetFromRange() {
        for (Entity entity : getEntityList(sort.get())) {
            if (lerpDistanceTo(mc.player, entity) <= range()) {
                return entity;
            }
        }

        return null;
    }

    private float interpolateAngles(float fraction) {
        return 0;
    }

    // PORT: armorInventory (ItemStack[]) replaced by a lookup over the four armor equipment slots.
    private float getProtection(PlayerEntity player) {
        return getProtection(new ItemStack[]{
                player.getEquippedStack(EquipmentSlot.FEET), player.getEquippedStack(EquipmentSlot.LEGS),
                player.getEquippedStack(EquipmentSlot.CHEST), player.getEquippedStack(EquipmentSlot.HEAD)});
    }

    private float getProtection(ItemStack[] stack1) {
        float protection = 0;

        for (ItemStack stack : stack1) {
            if (stack != null && !stack.isEmpty()) {
                // PORT: ItemArmor/damageReduceAmount are gone; an "armor" stack has an EQUIPPABLE
                //       component and its value is the ARMOR attribute modifier total.
                if (stack.contains(DataComponentTypes.EQUIPPABLE) && stack.contains(DataComponentTypes.ATTRIBUTE_MODIFIERS)) {
                    AttributeModifiersComponent modifiers = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
                    int damageReduceAmount = (int) modifiers.applyOperations(EntityAttributes.ARMOR, 0,
                            stack.get(DataComponentTypes.EQUIPPABLE).slot());

                    protection += damageReduceAmount + (100 - damageReduceAmount) * enchantmentLevel(Enchantments.PROTECTION, stack) * 0.0075D;
                    protection += enchantmentLevel(Enchantments.BLAST_PROTECTION, stack) / 100d;
                    protection += enchantmentLevel(Enchantments.FIRE_PROTECTION, stack) / 100d;
                    protection += enchantmentLevel(Enchantments.THORNS, stack) / 100d;
                    protection += enchantmentLevel(Enchantments.UNBREAKING, stack) / 50d;
                    protection += enchantmentLevel(Enchantments.PROJECTILE_PROTECTION, stack) / 100d;
                }
            }
        }

        return protection;
    }

    // PORT: EnchantmentHelper.getEnchantmentLevel(effectId, stack) -> registry entry lookup
    private int enchantmentLevel(net.minecraft.registry.RegistryKey<net.minecraft.enchantment.Enchantment> key, ItemStack stack) {
        return EnchantmentHelper.getLevel(mc.world.getRegistryManager()
                .getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(key), stack);
    }


    private boolean isInReach(Entity target) {
        return lerpDistanceTo(mc.player, target) <= (mc.player.canSee(target) ?
                Math.max(range(), blockRange()) : wallRange());
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (targetHud.get()) {
            if (shouldAttack()) {
                if (target instanceof PlayerEntity && !(mc.currentScreen instanceof ChatScreen)) {
                    RenderUtils.renderTHUD(this, (PlayerEntity) target);
                }
            }
        }

        if (blinking) {
            ScaledResolution sr = new ScaledResolution(mc);
            int size = toDispatch.size();
            String color = "";

            if (size > 40) {
                color = "\u00A78";
            } else if (size > 20) {
                color = "\u00A77";
            }

            String sizeStr = color + toDispatch.size();
            Fonts.SF.SF_18.SF_18.drawString("Buffer size: " + sizeStr, sr.getScaledWidthStatic(mc) / 2 - 26, sr.getScaledHeightStatic(mc) / 2 + 10, 0xFFFFFF, true);
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (visRange.get()) {
            // PORT: GL11 line-strip -> RenderLayers.lines() vertex pairs on submitWorld; glLineWidth
            //       is not replicable (the lines layer is always 1px). Coords are camera-relative.
            RenderUtils.pre3D();
            Vec3d base = RenderUtils.interpolateRender(mc.player);
            int blackAlpha = ((int) (alpha * 255) & 0xFF) << 24;

            RenderUtils.submitWorld(RenderLayers.lines(), (entry, vc) -> {
                for (double d = 0; d < Math.PI * 2; d += Math.PI * 2 / 51) {
                    double x1 = base.x + Math.sin(d) * range.get(), // @off
                            z1 = base.z + Math.cos(d) * range.get(),
                            x2 = base.x + Math.sin(d + Math.PI * 2 / 51) * range.get(),
                            z2 = base.z + Math.cos(d + Math.PI * 2 / 51) * range.get(); // @on
                    vc.vertex(entry, (float) x1, (float) base.y, (float) z1).color(blackAlpha);
                    vc.vertex(entry, (float) x2, (float) base.y, (float) z2).color(blackAlpha);
                }
            });

            int argb = 0xFF000000 | (color.getAwtColor().getRed() << 16) | (color.getAwtColor().getGreen() << 8) | color.getAwtColor().getBlue();

            RenderUtils.submitWorld(RenderLayers.lines(), (entry, vc) -> {
                for (double d = 0; d < Math.PI * 2; d += Math.PI * 2 / 51) {
                    double x1 = base.x + Math.sin(d) * range.get(), // @off
                            z1 = base.z + Math.cos(d) * range.get(),
                            x2 = base.x + Math.sin(d + Math.PI * 2 / 51) * range.get(),
                            z2 = base.z + Math.cos(d + Math.PI * 2 / 51) * range.get(); // @on
                    vc.vertex(entry, (float) x1, (float) base.y, (float) z1).color(argb);
                    vc.vertex(entry, (float) x2, (float) base.y, (float) z2).color(argb);
                }
            });

            RenderUtils.post3D();
        }
    }

    @EventTarget
    public void onAutoDisable(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (ServerUtils.serverIs(Servers.DUELS) && event.getPacket() instanceof TitleS2CPacket) {
                final TitleS2CPacket packet = (TitleS2CPacket) event.getPacket();

                // PORT: TitleS2CPacket is a TITLE-only record now (the old Type check is implicit)
                final String text = packet.text().getString();

                if (text.equals("VICTORY!")) {
                    novoline.getNotificationManager().pop("Check chat for stats", 1000, NotificationType.INFO);
                    DebugUtil.log(true, "[" + Formatting.RED + "Stats" + Formatting.GRAY + "] " + Formatting.RESET + "Your hp: " + Formatting.GREEN + mc.player.getHealth());
                }

                if (text.equals("GAME OVER!")) {
                    novoline.getNotificationManager().pop("Check chat for stats", 1000, NotificationType.INFO);
                    DebugUtil.log(true, "[" + Formatting.RED + "Stats" + Formatting.GRAY + "] " + Formatting.RESET + "Opponent hp: " + Formatting.GREEN + ((LivingEntity) target).getHealth());
                }
            }
        }
    }

    private void dispatchPackets() {
        blinking = false;
        toDispatch.forEach(this::sendPacketNoEvent);
        toDispatch.clear();
    }

    public Vec3d getPosition() {
        float borderSize = target.getTargetingMargin();
        Vec3d positionEyes = RotationUtil.getPositionEyes(1);
        Vec3d startVec = RotationUtil.getVectorForRotation(getIPitch(), getIYaw());
        Vec3d endVec = positionEyes.add(startVec.x * range(), startVec.y * range(), startVec.z * range());
        return target.getBoundingBox().expand(borderSize, borderSize, borderSize).raycast(positionEyes, endVec).orElse(null);
    }

    private ArrayList<cc.novoline.utils.pathfinding.Vec3> computePath(cc.novoline.utils.pathfinding.Vec3 topFrom, cc.novoline.utils.pathfinding.Vec3 to) {
        if (!canPassThrow(BlockPos.ofFloored(topFrom.mc()))) {
            topFrom = topFrom.addVector(0, 1, 0);
        }
        AStarCustomPathfinder pathfinder = new AStarCustomPathfinder(topFrom, to);
        pathfinder.compute();

        int i = 0;
        cc.novoline.utils.pathfinding.Vec3 lastLoc = null;
        cc.novoline.utils.pathfinding.Vec3 lastDashLoc = null;
        ArrayList<cc.novoline.utils.pathfinding.Vec3> path = new ArrayList<>();
        ArrayList<cc.novoline.utils.pathfinding.Vec3> pathFinderPath = pathfinder.getPath();
        for (cc.novoline.utils.pathfinding.Vec3 pathElm : pathFinderPath) {
            if (i == 0 || i == pathFinderPath.size() - 1) {
                if (lastLoc != null) {
                    path.add(lastLoc.addVector(0.5, 0, 0.5));
                }
                path.add(pathElm.addVector(0.5, 0, 0.5));
                lastDashLoc = pathElm;
            } else {
                boolean canContinue = true;
                if (pathElm.squareDistanceTo(lastDashLoc) > 4 * 4) {
                    canContinue = false;
                } else {
                    double smallX = Math.min(lastDashLoc.getX(), pathElm.getX());
                    double smallY = Math.min(lastDashLoc.getY(), pathElm.getY());
                    double smallZ = Math.min(lastDashLoc.getZ(), pathElm.getZ());
                    double bigX = Math.max(lastDashLoc.getX(), pathElm.getX());
                    double bigY = Math.max(lastDashLoc.getY(), pathElm.getY());
                    double bigZ = Math.max(lastDashLoc.getZ(), pathElm.getZ());
                    cordsLoop:
                    for (int x = (int) smallX; x <= bigX; x++) {
                        for (int y = (int) smallY; y <= bigY; y++) {
                            for (int z = (int) smallZ; z <= bigZ; z++) {
                                if (!AStarCustomPathfinder.checkPositionValidity(x, y, z, false)) {
                                    canContinue = false;
                                    break cordsLoop;
                                }
                            }
                        }
                    }
                }
                if (!canContinue) {
                    path.add(lastLoc.addVector(0.5, 0, 0.5));
                    lastDashLoc = lastLoc;
                }
            }
            lastLoc = pathElm;
            i++;
        }
        return path;
    }

    private boolean canPassThrow(BlockPos pos) {
        // PORT: Material checks -> block class checks; passable = air / plants / climbable / fluid / signs
        Block block = MinecraftClient.getInstance().world.getBlockState(new BlockPos(pos.getX(), pos.getY(), pos.getZ())).getBlock();
        return block == Blocks.AIR || block == Blocks.CAVE_AIR || block == Blocks.VOID_AIR
                || block instanceof net.minecraft.block.PlantBlock || block instanceof net.minecraft.block.VineBlock
                || block == Blocks.LADDER || block == Blocks.WATER
                || block instanceof net.minecraft.block.AbstractSignBlock;
    }


    //endregion


    //region Lombok
    public Entity getTarget() {
        return target;
    }

    public void setTarget(Entity target) {
        this.target = target;
    }

    public StringProperty getMode() {
        return mode;
    }

    public String mode() {
        return mode.get();
    }

    public FloatProperty getSwitchDelay() {
        return switchDelay;
    }

    public DoubleProperty getAps() {
        return aps;
    }

    public DoubleProperty getRange() {
        return range;
    }

    public DoubleProperty getWallRange() {
        return wallRange;
    }

    public DoubleProperty getBlockRange() {
        return blockRange;
    }

    public double range() {
        return mode.get().equals("MW Infinite") ? 100 : range.get();
    }

    public double blockRange() {
        return mode.get().equals("MW Infinite") ? 100 : blockRange.get();
    }

    public double wallRange() {
        return mode.get().equals("MW Infinite") ? 100 : wallRange.get();
    }

    public IntProperty getFovCheck() {
        return fovCheck;
    }

    public ListProperty<String> getTargets() {
        return targets;
    }

    public ListProperty<String> getFilters() {
        return filters;
    }

    public ListProperty<String> getParticles() {
        return particles;
    }

    public BooleanProperty getAutoBlock() {
        return autoBlock;
    }

    public BooleanProperty getTargetHud() {
        return targetHud;
    }

    public ListProperty getAutoDisable() {
        return autoDisable;
    }

    public IntProperty getThx() {
        return thx;
    }

    public IntProperty getThy() {
        return thy;
    }

    public float getYaw() {
        return yaw;
    }

    public float getPitch() {
        return pitch;
    }

    public List<Entity> getTargetList() {
        return targetList;
    }

    public StringProperty getSort() {
        return sort;
    }

    public boolean lagCheck() {
        return lagCheck.get();
    }

    //endregion
}
