package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render2DEvent;
import cc.novoline.gui.screen.click.DiscordGUI;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.DoubleProperty;
import cc.novoline.modules.configurations.property.object.IntProperty;
import cc.novoline.utils.PlayerUtils;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.RotationUtil;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix3x2fStack;

import java.awt.*;

import static cc.novoline.gui.screen.setting.Manager.put;
import static cc.novoline.modules.PlayerManager.EnumPlayerType.TARGET;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createDouble;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createInt;
import static java.lang.Math.toRadians;

public final class Radar extends AbstractModule {

    private final Dimension screenSize = cc.novoline.utils.AwtCompat.screenSize();

    /* properties @off */
    @Property("alpha")
    private final IntProperty alpha = createInt(180).minimum(50).maximum(255);
    @Property("scale")
    private final DoubleProperty scale = createDouble(0.85D).minimum(0.25D).maximum(5.0D);
    @Property("x")
    private final IntProperty x = createInt(1).minimum(1).maximum((int) (screenSize.getWidth() / 2));
    @Property("y")
    private final IntProperty y = createInt(152).minimum(1).maximum((int) (screenSize.getHeight() / 2));
    @Property("size")
    private final IntProperty size = createInt(120).minimum(50).maximum(200);

    /* constructors @on */
    public Radar(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Radar", EnumModuleType.VISUALS, "Useful for games like uhc/sg");
        put(new Setting("RADAR_ALPHA", "Alpha", SettingType.SLIDER, this, this.alpha, 1));
        put(new Setting("RADAR_SCALE", "Scale", SettingType.SLIDER, this, this.scale, 0.05));
        put(new Setting("RADAR_X_POS", "X", SettingType.SLIDER, this, this.x, 5));
        put(new Setting("RADAR_Y_POS", "Y", SettingType.SLIDER, this, this.y, 5));
        put(new Setting("RADAR_SIZE", "Size", SettingType.SLIDER, this, this.size, 5));
    }

    /* events */
    @EventTarget
    public void radar(Render2DEvent e) {
        if (!(mc.currentScreen instanceof ChatScreen)) {
            renderRadar();
        }
    }

    public void renderRadar() {
        Matrix3x2fStack matrices = RenderUtils.context().getMatrices();
        matrices.pushMatrix();
        scale(); // PORT: inlined ScaleUtils.scale(mc)

        RenderUtils.guiQuad(x.get() - 1, y.get() - 1, x.get() + size.get() + 1, y.get() + size.get() + 1, new Color(29, 29, 29, 255).getRGB());
        RenderUtils.guiQuad(x.get(), y.get(), x.get() + size.get(), y.get() + size.get(), new Color(40, 40, 40, 255).getRGB());

        RenderUtils.guiQuad(x.get() + size.get() / 2 - 0.3F + 1, y.get(), x.get() + size.get() / 2 + 0.3F + 1, y.get() + size.get(), new Color(255, 255, 255, 50).getRGB());
        RenderUtils.guiQuad(x.get(), y.get() + size.get() / 2 - 0.3F, x.get() + size.get(), y.get() + size.get() / 2 + 0.3F, new Color(255, 255, 255, 50).getRGB());


        for (Entity entity : mc.world.getEntities()) { // PORT: getLoadedEntityList -> getEntities
            if (entity == mc.player) continue;
            if (entity instanceof PlayerEntity && !entity.isInvisible()) {

                float yawToEntity = RotationUtil.getYawToPoint(entity.getX(), entity.getZ());
                float yawDiff = -(yawToEntity - mc.player.getYaw() + 180);
                double yawDiffRad = toRadians(yawDiff);

                double x = Math.abs(mc.player.getX() - entity.getX());
                double z = Math.abs(mc.player.getZ() - entity.getZ());
                double distance = Math.sqrt(x * x + z * z) / scale.get();

                int color = 0xffffffff;
                if (novoline.playerManager.hasType(entity.getName().getString(), TARGET)) {
                    color = new Color(255, 59, 59, 255).getRGB();
                } else if (novoline.playerManager.hasType(entity.getName().getString(), TARGET)) {
                    color = new Color(169, 255, 43, 255).getRGB();
                } else if (PlayerUtils.inTeam(entity, mc.player)) {
                    color = new Color(0, 231, 255, 255).getRGB();
                }

                if (Math.sin(yawDiffRad) > 0 && Math.cos(yawDiffRad) < 0 &&
                        Math.sin(yawDiffRad) * distance < size.get() / 2 && -Math.cos(yawDiffRad) * distance < size.get() / 2 ||
                        Math.sin(yawDiffRad) < 0 && Math.cos(yawDiffRad) < 0 &&
                                -Math.sin(yawDiffRad) * distance < size.get() / 2 && -Math.cos(yawDiffRad) * distance < size.get() / 2 ||
                        Math.sin(yawDiffRad) > 0 && Math.cos(yawDiffRad) > 0 &&
                                Math.sin(yawDiffRad) * distance < size.get() / 2 && Math.cos(yawDiffRad) * distance < size.get() / 2 ||
                        Math.sin(yawDiffRad) < 0 && Math.cos(yawDiffRad) > 0 &&
                                -Math.sin(yawDiffRad) * distance < size.get() / 2 && Math.cos(yawDiffRad) * distance < size.get() / 2) {

                    RenderUtils.drawBorderedRect(
                            this.x.get() + size.get() / 2 +
                                    Math.sin(yawDiffRad) * distance - 1f,
                            this.y.get() + size.get() / 2 +
                                    Math.cos(yawDiffRad) * distance - 1f,

                            this.x.get() + size.get() / 2 +
                                    Math.sin(yawDiffRad) * distance + 1f,

                            this.y.get() + size.get() / 2 +
                                    Math.cos(yawDiffRad) * distance + 1f,
                            0.1f, color, color);
                }


            }
        }
        matrices.popMatrix();
    }

    /* PORT: ScaleUtils.scale(mc) inlined */
    private void scale() {
        if (!(mc.currentScreen instanceof DiscordGUI)) {
            Matrix3x2fStack matrices = RenderUtils.context().getMatrices();
            switch (mc.options.getGuiScale().getValue()) {
                case 0:
                    matrices.scale(0.5F, 0.5F);
                    break;
                case 1:
                    matrices.scale(2.0F, 2.0F);
                    break;
                case 3:
                    matrices.scale(0.6666666666666667F, 0.6666666666666667F);
            }
        }
    }

    public IntProperty getSize() {
        return size;
    }

    public IntProperty getX() {
        return x;
    }

    public IntProperty getY() {
        return y;
    }
}
