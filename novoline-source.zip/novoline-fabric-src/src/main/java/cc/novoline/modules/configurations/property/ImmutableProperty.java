package cc.novoline.modules.configurations.property;
import org.jetbrains.annotations.Nullable;


/**
 * @author xDelsy
 */
public interface ImmutableProperty<Type> extends Property<Type> {

    @Override
	default void set(@Nullable Type value) {
        throw new UnsupportedOperationException("Tried to change immutable property");
    }

}
