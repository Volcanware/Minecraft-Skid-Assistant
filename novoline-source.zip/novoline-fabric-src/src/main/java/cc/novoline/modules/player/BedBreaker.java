package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.combat.KillAura;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.IntProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.configurations.property.object.StringProperty;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.RotationUtil;
import net.minecraft.block.BedBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.BedPart;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.NotNull;

import java.awt.*;

import static cc.novoline.gui.screen.setting.SettingType.*;

public final class BedBreaker extends AbstractModule {

    private double currentDamage;
    private boolean digging;
    private BlockPos currentPos;

    BlockPos whiteListed = new BlockPos(0, 0, 0);

    @Property("mode")
    private final StringProperty mode = PropertyFactory.createString("Simple").acceptableValues("Simple", "Advanced");
    @Property("radious")
    private final IntProperty radius = PropertyFactory.createInt(4).minimum(3).maximum(5);
    @Property("draw-radius")
    private final BooleanProperty drawRadius = PropertyFactory.createBoolean(false);

    public BedBreaker(@NotNull ModuleManager novoline) {
        super(novoline, "BedBreaker", EnumModuleType.PLAYER, "Breaks bed around you");
        Manager.put(new Setting("BB_MODE", "Mode", COMBOBOX, this, this.mode));
        Manager.put(new Setting("BB_RADIUS", "Break radius", SLIDER, this, this.radius, 1));
        Manager.put(new Setting("AV_BOOST", "Draw radius", CHECKBOX, this, this.drawRadius));
    }

    // PORT: Blocks.bed covered every color; BedBlock instanceof check is the modern equivalent
    private static boolean isBedHead(@NotNull BlockState state) {
        return state.getBlock() instanceof BedBlock && state.get(BedBlock.PART) == BedPart.HEAD;
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        if (currentPos != null) {
            if (currentDamage == 0) {
                sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.START_DESTROY_BLOCK, currentPos, Direction.UP));
            }

            currentDamage += mc.world.getBlockState(currentPos).calcBlockBreakingDelta(this.mc.player, this.mc.player.getEntityWorld(), currentPos);

            if (this.currentDamage >= 1.0F) {
                this.digging = false;
                sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, currentPos, Direction.UP));
                mc.interactionManager.breakBlock(currentPos); // PORT: was playerController.onPlayerDestroyBlock(pos, face)
                this.currentDamage = 0.0F;
                currentPos = null;
            }

            sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            this.mc.world.setBlockBreakingInfo(this.mc.player.getId(), currentPos, (int) (this.currentDamage * 10.0F) - 1);
        }
    }

    @EventTarget
    public void onMotionUpdate(MotionUpdateEvent event) {
/*        if (getModule(OptionalClass.class).teleporting) {
            return;
        }*/

        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (currentPos != null && (!getModule(KillAura.class).isEnabled() || getModule(KillAura.class).getTarget() == null)) {
                if (!bedAround()) {
                    currentPos = null;
                    currentDamage = 0;
                }
                float[] rotations = RotationUtil.getRotations(currentPos.getX() + 0.5, currentPos.getY() + 0.5, currentPos.getZ() + 0.5);
                event.setYaw(rotations[0]);
                event.setPitch(rotations[1]);
                PlayerHelper.updateTool(mc, currentPos);
                mc.player.headYaw = rotations[0];
                mc.player.setPitch(rotations[1]); // PORT: was renderArmPitch (no separate render arm pitch field in 1.21)
            } else {
                for (int x = -radius.get(); x < radius.get() + 1; x++) {
                    for (int z = -radius.get(); z < radius.get() + 1; z++) {
                        for (int y = -3; y < 5; y++) {
                            BlockPos pos = BlockPos.ofFloored(mc.player.getX() - x, mc.player.getY() + y, mc.player.getZ() - z);
                            BlockState state = mc.world.getBlockState(pos);
                            if (!isWhitelisted(pos) && isBedHead(state)) {

                                if (mode.get().equals("Advanced")) {
                                    float[] rotations = RotationUtil.getRotations(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);

                                    Vec3d myPos = new Vec3d(mc.player.getX(), mc.player.getY() + mc.player.getStandingEyeHeight(), mc.player.getZ());
                                    Vec3d rotationsVector = getVectorForRotation(rotations[1], rotations[0]);
                                    Vec3d multiplied = myPos.add(rotationsVector.x * radius.get(), rotationsVector.y * radius.get(), rotationsVector.z * radius.get());

                                    BlockHitResult hitResult = mc.world.raycast(new RaycastContext(myPos, multiplied, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));

                                    currentPos = hitResult.getBlockPos();
                                    currentDamage = 0;
                                    if (mc.world.getBlockState(currentPos).getBlock() instanceof BedBlock) {
                                        break;
                                    }
                                } else {
                                    currentPos = pos;
                                    currentDamage = 0;
                                }

                            }
                        }
                    }
                }
            }
        }
    }

    protected final Vec3d getVectorForRotation(float pitch, float yaw) {
        float f = MathHelper.cos((float) Math.toRadians(-yaw) - (float) Math.PI);
        float f1 = MathHelper.sin((float) Math.toRadians(-yaw) - (float) Math.PI);
        float f2 = -MathHelper.cos((float) Math.toRadians(-pitch));
        float f3 = MathHelper.sin((float) Math.toRadians(-pitch));
        return new Vec3d(f1 * f2, f3, f * f2);
    }

    public Vec3d getPositionEyes(float partialTicks) {
        return new Vec3d(mc.player.getX(), mc.player.getY() + (double) mc.player.getStandingEyeHeight(), mc.player.getZ());
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (drawRadius.get()) {
            // PORT: GL_LINE_STRIP circle -> pairs of segments on RenderLayers.lines()
            int color = new Color(255, 255, 255, 150).getRGB();
            RenderUtils.submitWorld(RenderLayers.lines(), (entry, vc) -> {
                Vec3d center = RenderUtils.interpolateRender(mc.player); // camera-relative
                Vec3d prev = null;
                for (double d = 0; d < Math.PI * 2; d += Math.PI * 2 / 26) { // @off
                    double x = center.x + Math.sin(d) * radius.get(),
                            y = center.y,
                            z = center.z + Math.cos(d) * radius.get(); // @on
                    if (prev != null) {
                        vc.vertex(entry, (float) prev.x, (float) prev.y, (float) prev.z).color(color);
                        vc.vertex(entry, (float) x, (float) y, (float) z).color(color);
                    }
                    prev = new Vec3d(x, y, z);
                }
            });
        }
        if (currentPos != null) {
            RenderUtils.drawSolidBlockESP(new BlockPos(currentPos), new Color(255, 255, 255, 50).getRGB());
        }
    }

    private boolean bedAround() {
        for (int x = -radius.get(); x < radius.get() + 1; x++) {
            for (int z = -radius.get(); z < radius.get() + 1; z++) {
                for (int y = -3; y < 5; y++) {
                    BlockPos pos = BlockPos.ofFloored(mc.player.getX() - x, mc.player.getY() + y, mc.player.getZ() - z);
                    if (!isWhitelisted(pos) && isBedHead(mc.world.getBlockState(pos))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }


    public BlockPos getWhiteListed() {
        return whiteListed;
    }

    public void setWhiteListed(BlockPos whiteListed) {
        this.whiteListed = whiteListed;
    }

    private boolean isWhitelisted(@NotNull BlockPos pos) {
        return pos.getX() == whiteListed.getX() && pos.getY() == whiteListed.getY() && pos.getZ() == whiteListed.getZ();
    }
}
