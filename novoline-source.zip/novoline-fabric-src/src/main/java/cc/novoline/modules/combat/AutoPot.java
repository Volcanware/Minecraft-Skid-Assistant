package cc.novoline.modules.combat;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.modules.move.Scaffold;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import cc.novoline.utils.Timer;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class AutoPot extends AbstractModule {

    /* fields */
    private final Timer timer = new Timer();
    private float prevPitch;

    /* properties @off */
    @Property("health")
    private final DoubleProperty health = PropertyFactory.createDouble(14.0D).minimum(0.5D).maximum(20.0D);
    @Property("delay")
    private final IntProperty delay = PropertyFactory.createInt(500).minimum(500).maximum(2500);
    @Property("potions")
    private final ListProperty<String> potions = PropertyFactory.createList("Regen").acceptableValues("Heal", "Regen", "Jump", "Speed", "Fire");
    @Property("overlap-effect")
    private final BooleanProperty overlap = PropertyFactory.booleanFalse();

    /* constructors @on */
    public AutoPot(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "AutoPotion", "Auto Potion", EnumModuleType.COMBAT, "Automatically throws pots");
        Manager.put(new Setting("HEARTS", "Health", SettingType.SLIDER, this,
                health, 0.5D, () -> potions.contains("Regen") || potions.contains("Heal")));
        Manager.put(new Setting("DELAY", "Throw Delay", SettingType.SLIDER, this, delay, 100D, () -> !potions.isEmpty()));
        Manager.put(new Setting("AP_POTIONS", "Potions", SettingType.SELECTBOX, this, potions));
        Manager.put(new Setting("OVERLAP", "Overlap", SettingType.CHECKBOX, this, overlap));
    }

    private int getBestSpoofSlot() {
        int spoofSlot = 5;

        for (int i = 36; i < 45; i++) {
            if (!mc.player.playerScreenHandler.getSlot(i).hasStack()) {
                spoofSlot = i - 36;
                break;
            } else if (mc.player.playerScreenHandler.getSlot(i).getStack().getItem() instanceof PotionItem) {
                spoofSlot = i - 36;
                break;
            }
        }

        return spoofSlot;
    }

    private int[] potions() {
        int[] pots = new int[]{-1, -1, -1, -1, -1, -1};
        if (this.potions.contains("Heal")) pots[0] = 6;
        if (this.potions.contains("Regen")) pots[1] = 10;
        if (this.potions.contains("Jump")) pots[2] = 8;
        if (this.potions.contains("Speed")) pots[3] = 1;
        if (this.potions.contains("Fire")) pots[4] = 12;
        return pots;
    }

    private boolean shouldBuff(int potID) {
        if (potID == 6 || potID == 10) {
            return mc.player.getHealth() < health.get();
        } else if (potID == 12) {
            return mc.player.isOnFire();
        }

        return potID == 1 || potID == 8;
    }

    /* methods */
    @EventTarget
    public void onPre(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (!mc.player.isOnGround() || ServerUtils.serverIs(Servers.PRE) || isEnabled(Scaffold.class)
                    || ServerUtils.serverIs(Servers.LOBBY) || mc.currentScreen instanceof CreativeInventoryScreen) {
                return;
            }

            for (int slot = 9; slot < 45; slot++) {
                ItemStack stack = mc.player.playerScreenHandler.getSlot(slot).getStack();

                if (!stack.isEmpty()) {
                    if (stack.getItem() instanceof PotionItem) {
                        for (StatusEffectInstance effect : getEffects(stack)) {

                            for (int potID : potions()) {
                                if (matches(effect.getEffectType(), potID) && stack.getItem() instanceof SplashPotionItem) {
                                    if (onOverlap(potID, effect)) {
                                        if (shouldBuff(potID)) {
                                            if (isBestPotion(stack)) {
                                                if (timer.delay(delay.get())) {
                                                    throwPot(event, slot);
                                                    timer.reset();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean onOverlap(int potID, StatusEffectInstance effect) {
        if (overlap.get()) {
            return !hasPotion(potID) || mc.player.getStatusEffect(effect(potID)) != null
                    && mc.player.getStatusEffect(effect(potID)).getAmplifier() < effect.getAmplifier();
        } else {
            return !hasPotion(potID);
        }
    }

    private void throwPot(MotionUpdateEvent event, int slot) {
        swap(slot, getBestSpoofSlot());
        sendPacket(new UpdateSelectedSlotC2SPacket(getBestSpoofSlot()));
        prevPitch = event.getPitch();
        sendLookPacket(event, 89.0F + ThreadLocalRandom.current().nextFloat());
        sendPacket(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
        sendLookPacket(event, prevPitch);
        sendPacket(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().getSelectedSlot()));
    }

    private void sendLookPacket(MotionUpdateEvent event, float pitch) {
        sendPacket(new PlayerMoveC2SPacket.Full(new Vec3d(event.getX(), event.getY(), event.getZ()),
                event.getYaw(), pitch, event.isOnGround(), mc.player.horizontalCollision));
    }

    private boolean isBestPotion(ItemStack stack) {
        if (getEffects(stack).size() != 1) {
            return false;
        }

        StatusEffectInstance effect = getEffects(stack).get(0);
        int potionID = potionId(effect.getEffectType()), amplifier = effect.getAmplifier(), duration = effect.getDuration();

        for (int slot = 9; slot < 45; slot++) {
            if (mc.player.playerScreenHandler.getSlot(slot).hasStack()) {
                ItemStack slotStack = mc.player.playerScreenHandler.getSlot(slot).getStack();

                if (slotStack.getItem() instanceof PotionItem) {
                    for (StatusEffectInstance potionEffect : getEffects(slotStack)) {
                        int id = potionId(potionEffect.getEffectType()), ampl = potionEffect.getAmplifier(), dur = potionEffect.getDuration();

                        if (id == potionID && slotStack.getItem() instanceof SplashPotionItem) {
                            if (ampl > amplifier) {
                                return false;
                            } else if (ampl == amplifier && dur > duration) {
                                return false;
                            }
                        }
                    }
                }
            }
        }

        return true;
    }

    // PORT: EntityPlayerSP#swap(windowClick mode 2) -> interactionManager.clickSlot(SWAP)
    private void swap(int inventorySlot, int hotbarSlot) {
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, inventorySlot, hotbarSlot, SlotActionType.SWAP, mc.player);
    }

    // PORT: potions are data-driven now; keep the legacy 1.8.9 numeric ids used by this module
    private static RegistryEntry<StatusEffect> effect(int potID) {
        switch (potID) {
            case 1:
                return StatusEffects.SPEED;
            case 6:
                return StatusEffects.INSTANT_HEALTH;
            case 8:
                return StatusEffects.JUMP_BOOST;
            case 10:
                return StatusEffects.REGENERATION;
            case 12:
                return StatusEffects.FIRE_RESISTANCE;
            default:
                return null;
        }
    }

    private static int potionId(RegistryEntry<StatusEffect> entry) {
        if (entry.equals(StatusEffects.SPEED)) return 1;
        if (entry.equals(StatusEffects.INSTANT_HEALTH)) return 6;
        if (entry.equals(StatusEffects.JUMP_BOOST)) return 8;
        if (entry.equals(StatusEffects.REGENERATION)) return 10;
        if (entry.equals(StatusEffects.FIRE_RESISTANCE)) return 12;
        return -1;
    }

    private static boolean matches(RegistryEntry<StatusEffect> entry, int potID) {
        return effect(potID) != null && entry.equals(effect(potID));
    }

    private boolean hasPotion(int potID) {
        RegistryEntry<StatusEffect> entry = effect(potID);
        return entry != null && mc.player.hasStatusEffect(entry);
    }

    // PORT: ItemPotion#getEffects(stack) -> POTION_CONTENTS component
    private static List<StatusEffectInstance> getEffects(ItemStack stack) {
        List<StatusEffectInstance> list = new ArrayList<>();
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);

        if (contents != null) {
            contents.getEffects().forEach(list::add);
        }

        return list;
    }
}
