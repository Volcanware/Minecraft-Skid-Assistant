package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.ListProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.visual.Brightness;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.EntityStatusEffectS2CPacket;
import org.jetbrains.annotations.NotNull;

import static cc.novoline.gui.screen.setting.SettingType.SELECTBOX;
import static cc.novoline.modules.EnumModuleType.MISC;

public final class NoEffects extends AbstractModule {

    /* properties @off */
    @Property("effects")
    private final ListProperty<String> effects = PropertyFactory.createList("Night Vision", "Blindness", "Nausea").acceptableValues("Night Vision", "Blindness", "Nausea");

    /* constructors @on */
    public NoEffects(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "NoEffects", "No Effects", MISC, "remove bad potion effects");
        Manager.put(new Setting("NF_EFFECTS", "Effects", SELECTBOX, this, effects));
    }

    @EventTarget
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        // PORT: numeric potion ids -> StatusEffects registry entries;
        // isPotionActive -> hasStatusEffect, removePotionEffectClient -> removeStatusEffect
        if (effects.contains("Nausea") && mc.player.hasStatusEffect(StatusEffects.NAUSEA)) {
            mc.player.removeStatusEffect(StatusEffects.NAUSEA);
        }

        //todo
        if (!isEnabled(Brightness.class) || !getModule(Brightness.class).getMode().equals("Effect")) {
            if (effects.contains("Night Vision") && mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            }
        }

        if (effects.contains("Blindness") && mc.player.hasStatusEffect(StatusEffects.BLINDNESS)) {
            mc.player.removeStatusEffect(StatusEffects.BLINDNESS);
        }
    }

    /* events */
    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            // PORT: S1DPacketEntityEffect -> EntityStatusEffectS2CPacket
            if (event.getPacket() instanceof EntityStatusEffectS2CPacket) {
                EntityStatusEffectS2CPacket packet = (EntityStatusEffectS2CPacket) event.getPacket();

                if (effects.contains("Nausea") && packet.getEffectId().equals(StatusEffects.NAUSEA) ||
                        effects.contains("Night Vision") && packet.getEffectId().equals(StatusEffects.NIGHT_VISION) ||
                        effects.contains("Blindness") && packet.getEffectId().equals(StatusEffects.BLINDNESS)) {
                    // PORT: packet is immutable in 1.21.11 — can't setShowParticles(false);
                    // cancelling the packet already prevents the effect from being applied
                    event.setCancelled(true);
                }
            }
        }
    }
}
