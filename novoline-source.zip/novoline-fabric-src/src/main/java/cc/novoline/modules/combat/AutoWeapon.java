package cc.novoline.modules.combat;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.configurations.property.object.StringProperty;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

import java.util.Locale;

/**
 * Switches to the best weapon in the hotbar when attacking: a fixed weapon
 * class (sword/axe/trident/mace), "Weapon" for the highest-damage item, or
 * "Advanced" where the Priority text lists classes in preferred order
 * (e.g. "axe,sword,weapon").
 */
public final class AutoWeapon extends AbstractModule {

    @Property("mode")
    private final StringProperty mode = PropertyFactory.createString("Weapon")
            .acceptableValues("Sword", "Axe", "Trident", "Mace", "Weapon", "Advanced");
    @Property("priority")
    private final StringProperty priority = PropertyFactory.createString("sword,axe,mace,trident,weapon");

    public AutoWeapon(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "AutoWeapon", "Auto Weapon", Keyboard.KEY_NONE, EnumModuleType.COMBAT,
                "Switches to a weapon when you attack");
        Manager.put(new Setting("AW_MODE", "Mode", SettingType.COMBOBOX, this, mode));
        Manager.put(new Setting("AW_PRIORITY", "Priority", SettingType.TEXTBOX, this, "sword,axe,mace,trident,weapon",
                priority, () -> mode.get().equalsIgnoreCase("Advanced")));
    }

    private static boolean isClass(ItemStack stack, String cls) {
        return switch (cls.toLowerCase(Locale.ROOT).trim()) {
            case "sword" -> stack.isIn(ItemTags.SWORDS);
            case "axe" -> stack.isIn(ItemTags.AXES);
            case "trident" -> stack.isOf(Items.TRIDENT);
            case "mace" -> stack.isOf(Items.MACE);
            case "weapon" -> weaponDamage(stack) > 1.0; // any meaningful damage item
            default -> false;
        };
    }

    private static double weaponDamage(ItemStack stack) {
        AttributeModifiersComponent component = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        if (component == null) return 0.0;
        double[] total = {0.0};
        component.applyModifiers(EquipmentSlot.MAINHAND, (attr, modifier) -> {
            if (attr == EntityAttributes.ATTACK_DAMAGE) {
                total[0] += modifier.value();
            }
        });
        return total[0];
    }

    /** @return hotbar slot of the best item in this class, or -1 */
    private static int bestSlot(String cls) {
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
        int best = -1;
        double bestDamage = 0.0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty() || !isClass(stack, cls)) continue;
            double dmg = weaponDamage(stack);
            if (best == -1 || dmg > bestDamage) {
                best = i;
                bestDamage = dmg;
            }
        }
        return best;
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        if (mc.player == null || mc.world == null) return;

        // only act while actually attacking something
        boolean attacking = mc.options.attackKey.isPressed()
                && mc.crosshairTarget instanceof EntityHitResult;
        KillAura killAura = getModule(KillAura.class);
        boolean killAuraActive = killAura.isEnabled() && killAura.getTarget() != null;
        if (!attacking && !killAuraActive) return;

        int target = -1;
        if (mode.get().equalsIgnoreCase("Advanced")) {
            for (String cls : priority.get().split(",")) {
                target = bestSlot(cls);
                if (target != -1) break;
            }
        } else {
            target = bestSlot(mode.get());
        }

        if (target != -1 && mc.player.getInventory().getSelectedSlot() != target) {
            mc.player.getInventory().setSelectedSlot(target);
        }
    }
}
