package cc.novoline.modules.visual;

import cc.novoline.Novoline;
import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render2DEvent;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.events.events.RenderNameTagEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.combat.KillAura;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.IntProperty;
import cc.novoline.modules.configurations.property.object.ListProperty;
import cc.novoline.modules.configurations.property.object.StringProperty;
import cc.novoline.modules.player.Freecam;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.ScaledResolution;
import static cc.novoline.utils.PlayerUtils.lerpDistanceTo;
import cc.novoline.utils.Timer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

import static cc.novoline.gui.screen.setting.SettingType.COMBOBOX;
import static cc.novoline.modules.PlayerManager.EnumPlayerType.FRIEND;
import static cc.novoline.modules.PlayerManager.EnumPlayerType.TARGET;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.*;
import static cc.novoline.utils.PlayerUtils.inTeamWithMinecraftPlayer;
import static cc.novoline.utils.fonts.impl.Fonts.SFBOLD.SFBOLD_18.SFBOLD_18;
import static cc.novoline.utils.fonts.impl.Fonts.SFBOLD.SFBOLD_20.SFBOLD_20;
import static net.minecraft.util.Formatting.*;

public final class Nametags extends AbstractModule {

    /* fields */
    private final List<Player> validEntities = new CopyOnWriteArrayList<>();

    /* properties @off */
    @Property("render-distance")
    private final IntProperty renderDistance = createInt(192).minimum(4).maximum(256);
    @Property("tag-font")
    private final StringProperty tagFont = createString("Client").acceptableValues("Client", "Vanilla");
    @Property("content")
    private final ListProperty<String> content = createList("Distance").acceptableValues("Distance", "Armor");
    @Property("additions")
    private final ListProperty<String> additions = createList("Background").acceptableValues("Background", "Health");
    @Property("health-type")
    private final StringProperty healthType = createString("Bar").acceptableValues("Bar", "Value");
    @Property("background-alpha")
    private final IntProperty backgroundAlpha = createInt(100).minimum(50).maximum(255);
    @Property("only-targets")
    private final BooleanProperty onlyTargets = booleanFalse();

    /* constructors @on */
    public Nametags(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Nametags", "Nametags", Keyboard.KEY_NONE, EnumModuleType.VISUALS);
        Manager.put(new Setting("NAMETAGS_FONT", "Nametags Font", COMBOBOX, this, tagFont));
        Manager.put(new Setting("NAMETAGS_RENDER_DIST", "Render distance", SettingType.SLIDER, this, this.renderDistance, 4));
        Manager.put(new Setting("NAMETAGS_CONTENT", "Content", SettingType.SELECTBOX, this, this.content));
        Manager.put(new Setting("NAMETAGS_ADDITIONS", "Additions", SettingType.SELECTBOX, this, this.additions));
        Manager.put(new Setting("NAMETAGS_BG_ALPHA", "Background Alpha", SettingType.SLIDER, this, this.backgroundAlpha, 5, () -> additions.get().contains("Background")));
        Manager.put(new Setting("NAMETAGS_HEALTH", "Health Type", SettingType.COMBOBOX, this, this.healthType, () -> additions.get().contains("Health")));
        Manager.put(new Setting("ONLY_TAR", "Only targets", SettingType.CHECKBOX, this, this.onlyTargets));
    }

    /* methods */
    @Override
    public void onDisable() {
        this.validEntities.clear();
    }

    private @Nullable Player getPlayerByEntity(LivingEntity entity) {
        return this.validEntities.stream().filter(player -> player.entity.equals(entity)).findFirst().orElse(null);
    }

    /* events */
    @EventTarget
    public void onNameTagRender(RenderNameTagEvent event) {
        if (event.getEntity() == getModule(Freecam.class).getFreecamEntity()) {
            return;
        }

        event.setCancelled(this.novoline.getPlayerManager().getType(event.getEntity().getName().getString()) == TARGET  //
                || lerpDistanceTo(this.mc.player, event.getEntity()) <= this.renderDistance.get() && !this.onlyTargets.get() //
                && !(event.getEntity() instanceof ArmorStandEntity) || getModule(PlayerESP.class).isEnabled() && getModule(PlayerESP.class).getFilter().get().contains("Name"));
    }

    @EventTarget
    public void onRender2D(Render2DEvent render2DEvent) {
        this.validEntities.forEach(Player::render);
    }

    @EventTarget
    private void onRender(Render3DEvent event) {
        for (Entity entity : this.mc.world.getEntities()) { // PORT: getLoadedEntityList -> getEntities
            if (entity instanceof PlayerEntity && !entity.isInvisible() && entity.isAlive()
                    && !this.validEntities.contains(getPlayerByEntity((LivingEntity) entity))) {
                this.validEntities.add(new Player((LivingEntity) entity));
            }
        }

        this.validEntities.forEach(player -> {
            if (!player.entity.isAlive() || lerpDistanceTo(this.mc.player, player.entity) > this.renderDistance.get() && Novoline.getInstance().getPlayerManager().getType(player.entity.getName().getString()) != TARGET) {
                this.validEntities.remove(player);
            }

            // PORT-FIX: the 1.8.9 displayName==name clause dropped every ordinary
            // player (displayName IS the name for unteamed players) so the tag
            // never rendered — kept the NPC filter, dropped that check.
            if (!containsEntity(player.entity) || this.onlyTargets.get() && Novoline.getInstance().getPlayerManager().getType(player.entity.getName().getString()) != TARGET || player.entity.getId() == this.mc.player.getId() || formattedText(player.entity.getDisplayName()).contains("NPC"))
                this.validEntities.remove(player);

            Vec3d camPos = this.mc.gameRenderer.getCamera().getCameraPos();
            final float x = (float) (player.entity.lastX + (player.entity.getX() - player.entity.lastX) * event.getPartialTicks() - camPos.x), //
                    y = (float) (player.entity.lastY + 2.3 + (player.entity.getY() + 2.3 - (player.entity.lastY + 2.3)) * event.getPartialTicks() - camPos.y), //
                    z = (float) (player.entity.lastZ + (player.entity.getZ() - player.entity.lastZ) * event.getPartialTicks() - camPos.z);
            player.positions = player.convertTo2D(x, y, z);
        });
    }

    private boolean containsEntity(Entity entity) {
        for (Entity e : this.mc.world.getEntities()) {
            if (e == entity) return true;
        }
        return false;
    }

    /** PORT: replaces {@code IChatComponent#getFormattedText()} -- rebuilds a legacy ""-coded string from a {@link Text}. */
    private static String formattedText(Text text) {
        if (text == null) return "";
        StringBuilder sb = new StringBuilder();
        text.visit((style, string) -> {
            TextColor color = style.getColor();
            if (color != null) {
                for (Formatting formatting : Formatting.values()) {
                    if (formatting.getColorValue() != null && formatting.getColorValue() == color.getRgb()) {
                        sb.append(formatting);
                        break;
                    }
                }
            }
            if (style.isBold()) sb.append(Formatting.BOLD);
            if (style.isItalic()) sb.append(Formatting.ITALIC);
            if (style.isUnderlined()) sb.append(Formatting.UNDERLINE);
            if (style.isStrikethrough()) sb.append(Formatting.STRIKETHROUGH);
            if (style.isObfuscated()) sb.append(Formatting.OBFUSCATED);
            sb.append(string);
            return Optional.empty();
        }, Style.EMPTY);
        return sb.toString();
    }

    private Timer tpTimer = new Timer();

    private class Player {

        private final LivingEntity entity;
        private double[] positions = {0, 0, 0};

        public Player(LivingEntity entity) {
            this.entity = entity;
        }

        void render() {
            if (this.positions == null) return;
            DrawContext context = RenderUtils.context();
            context.getMatrices().pushMatrix();
            final ScaledResolution scaledResolution = new ScaledResolution(MinecraftClient.getInstance());
            final PlayerManager.EnumPlayerType type = Novoline.getInstance().getPlayerManager().getType(this.entity.getName().getString());
            final float x = (float) (this.positions[0] / scaledResolution.getScaleFactor()), //
                    y = (float) (this.positions[1] / scaledResolution.getScaleFactor()), //
                    z = (float) (this.positions[2] / scaledResolution.getScaleFactor());

            final List<String> contentA = getModule(Nametags.class).getContent().get(), //
                    additions = getModule(Nametags.class).getAdditions().get();
            final String health = additions.contains("Health") ? getModule(Nametags.class).getHealthType().equalsIgnoreCase("Value") ? " " + (int) (this.entity.getHealth() + this.entity.getAbsorptionAmount()) : "" : "";//
            final String distance = contentA.contains("Distance") ? " " + (int) MinecraftClient.getInstance().player.distanceTo(this.entity) + "m" : "";
            String formattedName = formattedText(this.entity.getDisplayName());
//            UserEntity user = novoline.getIRC().getUserManager().findByNickname(this.entity.getName());
//
//            if (!this.entity.getName().isEmpty() && user != null) {
//                formattedName += " \u00A77(\u00A7b" + user.getUsername() + "\u00A77)\u00A7r";
//            }

            context.getMatrices().translate(x, y);

            float amp = 1;
            switch (MinecraftClient.getInstance().options.getGuiScale().getValue()) {
                case 0:
                    amp = 0.5F;
                    break;
                case 1:
                    amp = 2.0F;
                    break;
                case 3:
                    amp = 0.6666666666666667F;
            }


            if (this.positions[2] < 0.0 || this.positions[2] >= 1.0) {
                context.getMatrices().popMatrix();
                return;
            }

            ScaledResolution res = new ScaledResolution(mc);
            double scale2 = res.getScaleFactor() / Math.pow(res.getScaleFactor(), 2.0);
            context.getMatrices().scale((float) scale2, (float) scale2);

            // PORT: depth test is handled by the GUI pipeline
            String content = (type == FRIEND ? AQUA + "[FRIEND] " : getModule(KillAura.class).isEnabled() && getModule(KillAura.class).getFilters().contains("Teams") && inTeamWithMinecraftPlayer(this.entity) ? GREEN + "[TEAM] " : type == TARGET ? RED + "[TARGET] " : "") + RESET + formattedName + GRAY + distance;
            final float rectLength = Math.abs(-(getStringWidth(content) / 2) - 3 - (getStringWidth(content) / 2 + 4)), maxHealth = (int) (this.entity.getMaxHealth() + this.entity.getAbsorptionAmount()), amplifier = 100 / maxHealth, percent = (int) ((this.entity.getHealth() + this.entity.getAbsorptionAmount()) * amplifier), space = rectLength / 100; // @on
            int n = additions.contains("Health") && getModule(Nametags.class).getHealthType().equalsIgnoreCase("Value") ? 5 : 0;
            final float contentWidth = getStringWidth(content) / 2F;

            final ScaledResolution resolution = new ScaledResolution(MinecraftClient.getInstance());

            float width = resolution.getScaledWidth() / 2F;
            float height = resolution.getScaledHeight() / 2F;

            float sizePerPixelX = SFBOLD_20.stringWidth(content) / 2F * 0.5F;
            float sizePerPixelY = 15 * 0.45F;

            float xBnd1 = width / amp + sizePerPixelX;
            float xBnd2 = width / amp - sizePerPixelX;
            float yBnd1 = height / amp - sizePerPixelY;
            float yBnd2 = height / amp + sizePerPixelY;

/*            if (mc.options.getPerspective().ordinal() == 0 && this.positions[0] >= xBnd2 * 2 && this.positions[0] <= xBnd1 * 2 && this.positions[1] >= yBnd1 * 2 && this.positions[1] <= yBnd2 * 2) {
                SFBOLD_20.drawString("Middle click to teleport!", -(SFBOLD_20.stringWidth("Middle click to teleport") / 2F), -getYOffset() - 18, 0xffffffff, true);

                if (Mouse.isButtonDown(2)) {
                    if (tpTimer.delay(1000)) {
                        String command = mc.isInSingleplayer() ? "/tp" : ".tp";
                        mc.player.networkHandler.sendChatMessage(command + " " + entity.getName().getString());
                        tpTimer.reset();
                    }
                }
            }*/

            if (additions.contains("Background")) {
                RenderUtils.guiQuad(-contentWidth - 2 - n, -8.0F - getYOffset(), getStringWidth(content + health) / 2F + //
                                (getModule(Nametags.class).getHealthType().equalsIgnoreCase("Bar") ? 2 : getStringWidth(health) - 3 - n), //
                        (additions.contains("Health") ? getModule(Nametags.class).getHealthType().equalsIgnoreCase("Bar") ? 6 : 5 : 5) - getYOffset(), //
                        new Color(type == TARGET ? 100 : 0, type == FRIEND || getModule(KillAura.class).isEnabled() //
                                && getModule(KillAura.class).getFilters().contains("Teams") && inTeamWithMinecraftPlayer(this.entity) ? 90 : 0, type == FRIEND ? 120 : //
                                inTeamWithMinecraftPlayer(this.entity) ? 15 : 0, getModule(Nametags.class).getBackgroundAlpha().get()).getRGB());
            }

            if (contentA.contains("Armor")) {
                renderArmor((PlayerEntity) this.entity);
            }

            drawString(content, -contentWidth - n, -getYOffset() - 5, 16777215);
            drawString(health, contentWidth - n, -getYOffset() - 5, getHealthColor());

            if (additions.contains("Health") && getModule(Nametags.class).getHealthType().equalsIgnoreCase("Bar")) {
                RenderUtils.guiQuad(-contentWidth - 2, 5 - getYOffset(), -contentWidth - 5 + percent * space, 6 - getYOffset(), getHealthColor());
            }

            context.getMatrices().popMatrix();
        }

        private void drawString(String string, float x, float y, int color) {
            if (tagFont.get().equalsIgnoreCase("Client")) {
                SFBOLD_20.drawString(string, x, y, color);
            } else {
                // PORT: fontRendererObj -> textRenderer; 1.8.9 drawString always drew a drop shadow
                RenderUtils.context().drawText(mc.textRenderer, string, (int) x, (int) y, color, true);
            }
        }

        private float getStringWidth(String string) {
            if (tagFont.get().equalsIgnoreCase("Client")) {
                return SFBOLD_20.stringWidth(string);
            } else {
                return mc.textRenderer.getWidth(string);
            }
        }

        private float getYOffset() {
            final float distanceToEntity = MinecraftClient.getInstance().player.distanceTo(this.entity);

            if (getModule(Nametags.class).getHealthType().equalsIgnoreCase("Bar")) {
                return (float) Math.max(getDistance() * (distanceToEntity >= 110 ? 0.058 : 0.032 + 4 / distanceToEntity), 1);
            } else {
                return (float) Math.max(getDistance() * (distanceToEntity >= 110 ? 0.046 : 0.02 + 4 / distanceToEntity), 1);
            }
        }

        private int getHealthColor() {
            final float f = this.entity.getHealth(), // @off
                    f1 = this.entity.getMaxHealth(),
                    f2 = Math.max(0.0F, Math.min(f, f1) / f1); // @on
            return Color.HSBtoRGB(f2 / 3.0F, 1, 1) | 0xFF000000;
        }

        private int getDistance() {
            final int diffX = (int) Math.abs(MinecraftClient.getInstance().player.getX() - this.entity.getX()), // @off
                    diffY = (int) Math.abs(MinecraftClient.getInstance().player.getY() - this.entity.getY()),
                    diffZ = (int) Math.abs(MinecraftClient.getInstance().player.getZ() - this.entity.getZ()); // @on
            return (int) Math.sqrt(diffX * diffX + diffY * diffY + diffZ * diffZ);
        }

        private double[] convertTo2D(double x, double y, double z) {
            // PORT: GLU.gluProject replaced by a JOML projection; (x,y,z) arrive camera-relative.
            MinecraftClient mc = MinecraftClient.getInstance();
            Camera camera = mc.gameRenderer.getCamera();

            Matrix4f view = new Matrix4f()
                    .rotationX(camera.getPitch() * MathHelper.RADIANS_PER_DEGREE)
                    .rotateY((camera.getYaw() + 180.0F) * MathHelper.RADIANS_PER_DEGREE);
            Matrix4f projection = new Matrix4f(mc.gameRenderer.getBasicProjectionMatrix(((cc.novoline.mixin.GameRendererAccessor) mc.gameRenderer).novoline$getFov(camera, mc.getRenderTickCounter().getTickProgress(true), true)));

            int[] viewport = {0, 0, mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight()};
            Vector4f screenCoords = new Vector4f();
            projection.mul(view).project(
                    (float) x, (float) y, (float) z,
                    viewport, screenCoords);
            return new double[]{screenCoords.x, (mc.getWindow().getFramebufferHeight() - screenCoords.y), screenCoords.z};
        }

        private void renderArmor(PlayerEntity player) {
            // PORT: inventory.armorInventory -> equipment slots (0 = boots .. 3 = helmet)
            ItemStack[] renderStack = new ItemStack[]{
                    player.getEquippedStack(EquipmentSlot.FEET),
                    player.getEquippedStack(EquipmentSlot.LEGS),
                    player.getEquippedStack(EquipmentSlot.CHEST),
                    player.getEquippedStack(EquipmentSlot.HEAD)};
            ItemStack armourStack;
            int xOffset = 0;

            for (ItemStack aRenderStack : renderStack) {
                armourStack = aRenderStack;

                if (armourStack != null && !armourStack.isEmpty()) xOffset -= 8;
            }

            if (!player.getMainHandStack().isEmpty()) {
                xOffset -= 8;

                final ItemStack stock = player.getMainHandStack().copy();

                // PORT: ItemTool/ItemArmor no longer exist - tools/armor are marked by components
                if (stock.hasGlint() && (stock.contains(DataComponentTypes.TOOL) || stock.contains(DataComponentTypes.EQUIPPABLE)))
                    stock.setCount(1);

                renderItemStack(stock, xOffset, -25 - getYOffset() * 1.5f);
                xOffset += 16;
            }

            for (int index = 3; index >= 0; index--) {
                armourStack = renderStack[index];

                if (armourStack != null && !armourStack.isEmpty()) {
                    renderItemStack(armourStack, xOffset, -25 - getYOffset() * 1.5f);
                    xOffset += 16;
                }
            }
        }

        private void renderItemStack(final ItemStack stack, int x, float y) {
            // PORT: renderItemAndEffectIntoGUI -> DrawContext.drawItem; GL lighting/state handled by the pipeline
            DrawContext context = RenderUtils.context();
            context.getMatrices().pushMatrix();
            context.getMatrices().scale(0.7F, 0.7F);
            context.drawItem(stack, x, (int) y);
            // PORT: renderItemOverlaysCR used the SFBOLD_18 client font; DrawContext only supports the vanilla textRenderer
            context.drawStackOverlay(mc.textRenderer, stack, x, (int) y);
            context.getMatrices().popMatrix();
        }

    }

    //region Lombok
    public List<Player> getValidEntities() {
        return this.validEntities;
    }

    public IntProperty getRenderDistance() {
        return this.renderDistance;
    }

    public ListProperty<String> getContent() {
        return this.content;
    }

    public ListProperty<String> getAdditions() {
        return this.additions;
    }

    public StringProperty getHealthType() {
        return this.healthType;
    }

    public IntProperty getBackgroundAlpha() {
        return this.backgroundAlpha;
    }

    public BooleanProperty getOnlyTargets() {
        return this.onlyTargets;
    }
    //endregion
}
