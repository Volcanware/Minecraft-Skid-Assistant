package cc.novoline.modules.misc;


import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Mouse;

public class MiddleClick extends AbstractModule {

    @Property("pearl")
    private final BooleanProperty pearl = PropertyFactory.booleanTrue();
    @Property("friend")
    private final BooleanProperty friend = PropertyFactory.booleanTrue();

    public MiddleClick(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.MISC, "MiddleClick", "Middle Click");
        Manager.put(new Setting("MC_FRIEND", "Friend", SettingType.CHECKBOX, this, friend));
        Manager.put(new Setting("MC_PEARL", "Pearl", SettingType.CHECKBOX, this, pearl));
    }

    private boolean down = true;

    private int pearlSlot() {
        // PORT: EntityPlayerSP#getSlotByItem inlined — scans the hotbar for the item
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);

            if (!stack.isEmpty() && stack.getItem() == Items.ENDER_PEARL) {
                return i;
            }
        }

        return -1;
    }

    private void sendHeldItemChange(int slot) {
        // PORT: inventory.currentItem -> getInventory().getSelectedSlot()
        if (mc.player.getInventory().getSelectedSlot() != pearlSlot()) {
            sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(slot));
        }
    }

    @EventTarget
    public void onPre(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (Mouse.isButtonDown(2)) {
                if (down) {
                    if (!(mc.crosshairTarget instanceof EntityHitResult entityHit) || !(entityHit.getEntity() instanceof PlayerEntity) || !friend.get()) {
                        if (pearlSlot() != -1 && pearl.get()) {
                            sendHeldItemChange(pearlSlot());
                            // PORT: C08PacketPlayerBlockPlacement -> PlayerInteractItemC2SPacket; the sequenced-packet
                            // helper is package-private in 1.21.11 so the sequence is sent as 0
                            sendPacket(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
                            sendHeldItemChange(mc.player.getInventory().getSelectedSlot());
                        }
                    } else {
                        PlayerEntity player = (PlayerEntity) entityHit.getEntity();
                        if (novoline.getPlayerManager().hasType(player.getName().getString(), PlayerManager.EnumPlayerType.FRIEND)) {
                            mc.player.networkHandler.sendChatMessage(".f remove " + player.getName().getString());
                        } else {
                            mc.player.networkHandler.sendChatMessage(".f add " + player.getName().getString());
                        }
                    }
                    down = false;
                }

            } else {
                down = true;
            }
        }
    }
}
