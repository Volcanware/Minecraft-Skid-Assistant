package cc.novoline.modules.serializers;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import cc.novoline.modules.configurations.property.Property;
import cc.novoline.modules.configurations.property.object.ListProperty;
import com.google.common.reflect.TypeToken;
import ninja.leaping.configurate.ConfigurationNode;
import ninja.leaping.configurate.objectmapping.ObjectMappingException;
import ninja.leaping.configurate.objectmapping.serialize.TypeSerializer;

import java.util.Collection;
import java.util.List;

import static cc.novoline.modules.configurations.property.object.PropertyFactory.*;

/**
 * @author xDelsy
 */
public final class PropertySerializer implements TypeSerializer<Property<?>> {

    @Override
    public void serialize(@NotNull TypeToken<?> type, @Nullable Property<?> obj, @NotNull ConfigurationNode node) {
        if (obj == null || obj.get() == null) {
            node.setValue(null);
            return;
        }

        node.setValue(obj.get());
    }

    @Override
    @Nullable
    public Property<?> deserialize(@NotNull TypeToken<?> type,
                                   @NotNull ConfigurationNode node) throws ObjectMappingException {
        switch (node.getValueType()) {
            case LIST:
                return createList(
                        node.getList(new TypeToken<ListProperty<?>>() {
                        }));

            case SCALAR:
                final Object value = node.getValue();

                if (value instanceof CharSequence) {
                    return createString(value.toString());
                } else if (value instanceof Integer) {
                    return createInt((int) value);
                } else if (value instanceof Double) {
                    return createDouble((double) value);
                } else if (value instanceof Boolean) {
                    return createBoolean((boolean) value);
                } else if (value instanceof Float) {
                    return createFloat((float) value);
                } else if (value instanceof Long) {
                    return createLong((long) value);
                }

                break;

            case MAP:
                throw new ObjectMappingException("Unable to deserialize map property");
        }

        return null;
    }

}
