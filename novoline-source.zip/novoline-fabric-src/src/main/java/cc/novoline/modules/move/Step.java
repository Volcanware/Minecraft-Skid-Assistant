package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.events.events.StepConfirmEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.exploits.Phase;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Timer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;

import static cc.novoline.modules.EnumModuleType.MOVEMENT;

public class Step extends AbstractModule {

    private boolean resetTimer;
    private Timer timer = new Timer();

    public Step(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Step", MOVEMENT, "");
    }

    @Override
    public void onEnable() {
        setSuffix("Watchdog");
    }

    @Override
    public void onDisable() {
        MoveUtils.setTimerSpeed(1.0F);
        setStepHeight(0.625F);
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        setSuffix("Watchdog");
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        //     if (timer.delay(400)) {
        setStepHeight(MoveUtils.isInLiquid(mc.player) || MoveUtils.isOnLiquid(mc.player) || isEnabled(Speed.class) ||
                isEnabled(Phase.class) || !mc.player.isOnGround() ? 0.625F : 1.0F);
        //   }

        if (resetTimer) {
            MoveUtils.setTimerSpeed(1.0F);
            resetTimer = false;
        }
    }


    @EventTarget
    public void onStepConfirm(StepConfirmEvent event) {
        double diffY = mc.player.getBoundingBox().minY - mc.player.getY();
        double posX = mc.player.getX(), posY = mc.player.getY(), posZ = mc.player.getZ();

        if (diffY > 0.625 && diffY <= 1.0) {
            if (ServerUtils.isHypixel()) {
                sendPacketNoEvent(MoveUtils.sneakPacket(mc.player, true));
                mc.player.setSprinting(false);
                MoveUtils.setSpeed(mc.player, 0);
            }

            MoveUtils.setTimerSpeed(0.3f);
            resetTimer = true;

            double first = 0.41999998688698, second = 0.7531999805212;

            if (diffY != 1) {
                first *= diffY;
                second *= diffY;

                if (first > 0.425) {
                    first = 0.425;
                }

                if (second > 0.78) {
                    second = 0.78;
                } else if (second < 0.49) {
                    second = 0.49;
                }
            }

            sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(new Vec3d(posX, posY + first, posZ), false, mc.player.horizontalCollision));
            sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(new Vec3d(posX, posY + second, posZ), false, mc.player.horizontalCollision));

            if (ServerUtils.isHypixel()) {
                sendPacketNoEvent(MoveUtils.sneakPacket(mc.player, false));
            }

            setStepHeight(0.625f);
        }
    }

    // PORT: 1.8.9's mc.player.stepHeight field is the STEP_HEIGHT attribute in 1.21;
    // EntityMixin reads it back through getHeight().
    private void setStepHeight(float height) {
        EntityAttributeInstance attribute = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);

        if (attribute != null) {
            attribute.setBaseValue(height);
        }
    }

    public float getHeight() {
        EntityAttributeInstance attribute = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        return attribute != null ? (float) attribute.getValue() : 0.6F;
    }
}
