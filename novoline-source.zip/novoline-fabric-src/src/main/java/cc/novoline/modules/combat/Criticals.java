package cc.novoline.modules.combat;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.exploits.Blink;
import cc.novoline.modules.move.Speed;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Timer;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.ThreadLocalRandom;

import static cc.novoline.modules.EnumModuleType.COMBAT;

public final class Criticals extends AbstractModule {

    private Timer timer = new Timer();
    private boolean rotating;

    /* constructors @on */
    public Criticals(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Criticals", COMBAT, "");
    }

    public boolean shouldCrit(KillAura killAura) {
        return isEnabled() && killAura.shouldAttack() && killAura.isValidEntity(killAura.getTarget())
                && !this.mc.interactionManager.isBreakingBlock() && this.mc.player.isOnGround()
                && !this.isInLiquid() && !this.isInsideBlock() && !mc.player.input.playerInput.jump();
    }

    private boolean neededHurtTime(KillAura killAura) {
        double aps = killAura.getAps().get();
        int hurtTime = killAura.getTarget().timeUntilRegen;

        return aps < 7.0 && hurtTime >= 14 || aps < 3.0 && hurtTime >= 10 || aps == 1.0 || hurtTime >= 18;
    }

/*    @EventTarget
    public void onMotion(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (getModule(Blink.class).isEnabled() || isEnabled(Speed.class) && mc.player.isMoving()) {
                return;
            }

            if (isEnabled(KillAura.class)) {
                KillAura killAura = getModule(KillAura.class);

                if (shouldCrit(killAura)) {
                    int hurt = killAura.getTarget().timeUntilRegen;

                    switch (hurt) {
                        case 17:
                            event.setOnGround(false);
                            event.setY(event.getY() + 0.00163166800276);
                            break;
                        case 18:
                            event.setOnGround(false);
                            event.setY(event.getY() + 0.11921599284565);
                            break;
                        case 19:
                            event.setOnGround(false);
                            event.setY(event.getY() + 0.15919999545217);
                            break;
                        case 20:
                            event.setOnGround(false);
                            event.setY(event.getY() + 0.11999999731779);
                    }

                    print(event.isOnGround(), event.getY());
                }
            }
        }
    }*/

    public void onCrit(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.OUTGOING)) {
            if (getModule(Blink.class).isEnabled() || isEnabled(Speed.class) && isMoving()) {
                return;
            }

            if (event.getPacket() instanceof PlayerMoveC2SPacket) {
                PlayerMoveC2SPacket packet = (PlayerMoveC2SPacket) event.getPacket();

                if (isEnabled(KillAura.class)) {
                    KillAura killAura = getModule(KillAura.class);

                    if (shouldCrit(killAura)) {
                        if (mc.player.age % 5 != 0) {
                            event.setCancelled(true);
                            resend(packet, false, ThreadLocalRandom.current().nextDouble(secretShit));
                        }
                    }
                }
            }
        }
    }

    @EventTarget
    public void onMotion(PacketEvent event) {
        if (ServerUtils.isHypixel()) {
            if (event.getState().equals(PacketEvent.State.OUTGOING)) {
                if (getModule(Blink.class).isEnabled() || isEnabled(Speed.class) && isMoving()) {
                    return;
                }

                if (isEnabled(KillAura.class)) {
                    KillAura killAura = getModule(KillAura.class);

                    if (shouldCrit(killAura)) {
                        if (event.getPacket() instanceof PlayerMoveC2SPacket) {
                            PlayerMoveC2SPacket packet = (PlayerMoveC2SPacket) event.getPacket();

                            if (packet.changesPosition()) {
                                int resistantTime = killAura.getTarget().timeUntilRegen;

                                switch (resistantTime) {
                                    case 17:
                                        event.setCancelled(true);
                                        resend(packet, false, ThreadLocalRandom.current().nextDouble(min17, max17));
                                        break;
                                    case 18:
                                        event.setCancelled(true);
                                        resend(packet, false, ThreadLocalRandom.current().nextDouble(min18, max18));
                                        break;
                                    case 19:
                                        event.setCancelled(true);
                                        resend(packet, false, ThreadLocalRandom.current().nextDouble(min19, max19));
                                        break;
                                    case 20:
                                        event.setCancelled(true);
                                        resend(packet, false, ThreadLocalRandom.current().nextDouble(min20, max20));
                                }
                            }
                        }
                    }
                }
            }

        } else {
            onCrit(event);
        }
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        setSuffix("Watchdog");
    }

    @Override
    public void onEnable() {
        setSuffix("Watchdog");
    }

    /* PORT: C03PacketPlayer was mutable; PlayerMoveC2SPacket is immutable, so the packet is
       cancelled above and an identical packet with onGround=false and the y-offset applied is
       resent without re-firing PacketEvent. */
    private void resend(PlayerMoveC2SPacket packet, boolean onGround, double yOffset) {
        Packet<?> resend;
        Vec3d pos = new Vec3d(packet.getX(0.0), packet.getY(0.0) + yOffset, packet.getZ(0.0));

        if (packet.changesPosition() && packet.changesLook()) {
            resend = new PlayerMoveC2SPacket.Full(pos, packet.getYaw(0.0F), packet.getPitch(0.0F), onGround, packet.horizontalCollision());
        } else if (packet.changesPosition()) {
            resend = new PlayerMoveC2SPacket.PositionAndOnGround(pos, onGround, packet.horizontalCollision());
        } else if (packet.changesLook()) {
            resend = new PlayerMoveC2SPacket.LookAndOnGround(packet.getYaw(0.0F), packet.getPitch(0.0F), onGround, packet.horizontalCollision());
        } else {
            resend = new PlayerMoveC2SPacket.OnGroundOnly(onGround, packet.horizontalCollision());
        }

        sendPacketNoEvent(resend);
    }

    // PORT: EntityPlayerSP#isMoving() jar-mod
    private boolean isMoving() {
        return mc.player.input.getMovementInput().lengthSquared() != 0;
    }

    // PORT: EntityPlayerSP#isInLiquid() jar-mod; BlockLiquid -> FluidBlock
    private boolean isInLiquid() {
        final double y = mc.player.getY() + 0.01;
        for (int x = MathHelper.floor(mc.player.getX()); x < MathHelper.ceil(mc.player.getX()); ++x) {
            for (int z = MathHelper.floor(mc.player.getZ()); z < MathHelper.ceil(mc.player.getZ()); ++z) {
                if (mc.world.getBlockState(new BlockPos(x, (int) y, z)).getBlock() instanceof FluidBlock) {
                    return true;
                }
            }
        }
        return false;
    }

    // PORT: EntityPlayerSP#isInsideBlock() jar-mod: entity box intersects a non-air collision box
    private boolean isInsideBlock() {
        Box boundingBox = mc.player.getBoundingBox();
        for (int x = MathHelper.floor(boundingBox.minX); x < MathHelper.floor(boundingBox.maxX) + 1; x++) {
            for (int y = MathHelper.floor(boundingBox.minY); y < MathHelper.floor(boundingBox.maxY) + 1; y++) {
                for (int z = MathHelper.floor(boundingBox.minZ); z < MathHelper.floor(boundingBox.maxZ) + 1; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    BlockState state = mc.world.getBlockState(pos);
                    Block block = state.getBlock();

                    if (!state.isAir()) {
                        VoxelShape shape = state.getCollisionShape(mc.world, pos);

                        if (!shape.isEmpty() && boundingBox.intersects(shape.getBoundingBox())) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
}
