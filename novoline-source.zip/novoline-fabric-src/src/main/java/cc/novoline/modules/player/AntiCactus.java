package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.CollideWithBlockEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.Box;
import org.jetbrains.annotations.NotNull;

public final class AntiCactus extends AbstractModule {

    /* constructors */
    public AntiCactus(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "AntiCactus", "Anti Cactus", EnumModuleType.PLAYER, "");
    }

    /* methods */
    @EventTarget
    private void onCollision(CollideWithBlockEvent event) {
        if (event.getBlock() == Blocks.CACTUS) {
            event.setBoundingBox(new Box(event.getPos())); // PORT: Box(BlockPos) == AxisAlignedBB(pos, pos.add(1,1,1))
        }
    }
}
