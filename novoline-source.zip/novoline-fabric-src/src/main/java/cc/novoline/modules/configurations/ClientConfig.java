package cc.novoline.modules.configurations;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import cc.novoline.modules.ModuleArrayMap;
import cc.novoline.utils.java.Checks;
import ninja.leaping.configurate.objectmapping.Setting;
import ninja.leaping.configurate.objectmapping.serialize.ConfigSerializable;

/**
 * @author xDelsy
 */
@ConfigSerializable
public final class ClientConfig {

    /* fields @off */
    @Setting("modules")
    private ModuleArrayMap modules;
    @Setting("config-version")
    private int configVersion;

    /* constructors @on */
    public ClientConfig() {
    }

    private ClientConfig(@Nullable ModuleArrayMap options, int configVersion) {
        this.modules = options;
        this.configVersion = configVersion;
    }

    @NotNull
    public static ClientConfig of(@NotNull String name, @Nullable ModuleArrayMap options, int configVersion) {
        Checks.notNull(options, "modules");
        return new ClientConfig(options, configVersion);
    }

    @NotNull
    public static ClientConfig of(@NotNull ConfigManager configManager, @NotNull String name) {
        Checks.notNull(configManager, "module manager");
        return new ClientConfig(configManager.getModuleManager().getModuleManager(), configManager.getConfigVersion());
    }

    /* methods */
    //region Lombok
    public ModuleArrayMap getModules() {
        return this.modules;
    }

    public int getConfigVersion() {
        return this.configVersion;
    }

    @Override
    @NotNull
    public String toString() {
        return "ClientConfig{options=" + this.modules + ", configVersion=" + this.configVersion + '}';
    }
    //endregion

}
