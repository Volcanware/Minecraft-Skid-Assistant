package cc.novoline.modules.configurations.property.mapper;

import cc.novoline.modules.configurations.property.Property;
import cc.novoline.modules.configurations.property.object.*;
import com.google.common.reflect.TypeToken;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import ninja.leaping.configurate.ConfigurationNode;
import ninja.leaping.configurate.ValueType;
import ninja.leaping.configurate.objectmapping.ObjectMappingException;
import ninja.leaping.configurate.objectmapping.serialize.TypeSerializer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Objects;

/**
 * Deserialization logic for @Property fields. Stock configurate 3.x does not
 * expose ObjectMapper.SampleFieldData, so PropertyMapper wraps this in an
 * anonymous ObjectMapper.FieldData subclass (it can see the protected type
 * as an ObjectMapper subclass).
 *
 * @author xDelsy
 */
public final class PropertyFieldData {

    private PropertyFieldData() {
    }

    public static void deserialize(Object container, ConfigurationNode node,
                                   Field field) throws ObjectMappingException {
        final TypeToken<?> fieldType = TypeToken.of(field.getGenericType());
        final TypeSerializer<?> serial = node.getOptions().getSerializers().get(fieldType);

        if (serial == null) {
            throw new ObjectMappingException("No TypeSerializer found for field " + field.getName() + " of type " + fieldType);
        }

        deserializeAndSet(container, node, field, fieldType, serial);
    }

    protected static void deserializeAndSet(Object container, ConfigurationNode node,
                                            Field field, TypeToken<?> fieldType,
                                            TypeSerializer<?> serial) throws ObjectMappingException {
        try {
            if (node.getValueType() == ValueType.LIST) {
                final Property<?> propertyFromContainer = getPropertyFromContainer(field, container);
                final List<?> value = (List<?>) node.getValue();
                final ObjectArrayList<?> newValue = value != null ?
                        new ObjectArrayList<>(value) :
                        new ObjectArrayList<>();

                updatePropertyValue(propertyFromContainer, newValue);
            } else {
                final Object newVal = node.isVirtual() ? null : serial.deserialize(fieldType, node);

                if (newVal == null) {
                    final Object existingVal = field.get(container);
                    if (existingVal != null) {
                        serializeBack(existingVal, node, fieldType, serial);
                    }
                } else {
                    set(container, field, newVal);
                }
            }
        } catch (IllegalAccessException e) {
            throw new ObjectMappingException("Unable to deserialize field " + field.getName(), e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void serializeBack(Object existingVal, ConfigurationNode node,
                                      TypeToken<?> fieldType, TypeSerializer serial) throws ObjectMappingException {
        serial.serialize(fieldType, existingVal, node);
    }

    private static Property<?> getPropertyFromContainer(@NotNull Field field,
                                                        @NotNull Object container) throws IllegalAccessException {
        return (Property<?>) field.get(container);
    }

    private static void set(@NotNull Object container, @NotNull Field field,
                            Object newVal) throws ObjectMappingException, IllegalAccessException {
        // System.out.println("set \"" + newVal + "\" to \"" + field.getName() + "\"");

        final Property<?> property = getPropertyFromContainer(field, container);
        final Object newValue = ((Property<?>) newVal).get();

        try {
            updatePropertyValue(property, newValue);
        } catch (ClassCastException e) {
            try {
                castAndUpdatePropertyValue(property, Objects.requireNonNull(newValue));
            } catch (Throwable t) {
                throw new ObjectMappingException("Cannot update value", t);
            }
        } catch (Throwable e) {
            throw new ObjectMappingException("Cannot update value", e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void updatePropertyValue(@NotNull Property property, @Nullable Object newValue) {
        property.set(newValue);
    }

    @SuppressWarnings("rawtypes")
    private static void castAndUpdatePropertyValue(@NotNull Property property, @NotNull Object newValue) throws Throwable {
        if (property instanceof IntProperty) {
            updatePropertyValue(property, ((Number) newValue).intValue());
        } else if (property instanceof DoubleProperty) {
            updatePropertyValue(property, ((Number) newValue).doubleValue());
        } else if (property instanceof FloatProperty) {
            updatePropertyValue(property, ((Number) newValue).floatValue());
        } else if (property instanceof LongProperty) {
            updatePropertyValue(property, ((Number) newValue).longValue());
        } else if (property instanceof StringProperty) {
            updatePropertyValue(property, newValue.toString());
        } else if (property instanceof ListProperty) {
            updatePropertyValue(property, new ObjectArrayList<>(new Object[]{newValue}));
        } else if (property instanceof BooleanProperty) {
            if (newValue instanceof Number) {
                updatePropertyValue(property, ((Number) newValue).shortValue() > 0);
                return;
            }

            throw new ObjectMappingException();
        }
    }

}
