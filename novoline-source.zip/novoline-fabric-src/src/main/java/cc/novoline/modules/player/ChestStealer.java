package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.*;
import cc.novoline.gui.screen.dropdown.DropdownGUI;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.DoubleProperty;
import cc.novoline.modules.configurations.property.object.ListProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Timer;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.s2c.play.InventoryS2CPacket;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class ChestStealer extends AbstractModule {

    private String[] list = new String[]{"mode", "delivery", "menu", "selector", "game", "gui", "server", "inventory", "play", "teleporter", //
            "shop", "melee", "armor", "block", "castle", "mini", "warp", "teleport", "user", "team", "tool", "sure", "trade", "cancel", "accept",  //
            "soul", "book", "recipe", "profile", "tele", "port", "map", "kit", "select", "lobby", "vault", "lock", "anticheat", "travel", "settings", //
            "user", "preference", "compass", "cake", "wars", "buy", "upgrade", "ranged", "potions", "utility"};

    private List<Integer> containerSlots = new CopyOnWriteArrayList();
    private List<Integer> chestIds = new CopyOnWriteArrayList();
    private Timer timer = new Timer(), timerAura = new Timer();
    private boolean isStealing, slotsFilled;
    private int containerSize, windowID;

    @Property("auto_disable")
    private final ListProperty<String> auto_disable = PropertyFactory.createList("Death").acceptableValues("World Change", "Game End", "Death");
    @Property("delay")
    private final DoubleProperty delay = PropertyFactory.createDouble(100.0D).minimum(50.0D).maximum(150.0D);
    @Property("extra-packet")
    private final BooleanProperty extra_packet = PropertyFactory.booleanFalse();
    @Property("silent")
    private final BooleanProperty silent = PropertyFactory.booleanFalse();
    @Property("ignore")
    private final BooleanProperty ignore = PropertyFactory.booleanFalse();
    @Property("aura")
    private final BooleanProperty aura = PropertyFactory.booleanFalse();
    @Property("aura-range")
    private final DoubleProperty aura_range = PropertyFactory.createDouble(4.0D).minimum(1.5D).maximum(4.0D);

    public ChestStealer(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "ChestStealer", "Chest Stealer", EnumModuleType.PLAYER, "Steal items from chests");
        Manager.put(new Setting("CS_SILENT", "Silent", SettingType.CHECKBOX, this, silent));
        Manager.put(new Setting("CS_IGNORE", "Ignore", SettingType.CHECKBOX, this, ignore));
        Manager.put(new Setting("CS_EXTRA", "Extra Packet", SettingType.CHECKBOX, this, extra_packet));
        Manager.put(new Setting("CS_AURA", "Aura", SettingType.CHECKBOX, this, aura));
        Manager.put(new Setting("CS_AURA_RANGE", "Aura Range", SettingType.SLIDER, this, aura_range, 0.1D, aura::get));
        Manager.put(new Setting("CS_DELAY", "Delay", SettingType.SLIDER, this, delay, 5.0D, () -> !extra_packet.get()));
        Manager.put(new Setting("CS_AUTO_DISABLE", "Disable On", SettingType.SELECTBOX, this, auto_disable));
    }

    @Override
    public void onDisable() {
        slotsFilled = false;
        isStealing = false;
        containerSlots.clear();
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (event.getPacket() instanceof OpenScreenS2CPacket packet) {
                for (String blacklisted : list) {
                    // PORT: getWindowTitle().getUnformattedText() -> getName().getString()
                    if (packet.getName().getString().toLowerCase().contains(blacklisted)) {
                        isStealing = false;
                        return;
                    }
                }

                // PORT: guiId "minecraft:chest" -> GENERIC_9Xn screen handler types (chests of any size)
                isStealing = isChestScreen(packet.getScreenHandlerType());

                if (isStealing) {
                    containerSize = slotCount(packet.getScreenHandlerType());
                    windowID = packet.getSyncId();
                    containerSlots.clear();
                    slotsFilled = false;
                }
            }

            if (isStealing) {
                if (event.getPacket() instanceof InventoryS2CPacket packet) {
                    if (packet.syncId() == windowID) {
                        if (!slotsFilled) {
                            ItemStack[] contents = packet.contents().toArray(new ItemStack[0]);

                            for (int i = 0; i < containerSize; i++) {
                                ItemStack stack = contents[i];

                                if (!stack.isEmpty() && (!ignore.get() || isNotBad(stack) && checkArmor(stack, packet) && checkTool(stack, packet) && checkSword(stack, packet) && checkBow(stack, packet))) {
                                    containerSlots.add(i);
                                }
                            }

                            slotsFilled = true;
                        }
                    }
                }
            }
        }
    }

    // PORT: guiId "minecraft:chest" -> chest-sized generic containers
    private static boolean isChestScreen(ScreenHandlerType<?> type) {
        return type == ScreenHandlerType.GENERIC_9X1 || type == ScreenHandlerType.GENERIC_9X2
                || type == ScreenHandlerType.GENERIC_9X3 || type == ScreenHandlerType.GENERIC_9X4
                || type == ScreenHandlerType.GENERIC_9X5 || type == ScreenHandlerType.GENERIC_9X6;
    }

    // PORT: S2DPacketOpenWindow.getSlotCount() -> container slot count derived from the type
    private static int slotCount(ScreenHandlerType<?> type) {
        if (type == ScreenHandlerType.GENERIC_9X1) return 9;
        if (type == ScreenHandlerType.GENERIC_9X2) return 18;
        if (type == ScreenHandlerType.GENERIC_9X3) return 27;
        if (type == ScreenHandlerType.GENERIC_9X4) return 36;
        if (type == ScreenHandlerType.GENERIC_9X5) return 45;
        if (type == ScreenHandlerType.GENERIC_9X6) return 54;
        return 0;
    }

    private List<ChestBlockEntity> tileEntityChestList() {
        return mc.world.getBlockEntities()
                .stream().filter(te -> te instanceof ChestBlockEntity)
                .map(te -> (ChestBlockEntity) te).filter(te -> getDistance(te.getPos()) <= aura_range.get())
                .sorted(Comparator.comparing(o -> getDistance(((ChestBlockEntity) o).getPos())).reversed()).collect(Collectors.toList());
    }

    private double getDistance(BlockPos pos) {
        return Math.sqrt(mc.player.squaredDistanceTo(Vec3d.ofCenter(pos)));
    }

    @EventTarget
    public void onMotion(MotionUpdateEvent event) {
        if (aura.get() && ServerUtils.inGameTicks() > 15) {
            if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
                if (!isStealing) {
                    for (ChestBlockEntity chest : tileEntityChestList()) {
                        // PORT: toString() hash digits -> identityHashCode (stable per-object id)
                        int id = System.identityHashCode(chest);

                        if (!chestIds.contains(id) && timerAura.delay(300)) {
                            // PORT: onPlayerRightClick -> interactionManager.interactBlock;
                            //       MathHelper.getVec3(pos) -> Vec3d.ofCenter(pos);
                            //       Block.getFacingDirection was a Novoline jar-mod helper
                            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                                    new BlockHitResult(Vec3d.ofCenter(chest.getPos()),
                                            getFacingDirection(chest.getPos()), chest.getPos(), false));
                            chestIds.add(id);
                            timerAura.reset();
                        }
                    }

                } else {
                    timerAura.reset();
                }
            }
        }
    }

    // PORT: Block.getFacingDirection(pos) — Novoline-patched helper; same logic rebuilt here
    private Direction getFacingDirection(BlockPos pos) {
        return mc.world.getBlockState(pos.up()).isSolidBlock(mc.world, pos.up())
                ? raycastDirection(pos)
                : Direction.UP;
    }

    private Direction raycastDirection(BlockPos pos) {
        Vec3d eyes = mc.player.getEyePos();
        Vec3d center = Vec3d.ofCenter(pos);
        // PORT: getBlockReachDistance() -> BLOCK_INTERACTION_RANGE attribute
        BlockHitResult result = mc.world.raycast(new RaycastContext(eyes,
                eyes.add(center.subtract(eyes).normalize()
                        .multiply(mc.player.getAttributeValue(EntityAttributes.BLOCK_INTERACTION_RANGE))),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        Direction facing = result.getBlockPos().equals(pos) ? result.getSide() : null;
        return facing != null ? facing : Direction.UP;
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        if (isStealing) {
            if (!containerSlots.isEmpty()) {
                Collections.reverse(containerSlots);

                for (int count = 0; count < containerSlots.size(); count++) {
                    if (extra_packet.get() || timer.delay(delay.get())) {
                        // PORT: windowClick(windowId, slot, 0, 1) -> clickSlot(..., QUICK_MOVE)
                        mc.interactionManager.clickSlot(windowID, containerSlots.get(count), 0, SlotActionType.QUICK_MOVE, mc.player);
                        containerSlots.remove(containerSlots.get(count));
                        timer.reset();
                    }
                }

            } else {
                closeScreen(silent.get() ? mc.currentScreen instanceof InventoryScreen ? null : mc.currentScreen : null, windowID);
                isStealing = false;
            }
        }
    }

    @EventTarget
    public void onDisplayGuiChest(DisplayChestGuiEvent event) {
        // PORT: the event payload is the screen title (OpenScreenS2CPacket carries no gui id);
        //       isStealing is set by onPacket when a chest-type screen handler opened
        if (silent.get() && isStealing) {
            mc.setScreen(DropdownGUI.previousScreen instanceof InventoryScreen ? null : DropdownGUI.previousScreen);
        }
    }

    @EventTarget
    public void onKeyPress(KeyPressEvent event) {
        if (silent.get() && isStealing) {
            if (event.getKey() == -100 || event.getKey() == -99) {
                event.setCancelled(true);
            }
        }
    }

    // PORT: jar-modded EntityPlayerSP.closeScreen(screen, windowId)
    private void closeScreen(Screen current, int windowId) {
        sendPacketNoEvent(new CloseHandledScreenC2SPacket(windowId));
        mc.player.playerScreenHandler.setCursorStack(ItemStack.EMPTY);
        mc.player.currentScreenHandler = mc.player.playerScreenHandler;
        mc.setScreen(current);
    }

    private boolean checkArmor(ItemStack stack, InventoryS2CPacket packet) {
        ItemStack[] contents = packet.contents().toArray(new ItemStack[0]);

        if (stack.getItem().getTranslationKey().contains("helmet")) {
            return stack.equals(bestArmor(contents, Armor.HELMET)) && (bestArmor(Armor.HELMET) == null
                    || getProtection(bestArmor(contents, Armor.HELMET)) > getProtection(bestArmor(Armor.HELMET)));
        } else if (stack.getItem().getTranslationKey().contains("chestplate")) {
            return stack.equals(bestArmor(contents, Armor.CHESTPLATE)) && (bestArmor(Armor.CHESTPLATE) == null
                    || getProtection(bestArmor(contents, Armor.CHESTPLATE)) > getProtection(bestArmor(Armor.CHESTPLATE)));
        } else if (stack.getItem().getTranslationKey().contains("boots")) {
            return stack.equals(bestArmor(contents, Armor.BOOTS)) && (bestArmor(Armor.BOOTS) == null
                    || getProtection(bestArmor(contents, Armor.BOOTS)) > getProtection(bestArmor(Armor.BOOTS)));
        } else if (stack.getItem().getTranslationKey().contains("leggings")) {
            return stack.equals(bestArmor(contents, Armor.LEGGINS)) && (bestArmor(Armor.LEGGINS) == null
                    || getProtection(bestArmor(contents, Armor.LEGGINS)) > getProtection(bestArmor(Armor.LEGGINS)));
        }

        return true;
    }

    private boolean checkTool(ItemStack stack, InventoryS2CPacket packet) {
        ItemStack[] contents = packet.contents().toArray(new ItemStack[0]);

        if (stack.isIn(ItemTags.PICKAXES)) {
            return stack.equals(bestTool(contents, Tool.PICKAXE)) && (bestTool(getInventory(), Tool.PICKAXE) == null
                    || getEfficiency(bestTool(contents, Tool.PICKAXE)) > getEfficiency(bestTool(getInventory(), Tool.PICKAXE)));
        } else if (stack.isIn(ItemTags.AXES)) {
            return stack.equals(bestTool(contents, Tool.AXE)) && (bestTool(getInventory(), Tool.AXE) == null
                    || getEfficiency(bestTool(contents, Tool.AXE)) > getEfficiency(bestTool(getInventory(), Tool.AXE)));
        } else if (stack.isIn(ItemTags.SHOVELS)) {
            return stack.equals(bestTool(contents, Tool.SHOVEL)) && (bestTool(getInventory(), Tool.SHOVEL) == null
                    || getEfficiency(bestTool(contents, Tool.SHOVEL)) > getEfficiency(bestTool(getInventory(), Tool.SHOVEL)));
        }

        return true;
    }

    private boolean checkSword(ItemStack stack, InventoryS2CPacket packet) {
        ItemStack[] contents = packet.contents().toArray(new ItemStack[0]);

        if (stack.isIn(ItemTags.SWORDS)) {
            return stack.equals(bestSword(contents)) && (bestSword(getInventory()) == null || getDamage(bestSword(contents)) > getDamage(bestSword(getInventory())));
        }

        return true;
    }

    private boolean checkBow(ItemStack stack, InventoryS2CPacket packet) {
        ItemStack[] contents = packet.contents().toArray(new ItemStack[0]);

        if (stack.getItem() instanceof BowItem) {
            return stack.equals(bestBow(contents)) && (bestBow(getInventory()) == null || getPower(bestBow(contents)) > getPower(bestBow(getInventory())));
        }

        return true;
    }

    private boolean isNotBad(ItemStack item) {
        ItemStack stack = null;
        float lastDamage = -1;

        for (int i = 9; i < 45; i++) {
            if (mc.player.playerScreenHandler.slots.get(i).hasStack()) {
                final ItemStack is1 = mc.player.playerScreenHandler.slots.get(i).getStack();

                if (is1.isIn(ItemTags.SWORDS) && item.isIn(ItemTags.SWORDS)) {
                    if (lastDamage < getDamage(is1)) {
                        lastDamage = getDamage(is1);
                        stack = is1;
                    }
                }
            }
        }

        if (stack != null && stack.isIn(ItemTags.SWORDS) && item.isIn(ItemTags.SWORDS)) {
            final float currentDamage = getDamage(stack);
            final float itemDamage = getDamage(item);

            if (itemDamage > currentDamage) return true;
        }

        // @off
        return item == null || !unlocalizedContains(item.getItem(), "stick") && (!unlocalizedContains(item.getItem(), "egg") || unlocalizedContains(item.getItem(), "leg"))
                && !unlocalizedContains(item.getItem(), "string") && !unlocalizedContains(item.getItem(), "compass")
                && !unlocalizedContains(item.getItem(), "feather") && !unlocalizedContains(item.getItem(), "bucket")
                && !unlocalizedContains(item.getItem(), "snow") && !unlocalizedContains(item.getItem(), "fish")
                && !unlocalizedContains(item.getItem(), "enchant") && !unlocalizedContains(item.getItem(), "exp")
                && !unlocalizedContains(item.getItem(), "shears") && !unlocalizedContains(item.getItem(), "anvil")
                && !unlocalizedContains(item.getItem(), "torch") && !unlocalizedContains(item.getItem(), "seeds")
                && !unlocalizedContains(item.getItem(), "leather") && item.getItem() != Items.GLASS_BOTTLE
                && !unlocalizedContains(item.getItem(), "piston") && (!unlocalizedContains(item.getItem(), "potion") || !isBadPotion(item));
        // @on
    }

    private boolean isBadPotion(ItemStack stack) {
        if (stack != null && isPotionItem(stack)) {
            if (isSplash(stack)) {
                return getModule(InvManager.class).isBadPotionEffect(stack, stack);
            }
        }

        return false;
    }

    // PORT: item instanceof ItemPotion -> the three potion items
    private static boolean isPotionItem(ItemStack stack) {
        return stack.isOf(Items.POTION) || stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION);
    }

    // PORT: ItemPotion.isSplash(getItemDamage()) -> splash/lingering potion items
    private static boolean isSplash(ItemStack stack) {
        return stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION);
    }

    private ItemStack[] getInventory() {
        // PORT: inventory.mainInventory -> getMainStacks()
        return mc.player.getInventory().getMainStacks().toArray(new ItemStack[0]);
    }

    private ItemStack[] getArmorInventory() {
        // PORT: armorInventory[0..3] = boots, leggings, chestplate, helmet
        return new ItemStack[]{
                mc.player.getEquippedStack(EquipmentSlot.FEET),
                mc.player.getEquippedStack(EquipmentSlot.LEGS),
                mc.player.getEquippedStack(EquipmentSlot.CHEST),
                mc.player.getEquippedStack(EquipmentSlot.HEAD)};
    }

    public ItemStack bestArmor(Armor armor) {
        if (hasArmor(getInventory(), armor) && hasArmor(getArmorInventory(), armor)) {
            return Stream.of(Arrays.stream(getInventory()).filter(s -> s != null && unlocalizedContains(s.getItem(), armorType(armor)))
                            .sorted((s1, s2) -> Float.compare(getProtection(s2), getProtection(s1))).collect(Collectors.toList()).stream().findFirst().get(),
                    Arrays.stream(getArmorInventory()).filter(s -> s != null && unlocalizedContains(s.getItem(), armorType(armor)))
                            .sorted((s1, s2) -> Float.compare(getProtection(s2), getProtection(s1))).collect(Collectors.toList())
                            .stream().findFirst().get()).filter(s -> s != null && unlocalizedContains(s.getItem(), armorType(armor)))
                    .sorted((s1, s2) -> Integer.compare(s2.getMaxDamage() - s2.getDamage(), s1.getMaxDamage() - s1.getDamage()))
                    .sorted((s1, s2) -> Float.compare(getProtection(s2), getProtection(s1))).collect(Collectors.toList()).stream().findFirst().get();
        } else if (hasArmor(getInventory(), armor)) {
            return Arrays.stream(getInventory()).filter(s -> s != null && unlocalizedContains(s.getItem(), armorType(armor)))
                    .sorted((s1, s2) -> Integer.compare(s2.getMaxDamage() - s2.getDamage(), s1.getMaxDamage() - s1.getDamage()))
                    .sorted((s1, s2) -> Float.compare(getProtection(s2), getProtection(s1))).collect(Collectors.toList()).stream().findFirst().get();
        } else if (hasArmor(getArmorInventory(), armor)) {
            return Arrays.stream(getArmorInventory()).filter(s -> s != null && unlocalizedContains(s.getItem(), armorType(armor)))
                    .sorted((s1, s2) -> Integer.compare(s2.getMaxDamage() - s2.getDamage(), s1.getMaxDamage() - s1.getDamage()))
                    .sorted((s1, s2) -> Float.compare(getProtection(s2), getProtection(s1))).collect(Collectors.toList()).stream().findFirst().get();
        }

        return null;
    }

    public ItemStack bestArmor(ItemStack[] container, Armor armor) {
        if (hasArmor(container, armor)) {
            return Arrays.stream(container).filter(s -> s != null && unlocalizedContains(s.getItem(), armorType(armor)))
                    .sorted((s1, s2) -> Integer.compare(s2.getMaxDamage() - s2.getDamage(), s1.getMaxDamage() - s1.getDamage()))
                    .sorted((s1, s2) -> Float.compare(getProtection(s2), getProtection(s1))).sorted((s1, s2) -> Integer.compare(s2.getDamage(), s1.getDamage())).collect(Collectors.toList()).stream().findFirst().get();
        }

        return null;
    }

    public ItemStack bestTool(ItemStack[] container, Tool tool) {
        if (hasTool(container, tool)) {
            if (tool.equals(Tool.PICKAXE)) {
                return Stream.of(container).filter(s -> s != null && s.isIn(ItemTags.PICKAXES))
                        .sorted((s1, s2) -> Integer.compare(s2.getMaxDamage() - s2.getDamage(), s1.getMaxDamage() - s1.getDamage()))
                        .min((s1, s2) -> Float.compare(getEfficiency(s2), getEfficiency(s1))).get();
            } else if (tool.equals(Tool.SHOVEL)) {
                return Stream.of(container).filter(s -> s != null && s.isIn(ItemTags.SHOVELS))
                        .sorted((s1, s2) -> Integer.compare(s2.getMaxDamage() - s2.getDamage(), s1.getMaxDamage() - s1.getDamage()))
                        .min((s1, s2) -> Float.compare(getEfficiency(s2), getEfficiency(s1))).get();
            } else if (tool.equals(Tool.AXE)) {
                return Stream.of(container).filter(s -> s != null && s.isIn(ItemTags.AXES))
                        .sorted((s1, s2) -> Integer.compare(s2.getMaxDamage() - s2.getDamage(), s1.getMaxDamage() - s1.getDamage()))
                        .min((s1, s2) -> Float.compare(getEfficiency(s2), getEfficiency(s1))).get();
            }
        }

        return null;
    }

    public ItemStack bestSword(ItemStack[] container) {
        if (hasSword(container)) {
            return Stream.of(container).filter(s -> s != null && s.isIn(ItemTags.SWORDS))
                    .sorted((s1, s2) -> Integer.compare(s2.getMaxDamage() - s2.getDamage(), s1.getMaxDamage() - s1.getDamage()))
                    .sorted((s1, s2) -> Float.compare(getDamage(s2), getDamage(s1))).collect(Collectors.toList()).stream().findFirst().get();
        }

        return null;
    }

    public ItemStack bestBow(ItemStack[] container) {
        if (hasBow(container)) {
            return Stream.of(container).filter(s -> s != null && s.getItem() instanceof BowItem)
                    .sorted((s1, s2) -> Float.compare(getPower(s2), getPower(s1))).collect(Collectors.toList()).stream().findFirst().get();
        }

        return null;
    }

    private int containerContainsArmor(ItemStack[] container, Armor armor) {
        for (int i = 0; i < container.length; ++i) {
            if (container[i] != null && unlocalizedContains(container[i].getItem(), armorType(armor))) {
                return i;
            }
        }

        return -1;
    }

    private int containerContainsTool(ItemStack[] container, Tool tool) {
        for (int i = 0; i < container.length; ++i) {
            if (container[i] != null && unlocalizedContains(container[i].getItem(), toolType(tool))) {
                return i;
            }
        }

        return -1;
    }

    private int containerContainsSword(ItemStack[] container) {
        for (int i = 0; i < container.length; ++i) {
            if (container[i] != null && container[i].isIn(ItemTags.SWORDS)) {
                return i;
            }
        }

        return -1;
    }

    private int containerContainsBow(ItemStack[] container) {
        for (int i = 0; i < container.length; ++i) {
            if (container[i] != null && container[i].getItem() instanceof BowItem) {
                return i;
            }
        }

        return -1;
    }

    public boolean hasArmor(ItemStack[] container, Armor armor) {
        int i = this.containerContainsArmor(container, armor);
        return i >= 0;
    }

    public boolean hasTool(ItemStack[] container, Tool tool) {
        int i = this.containerContainsTool(container, tool);
        return i >= 0;
    }

    public boolean hasSword(ItemStack[] container) {
        int i = this.containerContainsSword(container);
        return i >= 0;
    }

    public boolean hasBow(ItemStack[] container) {
        int i = this.containerContainsBow(container);
        return i >= 0;
    }

    public String armorType(Armor armor) {
        if (armor.equals(Armor.LEGGINS)) {
            return "leggings";
        } else if (armor.equals(Armor.CHESTPLATE)) {
            return "chestplate";
        } else if (armor.equals(Armor.BOOTS)) {
            return "boots";
        } else if (armor.equals(Armor.HELMET)) {
            return "helmet";
        } else {
            return "";
        }
    }

    public String toolType(Tool tool) {
        if (tool.equals(Tool.AXE)) {
            return "hatchet";
        } else if (tool.equals(Tool.PICKAXE)) {
            return "pickaxe";
        } else if (tool.equals(Tool.SHOVEL)) {
            return "shovel";
        } else {
            return "";
        }
    }

    private float getPower(ItemStack stack) {
        return (float) (1 + level(Enchantments.POWER, stack) + level(Enchantments.FLAME, stack) + level(Enchantments.INFINITY, stack));
    }

    private float getDamage(@NotNull ItemStack stack) {
        float damage = 0;
        final Item item = stack.getItem();

        if (isToolItem(stack) || stack.isIn(ItemTags.SWORDS)) {
            // PORT: ItemTool.getDamage / ItemSword.getAttackDamage -> total ATTACK_DAMAGE
            //       attribute modifiers on the main hand
            AttributeModifiersComponent modifiers = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
            if (modifiers != null) {
                damage += (float) modifiers.applyOperations(EntityAttributes.ATTACK_DAMAGE, 0.0, EquipmentSlot.MAINHAND);
            }
        }

        damage += level(Enchantments.SHARPNESS, stack) * 1.25F + level(Enchantments.FIRE_ASPECT, stack) * 0.01F;

        return damage;
    }

    private float getProtection(@NotNull ItemStack stack) {
        float protection = 0;

        if (isArmorPiece(stack)) {
            EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);
            AttributeModifiersComponent modifiers = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
            // PORT: ItemArmor.damageReduceAmount -> total ARMOR attribute modifiers for the slot
            float armorValue = modifiers == null ? 0
                    : (float) modifiers.applyOperations(EntityAttributes.ARMOR, 0.0, equippable.slot());

            protection += armorValue + (100 - armorValue) * level(Enchantments.PROTECTION, stack) * 0.0075D;
            protection += level(Enchantments.BLAST_PROTECTION, stack) / 100d;
            protection += level(Enchantments.FIRE_PROTECTION, stack) / 100d;
            protection += level(Enchantments.THORNS, stack) / 100d;
            protection += level(Enchantments.UNBREAKING, stack) / 50d;
            protection += level(Enchantments.PROJECTILE_PROTECTION, stack) / 100d;
        }

        return protection;
    }

    private float getEfficiency(@NotNull ItemStack stack) {
        final Item item = stack.getItem();

        if (!isToolItem(stack)) {
            return 0;
        }

        final String name = item.getTranslationKey();
        float value;

        if (stack.isIn(ItemTags.PICKAXES)) {
            // PORT: getStrVsBlock(stack, Blocks.stone) -> getMiningSpeedMultiplier(state)
            value = stack.getMiningSpeedMultiplier(Blocks.STONE.getDefaultState());

            if (name.toLowerCase().contains("gold")) {
                value -= 6;
            }

        } else if (stack.isIn(ItemTags.SHOVELS)) {
            value = stack.getMiningSpeedMultiplier(Blocks.DIRT.getDefaultState());

            if (name.toLowerCase().contains("gold")) {
                value -= 6;
            }

        } else if (stack.isIn(ItemTags.AXES)) {
            value = stack.getMiningSpeedMultiplier(Blocks.OAK_LOG.getDefaultState());

            if (name.toLowerCase().contains("gold")) {
                value -= 6;
            }

        } else {
            return 1f;
        }

        value += level(Enchantments.EFFICIENCY, stack) * 0.0075D;
        value += level(Enchantments.UNBREAKING, stack) / 100.0D;
        return value;
    }

    private int level(RegistryKey<Enchantment> key, ItemStack stack) {
        return mc.world == null ? 0 : EnchantmentHelper.getLevel(mc.world.getRegistryManager()
                .getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(key), stack);
    }

    // PORT: ItemTool -> TOOL data component
    private static boolean isToolItem(ItemStack stack) {
        return stack.contains(DataComponentTypes.TOOL);
    }

    // PORT: ItemArmor -> EQUIPPABLE component on an armor slot
    private static boolean isArmorPiece(ItemStack stack) {
        EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);
        return equippable != null && switch (equippable.slot()) {
            case HEAD, CHEST, LEGS, FEET -> true;
            default -> false;
        };
    }

    // PORT: getUnlocalizedName().contains -> getTranslationKey().contains, with 1.8.9 aliases
    //       whose names no longer appear verbatim ("hatchet" -> "*_axe", "fish" -> cod/salmon)
    private static boolean unlocalizedContains(Item item, String needle) {
        String key = item.getTranslationKey();
        if (key.contains(needle)) return true;
        return switch (needle) {
            case "hatchet" -> key.contains("_axe");
            case "fish" -> key.contains("cod") || key.contains("salmon");
            default -> false;
        };
    }

    public List<Integer> getChestIds() {
        return chestIds;
    }

    public ListProperty<String> getAutoDisable() {
        return auto_disable;
    }

    public boolean isStealing() {
        return isStealing;
    }

    public enum Armor {
        CHESTPLATE,
        LEGGINS,
        HELMET,
        BOOTS
    }

    public enum Tool {
        PICKAXE,
        SHOVEL,
        AXE
    }
}
