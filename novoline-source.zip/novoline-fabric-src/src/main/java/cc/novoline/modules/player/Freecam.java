package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.*;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.FloatProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.exploits.Blink;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

public final class Freecam extends AbstractModule {

    /* fields */
    private OtherClientPlayerEntity freecamEntity;

    /* properties @off */
    @Property("freecam-speed")
    private final FloatProperty freecamSpeed = PropertyFactory.createFloat(4.0F).minimum(1.0F).maximum(5.0F);

    /* constructors @on */
    public Freecam(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Freecam", "Freecam", Keyboard.KEY_NONE, EnumModuleType.MOVEMENT, "Ghost Walking");
        Manager.put(new Setting("FC_SPEED", "Speed", SettingType.SLIDER, this, this.freecamSpeed, 1.0F));
    }

    /* methods */
    @Override
    public void onDisable() {
        if (this.freecamEntity != null) {
            this.mc.player.refreshPositionAndAngles(this.freecamEntity.getX(), this.freecamEntity.getY(), this.freecamEntity.getZ(),
                    this.freecamEntity.getYaw(), this.freecamEntity.getPitch());
            this.mc.world.removeEntity(this.freecamEntity.getId(), Entity.RemovalReason.DISCARDED);
        }
        this.mc.player.noClip = false;
    }

    @Override
    public void onEnable() {
        if (this.mc.player == null) return;
        checkModule(Blink.class);
        this.freecamEntity = new OtherClientPlayerEntity(this.mc.world, mc.player.getGameProfile());
        // PORT: inventory/playerScreenHandler are final fields now — copy the stacks instead of
        //       sharing the inventory object (no live link; snapshot only).
        for (int i = 0; i < this.freecamEntity.getInventory().size(); i++) {
            this.freecamEntity.getInventory().setStack(i, this.mc.player.getInventory().getStack(i));
        }
        // PORT: playerScreenHandler cannot be re-assigned (final); the clone keeps its own handler.
        this.freecamEntity.refreshPositionAndAngles(this.mc.player.getX(), this.mc.player.getY(),
                this.mc.player.getZ(), this.mc.player.getYaw(), this.mc.player.getPitch());
        this.freecamEntity.setHeadYaw(this.mc.player.getHeadYaw());
        // PORT: setEntityUniqueID(player uuid) removed — the entity index drops entities whose uuid
        //       is already taken, so the fake would never spawn.
        this.mc.world.addEntity(this.freecamEntity);
    }

    @EventTarget
    public void onEvent(MotionUpdateEvent event) {
        if(event.getState().equals(MotionUpdateEvent.State.PRE)) {
            this.mc.player.noClip = true;
        }
    }

    @EventTarget
    public void onEvent(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.OUTGOING)) {
            if (event.getPacket() instanceof PlayerMoveC2SPacket) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onEvent(CollideWithBlockEvent event) {
        event.setBoundingBox(null);
    }

    @EventTarget
    public void onEvent(MoveEvent event) {
        float speed = this.freecamSpeed.get();
        Vec3d velocity = this.mc.player.getVelocity();
        if (this.mc.player.input.playerInput.jump()) {
            this.mc.player.setVelocity(velocity.x, speed, velocity.z);
            event.setY(speed);
        } else if (this.mc.player.input.playerInput.sneak()) {
            this.mc.player.setVelocity(velocity.x, -speed, velocity.z);
            event.setY(-speed);
        } else {
            this.mc.player.setVelocity(velocity.x, 0.0D, velocity.z);
            event.setY(0.0D);
        }

        event.setMoveSpeed(speed);
    }

    @EventTarget
    public void onEvent(PushBlockEvent event) {
        event.setCancelled(true);
    }

    //region Lombok
    public OtherClientPlayerEntity getFreecamEntity() {
        return this.freecamEntity;
    }
    //endregion

}
