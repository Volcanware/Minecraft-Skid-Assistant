package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;

public final class WaterWalk extends AbstractModule {

    /* properties */

    /* constructors */
    public WaterWalk(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "WaterWalk", "Water Walk", EnumModuleType.MOVEMENT, "");
    }

    /* methods */
    @EventTarget
    public void onPreUpdate(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (!MoveUtils.sneaking(mc.player) && MoveUtils.isInLiquid(mc.player) && neededLevel(event.getX(), event.getY(), event.getZ())) {
                mc.player.setVelocity(mc.player.getVelocity().x, 0.12, mc.player.getVelocity().z);
            }
        }
    }

    private boolean waterUpper(MotionUpdateEvent event) {
        return mc.world.getBlockState(BlockPos.ofFloored(event.getX(),
                mc.player.getBoundingBox().maxY - 1,
                event.getZ())).getBlock() instanceof FluidBlock;
    }

    private boolean neededLevel(double x, double y, double z) {
        BlockState state = mc.world.getBlockState(BlockPos.ofFloored(x, y, z));
        return (state.contains(FluidBlock.LEVEL) ? state.get(FluidBlock.LEVEL) : 15)
                < (isEnabled(Speed.class) ? 2 : 4);
    }
}
