package cc.novoline.modules.configurations.holder;
import org.jetbrains.annotations.NotNull;

import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.ModuleManager.ModuleCreator;
import cc.novoline.modules.configurations.property.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.utils.java.Checks;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.function.BiFunction;

import static cc.novoline.modules.configurations.property.mapper.PropertyMapper.mapPropertyPath;

/**
 * @author xDelsy
 */
public final class CreatingModuleHolder<Module extends AbstractModule> extends ModuleHolder<Module> {

    /* fields */
    @NotNull
    private final ModuleManager moduleManager;
    @NotNull
    private final ModuleCreator<Module> creator;

    @NotNull
    private final Map<@NotNull String, @NotNull PropertyFieldData> fields;

    /* constructors */
    private CreatingModuleHolder(@NotNull ModuleManager moduleManager, @NotNull String name,
                                 @NotNull ModuleCreator<Module> creator) {
        super(name, creator.create(moduleManager));
        this.moduleManager = moduleManager;
        this.creator = creator;
        this.fields = collectFields();
    }

    @NotNull
    public static <Module extends AbstractModule> CreatingModuleHolder<Module> of(@NotNull ModuleManager moduleManager,
                                                                                  @NotNull String name,
                                                                                  @NotNull ModuleCreator<Module> creator) {
        Checks.notNull(moduleManager, "module manager");
        Checks.notBlank(name, "name");
        Checks.notNull(creator, "module creator");

        return new CreatingModuleHolder<>(moduleManager, name, creator);
    }

    /* methods */
    @NotNull
    private Map<@NotNull String, @NotNull PropertyFieldData> collectFields() {
        final Map<@NotNull String, @NotNull PropertyFieldData> fields = new Object2ObjectArrayMap<>();
        final Class<? extends AbstractModule> moduleClass = this.module.getClass();

        for (final Field field : AbstractModule.class.getDeclaredFields()) {
            collectField(fields, field, (s, field1) -> {
                if (s.equalsIgnoreCase("enabled")) {
                    return new EnabledPropertyFieldData(s, field1);
                } else {
                    return new PropertyFieldData(s, field1);
                }
            });
        }

        for (final Field field : moduleClass.getDeclaredFields()) {
            collectField(fields, field, PropertyFieldData::new);
        }

        return fields;
    }

    private void collectField(Map<@NotNull String, @NotNull PropertyFieldData> fields, @NotNull Field field,
                              @NotNull BiFunction<String, Field, PropertyFieldData> constructor) {
        final cc.novoline.modules.configurations.annotation.Property annotation = field
                .getAnnotation(cc.novoline.modules.configurations.annotation.Property.class);

        if (annotation != null) {
            field.setAccessible(true);

            final String path = mapPropertyPath(field, annotation);
            final PropertyFieldData data = constructor.apply(path, field);

            fields.put(path, data);
        }
    }

    @NotNull
    public Module createNew() {
        return this.creator.create(this.moduleManager);
    }

    @NotNull
    public Map<@NotNull String, @NotNull PropertyFieldData> getFields() {
        return this.fields;
    }

    public static class PropertyFieldData {

        @NotNull
        protected final String name;
        @NotNull
        protected final Field field;

        /* constructors */
        private PropertyFieldData(@NotNull String name, @NotNull Field field) {
            this.name = name;
            this.field = field;
        }

        /* methods */
        @SuppressWarnings({"unchecked", "rawtypes"})
        public void copyValue(@NotNull AbstractModule src, @NotNull AbstractModule dest,
                              boolean disable) throws IllegalAccessException {
            Checks.check(dest.getClass().isAssignableFrom(src.getClass()),
                    "cannot copy value of property from different modules");

            final Property srcProperty = (Property) this.field.get(src);
            final Property destProperty = (Property) this.field.get(dest);

            destProperty.set(srcProperty.get());
        }

    }

    public static class EnabledPropertyFieldData extends PropertyFieldData {

        private EnabledPropertyFieldData(@NotNull String name, @NotNull Field field) {
            super(name, field);
        }

        @Override
        public void copyValue(@NotNull AbstractModule src, @NotNull AbstractModule dest,
                              boolean disable) throws IllegalAccessException {
            Checks.check(dest.getClass().isAssignableFrom(src.getClass()),
                    "cannot copy value of property from different modules");

            final BooleanProperty srcProperty = (BooleanProperty) this.field.get(src);
            final BooleanProperty destProperty = (BooleanProperty) this.field.get(dest);

            dest.setEnabled(srcProperty.get());
        }

    }

}
