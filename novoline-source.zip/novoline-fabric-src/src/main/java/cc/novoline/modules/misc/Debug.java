package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render2DEvent;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.move.MoveUtils;
import cc.novoline.modules.move.Speed;
import cc.novoline.utils.fonts.impl.Fonts;
import org.jetbrains.annotations.NotNull;

public class Debug extends AbstractModule {

    public Debug(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.MISC, "Debug");
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        int y = 90;

        try {
            // PORT: mc.timer.timerSpeed is gone in 1.21 — reads the shared MoveUtils.timerSpeed
            // holder that the (planned) RenderTickCounter hook will update.
            for (Object debug : new Object[]{"timer speed: " + (isEnabled(Speed.class) ? 1.0 : MoveUtils.timerSpeed)}) {
                Fonts.SF.SF_20.SF_20.drawString(String.valueOf(debug), 1, y, 0xFFFFFF, true);
                y += Fonts.SF.SF_20.SF_20.getHeight() + 2;
            }

        } catch (NullPointerException ignored) {
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {

    }
}
