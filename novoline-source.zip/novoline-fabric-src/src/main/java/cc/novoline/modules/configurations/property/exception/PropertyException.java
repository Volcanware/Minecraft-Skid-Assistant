package cc.novoline.modules.configurations.property.exception;
import org.jetbrains.annotations.NotNull;

import cc.novoline.modules.configurations.property.Property;

/**
 * @author xDelsy
 */
public class PropertyException extends RuntimeException {

    /* fields */
    @NotNull
    private final Property<?> property;

    /* constructors */
    public PropertyException(@NotNull Property<?> property) {
        this.property = property;
    }

    public PropertyException(String message, @NotNull Property<?> property) {
        super(message);
        this.property = property;
    }

    public PropertyException(String message, Throwable cause, @NotNull Property<?> property) {
        super(message, cause);
        this.property = property;
    }

    public PropertyException(Throwable cause, @NotNull Property<?> property) {
        super(cause);
        this.property = property;
    }

    /* methods */
    //region Lombok
    @NotNull
    public Property<?> getProperty() {
        return this.property;
    }
    //endregion

}
