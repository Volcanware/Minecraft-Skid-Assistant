package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.utils.RenderUtils;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import org.jetbrains.annotations.NotNull;

import java.awt.*;

public class BlockOutline extends AbstractModule {

    public BlockOutline(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "BlocksOutline","Blocks Outline",EnumModuleType.VISUALS,"Outlines the block you're looking at");
    }

    @EventTarget
    public void onRender3D(Render3DEvent event){
        if(mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK){
            BlockPos pos = ((BlockHitResult) mc.crosshairTarget).getBlockPos();
            double x = pos.getX();
            double y = pos.getY();
            double z = pos.getZ();
            double height = mc.world.getBlockState(pos).getOutlineShape(mc.world, pos).getMax(Direction.Axis.Y)
                    - mc.world.getBlockState(pos).getOutlineShape(mc.world, pos).getMin(Direction.Axis.Y);
            // PORT: the twelve GL_LINE_STRIP edges below describe the same wireframe
            // box that RenderUtils' outline helper emits; coordinates stay absolute —
            // the camera offset is applied inside the submission.
            int color = new Color(152, 217, 0).getRGB();
            Box box = new Box(x, y, z, x + 1.0, y + height, z + 1.0);
            RenderUtils.submitWorld(RenderLayers.lines(), (entry, consumer) ->
                    RenderUtils.boxOutlineVertices(consumer, entry.getPositionMatrix(), box, color));

//            original immediate-mode edge list, kept for reference:
//            (x,y,z)->(x,y+height,z) and the three other verticals,
//            bottom square edges and top square edges.
        }
    }

}
