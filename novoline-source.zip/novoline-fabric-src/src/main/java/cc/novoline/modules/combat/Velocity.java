package cc.novoline.modules.combat;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.IntProperty;
import cc.novoline.modules.exploits.Blink;
import cc.novoline.modules.move.Speed;
import cc.novoline.utils.DebugUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

import java.util.concurrent.ThreadLocalRandom;

import static cc.novoline.gui.screen.setting.Manager.put;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.booleanFalse;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createInt;

public final class Velocity extends AbstractModule {

    /* properties @off */
    @Property("alerts")
    private final BooleanProperty alerts = booleanFalse();
    @Property("horizontal")
    private final IntProperty horizontal = createInt(0).minimum(0).maximum(100);
    @Property("vertical")
    private final IntProperty vertical = createInt(0).minimum(0).maximum(100);
    @Property("chance")
    private final IntProperty chance = createInt(100).minimum(0).maximum(100);

    /* constructors @on */
    public Velocity(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Velocity", "Velocity", Keyboard.KEY_NONE, EnumModuleType.COMBAT, "Don't take knockback");
        put(new Setting("ALERTS", "Alerts", SettingType.CHECKBOX, this, alerts));
        put(new Setting("VEL_HOR", "Horizontal", SettingType.SLIDER, this, horizontal, 5));
        put(new Setting("VEL_VER", "Vertical", SettingType.SLIDER, this, vertical, 5));
        put(new Setting("VEL_CHANCE", "Chance", SettingType.SLIDER, this, chance, 5));
    }

    /* methods */
    public boolean shouldCancel() {
        return isEnabled(Blink.class) || horizontal.get().equals(0) && vertical.get().equals(0) || isEnabled(Speed.class);
    }

    @EventTarget
    private void onVelocity(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket) {
                EntityVelocityUpdateS2CPacket packet = (EntityVelocityUpdateS2CPacket) event.getPacket();

                if (packet.getEntityId() == mc.player.getId()) {
                    if (!shouldCancel()) {
                        if (Math.random() <= chance.get() / 100) {
                            // PORT: S12 packet fields are immutable in modern versions; cancel the
                            // packet and apply the scaled velocity to the player directly.
                            event.setCancelled(true);
                            Vec3d velocity = packet.getVelocity();
                            mc.player.setVelocity(velocity.x * horizontal.get() / 100,
                                    velocity.y * vertical.get() / 100,
                                    velocity.z * horizontal.get() / 100);
                        }

                    } else {
                        event.setCancelled(true);
                    }

                    if (alerts.get()) {
                        DebugUtil.log("Velocity", String.valueOf(ThreadLocalRandom.current().nextInt(1000, 10000)));
                    }
                }
            }
        }
    }

    @EventTarget
    private void onExplosion(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (shouldCancel() && event.getPacket() instanceof ExplosionS2CPacket) {
                event.setCancelled(true);
            }
        }
    }

    public void handleExplosion(MinecraftClient gameController, ExplosionS2CPacket packet) {
        // PORT: called by the NetHandlerPlayClient.handleExplosion patch in 1.8.9; needs a hook in
        //       ClientPlayNetworkHandler#onExplosion that calls this (instead of vanilla knockback)
        //       when Velocity is enabled and the packet is not cancelled.
        if (!shouldCancel()) {
            Vec3d knockback = packet.playerKnockback().orElse(Vec3d.ZERO);

            if (Math.random() <= chance.get() / 100) {
                gameController.player.setVelocity(gameController.player.getVelocity().add(
                        knockback.x * horizontal.get() / 100,
                        knockback.y * vertical.get() / 100,
                        knockback.z * horizontal.get() / 100));
            } else {
                gameController.player.setVelocity(gameController.player.getVelocity().add(knockback));
            }
        }
    }

    @EventTarget
    public void onUpdate(TickUpdateEvent event) {
        setSuffix(horizontal.get() + ".0%" + " " + vertical.get() + ".0%");
    }

    @Override
    public void onEnable() {
        setSuffix(horizontal.get() + ".0%" + " " + vertical.get() + ".0%");
    }
}
