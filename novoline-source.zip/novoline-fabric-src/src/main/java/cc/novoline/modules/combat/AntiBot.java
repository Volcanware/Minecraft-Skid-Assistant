package cc.novoline.modules.combat;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.exploits.Blink;
import cc.novoline.modules.player.Freecam;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityPositionS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.stream.Collectors;

import static cc.novoline.modules.EnumModuleType.COMBAT;

public final class AntiBot extends AbstractModule {

    @Property("visible-check")
    private final BooleanProperty visible_check = PropertyFactory.booleanFalse();

    /* constructors */
    public AntiBot(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "AntiBot", "Anti Bot", COMBAT, "Removes server-sided anti-cheat bots to prevent you from getting banned");
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (ServerUtils.isHypixel()) {
            if (!ServerUtils.serverIs(Servers.LOBBY)) {
                if (event.getState().equals(PacketEvent.State.INCOMING)) {
                    // PORT: S18PacketEntityTeleport -> EntityPositionS2CPacket
                    if (event.getPacket() instanceof EntityPositionS2CPacket) {
                        EntityPositionS2CPacket packet = (EntityPositionS2CPacket) event.getPacket();
                        Entity entity = mc.world.getEntityById(packet.entityId());

                        if (entity instanceof PlayerEntity && entity.isInvisible() && entity.age > 3 && mc.world.getPlayers().contains(entity) && !isInTabList((PlayerEntity) entity)) {
                            mc.world.removeEntity(entity.getId(), Entity.RemovalReason.DISCARDED);
                        }
                    }

                    // PORT: S0CPacketSpawnPlayer -> EntitySpawnS2CPacket (players spawn through it now);
                    // coordinates are already absolute, no /32.0 fixed-point decode needed.
                    if (event.getPacket() instanceof EntitySpawnS2CPacket) {
                        EntitySpawnS2CPacket packet = (EntitySpawnS2CPacket) event.getPacket();
                        Entity player = mc.world.getEntityById(packet.getEntityId());

                        double posX = packet.getX(), posY = packet.getY(), posZ = packet.getZ();
                        double difX = mc.player.getX() - posX, difY = mc.player.getY() - posY, difZ = mc.player.getZ() - posZ;
                        double dist = Math.sqrt(difX * difX + difY * difY + difZ * difZ);

                        if (mc.world.getPlayers().contains(player) && dist <= 17.0D && !player.equals(mc.player)
                                && posX != mc.player.getX() && posY != mc.player.getY() && posZ != mc.player.getZ()) {
                            mc.world.removeEntity(player.getId(), Entity.RemovalReason.DISCARDED);
                        }
                    }
                }
            }
        }
    }

    private boolean isInTabList(PlayerEntity player) {
        return mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(player.getGameProfile().id()) != null;
    }

    private List<PlayerEntity> entityPlayersList() {
        return mc.world.getPlayers().stream()
                .filter(e -> !e.equals(mc.player) &&
                        !e.equals(getModule(Blink.class).getBlinkEntity()) &&
                        !e.equals(getModule(Freecam.class).getFreecamEntity()))
                .collect(Collectors.toList());
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        setSuffix("Hypixel");
    }

    @Override
    public void onEnable() {
        setSuffix("Hypixel");
    }
}
