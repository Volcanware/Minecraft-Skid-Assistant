package cc.novoline.modules.combat;

import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.EventTarget;
import cc.novoline.events.events.*;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.modules.exploits.Blink;
import cc.novoline.modules.exploits.Teleport;
import cc.novoline.modules.move.Scaffold;
import cc.novoline.modules.move.Speed;
import cc.novoline.modules.player.Freecam;
import cc.novoline.utils.*;
import cc.novoline.utils.Timer;
import cc.novoline.utils.fonts.impl.Fonts;
import cc.novoline.utils.notifications.NotificationType;
import cc.novoline.utils.pathfinding.AStarCustomPathfinder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.GolemEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.NotNull;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static cc.novoline.modules.configurations.property.object.PropertyFactory.createColor;

public class InfiniteAura extends AbstractModule {
    public InfiniteAura(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.COMBAT, "InfiniteAura");
        Manager.put(new Setting("APS", "APS", SettingType.SLIDER, this, aps, 1.0D));
        Manager.put(new Setting("RANGE", "Range", SettingType.SLIDER, this, range, 0.1));
        Manager.put(new Setting("WALL_RANGE", "Wall Range", SettingType.SLIDER, this, wallRange, 0.1));
        Manager.put(new Setting("TARGETS", "Targets", SettingType.SELECTBOX, this, targets));
        Manager.put(new Setting("KA_FILTER", "Filters", SettingType.SELECTBOX, this, filters));
        Manager.put(new Setting("KA_LAG_CHECK", "Lag Check", SettingType.CHECKBOX, this, lagCheck));
        Manager.put(new Setting("TAR_HUD", "Target HUD", SettingType.CHECKBOX, this, targetHud));
    }


    /* fields */
    private Entity target;
    private int switchIndex;
    private List<Entity> targetList = new CopyOnWriteArrayList<>();
    private final Timer timerAttack = new Timer(), timerSwitch = new Timer(), lossTimer = new Timer();
    private final Dimension screenSize = cc.novoline.utils.AwtCompat.screenSize();
    private final List<Packet<?>> toDispatch = new ArrayList<>();
    private boolean blinking, blocking, sentC08;

    /* properties @off */
    @Property("aps")
    private final DoubleProperty aps = PropertyFactory.createDouble(5.0D).minimum(1.0D).maximum(18.0D);
    @Property("range")
    private final DoubleProperty range = PropertyFactory.createDouble(3.5D).minimum(1.0D).maximum(50.0D);
    @Property("wall-range")
    private final DoubleProperty wallRange = PropertyFactory.createDouble(3.5D).minimum(1.0D).maximum(50.0D);
    @Property("targets")
    private final ListProperty<String> targets = PropertyFactory.createList("Players").acceptableValues("Players", "Animals", "Mobs", "Invisibles");
    @Property("filters")
    private final ListProperty<String> filters = PropertyFactory.createList("Teams").acceptableValues("Teams", "Users", "Armor");
    @Property("target-hud")
    private final BooleanProperty targetHud = PropertyFactory.booleanFalse();
    @Property("lag-check")
    private final BooleanProperty lagCheck = PropertyFactory.booleanFalse();
    @Property("color")
    private final ColorProperty color = createColor(0xFFFFFFFF);
    @Property("th-x")
    private final IntProperty thx = PropertyFactory.createInt((int) screenSize.getWidth() / 4).minimum(1).maximum((int) screenSize.getWidth() / 2);
    @Property("th-y")
    private final IntProperty thy = PropertyFactory.createInt((int) screenSize.getHeight() / 4).minimum(1).maximum((int) screenSize.getHeight() / 2);


    //methods
    @Override
    public void onDisable() {
        target = null;
        targetList.clear();
    }

    @Override
    public void onEnable() {
        lossTimer.reset();
    }

    private boolean hasArmor(@NotNull PlayerEntity e) {
        return !e.getEquippedStack(EquipmentSlot.FEET).isEmpty() || !e.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
                || !e.getEquippedStack(EquipmentSlot.CHEST).isEmpty() || !e.getEquippedStack(EquipmentSlot.HEAD).isEmpty();
    }

    public boolean serverLag() {
        return lagCheck.get() && lossTimer.getLastDelay() >= 100;
    }

    public boolean shouldAttack() {
        return target != null && target.isAlive() && mc.player.distanceTo(target) <=
                (mc.player.canSee(target) ? range() : wallRange()) && !isEnabled(Scaffold.class);
    }

    public boolean shouldRotate() {
        return shouldAttack() && !serverLag() && !isEnabled(Scaffold.class) && !mc.interactionManager.isBreakingBlock();
    }

    private boolean isAutismShopKeeperCheck(Entity target) {
        Text component = target.getDisplayName();
        String formatted = KillAura.getFormattedText(component);
        String unFormatted = component.getString();
        boolean first = !formatted.substring(0, formatted.length() - 2).contains("\u00A7");
        boolean second = formatted.substring(formatted.length() - 2).contains("\u00A7");
        return ServerUtils.isHypixel() && ServerUtils.serverIs(Servers.BW) && first && second;
    }

    @EventTarget
    public void targetSwitching(MotionUpdateEvent e) {
        if (e.getState().equals(MotionUpdateEvent.State.PRE)) {

            if (targetsInRange() > 0) {
                targetList = getTargetsFromRange();
            } else {
                targetList = getEntityList();
            }

            if (target != null && !target.isAlive()) {
                target = null;
            }


            if(target != null){
                if(!canTeleport(target)){
                    target = null;
                }
            }

            if (targetList != null) {
                if (!isContainsTarget()) {
                    if (target != null) {
                        if (mc.player.distanceTo(target) > range() && targetsInRange() > 0) {
                            target = getTargetFromRange();
                        } else if (!target.isAlive() && ((LivingEntity) target).getHealth() <= 0) {
                            target = null;
                        }

                    } else {
                        target = targetList.get(0);
                    }

                } else {
                    for (Entity entity : targetList) {
                        if (novoline.getPlayerManager().hasType(entity.getName().getString(), PlayerManager.EnumPlayerType.TARGET)) {
                            target = entity;
                        }
                    }
                }
            }
        }
    }


    private void attackEntity(Entity target) {
        if (canTeleport(target)) {
            if (timerAttack.delay(1000L / aps.get().longValue())) {
                EventManager.call(new AttackEvent());

                List<Packet<?>> packets = teleport(target);

                packets.forEach(this::sendPacketNoEvent);

                mc.player.swingHand(Hand.MAIN_HAND);
                sendPacket(PlayerInteractEntityC2SPacket.attack(target, mc.player.isSneaking()));

                Collections.reverse(packets);

                packets.forEach(this::sendPacketNoEvent);

                timerAttack.reset();
            }
        }
    }

    @EventTarget
    public void onMotions(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (shouldAttack()) {
                attackEntity(target);
            }
        }
    }

    @EventTarget
    public void onSend(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.OUTGOING)) {
        } else {
            lossTimer.reset();
        }
    }


    @EventTarget
    public void Rotations(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (shouldRotate()) {
                float[] rotations = RotationUtil.getAngles((LivingEntity) target);

                event.setYaw(rotations[0]);
                event.setPitch(rotations[1]);
            }
        }
    }


    public boolean isValidEntity(@NotNull Entity target) {
        final boolean mobsTarget = targets.contains("Mobs"), animalsTarget = targets.contains("Animals"), //
                playersTarget = targets.contains("Players"), invisibleTarget = targets.contains("Invisibles");

        if (target.isAlive() && mc.player.getHealth() > 0.0F && !novoline.getPlayerManager()
                .hasType(target.getName().getString(), PlayerManager.EnumPlayerType.FRIEND)) {
            if (target instanceof HostileEntity || target instanceof SlimeEntity || target instanceof GolemEntity) {
                return mobsTarget && !(target.isInvisible() && !invisibleTarget);
            }

            if (target instanceof AnimalEntity || target instanceof VillagerEntity) {
                return animalsTarget && !(target.isInvisible() && !invisibleTarget);
            }


            if (target instanceof PlayerEntity) {
                return playersTarget
                        && target != mc.player
                        && (!filters.contains("Armor")
                        || hasArmor((PlayerEntity) target))
                        && (!filters.contains("Teams")
                        || !PlayerUtils
                        .inTeam(mc.player, target))
                        && !(target.isInvisible() && !invisibleTarget) &&
                        !isAutismShopKeeperCheck(target)
                        && (!filters.contains("Users"))
                        && target != getModule(Freecam.class).getFreecamEntity()
                        && target != getModule(Blink.class).getBlinkEntity()
                        && target != getModule(Teleport.class).getTeleportEntity();
            }
        }

        return false;
    }

    private boolean isContainsTarget() {
        for (Entity entity : getEntityList().stream()
                .filter(entity -> mc.player.distanceTo(entity) < range())
                .collect(Collectors.toCollection(ObjectArrayList::new))) {
            if (novoline.getPlayerManager().hasType(entity.getName().getString(), PlayerManager.EnumPlayerType.TARGET)) {
                return true;
            }
        }

        return false;
    }

    private List<Entity> getEntityList() {
        List<Entity> list = StreamSupport.stream(mc.world.getEntities().spliterator(), false).filter(this::isValidEntity).collect(Collectors.toList());

        list = list.stream().sorted(Comparator.comparing(o -> o.distanceTo(mc.player)))
                .collect(Collectors.toCollection(ObjectArrayList::new));

        list = list.stream().filter(this::isInReach).collect(Collectors.toList());

        return list.stream().filter(this::canTeleport).collect(Collectors.toList());
    }

    private List<Entity> getTargetsFromRange() {

        List<Entity> collect = getEntityList().stream().filter(e -> mc.player.distanceTo(e) <= range()).collect(Collectors.toList());
        collect = collect.stream().filter(this::canTeleport).collect(Collectors.toList());
        return collect;
    }

    private int targetsInRange() {
        int i = 0;

        if (getEntityList().isEmpty()) {
            return 0;

        } else {
            for (Entity entity : getEntityList()) {
                if (mc.player.distanceTo(entity) <= range()) {
                    i++;
                }
            }

            return i;
        }
    }

    private Entity getTargetFromRange() {
        for (Entity entity : getEntityList()) {
            if (mc.player.distanceTo(entity) <= range()) {
                return entity;
            }
        }

        return null;
    }


    private boolean isInReach(Entity target) {
        return mc.player.distanceTo(target) <= (mc.player.canSee(target) ?
                range() : wallRange());
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (targetHud.get()) {
            if (shouldAttack()) {
                if (target instanceof PlayerEntity && !(mc.currentScreen instanceof ChatScreen)) {
//                    RenderUtils.renderTHUD(this, (PlayerEntity) target);
                }
            }
        }
    }

    @EventTarget
    public void onAutoDisable(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (ServerUtils.serverIs(Servers.DUELS) && event.getPacket() instanceof TitleS2CPacket) {
                final TitleS2CPacket packet = (TitleS2CPacket) event.getPacket();

                // PORT: TitleS2CPacket is a TITLE-only record now (the old Type check is implicit)
                final String text = packet.text().getString();

                if (text.equals("VICTORY!")) {
                    novoline.getNotificationManager().pop("Check chat for stats", 1000, NotificationType.INFO);
                    DebugUtil.log(true, "[" + Formatting.RED + "Stats" + Formatting.GRAY + "] " + Formatting.RESET + "Your hp: " + Formatting.GREEN + mc.player.getHealth());
                }

                if (text.equals("GAME OVER!")) {
                    novoline.getNotificationManager().pop("Check chat for stats", 1000, NotificationType.INFO);
                    DebugUtil.log(true, "[" + Formatting.RED + "Stats" + Formatting.GRAY + "] " + Formatting.RESET + "Opponent hp: " + Formatting.GREEN + ((LivingEntity) target).getHealth());
                }
            }
        }
    }


    //region Lombok
    public Entity getTarget() {
        return target;
    }

    public void setTarget(Entity target) {
        this.target = target;
    }

    public DoubleProperty getAps() {
        return aps;
    }

    public DoubleProperty getRange() {
        return range;
    }

    public DoubleProperty getWallRange() {
        return wallRange;
    }

    public double range() {
        return range.get();
    }


    public double wallRange() {
        return wallRange.get();
    }


    public ListProperty<String> getTargets() {
        return targets;
    }

    public ListProperty<String> getFilters() {
        return filters;
    }

    public BooleanProperty getTargetHud() {
        return targetHud;
    }

    public IntProperty getThx() {
        return thx;
    }

    public IntProperty getThy() {
        return thy;
    }

    public List<Entity> getTargetList() {
        return targetList;
    }

    public boolean lagCheck() {
        return lagCheck.get();
    }

    public Vec3d getPositionForVector(double x, double y, double z) {
        return new Vec3d(x, y, z);
    }


    private boolean canTeleport(Entity entity) {
        if(!mc.player.isOnGround()){
            return false;
        }
        double maximumStepDistance = 0.1;
        double x = entity.getX(), z = entity.getZ();
        float angleYaw = RotationUtil.getYawToPoint(x, z);
        // PORT: Entity#getDistance -> Math.sqrt(squaredDistanceTo)
        double distance = Math.abs(Math.sqrt(mc.player.squaredDistanceTo(x, mc.player.getY(), z))) - 1;

        double height = mc.player.getY();


        for (double step = maximumStepDistance; step < distance; step += maximumStepDistance) {

            double xAxis = -Math.sin(Math.toRadians(angleYaw)) * step;
            double zAxis = Math.cos(Math.toRadians(angleYaw)) * step;

            { // Checking if inside a block
                Vec3d position = getPositionForVector(mc.player.getX() + xAxis, height + 0.01, mc.player.getZ() + zAxis);
                Vec3d startVec = RotationUtil.getVectorForRotation(0, angleYaw);
                Vec3d endVec = position.add(startVec.x * 0.1, startVec.y * 0.1, startVec.z * 0.1);
                BlockHitResult blockAhead = mc.world.raycast(new RaycastContext(position, endVec,
                        RaycastContext.ShapeType.COLLIDER,
                        RaycastContext.FluidHandling.NONE,
                        mc.player));
                if (blockAhead != null) {
                    if (blockAhead.getType() == HitResult.Type.BLOCK) {
                        return false;
                    }
                }
            }

            { // Checking if there's a block below
                BlockPos pos = new BlockPos((int) Math.floor(mc.player.getX() + xAxis), (int) Math.floor(height - 1), (int) Math.floor(mc.player.getZ() + zAxis));
                if(mc.world.getBlockState(pos).getBlock() == Blocks.AIR || !mc.world.getBlockState(pos).isSolidBlock(mc.world, pos)){
                    return false;
                }
            }


        }
        return true;
    }

    private List<Packet<?>> teleport(Entity entity) {
        List<Packet<?>> packets = new CopyOnWriteArrayList<>();
        double maximumStepDistance = 0.23061663902;
        double x = entity.getX(), z = entity.getZ();
        float angleYaw = RotationUtil.getYawToPoint(x, z);
        double distance = Math.abs(Math.sqrt(mc.player.squaredDistanceTo(x, mc.player.getY(), z))) - 1;

        double height = mc.player.getY();

        for (double step = maximumStepDistance; step < distance; step += maximumStepDistance) {

            double xAxis = -Math.sin(Math.toRadians(angleYaw)) * step;
            double zAxis = Math.cos(Math.toRadians(angleYaw)) * step;

            packets.add(new PlayerMoveC2SPacket.PositionAndOnGround(
                    mc.player.getX() + xAxis,
                    height,
                    mc.player.getZ() + zAxis,
                    true,
                    mc.player.horizontalCollision
            ));
        }

        return packets;
    }


    //endregion

}
