package cc.novoline.modules.configurations.property.exception;
import org.jetbrains.annotations.NotNull;

import cc.novoline.modules.configurations.property.AbstractNumberProperty;

/**
 * @author xDelsy
 */
public final class NumberLimitsException extends NumberException {

    public NumberLimitsException(@NotNull AbstractNumberProperty<?, ?> property) {
        super(property);
    }

    public NumberLimitsException(String message, @NotNull AbstractNumberProperty<?, ?> property) {
        super(message, property);
    }

    public NumberLimitsException(String message, Throwable cause, @NotNull AbstractNumberProperty<?, ?> property) {
        super(message, cause, property);
    }

    public NumberLimitsException(Throwable cause, @NotNull AbstractNumberProperty<?, ?> property) {
        super(cause, property);
    }

}
