package cc.novoline.modules.misc;

import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.move.FastSneak;
import cc.novoline.utils.NovolineInput;
import cc.novoline.mixin.KeyBindingAccessor;
import net.minecraft.client.input.Input;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.jetbrains.annotations.NotNull;

public final class GuiMove extends AbstractModule {

    @Property("sneak")
    private final BooleanProperty sneak = PropertyFactory.createBoolean(false);

    /* constructors */
    public GuiMove(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "GuiMove", "Gui Move", EnumModuleType.MISC, "Allows you to walk with an opened GUI");
        Manager.put(new Setting("GM_SNEAK", "Sneak", SettingType.CHECKBOX, this, sneak));
    }

    public void updatePlayerMoveState() {
        Input input = mc.player.input;
        NovolineInput movementInput = (NovolineInput) input;

        movementInput.novoline$setMoveStrafe(0.0F);
        movementInput.novoline$setMoveForward(0.0F);

        if (isKeyDown(mc.options.forwardKey)) {
            movementInput.novoline$setMoveForward(movementInput.novoline$getMoveForward() + 1);
        }

        if (isKeyDown(mc.options.backKey)) {
            movementInput.novoline$setMoveForward(movementInput.novoline$getMoveForward() - 1);
        }

        if (isKeyDown(mc.options.leftKey)) {
            movementInput.novoline$setMoveStrafe(movementInput.novoline$getMoveStrafe() + 1);
        }

        if (isKeyDown(mc.options.rightKey)) {
            movementInput.novoline$setMoveStrafe(movementInput.novoline$getMoveStrafe() - 1);
        }

        movementInput.novoline$setJump(isKeyDown(mc.options.jumpKey));
        movementInput.novoline$setSneak(sneak.get() && isKeyDown(mc.options.sneakKey) || mc.options.sneakKey.isPressed());

        if (input.playerInput.sneak() && !isEnabled(FastSneak.class)) {
            movementInput.novoline$setMoveStrafe(movementInput.novoline$getMoveStrafe() * 0.3F);
            movementInput.novoline$setMoveForward(movementInput.novoline$getMoveForward() * 0.3F);
        }
    }

    private boolean isKeyDown(KeyBinding keyBinding) {
        return InputUtil.isKeyPressed(mc.getWindow(), ((KeyBindingAccessor) keyBinding).novoline$getBoundKey().getCode());
    }
}
