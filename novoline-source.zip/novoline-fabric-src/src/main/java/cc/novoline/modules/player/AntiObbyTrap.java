package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.FurnaceBlock;
import net.minecraft.block.Blocks;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

import java.util.concurrent.ThreadLocalRandom;

public final class AntiObbyTrap extends AbstractModule {

    private float currentDamage;
    private boolean digging;

    public AntiObbyTrap(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "AntiObbyTrap", "Anti Obby Trap", Keyboard.KEY_NONE, EnumModuleType.PLAYER,
                "Stop being a bot and falling for obby traps");
    }

    @EventTarget
    public void onPre(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (this.mc.world.getBlockState(BlockPos.ofFloored(event.getX(), event.getY() + 1, event.getZ()))
                    .getBlock() == Blocks.OBSIDIAN || this.mc.world.getBlockState(BlockPos.ofFloored(event.getX(), event.getY() + 1, event.getZ()))
                    .getBlock() == Blocks.COBBLESTONE || this.mc.world.getBlockState(BlockPos.ofFloored(event.getX(), event.getY() + 2, event.getZ()))
                    .getBlock() instanceof FurnaceBlock) {
                event.setPitch(89 + ThreadLocalRandom.current().nextFloat());
                BlockState currentBlock = this.mc.world.getBlockState(BlockPos.ofFloored(event.getX(), event.getY() - 1, event.getZ()));
                BlockPos pos = BlockPos.ofFloored(event.getX(), event.getY() - 1, event.getZ());

                if (this.currentDamage == 0.0F) {
                    this.digging = true;
                    sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.START_DESTROY_BLOCK, pos, Direction.UP));
                }

                PlayerHelper.updateTool(mc, pos);
                sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
                this.currentDamage += currentBlock.calcBlockBreakingDelta(this.mc.player, this.mc.world, pos);
                this.mc.world.setBlockBreakingInfo(this.mc.player.getId(), pos, (int) (this.currentDamage * 10.0F) - 1);

                if (this.currentDamage >= 1.0F) {
                    sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, pos, Direction.UP));
                    this.mc.interactionManager.breakBlock(pos); // PORT: was playerController.onPlayerDestroyBlock(pos, face)
                    this.currentDamage = 0.0F;
                    this.digging = false;
                }
            } else {
                this.currentDamage = 0.0F;
                this.digging = false;
            }
        }
    }

    public boolean isDigging() {
        return digging;
    }

}
