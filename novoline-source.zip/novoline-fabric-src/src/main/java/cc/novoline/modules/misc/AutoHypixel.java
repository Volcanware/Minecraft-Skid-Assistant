package cc.novoline.modules.misc;

import cc.novoline.Novoline;
import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.utils.Channels;
import cc.novoline.utils.ServerUtils;
import cc.novoline.utils.Servers;
import cc.novoline.utils.Timer;
import cc.novoline.utils.notifications.NotificationType;
import cc.novoline.utils.tasks.FutureTask;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerAbilitiesS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

import static cc.novoline.modules.configurations.property.object.PropertyFactory.createString;

public class AutoHypixel extends AbstractModule {

    @Property("reconnect")
    private final BooleanProperty reconnect = PropertyFactory.booleanFalse();
    @Property("quick_math")
    private final BooleanProperty quick_math = PropertyFactory.booleanFalse();
    @Property("auto-play")
    private final BooleanProperty auto_play = PropertyFactory.booleanFalse();
    @Property("delay")
    private final IntProperty delay = PropertyFactory.createInt(3).minimum(1).maximum(10);
    @Property("auto-pit")
    private final BooleanProperty auto_pit = PropertyFactory.booleanFalse();
    @Property("auto-sw")
    private final BooleanProperty auto_sw = PropertyFactory.booleanFalse();
    @Property("auto-uhc")
    private final BooleanProperty auto_uhc = PropertyFactory.booleanFalse();
    @Property("craft-list")
    private final ListProperty<String> crafts = PropertyFactory.createList("Planks").acceptableValues("Planks");
    @Property("min-bounty")
    private final IntProperty min_bounty = PropertyFactory.createInt(500).minimum(50).maximum(5000);
    @Property("auto-tar")
    private final BooleanProperty auto_tar = PropertyFactory.booleanFalse();
    @Property("auto-gg")
    private final BooleanProperty auto_gg = PropertyFactory.booleanFalse();
    @Property("message")
    private final StringProperty message = createString("GG");
    @Property("death-tp")
    private final BooleanProperty death_tp = PropertyFactory.booleanFalse();
    @Property("auto-paper")
    private final BooleanProperty auto_paper = PropertyFactory.booleanFalse();

    private List<Entity> entities = new CopyOnWriteArrayList<>();
    private boolean send, queued;
    private int tpX, tpY, tpZ;
    private Timer timer = new Timer();

    public AutoHypixel(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.MISC, "AutoHypixel", "Auto Hypixel");
        Manager.put(new Setting("AH_CRAFTS", "Auto Crafts", SettingType.SELECTBOX, this, crafts));
        Manager.put(new Setting("AH_PIT_DEATH_TP", "Death TP", SettingType.CHECKBOX, this, death_tp));
        Manager.put(new Setting("AH_UHC_UHC", "Auto UHC", SettingType.CHECKBOX, this, auto_uhc));
        Manager.put(new Setting("AH_PIT", "Auto Pit", SettingType.CHECKBOX, this, auto_pit));
        Manager.put(new Setting("AH_UHC_QM", "Quick Math", SettingType.CHECKBOX, this, quick_math, auto_pit::get));
        Manager.put(new Setting("AH_UHC_AT", "Target Bounty", SettingType.CHECKBOX, this, auto_tar, auto_pit::get));
        Manager.put(new Setting("AH_BOUNTY", "Minimal Bounty", SettingType.SLIDER, this, min_bounty, 50, () -> auto_pit.get() && auto_tar.get()));
        Manager.put(new Setting("AH_UHC_REC", "Reconnect", SettingType.CHECKBOX, this, reconnect));
        Manager.put(new Setting("AH_UHC_AA", "Auto Play", SettingType.CHECKBOX, this, auto_play));
        Manager.put(new Setting("AP_DELAY", "Delay (Seconds)", SettingType.SLIDER, this, this.delay, 1, auto_play::get));
        Manager.put(new Setting("AH_AUTO_GG", "Auto GG", SettingType.CHECKBOX, this, auto_gg));
        Manager.put(new Setting("AH_AUTO_GG_TEXT", "Message", SettingType.TEXTBOX, this, "Message text", this.message, auto_gg::get));
        Manager.put(new Setting("AH_SW", "Auto SkyWars", SettingType.CHECKBOX, this, auto_sw));
        Manager.put(new Setting("AH_SW_APG", "Paper Challenge", SettingType.CHECKBOX, this, auto_paper, auto_sw::get));
    }

    @EventTarget
    public void onPreUpdate(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            for (Entity playerEntity : entities) {
                if (!mc.world.getPlayers().contains(playerEntity)) {
                    entities.remove(playerEntity);
                    novoline.getPlayerManager().removeType(playerEntity.getName().getString(), PlayerManager.EnumPlayerType.TARGET);
                }
            }

            if (crafts.contains("Planks")) {
                for (int slotIndex = 0; slotIndex < 36; slotIndex++) {
                    ItemStack stack = mc.player.getInventory().getStack(slotIndex);

                    if (!stack.isEmpty()) {
                        // PORT: numeric item ids 17/162 (log/log2) -> ItemTags.LOGS
                        if (stack.isIn(ItemTags.LOGS)) {
                            int slot = slotIndex < 9 ? slotIndex + 36 : slotIndex;
                            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot, 0, SlotActionType.PICKUP, mc.player);
                            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, 3, 0, SlotActionType.PICKUP, mc.player); //крафт слот 1-4
                            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, 0, 0, SlotActionType.QUICK_MOVE, mc.player);
                        }
                    }
                }
            }

            if (auto_pit.get()) {
                if (auto_tar.get()) {
                    for (AbstractClientPlayerEntity playerEntity : mc.world.getPlayers()) {
                        if (!playerEntity.equals(mc.player)) {
                            String displayName = getFormattedText(playerEntity.getDisplayName());
                            String name = playerEntity.getName().getString();

                            if (displayName.contains("§6§l")) {
                                String[] split = displayName.split(" ");
                                if (split.length > 2) {
                                    int bounty = Integer.parseInt(
                                            split[split.length - 1].
                                                    replace("§6§l", "").
                                                    replace("g", ""));
                                    if (bounty >= min_bounty.get()) {
                                        if (!entities.contains(playerEntity) && !novoline.getPlayerManager().hasType(playerEntity.getName().getString(), PlayerManager.EnumPlayerType.FRIEND)) {
                                            entities.add(playerEntity);
                                            novoline.getNotificationManager().pop("Found a bountied player", playerEntity.getName().getString() + " has " + Formatting.GOLD + bounty + "g" + Formatting.RESET + " on him!", 7000, NotificationType.INFO);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    for (Entity playerEntity : entities) {
                        if (novoline.getPlayerManager().hasType(playerEntity.getName().getString(), PlayerManager.EnumPlayerType.FRIEND)) {
                            entities.remove(playerEntity);
                            novoline.getPlayerManager().removeType(playerEntity.getName().getString(), PlayerManager.EnumPlayerType.TARGET);
                            break;
                        }
                        String displayName = getFormattedText(playerEntity.getDisplayName());
                        String name = playerEntity.getName().getString();

                        novoline.getPlayerManager().setType(playerEntity.getName().getString(), PlayerManager.EnumPlayerType.TARGET);

                        if (displayName.contains("§6§l")) {
                            String[] split = displayName.split(" ");
                            if (split.length < 3) {
                                entities.remove(playerEntity);
                                novoline.getPlayerManager().removeType(playerEntity.getName().getString(), PlayerManager.EnumPlayerType.TARGET);
                            } else {
                                int bounty = Integer.parseInt(
                                        split[split.length - 1].
                                                replace("§6§l", "").
                                                replace("g", ""));
                                if (bounty < min_bounty.get()) {
                                    entities.remove(playerEntity);
                                    novoline.getPlayerManager().removeType(playerEntity.getName().getString(), PlayerManager.EnumPlayerType.TARGET);
                                }
                            }
                        } else {
                            entities.remove(playerEntity);
                            novoline.getPlayerManager().removeType(playerEntity.getName().getString(), PlayerManager.EnumPlayerType.TARGET);
                        }

                    }
                }
            }
        }
    }

    @EventTarget
    public void features(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (reconnect.get()) {
                reconnect(event);
            }

            if (auto_play.get()) {
                autoplay(event);
            }

            if (auto_pit.get() && quick_math.get()) {
                quickmath(event);
            }

            if (death_tp.get()) {
                deathtp(event);
            }

            if (auto_gg.get()) {
                autogg(event);
            }
        }
    }

    private void reconnect(PacketEvent event) {
        if (event.getPacket() instanceof GameMessageS2CPacket) {
            GameMessageS2CPacket packet = (GameMessageS2CPacket) event.getPacket();
            String message = packet.content().getString();

            if (message.contains("Flying or related")) {
                sendPacketNoEvent(new CommandExecutionC2SPacket("back"));
            }
        }
    }

    private void autoplay(PacketEvent packetEventReceive) {
        if (packetEventReceive.getPacket() instanceof GameMessageS2CPacket) {
            final GameMessageS2CPacket packet = (GameMessageS2CPacket) packetEventReceive.getPacket();
            // PORT: IChatComponent#toString click-event scraping -> walk the Text tree for a
            // ClickEvent.RunCommand (its command() is the old value='...' payload).
            final String command = findRunCommand(packet.content());

            if (command != null && (command.startsWith("/play ") || command.startsWith("play "))) {
                final String split = command.startsWith("/") ? command.substring(1) : command;
                Novoline.getInstance().getNotificationManager().pop("Sending you to the next game in ", delay.get() * 1000, NotificationType.INFO);

                Novoline.getInstance().getTaskManager().queue(new FutureTask(this.delay.get() * 1_000) {

                    @Override
                    public void execute() {
                        sendPacket(new CommandExecutionC2SPacket(split));
                    }

                    @Override
                    public void run() {
                    }
                });
            }
        }
    }

    private void autogg(PacketEvent e) {
        if (e.getPacket() instanceof TitleS2CPacket) {
            TitleS2CPacket packet = (TitleS2CPacket) e.getPacket();

            if (!isEnabled(Spammer.class) && packet.text().getString().equals("VICTORY!")) {
                if (message.get().startsWith("/")) {
                    sendPacketNoEvent(new CommandExecutionC2SPacket(message.get().substring(1)));
                } else if (!ServerUtils.isHypixel() || !ServerUtils.channelIs(Channels.PM)) {
                    if (message.get().toLowerCase().startsWith("gg")) {
                        sendChatMessageNoEvent(message.get());
                    } else {
                        mc.player.networkHandler.sendChatMessage(message.get());
                    }
                }
            }
        }
    }

    private void quickmath(PacketEvent event) {
        if (event.getPacket() instanceof GameMessageS2CPacket) {
            GameMessageS2CPacket packetChat = (GameMessageS2CPacket) event.getPacket();
            String text = packetChat.content().getString();

            if (text.contains("QUICK MATHS! Solve:")) {
                String[] eArray = text.split("Solve: ");

                // PORT: javax.script "JavaScript" (Nashorn) no longer ships with the JDK —
                // replaced with an equivalent arithmetic evaluator for + - x / ( ).
                try {
                    double result = evalExpression(eArray[1].replace("x", "*"));
                    String answer = result == Math.floor(result) && !Double.isInfinite(result)
                            ? String.valueOf((long) result)
                            : String.valueOf(result);
                    sendChatMessageNoEvent(answer);
                } catch (RuntimeException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void deathtp(PacketEvent event) {
        if (ServerUtils.isHypixel()) {
            if (event.getState().equals(PacketEvent.State.INCOMING)) {
                if (ServerUtils.serverIs(Servers.PIT)) {
                    if (event.getPacket() instanceof TitleS2CPacket) {
                        TitleS2CPacket title = (TitleS2CPacket) event.getPacket();

                        if (getFormattedText(title.text()).contains("YOU DIED") || getFormattedText(title.text()).contains("VOUS ETES MORT")) {
                            tpX = (int) mc.player.getX();
                            tpY = (int) mc.player.getY();
                            tpZ = (int) mc.player.getZ();
                            mc.player.networkHandler.sendChatMessage(".tp " + tpX + " " + tpY + " " + tpZ + " " + "goteleportnigga");
                        }
                    }
                } else if (ServerUtils.serverIs(Servers.BW)) {
                    if (event.getPacket() instanceof PlayerAbilitiesS2CPacket) {
                        PlayerAbilitiesS2CPacket packet = (PlayerAbilitiesS2CPacket) event.getPacket();

                        if (packet.isFlying()) {
                            timer.reset();
                        }
                    }

                    if (event.getPacket() instanceof TitleS2CPacket && !queued) {
                        TitleS2CPacket title = (TitleS2CPacket) event.getPacket();

                        if (getFormattedText(title.text()).contains("YOU DIED")) {
                            send = true;
                            queued = true;
                        }
                    }


                    if (send) {
                        novoline.getTaskManager().queue(new FutureTask(5100) {
                            @Override
                            public void execute() {
                                mc.player.networkHandler.sendChatMessage(".tp " + tpX + " " + tpY + " " + tpZ + " " + "goteleportnigga");
                                queued = false;
                            }

                            @Override
                            public void run() {
                            }
                        });
                        send = false;
                    }
                }
            }
        }
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (death_tp.get() && ServerUtils.serverIs(Servers.BW)) {
            if (mc.player.isOnGround() && mc.player.getY() % 0.125 == 0) {
                tpX = (int) mc.player.getX();
                tpY = (int) mc.player.getY();
                tpZ = (int) mc.player.getZ();
            }
        }
    }

    private int getAndurilInHotbar() {
        int slot = -1;

        for (int i = 0; i < 9; ++i) {
            if (!mc.player.getInventory().getStack(i).isEmpty() && mc.player.getInventory().getStack(i).getCount() != 0) {
                ItemStack itemStack = mc.player.getInventory().getStack(i);
                if (getFormattedText(itemStack.getName()).equalsIgnoreCase("§aAndûril") && !itemStack.isEmpty() && itemStack.getCount() != 0) {
                    slot = i;
                }
            }
        }

        return slot;
    }

    /* PORT helpers */

    // PORT: C01PacketChatMessage no longer exists — plain text goes through sendChatMessage,
    // wrapped in the noEventSend flag to reproduce sendPacketNoEvent semantics.
    private void sendChatMessageNoEvent(String message) {
        if (mc.player == null) {
            return;
        }

        novoline.getNoEventSend().set(true);
        try {
            mc.player.networkHandler.sendChatMessage(message);
        } finally {
            novoline.getNoEventSend().remove();
        }
    }

    // PORT: IChatComponent#getFormattedText equivalent — emits legacy § formatting codes
    // reconstructed from each component's Style, matching the 1.8.9 string layout
    // (codes + text + §r per component, siblings depth-first). Package-private for AntiAtlas.
    static String getFormattedText(Text text) {
        StringBuilder builder = new StringBuilder();
        appendFormatted(text, builder);
        return builder.toString();
    }

    private static void appendFormatted(Text text, StringBuilder builder) {
        builder.append(formattingCode(text.getStyle()));
        text.getContent().visit(s -> {
            builder.append(s);
            return Optional.empty();
        });
        builder.append(Formatting.RESET);

        for (Text sibling : text.getSiblings()) {
            appendFormatted(sibling, builder);
        }
    }

    private static String formattingCode(Style style) {
        StringBuilder builder = new StringBuilder();
        TextColor color = style.getColor();

        if (color != null) {
            for (Formatting formatting : Formatting.values()) {
                if (formatting.isColor() && formatting.getColorValue() != null
                        && formatting.getColorValue() == color.getRgb()) {
                    builder.append(formatting);
                    break;
                }
            }
        }

        if (style.isBold()) builder.append(Formatting.BOLD);
        if (style.isObfuscated()) builder.append(Formatting.OBFUSCATED);
        if (style.isStrikethrough()) builder.append(Formatting.STRIKETHROUGH);
        if (style.isUnderlined()) builder.append(Formatting.UNDERLINE);
        if (style.isItalic()) builder.append(Formatting.ITALIC);

        return builder.toString();
    }

    private static String findRunCommand(Text text) {
        ClickEvent clickEvent = text.getStyle().getClickEvent();

        if (clickEvent instanceof ClickEvent.RunCommand) {
            return ((ClickEvent.RunCommand) clickEvent).command();
        }

        for (Text sibling : text.getSiblings()) {
            String command = findRunCommand(sibling);
            if (command != null) {
                return command;
            }
        }

        return null;
    }

    // PORT: replaces the Nashorn JS engine used for Hypixel "QUICK MATHS" — same
    // + - * / ( ) decimal grammar, evaluating the chat-provided expression.
    private static double evalExpression(String expression) {
        return new Object() {
            int pos = -1, ch;

            void next() {
                ch = ++pos < expression.length() ? expression.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') next();
                if (ch == charToEat) {
                    next();
                    return true;
                }
                return false;
            }

            double parse() {
                next();
                return parseExpression();
            }

            double parseExpression() {
                double x = parseTerm();
                for (; ; ) {
                    if (eat('+')) x += parseTerm();
                    else if (eat('-')) x -= parseTerm();
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (; ; ) {
                    if (eat('*')) x *= parseFactor();
                    else if (eat('/')) x /= parseFactor();
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor();
                if (eat('-')) return -parseFactor();

                double x;
                int startPos = pos;

                if (eat('(')) {
                    x = parseExpression();
                    eat(')');
                } else {
                    while ((ch >= '0' && ch <= '9') || ch == '.') next();
                    if (startPos == pos) throw new IllegalArgumentException("Unexpected: " + (char) ch);
                    x = Double.parseDouble(expression.substring(startPos, pos));
                }

                return x;
            }
        }.parse();
    }

    @Override
    public void onDisable() {
        if (!entities.isEmpty()) {
            entities.clear();
        }
    }

    public boolean isAutoSW() {
        return auto_sw.get();
    }

    public boolean isAutoPaper() {
        return auto_paper.get();
    }

    public BooleanProperty getDeath_tp() {
        return death_tp;
    }
}
