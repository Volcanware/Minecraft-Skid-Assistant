package cc.novoline.modules.configurations.property.mapper;
import org.jetbrains.annotations.NotNull;

import cc.novoline.modules.configurations.annotation.Property;
import com.google.common.reflect.TypeToken;
import ninja.leaping.configurate.objectmapping.ObjectMapper;
import ninja.leaping.configurate.objectmapping.ObjectMappingException;

import java.lang.reflect.Field;
import java.util.Map;

/**
 * @author xDelsy
 */
public final class PropertyMapper<T> extends ObjectMapper<T> {

    protected PropertyMapper(Class<T> clazz) throws ObjectMappingException {
        super(clazz);
    }

    /**
     * configurate 3.7.1: the constructor calls the {@code TypeToken} overload in
     * non-legacy mode, and the {@code Class} overload is a deprecated no-op.
     * Both are overridden here so {@code @Property} fields are collected either
     * way; classes without any {@code @Property} fields fall back to vanilla
     * {@code @Setting} collection (e.g. {@code ClientConfig}).
     */
    @Override
    protected void collectFields(Map<String, FieldData> cachedFields,
                                 TypeToken<? super T> type) throws ObjectMappingException {
        if (!collectPropertyFields(cachedFields, type.getRawType())) {
            super.collectFields(cachedFields, type);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void collectFields(Map<String, FieldData> cachedFields,
                                 @NotNull Class<? super T> clazz) throws ObjectMappingException {
        // legacy path (ObjectMapper.isLegacy): still used when this overload is
        // declared; delegate to the real collection logic
        if (!collectPropertyFields(cachedFields, clazz)) {
            super.collectFields(cachedFields, TypeToken.of(clazz));
        }
    }

    private boolean collectPropertyFields(Map<String, FieldData> cachedFields,
                                          @NotNull Class<?> clazz) throws ObjectMappingException {
        boolean b = false;

        for (final Field field : clazz.getDeclaredFields()) {
            if (cc.novoline.modules.configurations.property.Property.class.isAssignableFrom(field.getType()) && field
                    .isAnnotationPresent(Property.class)) {
                b = true;

                field.setAccessible(true);
                final FieldData data = new FieldData(field, null) {
                    @Override
                    public void deserializeFrom(Object instance,
                                                ninja.leaping.configurate.ConfigurationNode node) throws ObjectMappingException {
                        PropertyFieldData.deserialize(instance, node, field);
                    }
                };

                final Property property = field.getAnnotation(Property.class);
                final String path = mapPropertyPath(field, property);

                if (!cachedFields.containsKey(path)) {
                    cachedFields.put(path, data);
                }
            }
        }

        return b;
    }

    @NotNull
    public static String mapPropertyPath(@NotNull Field field, @NotNull Property annotation) {
        return annotation.value();
    }

}
