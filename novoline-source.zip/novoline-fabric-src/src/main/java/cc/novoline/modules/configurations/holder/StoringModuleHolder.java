package cc.novoline.modules.configurations.holder;
import org.jetbrains.annotations.NotNull;

import cc.novoline.modules.AbstractModule;
import cc.novoline.utils.java.Checks;

/**
 * @author xDelsy
 */
public final class StoringModuleHolder<Module extends AbstractModule> extends ModuleHolder<Module> {

    /* constructors */
    private StoringModuleHolder(@NotNull String name, @NotNull Module module) {
        super(name, module);
    }

    @NotNull
    public static <Module extends AbstractModule> StoringModuleHolder<Module> of(@NotNull String name,
                                                                                 @NotNull Module module) {
        Checks.notBlank(name, "name");
        Checks.notNull(module, "module");

        return new StoringModuleHolder<>(name, module);
    }

    /* methods */
    //region Lombok
    public void setModule(@NotNull Module module) {
        Checks.notNull(module, "module");
        this.module = module;
    }
    //endregion

}
