package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.modules.configurations.property.object.StringProperty;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Mouse;

public class ClickTeleport extends AbstractModule {

    @Property("mouse-button")
    private final StringProperty mouse_button = PropertyFactory.createString("Side Front").acceptableValues("Left", "Right", "Middle", "Side Front", "Side Back");

    public ClickTeleport(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.PLAYER, "ClickTeleport", "Click Teleport");
        Manager.put(new Setting("CT_MOUSE_BUTTON", "Mouse", SettingType.COMBOBOX, this, mouse_button));
    }

    private boolean down;

    private int button() {
        if (mouse_button.equals("Left")) {
            return 0;
        } else if (mouse_button.equals("Right")) {
            return 1;
        } else if (mouse_button.equals("Middle")) {
            return 2;
        } else if (mouse_button.equals("Side Back")) {
            return 3;
        } else if (mouse_button.equals("Side Front")) {
            return 4;
        } else {
            return -1;
        }
    }

    @EventTarget
    private void onMotions(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (mc.currentScreen == null) {
                if (Mouse.isButtonDown(button())) {
                    if (down) {
                        if (rayTrace() != null) {
                            int xNew = rayTrace().getBlockPos().getX();
                            int yNew = rayTrace().getBlockPos().getY();
                            int zNew = rayTrace().getBlockPos().getZ();
                            mc.player.networkHandler.sendChatMessage(".tp " + xNew + " " + yNew + " " + zNew);
                        }

                        down = false;
                    }

                } else {
                    down = true;
                }
            }
        }
    }

/*    public void tpToPos(double xNew, double yNew, double zNew) {
        double distance = mc.player.getDistance(xNew, yNew, zNew);

        for (double dist = 0.0D; dist < distance; dist += 1.0D) {
            double xPos = mc.player.posX + (xNew - mc.player.getHorizontalFacing().getFrontOffsetX() - mc.player.posX) * dist / distance;
            double yPos = mc.player.posY + (yNew - mc.player.posY) * dist / distance;
            double zPos = mc.player.posZ + (zNew - mc.player.getHorizontalFacing().getFrontOffsetZ() - mc.player.posZ) * dist / distance;
            setPos(xPos, yPos, zPos);
        }

        checkModule(Flight.class);
        setPos(xNew, yNew, zNew);
    }*/

    public BlockHitResult rayTrace() {
        Vec3d posVec = new Vec3d(mc.player.getX(), mc.player.getY() + mc.player.getStandingEyeHeight(), mc.player.getZ());
        Vec3d rotVec = getVectorForRotation(mc.player.getPitch(), mc.player.getYaw());
        Vec3d endVec = posVec.add(rotVec.x * 500, rotVec.y * 500, rotVec.z * 500);
        // PORT: rayTraceBlocks(start, end, stopOnLiquid, ignoreNonCube, returnLastUncollidable) -> RaycastContext
        //       (stopOnLiquid=false -> FluidHandling.NONE, ignoreNonCube=false -> ShapeType.COLLIDER)
        return mc.world.raycast(new RaycastContext(posVec, endVec, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
    }

    protected final Vec3d getVectorForRotation(float pitch, float yaw) {
        float f = MathHelper.cos(Math.toRadians(-yaw) - (float) Math.PI);
        float f1 = MathHelper.sin(Math.toRadians(-yaw) - (float) Math.PI);
        float f2 = -MathHelper.cos(Math.toRadians(-pitch));
        float f3 = MathHelper.sin(Math.toRadians(-pitch));
        return new Vec3d(f1 * f2, f3, f * f2);
    }

/*    public void setPos(double x, double y, double z) {
        if (mc.isSingleplayer() || ServerUtils.isHypixel()) {
            sendPacket(new C04PacketPlayerPosition(x, y, z, true));
        } else {
            sendPacket(new C04PacketPlayerPosition(x, y, z, false));
        }

        //    mc.player.setPositionAndUpdate(x, y, z);
    }*/
}
