package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import net.minecraft.client.gui.screen.DeathScreen;
import org.jetbrains.annotations.NotNull;

public final class Respawn extends AbstractModule {

    /* constructors */
    public Respawn(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Respawn", EnumModuleType.MISC, "Respawns you");
    }

    /* events */
    @EventTarget
    public void onUpdate(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            // PORT: GuiGameOver -> DeathScreen; EntityPlayerSP#respawnPlayer -> ClientPlayerEntity#requestRespawn
            if (this.mc.currentScreen instanceof DeathScreen) {
                this.mc.player.requestRespawn();
            }
        }
    }

}
