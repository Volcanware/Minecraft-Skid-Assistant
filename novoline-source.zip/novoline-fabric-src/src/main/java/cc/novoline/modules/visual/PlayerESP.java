package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render2DEvent;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.events.events.RenderNameTagEvent;
import cc.novoline.events.events.UpdateModelEvent;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.combat.KillAura;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.utils.NovolineRenderLayers;
import cc.novoline.utils.PlayerUtils;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.ScaledResolution;
import cc.novoline.utils.Timer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.util.List;
import java.util.*;

import static cc.novoline.gui.screen.setting.Manager.put;
import static cc.novoline.gui.screen.setting.SettingType.CHECKBOX;
import static cc.novoline.gui.screen.setting.SettingType.COLOR_PICKER;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createColor;

public final class PlayerESP extends AbstractModule {

    private final Color WHITE = new Color(255, 255, 255);
    private final Color TEAM = new Color(0, 231, 255, 255);
    private final Color TARGET = new Color(255, 59, 59, 255);
    private final Color FRIEND = new Color(169, 255, 43, 255);
    private final Color BLACK = new Color(0, 0, 0, 100);

    private int percent = 0;

    private Timer tpTimer = new Timer();

    /* properties @off */
    private final List<PlayerEntity> collectedEntities = new ArrayList<>();
    private final Map<PlayerEntity, float[][]> playerRotationMap = new WeakHashMap();

    @Property("pESP-filter")
    private final ListProperty<String> filter = PropertyFactory.createList("Health").acceptableValues("Health", "Armor", "Box", "Name", "Skeleton", "Held Item");
    @Property("pESP-hurtTime")
    private final BooleanProperty hurtTimeCheck = PropertyFactory.booleanFalse();
    @Property("pESP-boxColor")
    private final ColorProperty color = createColor(0xFF8A8AFF);
    @Property("pESP-nameColor")
    private final ColorProperty nameColor = createColor(new Color(245, 255, 94).getRGB());
    @Property("pESP-targetcolor")
    private final ColorProperty targetColor = createColor(TARGET.getRGB());
    @Property("pESP-friendColor")
    private final ColorProperty friendColor = createColor(FRIEND.getRGB());
    @Property("pESP-box_mode")
    private final StringProperty boxMode = PropertyFactory.createString("Bordered").acceptableValues("Basic", "Bordered");
    @Property("pESP-box_color_mode")
    private final StringProperty boxColorMode = PropertyFactory.createString("Static").acceptableValues("Static", "Rainbow", "Astolfo", "Team");
    @Property("pESP-box_style")
    private final StringProperty boxStyle = PropertyFactory.createString("Full").acceptableValues("Full", "Corner");
    @Property("pESP-health-mode")
    private final StringProperty healthMode = PropertyFactory.createString("Hearts").acceptableValues("Hearts", "HP", "Percentage");
    @Property("pESP-name-color-type")
    private final StringProperty nameColorType = PropertyFactory.createString("Team").acceptableValues("Team", "Custom");
    @Property("pESP-onlyTargets")
    private final BooleanProperty onlyTargets = PropertyFactory.booleanFalse();
    @Property("bg-transparency")
    private final IntProperty transparency = PropertyFactory.createInt(100).minimum(0).maximum(255);

    /* constructors @on */
    public PlayerESP(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "PlayerESP", "Player ESP", Keyboard.KEY_NONE, EnumModuleType.VISUALS, "fucking cs:go shit");
        put(new Setting("PESP_FILTER", "Filter", SettingType.SELECTBOX, this, this.filter));
        put(new Setting("BOX_MODE", "Health", SettingType.COMBOBOX, this, this.healthMode, () -> filter.get().contains("Health")));
        put(new Setting("BOX_MODE", "Box mode", SettingType.COMBOBOX, this, this.boxMode, () -> filter.get().contains("Box")));
        put(new Setting("BOX_MODE", "Box Style", SettingType.COMBOBOX, this, this.boxStyle, () -> filter.get().contains("Box")));
        put(new Setting("BOX_COLOR_MODE", "Box Color", SettingType.COMBOBOX, this, this.boxColorMode, () -> filter.get().contains("Box")));
        put(new Setting("BOX_COLOR", "Color", COLOR_PICKER, this, this.color, null, () -> filter.get().contains("Box")));
        put(new Setting("PESP-ONLYTARGETS", "Targets Only", CHECKBOX, this, onlyTargets));
        put(new Setting("PESP-HT", "HurtTime Check", SettingType.CHECKBOX, this, this.hurtTimeCheck, () -> filter.get().contains("Box")));
        put(new Setting("PEST-TRANSPARENCY", "Transparency", SettingType.SLIDER, this, transparency, 5, () -> filter.get().contains("Name")));
        put(new Setting("NAME_COLOR_MODE", "Name Color", SettingType.COMBOBOX, this, this.nameColorType, () -> filter.get().contains("Name")));
        put(new Setting("NAME_COLOR", "Color", COLOR_PICKER, this, this.nameColor, null, () -> filter.get().contains("Name") && nameColorType.get().equals("Custom")));
        put(new Setting("NAME_COLOR_TARGET", "Target Color", COLOR_PICKER, this, this.targetColor, null, () -> filter.get().contains("Name") && nameColorType.get().equals("Custom")));
        put(new Setting("NAME_COLOR_FRIEND", "Friend Color", COLOR_PICKER, this, this.friendColor, null, () -> filter.get().contains("Name") && nameColorType.get().equals("Custom")));
    }


    @EventTarget
    public void onRenderTag(RenderNameTagEvent event) {
        event.setCancelled(filter.contains("Name") && (!onlyTargets.get() || novoline.getPlayerManager().hasType(event.getEntity().getName().getString(),
                PlayerManager.EnumPlayerType.TARGET)) || getModule(Nametags.class).isEnabled());
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        DrawContext context = event.getContext();
        context.getMatrices().pushMatrix();
        this.collectedEntities.clear();
        collectEntities();

        // PORT: project2D returns true scaled-screen coordinates in the DrawContext's
        // own space — the 1.8.9 scaleFactor normalisation is identity here, so no
        // outer transform is applied.
        ScaledResolution eventResolution = new ScaledResolution(mc); // PORT: Render2DEvent carries no resolution in the Fabric port

        for (PlayerEntity entity : this.collectedEntities) {
            if (onlyTargets.get() && !novoline.getPlayerManager().hasType(entity.getName().getString(), PlayerManager.EnumPlayerType.TARGET))
                continue;
            if (entity == mc.player && mc.options.getPerspective().isFirstPerson())
                continue;
            if (isValid(entity) && RenderUtils.isInViewFrustrum(entity)) {
                final double x = RenderUtils.interpolate(entity.getX(), entity.lastX, event.getPartialTicks()), // @off
                        y = RenderUtils.interpolate(entity.getY(), entity.lastY, event.getPartialTicks()),
                        z = RenderUtils.interpolate(entity.getZ(), entity.lastZ, event.getPartialTicks()),
                        width = entity.getWidth() / 1.4,
                        height = entity.getHeight() + 0.2; // @on

                Box aabb = new Box(x - width, y, z - width, x + width, y + height, z + width);
                List<Vec3d> vectors = Arrays.asList(new Vec3d(aabb.minX, aabb.minY, aabb.minZ),
                        new Vec3d(aabb.minX, aabb.maxY, aabb.minZ), new Vec3d(aabb.maxX, aabb.minY, aabb.minZ),
                        new Vec3d(aabb.maxX, aabb.maxY, aabb.minZ), new Vec3d(aabb.minX, aabb.minY, aabb.maxZ),
                        new Vec3d(aabb.minX, aabb.maxY, aabb.maxZ), new Vec3d(aabb.maxX, aabb.minY, aabb.maxZ),
                        new Vec3d(aabb.maxX, aabb.maxY, aabb.maxZ));

                // PORT: setupCameraTransform replaced by the camera-relative projection in project2D
                Vector4f position = null;
                Vec3d viewerPos = this.mc.gameRenderer.getCamera().getCameraPos();
                for (Vec3d vector : vectors) {
                    Vector3f projected = project2D(vector.x - viewerPos.x,
                            vector.y - viewerPos.y,
                            vector.z - viewerPos.z);

                    if (projected != null && projected.z >= 0.0 && projected.z < 1.0) {
                        if (position == null) {
                            position = new Vector4f(projected.x, projected.y, projected.z, 0.0F);
                        }

                        position.x = Math.min(projected.x, position.x);
                        position.y = Math.min(projected.y, position.y);
                        position.z = Math.max(projected.x, position.z);
                        position.w = Math.max(projected.y, position.w);
                    }
                }

                // PORT: setupOverlayRendering not needed - HUD overlay rendering is implicit

                if (position != null) {
                    double posX = position.x, // @off
                            posY = position.y,
                            endPosX = position.z,
                            endPosY = position.w,
                            length = Math.abs(endPosY - posY),
                            difference = posY - endPosY + 0.5; // @on


                    float amp = 1;
                    switch (mc.options.getGuiScale().getValue()) {
                        case 0:
                            amp = 0.5F;
                            break;
                        case 1:
                            amp = 2.0F;
                            break;
                        case 3:
                            amp = 0.6666666666666667F;
                    }

                    // Projected coords are already in scaled screen space — no
                    // getScaledMouseCoordinates round-trip needed.
                    double[] scaledPositions = new double[]{posX, posY, endPosX, endPosY};
                    // Text/item blocks draw under a `scale(k*amp)` matrix: multiplying
                    // draw coords by 1/(k*amp) keeps the shrunk text at the right anchor.
                    double inv05 = 1.0 / (0.5 * amp), inv048 = 1.0 / (0.48 * amp);

                    final ScaledResolution resolution = new ScaledResolution(mc);

                    float width1 = resolution.getScaledWidth() / 2F;
                    float height1 = resolution.getScaledHeight() / 2F;
                    double centreX = posX + (endPosX - posX) / 2;
                    double centreY = posY + (endPosY - posY) / 2;


                    if (centreX <= width1 + (endPosX - posX) / 2 && centreX >= width1 - (endPosX - posX) / 2 &&
                            centreY <= height1 + (endPosY - posY) / 2 && centreY >= height1 - (endPosY - posY) / 2 && mc.options.getPerspective().isFirstPerson()) {
                        context.getMatrices().pushMatrix();
                        context.getMatrices().scale(0.5f * amp, 0.5f * amp);

                        double[] sp = {scaledPositions[0] * inv05, scaledPositions[1] * inv05, scaledPositions[2] * inv05, scaledPositions[3] * inv05};
                        double _width = Math.abs(sp[2] - sp[0]);
                        float v = (float) (mc.textRenderer.fontHeight * 2) - mc.textRenderer.fontHeight / 2;

                        // PORT: fontRendererCrack -> textRenderer
                        context.drawText(mc.textRenderer, "Target", (int) (sp[0] + _width / 2 -
                                mc.textRenderer.getWidth("Target") / 2), (int) (sp[3] + mc.textRenderer.fontHeight / 2), 0xffffffff, true);

                        if (Mouse.isButtonDown(2)) {
                            if (tpTimer.delay(150)) {
                                mc.player.networkHandler.sendChatMessage(".tar " + entity.getName().getString().toLowerCase());
                                tpTimer.reset();
                            }
                        }

                        context.getMatrices().popMatrix();

                    }

                    if (filter.contains("Held Item")) {
                        context.getMatrices().pushMatrix();
                        context.getMatrices().scale(0.5f * amp, 0.5f * amp);
                        float v = (float) (mc.textRenderer.fontHeight * 2) - mc.textRenderer.fontHeight / 2;
                        double[] sp = {scaledPositions[0] * inv05, scaledPositions[1] * inv05, scaledPositions[2] * inv05, scaledPositions[3] * inv05};
                        double _width = Math.abs(sp[2] - sp[0]);

                        if (!entity.getMainHandStack().isEmpty()) {
                            String heldName = entity.getMainHandStack().getName().getString();
                            RenderUtils.guiQuad(
                                    (float) (sp[0] + _width / 2 -
                                            mc.textRenderer.getWidth(heldName) / 2) - 2,
                                    (float) sp[3] + v / 3f - 2,
                                    (float) (sp[0] + _width / 2 -
                                            mc.textRenderer.getWidth(heldName) / 2) + mc.textRenderer.getWidth(heldName) + 1,
                                    (float) (sp[3] + v / 3f + mc.textRenderer.fontHeight + 1),
                                    new Color(0, 0, 0, 255 - transparency.get()).getRGB());
                            context.drawText(mc.textRenderer, heldName, (int) (sp[0] + _width / 2 -
                                    mc.textRenderer.getWidth(heldName) / 2), (int) (sp[3] + v / 3f), 0xffffffff, true);
                            double newY = sp[3] + v / 3f + v;
                            // PORT: tagCompound lore -> DataComponentTypes.LORE
                            LoreComponent heldLore = entity.getMainHandStack().get(DataComponentTypes.LORE);
                            if (heldLore != null) {
                                for (Text line : heldLore.lines()) {
                                    String s = line.getString();
                                    if (!s.contains("+") && !s.contains("Unbreakable")) {
                                        RenderUtils.guiQuad(
                                                (float) (sp[0] + _width / 2 -
                                                        mc.textRenderer.getWidth(s) / 2) - 2,
                                                (float) newY - 2,
                                                (float) (sp[0] + _width / 2 -
                                                        mc.textRenderer.getWidth(s) / 2) + mc.textRenderer.getWidth(s) + 1,
                                                (float) (newY + mc.textRenderer.fontHeight + 1),
                                                new Color(0, 0, 0, 255 - transparency.get()).getRGB());
                                        context.drawText(mc.textRenderer, Text.literal(s).formatted(Formatting.AQUA), (int) (sp[0] + _width / 2 -
                                                mc.textRenderer.getWidth(s) / 2), (int) newY, 0xffffffff, true);
                                        newY += v;
                                    }
                                }
                            }
                            ItemStack leggings = entity.getEquippedStack(EquipmentSlot.LEGS);
                            if (!leggings.isEmpty()) {
                                LoreComponent legLore = leggings.get(DataComponentTypes.LORE);
                                if (legLore != null) {
                                    for (Text line : legLore.lines()) {
                                        String s = line.getString();
                                        if (s.length() != 1 && !s.contains("Pants") && !s.contains("Also, a fashion") && !s.contains("Used in the") && !s.contains("As strong")) {
                                            RenderUtils.guiQuad(
                                                    (float) (sp[0] + _width / 2 -
                                                            mc.textRenderer.getWidth(s) / 2) - 2,
                                                    (float) newY - 2,
                                                    (float) (sp[0] + _width / 2 -
                                                            mc.textRenderer.getWidth(s) / 2) + mc.textRenderer.getWidth(s) + 1,
                                                    (float) (newY + mc.textRenderer.fontHeight + 1),
                                                    new Color(0, 0, 0, 255 - transparency.get()).getRGB());
                                            context.drawText(mc.textRenderer, Text.literal(s).formatted(Formatting.GOLD), (int) (sp[0] + _width / 2 -
                                                    mc.textRenderer.getWidth(s) / 2), (int) newY, 0xffffffff, true);
                                            newY += v;
                                        }
                                    }
                                }
                            }
                        }

                        context.getMatrices().popMatrix();
                    }


                    if (filter.contains("Name")) {
                        context.getMatrices().pushMatrix();
                        context.getMatrices().scale(0.5f * amp, 0.5f * amp);
                        double[] sp = {scaledPositions[0] * inv05, scaledPositions[1] * inv05, scaledPositions[2] * inv05, scaledPositions[3] * inv05};
                        double _width = Math.abs(sp[2] - sp[0]);

                        int color;

                        if (nameColorType.get().equals("Team")) {
                            Integer detected = PlayerUtils.getTeamColor(entity);
                            color = detected != null ? detected : new Color(255, 99, 99).getRGB();
                            if (onlyTargets.get()) {
                                color = WHITE.getRGB();
                            } else {
                                if (novoline.playerManager.hasType(entity.getName().getString().toLowerCase(), PlayerManager.EnumPlayerType.FRIEND)) {
                                    color = FRIEND.getRGB();
                                } else if (novoline.playerManager.hasType(entity.getName().getString().toLowerCase(), PlayerManager.EnumPlayerType.TARGET)) {
                                    color = TARGET.getRGB();
                                } else if (detected == null && PlayerUtils.inTeam(mc.player, entity) && getModule(KillAura.class).getFilters().get().contains("Teams")) {
                                    color = TEAM.getRGB();
                                }
                            }
                        } else {
                            color = nameColor.getAwtColor().getRGB();
                            if (novoline.playerManager.hasType(entity.getName().getString().toLowerCase(), PlayerManager.EnumPlayerType.FRIEND)) {
                                color = friendColor.getAwtColor().getRGB();
                            } else if (novoline.playerManager.hasType(entity.getName().getString().toLowerCase(), PlayerManager.EnumPlayerType.TARGET)) {
                                color = targetColor.getAwtColor().getRGB();
                            }
                        }

                        String name = entity.getName().getString();
//                        UserEntity user = novoline.getIRCUser(name);
//
//                        if (!name.isEmpty() && user != null) {
//                            name += " §7(§b" + user.getUsername() + "§7)§r";
//                        }
//                        if (entity.getCustomNameTag().startsWith("Desynced - ")) {
//                            name = Formatting.YELLOW + "Your position for " + name;
//                        }

                        float v = (float) (mc.textRenderer.fontHeight * 2) - mc.textRenderer.fontHeight / 2;
                        RenderUtils.guiQuad(
                                (float) (sp[0] + _width / 2 -
                                        mc.textRenderer.getWidth(name) / 2) - 2,
                                (float) sp[1] - v - 2,
                                (float) (sp[0] + _width / 2 -
                                        mc.textRenderer.getWidth(name) / 2) + mc.textRenderer.getWidth(name) + 1,
                                (float) (sp[1] - v + mc.textRenderer.fontHeight + 1),
                                new Color(0, 0, 0, 255 - transparency.get()).getRGB());
                        context.drawText(mc.textRenderer, name, (int) (sp[0] + _width / 2 -
                                mc.textRenderer.getWidth(name) / 2), (int) (sp[1] - v), color, true);
                        context.getMatrices().popMatrix();
                    }


                    if (this.filter.contains("Health")) {
                        RenderUtils.start2D();
                        context.getMatrices().pushMatrix();
                        double maxHealth = entity.getMaxHealth(), amplifier = 100 / maxHealth, space = length / 100;
                        float health = entity.getHealth();

                        if (health > maxHealth) {
                            health *= maxHealth / health;
                        }

                        int percent = (int) (health * amplifier);
                        // PORT: GL line strip -> two thin quads: dark outline + colored health bar
                        int healthColor = RenderUtils.getHealthColor(entity);
                        RenderUtils.drawBorderedRect(posX - 2.3, endPosY - percent * space - 0.3, posX - 1.3, endPosY + 0.3, 0.3F, new Color(40, 40, 40).getRGB(), 0);
                        RenderUtils.guiQuad((float) (posX - 2), (float) (endPosY - percent * space), (float) (posX - 1.3), (float) endPosY, healthColor);
                        context.getMatrices().popMatrix();
                        RenderUtils.stop2D();
                        context.getMatrices().pushMatrix();

                        double[] newPos = {posX * inv048, (endPosY - percent * space) * inv048};

                        String hp = "";
                        Text hpText = null;

                        switch (healthMode.get()) {
                            case "Hearts":
                                // PORT: keep the red heart as a styled Text so the colour survives in the modern font renderer
                                hp = String.format("%.1f", entity.getHealth() / 2);
                                hpText = Text.literal(hp).append(Text.literal("❤").formatted(Formatting.RED));
                                break;
                            case "HP":
                                hp = (int) entity.getHealth() + " HP";
                                hpText = Text.literal(hp);
                                break;
                            case "Percentage":
                                hp = percent + "%";
                                hpText = Text.literal(hp);
                        }


                        context.getMatrices().scale(0.48f * amp, 0.48f * amp);
                        if (entity.getHealth() != entity.getMaxHealth())
                            context.drawText(mc.textRenderer, hpText,
                                    (int) (newPos[0] - mc.textRenderer.getWidth(Text.literal("a").append(hpText.copy()))),
                                    (int) newPos[1],
                                    0xffffffff, true);
                        context.getMatrices().popMatrix();
                    }

                    if (this.filter.contains("Box")) {
                        boolean bordered = this.boxMode.get().equalsIgnoreCase("Bordered");
                        if (boxColorMode.get().equals("Rainbow")
                                || boxColorMode.get().equals("Astolfo")) {
                            drawRainbowBox(posX, posY, endPosX, endPosY, 2,
                                    boxStyle.get().equals("Corner"),
                                    boxColorMode.get().equals("Astolfo"), bordered);
                        } else {
                            Integer teamColor = boxColorMode.get().equals("Team") ? PlayerUtils.getTeamColor(entity) : null;
                            Color baseColor = teamColor != null ? new Color(teamColor) : this.color.getAwtColor();
                            if (boxStyle.get().equals("Full")) {
                                RenderUtils.drawBorderedBox(posX, posY, endPosX, endPosY, baseColor, bordered);
                            } else {
                                if (bordered) {
                                    RenderUtils.drawCornerBox(posX, posY, endPosX, endPosY, 3, BLACK);
                                }

                                RenderUtils.drawCornerBox(posX, posY, endPosX, endPosY, 1, this.hurtTimeCheck.get() &&
                                        entity.timeUntilRegen >= 10 ? Color.RED : baseColor); // PORT: hurtResistantTime -> timeUntilRegen
                            }
                        }

                    }


                    if (this.filter.contains("Armor")) {
                        int i = 0;
                        float posy = 0;

                        List<ItemStack> stuff = new ArrayList<>();

                        // PORT: inventory.armorInventory -> equipment slots (0 = boots .. 3 = helmet)
                        for (ItemStack stack : new ItemStack[]{
                                entity.getEquippedStack(EquipmentSlot.FEET),
                                entity.getEquippedStack(EquipmentSlot.LEGS),
                                entity.getEquippedStack(EquipmentSlot.CHEST),
                                entity.getEquippedStack(EquipmentSlot.HEAD)}) {
                            if (stack != null && !stack.isEmpty()) {
                                stuff.add(stack);
                            }
                        }

                        Collections.reverse(stuff);
                        // PORT: GL lighting/state handled by the pipeline
                        context.getMatrices().scale(0.5f * amp, 0.5f * amp);
                        for (ItemStack item : stuff) {
                            context.drawItem(item, (int) ((scaledPositions[2] + 2) * inv05), (int) ((scaledPositions[1] + posy - mc.player.distanceTo(entity) * 0.053f) * inv05));
                            posy += Math.abs(scaledPositions[3] - scaledPositions[1]) / 4;
                        }
                        context.getMatrices().scale(1 / (0.5f * amp), 1 / (0.5f * amp));

                    }
                }
            }
        }

        context.getMatrices().popMatrix();
    }

    @EventTarget
    public void onUpdateModel(UpdateModelEvent event) {
        if (!(event.getEntity() instanceof PlayerEntity player)) {
            return; // fired for every living entity — skeleton tracking is players-only
        }
        BipedEntityModel<?> model = event.getModelPlayer();
        // PORT: bipedXxx -> head/rightArm/... ; rotateAngleX/Y/Z -> pitch/yaw/roll
        this.playerRotationMap.put(player, new float[][]{{model.head.pitch, model.head.yaw, model.head.roll}, {model.rightArm.pitch, model.rightArm.yaw, model.rightArm.roll}, {model.leftArm.pitch, model.leftArm.yaw, model.leftArm.roll}, {model.rightLeg.pitch, model.rightLeg.yaw, model.rightLeg.roll}, {model.leftLeg.pitch, model.leftLeg.yaw, model.leftLeg.roll}});
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (!filter.get().contains("Skeleton")) {
            return;
        }

        this.setupRender(true);
        this.playerRotationMap.keySet().removeIf(this::contain);
        Map<PlayerEntity, float[][]> playerRotationMap = this.playerRotationMap;
        List<AbstractClientPlayerEntity> worldPlayers = mc.world.getPlayers();
        Object[] players = playerRotationMap.keySet().toArray();
        int playersLength = players.length;


        for (Object o : players) {
            PlayerEntity player = (PlayerEntity) o;
            float[][] entPos = playerRotationMap.get(player);
            if (entPos == null || player.getId() == -1488 || !player.isAlive() || !RenderUtils.isInViewFrustrum(player) || player.isRemoved() || player == mc.player || player.isSleeping() || player.isInvisible())
                continue;
            float[][] modelRotations = playerRotationMap.get(player);
            Vec3d camPos = RenderUtils.cameraPos();
            double x = interpolate(player.getX(), player.lastX, event.getPartialTicks()) - camPos.x;
            double y = interpolate(player.getY(), player.lastY, event.getPartialTicks()) - camPos.y;
            double z = interpolate(player.getZ(), player.lastZ, event.getPartialTicks()) - camPos.z;

            // PORT: GL matrix stack -> JOML transform chain; lines emitted via the world vertex queue
            float bodyYawOffset = player.lastBodyYaw + (player.bodyYaw - player.lastBodyYaw) * mc.getRenderTickCounter().getTickProgress(true);
            Matrix4f base = new Matrix4f()
                    .translate((float) x, (float) y, (float) z)
                    .rotateY((float) Math.toRadians(-bodyYawOffset))
                    .translate(0.0F, 0.0F, player.isSneaking() ? -0.235F : 0.0F);
            float legHeight = player.isSneaking() ? 0.6f : 0.75f;

            List<float[]> lines = new ArrayList<>();

            Matrix4f leg = new Matrix4f(base).translate(-0.125F, legHeight, 0.0F)
                    .rotateX(modelRotations[3][0]).rotateY(modelRotations[3][1]).rotateZ(modelRotations[3][2]);
            lines.addAll(line(leg, 0, 0, 0, 0, -legHeight, 0));

            leg = new Matrix4f(base).translate(0.125F, legHeight, 0.0F)
                    .rotateX(modelRotations[4][0]).rotateY(modelRotations[4][1]).rotateZ(modelRotations[4][2]);
            lines.addAll(line(leg, 0, 0, 0, 0, -legHeight, 0));

            Matrix4f torso = new Matrix4f(base)
                    .translate(0.0F, 0.0F, player.isSneaking() ? 0.25F : 0.0F);
            Matrix4f arms = new Matrix4f(torso)
                    .translate(0.0F, player.isSneaking() ? -0.05F : 0.0F, player.isSneaking() ? -0.01725F : 0.0F);

            Matrix4f arm = new Matrix4f(arms).translate(-0.375F, legHeight + 0.55F, 0.0F)
                    .rotateX(modelRotations[1][0]).rotateY(modelRotations[1][1]).rotateZ(-modelRotations[1][2]);
            lines.addAll(line(arm, 0, 0, 0, 0, -0.5F, 0));

            arm = new Matrix4f(arms).translate(0.375F, legHeight + 0.55F, 0.0F)
                    .rotateX(modelRotations[2][0]).rotateY(modelRotations[2][1]).rotateZ(-modelRotations[2][2]);
            lines.addAll(line(arm, 0, 0, 0, 0, -0.5F, 0));

            Matrix4f head = new Matrix4f(arms)
                    .rotateY((float) Math.toRadians(bodyYawOffset - player.headYaw))
                    .translate(0.0F, legHeight + 0.55F, 0.0F)
                    .rotateX(modelRotations[0][0]);
            lines.addAll(line(head, 0, 0, 0, 0, 0.3F, 0));

            Matrix4f pelvis = new Matrix4f(torso)
                    .rotateX((float) Math.toRadians(player.isSneaking() ? 25.0F : 0.0F))
                    .translate(0.0F, player.isSneaking() ? -0.16175F : 0.0F, player.isSneaking() ? -0.48025F : 0.0F);

            lines.addAll(line(new Matrix4f(pelvis).translate(0.0F, legHeight, 0.0F), -0.125F, 0, 0, 0.125F, 0, 0));
            lines.addAll(line(new Matrix4f(pelvis).translate(0.0F, legHeight, 0.0F), 0, 0, 0, 0, 0.55F, 0));
            lines.addAll(line(new Matrix4f(pelvis).translate(0.0F, legHeight + 0.55F, 0.0F), -0.375F, 0, 0, 0.375F, 0, 0));

            // no-depth lines — vanilla RenderLayers.lines() depth-tests, hiding
            // skeleton edges inside the player model.
            RenderUtils.submitWorld(NovolineRenderLayers.noDepthLines(), (entry, vc) -> {
                Matrix4f m = entry.getPositionMatrix();
                for (float[] line : lines) {
                    Vector4f a = m.transform(new Vector4f(line[0], line[1], line[2], 1.0F));
                    Vector4f b = m.transform(new Vector4f(line[3], line[4], line[5], 1.0F));
                    // line format needs NORMAL+LINE_WIDTH (see RenderUtils.lineVertex)
                    float dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
                    float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (len < 1.0E-4F) { dx = 0; dy = 1; dz = 0; len = 1; }
                    float nx = dx / len, ny = dy / len, nz = dz / len;
                    vc.vertex(a.x, a.y, a.z).color(0xffffffff).normal(nx, ny, nz).lineWidth(1.0F);
                    vc.vertex(b.x, b.y, b.z).color(0xffffffff).normal(nx, ny, nz).lineWidth(1.0F);
                }
            });
        }

        this.setupRender(false);
    }

    /** Transform a local-space line by {@code m} into a camera-relative [ax,ay,az,bx,by,bz] pair. */
    private static List<float[]> line(Matrix4f m, float ax, float ay, float az, float bx, float by, float bz) {
        Vector4f a = m.transform(new Vector4f(ax, ay, az, 1.0F));
        Vector4f b = m.transform(new Vector4f(bx, by, bz, 1.0F));
        return Collections.singletonList(new float[]{a.x, a.y, a.z, b.x, b.y, b.z});
    }

    private void setupRender(boolean start) {
        // PORT: GL state handled by the world render pipeline; depth mask toggling kept as a no-op
    }

    public ListProperty<String> getFilter() {
        return filter;
    }

    private void collectEntities() {
        for (AbstractClientPlayerEntity entity : this.mc.world.getPlayers()) {
            if (isValid(entity)) this.collectedEntities.add((PlayerEntity) entity);
        }
    }

    private boolean contain(PlayerEntity var0) {
        return !mc.world.getPlayers().contains(var0);
    }

    public static double interpolate(double current, double old, double scale) {
        return old + (current - old) * scale;
    }

    private Vector3f project2D(double x, double y, double z) {
        // PORT: GLU.gluProject replaced by a JOML projection; (x,y,z) arrive camera-relative
        MinecraftClient mc = MinecraftClient.getInstance();
        Camera camera = mc.gameRenderer.getCamera();

        Matrix4f view = new Matrix4f()
                .rotationX(camera.getPitch() * MathHelper.RADIANS_PER_DEGREE)
                .rotateY((camera.getYaw() + 180.0F) * MathHelper.RADIANS_PER_DEGREE);
        Matrix4f projection = new Matrix4f(mc.gameRenderer.getBasicProjectionMatrix(((cc.novoline.mixin.GameRendererAccessor) mc.gameRenderer).novoline$getFov(camera, mc.getRenderTickCounter().getTickProgress(true), true)));

        int[] viewport = {0, 0, mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight()};
        Vector4f screenCoords = new Vector4f();
        // PORT: gluProject essentially always returned true; JOML project() fills the dest vector.
        projection.mul(view).project((float) x, (float) y, (float) z, viewport, screenCoords);
        int scaleFactor = new ScaledResolution(mc).getScaleFactor();
        return new Vector3f(screenCoords.x / scaleFactor,
                (mc.getWindow().getFramebufferHeight() - screenCoords.y) / scaleFactor, screenCoords.z);
    }

    private boolean isValid(PlayerEntity entityLivingBase) {
        return !entityLivingBase.isRemoved() && !entityLivingBase.isInvisible(); // PORT: isDead -> isRemoved
    }

    public ColorProperty getColor() {
        return color;
    }

    /* PORT: ScaleUtils.scale/getScaledMouseCoordinates inlined (guiScale amp) */
    private static double[] getScaledMouseCoordinates(MinecraftClient mc, double mouseX, double mouseY) {
        double x = mouseX;
        double y = mouseY;
        switch (mc.options.getGuiScale().getValue()) {
            case 0:
                x *= 2;
                y *= 2;
                break;
            case 1:
                x *= 0.5;
                y *= 0.5;
                break;
            case 3:
                x *= 1.4999999999999999998;
                y *= 1.4999999999999999998;
        }
        return new double[]{x, y};
    }

    /* PORT: RenderUtils.drawRainbowBox inlined - axis-aligned strips drawn as thin quads */
    private void drawRainbowBox(double x, double y, double x2, double y2, float lw, boolean cornered, boolean astolfo, boolean bordered) {
        RenderUtils.start2D();
        if (cornered) {
            double width = Math.abs(x2 - x);
            double height = Math.abs(y2 - y);
            double halfWidth = width / 4;
            double halfHeight = height / 4;
            int counter = 0;
            if (width != 0 && height != 0) {
                if (bordered) {
                    drawStrip(2.5f, BLACK.getRGB(),
                            new double[]{x + halfWidth, y, x, y, x, y + halfHeight});
                    drawStrip(2.5f, BLACK.getRGB(),
                            new double[]{x, y + height - halfHeight, x, y + height, x + halfWidth, y + height});
                    drawStrip(2.5f, BLACK.getRGB(),
                            new double[]{x + width - halfWidth, y + height, x + width, y + height, x + width, y + height - halfHeight});
                    drawStrip(2.5f, BLACK.getRGB(),
                            new double[]{x + width, y + halfHeight, x + width, y, x + width - halfWidth, y});
                }

                List<Double> points = new ArrayList<>();
                List<Integer> colors = new ArrayList<>();
                for (double i = 0; i <= halfWidth; i += halfWidth / 8) {
                    points.add(x + halfWidth - i);
                    points.add(y);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                for (double i = 0; i <= halfHeight; i += halfHeight / 8) {
                    points.add(x);
                    points.add(y + i);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                drawStrip(1.5f, points, colors);

                points.clear();
                colors.clear();
                for (double i = 0; i <= halfHeight; i += halfHeight / 8) {
                    points.add(x);
                    points.add(y + height - halfHeight + i);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                for (double i = 0; i <= halfWidth; i += halfWidth / 8) {
                    points.add(x + i);
                    points.add(y + height);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                drawStrip(1.5f, points, colors);

                points.clear();
                colors.clear();
                for (double i = 0; i <= halfWidth; i += halfWidth / 8) {
                    points.add(x + width - halfWidth + i);
                    points.add(y + height);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                for (double i = 0; i <= halfHeight; i += halfHeight / 8) {
                    points.add(x + width);
                    points.add(y + height - i);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                drawStrip(1.5f, points, colors);

                points.clear();
                colors.clear();
                for (double i = 0; i <= halfHeight; i += halfHeight / 8) {
                    points.add(x + width);
                    points.add(y + halfHeight - i);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                for (double i = 0; i <= halfWidth; i += halfWidth / 8) {
                    points.add(x + width - i);
                    points.add(y);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                drawStrip(1.5f, points, colors);
            }
        } else {
            double x3 = Math.abs(x2 - x);
            double y3 = Math.abs(y2 - y);

            if (bordered) {
                drawStrip(2.5f, new Color(0xff000000).getRGB(),
                        new double[]{x, y, x + (x2 - x), y, x + (x2 - x), y + (y2 - y), x, y + (y2 - y), x, y});
            }
            int counter = 0;
            if (y3 != 0 && x3 != 0) {
                List<Double> points = new ArrayList<>();
                List<Integer> colors = new ArrayList<>();
                for (double i = 0; i <= y3; i += y3 / 10) {
                    points.add(x);
                    points.add(y + i);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                for (double i = 0; i <= x3; i += x3 / 10) {
                    points.add(x + i);
                    points.add(y + y3);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                for (double i = 0; i <= y3; i += y3 / 10) {
                    points.add(x + x3);
                    points.add(y + y3 - i);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                for (double i = 0; i <= x3; i += x3 / 10) {
                    points.add(x + x3 - i);
                    points.add(y);
                    colors.add(astolfo ? RenderUtils.getArrayAstolfo(counter, 255) : RenderUtils.getArrayRainbow(counter, 255));
                    counter++;
                }
                drawStrip(1.5f, points, colors);
            }
        }
        RenderUtils.stop2D();
    }

    /** Draw a solid-colour strip through an alternating [x,y,...] polyline as thin quads of width {@code lw}. */
    private static void drawStrip(float lw, int color, double[] points) {
        for (int i = 0; i + 3 < points.length; i += 2) {
            drawSegment(points[i], points[i + 1], points[i + 2], points[i + 3], lw, color, color);
        }
    }

    private static void drawStrip(float lw, List<Double> points, List<Integer> colors) {
        for (int i = 0; i + 1 < points.size() / 2; i++) {
            double x1 = points.get(i * 2), y1 = points.get(i * 2 + 1);
            double x2 = points.get(i * 2 + 2), y2 = points.get(i * 2 + 3);
            drawSegment(x1, y1, x2, y2, lw, colors.get(i), colors.get(i + 1));
        }
    }

    /** Emit one axis-aligned segment of a strip as a lw-wide quad.
     * The GUI render pipeline culls backfaces, so endpoints are normalized to
     * emit left→right / top→bottom — reversed segments were invisible. */
    private static void drawSegment(double x1, double y1, double x2, double y2, float lw, int c1, int c2) {
        float half = lw / 2;
        float[] verts;
        int[] colors;
        if (Math.abs(x2 - x1) >= Math.abs(y2 - y1)) { // horizontal
            if (x1 > x2) { double tx = x1; x1 = x2; x2 = tx; double ty = y1; y1 = y2; y2 = ty; int tc = c1; c1 = c2; c2 = tc; }
            /* GUI pipeline culls backfaces — emit TL->BL->BR->TR (CCW in NDC),
               matching drawRect's winding. The old TL->TR->BR->BL order was
               clockwise and got culled entirely. */
            verts = new float[]{(float) x1, (float) (y1 - half), (float) x1, (float) (y1 + half), (float) x2, (float) (y2 + half), (float) x2, (float) (y2 - half)};
            colors = new int[]{c1, c1, c2, c2};
        } else { // vertical
            if (y1 > y2) { double ty = y1; y1 = y2; y2 = ty; double tx = x1; x1 = x2; x2 = tx; int tc = c1; c1 = c2; c2 = tc; }
            verts = new float[]{(float) (x1 - half), (float) y1, (float) (x2 - half), (float) y2, (float) (x2 + half), (float) y2, (float) (x1 + half), (float) y1};
            colors = new int[]{c1, c2, c2, c1};
        }
        int minX = (int) Math.floor(Math.min(x1, x2) - half);
        int minY = (int) Math.floor(Math.min(y1, y2) - half);
        int maxX = (int) Math.ceil(Math.max(x1, x2) + half);
        int maxY = (int) Math.ceil(Math.max(y1, y2) + half);
        RenderUtils.guiShape(verts, colors, minX, minY, maxX, maxY);
    }
}
