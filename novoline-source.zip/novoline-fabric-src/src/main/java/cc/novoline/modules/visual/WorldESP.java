package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.ColorProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.utils.NovolineRenderLayers;
import cc.novoline.utils.RenderUtils;
import net.minecraft.block.BedBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.CakeBlock;
import net.minecraft.block.CandleCakeBlock;
import net.minecraft.block.DragonEggBlock;
import net.minecraft.block.entity.BedBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.world.ClientChunkManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

import static cc.novoline.gui.screen.setting.Manager.put;
import static cc.novoline.modules.configurations.property.object.PropertyFactory.createColor;

/**
 * Block ESP for non-container blocks: beds (box takes the bed's dye color),
 * cakes and dragon eggs, drawn through walls like ChestESP's chams pass.
 * Beds/cakes/dragon eggs have no useful block entity coverage client-side,
 * so chunk block states are scanned on a 20-tick timer and cached.
 */
public final class WorldESP extends AbstractModule {

    @Property("beds")
    private final BooleanProperty beds = PropertyFactory.createBoolean(true);
    @Property("cakes")
    private final BooleanProperty cakes = PropertyFactory.createBoolean(true);
    @Property("eggs")
    private final BooleanProperty eggs = PropertyFactory.createBoolean(true);
    @Property("cake-color")
    private final ColorProperty cakeColor = createColor(0xFFFFFF9C);
    @Property("egg-color")
    private final ColorProperty eggColor = createColor(0xFF9C27B0);

    private final List<Entry> found = new ArrayList<>();
    private int scanTimer;

    public WorldESP(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "WorldESP", "World ESP", Keyboard.KEY_NONE, EnumModuleType.VISUALS);
        put(new Setting("WESP_BEDS", "Beds", SettingType.CHECKBOX, this, beds));
        put(new Setting("WESP_CAKES", "Cakes", SettingType.CHECKBOX, this, cakes));
        put(new Setting("WESP_EGGS", "Eggs", SettingType.CHECKBOX, this, eggs));
        put(new Setting("WESP_CAKE_COLOR", "Cake Color", SettingType.COLOR_PICKER, this, cakeColor, null, () -> cakes.get()));
        put(new Setting("WESP_EGG_COLOR", "Egg Color", SettingType.COLOR_PICKER, this, eggColor, null, () -> eggs.get()));
    }

    private record Entry(BlockPos pos, int argb) {
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        if (mc.world == null || mc.player == null) return;
        if (++scanTimer < 20) return;
        scanTimer = 0;

        found.clear();
        int pcx = mc.player.getBlockPos().getX() >> 4;
        int pcz = mc.player.getBlockPos().getZ() >> 4;

        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                WorldChunk chunk = (WorldChunk) ((ClientChunkManager) mc.world.getChunkManager())
                        .getChunk(pcx + dx, pcz + dz);
                if (chunk == null) continue;

                ChunkSection[] sections = chunk.getSectionArray();
                for (int s = 0; s < sections.length; s++) {
                    ChunkSection section = sections[s];
                    if (section == null || section.isEmpty()) continue;
                    int baseY = chunk.getBottomY() + (s << 4);

                    for (int lx = 0; lx < 16; lx++) {
                        for (int ly = 0; ly < 16; ly++) {
                            for (int lz = 0; lz < 16; lz++) {
                                BlockState state = section.getBlockState(lx, ly, lz);
                                if (state.isAir()) continue;

                                int x = (pcx + dx) * 16 + lx;
                                int y = baseY + ly;
                                int z = (pcz + dz) * 16 + lz;

                                if (beds.get() && state.getBlock() instanceof BedBlock) {
                                    int argb = 0xFFFF5555;
                                    BlockEntity be = chunk.getBlockEntity(new BlockPos(x, y, z));
                                    if (be instanceof BedBlockEntity bed) {
                                        argb = 0xFF000000 | (bed.getColor().getEntityColor() & 0xFFFFFF);
                                    }
                                    found.add(new Entry(new BlockPos(x, y, z), argb));
                                } else if (cakes.get() && (state.getBlock() instanceof CakeBlock || state.getBlock() instanceof CandleCakeBlock)) {
                                    found.add(new Entry(new BlockPos(x, y, z), cakeColor.getAwtColor().getRGB()));
                                } else if (eggs.get() && state.getBlock() instanceof DragonEggBlock) {
                                    found.add(new Entry(new BlockPos(x, y, z), eggColor.getAwtColor().getRGB()));
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        for (Entry e : found) {
            Box box = new Box(e.pos());
            int hiddenColor = (e.argb() & 0x00FFFFFF) | 0x3C000000;
            int visibleColor = (e.argb() & 0x00FFFFFF) | 0x8C000000;
            // through-wall pass + depth-tested pass, same color (ChestESP chams layout)
            RenderUtils.submitWorld(NovolineRenderLayers.noDepthQuads(), (entry, consumer) ->
                    RenderUtils.boxVertices(consumer, entry.getPositionMatrix(), box, hiddenColor));
            RenderUtils.submitWorld(RenderLayers.debugQuads(), (entry, consumer) ->
                    RenderUtils.boxVertices(consumer, entry.getPositionMatrix(), box, visibleColor));
        }
    }

    @Override
    public void onDisable() {
        found.clear();
    }
}
