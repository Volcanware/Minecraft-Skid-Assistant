package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.RenderEntityEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.*;
import cc.novoline.utils.minecraft.FakeEntityPlayer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.GolemEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.NotNull;

import static cc.novoline.modules.configurations.property.object.PropertyFactory.*;

public final class Chams extends AbstractModule {

    /* properties @off */
    @Property("chams-visible")
    private final ColorProperty visible = createColor(0xFF8A8AFF);
    @Property("chams-hidden")
    private final ColorProperty hidden = createColor(0xFF8A8AFF);
    @Property("chams-hand")
    private final ColorProperty handColor = createColor(0xFF8A8AFF);
    @Property("visible-alpha")
    private final FloatProperty visibleAlpha = createFloat(255.0F).minimum(50.0F).maximum(255.0F);
    @Property("pulse-speed")
    private final FloatProperty pulseSpeed = createFloat(10.0F).minimum(5.0F).maximum(20.0F);
    @Property("rainbow")
    private final BooleanProperty rainbow = booleanFalse();
    @Property("colored")
    private final BooleanProperty colored = booleanTrue();
    @Property("pulse")
    private final BooleanProperty pulse = booleanFalse();
    @Property("hand")
    private final BooleanProperty hand = booleanFalse();
    @Property("targets")
    private final ListProperty<String> targets = createList("Players").acceptableValues("Players", "Animals", "Mobs", "Passives");
    @Property("chams-onlyTargets")
    private final BooleanProperty onlyTargets = PropertyFactory.booleanFalse();
    @Property("chams-material")
    private final BooleanProperty material = PropertyFactory.booleanFalse();


    private boolean isF = false;
    private float pulseAlpha;

    public BooleanProperty isColored() {
        return colored;
    }

    public BooleanProperty isMaterial() {
        return material;
    }

    /**
     * ARGB tint for the through-wall model pass — hidden color (or rainbow when
     * enabled), with the configured/pulsing alpha.
     */
    public int getChamsColor() {
        java.awt.Color base = rainbow.get()
            ? java.awt.Color.getHSBColor((System.currentTimeMillis() % 4000L) / 4000.0F, 1.0F, 1.0F)
            : hidden.getAwtColor();
        float alpha = visibleAlpha.get() / 255.0F;
        if (pulse.get()) {
            alpha *= pulseAlpha / 255.0F;
        }
        return new java.awt.Color(base.getRed() / 255.0F, base.getGreen() / 255.0F,
            base.getBlue() / 255.0F, MathHelper.clamp(alpha, 0.0F, 1.0F)).getRGB();
    }

    /* constructors @on */
    public Chams(@NotNull ModuleManager moduleManager) {
        super(moduleManager, EnumModuleType.VISUALS, "Chams");
        Manager.put(new Setting("CTARGETS", "Targets", SettingType.SELECTBOX, this, targets));
        Manager.put(new Setting("ChamsColored", "Colored", SettingType.CHECKBOX, this, colored));
        Manager.put(new Setting("VISIBLE_CHAMS", "Visible", SettingType.COLOR_PICKER, this, visible, null, () -> !rainbow.get() && colored.get()));
        Manager.put(new Setting("HIDDEN_CHAMS", "Hidden", SettingType.COLOR_PICKER, this, hidden, null, () -> !rainbow.get() && colored.get()));
        Manager.put(new Setting("VAlpha", "Alpha", SettingType.SLIDER, this, visibleAlpha, 5, colored::get));
        Manager.put(new Setting("CHAMS_MT", "Material", SettingType.CHECKBOX, this, material, colored::get));
        Manager.put(new Setting("ChamsRainbow", "Rainbow", SettingType.CHECKBOX, this, rainbow, colored::get));
        Manager.put(new Setting("PULSE", "Pulse", SettingType.CHECKBOX, this, pulse, colored::get));
        Manager.put(new Setting("HAND", "Hand", SettingType.CHECKBOX, this, hand, colored::get));
        Manager.put(new Setting("HAND_CHAMS", "Hand color", SettingType.COLOR_PICKER, this, handColor, null, () -> !rainbow.get() && colored.get() && hand.get()));
        Manager.put(new Setting("PS", "Pulse speed", SettingType.SLIDER, this, pulseSpeed, 1, () -> pulse.get() && colored.get()));
        Manager.put(new Setting("ONLYTARGETS", "Targets Only", SettingType.CHECKBOX, this, onlyTargets));
    }

    /* methods */
    public boolean isValid(LivingEntity entity) {
        return !(entity instanceof FakeEntityPlayer) && isValidType(entity) && entity.isAlive() && !entity.isInvisible() && entity != mc.player && (!onlyTargets.get() || novoline.getPlayerManager().hasType(entity.getName().getString(), PlayerManager.EnumPlayerType.TARGET));
    }

    private boolean isValidType(LivingEntity entity) {
        return targets.contains("Players") && entity instanceof PlayerEntity// @off
                || targets.contains("Mobs") && (entity instanceof HostileEntity || entity instanceof SlimeEntity)
                || targets.contains("Passives") && (entity instanceof VillagerEntity
                || entity instanceof GolemEntity) || targets.contains("Animals") && entity instanceof AnimalEntity; // @on
    }

    @EventTarget
    public void onRenderEntity(RenderEntityEvent renderEntityEvent) {
        if (!colored.get()) {
            if (isValid((LivingEntity) renderEntityEvent.getEntity())) {
                if (renderEntityEvent.getState() == RenderEntityEvent.State.PRE) {
                    // PORT: GL11.glEnable(GL_POLYGON_OFFSET_FILL) + glPolygonOffset(1, -1100000)
                    // has no immediate-mode equivalent — the wall-hack needs a chams
                    // RenderLayer or depth-test override inside the entity renderer
                    // mixin (see notes/hooks_needed).
                } else {
                    // PORT: counterpart restore (glDisable + glPolygonOffset(1, 1100000)).
                }
            }
        }
    }

    @EventTarget
    public void onTick(TickUpdateEvent tickUpdateEvent) {
        pulseAlpha = MathHelper.clamp(pulseAlpha, 0, visibleAlpha.get());
        if (!isF && pulseAlpha < visibleAlpha.get()) {
            pulseAlpha = MathHelper.clamp(pulseAlpha + pulseSpeed.get(), 0, visibleAlpha.get());
        } else if (!isF && pulseAlpha == visibleAlpha.get()) {
            isF = true;
        } else if (isF && pulseAlpha > 0) {
            pulseAlpha = MathHelper.clamp(pulseAlpha - pulseSpeed.get(), 0, visibleAlpha.get());
        } else if (isF && pulseAlpha == 0) {
            isF = false;
        }
    }

    //region Lombok
    public ColorProperty getVisible() {
        return visible;
    }

    public ColorProperty getHidden() {
        return hidden;
    }

    public ColorProperty getHandColor() { return handColor; }

    public BooleanProperty getHand() { return hand; }

    public float getVisibleAlpha() {
        return pulse.get() ? pulseAlpha : visibleAlpha.get();
    }

    public BooleanProperty getRainbow() {
        return rainbow;
    }

    public ListProperty<String> getTargets() {
        return targets;
    }

    @Override
    public void onEnable() {
        pulseAlpha = 0;
        isF = false;
        super.onEnable();
    }

    //endregion

}
