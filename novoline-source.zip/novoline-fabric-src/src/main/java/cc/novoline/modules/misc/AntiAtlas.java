package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.LoadWorldEvent;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.utils.Timer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

import static cc.novoline.modules.misc.AutoHypixel.getFormattedText;

public class AntiAtlas extends AbstractModule {

    private List<UUID> reported = new CopyOnWriteArrayList();
    private Timer timer = new Timer();

    public AntiAtlas(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.MISC, "AntiAtlas", "Anti Atlas");
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        for (PlayerListEntry playerInfo : mc.getNetworkHandler().getPlayerList()) {
            UUID uuid = playerInfo.getProfile().id();
            String name = playerInfo.getProfile().name();

            if (timer.delay(5000) && !reported.contains(uuid) && !uuid.equals(mc.player.getUuid())) {
                // PORT: C01PacketChatMessage("/...") -> CommandExecutionC2SPacket (command without "/")
                sendPacketNoEvent(new CommandExecutionC2SPacket("report " + name + " killaura fly speed"));
                reported.add(uuid);
                timer.reset();
            }
        }
    }

    @EventTarget
    public void onWorldLoad(LoadWorldEvent event) {
        reported.clear();
        timer.reset();
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.INCOMING)) {
            if (event.getPacket() instanceof GameMessageS2CPacket) {
                GameMessageS2CPacket packet = (GameMessageS2CPacket) event.getPacket();

                if (getFormattedText(packet.content()).startsWith("§cThere is no player named")) {
                    event.setCancelled(true);
                }
            }
        }
    }
}
