package cc.novoline.modules.misc;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

import java.util.Arrays;
import java.util.stream.Stream;

public final class
ChatFilter extends AbstractModule {


    /* constructors @on */
    public ChatFilter(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "ChatBypass", "Chat Bypass", Keyboard.KEY_NONE, EnumModuleType.MISC, "Bypasses N, F words");
    }

    @EventTarget
    public void onPacketSending(PacketEvent event) {
        if(event.getState().equals(PacketEvent.State.OUTGOING)) {
            // PORT: C01PacketChatMessage split into ChatMessageC2SPacket (plain chat) and
            // CommandExecutionC2SPacket (slash commands, stored without the leading "/").
            String message = null;

            if (event.getPacket() instanceof ChatMessageC2SPacket) {
                message = ((ChatMessageC2SPacket) event.getPacket()).chatMessage();
            } else if (event.getPacket() instanceof CommandExecutionC2SPacket) {
                message = "/" + ((CommandExecutionC2SPacket) event.getPacket()).command();
            }

            if (message != null) {
                final String[] split = message.split(" ");
                final String command = split[0];
                String transformed = null;

                if (message.startsWith("/") && Stream.of("/r", "/shout", "/msg", "/m", "/tell", "/whisper", "/w", "/ac", "/pc", "/gc").anyMatch(command::equalsIgnoreCase)) {
                    if (Stream.of("/r", "/shout", "/ac", "/pc", "/gc").anyMatch(command::equalsIgnoreCase)) {
                        transformed = split[0] + " " + encrypt(String.join(" ", Arrays.copyOfRange(split, 1, split.length)));
                    } else if (split.length > 1) {
                        transformed = split[0] + " " + split[1] + " " + encrypt(String.join(" ", Arrays.copyOfRange(split, 2, split.length)));
                    }
                }

                if (transformed != null) {
                    message = transformed;
                }

                if (!message.startsWith("/") && !message.startsWith(".")
                        && !message.startsWith("http") && !message.equalsIgnoreCase("gg")) {
                    transformed = encrypt(message);
                }

                // PORT: modern packets are immutable and PacketEvent has no setPacket — cancel the
                // original and re-send the transformed content, skipping the event to avoid recursion.
                if (transformed != null) {
                    event.setCancelled(true);
                    sendTransformed(transformed);
                }
            }
        }
    }

    private void sendTransformed(String message) {
        if (mc.player == null) {
            return;
        }

        novoline.getNoEventSend().set(true);
        try {
            if (message.startsWith("/")) {
                mc.player.networkHandler.sendChatCommand(message.substring(1));
            } else {
                mc.player.networkHandler.sendChatMessage(message);
            }
        } finally {
            novoline.getNoEventSend().remove();
        }
    }

    private String encrypt(String string) {
        StringBuilder msg = new StringBuilder();
        char[] chars = string.toCharArray();

        for (char aChar : chars) {
            msg.append(aChar).append('ּ');
        }

        return msg.toString();
    }
}
