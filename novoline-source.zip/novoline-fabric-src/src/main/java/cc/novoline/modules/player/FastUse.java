/*
package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.IntProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.utils.ServerUtils;
import net.minecraft.component.type.DataComponentTypes;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import org.jetbrains.annotations.NotNull;

public class FastUse extends AbstractModule {

    @Property("tick")
    private final IntProperty tick = PropertyFactory.createInt(4).maximum(20).minimum(1);

    public FastUse(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.PLAYER, "FastUse", "Fast Use");
        Manager.put(new Setting("FS_TICK", "Tick", SettingType.SLIDER, this, tick, 1));
    }

    @EventTarget
    public void onMotion(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.POST)) {
            // PORT: ItemFood/ItemPotion/ItemBucketMilk -> CONSUMABLE component (covers all three;
            //       slightly broader: any consumable like dried kelp/potion/milk)
            if (mc.player.isUsingItem() && mc.player.getActiveItem().contains(DataComponentTypes.CONSUMABLE)) {
                if (tick.get() == 1 || mc.player.getItemUseTime() == tick.get()) {
                    if (ServerUtils.isHypixel()) {
                        // PORT: ViaFabric.clientSideVersion == novoline.viaVersion() check dropped
                        //       (ViaVersion not ported); extra-packet path always taken
                        for (int i = 0; i < 30; i++) {
                            sendPacketNoEvent(new PlayerMoveC2SPacket.OnGroundOnly(false, mc.player.horizontalCollision));
                            sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().getSelectedSlot()));
                        }

                    } else {
                        for (int i = 0; i < 20; i++) {
                            sendPacketNoEvent(new PlayerMoveC2SPacket.OnGroundOnly(false, mc.player.horizontalCollision));
                        }
                    }
                }
            }
        }
    }
}
*/
