package cc.novoline.modules.visual;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.BooleanProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;
import cc.novoline.utils.PlayerUtils;
import cc.novoline.utils.RenderUtils;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;

import java.util.stream.Collectors;

public class Tracers extends AbstractModule {

    @Property("only-tar")
    BooleanProperty only_tar = PropertyFactory.booleanFalse();
    @Property("team-color")
    BooleanProperty team_color = PropertyFactory.booleanFalse();

    public Tracers(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "Tracers", EnumModuleType.VISUALS);
        Manager.put(new Setting("TC_ONLY_TAR", "Targets Only", SettingType.CHECKBOX, this, only_tar));
        Manager.put(new Setting("TC_TEAM_COLOR", "Team Color", SettingType.CHECKBOX, this, team_color));
    }

    @EventTarget
    public void on3DRender(Render3DEvent event) {
        for (AbstractClientPlayerEntity player : mc.world.getPlayers().stream().filter(e -> !only_tar.get()
                || novoline.getPlayerManager().hasType(e.getName().getString(), PlayerManager.EnumPlayerType.TARGET)).collect(Collectors.toList())) {

            if (player.isAlive() && player != mc.player && !player.isInvisible()) {
                Vec3d camPos = RenderUtils.cameraPos();
                final double posX = player.lastX + (player.getX() - player.lastX) * event.getPartialTicks() - camPos.x;
                final double posY = player.lastY + (player.getY() - player.lastY) * event.getPartialTicks() - camPos.y;
                final double posZ = player.lastZ + (player.getZ() - player.lastZ) * event.getPartialTicks() - camPos.z;
                // PORT: viewBobbing/setupCameraTransform not needed - the world queue is already camera-space

                RenderUtils.startDrawing();

                boolean target = novoline.getPlayerManager().hasType(player.getName().getString(), PlayerManager.EnumPlayerType.TARGET);
                double[] color;
                Integer teamColor = !target && team_color.get() ? PlayerUtils.getTeamColor(player) : null;
                if (target) {
                    color = new double[]{1.0D, 0.0D, 0.0D};
                } else if (teamColor != null) {
                    color = new double[]{(teamColor >> 16 & 0xFF) / 255.0D, (teamColor >> 8 & 0xFF) / 255.0D, (teamColor & 0xFF) / 255.0D};
                } else {
                    color = new double[]{1.0D, 1.0D, 1.0D};
                }
                RenderUtils.drawLine(player, color, posX, posY + player.getStandingEyeHeight(), posZ);
                RenderUtils.stopDrawing();
            }
        }
    }
}
