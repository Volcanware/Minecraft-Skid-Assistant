package cc.novoline.modules.move;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.*;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import cc.novoline.utils.notifications.NotificationType;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class LongJump extends AbstractModule {

/*    @Property("speed")
    private DoubleProperty speed = PropertyFactory.createDouble(5.0).minimum(2.0).maximum(6.0);
    @Property("jump-boost")
    private IntProperty jump_boost = PropertyFactory.createInt(2).minimum(0).maximum(4);*/

    public LongJump(@NotNull ModuleManager novoline) {
        super(novoline, EnumModuleType.MOVEMENT, "LongJump", "Long Jump");
/*        Manager.put(new Setting("LJ_SPEED", "Speed", SettingType.SLIDER, this, speed, 0.2));
        Manager.put(new Setting("LJ_JUMP_BOOST", "Jump Boost", SettingType.SLIDER, this, jump_boost, 1));*/
    }

    private int tick, stage;
    private boolean shouldBoost, wait;
    private double lastDist, baseSpeed, moveSpeed;
    private List<Packet<?>> packetList = new CopyOnWriteArrayList();

    private int bowSlot() {
        return MoveUtils.getSlotByItem(mc.player, Items.BOW);
    }

    @Override
    public void onEnable() {
        if (bowSlot() == -1 || !mc.player.getInventory().contains(stack -> stack.isOf(Items.ARROW))) {
            novoline.getNotificationManager().pop(getDisplayName(), "You need bow in your hotbar and arrows", NotificationType.WARNING);
            toggle();
            return;
        }

        wait = true;
        setSuffix("Hypixel");
        checkModule(Speed.class, Scaffold.class, Flight.class);
    }

    @Override
    public void onDisable() {
        tick = 0;
        MoveUtils.setTimerSpeed(1);
    }

    @EventTarget
    public void onTick(TickUpdateEvent event) {
        setSuffix("Hypixel");
        tick++;
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        lastDist = MoveUtils.getLastTickDistance(mc.player);
        baseSpeed = MoveUtils.getBaseMoveSpeed(mc.player, 0.16);

        if (mc.player.timeUntilRegen == 19) {
            wait = false;
            stage = 1;
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (event.getPacket() instanceof PlayerPositionLookS2CPacket) {
            checkModule(getClass());
        }

        if (wait) {
            if (event.getPacket() instanceof PlayerMoveC2SPacket || event.getPacket() instanceof PlayerInteractItemC2SPacket
                    || event.getPacket() instanceof PlayerInteractBlockC2SPacket || event.getPacket() instanceof PlayerActionC2SPacket
                    || event.getPacket() instanceof UpdateSelectedSlotC2SPacket) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onMotion(MotionUpdateEvent event) {
        if (event.getState().equals(MotionUpdateEvent.State.PRE)) {
            if (tick == 1) {
                sendPacketNoEvent(new PlayerMoveC2SPacket.OnGroundOnly(false, mc.player.horizontalCollision));
                sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(bowSlot()));
                sendPacketNoEvent(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
            } else if (tick == 2) {
                sendPacketNoEvent(new PlayerMoveC2SPacket.OnGroundOnly(false, mc.player.horizontalCollision));
            } else if (tick == 3) {
                sendPacketNoEvent(new PlayerMoveC2SPacket.OnGroundOnly(false, mc.player.horizontalCollision));
            } else if (tick == 4) {
                sendPacketNoEvent(new PlayerMoveC2SPacket.Full(new Vec3d(event.getX(), event.getY(), event.getZ()), event.getYaw(), -90, event.isOnGround(), mc.player.horizontalCollision));
                sendPacketNoEvent(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, Direction.DOWN));
                sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().getSelectedSlot()));
            }
        }

        if (tick > 35) {
            if (mc.player.isOnGround()) {
                MoveUtils.setTimerSpeed(1);
                checkModule(getClass());
            }
        }
    }

    @EventTarget
    public void onMove(MoveEvent event) {
        double baseAmplifier = mc.player.hasStatusEffect(StatusEffects.SPEED) ? mc.player.getStatusEffect(StatusEffects.SPEED).getAmplifier() == 1 ? 1.86 : 1.34 : 1.34;
        double jumpAmplifier = mc.player.hasStatusEffect(StatusEffects.SPEED) ? mc.player.getStatusEffect(StatusEffects.SPEED).getAmplifier() == 1 ? 1.69 : 2.35 : 2.2;
        if (wait) {
            event.setMoveSpeed(0);
        } else if (MoveUtils.isMoving(mc.player)) {
            if (mc.player.isOnGround()) {
                if (shouldBoost) {
                    double motionY = MoveUtils.getBaseMotionY(mc.player) + 0.1 * (4 - (mc.player.hasStatusEffect(StatusEffects.JUMP_BOOST) ?
                            mc.player.getStatusEffect(StatusEffects.JUMP_BOOST).getAmplifier() + 1 : 0));
                    mc.player.setVelocity(mc.player.getVelocity().x, motionY, mc.player.getVelocity().z);
                    event.setY(motionY);
                    moveSpeed *= 0.9;
                } else {
                    moveSpeed = MoveUtils.getBySprinting(mc.player) * 2;
                }
            } else {
                print(mc.player.getVelocity().y);
                if (mc.player.getVelocity().y == 0.03196443960654492) {
                    mc.player.setVelocity(mc.player.getVelocity().x, -0.13, mc.player.getVelocity().z);
                }
                moveSpeed = lastDist - lastDist / 55;
            }

            event.setMoveSpeed(Math.max(moveSpeed, baseSpeed));
            shouldBoost = mc.player.isOnGround();
        }
    }
}
