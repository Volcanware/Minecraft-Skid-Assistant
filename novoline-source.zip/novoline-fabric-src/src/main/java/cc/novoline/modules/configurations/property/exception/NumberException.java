package cc.novoline.modules.configurations.property.exception;
import org.jetbrains.annotations.NotNull;

import cc.novoline.modules.configurations.property.AbstractNumberProperty;

/**
 * @author xDelsy
 */
public class NumberException extends PropertyException {

    /* constructors */
    public NumberException(@NotNull AbstractNumberProperty<?, ?> property) {
        super(property);
    }

    public NumberException(String message, @NotNull AbstractNumberProperty<?, ?> property) {
        super(message, property);
    }

    public NumberException(String message, Throwable cause, @NotNull AbstractNumberProperty<?, ?> property) {
        super(message, cause, property);
    }

    public NumberException(Throwable cause, @NotNull AbstractNumberProperty<?, ?> property) {
        super(cause, property);
    }

}
