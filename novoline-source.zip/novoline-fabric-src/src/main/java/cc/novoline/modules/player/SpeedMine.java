package cc.novoline.modules.player;

import cc.novoline.events.EventTarget;
import cc.novoline.events.events.PacketEvent;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.gui.screen.setting.SettingType;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.ModuleManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.jetbrains.annotations.NotNull;

import cc.novoline.mixin.ClientPlayerInteractionManagerAccessor;
import cc.novoline.modules.configurations.annotation.Property;
import cc.novoline.modules.configurations.property.object.FloatProperty;
import cc.novoline.modules.configurations.property.object.PropertyFactory;

public final class SpeedMine extends AbstractModule {

    @Property("mine-speed")
    private final FloatProperty mine_speed = PropertyFactory.createFloat(1.4F).minimum(0.1F).maximum(10.0F);

    private boolean destroy = false;
    private float progress = 0.0f;
    private BlockPos blockPos;
    private Direction facing;

    /* constructors */
    public SpeedMine(@NotNull ModuleManager moduleManager) {
        super(moduleManager, "SpeedMine", "Speed Mine", EnumModuleType.PLAYER, "Speeds up block breaking");
        Manager.put(new Setting("SM_SPEED", "Mine Speed", SettingType.SLIDER, this, mine_speed, 0.1));
    }

    /* events */

    @EventTarget
    public void onDamageBlock(PacketEvent event) {
        if (event.getState().equals(PacketEvent.State.OUTGOING)) {
            if (mc.interactionManager == null || mc.interactionManager.getCurrentGameMode().isCreative()) {
                return;
            }

            // PORT: extendedReach() == getCurrentGameMode().isCreative() in the 1.8.9 controller
            if (event.getPacket() instanceof PlayerActionC2SPacket packet && !mc.interactionManager.getCurrentGameMode().isCreative() && mc.interactionManager != null) {
                if (packet.getAction() == PlayerActionC2SPacket.Action.START_DESTROY_BLOCK) {
                    destroy = true;
                    blockPos = packet.getPos();
                    facing = packet.getDirection();
                    progress = 0.0f;

                } else if (packet.getAction() == PlayerActionC2SPacket.Action.ABORT_DESTROY_BLOCK
                        || packet.getAction() == PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK) {
                    destroy = false;
                    progress = 0.0f;
                    blockPos = null;
                    facing = null;
                }
            }
        }
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.interactionManager == null) {
            return;
        }

        if (mc.interactionManager.getCurrentGameMode().isCreative()) {
            // PORT: extendedReach() -> same creative check; blockHitDelay -> private blockBreakingCooldown
            setBlockBreakingCooldown(0);

        } else if (destroy && mc.interactionManager.isBreakingBlock() && canHarvestTarget()) {
            BlockState state = mc.world.getBlockState(blockPos);
            progress += state.calcBlockBreakingDelta(mc.player, mc.world, blockPos) * mine_speed.get();

            if (progress >= 1.0f) {
                mc.world.setBlockState(blockPos, Blocks.AIR.getDefaultState(), 11);
                sendPacketNoEvent(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, blockPos, facing));
            }
        }
    }

    // PORT: mc.player.canHarvestBlock(block) -> mc.player.canHarvest(state) on the crosshair target
    private boolean canHarvestTarget() {
        return mc.crosshairTarget instanceof BlockHitResult hitResult
                && mc.player.canHarvest(mc.world.getBlockState(hitResult.getBlockPos()));
    }

    private void setBlockBreakingCooldown(int value) {
        ((ClientPlayerInteractionManagerAccessor) mc.interactionManager).novoline$setBlockBreakingCooldown(value);
    }

    @Override
    public void onDisable() {
        progress = 0.0f;
        destroy = false;
        blockPos = null;
        facing = null;
    }
}
