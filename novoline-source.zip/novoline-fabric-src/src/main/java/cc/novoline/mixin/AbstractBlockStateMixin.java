package cc.novoline.mixin;

import cc.novoline.events.EventManager;
import cc.novoline.events.events.CollideWithBlockEvent;
import cc.novoline.modules.visual.XRay;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class AbstractBlockStateMixin {

    /**
     * Fires CollideWithBlockEvent for every block the entity collides with —
     * modules may replace the box (Freecam nulls it, AntiCactus widens it).
     */
    @ModifyReturnValue(method = "getCollisionShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/ShapeContext;)Lnet/minecraft/util/shape/VoxelShape;", at = @At("RETURN"))
    private VoxelShape novoline$collideWithBlock(VoxelShape original, BlockView world, BlockPos pos, ShapeContext context) {
        AbstractBlock.AbstractBlockState self = (AbstractBlock.AbstractBlockState) (Object) this;
        CollideWithBlockEvent event = (CollideWithBlockEvent) EventManager.call(
            new CollideWithBlockEvent(self.getBlock(), pos, original.isEmpty() ? null : original.getBoundingBox()));
        if (event.isCancelled() || event.getBoundingBox() == null) {
            return VoxelShapes.empty();
        }
        if (original.isEmpty() || !event.getBoundingBox().equals(original.getBoundingBox())) {
            return VoxelShapes.cuboid(event.getBoundingBox());
        }
        return original;
    }

    /** XRay: cull every side of non-whitelisted blocks so only ores render. */
    @ModifyReturnValue(method = "isSideInvisible", at = @At("RETURN"))
    private boolean novoline$xrayCull(boolean original, BlockState state, Direction direction) {
        if (XRay.isEnabled && !XRay.isXrayBlock(((AbstractBlock.AbstractBlockState) (Object) this).getBlock())) {
            return true;
        }
        return original;
    }
}
