package cc.novoline.mixin;

import cc.novoline.Novoline;
import cc.novoline.modules.visual.Atmosphere;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(World.class)
public abstract class WorldMixin {

    /** Atmosphere overrides the reported time of day. */
    @ModifyReturnValue(method = "getTimeOfDay", at = @At("RETURN"))
    private long novoline$timeOfDay(long original) {
        if (Novoline.getInstance().getModuleManager() != null) {
            Atmosphere atmosphere = Novoline.getInstance().getModuleManager().getModule(Atmosphere.class);
            if (atmosphere != null && atmosphere.isEnabled()) {
                return atmosphere.getTime();
            }
        }
        return original;
    }
}
