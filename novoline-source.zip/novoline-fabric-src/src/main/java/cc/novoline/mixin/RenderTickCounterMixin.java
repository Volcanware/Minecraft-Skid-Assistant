package cc.novoline.mixin;

import cc.novoline.modules.move.MoveUtils;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(RenderTickCounter.Dynamic.class)
public abstract class RenderTickCounterMixin {

    /** GameSpeed: scales the tick rate — dynamicDeltaTicks ends up multiplied by timerSpeed. */
    @ModifyExpressionValue(method = "beginRenderTick(J)I", at = @At(value = "INVOKE",
        target = "Lit/unimi/dsi/fastutil/floats/FloatUnaryOperator;apply(F)F"))
    private float novoline$timerSpeed(float original) {
        float speed = MoveUtils.getTimerSpeed();
        return speed == 1.0F ? original : original / speed;
    }
}
