package cc.novoline.mixin;

import cc.novoline.Novoline;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(Camera.class)
public abstract class CameraMixin {

    /** ViewClip: keep the requested third-person distance instead of clipping into blocks. */
    @ModifyReturnValue(method = "clipToSpace", at = @At("RETURN"))
    private float novoline$viewClip(float original, float desiredCameraDistance) {
        cc.novoline.modules.visual.Camera camera = Novoline.getInstance().getModuleManager() != null
            ? Novoline.getInstance().getModuleManager().getModule(cc.novoline.modules.visual.Camera.class) : null;
        if (camera != null && camera.isEnabled() && camera.getViewClip().get()) {
            return desiredCameraDistance;
        }
        return original;
    }
}
