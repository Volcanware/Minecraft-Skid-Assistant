package cc.novoline.mixin;

import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.events.KeyPressEvent;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.binds.KeyboardKeybind;
import cc.novoline.modules.configurations.holder.ModuleHolder;
import net.minecraft.client.Keyboard;
import net.minecraft.client.input.KeyInput;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public abstract class KeyboardMixin {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void novoline$onKey(long window, int action, KeyInput input, CallbackInfo ci) {
        org.lwjgl.input.Keyboard.setEventKey(org.lwjgl.input.Keyboard.fromGlfw(input.key()), action != GLFW.GLFW_RELEASE);

        if (action == GLFW.GLFW_PRESS) {
            int k = org.lwjgl.input.Keyboard.getEventKey();
            EventManager.call(new KeyPressEvent(k));

            // Binds must not toggle while a screen is open (typing a "." command
            // or chatting would toggle modules) nor before a world is loaded.
            net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
            if (mc.currentScreen == null && mc.player != null && Novoline.getInstance().getModuleManager() != null) {
                for (ModuleHolder<?> holder : Novoline.getInstance().getModuleManager().getModuleManager().values()) {
                    AbstractModule module = holder.getModule();
                    if (module.getKeybind().get() instanceof KeyboardKeybind
                        && module.getKeybind().get().getKey() == k) {
                        module.toggle();
                    }
                }
            }
        }
    }
}
