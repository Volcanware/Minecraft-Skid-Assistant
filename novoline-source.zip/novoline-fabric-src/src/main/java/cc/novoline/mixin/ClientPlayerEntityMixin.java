package cc.novoline.mixin;

import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.events.DisplayChestGuiEvent;
import cc.novoline.events.events.MotionUpdateEvent;
import cc.novoline.events.events.MoveEvent;
import cc.novoline.events.events.PlayerUpdateEvent;
import cc.novoline.events.events.SlowdownEvent;
import cc.novoline.events.events.SneakEvent;
import cc.novoline.modules.combat.Criticals;
import cc.novoline.modules.combat.KillAura;
import cc.novoline.modules.misc.GuiMove;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {

    @Shadow
    @Final
    public net.minecraft.client.network.ClientPlayNetworkHandler networkHandler;

    @Shadow
    private double lastXClient;
    @Shadow
    private double lastYClient;
    @Shadow
    private double lastZClient;
    @Shadow
    private float lastYawClient;
    @Shadow
    private float lastPitchClient;
    @Shadow
    private int ticksSinceLastPositionPacketSent;
    @Shadow
    private boolean lastOnGround;
    @Shadow
    private boolean lastHorizontalCollision;
    @Shadow
    private boolean autoJumpEnabled;
    @Shadow
    @Final
    protected MinecraftClient client;

    @Shadow
    public abstract boolean isUsingItem();

    @Shadow
    protected abstract void sendSprintingPacket();

    @Shadow
    protected abstract boolean isCamera();

    @Inject(method = "tick", at = @At("HEAD"))
    private void novoline$playerUpdate(CallbackInfo ci) {
        EventManager.call(new PlayerUpdateEvent());
    }

    /**
     * Replaces vanilla sendMovementPackets with the 1.8.9 onUpdateWalkingPlayer
     * behaviour: fires a mutable PRE MotionUpdateEvent whose values go into the
     * movement packets, and a POST event afterwards.
     */
    @Inject(method = "sendMovementPackets", at = @At("HEAD"), cancellable = true)
    private void novoline$sendMovementPackets(CallbackInfo ci) {
        ci.cancel();

        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        this.sendSprintingPacket();

        if (!this.isCamera()) {
            return;
        }

        MotionUpdateEvent preUpdate = new MotionUpdateEvent(
            self.getX(), self.getY(), self.getZ(), self.getYaw(), self.getPitch(),
            self.isOnGround(), MotionUpdateEvent.State.PRE);
        MotionUpdateEvent postUpdate = new MotionUpdateEvent(MotionUpdateEvent.State.POST);
        EventManager.call(preUpdate);

        double d = preUpdate.getX() - this.lastXClient;
        double e = preUpdate.getY() - this.lastYClient;
        double f = preUpdate.getZ() - this.lastZClient;
        double g = preUpdate.getYaw() - this.lastYawClient;
        double h = preUpdate.getPitch() - this.lastPitchClient;
        this.ticksSinceLastPositionPacketSent++;
        boolean bl = net.minecraft.util.math.MathHelper.squaredMagnitude(d, e, f) > net.minecraft.util.math.MathHelper.square(2.0E-4)
            || this.ticksSinceLastPositionPacketSent >= 20
            || Novoline.getInstance().getModuleManager().getModule(Criticals.class)
            .shouldCrit(Novoline.getInstance().getModuleManager().getModule(KillAura.class));
        boolean bl2 = g != 0.0 || h != 0.0;

        if (bl && bl2) {
            this.networkHandler.sendPacket(new PlayerMoveC2SPacket.Full(
                new Vec3d(preUpdate.getX(), preUpdate.getY(), preUpdate.getZ()),
                preUpdate.getYaw(), preUpdate.getPitch(), preUpdate.isOnGround(), self.horizontalCollision));
        } else if (bl) {
            this.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                new Vec3d(preUpdate.getX(), preUpdate.getY(), preUpdate.getZ()),
                preUpdate.isOnGround(), self.horizontalCollision));
        } else if (bl2) {
            this.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                preUpdate.getYaw(), preUpdate.getPitch(), preUpdate.isOnGround(), self.horizontalCollision));
        } else if (this.lastOnGround != preUpdate.isOnGround() || this.lastHorizontalCollision != self.horizontalCollision) {
            this.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(preUpdate.isOnGround(), self.horizontalCollision));
        }

        if (bl) {
            this.lastXClient = preUpdate.getX();
            this.lastYClient = preUpdate.getY();
            this.lastZClient = preUpdate.getZ();
            this.ticksSinceLastPositionPacketSent = 0;
        }

        if (bl2) {
            this.lastYawClient = preUpdate.getYaw();
            this.lastPitchClient = preUpdate.getPitch();
        }

        this.lastOnGround = preUpdate.isOnGround();
        this.lastHorizontalCollision = self.horizontalCollision;
        this.autoJumpEnabled = this.client.options.getAutoJump().getValue();

        EventManager.call(postUpdate);
    }

    @ModifyVariable(method = "move", at = @At("HEAD"), argsOnly = true)
    private Vec3d novoline$move(Vec3d movement) {
        MoveEvent event = new MoveEvent(movement.x, movement.y, movement.z);
        EventManager.call(event);
        return new Vec3d(event.getX(), event.getY(), event.getZ());
    }

    @ModifyReturnValue(method = "getActiveItemSpeedMultiplier", at = @At("RETURN"))
    private float novoline$slowdown(float original) {
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        if (self.isUsingItem() && !self.hasVehicle()) {
            SlowdownEvent event = new SlowdownEvent();
            EventManager.call(event);
            if (event.isCancelled()) {
                return 1.0F;
            }
        }
        return original;
    }

    @Inject(method = "pushOutOfBlocks", at = @At("HEAD"), cancellable = true)
    private void novoline$pushOutOfBlocks(double x, double z, CallbackInfo ci) {
        cc.novoline.events.events.PushBlockEvent pushBlock = new cc.novoline.events.events.PushBlockEvent();
        EventManager.call(pushBlock);
        if (pushBlock.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/input/Input;tick()V", shift = At.Shift.AFTER))
    private void novoline$guiMove(CallbackInfo ci) {
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        if (Novoline.getInstance().getModuleManager() != null
            && Novoline.getInstance().getModuleManager().getModule(GuiMove.class).isEnabled()
            && !(this.client.currentScreen instanceof ChatScreen)) {
            Novoline.getInstance().getModuleManager().getModule(GuiMove.class).updatePlayerMoveState();
        }
    }
}
