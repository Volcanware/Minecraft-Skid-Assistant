package cc.novoline.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import net.minecraft.util.ApiServices;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
    @Accessor("apiServices")
    void novoline$setApiServices(ApiServices apiServices);

    @Accessor("session")
    void novoline$setSession(Session session);
}
