package cc.novoline.mixin;

import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(SimpleOption.class)
public interface SimpleOptionAccessor<T> {

    /** Bypasses the slider's min/max validation (Brightness sets gamma to 10000). */
    @Accessor("value")
    void novoline$setValue(T value);
}
