package cc.novoline.mixin;

import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.events.PacketEvent;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.NetworkSide;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientConnection.class)
public abstract class ClientConnectionMixin {

    @Shadow
    private NetworkSide side;

    @Inject(method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V",
        at = @At("HEAD"), cancellable = true)
    private void novoline$receive(ChannelHandlerContext ctx, Packet<?> packet, CallbackInfo ci) {
        if (this.side == NetworkSide.CLIENTBOUND) {
            PacketEvent event = new PacketEvent(packet, PacketEvent.State.INCOMING);
            EventManager.call(event);
            if (event.isCancelled()) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V",
        at = @At("HEAD"), cancellable = true)
    private void novoline$send(Packet<?> packet, ChannelFutureListener listener, boolean flush,
                               CallbackInfo ci) {
        if (this.side == NetworkSide.CLIENTBOUND) {
            if (Novoline.getInstance().getNoEventSend() != null && Boolean.TRUE.equals(Novoline.getInstance().getNoEventSend().get())) {
                return;
            }

            PacketEvent event = new PacketEvent(packet, PacketEvent.State.OUTGOING);
            EventManager.call(event);
            if (event.isCancelled()) {
                ci.cancel();
            }
        }
    }
}
