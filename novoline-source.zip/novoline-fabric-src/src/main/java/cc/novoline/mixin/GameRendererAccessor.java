package cc.novoline.mixin;

import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(GameRenderer.class)
public interface GameRendererAccessor {

    @Invoker("setPostProcessor")
    void novoline$setPostProcessor(Identifier id);

    @Invoker("getFov")
    float novoline$getFov(net.minecraft.client.render.Camera camera, float tickProgress, boolean changingFov);
}
