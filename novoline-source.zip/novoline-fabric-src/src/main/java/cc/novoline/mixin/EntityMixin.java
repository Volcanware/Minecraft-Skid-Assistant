package cc.novoline.mixin;

import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.events.StepConfirmEvent;
import cc.novoline.modules.move.Step;
import cc.novoline.modules.visual.ESP;
import cc.novoline.utils.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;

@Mixin(Entity.class)
public abstract class EntityMixin {

    /**
     * Fires when the engine actually steps the entity up — mirrors the 1.8.9
     * hook in Entity#moveEntity's stepped-onto-block path.
     */
    @Inject(method = "adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;",
        at = @At(value = "RETURN", ordinal = 0))
    private void novoline$stepConfirm(Vec3d movement, CallbackInfoReturnable<Vec3d> cir) {
        if ((Entity) (Object) this == MinecraftClient.getInstance().player) {
            EventManager.call(new StepConfirmEvent());
        }
    }

    @Inject(method = "getStepHeight", at = @At("RETURN"), cancellable = true)
    private void novoline$stepHeight(CallbackInfoReturnable<Float> cir) {
        if ((Entity) (Object) this == MinecraftClient.getInstance().player
            && Novoline.getInstance().getModuleManager() != null) {
            Step step = Novoline.getInstance().getModuleManager().getModule(Step.class);
            if (step != null && step.isEnabled() && step.getHeight() > cir.getReturnValue()) {
                cir.setReturnValue(step.getHeight());
            }
        }
    }

    private static ESP novoline$glowModule() {
        if (Novoline.getInstance().getModuleManager() == null) return null;
        return Novoline.getInstance().getModuleManager().getModule(ESP.class);
    }

    /**
     * Glow module: flags valid entities as glowing so vanilla renders its
     * spectral outline pass on them (through walls). Replaces the 1.8.9
     * entityOutlineFramebuffer + OutlineUtils stencil approach.
     */
    @ModifyReturnValue(method = "isGlowing", at = @At("RETURN"))
    private boolean novoline$glow(boolean original) {
        if (original) return true;
        Entity self = (Entity) (Object) this;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || self == mc.player) return false;
        ESP esp = novoline$glowModule();
        return esp != null && esp.isEnabled()
            && self instanceof LivingEntity living && esp.isValid(living);
    }

    @org.spongepowered.asm.mixin.Shadow
    private Vec3d movementMultiplier;

    /** NoSlow webs: rewrites the slowdown multiplier for cobweb collisions.
        Web Speed 1.0 removes it entirely, higher moves faster than normal.
        "On Ground Only" keeps the vanilla multiplier while airborne. */
    @Inject(method = "slowMovement(Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/Vec3d;)V",
            at = @At("TAIL"))
    private void novoline$webMultiplier(net.minecraft.block.BlockState state, Vec3d multiplier,
                                        org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        if (!state.isOf(net.minecraft.block.Blocks.COBWEB)
                || Novoline.getInstance().getModuleManager() == null) {
            return;
        }
        cc.novoline.modules.move.NoSlow noSlow =
                Novoline.getInstance().getModuleManager().getModule(cc.novoline.modules.move.NoSlow.class);
        Entity self = (Entity) (Object) this;
        if (noSlow != null && noSlow.isEnabled() && noSlow.isWebEnabled()
                && (!noSlow.isWebOnGroundOnly() || self.isOnGround())) {
            float speed = noSlow.getWebSpeed();
            this.movementMultiplier = new Vec3d(speed, speed, speed);
        }
    }

    /** Tints the vanilla glow outline with the module's outline color. */
    @ModifyReturnValue(method = "getTeamColorValue", at = @At("RETURN"))
    private int novoline$glowColor(int original) {
        Entity self = (Entity) (Object) this;
        ESP esp = novoline$glowModule();
        if (esp == null || !esp.isEnabled()
            || !(self instanceof LivingEntity living) || !esp.isValid(living)) {
            return original;
        }
        switch (esp.outlineColor.get()) {
            case "Static":
                return esp.color.getAwtColor().getRGB() & 0xFFFFFF;
            case "Rainbow":
                return RenderUtils.getRainbow(3000, -15 * (int) (System.currentTimeMillis() / 10L)) & 0xFFFFFF;
            case "Team":
            default:
                return original;
        }
    }
}
