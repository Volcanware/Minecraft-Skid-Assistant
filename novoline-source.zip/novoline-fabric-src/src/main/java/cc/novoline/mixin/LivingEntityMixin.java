package cc.novoline.mixin;

import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.events.JumpEvent;
import cc.novoline.events.events.LivingUpdateEvent;
import cc.novoline.modules.visual.Animations;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Shadow
    public abstract float getJumpVelocity();

    @Inject(method = "tick", at = @At("TAIL"))
    private void novoline$livingUpdate(CallbackInfo ci) {
        EventManager.call(new LivingUpdateEvent((LivingEntity) (Object) this));
    }

    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    private void novoline$jump(CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self != MinecraftClient.getInstance().player) {
            return;
        }

        JumpEvent jumpEvent = new JumpEvent(this.getJumpVelocity());
        EventManager.call(jumpEvent);

        boolean heightChanged = jumpEvent.getHeight() != this.getJumpVelocity();
        if (jumpEvent.isCancelled() || heightChanged) {
            ci.cancel();
        }

        // Cancelled: vanilla must not run. Unchanged: let vanilla jump() run untouched —
        // running our replacement too would apply the sprint boost twice per jump.
        if (jumpEvent.isCancelled() || !heightChanged) {
            return;
        }

        float f = (float) jumpEvent.getHeight();
        if (f > 1.0E-5F) {
            Vec3d vec3d = self.getVelocity();
            self.setVelocity(vec3d.x, Math.max(f, vec3d.y), vec3d.z);
            if (self.isSprinting()) {
                float g = self.getYaw() * (float) (Math.PI / 180.0);
                self.addVelocityInternal(new Vec3d(-MathHelper.sin(g) * 0.2, 0.0, MathHelper.cos(g) * 0.2));
            }
            self.velocityDirty = true;
        }
    }

    /* PORT: 1.8.9 patched getArmSwingAnimationEnd() to return 6 + slowdown for the local player. */
    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
    private void novoline$slowSwing(CallbackInfoReturnable<Integer> cir) {
        if ((Object) this != MinecraftClient.getInstance().player) {
            return;
        }
        if (Novoline.getInstance().getModuleManager() == null) {
            return;
        }
        Animations animations = Novoline.getInstance().getModuleManager().getModule(Animations.class);
        if (animations != null && animations.isEnabled()) {
            cir.setReturnValue(6 + animations.getSlowdown().get());
        }
    }
}
