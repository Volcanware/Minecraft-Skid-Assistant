package cc.novoline.mixin;

import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.events.RenderNameTagEvent;
import cc.novoline.events.events.UpdateModelEvent;
import cc.novoline.modules.visual.Chams;
import cc.novoline.utils.NovolineRenderLayers;
import net.fabricmc.fabric.api.client.rendering.v1.FabricRenderState;
import net.fabricmc.fabric.api.client.rendering.v1.RenderStateDataKey;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<T extends LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>> {

    private static final RenderStateDataKey<Entity> NOVOLINE_ENTITY = RenderStateDataKey.create();

    @Shadow
    @Final
    protected M model;

    @Shadow
    public abstract net.minecraft.util.Identifier getTexture(S state);

    @Shadow
    protected float getAnimationCounter(S state) {
        return 0.0F;
    }

    /** Stash the entity on its render state so the render pass can recover it. */
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void novoline$stashEntity(T livingEntity, S livingEntityRenderState, float f, CallbackInfo ci) {
        ((FabricRenderState) livingEntityRenderState).setData(NOVOLINE_ENTITY, livingEntity);

        // RenderNameTagEvent: listeners cancel to suppress the vanilla nametag
        if (livingEntityRenderState.displayName != null) {
            RenderNameTagEvent event = (RenderNameTagEvent) EventManager.call(new RenderNameTagEvent(livingEntity));
            if (event.isCancelled()) {
                livingEntityRenderState.displayName = null;
            }
        }
    }

    /** UpdateModelEvent after the model angles are set for this entity. */
    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/model/EntityModel;setAngles(Ljava/lang/Object;)V", shift = At.Shift.AFTER))
    private void novoline$updateModel(S renderState, MatrixStack matrices, OrderedRenderCommandQueue queue,
                                      CameraRenderState cameraState, CallbackInfo ci) {
        Entity entity = ((FabricRenderState) renderState).getData(NOVOLINE_ENTITY);
        if (entity != null && this.model instanceof BipedEntityModel) {
            EventManager.call(new UpdateModelEvent(entity, (BipedEntityModel<?>) this.model));
        }
    }

    /** Chams: submit a second model pass through a no-depth-test layer so valid
     *  entities render through walls, tinted with the configured color. */
    @Inject(method = "render", at = @At("TAIL"))
    private void novoline$chams(S renderState, MatrixStack matrices, OrderedRenderCommandQueue queue,
                                CameraRenderState cameraState, CallbackInfo ci) {
        Entity entity = ((FabricRenderState) renderState).getData(NOVOLINE_ENTITY);
        if (!(entity instanceof LivingEntity living) || renderState.invisibleToPlayer) {
            return;
        }
        if (Novoline.getInstance().getModuleManager() == null) {
            return;
        }
        Chams chams = Novoline.getInstance().getModuleManager().getModule(Chams.class);
        if (chams == null || !chams.isEnabled() || !chams.isValid(living)) {
            return;
        }
        int tint = chams.isColored().get() ? chams.getChamsColor() : 0xFFFFFFFF;
        queue.submitModel(
            this.model, renderState, matrices,
            NovolineRenderLayers.chams(this.getTexture(renderState)),
            renderState.light,
            LivingEntityRenderer.getOverlay(renderState, this.getAnimationCounter(renderState)),
            tint, null, 0, null
        );
    }
}
