package cc.novoline.mixin;

import cc.novoline.Initializer;
import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.events.LoadWorldEvent;
import cc.novoline.events.events.RightClickEvent;
import cc.novoline.events.events.TickUpdateEvent;
import cc.novoline.gui.screen.dropdown.DropdownGUI;
import cc.novoline.modules.misc.FastPlace;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

    @Shadow
    @Nullable
    public net.minecraft.client.gui.screen.Screen currentScreen;

    @Shadow
    @Nullable
    public net.minecraft.client.network.ClientPlayerEntity player;

    @Shadow
    @Nullable
    public net.minecraft.client.world.ClientWorld world;

    @Inject(method = "onInitFinished", at = @At("RETURN"))
    private void novoline$init(CallbackInfoReturnable<Runnable> cir) {
        Initializer.getInstance().init();
    }

    @Inject(method = "stop", at = @At("HEAD"))
    private void novoline$shutdown(CallbackInfo ci) {
        Novoline.getInstance().onDisable();
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void novoline$tick(CallbackInfo ci) {
        EventManager.call(new TickUpdateEvent());
    }

    @Inject(method = "doItemUse", at = @At("HEAD"))
    private void novoline$rightClick(CallbackInfo ci) {
        EventManager.call(new RightClickEvent());
    }

    @Inject(method = "setWorld", at = @At("HEAD"))
    private void novoline$loadWorld(ClientWorld world, CallbackInfo ci) {
        if (world != null) {
            EventManager.call(new LoadWorldEvent());
        }
    }

    /** Tracks the previously-open screen — the clickgui restores it on close. */
    @Inject(method = "setScreen", at = @At("HEAD"))
    private void novoline$previousScreen(@Nullable Screen screen, CallbackInfo ci) {
        if (this.currentScreen != null) {
            DropdownGUI.previousScreen = this.currentScreen;
        }
    }

    /* PORT: 1.8.9 jar-patched GuiMainMenu itself; here we swap every vanilla
       TitleScreen for the NovoMainMenu. Two paths reach it: an explicit
       setScreen(new TitleScreen()) argument (getClass(), not instanceof, so
       RealmsMainScreen stays untouched) and setScreen(null) on the menu, where
       setScreen internally builds a TitleScreen without re-entering itself. */
    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void novoline$replaceTitleScreen(@Nullable Screen screen, CallbackInfo ci) {
        if ((screen != null && screen.getClass() == net.minecraft.client.gui.screen.TitleScreen.class)
                || (screen == null && this.world == null)) {
            ci.cancel();
            ((MinecraftClient) (Object) this).setScreen(new cc.novoline.gui.screen.menu.NovoMainMenu());
        }
    }

    /** FastPlace: shortens the use cooldown when placing blocks (or anything if blocksOnly is off). */
    @ModifyConstant(method = "doItemUse", constant = @Constant(intValue = 4))
    private int novoline$fastPlace(int original) {
        Novoline novoline = Novoline.getInstance();
        if (novoline.getModuleManager() == null) {
            return original;
        }
        FastPlace fastPlace = novoline.getModuleManager().getModule(FastPlace.class);
        if (!fastPlace.isEnabled() || this.player == null) {
            return original;
        }
        if (fastPlace.blocksOnly.get()
            && !(this.player.getMainHandStack().getItem() instanceof BlockItem)) {
            return original;
        }
        return fastPlace.placeDelay.get();
    }

    /** MultiTask: vanilla skips block breaking while an item is in use; drop that gate. */
    @com.llamalad7.mixinextras.injector.ModifyExpressionValue(method = "handleBlockBreaking",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"))
    private boolean novoline$multiTask(boolean original) {
        Novoline novoline = Novoline.getInstance();
        if (novoline.getModuleManager() == null) {
            return original;
        }
        cc.novoline.modules.player.MultiTask multiTask = novoline.getModuleManager().getModule(cc.novoline.modules.player.MultiTask.class);
        return multiTask == null || !multiTask.isEnabled() ? original : false;
    }
}
