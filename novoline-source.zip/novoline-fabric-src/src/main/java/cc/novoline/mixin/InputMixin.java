package cc.novoline.mixin;

import cc.novoline.events.EventManager;
import cc.novoline.events.events.SneakEvent;
import cc.novoline.utils.NovolineInput;
import net.minecraft.client.input.Input;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(Input.class)
public abstract class InputMixin implements NovolineInput {

    @Shadow
    public PlayerInput playerInput;

    @Shadow
    protected Vec2f movementVector;

    @Override
    public void novoline$setMoveStrafe(float strafe) {
        this.movementVector = new Vec2f(strafe, this.movementVector.y);
    }

    @Override
    public void novoline$setMoveForward(float forward) {
        this.movementVector = new Vec2f(this.movementVector.x, forward);
    }

    @Override
    public void novoline$setJump(boolean jump) {
        this.playerInput = new PlayerInput(
            this.playerInput.forward(), this.playerInput.backward(),
            this.playerInput.left(), this.playerInput.right(),
            jump, this.playerInput.sneak(), this.playerInput.sprint());
    }

    @Override
    public void novoline$setSneak(boolean sneak) {
        SneakEvent event = new SneakEvent();
        EventManager.call(event);
        if (event.isCancelled()) {
            sneak = false;
        }
        this.playerInput = new PlayerInput(
            this.playerInput.forward(), this.playerInput.backward(),
            this.playerInput.left(), this.playerInput.right(),
            this.playerInput.jump(), sneak, this.playerInput.sprint());
    }

    @Override
    public float novoline$getMoveStrafe() {
        return this.movementVector.x;
    }

    @Override
    public float novoline$getMoveForward() {
        return this.movementVector.y;
    }
}
