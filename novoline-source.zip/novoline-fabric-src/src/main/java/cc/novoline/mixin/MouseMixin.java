package cc.novoline.mixin;

import cc.novoline.Novoline;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.binds.MouseKeybind;
import cc.novoline.modules.binds.ModuleKeybind;
import cc.novoline.modules.configurations.holder.ModuleHolder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {

    @Shadow
    @Final
    private MinecraftClient client;

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void novoline$onMouseButton(long window, MouseInput input, int action, CallbackInfo ci) {
        if (action == GLFW.GLFW_PRESS && Novoline.getInstance().getModuleManager() != null) {
            for (ModuleHolder<?> holder : Novoline.getInstance().getModuleManager().getModuleManager().values()) {
                AbstractModule module = holder.getModule();
                ModuleKeybind moduleKeybind = module.getKeybind().get();

                if (moduleKeybind instanceof MouseKeybind keybind) {
                    if (keybind.getKey() == input.button() && keybind.click()) {
                        module.toggle();
                    }
                }
            }
        }
    }

    @Inject(method = "onMouseScroll", at = @At("HEAD"))
    private void novoline$onScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        org.lwjgl.input.Mouse.addScrollDelta(vertical);
    }
}
