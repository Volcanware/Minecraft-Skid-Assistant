package cc.novoline.mixin;

import cc.novoline.events.EventManager;
import cc.novoline.events.events.SpawnCheckEvent;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin {

    /** Fires SpawnCheckEvent whenever an entity enters the client world. */
    @Inject(method = "addEntity", at = @At("HEAD"))
    private void novoline$spawnCheck(Entity entity, CallbackInfo ci) {
        EventManager.call(new SpawnCheckEvent(entity));
    }
}
