package cc.novoline.mixin;

import cc.novoline.Novoline;
import cc.novoline.events.EventManager;
import cc.novoline.events.events.DisplayChestGuiEvent;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {

    /* Anything starting with '.' is a client command — never let it reach the
       server. The old prefix whitelist leaked every command it didn't list. */
    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void novoline$sendChatMessage(String content, CallbackInfo ci) {
        if (content.startsWith(".")) {
            Novoline.getInstance().getNovoCommandHandler().executeCommand(content.toLowerCase());
            ci.cancel();
        }
    }

    @Inject(method = "onOpenScreen", at = @At("HEAD"))
    private void novoline$onOpenScreen(OpenScreenS2CPacket packet, CallbackInfo ci) {
        EventManager.call(new DisplayChestGuiEvent(packet.getName().getString()));
    }

    /** Routes ".command" click events through NovoCommandHandler instead of the server. */
    @Inject(method = "runClickEventCommand", at = @At("HEAD"), cancellable = true)
    private void novoline$runClickEventCommand(String command, net.minecraft.client.gui.screen.Screen screen, CallbackInfo ci) {
        if (command.startsWith(".")) {
            Novoline.getInstance().getNovoCommandHandler().executeCommand(command.toLowerCase());
            ci.cancel();
        }
    }
}
