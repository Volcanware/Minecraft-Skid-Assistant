package cc.novoline.mixin;

import cc.novoline.Novoline;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    /** NoHurtCam: skip the hurt-tilt camera effect. */
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void novoline$noHurtCam(MatrixStack matrices, float tickProgress, CallbackInfo ci) {
        cc.novoline.modules.visual.Camera camera = Novoline.getInstance().getModuleManager() != null
            ? Novoline.getInstance().getModuleManager().getModule(cc.novoline.modules.visual.Camera.class) : null;
        if (camera != null && camera.isEnabled() && camera.getNoHurtCam().get()) {
            ci.cancel();
        }
    }
}
