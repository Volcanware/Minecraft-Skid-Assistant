package cc.novoline;

import cc.novoline.events.EventManager;
import cc.novoline.gui.screen.alt.repository.AltRepositoryGUI;
import cc.novoline.gui.screen.click.DiscordGUI;
import cc.novoline.gui.screen.dropdown.DropdownGUI;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.ModuleManager;
import cc.novoline.modules.ModuleManager.ModuleCreator;
import cc.novoline.modules.PlayerManager;
import cc.novoline.modules.combat.*;
import cc.novoline.modules.configurations.ConfigManager;
import cc.novoline.modules.exceptions.OutdatedConfigException;
import cc.novoline.modules.exploits.*;
import cc.novoline.modules.misc.*;
import cc.novoline.modules.move.*;
import cc.novoline.modules.player.*;
import cc.novoline.modules.visual.*;
import cc.novoline.utils.notifications.NotificationManager;
import cc.novoline.utils.tasks.TaskManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Fabric port of the 1.8.9 Initializer. Protection and ViaVersion are excluded
 * per request; everything else mirrors the original module registration.
 */
public class Initializer {

    private static final Logger LOGGER = LogManager.getLogger();
    private boolean isDev;

    public double secretShit = 0.01;
    public double flight50 = -50;
    public double flight90 = -12;
    public double flightAmp = -0.001;
    public double flight75 = -0.42;
    public double flightMagicCon1 = -1;
    public double flightMagicCon2 = 1;
    public double flightHypixelGroundCheck = 1;
    public double bunnyDivFriction = 50;
    public double threshold = 0.5;

    public double min17 = 0.00015, max17 = 0.000163166800276;
    public double min18 = 0.0099, max18 = 0.011921599284565;
    public double min19 = 0.014, max19 = 0.015919999545217;
    public double min20 = 0.0099, max20 = 0.011999999731779;

    private enum Singleton {
        INSTANCE;

        private final Initializer value;

        Singleton() {
            this.value = new Initializer();
        }
    }

    public static Initializer getInstance() {
        return Singleton.INSTANCE.value;
    }

    private boolean initialized;

    public void init() {
        if (initialized) return;
        initialized = true;
        onProtection("");
    }

    public String Xor(Object obj, String key) {
        StringBuilder sb = new StringBuilder();
        char[] keyChars = key.toCharArray();

        int i = 0;

        for (char c : obj.toString().toCharArray()) {
            sb.append((char) (c ^ keyChars[i % keyChars.length]));
            i++;
        }

        return sb.toString();
    }

    public void onProtection(String token) {
        try {
            {
                secretShit = 0.0001000000001;
                flight50 = 5.0d;
                flight90 = 9.0d;
                flight75 = 0.75d;
                flightAmp = 0.13d;
                flightMagicCon1 = 2.1449999809265137;
                flightMagicCon2 = -0.1552320045166016;
                flightHypixelGroundCheck = 0.015625;
                bunnyDivFriction = 159.9;
                threshold = 0.66;
            }

            try {
                Novoline.getInstance().setModuleManager(new ModuleManager(Novoline.getInstance(), 3));
                isDev = true;

                register("sprint", Sprint::new);
                register("hud", HUD::new);
                register("click_gui", ClickGUI::new);
                register("anti_bot", AntiBot::new);
                //           register("no_rotate", NoRotate::new);
                register("speed_mine", SpeedMine::new);
                register("auto_pot", AutoPot::new);
                register("kill_aura", KillAura::new);
                register("criticals", Criticals::new);
                register("reach", Reach::new);
                register("step", Step::new);
                register("water-walk", WaterWalk::new);
                register("no_slow", NoSlow::new);
                register("speed", Speed::new);
                register("velocity", Velocity::new);
                register("glow", ESP::new);
                register("chams", Chams::new);
                register("chest_esp", ChestESP::new);
                register("nametags", Nametags::new);
                register("no_fall", NoFall::new);
                register("xray", XRay::new);
                register("chest_stealer", ChestStealer::new);
                register("scaffold", Scaffold::new);
                register("auto_armor", AutoArmor::new);
                register("inv_manager", InvManager::new);
                register("auto-hypixel", AutoHypixel::new);
                register("gui_move", GuiMove::new);
                register("phase", Phase::new);
                register("auto_tool", AutoTool::new);
                register("animations", Animations::new);
                //     register("long-jump", LongJump::new);
                register("teleport", Teleport::new);
                register("glint-colorize", GlintColorize::new);
                register("middle-click", MiddleClick::new);
                register("dmg-particles", DMGParticle::new);
                register("tracers", Tracers::new);
                register("respawn", Respawn::new);
                register("blink", Blink::new);
                register("anti_cactus", AntiCactus::new);
                register("no_effects", NoEffects::new);
                register("crosshair", Crosshair::new);
                register("brightness", Brightness::new);
                register("item_physic", ItemPhysic::new);
                register("item_esp", ItemESP::new);
                register("auto_clicker", AutoClicker::new);
                register("aim_assist", AimAssist::new);
                register("fast_place", FastPlace::new);
                register("radar", Radar::new);
                register("players_finder", Notifier::new);
                register("world_time", Atmosphere::new);
                register("killsults", Killsults::new);
                register("spammer", Spammer::new);
                register("player_esp", PlayerESP::new);
                register("hit_box", HitBox::new);
                register("chat_filter", ChatFilter::new);
                register("waypoints", Waypoints::new);
                register("streamer", Streamer::new);
                register("antiobbytrap", AntiObbyTrap::new);
                register("freecam", Freecam::new);
                register("target-strafe", TargetStrafe::new);
                register("tab-gui", TabGUI::new);
                register("lightning-trecker", LightningTracker::new);
                register("camera", Camera::new);
                register("fast-sneak", FastSneak::new);
                register("arrows", Arrows::new);
                register("bed-breaker", BedBreaker::new);
                register("auto-heal", AutoHead::new);
                //   register("click-teleport", ClickTeleport::new);
                register("flight", Flight::new);
                register("anti_void", AntiVoid::new);
                register("long-jump", LongJump::new);
                register("anti-alts", AntiAtlas::new);
                register("blocksoverlay", BlockOutline::new);
                register("world-esp", WorldESP::new);
                register("multi-task", MultiTask::new);
                register("auto-weapon", AutoWeapon::new);

                if (isDev) {
                    register("game-speed", GameSpeed::new);
                    register("debug", Debug::new);
                    register("damage", Damage::new);
                }

                register("disabler", Disabler::new);

                Novoline.getInstance().playerManager = new PlayerManager(Novoline.getInstance(), "players.novo");
                Novoline.getInstance().taskManager = new TaskManager();
                Novoline.getInstance().notificationManager = new NotificationManager();
            } catch (Throwable t) {
                throw new RuntimeException("An error occurred while loading managers", t);
            }

            EventManager.register(Novoline.getInstance().getModuleManager().getModule(ClickGUI.class));
            Killsults killsults = Novoline.getInstance().getModuleManager().getModule(Killsults.class);

            if (Files.notExists(killsults.getPath())) {
                Files.createFile(killsults.getPath());
            }

            if (Novoline.getInstance().version.toCharArray()[0] == '@') {
                Novoline.getInstance().version = new SimpleDateFormat("MMddyy").format(new Date());
            }

            //region Loading configurations
            Novoline.getInstance().getModuleManager().getBindManager().load();

            ConfigManager configManager = Novoline.getInstance().getModuleManager().getConfigManager();
            Path path = configManager.getConfigPath("default");

            try {
                if (Files.exists(path)) {
                    configManager.load(path, false);
                }
            } catch (OutdatedConfigException oce) {
                LOGGER.error("Default config is outdated. Deleting it...");

                try {
                    Files.delete(path);
                } catch (IOException ioe) {
                    LOGGER.error("An I/O error occurred while deleting default config", ioe);
                }
            } catch (Throwable t) {
                LOGGER.error("An unexpected error occurred while loading default config", t);
            }
            //endregion

            MinecraftClient.getInstance().getWindow().setTitle("Novoline " + Novoline.getInstance().getVersion());
            Novoline.getInstance().discordGUI = new DiscordGUI(Novoline.getInstance());
            Novoline.getInstance().dropDownGUI = new DropdownGUI();
            Novoline.getInstance().altRepositoryGUI = new AltRepositoryGUI(Novoline.getInstance());

            System.setProperty("java.net.preferIPv4Stack", "true");
        } catch (Throwable t) {
            t.printStackTrace();
            MinecraftClient.getInstance().stop();
            return;
        }
    }

    private <Module extends AbstractModule> void register(@NotNull String name, @NotNull ModuleCreator<Module> moduleCreator) {
        Novoline.getInstance().getModuleManager().register(name, moduleCreator);
    }
}
