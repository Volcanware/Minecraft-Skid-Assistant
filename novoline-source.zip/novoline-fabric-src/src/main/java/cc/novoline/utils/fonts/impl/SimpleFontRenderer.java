package cc.novoline.utils.fonts.impl;

import cc.novoline.Novoline;
import cc.novoline.modules.misc.Streamer;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.fonts.api.FontRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

/**
 * Port of the 1.8.9 AWT glyph-atlas font renderer.
 * <p>
 * Atlases are built identically (one 512x512 image per style: plain, bold,
 * italic, bold-italic), uploaded as {@link NativeImageBackedTexture}s, and each
 * glyph is drawn as a textured GUI-quad submitted to the active
 * {@link net.minecraft.client.gui.DrawContext} via
 * {@link RenderUtils#guiTexturedQuad}.
 *
 * @author gast
 * @since 2017/07/14
 */
@SuppressWarnings("MagicNumber")
final class SimpleFontRenderer implements FontRenderer {

    private static final int[] COLOR_CODES = setupMinecraftColorCodes();
    private static final String COLORS = "0123456789abcdefklmnor";
    private static final char COLOR_PREFIX = '§';

    private static final short CHARS = 256;
    private static final float IMG_SIZE = 512;

    private final CharData[] charData = new CharData[CHARS];
    private final CharData[] boldChars = new CharData[CHARS];
    private final CharData[] italicChars = new CharData[CHARS];
    private final CharData[] boldItalicChars = new CharData[CHARS];

    private final Font awtFont;
    private final boolean antiAlias;
    private final boolean fractionalMetrics;

    private Identifier texturePlain;
    private Identifier textureBold;
    private Identifier textureItalic;
    private Identifier textureItalicBold;
    private int fontHeight = -1;
    private boolean texturesBuilt;

    //region instantiating
    private SimpleFontRenderer(Font awtFont, boolean antiAlias, boolean fractionalMetrics) {
        this.awtFont = awtFont;
        this.antiAlias = antiAlias;
        this.fractionalMetrics = fractionalMetrics;
    }

    static FontRenderer create(Font font, boolean antiAlias, boolean fractionalMetrics) {
        return new SimpleFontRenderer(font, antiAlias, fractionalMetrics);
    }

    public static FontRenderer create(Font font) {
        return create(font, true, true);
    }

    /** Build atlases + upload textures. Deferred until first draw — needs a live GPU device. */
    private void ensureTextures() {
        if (texturesBuilt) {
            return;
        }
        texturesBuilt = true;
        String base = "novolinefont_" + Integer.toHexString(System.identityHashCode(this));
        texturePlain = upload(base + "_plain", generateFontImage(awtFont, charData));
        textureBold = upload(base + "_bold", generateFontImage(awtFont.deriveFont(Font.BOLD), boldChars));
        textureItalic = upload(base + "_italic", generateFontImage(awtFont.deriveFont(Font.ITALIC), italicChars));
        textureItalicBold = upload(base + "_bolditalic", generateFontImage(awtFont.deriveFont(Font.BOLD | Font.ITALIC), boldItalicChars));
    }

    private Identifier upload(String name, BufferedImage image) {
        int w = image.getWidth(), h = image.getHeight();
        NativeImage nativeImage = new NativeImage(w, h, true);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                nativeImage.setColorArgb(x, y, image.getRGB(x, y));
            }
        }
        NativeImageBackedTexture texture = new NativeImageBackedTexture(() -> name, nativeImage);
        texture.upload();
        Identifier id = Identifier.of("novoline", name);
        MinecraftClient.getInstance().getTextureManager().registerTexture(id, texture);
        return id;
    }

    private BufferedImage generateFontImage(Font font, CharData[] chars) {
        final int imgSize = (int) IMG_SIZE;
        BufferedImage bufferedImage = new BufferedImage(imgSize, imgSize, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = (Graphics2D) bufferedImage.getGraphics();

        graphics.setFont(font);
        graphics.setColor(new Color(255, 255, 255, 0));
        graphics.fillRect(0, 0, imgSize, imgSize);
        graphics.setColor(Color.WHITE);

        graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        if (this.fractionalMetrics) {
            graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        } else {
            graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
        }

        FontMetrics fontMetrics = graphics.getFontMetrics();
        int charHeight = 0, positionX = 0, positionY = 1;

        for (int i = 0; i < chars.length; i++) {
            char ch = (char) i;
            CharData charData = new CharData();
            Rectangle2D dimensions = fontMetrics.getStringBounds(String.valueOf(ch), graphics);

            charData.width = dimensions.getBounds().width + 8;
            charData.height = dimensions.getBounds().height;

            if (positionX + charData.width >= imgSize) {
                positionX = 0;
                positionY += charHeight;
                charHeight = 0;
            }

            if (charData.height > charHeight) {
                charHeight = charData.height;
            }

            charData.storedX = positionX;
            charData.storedY = positionY;

            if (charData.height > fontHeight) {
                this.fontHeight = charData.height;
            }

            chars[i] = charData;

            graphics.drawString(String.valueOf(ch), positionX + 2, positionY + fontMetrics.getAscent());
            positionX += charData.width;
        }

        return bufferedImage;
    }
    //endregion

    @Override
    public float drawString(CharSequence text, double x, double y, int color, boolean dropShadow) {
        if (dropShadow) {
            float shadowWidth = drawStringInternal(text, x + 0.5, y + 0.5, color, true);
            return Math.max(shadowWidth, drawStringInternal(text, x, y, color, false));
        } else {
            return drawStringInternal(text, x, y, color, false);
        }
    }

    @SuppressWarnings("OverlyComplexMethod")
    private float drawStringInternal(CharSequence text, double x, double y, int color, boolean shadow) {
        x -= 1;

        if (text == null) return 0.0F;

        MinecraftClient mc = MinecraftClient.getInstance();
        Novoline novoline = Novoline.getInstance();

        if (mc.world != null) {
            if (novoline.getModuleManager().getModule(Streamer.class).isEnabled()) {
                Streamer streamer = novoline.getModuleManager().getModule(Streamer.class);

                for (String name : streamer.name_data) {
                    if (!name.isEmpty()) {
                        if (text.toString().contains(name)) {
                            if (name.equalsIgnoreCase(mc.player.getName().getString())) {
                                if (streamer.isChangeYourName().get()) {
                                    text = text.toString().replace(name, streamer.getYourName().get().replace("&", "§"));
                                }
                            } else if (streamer.isHideOthers().get()) {
                                text = text.toString().replace(name, "Player");
                            }
                        }
                    }
                }
            }
        }

        if (color == 0x20FFFFFF) color = 0xFFFFFF;
        if ((color & 0xFC000000) == 0) color |= 0xFF000000;

        if (shadow) {
            color = (color & 0xFCFCFC) >> 2 | color & 0xFF000000;
        }

        if (!RenderUtils.hasContext()) {
            return 0.0F;
        }
        ensureTextures();

        CharData[] charData = this.charData;
        int currentColor = color;

        x *= 2.0D;
        y = (y - 3.0D) * 2.0D;

        //region rendering — all quads are emitted in 2x space under a 0.5 scale
        Matrix3x2fStack matrices = RenderUtils.context().getMatrices();
        matrices.pushMatrix();
        matrices.scale(0.5F, 0.5F);

        boolean underline = false;
        boolean strikethrough = false;
        boolean italic = false;
        boolean bold = false;
        Identifier currentTexture = texturePlain;

        for (int i = 0, size = text.length(); i < size; i++) {
            char character = text.charAt(i);

            if (character == COLOR_PREFIX && i + 1 < size) {
                int colorIndex = COLORS.indexOf(text.charAt(i + 1));

                if (colorIndex < 16) {
                    bold = false;
                    italic = false;
                    underline = false;
                    strikethrough = false;
                    currentTexture = texturePlain;
                    charData = this.charData;

                    if (colorIndex < 0) colorIndex = 15;
                    if (shadow) colorIndex += 16;

                    int colorCode = COLOR_CODES[colorIndex];
                    currentColor = (color & 0xFF000000) | colorCode;
                } else if (colorIndex == 17) {
                    bold = true;
                    if (italic) {
                        currentTexture = textureItalicBold;
                        charData = boldItalicChars;
                    } else {
                        currentTexture = textureBold;
                        charData = boldChars;
                    }
                } else if (colorIndex == 18) {
                    strikethrough = true;
                } else if (colorIndex == 19) {
                    underline = true;
                } else if (colorIndex == 20) {
                    italic = true;
                    if (bold) {
                        currentTexture = textureItalicBold;
                        charData = boldItalicChars;
                    } else {
                        currentTexture = textureItalic;
                        charData = italicChars;
                    }
                } else if (colorIndex == 21) {
                    bold = false;
                    italic = false;
                    underline = false;
                    strikethrough = false;
                    currentColor = color;
                    currentTexture = texturePlain;
                    charData = this.charData;
                }

                //noinspection AssignmentToForLoopParameter
                i++;
            } else if (character < charData.length) {
                CharData data = charData[character];
                float u0 = data.storedX / IMG_SIZE;
                float v0 = data.storedY / IMG_SIZE;
                float u1 = (data.storedX + data.width) / IMG_SIZE;
                float v1 = (data.storedY + data.height) / IMG_SIZE;

                RenderUtils.guiTexturedQuad(currentTexture, RenderPipelines.GUI_TEXTURED,
                    (float) x, (float) y, (float) (x + data.width), (float) (y + data.height),
                    u0, v0, u1, v1, currentColor);

                if (strikethrough) {
                    RenderUtils.guiQuad((float) x, (float) (y + data.height / 2.0F),
                        (float) (x + data.width - 8.0D), (float) (y + data.height / 2.0F + 1.0F), currentColor);
                }

                if (underline) {
                    RenderUtils.guiQuad((float) x, (float) (y + data.height - 2.0D),
                        (float) (x + data.width - 8.0D), (float) (y + data.height - 1.0D), currentColor);
                }

                x += data.width - (character == ' ' ? 8 : 9);
            }
        }

        matrices.popMatrix();
        //endregion

        return (float) x / 2.0F;
    }

    @Override
    public String trimStringToWidth(CharSequence text, int width, boolean reverse) {
        StringBuilder builder = new StringBuilder();

        float f = 0.0F;
        int i = reverse ? text.length() - 1 : 0;
        int j = reverse ? -1 : 1;
        boolean flag = false;
        boolean flag1 = false;

        for (int k = i; k >= 0 && k < text.length() && f < width; k += j) {
            char c0 = text.charAt(k);
            float f1 = stringWidth(String.valueOf(c0));

            if (flag) {
                flag = false;

                if (c0 != 'l' && c0 != 'L') {
                    if (c0 == 'r' || c0 == 'R') {
                        flag1 = false;
                    }
                } else {
                    flag1 = true;
                }
            } else if (f1 < 0.0F) {
                flag = true;
            } else {
                f += f1;
                if (flag1) ++f;
            }

            if (f > width) break;

            if (reverse) {
                builder.insert(0, c0);
            } else {
                builder.append(c0);
            }
        }

        return builder.toString();
    }

    @Override
    public int stringWidth(CharSequence text) {
        if (text == null) return 0;

        // charData is populated lazily — measurement-only calls (e.g.
        // TabModule.getLongest) hit it before any draw call
        ensureMetrics();

        MinecraftClient mc = MinecraftClient.getInstance();
        Novoline novoline = Novoline.getInstance();

        if (mc.world != null) {
            if (novoline.getModuleManager().getModule(Streamer.class).isEnabled()) {
                Streamer streamer = novoline.getModuleManager().getModule(Streamer.class);

                for (String name : streamer.name_data) {
                    if (!name.isEmpty()) {
                        if (text.toString().contains(name)) {
                            if (name.equalsIgnoreCase(mc.player.getName().getString())) {
                                if (streamer.isChangeYourName().get()) {
                                    text = text.toString().replace(name, streamer.getYourName().get().replace("&", "§"));
                                }
                            } else if (streamer.isHideOthers().get()) {
                                text = text.toString().replace(name, "Player");
                            }
                        }
                    }
                }
            }
        }

        int width = 0;
        CharData[] currentData = charData;
        boolean bold = false;
        boolean italic = false;

        for (int i = 0, size = text.length(); i < size; i++) {
            char character = text.charAt(i);

            if (character == COLOR_PREFIX && i + 1 < size) {
                int colorIndex = COLORS.indexOf(text.charAt(i + 1));

                if (colorIndex < 16) { // color
                    bold = false;
                    italic = false;
                } else if (colorIndex == 17) { // bold
                    bold = true;
                    if (italic) currentData = boldItalicChars;
                    else currentData = boldChars;
                } else if (colorIndex == 20) { // italic
                    italic = true;
                    if (bold) currentData = boldItalicChars;
                    else currentData = italicChars;
                } else if (colorIndex == 21) { // reset
                    bold = false;
                    italic = false;
                    currentData = charData;
                }

                //noinspection AssignmentToForLoopParameter
                i++;
            } else if (character < currentData.length) {
                width += currentData[character].width - (character == ' ' ? 8 : 9);
            }
        }

        return width / 2;
    }

    @Override
    public float charWidth(char s) {
        ensureMetrics();
        return (charData[s].width - 8) / 2;
    }

    /** charData is populated when atlases are generated — do it without uploading. */
    private void ensureMetrics() {
        if (charData[0] == null) {
            generateFontImage(awtFont, charData);
            generateFontImage(awtFont.deriveFont(Font.BOLD), boldChars);
            generateFontImage(awtFont.deriveFont(Font.ITALIC), italicChars);
            generateFontImage(awtFont.deriveFont(Font.BOLD | Font.ITALIC), boldItalicChars);
        }
    }

    public CharData[] getCharData() {
        return charData;
    }

    //region shit
    private static int[] setupMinecraftColorCodes() {
        int[] colorCodes = new int[32];

        for (int i = 0; i < 32; i++) {
            int noClue = (i >> 3 & 0x1) * 85;
            int red = (i >> 2 & 0x1) * 170 + noClue;
            int green = (i >> 1 & 0x1) * 170 + noClue;
            int blue = (i & 0x1) * 170 + noClue;

            if (i == 6) {
                red += 85;
            }

            if (i >= 16) {
                red >>= 2; // divide by 4
                green >>= 2;
                blue >>= 2;
            }

            colorCodes[i] = (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
        }

        return colorCodes;
    }

    private static class CharData {

        private int width;
        private int height;
        private int storedX;
        private int storedY;

        private CharData() {
        }
    }
    //endregion

    //region lombok
    @Override
    public String getName() {
        return awtFont.getFamily();
    }

    @Override
    public int getHeight() {
        ensureMetrics();
        return (fontHeight - 8) / 2;
    }

    @Override
    public boolean isAntiAlias() {
        return antiAlias;
    }

    @Override
    public boolean isFractionalMetrics() {
        return fractionalMetrics;
    }
    //endregion
}
