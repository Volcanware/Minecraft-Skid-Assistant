package cc.novoline.utils;

/**
 * Duck interface added to {@link net.minecraft.client.input.Input} by
 * {@link cc.novoline.mixin.InputMixin} — restores the mutable
 * MovementInput API (setMoveStrafe/setMoveForward/setJump/setSneak)
 * that modules like GuiMove rely on.
 */
public interface NovolineInput {

    void novoline$setMoveStrafe(float strafe);

    void novoline$setMoveForward(float forward);

    void novoline$setJump(boolean jump);

    void novoline$setSneak(boolean sneak);

    float novoline$getMoveStrafe();

    float novoline$getMoveForward();
}
