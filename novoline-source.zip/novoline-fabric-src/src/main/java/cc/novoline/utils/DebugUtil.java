package cc.novoline.utils;

import cc.novoline.utils.messages.MessageFactory;
import cc.novoline.utils.messages.TextMessage;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.Arrays;

import static net.minecraft.util.Formatting.GRAY;
import static net.minecraft.util.Formatting.LIGHT_PURPLE;

public class DebugUtil {

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static void print(Object... debug) {
        if (isDev()) {
            String message = Arrays.toString(debug);
            mc.inGameHud.getChatHud().addMessage(Text.literal(message));
        }
    }

    public static void log(Object message) {
        String text = String.valueOf(message);
        mc.inGameHud.getChatHud().addMessage(Text.literal(text));
    }

    public static void log(boolean prefix, Object message) {
        // PORT: styled prefix appended to the literal text instead of flattening
        // getFormattedText() into a ChatComponentText — same rendered result.
        mc.inGameHud.getChatHud().addMessage(prefix().toText().append(" " + message));
    }

    public static void log(String prefix, Object message) {
        mc.inGameHud.getChatHud().addMessage(prefix(prefix).toText().append(" " + message));
    }


    public static TextMessage prefix(String text) {
        return MessageFactory.text(text, LIGHT_PURPLE).append(" » ", GRAY);
    }

    public static TextMessage prefix() {
        return MessageFactory.text("Novoline", LIGHT_PURPLE).append(" » ", GRAY);
    }

    private static boolean isDev() {
        return true;
    }
}
