package cc.novoline.utils;

import cc.novoline.Novoline;
import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.binds.KeyboardKeybind;
import cc.novoline.modules.configurations.holder.ModuleHolder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.input.Keyboard;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class PlayerUtils {

    private static int pressCount;

    public static void onBindInGui() {
        if (Keyboard.getEventKeyState()) {
            int k = Keyboard.getEventKey();

            for (ModuleHolder<?> holder : Novoline.getInstance().getModuleManager().getModuleManager().values()) {
                AbstractModule module = holder.getModule();

                if (module.getKeybind().get() instanceof KeyboardKeybind && module.getKeybind().get().getKey() == k) {
                    if (Keyboard.isKeyDown(k)) {
                        pressCount++;
                    }

                    if (pressCount == 1) {
                        module.toggle();
                    }
                }
            }
        } else {
            pressCount = 0;
        }
    }

    public static boolean inTeam(@NotNull Entity entity0, @NotNull Entity entity1) {
        if (entity0.isTeammate(entity1)) {
            return true;
        }
        String s = "§" + teamColor(entity0);
        return entity0.getDisplayName().getString().contains(s)
            && entity1.getDisplayName().getString().contains(s);
    }

    public static boolean inTeamWithMinecraftPlayer(@NotNull Entity entity) {
        return MinecraftClient.getInstance().player != null && inTeam(MinecraftClient.getInstance().player, entity);
    }

    public static @NotNull String teamColor(@NotNull Entity player) {
        if (player.getScoreboardTeam() != null && player.getScoreboardTeam().getColor() != null) {
            return player.getScoreboardTeam().getColor().getCode() + "";
        }
        Matcher matcher = Pattern.compile("§(.).*§r").matcher(player.getDisplayName().getString());
        return matcher.find() ? matcher.group(1) : "f";
    }

    /**
     * Detects a player's team color for ESP coloring. Tries, in order:
     * 1) vanilla scoreboard team color, 2) dyed leather armor color,
     * 3) a [X] name prefix (R=red, G=green, B=blue, Y=yellow, O=orange, P=purple,
     *    C=cyan, W=white, K=black, N=brown, L=lime, S=gray, D=dark gray).
     *
     * @return an ARGB int, or null when no team color could be detected
     */
    public static @Nullable Integer getTeamColor(@NotNull Entity entity) {
        if (entity.getScoreboardTeam() != null) {
            Formatting formatting = entity.getScoreboardTeam().getColor();
            if (formatting != null && formatting.getColorValue() != null) {
                return 0xFF000000 | formatting.getColorValue();
            }
        }

        if (entity instanceof LivingEntity living) {
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                if (!slot.isArmorSlot()) continue;
                net.minecraft.component.type.DyedColorComponent dyed =
                        living.getEquippedStack(slot).get(net.minecraft.component.DataComponentTypes.DYED_COLOR);
                if (dyed != null) {
                    return 0xFF000000 | (dyed.rgb() & 0xFFFFFF);
                }
            }
        }

        String name = entity.getName().getString();
        if (name.length() >= 3 && name.charAt(0) == '[' && name.charAt(2) == ']') {
            Integer rgb = PREFIX_COLORS.get(Character.toUpperCase(name.charAt(1)));
            if (rgb != null) {
                return 0xFF000000 | rgb;
            }
        }

        return null;
    }

    private static final java.util.Map<Character, Integer> PREFIX_COLORS = java.util.Map.ofEntries(
            java.util.Map.entry('R', 0xFF5555),
            java.util.Map.entry('G', 0x55FF55),
            java.util.Map.entry('B', 0x5555FF),
            java.util.Map.entry('Y', 0xFFFF55),
            java.util.Map.entry('O', 0xFFAA00),
            java.util.Map.entry('P', 0xFF55FF),
            java.util.Map.entry('C', 0x55FFFF),
            java.util.Map.entry('W', 0xFFFFFF),
            java.util.Map.entry('K', 0x555555),
            java.util.Map.entry('N', 0xAA5500),
            java.util.Map.entry('L', 0x80FF00),
            java.util.Map.entry('S', 0xAAAAAA),
            java.util.Map.entry('D', 0x555555)
    );

    /**
     * Distance to a target that follows the position interpolator for remote
     * entities: their raw {@code pos} can lag the lerped packet position under
     * tick/network stalls while the renderer already shows the fresh position,
     * so plain {@code distanceTo} starves reach checks. Falls back to the raw
     * position when the entity is not interpolating (local player included).
     */
    public static double lerpDistanceTo(Entity from, Entity to) {
        net.minecraft.entity.PositionInterpolator interp = to.getInterpolator();
        net.minecraft.util.math.Vec3d p =
                interp != null && interp.isInterpolating() ? interp.getLerpedPos() : to.getEntityPos();
        return from.getEntityPos().distanceTo(p);
    }

    @Contract(value = "-> fail", pure = true)
    private PlayerUtils() {
        throw new java.lang.UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}
