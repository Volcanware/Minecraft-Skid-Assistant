package cc.novoline.utils.messages;

import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;

import java.util.Iterator;
import java.util.Spliterator;
import java.util.Spliterators;

final class EmptyMessage extends Message {

    private static EmptyMessage INSTANCE;

    static EmptyMessage get() {
        if (INSTANCE == null) INSTANCE = new EmptyMessage();
        return INSTANCE;
    }

    private EmptyMessage() {
        super();
    }

    @Override
    public TextMessage appendSibling(Text component) {
        throw new UnsupportedOperationException();
    }

    @Override
    public TextMessage appendText(String text) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void setChatStyle(net.minecraft.text.Style style) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Spliterator<TextMessage> spliterator() {
        return Spliterators.emptySpliterator();
    }

    @Override
    public @NotNull Iterator<TextMessage> iterator() {
        return new Iterator<TextMessage>() {
            @Override public boolean hasNext() { return false; }
            @Override public TextMessage next() { throw new java.util.NoSuchElementException(); }
        };
    }

    @Override
    public @NotNull String toString() {
        return "Message{}";
    }
}
