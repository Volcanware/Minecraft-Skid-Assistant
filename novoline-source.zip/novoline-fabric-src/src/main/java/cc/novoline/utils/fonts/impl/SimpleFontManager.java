package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.SneakyThrowing;
import cc.novoline.utils.fonts.api.FontFamily;
import cc.novoline.utils.fonts.api.FontManager;
import cc.novoline.utils.fonts.api.FontType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

import java.awt.FontFormatException;
import java.io.IOException;
import java.io.InputStream;
import java.util.EnumMap;
import java.util.Optional;

/**
 * @author Artyom Popov
 * @since June 30, 2020
 */
public final class SimpleFontManager implements FontManager {

    //region instantiating
    private SimpleFontManager() {}

    public static FontManager create() {
        return new SimpleFontManager();
    }
    //endregion

    private static final String FONT_DIRECTORY = "novoline/fonts/";
    private final FontRegistry fonts = new FontRegistry();

    @Override
    public FontFamily fontFamily(FontType fontType) {
        return fonts.fontFamily(fontType);
    }

    private static final class FontRegistry extends EnumMap<FontType, FontFamily> {

        private FontRegistry() { super(FontType.class); }

        private FontFamily fontFamily(FontType fontType) {
            return computeIfAbsent(fontType, ignored -> {
                try {
                    return SimpleFontFamily.create(fontType, readFontFromResources(fontType));
                } catch (IOException e) {
                    throw SneakyThrowing.sneakyThrow(e);
                }
            });
        }

        //region reading font
        private static java.awt.Font readFontFromResources(FontType fontType) throws IOException {
            ResourceManager resourceManager = MinecraftClient.getInstance().getResourceManager();
            Identifier location = Identifier.of("novoline", "fonts/" + fontType.fileName());
            Optional<Resource> resource = resourceManager.getResource(location);

            if (resource.isEmpty()) {
                throw new IOException("Couldn't find resource: " + location);
            }

            try (InputStream resourceInputStream = resource.get().getInputStream()) {
                return readFont(resourceInputStream);
            }
        }

        private static java.awt.Font readFont(InputStream resource) {
            java.awt.Font font;

            try {
                font = java.awt.Font.createFont(java.awt.Font.TRUETYPE_FONT, resource);
            } catch (FontFormatException e) {
                throw new RuntimeException("Resource does not contain the required font tables for the specified format", e);
            } catch (IOException e) {
                throw new RuntimeException("Couldn't completely read font resource", e);
            }

            return font;
        }
        //endregion
    }
}
