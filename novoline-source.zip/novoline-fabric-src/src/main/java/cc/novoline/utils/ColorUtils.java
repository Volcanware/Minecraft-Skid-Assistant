package cc.novoline.utils;

import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.NotNull;

import java.awt.*;

public final class ColorUtils {

    private ColorUtils() {
        throw new java.lang.UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static int getColor(@NotNull final Color color) {
        return getColor(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    public static int getColor(final int brightness) {
        return getColor(brightness, brightness, brightness, 255);
    }

    public static int getColor(final int brightness, final int alpha) {
        return getColor(brightness, brightness, brightness, alpha);
    }

    public static int getColor(final int red, final int green, final int blue) {
        return getColor(red, green, blue, 255);
    }

    public static int getColor(int red, int green, int blue, int alpha) {
        int color = MathHelper.clamp(alpha, 0, 255) << 24;
        color |= MathHelper.clamp(red, 0, 255) << 16;
        color |= MathHelper.clamp(green, 0, 255) << 8;
        color |= MathHelper.clamp(blue, 0, 255);

        return color;
    }

}


