package cc.novoline.utils.thealtening.service;

import com.mojang.authlib.Environment;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilEnvironment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.ApiServices;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class ServiceSwitcher {

    private static final Logger LOGGER = LogManager.getLogger();

    // PORT: authlib 7.x has no static ROUTE_* fields — the routes are derived
    // per-service from an Environment. The modern equivalent of patching them
    // is swapping MinecraftClient.apiServices (private final) for services
    // built against a custom Environment via the accessor mixin.
    public ServiceSwitcher() {
    }

    public AlteningServiceType switchToService(AlteningServiceType service) {
        try {
            final MinecraftClient mc = MinecraftClient.getInstance();
            final Environment prod = YggdrasilEnvironment.PROD.getEnvironment();

            final String authServer = service.getAuthServer();
            final String sessionServer = service.getSessionServer();
            // authlib 7.x authenticates via OAuth device-code against the
            // services/profiles hosts — there is no password endpoint to
            // redirect, so only the session host is switched (as before);
            // services/profiles stay on production Mojang.
            final Environment environment = service == AlteningServiceType.MOJANG
                ? prod
                : new Environment(sessionServer, prod.servicesHost(), prod.profilesHost(), service.name().toLowerCase());

            final YggdrasilAuthenticationService authenticationService =
                new YggdrasilAuthenticationService(mc.getNetworkProxy(), environment);
            final ApiServices apiServices = ApiServices.create(authenticationService, mc.runDirectory);

            ((cc.novoline.mixin.MinecraftClientAccessor) mc).novoline$setApiServices(apiServices);
        } catch (Exception e) {
            LOGGER.warn(e);
            return AlteningServiceType.MOJANG;
        }

        return service;
    }

}
