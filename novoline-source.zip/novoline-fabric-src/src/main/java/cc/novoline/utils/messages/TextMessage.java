package cc.novoline.utils.messages;

import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;

/**
 * Port of Novoline's TextMessage — a StringBuilder root plus sibling components,
 * mirroring the 1.8.9 IChatComponent API on top of modern Text.
 */
public class TextMessage implements Iterable<TextMessage> {

    private static final Style RESET_STYLE = Style.EMPTY.withFormatting(Formatting.RESET);

    /* fields */
    private final StringBuilder message;
    protected final List<Text> siblings = new ArrayList<>();
    private Style style;

    /* constructors */
    protected TextMessage(@Nullable String message, @Nullable Formatting color) {
        this.message = message != null ? new StringBuilder(message) : new StringBuilder();
        this.style = color != null ? Style.EMPTY.withFormatting(color) : RESET_STYLE;
    }

    protected TextMessage(@Nullable String message) {
        this(message, null);
    }

    public static @NotNull TextMessage of(@Nullable String text) {
        return new TextMessage(text);
    }

    public static @NotNull TextMessage of(@Nullable String text, @Nullable Formatting color) {
        return new TextMessage(text, color);
    }

    /* methods */
    /** Build the underlying MutableText for display. */
    public MutableText toText() {
        MutableText root = Text.literal(message.toString());
        if (style != null) root.setStyle(style);
        for (Text sibling : siblings) root.append(sibling);
        return root;
    }

    public TextMessage prefix(@Nullable TextMessage prefix) {
        if (prefix != null) {
            TextMessage copy = prefix.createCopy();
            copy.appendSibling(this.toText());
            return copy;
        }
        return this;
    }

    public TextMessage suffix(@Nullable Text suffix) {
        if (suffix != null) siblings.add(suffix);
        return this;
    }

    public TextMessage newLine() {
        append("\n");
        return this;
    }

    public TextMessage append(@Nullable String s, @Nullable Formatting color) {
        appendSibling(of(s, color).toText());
        return this;
    }

    public TextMessage appendText(@Nullable String s) {
        append(s, Formatting.RESET);
        return this;
    }

    public TextMessage append(@Nullable String s) {
        return appendText(s);
    }

    public TextMessage append(Text component) {
        appendSibling(component);
        return this;
    }

    public TextMessage appendSibling(Text component) {
        siblings.add(component);
        return this;
    }

    public TextMessage createCopy() {
        TextMessage msg = of(this.message.toString());
        msg.setChatStyle(this.style);
        for (Text sibling : siblings) msg.appendSibling(sibling.copy());
        return msg;
    }

    public void setChatStyle(Style style) {
        this.style = style;
    }

    public void setColor(@Nullable Formatting color) {
        this.style = color != null ? Style.EMPTY.withFormatting(color) : null;
    }

    public Style getChatStyle() {
        return style;
    }

    public List<Text> getSiblings() {
        return siblings;
    }

    public String getUnformattedTextForChat() {
        return message.toString();
    }

    @NotNull
    @Override
    public Iterator<TextMessage> iterator() {
        List<TextMessage> all = new ArrayList<>();
        all.add(this);
        for (Text s : siblings) {
            if (s instanceof TextMessage tm) all.add(tm);
        }
        return all.iterator();
    }

    @Override
    public Spliterator<TextMessage> spliterator() {
        List<TextMessage> all = new ArrayList<>();
        for (TextMessage m : this) all.add(m);
        return all.spliterator();
    }
}
