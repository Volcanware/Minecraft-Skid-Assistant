package cc.novoline.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;

import java.awt.Dimension;
import java.awt.Toolkit;

/**
 * Minecraft 1.21 runs with {@code java.awt.headless=true}, so
 * {@code Toolkit.getScreenSize()} throws HeadlessException. Returns the game
 * window's framebuffer size instead, falling back to AWT then to 1920x1080.
 */
public final class AwtCompat {

    private static final Dimension FALLBACK = new Dimension(1920, 1080);

    private AwtCompat() {
    }

    public static Dimension screenSize() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null) {
            Window window = mc.getWindow();
            if (window != null && window.getFramebufferWidth() > 0) {
                return new Dimension(window.getFramebufferWidth(), window.getFramebufferHeight());
            }
        }
        try {
            return Toolkit.getDefaultToolkit().getScreenSize();
        } catch (Throwable t) {
            return FALLBACK;
        }
    }
}
