package cc.novoline.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;

public final class ChatUtils {

    /* fields */
    private final MutableText message;

    /* constructors */
    private ChatUtils(final MutableText message) {
        this.message = message;
    }

    /* methods */
    @NotNull
    public static String addFormat(@NotNull String message, String regex) {
        return message.replaceAll("(?i)" + regex + "([0-9a-fklmnor])", "§$1");
    }

    public void displayClientSided() {
        if (MinecraftClient.getInstance().player != null) {
            MinecraftClient.getInstance().player.sendMessage(this.message, false);
        }
    }

    //region Lombok
    private Text getChatComponent() {
        return this.message;
    }
    //endregion

    public static class ChatMessageBuilder {

        private static final Formatting defaultMessageColor;

        static {
            defaultMessageColor = Formatting.WHITE;
        }

        private final MutableText theMessage;
        private boolean useDefaultMessageColor;
        private Style workingStyle;
        private MutableText workerMessage;

        public ChatMessageBuilder(final boolean prependDefaultPrefix, final boolean useDefaultMessageColor) {
            this.theMessage = Text.empty();
            this.useDefaultMessageColor = false;
            this.workingStyle = Style.EMPTY;
            this.workerMessage = Text.empty();
            if (prependDefaultPrefix)
                this.theMessage.append(new ChatMessageBuilder(false, false).appendText(Formatting.AQUA + "Stella ").setColor(Formatting.RED).build().getChatComponent());
            this.useDefaultMessageColor = useDefaultMessageColor;
        }

        public ChatMessageBuilder() {
            this.theMessage = Text.empty();
            this.useDefaultMessageColor = false;
            this.workingStyle = Style.EMPTY;
            this.workerMessage = Text.empty();
        }

        public ChatMessageBuilder appendText(final String text) {
            this.appendSibling();
            this.workerMessage = Text.literal(text);
            this.workingStyle = Style.EMPTY;
            if (this.useDefaultMessageColor) {
                this.setColor(ChatMessageBuilder.defaultMessageColor);
            }
            return this;
        }

        public ChatMessageBuilder setColor(final Formatting color) {
            this.workingStyle = this.workingStyle.withColor(color);
            return this;
        }

        public ChatMessageBuilder bold() {
            this.workingStyle = this.workingStyle.withBold(true);
            return this;
        }

        public ChatMessageBuilder italic() {
            this.workingStyle = this.workingStyle.withItalic(true);
            return this;
        }

        public ChatMessageBuilder strikethrough() {
            this.workingStyle = this.workingStyle.withStrikethrough(true);
            return this;
        }

        public ChatMessageBuilder underline() {
            this.workingStyle = this.workingStyle.withUnderline(true);
            return this;
        }

        public ChatUtils build() {
            this.appendSibling();
            return new ChatUtils(this.theMessage);
        }

        private void appendSibling() {
            this.theMessage.append(this.workerMessage.copy().setStyle(this.workingStyle));
        }

    }

}
