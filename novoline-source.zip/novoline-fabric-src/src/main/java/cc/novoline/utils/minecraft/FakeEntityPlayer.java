package cc.novoline.utils.minecraft;

import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class FakeEntityPlayer extends OtherClientPlayerEntity {

	private static final Identifier TEXTURE_STEVE = Identifier.ofVanilla("textures/entity/player/wide/steve.png");
	private static final Identifier TEXTURE_ALEX = Identifier.ofVanilla("textures/entity/player/slim/alex.png");

	private static final List<ItemStack> ITEM_STACKS = Arrays.asList( // @off
            new ItemStack(Items.BOW),
            new ItemStack(Items.IRON_SWORD),
            new ItemStack(Items.WOODEN_SWORD),
            new ItemStack(Items.STONE_PICKAXE),
            new ItemStack(Items.DIAMOND_PICKAXE),
            new ItemStack(Items.IRON_INGOT),
            new ItemStack(Blocks.COBBLESTONE),
            new ItemStack(Blocks.POPPY)
    ); // @on

	/* fields */
	private final Identifier locationSkin;
	private String skinType;

	/* constructors */
	public FakeEntityPlayer(@NotNull GameProfile profile, @Nullable Identifier locationSkin) {
		super(new FakeWorld(), profile);

		try {
            profile.properties().asMap().get("textures").stream().findFirst().map(property -> {
				return JsonParser.parseString(new String(Base64.getDecoder().decode(property.value()))).getAsJsonObject()
						.getAsJsonObject("textures").getAsJsonObject("SKIN");
			}).ifPresent(jsonObject -> {
				this.skinType = jsonObject.has("metadata") ? jsonObject.getAsJsonObject("metadata").get("model").getAsString() : "default";
			});
		} catch(Throwable ignored) {
		} finally {
			if(skinType == null) this.skinType = "slim";
		}

		if(locationSkin != null) {
			this.locationSkin = locationSkin;
		} else {
			this.locationSkin = skinType.equals("default") ? TEXTURE_STEVE : TEXTURE_ALEX;
		}

		getInventory().setStack(0, ITEM_STACKS.get(ThreadLocalRandom.current().nextInt(ITEM_STACKS.size())));
	}

	/* methods */
	// region Lombok
	// PORT: EntityOtherPlayerMP.getSkinType()/getLocationSkin() -> getSkin() returning a
	// SkinTextures record; getSkinType()/getLocationSkin() kept as plain accessors for
	// callers that still want the raw values.
	@Override
	public SkinTextures getSkin() {
		return SkinTextures.create(new AssetInfo.TextureAssetInfo(locationSkin), null, null,
				PlayerSkinType.byModelMetadata(skinType));
	}

	public String getSkinType() {
		return skinType;
	}

	@Nullable
	public Identifier getLocationSkin() {
		return locationSkin;
	}
	//endregion

}
