package cc.novoline.utils.messages;

import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;
import java.util.Spliterators;

/**
 * Port of Novoline's Message — wraps a MutableText root + sibling list.
 */
public class Message extends TextMessage {

    protected Message() {
        super("");
    }

    @Override
    public String getUnformattedTextForChat() {
        return null;
    }
}
