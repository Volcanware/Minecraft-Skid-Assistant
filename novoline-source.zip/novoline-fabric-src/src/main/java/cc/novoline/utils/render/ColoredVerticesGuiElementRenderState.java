package cc.novoline.utils.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2f;

/**
 * GUI render state for arbitrary colored geometry (lines, circles, gradient
 * rects) — replaces GL11 immediate mode used by the 1.8.9 renderer.
 */
public record ColoredVerticesGuiElementRenderState(
    RenderPipeline pipeline,
    TextureSetup textureSetup,
    Matrix3x2f pose,
    float[] vertices,
    int[] colors,
    @Nullable ScreenRect scissorArea,
    @Nullable ScreenRect bounds
) implements SimpleGuiElementRenderState {

    public ColoredVerticesGuiElementRenderState(
        RenderPipeline pipeline,
        Matrix3x2f pose,
        float[] vertices,
        int[] colors,
        @Nullable ScreenRect scissorArea,
        @Nullable ScreenRect bounds
    ) {
        this(pipeline, TextureSetup.empty(), pose, vertices, colors, scissorArea, bounds);
    }

    /**
     * @param vertices flat x,y pairs (4 per quad / 3 per triangle)
     * @param colors   one ARGB color per vertex
     */
    public ColoredVerticesGuiElementRenderState(
        RenderPipeline pipeline,
        Matrix3x2f pose,
        float[] vertices,
        int[] colors,
        int x1, int y1, int x2, int y2,
        @Nullable ScreenRect scissorArea
    ) {
        this(pipeline, TextureSetup.empty(), pose, vertices, colors, scissorArea,
            createBounds(x1, y1, x2, y2, pose, scissorArea));
    }

    @Override
    public void setupVertices(VertexConsumer consumer) {
        for (int i = 0; i < colors.length; i++) {
            consumer.vertex(this.pose(), this.vertices[i * 2], this.vertices[i * 2 + 1]).color(this.colors[i]);
        }
    }

    @Nullable
    private static ScreenRect createBounds(int x1, int y1, int x2, int y2, Matrix3x2f pose, @Nullable ScreenRect scissorArea) {
        ScreenRect screenRect = new ScreenRect(x1, y1, x2 - x1, y2 - y1).transformEachVertex(pose);
        return scissorArea != null ? scissorArea.intersection(screenRect) : screenRect;
    }
}
