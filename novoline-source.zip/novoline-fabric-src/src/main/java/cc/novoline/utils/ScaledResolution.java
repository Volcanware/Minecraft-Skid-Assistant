package cc.novoline.utils;

import cc.novoline.gui.screen.alt.repository.AltRepositoryGUI;
import cc.novoline.gui.screen.click.DiscordGUI;
import cc.novoline.gui.screen.login.GuiLogin;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

/**
 * Port of the Novoline-patched ScaledResolution. The client forces scale
 * factor 2 while the alt repository / discord / login screens are open, and
 * HUD code asks for the "static" dimensions derived from the user's guiScale
 * option instead of the effective screen scale.
 */
public class ScaledResolution {

    private final double scaledWidthD;
    private final double scaledHeightD;
    private int scaledWidth;
    private int scaledHeight;
    private int scaleFactor;

    public ScaledResolution(MinecraftClient mc) {
        this.scaledWidth = mc.getWindow().getFramebufferWidth();
        this.scaledHeight = mc.getWindow().getFramebufferHeight();
        this.scaleFactor = 1;
        boolean unicode = mc.forcesUnicodeFont();
        int i;
        if (mc.currentScreen instanceof AltRepositoryGUI || mc.currentScreen instanceof DiscordGUI || mc.currentScreen instanceof GuiLogin) {
            i = 2;
        } else {
            i = mc.options.getGuiScale().getValue();
        }

        if (i == 0) {
            i = 1000;
        }

        while (this.scaleFactor < i && this.scaledWidth / (this.scaleFactor + 1) >= 320 && this.scaledHeight / (this.scaleFactor + 1) >= 240) {
            ++this.scaleFactor;
        }

        if (unicode && this.scaleFactor % 2 != 0 && this.scaleFactor != 1) {
            --this.scaleFactor;
        }

        this.scaledWidthD = (double) this.scaledWidth / this.scaleFactor;
        this.scaledHeightD = (double) this.scaledHeight / this.scaleFactor;
        this.scaledWidth = MathHelper.ceil(this.scaledWidthD);
        this.scaledHeight = MathHelper.ceil(this.scaledHeightD);
    }

    public int getScaledWidth() {
        return this.scaledWidth;
    }

    public int getScaledHeight() {
        return this.scaledHeight;
    }

    public double getScaledWidth_double() {
        return this.scaledWidthD;
    }

    public double getScaledHeight_double() {
        return this.scaledHeightD;
    }

    public int getScaleFactor() {
        return this.scaleFactor;
    }

    public int getScaledWidthStatic(MinecraftClient minecraft) {
        if (minecraft.currentScreen instanceof DiscordGUI) {
            return getScaledWidth();
        }

        switch (MinecraftClient.getInstance().options.getGuiScale().getValue()) {
            case 0:
                return getScaledWidth() * 2;
            case 1:
                return (int) (getScaledWidth() * 0.5);
            case 3:
                return (int) (getScaledWidth() * 1.5);
            default:
                return getScaledWidth();
        }
    }

    public int getScaledHeightStatic(MinecraftClient minecraft) {
        if (minecraft.currentScreen instanceof DiscordGUI) {
            return getScaledHeight();
        }

        switch (MinecraftClient.getInstance().options.getGuiScale().getValue()) {
            case 0:
                return getScaledHeight() * 2;
            case 1:
                return (int) (getScaledHeight() * 0.5);
            case 3:
                return (int) (getScaledHeight() * 1.5);
            default:
                return getScaledHeight();
        }
    }
}
