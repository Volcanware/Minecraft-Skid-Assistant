package cc.novoline.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

public final class RotationUtil {

    private static float[] serverAngles = new float[2];
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private RotationUtil() {
        throw new java.lang.UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Vec3d getVectorForRotation(float pitch, float yaw) {
        float f = MathHelper.cos(Math.toRadians(-yaw) - (float) Math.PI);
        float f1 = MathHelper.sin(Math.toRadians(-yaw) - (float) Math.PI);
        float f2 = -MathHelper.cos(Math.toRadians(-pitch));
        float f3 = MathHelper.sin(Math.toRadians(-pitch));
        return new Vec3d(f1 * f2, f3, f * f2);
    }

    public static Vec3d getPositionEyes(float partialTicks) {
        return new Vec3d(mc.player.getX(), mc.player.getY() + mc.player.getStandingEyeHeight(), mc.player.getZ());
    }

    public static float getYawChange(double posX, double posZ) {
        final ClientPlayerEntity player = mc.player;
        final double deltaX = posX - player.getX(),
                deltaZ = posZ - player.getZ();

        final double yawToEntity;
        final double v1 = Math.toDegrees(Math.atan(deltaZ / deltaX));

        if (deltaZ < 0.0D && deltaX < 0.0D) {
            yawToEntity = 90.0D + v1;
        } else if (deltaZ < 0.0D && deltaX > 0.0D) {
            yawToEntity = -90.0D + v1;
        } else {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }

        return MathHelper.wrapDegrees(-(player.getYaw() - (float) yawToEntity));
    }

    public static float[] getRotations(double posX, double posY, double posZ) {
        ClientPlayerEntity player = mc.player;
        double x = posX - player.getX();
        double y = posY - (player.getY() + player.getStandingEyeHeight());
        double z = posZ - player.getZ();
        double dist = Math.sqrt(x * x + z * z);
        float yaw = (float) (Math.atan2(z, x) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) -(Math.atan2(y, dist) * 180.0D / Math.PI);
        return new float[]{yaw, pitch};
    }

    public static float[] getRotationsEntity(LivingEntity entity) {
        return isPlayerMoving()
            ? getRotations(entity.getX() + ThreadLocalRandom.current().nextDouble(-0.03D, 0.03D),
                           entity.getY() + entity.getStandingEyeHeight() - 0.4D + ThreadLocalRandom.current().nextDouble(-0.07D, 0.07D),
                           entity.getZ() + ThreadLocalRandom.current().nextDouble(-0.03D, 0.03D))
            : getRotations(entity.getX(), entity.getY() + entity.getStandingEyeHeight() - 0.4D, entity.getZ());
    }

    public static boolean isPlayerMoving() {
        ClientPlayerEntity player = mc.player;
        return player.forwardSpeed != 0.0F || player.sidewaysSpeed != 0.0F;
    }

    public static float getYawToPoint(double posX, double posZ) {
        MinecraftClient instance = mc;
        float partialTicks = instance.getRenderTickCounter().getTickProgress(true);
        double xDiff = posX - (instance.player.lastX + (instance.player.getX() - instance.player.lastX) * partialTicks),
               zDiff = posZ - (instance.player.lastZ + (instance.player.getZ() - instance.player.lastZ) * partialTicks),
               dist = Math.sqrt(xDiff * xDiff + zDiff * zDiff);
        return (float) (Math.atan2(zDiff, xDiff) * 180.0D / Math.PI) - 90.0F;
    }

    public static float getPitchChange(Entity entity, double posY) {
        final double deltaX = entity.getX() - mc.player.getX();
        final double deltaZ = entity.getZ() - mc.player.getZ();
        final double deltaY = posY - 2.2D + entity.getStandingEyeHeight() - mc.player.getY();
        final double distanceXZ = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        final double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));

        return -MathHelper.wrapDegrees(mc.player.getPitch() - (float) pitchToEntity) - 2.5F;
    }

    public static float[] getRotationFromPosition(double x, double z, double y) {
        final double xDiff = x - mc.player.getX(),
                     zDiff = z - mc.player.getZ(),
                     yDiff = y - mc.player.getY() - 1.2D,
                     dist = Math.sqrt(xDiff * xDiff + zDiff * zDiff);
        final float yaw = (float) (Math.atan2(zDiff, xDiff) * 180.0D / Math.PI) - 90.0F,
                    pitch = (float) -(Math.atan2(yDiff, dist) * 180.0D / Math.PI);

        return new float[]{yaw, pitch};
    }

    public static float[] aimAtLocation(double positionX, double positionY, double positionZ) {
        final double x = positionX - mc.player.getX(),
                     y = positionY - mc.player.getY(),
                     z = positionZ - mc.player.getZ(),
                     distance = Math.sqrt(x * x + z * z);

        return new float[]{(float) (Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f,
                           (float) -(Math.atan2(y, distance) * 180.0 / Math.PI)};
    }

    public static float[] getAngles(LivingEntity entity) {
        if (entity == null) return null;
        final ClientPlayerEntity player = mc.player;

        final double diffX = entity.getX() - player.getX(),
                     diffY = entity.getY() + entity.getStandingEyeHeight() * 0.9 - (player.getY() + player.getStandingEyeHeight()),
                     diffZ = entity.getZ() - player.getZ(),
                     dist = Math.sqrt(diffX * diffX + diffZ * diffZ);

        final float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F,
                    pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);

        return new float[]{player.getYaw() + MathHelper.wrapDegrees(yaw - player.getYaw()),
                           player.getPitch() + MathHelper.wrapDegrees(pitch - player.getPitch())};
    }

    public static float[] getAngles(BlockPos pos) {
        double posX = pos.getX(), posY = pos.getY(), posZ = pos.getZ();
        final ClientPlayerEntity player = mc.player;

        final double diffX = posX - player.getX(),
                     diffY = posY - (player.getY() + player.getStandingEyeHeight()),
                     diffZ = posZ - player.getZ(),
                     dist = Math.sqrt(diffX * diffX + diffZ * diffZ);

        final float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F,
                    pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);

        return new float[]{player.getYaw() + MathHelper.wrapDegrees(yaw - player.getYaw()),
                           player.getPitch() + MathHelper.wrapDegrees(pitch - player.getPitch())};
    }

    public static float[] getAngles(Vec3d vector) {
        double posX = vector.getX(), posY = vector.getY(), posZ = vector.getZ();
        final ClientPlayerEntity player = mc.player;

        final double diffX = posX - player.getX(),
                     diffY = posY - (player.getY() + player.getStandingEyeHeight()),
                     diffZ = posZ - player.getZ(),
                     dist = Math.sqrt(diffX * diffX + diffZ * diffZ);

        final float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F,
                    pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);

        return new float[]{player.getYaw() + MathHelper.wrapDegrees(yaw - player.getYaw()),
                           player.getPitch() + MathHelper.wrapDegrees(pitch - player.getPitch())};
    }

    public static float getNewAngle(float angle) {
        angle %= 360.0F;

        if (angle >= 180.0F) {
            angle -= 360.0F;
        }

        if (angle < -180.0F) {
            angle += 360.0F;
        }

        return angle;
    }

    public static float getDistanceBetweenAngles(float angle1, float angle2) {
        final float angle = Math.abs(angle1 - angle2) % 360.0F;
        return angle > 180.0F ? 360.0F - angle : angle;
    }

    public static double[] getDistance(double x, double z, double y) {
        final double distance = Math.sqrt(x * x + z * z),
                     yaw = Math.atan2(z, x) * 180.0D / Math.PI - 90.0F,
                     pitch = -(Math.atan2(y, distance) * 180.0D / Math.PI);

        return new double[]{mc.player.getYaw() + MathHelper.wrapDegrees((float) (yaw - mc.player.getYaw())),
                            mc.player.getPitch() + MathHelper.wrapDegrees((float) (pitch - mc.player.getPitch()))};
    }
}
