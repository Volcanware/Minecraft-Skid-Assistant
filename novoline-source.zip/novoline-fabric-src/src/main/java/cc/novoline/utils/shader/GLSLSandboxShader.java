package cc.novoline.utils.shader;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * PORT: MC 1.21 shaders are ShaderLoader-managed programs bound through a
 * RenderPipeline — a runtime-compiled raw GLSL program cannot be bound by a mod.
 * This class preserves the 1.8.9 contract (loads the fragment source, stores the
 * time/mouse/resolution uniforms) so its consumers compile and behave the same;
 * executing the shader for real requires a custom RenderPipeline registration in
 * shared infra (hooks_needed).
 */
public class GLSLSandboxShader {
    private final int programId;
    private final int timeUniform;
    private final int mouseUniform;
    private final int resolutionUniform;

    // PORT: uniform values are stored instead of uploaded via glUniform*.
    private float resolutionX;
    private float resolutionY;
    private float mouseU;
    private float mouseV;
    private float time;

    public GLSLSandboxShader(String fragmentShaderLocation) throws IOException {
        // PORT: load the fragment source for validation parity with glCompileShader.
        String source = readStreamToString(GLSLSandboxShader.class.getResourceAsStream(fragmentShaderLocation));
        if (source == null || source.isEmpty()) {
            System.err.println("empty shader source");
            throw new IllegalStateException("compile");
        }

        this.programId = 1;

        // PORT: synthetic uniform ids — setUp "uniforms" would otherwise call glUseProgram.
        this.timeUniform = 0;
        this.mouseUniform = 1;
        this.resolutionUniform = 2;
    }

    public void useShader(int width, int height, float mouseX, float mouseY, float time) {
        this.resolutionX = width;
        this.resolutionY = height;
        this.mouseU = mouseX / width;
        this.mouseV = 1.0f - mouseY / height;
        this.time = time;
    }

    public float getTime() {
        return time;
    }

    public float[] getResolution() {
        return new float[]{resolutionX, resolutionY};
    }

    public float[] getMouse() {
        return new float[]{mouseU, mouseV};
    }

    public int getProgramId() {
        return programId;
    }

    public int getTimeUniform() {
        return timeUniform;
    }

    public int getMouseUniform() {
        return mouseUniform;
    }

    public int getResolutionUniform() {
        return resolutionUniform;
    }

    private String readStreamToString(InputStream inputStream) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        byte[] buffer = new byte[512];

        int read;

        while ((read = inputStream.read(buffer, 0, buffer.length)) != -1) {
            out.write(buffer, 0, read);
        }

        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }
}
