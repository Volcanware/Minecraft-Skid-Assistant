package cc.novoline.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.awt.*;

import static cc.novoline.utils.RenderUtils.context;
import static cc.novoline.utils.RenderUtils.hasContext;

/**
 * @author Janrupf
 */
public class OpenGLUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static int lastDisplayWidth;
    private static int lastDisplayHeight;
    private static final Object MUTEX = new Object();

    // PORT: the vanilla "minecraft:blur" post effect (assets/minecraft/post_effect/blur.json)
    // replaces the ShaderGroup+Framebuffer duo used in 1.8.9.
    private static final Identifier BLUR_ID = Identifier.ofVanilla("blur");
    private static PostEffectProcessor blurShader;

    public static void bindShader() {
        if (mc.options.getGuiScale().getValue() != 2) {
            return;
        }
        final int displayWidth = mc.getWindow().getFramebufferWidth();
        final int displayHeight = mc.getWindow().getFramebufferHeight();
        synchronized (MUTEX) {
            if (blurShader == null || lastDisplayWidth != displayWidth || lastDisplayHeight != displayHeight) {
                try {
                    blurShader = mc.getShaderLoader().loadPostEffect(BLUR_ID, DefaultFramebufferSet.MAIN_ONLY);
                } catch (Throwable t) {
                    blurShader = null;
                }
                lastDisplayWidth = displayWidth;
                lastDisplayHeight = displayHeight;
            }
        }
    }

    public static void blurScissor(final float right, final float top, final float left, final float down, final boolean overlay) {
        if (mc.options.getGuiScale().getValue() != 2) {
            return;
        }
        if (blurShader == null) {
            return;
        }
        // PORT: the GUI scissor only clips DrawContext draws — the post pass renders the
        // whole framebuffer regardless. Kept so the region logic matches 1.8.9.
        scaledScissor((int) right, (int) top, (int) left, (int) down);
        blurFully(overlay);
        disableScissor();
    }

    public static void scaledScissor(final int right, final int top, int left, int down) {
        if (mc.options.getGuiScale().getValue() != 2) {
            return;
        }
        if (!hasContext()) {
            return;
        }
        left -= right;
        down -= top;
        context().enableScissor(right, top, right + left, top + down);
    }

    public static void blurFully(final boolean overlay) {
        if (mc.options.getGuiScale().getValue() != 2) {
            return;
        }
        if (blurShader != null) {
            blurShader.render(mc.getFramebuffer(), ObjectAllocator.TRIVIAL);
        }
    }

    private static void disableScissor() {
        if (hasContext()) {
            context().disableScissor();
        }
    }

    public static int interpolateColor(Color color1, Color color2, float fraction) {
        int r = MathHelper.clamp((int) (color1.getRed() + (color2.getRed() - color1.getRed()) * fraction), 0, 255);
        int g = MathHelper.clamp((int) (color1.getGreen() + (color2.getGreen() - color1.getGreen()) * fraction), 0, 255);
        int b = MathHelper.clamp((int) (color1.getBlue() + (color2.getBlue() - color1.getBlue()) * fraction), 0, 255);
        int a = MathHelper.clamp((int) (color1.getAlpha() + (color2.getAlpha() - color1.getAlpha()) * fraction), 0, 255);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
