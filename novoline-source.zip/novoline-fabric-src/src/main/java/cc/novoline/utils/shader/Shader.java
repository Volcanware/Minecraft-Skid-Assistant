package cc.novoline.utils.shader;

import cc.novoline.Novoline;
import org.apache.commons.io.IOUtils;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * PORT: MC 1.21 cannot compile arbitrary GLSL at runtime — vanilla shaders go through
 * the ShaderLoader registry with JSON program definitions and RenderPipeline objects,
 * all baked at resource load. This class preserves the 1.8.9 API surface: it still
 * loads and validates the shader sources from the classpath and tracks uniform
 * values, so callers behave identically. Actually executing the program on the GPU
 * requires a registered RenderPipeline + ShaderProgram hook in shared infra
 * (see PORTING notes / hooks_needed).
 */
public abstract class Shader {
    private int program;

    private Map<String, Integer> uniformsMap;
    private final Map<String, Object> uniformValues = new HashMap<>();
    private boolean active;

    public Shader(final String fragmentShader) {
        try {
            // PORT: sources are loaded for validation/log parity; there is no
            // ARB-style object to link them into anymore.
            final InputStream vertexStream = getClass().getResourceAsStream("/assets/minecraft/liquidbounce/shader/vertex.vert");
            String vertexSource = IOUtils.toString(vertexStream);
            IOUtils.closeQuietly(vertexStream);

            final InputStream fragmentStream = getClass().getResourceAsStream("/assets/minecraft/liquidbounce/shader/fragment/" + fragmentShader);
            String fragmentSource = IOUtils.toString(fragmentStream);
            IOUtils.closeQuietly(fragmentStream);
        } catch (final Exception e) {
            e.printStackTrace();
            return;
        }

        // PORT: no GL program object; use 1 as a sentinel for "compiled".
        program = 1;

        Novoline.getLogger().info("[Shader] Successfully loaded: " + fragmentShader);
    }

    public void startShader() {
        active = true;

        if (uniformsMap == null) {
            uniformsMap = new HashMap<>();
            setupUniforms();
        }

        updateUniforms();
    }

    public void stopShader() {
        active = false;
    }

    public abstract void setupUniforms();

    public abstract void updateUniforms();

    public boolean isActive() {
        return active;
    }

    protected void setUniformValue(final String uniformName, final Object value) {
        uniformValues.put(uniformName, value);
    }

    protected Object getUniformValue(final String uniformName) {
        return uniformValues.get(uniformName);
    }

    public void setUniform(final String uniformName, final int location) {
        uniformsMap.put(uniformName, location);
    }

    public void setupUniform(final String uniformName) {
        // PORT: glGetUniformLocation -> synthetic sequential location.
        setUniform(uniformName, uniformsMap.size());
    }

    public int getUniform(final String uniformName) {
        return uniformsMap.get(uniformName);
    }

    public int getProgramId() {
        return program;
    }
}
