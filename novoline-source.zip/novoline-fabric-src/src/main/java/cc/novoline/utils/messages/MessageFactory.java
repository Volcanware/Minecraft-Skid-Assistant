package cc.novoline.utils.messages;

import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static cc.novoline.utils.messages.HelpMessage.UsageMessage;

public final class MessageFactory {

    public static @NotNull TextMessage text(@Nullable String text) {
        return TextMessage.of(text);
    }

    public static @NotNull TextMessage text(@Nullable String text, @Nullable Formatting color) {
        return TextMessage.of(text, color);
    }

    public static @NotNull HelpMessage help(@NotNull String name, @NotNull String command, @NotNull UsageMessage... subCommands) {
        return HelpMessage.of(name, command, subCommands);
    }

    public static @NotNull UsageMessage usage(@NotNull String command, @NotNull String description) {
        return UsageMessage.of(command, description);
    }

    public static @NotNull Message empty() {
        return EmptyMessage.get();
    }

    private MessageFactory() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}
