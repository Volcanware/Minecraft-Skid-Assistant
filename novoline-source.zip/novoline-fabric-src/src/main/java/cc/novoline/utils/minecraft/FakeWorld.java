package cc.novoline.utils.minecraft;

import com.mojang.serialization.Lifecycle;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.network.ClientConnectionState;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.session.telemetry.TelemetrySender;
import net.minecraft.client.session.telemetry.WorldSession;
import net.minecraft.client.world.ClientChunkLoadProgress;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.boss.dragon.EnderDragonPart;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.FuelRegistry;
import net.minecraft.item.map.MapState;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.NetworkSide;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.recipe.BrewingRecipeRegistry;
import net.minecraft.recipe.RecipeManager;
import net.minecraft.registry.*;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryInfo;
import net.minecraft.resource.featuretoggle.FeatureFlags;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.server.ServerLinks;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.collection.WeightedPool;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.GlobalPos;
import net.minecraft.world.Difficulty;
import net.minecraft.world.World;
import net.minecraft.world.WorldProperties;
import net.minecraft.world.attribute.WorldEnvironmentAttributeAccess;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.dimension.DimensionTypes;
import net.minecraft.world.explosion.ExplosionBehavior;
import net.minecraft.world.tick.TickManager;
import com.mojang.authlib.GameProfile;
import net.minecraft.recipe.ServerRecipeManager;
import net.minecraft.util.Util;

import java.time.Duration;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * @author xDelsy
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class FakeWorld extends ClientWorld {

    public FakeWorld() {
        super(createNetworkHandler(),
                new Properties(Difficulty.PEACEFUL, false, false),
                World.OVERWORLD,
                getDimensionTypeEntry(),
                8,
                8,
                MinecraftClient.getInstance().worldRenderer,
                false,
                1L,
                0);
    }

    // PORT: 1.8.9 built a World with FakeSaveHandler/FakeWorldProvider; on 1.21 a
    // client-side world is ClientWorld, which needs a ClientPlayNetworkHandler holding
    // a ClientConnectionState with a registry manager. The connection is inert —
    // nothing ever writes to it.
    private static ClientPlayNetworkHandler createNetworkHandler() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientConnectionState state = new ClientConnectionState(
                new ClientChunkLoadProgress(),
                mc.getGameProfile() != null ? mc.getGameProfile() : new GameProfile(Util.NIL_UUID, "fake"),
                new WorldSession(TelemetrySender.NOOP, false, Duration.ZERO, "fake"),
                createRegistryManager(),
                FeatureFlags.VANILLA_FEATURES,
                "fake",
                null,
                null,
                Map.of(),
                new ChatHud.ChatState(List.of(), List.of(), List.of()),
                Map.of(),
                ServerLinks.EMPTY,
                Map.of(),
                false);
        return new ClientPlayNetworkHandler(mc, new ClientConnection(NetworkSide.CLIENTBOUND), state);
    }

    private static RegistryEntry<DimensionType> getDimensionTypeEntry() {
        return BuiltinRegistries.createWrapperLookup()
                .getOrThrow(RegistryKeys.DIMENSION_TYPE)
                .getOrThrow(DimensionTypes.OVERWORLD);
    }

    // PORT: a real registry manager is required by the ClientWorld/World constructors
    // (PalettesFactory needs the biome registry, DamageSources needs damage types).
    // Copy every static registry plus the materialized builtin dynamic registries the
    // world touches.
    private static DynamicRegistryManager.Immutable createRegistryManager() {
        RegistryWrapper.WrapperLookup lookup = BuiltinRegistries.createWrapperLookup();
        SimpleRegistry<Registry<?>> registries = new SimpleRegistry<>(
                RegistryKey.ofRegistry(RegistryKeys.ROOT), Lifecycle.stable());
        for (Registry<?> registry : Registries.REGISTRIES) {
            registries.add((RegistryKey<Registry<?>>) registry.getKey(), registry, RegistryEntryInfo.DEFAULT);
        }
        addRegistry(registries, lookup, RegistryKeys.DIMENSION_TYPE);
        addRegistry(registries, lookup, RegistryKeys.BIOME);
        addRegistry(registries, lookup, RegistryKeys.DAMAGE_TYPE);
        return DynamicRegistryManager.of(registries);
    }

    private static <T> void addRegistry(SimpleRegistry<Registry<?>> registries,
                                        RegistryWrapper.WrapperLookup lookup,
                                        RegistryKey<Registry<T>> key) {
        SimpleRegistry<T> registry = new SimpleRegistry<>(key, Lifecycle.stable());
        lookup.getOrThrow(key).streamEntries()
                .forEach(entry -> registry.add(entry.registryKey(), entry.value(), RegistryEntryInfo.DEFAULT));
        registries.add((RegistryKey<Registry<?>>) (Object) key, registry, RegistryEntryInfo.DEFAULT);
    }

    @Override
    public BlockState getBlockState(BlockPos pos) {
        return pos.getY() > 63 ? Blocks.AIR.getDefaultState() : Blocks.GRASS_BLOCK.getDefaultState();
    }

    @Override
    public boolean spawnEntity(final Entity entity) {
        return false;
    }

    @Override
    public void addEntity(final Entity entity) {
    }

    @Override
    public void removeEntity(final int entityId, final Entity.RemovalReason removalReason) {
    }

    @Override
    public void tick(final java.util.function.BooleanSupplier shouldKeepTicking) {
    }

    @Override
    public void tickEntities() {
    }

    @Override
    public void tickEntity(final Entity entity) {
    }

    @Override
    public void doRandomBlockDisplayTicks(final int x, final int y, final int z) {
    }

    @Override
    public void updateListeners(final BlockPos pos, final BlockState oldState, final BlockState newState, final int flags) {
    }

    @Override
    public void playSound(final Entity source, final double x, final double y, final double z,
                          final RegistryEntry<SoundEvent> sound, final SoundCategory category,
                          final float volume, final float pitch, final long seed) {
    }

    @Override
    public void playSoundFromEntity(final Entity source, final Entity entity,
                                    final RegistryEntry<SoundEvent> sound, final SoundCategory category,
                                    final float volume, final float pitch, final long seed) {
    }

    @Override
    public void createExplosion(final Entity entity, final DamageSource damageSource,
                                final ExplosionBehavior explosionBehavior, final double x, final double y,
                                final double z, final float power, final boolean createFire,
                                final ExplosionSourceType explosionSourceType, final ParticleEffect smallParticle,
                                final ParticleEffect largeParticle,
                                final WeightedPool<net.minecraft.particle.BlockParticleEffect> blockParticles,
                                final RegistryEntry<SoundEvent> soundEvent) {
    }

    @Override
    public void setBlockBreakingInfo(final int entityId, final BlockPos pos, final int progress) {
    }

    @Override
    public boolean isDay() {
        return true;
    }

    @Override
    public long getTime() {
        return 1L;
    }

    @Override
    public long getTimeOfDay() {
        return 1L;
    }

    @Override
    public void setTime(final long time, final long timeOfDay, final boolean stopTime) {
    }

    @Override
    public int getLightLevel(final BlockPos pos) {
        return 15;
    }

    @Override
    public float getRainGradient(final float delta) {
        return 0.0f;
    }

    @Override
    public boolean isThundering() {
        return false;
    }

    @Override
    public boolean isRaining() {
        return false;
    }

    @Override
    public int getSeaLevel() {
        return 63;
    }

    @Override
    public int getHeight() {
        return 256;
    }

    @Override
    public WorldProperties.SpawnPoint getSpawnPoint() {
        return WorldProperties.SpawnPoint.create(World.OVERWORLD, new BlockPos(0, 64, 0), 0.0f, 0.0f);
    }

    @Override
    public void setSpawnPoint(final WorldProperties.SpawnPoint spawnPoint) {
    }

    @Override
    public net.minecraft.entity.Entity getEntityById(final int id) {
        try {
            final EntityType<?> entityType = Registries.ENTITY_TYPE.get(id);
            return entityType == null ? null : entityType.create(this, SpawnReason.LOAD);
        } catch (Throwable ignored) {
            return null;
        }
    }

    @Override
    public List<EnderDragonPart> getEnderDragonParts() {
        return List.of();
    }

    @Override
    public TickManager getTickManager() {
        return tickManager;
    }

    private final TickManager tickManager = new TickManager();
    private final Scoreboard scoreboard = new Scoreboard();
    private final RecipeManager recipeManager = new ServerRecipeManager(BuiltinRegistries.createWrapperLookup());
    private final WorldEnvironmentAttributeAccess environmentAttributes = WorldEnvironmentAttributeAccess.builder().build();

    @Override
    public MapState getMapState(final net.minecraft.component.type.MapIdComponent id) {
        return null;
    }

    @Override
    public Scoreboard getScoreboard() {
        return scoreboard;
    }

    @Override
    public RecipeManager getRecipeManager() {
        return recipeManager;
    }

    @Override
    public WorldEnvironmentAttributeAccess getEnvironmentAttributes() {
        return environmentAttributes;
    }

    @Override
    public BrewingRecipeRegistry getBrewingRecipeRegistry() {
        return BrewingRecipeRegistry.EMPTY;
    }

    @Override
    public FuelRegistry getFuelRegistry() {
        return FuelRegistry.createDefault(BuiltinRegistries.createWrapperLookup(), FeatureFlags.VANILLA_FEATURES);
    }

    @Override
    public String asString() {
        return "";
    }

}
