package cc.novoline.utils.web;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

public class JsonObtainer {

    // PORT: org.json is not on the 1.21.11 classpath — returns Gson JsonObject
    // instead of org.json.JSONObject. Callers: optBoolean(k)/optString(k) map to
    // (has(k) && get(k).getAsBoolean()) / (has(k) ? get(k).getAsString() : "").
    public static JsonObject obtainJson(String url){
        try{
            URL u = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) u.openConnection();
            connection.setRequestMethod("GET");
            connection.addRequestProperty("User-Agent","Mozilla/4.76 (Sk1er-UHCStars V1.0)");
            InputStream is = connection.getInputStream();
            return JsonParser.parseString(new String(is.readAllBytes(), Charset.defaultCharset())).getAsJsonObject();
        }catch (Exception e){
            e.printStackTrace();
        }
        JsonObject failure = new JsonObject();
        failure.addProperty("succcess", false);
        failure.addProperty("cause", "API_DOWN");
        return failure;
    }

}
