package cc.novoline.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import org.jetbrains.annotations.NotNull;

import java.awt.*;

public final class OutlineUtils {

    private OutlineUtils() {
        throw new java.lang.UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    // PORT: the 1.8.9 implementation drove a multi-pass stencil-buffer outline around
    // entities (renderOne..renderFive bracketed entity rendering). MC 1.21 has no
    // stencil pipeline reachable through DrawContext/RenderUtils — the modern
    // equivalent of entity silhouettes is the vanilla `entity_outline` post effect
    // (flag entities with `setGlowing(true)`), which renders through the frame graph.
    // The methods keep their original signatures and are no-ops; see hooks_needed.

    public static void renderOne() {
        checkSetupFBO();
    }

    public static void renderTwo() {
        // PORT: no-op (stencil pass 2 — polygon fill with GL_NEVER stencil func).
    }

    public static void renderThree() {
        // PORT: no-op (stencil pass 3 — outline stroke via GL_EQUAL stencil func).
    }

    public static void renderFour() {
        setColor(new Color(0xFFFFFF));
    }

    public static void renderFive() {
        // PORT: no-op (state restore — GL attribute stack does not exist anymore).
    }

    public static void setColor(@NotNull Color c) {
        // PORT: immediate-mode vertex color has no DrawContext equivalent; DrawContext
        // tint is per-draw-call. Consumers should pass c.getRGB() to the draw call.
    }

    public static void checkSetupFBO() {
        final Framebuffer framebuffer = MinecraftClient.getInstance().getFramebuffer();

        if (framebuffer != null && framebuffer.getDepthAttachment() != null) {
            // PORT: modern framebuffers manage their own depth/stencil attachments;
            // there is nothing to rebuild here. Callers keep the same check shape.
            setupFBO(framebuffer);
        }
    }

    public static void setupFBO(@NotNull Framebuffer fbo) {
        // PORT: no-op — replacing the main framebuffer's depth-stencil renderbuffer is
        // internal to GlFramebuffer in 1.21 and not something mods do manually.
    }

}
