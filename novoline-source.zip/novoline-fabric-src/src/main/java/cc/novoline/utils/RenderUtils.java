package cc.novoline.utils;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.render.ColoredVerticesGuiElementRenderState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.render.state.ColoredQuadGuiElementRenderState;
import net.minecraft.client.gui.render.state.TexturedQuadGuiElementRenderState;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.command.RenderCommandQueue;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.awt.*;

import static cc.novoline.utils.fonts.impl.Fonts.SF.SF_16.SF_16;

/**
 * Port of the 1.8.9 RenderUtils to the 1.21.11 render pipeline.
 * <p>
 * 2D (GUI-space) calls draw into the {@link DrawContext} stored by
 * {@link #setContext(DrawContext)} — set by the Render2DEvent hook and by each
 * Novoline screen before rendering.
 * <p>
 * 3D (world-space) calls submit through the {@link RenderCommandQueue} stored
 * by {@link #setWorldContext(RenderCommandQueue, MatrixStack, Vec3d)} during
 * the Render3DEvent dispatch.
 */
@SuppressWarnings({"unused", "MagicNumber"})
public final class RenderUtils {

    public static double healthPercent;
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    /** Active GUI draw context — null outside of 2D render. */
    private static DrawContext context;
    /** Active world-render queue + matrices — null outside of Render3DEvent. */
    private static RenderCommandQueue worldQueue;
    private static MatrixStack worldMatrices;
    private static Vec3d cameraPos = Vec3d.ZERO;

    private RenderUtils() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    //region context management
    public static void setContext(DrawContext ctx) {
        context = ctx;
    }

    public static DrawContext context() {
        if (context == null) {
            throw new IllegalStateException("RenderUtils.context used outside of a 2D render pass");
        }
        return context;
    }

    public static boolean hasContext() {
        return context != null;
    }

    public static void setWorldContext(RenderCommandQueue queue, MatrixStack matrices, Vec3d camera) {
        worldQueue = queue;
        worldMatrices = matrices;
        cameraPos = camera;
    }

    public static void clearWorldContext() {
        worldQueue = null;
        worldMatrices = null;
    }

    public static RenderCommandQueue worldQueue() {
        if (worldQueue == null) {
            throw new IllegalStateException("world drawing used outside of Render3DEvent");
        }
        return worldQueue;
    }

    public static MatrixStack worldMatrices() {
        if (worldMatrices == null) {
            throw new IllegalStateException("world drawing used outside of Render3DEvent");
        }
        return worldMatrices;
    }

    public static Vec3d cameraPos() {
        return cameraPos;
    }
    //endregion

    //region 2D primitives
    /** Submit a colored axis-aligned quad into the GUI render state. */
    /* Float-precision quads — the vanilla ColoredQuadGuiElementRenderState takes ints,
       which snaps every edge to integer GUI coords. Adjacent rects (e.g. arraylist
       rows) that share a fractional edge then render a gap or an overlapping dark
       band at non-integer GUI scales. Emit float vertices via guiShape instead. */
    public static void guiQuad(float x1, float y1, float x2, float y2, int color) {
        float minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
        float minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
        guiShape(new float[]{minX, minY, minX, maxY, maxX, maxY, maxX, minY},
            new int[]{color, color, color, color},
            (int) Math.floor(minX), (int) Math.floor(minY),
            (int) Math.ceil(maxX), (int) Math.ceil(maxY));
    }

    public static void guiQuadGradient(float x1, float y1, float x2, float y2, int colorTop, int colorBottom) {
        float minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
        float minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
        guiShape(new float[]{minX, minY, minX, maxY, maxX, maxY, maxX, minY},
            new int[]{colorTop, colorBottom, colorBottom, colorTop},
            (int) Math.floor(minX), (int) Math.floor(minY),
            (int) Math.ceil(maxX), (int) Math.ceil(maxY));
    }

    /** Submit arbitrary colored geometry (flat x,y pairs, one color per vertex). */
    public static void guiShape(float[] vertices, int[] colors, int x1, int y1, int x2, int y2) {
        guiShape(vertices, colors, x1, y1, x2, y2, RenderPipelines.GUI);
    }

    public static void guiShape(float[] vertices, int[] colors, int x1, int y1, int x2, int y2, RenderPipeline pipeline) {
        DrawContext ctx = context();
        ctx.state.addSimpleElement(new ColoredVerticesGuiElementRenderState(
            pipeline, new Matrix3x2f(ctx.getMatrices()), vertices, colors, x1, y1, x2, y2,
            ctx.scissorStack.peekLast()));
    }

    /** Submit a textured quad (e.g. font glyphs) into the GUI render state. */
    public static void guiTexturedQuad(net.minecraft.util.Identifier textureId, RenderPipeline pipeline,
                                       float x1, float y1, float x2, float y2,
                                       float u1, float v1, float u2, float v2, int color) {
        DrawContext ctx = context();
        net.minecraft.client.texture.AbstractTexture texture = mc.getTextureManager().getTexture(textureId);
        ctx.state.addSimpleElement(new TexturedQuadGuiElementRenderState(
            pipeline, TextureSetup.of(texture.getGlTextureView(), texture.getSampler()),
            new Matrix3x2f(ctx.getMatrices()),
            (int) x1, (int) y1, (int) x2, (int) y2, u1, u2, v1, v2, color, ctx.scissorStack.peekLast()));
    }
    //endregion

    public static void setupRender(boolean start) {
        /* no-op in the render-state pipeline */
    }

    public static int getArrayRainbow(int counter, int alpha) {
        return getRainbow(3000, -15 * counter, alpha);
    }

    public static int getArrayAstolfo(int counter, int alpha) {
        float[] hsb = Color.RGBtoHSB(255, 100, 220, null);
        float speed = 3100.0f;
        float hue = (float) (System.currentTimeMillis() % (long) ((int) speed)) / speed;
        return Color.getHSBColor(hue - (counter * 0.015f), hsb[1], hsb[2]).getRGB() & 0x00FFFFFF | (alpha << 24);
    }

    public static Vec3d interpolateRender(Entity player) {
        float ticks = mc.getRenderTickCounter().getTickProgress(true);
        return new Vec3d(
            player.lastRenderX + (player.getX() - player.lastRenderX) * ticks - mc.gameRenderer.getCamera().getCameraPos().x,
            player.lastRenderY + (player.getY() - player.lastRenderY) * ticks - mc.gameRenderer.getCamera().getCameraPos().y,
            player.lastRenderZ + (player.getZ() - player.lastRenderZ) * ticks - mc.gameRenderer.getCamera().getCameraPos().z);
    }

    public static float[] getRGBAs(int rgb) {
        return new float[]{(rgb >> 16 & 255) / 255.0F, (rgb >> 8 & 255) / 255.0F, (rgb & 255) / 255.0F, (rgb >> 24 & 255) / 255.0F};
    }

    public static void drawHorizontal(String s, float x, float y) {
        drawHorizontal(SF_16, s, x, y);
    }

    public static void drawHorizontal(FontRenderer font, String s, float x, float y) {
        font.drawString(s, x, y, Color.WHITE.getRGB(), false);
    }

    public static String obfuscateString(String s, String replacement) {
        StringBuilder out = new StringBuilder();
        for (char c : s.toCharArray()) {
            out.append(c == ' ' ? ' ' : replacement.charAt(0));
        }
        return out.toString();
    }

    public static void rectangle(double left, double top, double right, double bottom, int color) {
        drawRect((float) left, (float) top, (float) right, (float) bottom, color);
    }

    public static int getRainbow(int speed, int offset) {
        return getRainbow(speed, offset, 0xFF);
    }

    public static int getRainbow(int speed, int offset, int alpha) {
        float hue = (float) ((System.currentTimeMillis() + offset) % (long) speed) / speed;
        return Color.getHSBColor(hue, 0.55f, 1.0f).getRGB() & 0x00FFFFFF | (alpha << 24);
    }

    public static void rectangleBordered(double x, double y, double x1, double y1, double width, int internalColor, int borderColor) {
        drawRect((float) x, (float) y, (float) x1, (float) y1, borderColor);
        drawRect((float) (x + width), (float) (y + width), (float) (x1 - width), (float) (y1 - width), internalColor);
    }

    public static double interpolate(double current, double old, double scale) {
        return old + (current - old) * scale;
    }

    /** Frustum captured each frame by EntityRenderManagerMixin. */
    public static net.minecraft.client.render.Frustum lastFrustum;

    public static boolean isInViewFrustrum(Entity entity) {
        return isInViewFrustrum(entity.getBoundingBox());
    }

    public static boolean isInViewFrustrum(Box bb) {
        return lastFrustum != null && lastFrustum.isVisible(bb);
    }

    public static void drawBorderedBox(double x, double y, double x2, double y2, Color color, boolean bordered) {
        if (bordered) {
            drawRect((float) x, (float) y, (float) x2, (float) y2, new Color(0, 0, 0, 100).getRGB());
            drawBorderedRect(x, y, x2, y2, 1.0f, color.getRGB(), 0);
        } else {
            drawRect((float) x, (float) y, (float) x2, (float) y2, color.getRGB());
        }
    }

    public static void drawBorderedRect(float x, float y, float x2, float y2, float l1, int col1, int col2) {
        drawRect(x, y, x2, y2, col2);
        float f = (float) (col1 >> 24 & 0xFF) / 255.0F;
        float f1 = (float) (col1 >> 16 & 0xFF) / 255.0F;
        float f2 = (float) (col1 >> 8 & 0xFF) / 255.0F;
        float f3 = (float) (col1 & 0xFF) / 255.0F;
        drawRect(x, y, x + l1, y2, col1);
        drawRect(x2 - l1, y, x2, y2, col1);
        drawRect(x + l1, y, x2 - l1, y + l1, col1);
        drawRect(x + l1, y2 - l1, x2 - l1, y2, col1);
    }

    public static void drawBorderedRect(double x, double y, double x2, double y2, float l1, int col1, int col2) {
        drawBorderedRect((float) x, (float) y, (float) x2, (float) y2, l1, col1, col2);
    }

    public static void drawRoundedRect(float x, float y, float width, float height, float radius, int color) {
        // Approximation: polygonal rounded rect via triangle-fan arcs in the GUI pipeline
        float[] v = new float[0];
        java.util.List<Float> verts = new java.util.ArrayList<>();
        java.util.List<Integer> cols = new java.util.ArrayList<>();

        double x1 = x + width, y1 = y + height;
        float f = radius;
        // sides
        emitQuad(verts, cols, color, x, y + f, x, y1 - f, x + f, y1 - f, x + f, y + f);
        emitQuad(verts, cols, color, x + f, y + f, x + f, y1 - f, x1 - f, y1 - f, x1 - f, y + f);
        emitQuad(verts, cols, color, x1 - f, y + f, x1 - f, y1 - f, x1, y1 - f, x1, y + f);
        // corners
        arc(verts, cols, color, x + f, y + f, f, 180, 270);
        arc(verts, cols, color, x1 - f, y + f, f, 270, 360);
        arc(verts, cols, color, x1 - f, y1 - f, f, 0, 90);
        arc(verts, cols, color, x + f, y1 - f, f, 90, 180);

        guiShape(toF(verts), toI(cols), (int) x, (int) y, (int) x1 + 1, (int) y1 + 1);
    }

    private static void emitQuad(java.util.List<Float> v, java.util.List<Integer> c, int col,
                                 double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3) {
        v.add((float) x0); v.add((float) y0); c.add(col);
        v.add((float) x1); v.add((float) y1); c.add(col);
        v.add((float) x2); v.add((float) y2); c.add(col);
        v.add((float) x3); v.add((float) y3); c.add(col);
    }

    /** Fan of degenerate quads (triangles rendered as quads with a repeated vertex). */
    private static void arc(java.util.List<Float> v, java.util.List<Integer> c, int col,
                            double cx, double cy, double r, double from, double to) {
        int segments = 8;
        for (int i = 0; i < segments; i++) {
            double a0 = Math.toRadians(from + (to - from) * i / segments);
            double a1 = Math.toRadians(from + (to - from) * (i + 1) / segments);
            v.add((float) cx); v.add((float) cy); c.add(col);
            v.add((float) (cx + Math.cos(a0) * r)); v.add((float) (cy + Math.sin(a0) * r)); c.add(col);
            v.add((float) (cx + Math.cos(a1) * r)); v.add((float) (cy + Math.sin(a1) * r)); c.add(col);
            v.add((float) (cx + Math.cos(a1) * r)); v.add((float) (cy + Math.sin(a1) * r)); c.add(col);
        }
    }

    private static float[] toF(java.util.List<Float> l) {
        float[] out = new float[l.size()];
        for (int i = 0; i < l.size(); i++) out[i] = l.get(i);
        return out;
    }

    private static int[] toI(java.util.List<Integer> l) {
        int[] out = new int[l.size()];
        for (int i = 0; i < l.size(); i++) out[i] = l.get(i);
        return out;
    }

    public static @NotNull Color blend(@NotNull Color color1, @NotNull Color color2, double ratio) {
        float r = (float) ratio;
        float ir = 1.0F - r;
        float[] rgb1 = new float[3];
        float[] rgb2 = new float[3];
        color1.getColorComponents(rgb1);
        color2.getColorComponents(rgb2);
        return new Color(rgb1[0] * r + rgb2[0] * ir, rgb1[1] * r + rgb2[1] * ir, rgb1[2] * r + rgb2[2] * ir);
    }

    public static void drawRect(float left, float top, float right, float bottom, int col1) {
        if (left < right) {
            float i = left; left = right; right = i;
        }
        if (top < bottom) {
            float j = top; top = bottom; bottom = j;
        }
        guiQuad(left, top, right, bottom, col1);
    }

    public static void drawBoundingBox(@NotNull Box aa) {
        submitWorld(RenderLayers.debugQuads(), (entry, vc) -> {
            Matrix4f m = entry.getPositionMatrix();
            vertex(vc, m, (float) aa.minX, (float) aa.minY, (float) aa.minZ, -1);
            vertex(vc, m, (float) aa.maxX, (float) aa.minY, (float) aa.minZ, -1);
            vertex(vc, m, (float) aa.maxX, (float) aa.minY, (float) aa.maxZ, -1);
            vertex(vc, m, (float) aa.minX, (float) aa.minY, (float) aa.maxZ, -1);
            vertex(vc, m, (float) aa.minX, (float) aa.maxY, (float) aa.minZ, -1);
            vertex(vc, m, (float) aa.maxX, (float) aa.maxY, (float) aa.minZ, -1);
            vertex(vc, m, (float) aa.maxX, (float) aa.maxY, (float) aa.maxZ, -1);
            vertex(vc, m, (float) aa.minX, (float) aa.maxY, (float) aa.maxZ, -1);
        });
    }

    public static void drawCircle(float cx, float cy, float r, float numSegments, int c) {
        java.util.List<Float> v = new java.util.ArrayList<>();
        java.util.List<Integer> cols = new java.util.ArrayList<>();
        for (double i = 0; i < numSegments; i++) {
            double a0 = i * 360.0 / numSegments;
            double a1 = (i + 1) * 360.0 / numSegments;
            v.add(cx); v.add(cy); cols.add(c);
            v.add((float) (cx + Math.cos(Math.toRadians(a0)) * r)); v.add((float) (cy + Math.sin(Math.toRadians(a0)) * r)); cols.add(c);
            v.add((float) (cx + Math.cos(Math.toRadians(a1)) * r)); v.add((float) (cy + Math.sin(Math.toRadians(a1)) * r)); cols.add(c);
            v.add((float) (cx + Math.cos(Math.toRadians(a1)) * r)); v.add((float) (cy + Math.sin(Math.toRadians(a1)) * r)); cols.add(c);
        }
        guiShape(toF(v), toI(cols), (int) (cx - r), (int) (cy - r), (int) (cx + r) + 1, (int) (cy + r) + 1);
    }

    public static int getHealthColor(@NotNull LivingEntity player) {
        float health = player.getHealth();
        float max = player.getMaxHealth();
        return Color.HSBtoRGB(Math.max(0.0F, health / max * 0.5F - 0.15F), 0.9F, 1.0F) | 0xFF000000;
    }

    public static void drawFilledCircle(float x, float y, float r, int c) {
        drawCircle(x, y, r, 36, c);
    }

    public static void dr(double i, double j, double k, double l, int i1) {
        drawRect((float) i, (float) j, (float) k, (float) l, i1);
    }

    //region world-space submission
    /** Submit world-space geometry; coords must be camera-relative (done by {@link #boxVertices}). */
    public static void submitWorld(RenderLayer layer, OrderedRenderCommandQueue.Custom renderer) {
        worldQueue().submitCustom(worldMatrices(), layer, renderer);
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, float x, float y, float z, int color) {
        Vector4f v = m.transform(new Vector4f(x, y, z, 1.0F));
        vc.vertex(v.x, v.y, v.z).color(color);
    }

    /** RenderLayers.lines() uses the POSITION|COLOR|NORMAL|LINE_WIDTH vertex
     *  format — plain vertex() emits no Normal/LineWidth. */
    private static void lineVertex(VertexConsumer vc, Matrix4f m, float x, float y, float z,
                                   float nx, float ny, float nz, int color) {
        Vector4f v = m.transform(new Vector4f(x, y, z, 1.0F));
        vc.vertex(v.x, v.y, v.z).color(color).normal(nx, ny, nz).lineWidth(1.0F);
    }

    /** Write a filled box into a quad-mode VertexConsumer. Submitted vertices must
     *  be camera-relative (verified: END_MAIN pose stack is identity in 1.21.11). */
    public static void boxVertices(VertexConsumer vc, Matrix4f m, Box worldBox, int color) {
        Box b = worldBox.offset(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        float minX = (float) b.minX, minY = (float) b.minY, minZ = (float) b.minZ;
        float maxX = (float) b.maxX, maxY = (float) b.maxY, maxZ = (float) b.maxZ;

        float[][] faces = {
            {minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ}, // bottom
            {minX, maxY, minZ, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ}, // top
            {minX, minY, minZ, minX, maxY, minZ, minX, maxY, maxZ, minX, minY, maxZ}, // -x
            {maxX, minY, minZ, maxX, minY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ}, // +x
            {minX, minY, minZ, minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ}, // -z
            {maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, minX, minY, maxZ}, // +z back? (kept for completeness)
            {minX, minY, maxZ, maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ}, // +z
            {maxX, minY, minZ, minX, minY, minZ, minX, maxY, minZ, maxX, maxY, minZ}, // -z
        };

        for (float[] f : faces) {
            for (int i = 0; i < 4; i++) {
                vertex(vc, m, f[i * 3], f[i * 3 + 1], f[i * 3 + 2], color);
            }
        }
    }

    /** Write a box outline into a lines-mode VertexConsumer — camera-relative coords. */
    public static void boxOutlineVertices(VertexConsumer vc, Matrix4f m, Box worldBox, int color) {
        Box b = worldBox.offset(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        float[][] edges = {
            {(float) b.minX, (float) b.minY, (float) b.minZ}, {(float) b.maxX, (float) b.minY, (float) b.minZ},
        };
        float minX = (float) b.minX, minY = (float) b.minY, minZ = (float) b.minZ;
        float maxX = (float) b.maxX, maxY = (float) b.maxY, maxZ = (float) b.maxZ;
        float[][] e = {
            {minX, minY, minZ}, {maxX, minY, minZ}, {maxX, minY, minZ}, {maxX, minY, maxZ},
            {maxX, minY, maxZ}, {minX, minY, maxZ}, {minX, minY, maxZ}, {minX, minY, minZ},
            {minX, maxY, minZ}, {maxX, maxY, minZ}, {maxX, maxY, minZ}, {maxX, maxY, maxZ},
            {maxX, maxY, maxZ}, {minX, maxY, maxZ}, {minX, maxY, maxZ}, {minX, maxY, minZ},
            {minX, minY, minZ}, {minX, maxY, minZ}, {maxX, minY, minZ}, {maxX, maxY, minZ},
            {maxX, minY, maxZ}, {maxX, maxY, maxZ}, {minX, minY, maxZ}, {minX, maxY, maxZ},
        };
        for (int i = 0; i + 1 < e.length; i += 2) {
            float dx = e[i + 1][0] - e[i][0], dy = e[i + 1][1] - e[i][1], dz = e[i + 1][2] - e[i][2];
            float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1.0E-4F) { dx = 0; dy = 1; dz = 0; len = 1; }
            float nx = dx / len, ny = dy / len, nz = dz / len;
            lineVertex(vc, m, e[i][0], e[i][1], e[i][2], nx, ny, nz, color);
            lineVertex(vc, m, e[i + 1][0], e[i + 1][1], e[i + 1][2], nx, ny, nz, color);
        }
    }
    //endregion

    public static void drawOutlinedBoundingBox(Box bb) {
        submitWorld(RenderLayers.lines(), (entry, vc) -> boxOutlineVertices(vc, entry.getPositionMatrix(), bb, -1));
    }

    public static void drawFilledBox(@NotNull Box mask) {
        submitWorld(RenderLayers.debugQuads(), (entry, vc) -> boxVertices(vc, entry.getPositionMatrix(), mask, -1));
    }

    public static void drawSolidBlockESP(double x, double y, double z, int color) {
        Box bb = new Box(x + 0.06, y + 0.06, z + 0.06, x + 0.94, y + 0.94, z + 0.94);
        submitWorld(RenderLayers.debugQuads(), (entry, vc) -> boxVertices(vc, entry.getPositionMatrix(), bb, color));
    }

    public static void drawSolidBlockESP(BlockPos pos, int color) {
        drawSolidBlockESP(pos.getX(), pos.getY(), pos.getZ(), color);
    }

    public static void drawOutlinedEntityESP(double x, double y, double z, double width, double height, float red, float green, float blue, float alpha) {
        Box bb = new Box(x - width, y, z - width, x + width, y + height, z + width);
        int color = new Color(red, green, blue, alpha).getRGB();
        submitWorld(RenderLayers.lines(), (entry, vc) -> boxOutlineVertices(vc, entry.getPositionMatrix(), bb, color));
    }

    public static void drawLine(Entity entity, double[] color, double x, double y, double z) {
        Vec3d start = new Vec3d(0, mc.player != null ? mc.player.getEyeHeight(mc.player.getPose()) : 0, 0);
        Vec3d end = interpolateRender(entity);
        drawLineInternal(start, end, color);
    }

    public static void drawLine(BlockPos blockPos, int color) {
        Vec3d start = new Vec3d(0, mc.player != null ? mc.player.getEyeHeight(mc.player.getPose()) : 0, 0);
        Vec3d end = new Vec3d(blockPos.getX() + 0.5, blockPos.getY() + 0.5, blockPos.getZ() + 0.5)
            .subtract(cameraPos);
        drawLineInternal(start, end, new double[]{(color >> 16 & 255) / 255.0, (color >> 8 & 255) / 255.0, (color & 255) / 255.0, (color >> 24 & 255) / 255.0});
    }

    private static void drawLineInternal(Vec3d start, Vec3d end, double[] color) {
        int c = new Color((float) color[0], (float) color[1], (float) color[2], (float) (color.length > 3 ? color[3] : 1.0)).getRGB();
        submitWorld(RenderLayers.lines(), (entry, vc) -> {
            Matrix4f m = entry.getPositionMatrix();
            float dx = (float) (end.x - start.x), dy = (float) (end.y - start.y), dz = (float) (end.z - start.z);
            float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1.0E-4F) { dx = 0; dy = 1; dz = 0; len = 1; }
            float nx = dx / len, ny = dy / len, nz = dz / len;
            lineVertex(vc, m, (float) start.x, (float) start.y, (float) start.z, nx, ny, nz, c);
            lineVertex(vc, m, (float) end.x, (float) end.y, (float) end.z, nx, ny, nz, c);
        });
    }

    /* PORT: the 1.8.9 original drew a GL_LINE_STRIP chevron
     * (x,y) -> (x+3, y+length) -> (x+6, y) at glLineWidth(lineWidth).
     * Reproduced as two thick segment quads — the GUI pipeline only
     * tessellates QUADS, so every emitted shape needs 4 vertices. */
    public static void drawArrow(double x, double y, int lineWidth, int color, double length) {
        java.util.List<Float> v = new java.util.ArrayList<>();
        java.util.List<Integer> cols = new java.util.ArrayList<>();
        emitSegment(v, cols, color, x, y, x + 3, y + length, lineWidth);
        emitSegment(v, cols, color, x + 3, y + length, x + 6, y, lineWidth);
        guiShape(toF(v), toI(cols), (int) x - 1, (int) (y + Math.min(0, length)) - 1,
                (int) x + 7, (int) (y + Math.max(0, length)) + 2, RenderPipelines.GUI);
    }

    /** Quad for a line segment (x0,y0)-(x1,y1) expanded `width` px perpendicular to itself. */
    private static void emitSegment(java.util.List<Float> v, java.util.List<Integer> cols, int col,
                                    double x0, double y0, double x1, double y1, double width) {
        double dx = x1 - x0, dy = y1 - y0;
        double len = Math.hypot(dx, dy);
        if (len < 1.0E-4) {
            len = 1.0E-4;
        }
        double nx = -dy / len * width / 2.0, ny = dx / len * width / 2.0;
        v.add((float) (x0 + nx)); v.add((float) (y0 + ny)); cols.add(col);
        v.add((float) (x1 + nx)); v.add((float) (y1 + ny)); cols.add(col);
        v.add((float) (x1 - nx)); v.add((float) (y1 - ny)); cols.add(col);
        v.add((float) (x0 - nx)); v.add((float) (y0 - ny)); cols.add(col);
    }

    /* PORT: 1.8.9 drew GL_LINE_STRIP (x,y) -> (x+2, y+3) -> (x+6, y-2) */
    public static void drawCheck(double x, double y, int lineWidth, int color) {
        java.util.List<Float> v = new java.util.ArrayList<>();
        java.util.List<Integer> cols = new java.util.ArrayList<>();
        emitSegment(v, cols, color, x, y, x + 2, y + 3, lineWidth);
        emitSegment(v, cols, color, x + 2, y + 3, x + 6, y - 2, lineWidth);
        guiShape(toF(v), toI(cols), (int) x - 1, (int) y - 3, (int) x + 7, (int) y + 4, RenderPipelines.GUI);
    }

    public static void drawCheckbox(double x, double y, double x2, double y2, double lineWidth, int color) {
        drawBorderedRect(x, y, x2, y2, (float) lineWidth, color, 0);
    }

    public static void drawCornerBox(double x, double y, double x2, double y2, double lw, Color color) {
        int c = color.getRGB();
        drawRect((float) x, (float) y, (float) (x + lw), (float) (y + (y2 - y) / 4), c);
        drawRect((float) x, (float) y, (float) (x + (x2 - x) / 4), (float) (y + lw), c);
        drawRect((float) (x2 - lw), (float) y, (float) x2, (float) (y + (y2 - y) / 4), c);
        drawRect((float) (x2 - (x2 - x) / 4), (float) y, (float) x2, (float) (y + lw), c);
        drawRect((float) x, (float) (y2 - (y2 - y) / 4), (float) (x + lw), (float) y2, c);
        drawRect((float) x, (float) (y2 - lw), (float) (x + (x2 - x) / 4), (float) y2, c);
        drawRect((float) (x2 - lw), (float) (y2 - (y2 - y) / 4), (float) x2, (float) y2, c);
        drawRect((float) (x2 - (x2 - x) / 4), (float) (y2 - lw), (float) x2, (float) y2, c);
    }

    public static void glColor(int hex) {
        /* handled per-vertex in the new pipeline */
    }

    public static void enableGL2D() {
    }

    public static void disableGL2D() {
    }

    public static void pre3D() {
    }

    public static void post3D() {
    }

    public static void start2D() {
    }

    public static void stop2D() {
    }

    public static void setColor(Color color) {
    }

    public static void startDrawing() {
    }

    public static void stopDrawing() {
    }

    /* ---- KillAura target HUD (renderTHUD), ported from 1.8.9 ---- */
    private static float lastP;
    private static float diffP;

    public static void renderTHUD(cc.novoline.modules.combat.KillAura aura, @NotNull PlayerEntity e) {
        DrawContext ctx = context();
        float hp = e.getHealth() + e.getAbsorptionAmount();
        final float maxHP = e.getMaxHealth() + e.getAbsorptionAmount() - 0.05f;
        int i = 0;

        for (net.minecraft.entity.EquipmentSlot slot : net.minecraft.entity.EquipmentSlot.values()) {
            if (slot.getType() == net.minecraft.entity.EquipmentSlot.Type.HUMANOID_ARMOR
                    && !e.getEquippedStack(slot).isEmpty()) {
                i++;
            }
        }

        if (!e.getMainHandStack().isEmpty()) {
            i++;
        }

        final net.minecraft.client.font.TextRenderer font = mc.textRenderer;
        float rectLength = 35 + font.getWidth(e.getName().getString()) + 40;
        float health = (float) (Math.round(hp * 100.0) / 100.0);

        if (health > maxHP) {
            health *= maxHP / health;
        }

        float amplifier = 100 / maxHP, percent = health * amplifier, space = (rectLength - 50) / 100;
        cc.novoline.utils.ScaledResolution sr = new cc.novoline.utils.ScaledResolution(mc);

        if (aura.getThx().get() > sr.getScaledWidthStatic(mc) - 50) {
            aura.getThx().set(sr.getScaledWidthStatic(mc) - 50);
        }

        if (aura.getThy().get() > sr.getScaledHeightStatic(mc) - 50) {
            aura.getThy().set(sr.getScaledHeightStatic(mc) - 50);
        }

        final int i2 = aura.getThx().get();
        final int i1 = aura.getThy().get();

        if (percent < lastP) {
            diffP = lastP - percent;
        }
        lastP = percent;
        if (diffP > 0) {
            diffP = diffP + (0 - diffP) * 0.05f;
        }

        diffP = net.minecraft.util.math.MathHelper.clamp(diffP, 0, 100 - percent);

        drawBorderedRect(i2, i1 - 1.5f, i2 + rectLength - 6, i1 + 37.5, 1f,
                new Color(0, 0, 0, 50).getRGB(), new Color(29, 29, 29, 130).getRGB());
        drawRect(i2 + 1, i1, i2 + rectLength - 7, i1 + 36, new Color(40, 40, 40, 130).getRGB());

        if (e instanceof net.minecraft.client.network.AbstractClientPlayerEntity) {
            net.minecraft.util.Identifier skin =
                    ((net.minecraft.client.network.AbstractClientPlayerEntity) e).getSkin().body().texturePath();
            guiTexturedQuad(skin, RenderPipelines.GUI_TEXTURED,
                    i2 + 1.5f, i1 + 0.2f, i2 + 1.5f + 35.2f, i1 + 0.2f + 35.2f,
                    8f / 64f, 8f / 64f, 16f / 64f, 16f / 64f, 0xffffffff);
        }

        int hudColor = cc.novoline.Novoline.getInstance().getModuleManager()
                .getModule(cc.novoline.modules.visual.HUD.class).getHUDColor();
        drawRect(i2 + 40, i1 + 16.5f, i2 + 40 + 100 * space, i1 + 27.3f, new Color(0, 0, 0, 50).getRGB());
        drawRect(i2 + 40, i1 + 16.5f, i2 + 40 + percent * space, i1 + 27.3f, hudColor);
        drawRect(i2 + 40 + percent * space, i1 + 16.5f, i2 + 40 + percent * space + diffP * space, i1 + 27.3f,
                new Color(hudColor).darker().getRGB());
        String text = String.format("%.1f", percent) + "%";
        ctx.drawText(font, text, (int) (i2 + 40 + 50 * space - font.getWidth(text) / 2f),
                (int) (i1 + 18f), 0xffffffff, true);
        ctx.drawText(font, e.getName().getString(), i2 + 40, i1 + 4, 0xffffffff, true);
    }
}
