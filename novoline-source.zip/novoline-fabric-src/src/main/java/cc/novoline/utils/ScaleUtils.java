package cc.novoline.utils;

import cc.novoline.gui.screen.click.DiscordGUI;
import net.minecraft.client.MinecraftClient;

import static cc.novoline.utils.RenderUtils.context;

public class ScaleUtils {


    public static int[] getScaledMouseCoordinates(MinecraftClient mc, int mouseX, int mouseY) {
        int x = mouseX;
        int y = mouseY;
        switch (mc.options.getGuiScale().getValue()) {
            case 0:
                x *= 2;
                y *= 2;
                break;
            case 1:
                x *= 0.5;
                y *= 0.5;
                break;
            case 3:
                x *= 1.4999999999999999998;
                y *= 1.4999999999999999998;
        }
        return new int[]{x, y};
    }


    public static double[] getScaledMouseCoordinates(MinecraftClient mc, double mouseX, double mouseY) {
        double x = mouseX;
        double y = mouseY;
        switch (mc.options.getGuiScale().getValue()) {
            case 0:
                x *= 2;
                y *= 2;
                break;
            case 1:
                x *= 0.5;
                y *= 0.5;
                break;
            case 3:
                x *= 1.4999999999999999998;
                y *= 1.4999999999999999998;
        }
        return new double[]{x, y};
    }


    public static void scale(MinecraftClient mc) {
        if (!(mc.currentScreen instanceof DiscordGUI)) {
            // PORT: GlStateManager.scale -> Matrix3x2fStack.scale. The 2D GUI matrix
            // stack has no z axis, so the former uniform 3D scale becomes 2D.
            switch (mc.options.getGuiScale().getValue()) {
                case 0:
                    context().getMatrices().scale(0.5f, 0.5f);
                    break;
                case 1:
                    context().getMatrices().scale(2, 2);
                    break;
                case 3:
                    context().getMatrices().scale(0.6666666666666667f, 0.6666666666666667f);
            }
        }
    }


}
