package cc.novoline.utils;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.util.Identifier;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Custom render layers that have no vanilla equivalent in 1.21.11 — mostly
 * no-depth-test variants used by Chams/ChestESP "see through walls" rendering.
 */
public final class NovolineRenderLayers {

    /** Entity model pipeline with depth testing fully disabled (chams). */
    private static final RenderPipeline CHAMS_PIPELINE = RenderPipeline.builder(RenderPipelines.ENTITY_SNIPPET)
        // withLocation(String) goes through Identifier.ofVanilla — a namespaced
        // literal would put an illegal ':' in the path; use Identifier.of
        .withLocation(Identifier.of("novoline", "pipeline/chams"))
        .withShaderDefine("ALPHA_CUTOUT", 0.1F)
        .withShaderDefine("PER_FACE_LIGHTING")
        .withSampler("Sampler1")
        .withBlend(BlendFunction.TRANSLUCENT)
        .withCull(false)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withDepthWrite(false)
        .build();

    /** World-space quads with no depth test (see-through block ESP). */
    private static final RenderPipeline NO_DEPTH_QUADS_PIPELINE = RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
        .withLocation(Identifier.of("novoline", "pipeline/no_depth_quads"))
        .withBlend(BlendFunction.TRANSLUCENT)
        .withCull(false)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withDepthWrite(false)
        .build();

    /** Line pipeline with no depth test (see-through skeleton ESP). */
    private static final RenderPipeline NO_DEPTH_LINES_PIPELINE = RenderPipeline.builder(RenderPipelines.RENDERTYPE_LINES_SNIPPET)
        .withLocation(Identifier.of("novoline", "pipeline/no_depth_lines"))
        .withCull(false)
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .withDepthWrite(false)
        .build();

    private static final RenderLayer NO_DEPTH_QUADS_LAYER = RenderLayer.of(
        "novoline_no_depth_quads", RenderSetup.builder(NO_DEPTH_QUADS_PIPELINE).translucent().build());

    private static final RenderLayer NO_DEPTH_LINES_LAYER = RenderLayer.of(
        "novoline_no_depth_lines", RenderSetup.builder(NO_DEPTH_LINES_PIPELINE).build());

    private static final Map<Identifier, RenderLayer> CHAMS_LAYERS = new ConcurrentHashMap<>();

    private NovolineRenderLayers() {
    }

    /** See-through quads layer for block ESP geometry (camera-relative coords). */
    public static RenderLayer noDepthQuads() {
        return NO_DEPTH_QUADS_LAYER;
    }

    /** See-through lines layer for skeleton/wireframe ESP (camera-relative coords). */
    public static RenderLayer noDepthLines() {
        return NO_DEPTH_LINES_LAYER;
    }

    /** See-through entity layer bound to {@code texture} — one instance per texture. */
    public static RenderLayer chams(Identifier texture) {
        return CHAMS_LAYERS.computeIfAbsent(texture, t -> RenderLayer.of("novoline_chams",
            RenderSetup.builder(CHAMS_PIPELINE)
                .texture("Sampler0", t)
                .useLightmap()
                .useOverlay()
                .translucent()
                .build()));
    }
}
