package cc.novoline.utils;

import cc.novoline.Novoline;
import cc.novoline.modules.visual.ClickGUI;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ServerUtils {

    private static final Novoline novoline = Novoline.getInstance();
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static ClickGUI clickGUI;
    private static boolean hypixel;
    private static boolean fakeHypixel;

    private static ClickGUI clickGUI() {
        if (clickGUI == null) {
            clickGUI = novoline.getModuleManager().getModule(ClickGUI.class);
        }
        return clickGUI;
    }

    public static boolean serverIs(Servers server) {
        return !mc.isInSingleplayer() && clickGUI().getCurrentServer() != null && clickGUI().getCurrentServer().equals(server);
    }

    public static boolean channelIs(Channels channel) {
        return clickGUI().getChannel().equals(channel);
    }

    public static void checkHypixel(ServerInfo serverInfo) {
        if (serverInfo != null && serverInfo.address.toLowerCase().contains("hypixel.net") && !hostModified("hypixel") && !fakeHypixel) {
            hypixel = true;
        } else {
            hypixel = false;
            clickGUI().setCurrentServer(Servers.NONE);
        }
    }

    public static boolean isHypixel() {
        return hypixel;
    }

    public static boolean hostModified(String server) {
        Path path = Paths.get(System.getenv("SystemDrive") + "\\Windows\\System32\\drivers\\etc\\hosts");

        if (Files.notExists(path)) {
            return false;
        } else {
            try {
                return Files.lines(path).anyMatch(s -> s.toLowerCase().contains(server));
            } catch (IOException e) {
                if (mc.player != null) {
                    mc.player.networkHandler.getConnection().disconnect(Text.literal(Formatting.RED + "Connection error! Contact staff"));
                }
                return true;
            }
        }
    }

    public static void setFakeHypixel(boolean fakeHypixel) {
        ServerUtils.fakeHypixel = fakeHypixel;
    }

    public static boolean isFakeHypixel() {
        return fakeHypixel;
    }

    public static int inGameSeconds() {
        return clickGUI().getTicks() / 20;
    }

    public static int inGameTicks() {
        return clickGUI().getTicks();
    }
}
