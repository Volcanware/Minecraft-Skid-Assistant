package cc.novoline.events.events;

import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.Entity;

public class UpdateModelEvent implements Event {

    private BipedEntityModel<?> modelPlayer;
    private Entity entity;

    public UpdateModelEvent(Entity entity, BipedEntityModel<?> modelPlayer) {
        this.modelPlayer = modelPlayer;
        this.entity = entity;
    }

    public Entity getEntity() {
        return entity;
    }

    public BipedEntityModel<?> getModelPlayer() {
        return modelPlayer;
    }
}
