package cc.novoline.events.events.callables;

import cc.novoline.events.events.Cancellable;
import cc.novoline.events.events.Event;

public abstract class CancellableEvent implements Event, Cancellable {

    private boolean cancelled;

    protected CancellableEvent() {
    }

    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }

    @Override
    public void setCancelled(boolean state) {
        this.cancelled = state;
    }
}
