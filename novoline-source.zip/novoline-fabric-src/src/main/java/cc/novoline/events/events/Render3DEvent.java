package cc.novoline.events.events;

import net.minecraft.client.util.math.MatrixStack;

public class Render3DEvent implements Event {

    private final float partialTicks;
    private final MatrixStack matrixStack;

    public Render3DEvent(float partialTicks, MatrixStack matrixStack) {
        this.partialTicks = partialTicks;
        this.matrixStack = matrixStack;
    }

    public float getPartialTicks() {
        return this.partialTicks;
    }

    public MatrixStack getMatrixStack() {
        return matrixStack;
    }
}
