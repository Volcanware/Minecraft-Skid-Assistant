package cc.novoline.events.events;

import cc.novoline.Novoline;
import cc.novoline.modules.combat.KillAura;
import cc.novoline.modules.move.TargetStrafe;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;

public class MoveEvent implements Event {

    private double x, y, z;

    public MoveEvent(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public double getX() {
        return this.x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return this.y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getZ() {
        return this.z;
    }

    public void setZ(double z) {
        this.z = z;
    }

    public void setMoveSpeed(double moveSpeed) {
        Novoline novoline = Novoline.getInstance();
        MinecraftClient mc = MinecraftClient.getInstance();
        KillAura killAura = novoline.getModuleManager().getModule(KillAura.class);
        TargetStrafe targetStrafe = novoline.getModuleManager().getModule(TargetStrafe.class);
        Input movementInput = mc.player.input;
        Vec2f vec = movementInput.getMovementInput();
        double moveForward = vec.y;
        double moveStrafe = vec.x;
        double yaw = mc.player.getYaw();
        double modifier = moveForward == 0.0F ? 90.0F : moveForward < 0.0F ? -45.0F : 45.0F;
        boolean moving = moveForward != 0 || moveStrafe != 0;
        yaw += moveForward < 0.0F ? 180.0F : 0.0F;

        if (moveStrafe < 0.0F) {
            yaw += modifier;
        } else if (moveStrafe > 0.0F) {
            yaw -= modifier;
        }

        if (moving) {
            if (targetStrafe.isEnabled() && killAura.isEnabled() && killAura.getTarget() != null && killAura.shouldAttack() && targetStrafe.shouldTarget()) {
                targetStrafe.circleStrafe(this, moveSpeed, killAura.getTarget());
            } else {
                setX(-(MathHelper.sin((float) Math.toRadians(yaw)) * moveSpeed));
                setZ(MathHelper.cos((float) Math.toRadians(yaw)) * moveSpeed);
            }
        } else {
            setX(0);
            setZ(0);
        }
    }
}
