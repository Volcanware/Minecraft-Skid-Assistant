package cc.novoline.events;

/**
 * @author DarkMagician6
 * @since July 30, 2013
 */
public final class EventAPI {
    public static final String VERSION = "0.7";
    public static final String[] AUTHORS = { "DarkMagician6" };

    private EventAPI() {
    }
}
