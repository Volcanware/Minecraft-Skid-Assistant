package cc.novoline.events.events.callables;

import cc.novoline.events.events.Event;
import cc.novoline.events.events.Typed;

public abstract class TypedEvent implements Event, Typed {

    private final byte type;

    protected TypedEvent(byte eventType) {
        this.type = eventType;
    }

    @Override
    public byte getType() {
        return this.type;
    }
}
