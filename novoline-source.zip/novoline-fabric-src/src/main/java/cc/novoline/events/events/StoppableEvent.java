package cc.novoline.events.events;

public abstract class StoppableEvent implements Event {

    private boolean stopped;

    protected StoppableEvent() {
    }

    public void stop() {
        this.stopped = true;
    }

    public boolean isStopped() {
        return this.stopped;
    }
}
