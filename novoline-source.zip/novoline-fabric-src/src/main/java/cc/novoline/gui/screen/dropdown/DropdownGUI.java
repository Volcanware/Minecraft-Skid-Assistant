package cc.novoline.gui.screen.dropdown;

import cc.novoline.Novoline;
import cc.novoline.gui.screen.dropdown.config.ConfigTab;
import cc.novoline.gui.screen.setting.Manager;
import cc.novoline.gui.screen.setting.Setting;
import cc.novoline.modules.EnumModuleType;
import cc.novoline.modules.visual.ClickGUI;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.ScaleUtils;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class DropdownGUI extends Screen {

    private final List<Tab> tabs = new CopyOnWriteArrayList<>();

    // PORT: `mc.previousScreen` was a patched field in 1.8.9; nothing equivalent exists in
    // 1.21.11. A ScreenMixin hook should capture the previously displayed screen into this
    // field (see hooks: MinecraftClient#setScreen previous-screen tracking).
    public static Screen previousScreen;

    private boolean dragging;
    private int dragX;
    private int dragY;
    private int alpha;

    public DropdownGUI() {
        super(Text.literal(""));
    }

    @Override
    protected void init() {
        float x = 75;
        alphaBG = 0;

        if (tabs.isEmpty()) {
            for (EnumModuleType value : EnumModuleType.values()) {
                tabs.add(new Tab(value, x, 10));
                x += 110;
            }

            tabs.add(new ConfigTab(x, 10));
        }

        if (!(previousScreen instanceof GenericContainerScreen) && previousScreen != this) {
            for (Tab tab : tabs) {
                for (Module module : tab.modules) {
                    module.fraction = 0;

                    for (cc.novoline.gui.screen.dropdown.Setting setting : module.settings) {
                        setting.setPercent(0);
                    }
                }

                if (tab instanceof ConfigTab) {
                    ((ConfigTab) tab).refreshConfigs();
                }
            }
        }

        // PORT: `mc.entityRenderer.loadShader(blur.json)` is gone; the vanilla menu blur
        // post-processor replaces it and is applied in render() when the option is on.

        super.init();
    }

    @Override
    public void removed() {
        // PORT: no shader group to delete; the blur post-processor clears itself.
        super.removed();
    }

    int alphaBG = 0;

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float partialTicks) {
        RenderUtils.setContext(context);

        if (Novoline.getInstance().getModuleManager().getModule(ClickGUI.class).getBlur().get()) {
            context.applyBlur();
        }

        context.getMatrices().pushMatrix();
        cc.novoline.utils.ScaledResolution scaledResolution = new cc.novoline.utils.ScaledResolution(client);
        int x = ScaleUtils.getScaledMouseCoordinates(client, mouseX, mouseY)[0];
        int y = ScaleUtils.getScaledMouseCoordinates(client, mouseX, mouseY)[1];
        // PORT: ScaleUtils.scale(mc) -> scale the GUI matrix from screen space to the
        // "static" (forced scale factor 2) coordinate space the dropdown GUI is drawn in.
        context.getMatrices().scale((float) (scaledResolution.getScaledWidth_double() / scaledResolution.getScaledWidthStatic(client)),
                (float) (scaledResolution.getScaledHeight_double() / scaledResolution.getScaledHeightStatic(client)));
        RenderUtils.drawRect(0, 0, scaledResolution.getScaledWidthStatic(client), scaledResolution.getScaledHeightStatic(client), new Color(0, 0, 0, 120).getRGB());
        for (Tab tab : tabs) {
            tab.drawScreen(x, y);
            if (tab.dragging) {
                tab.setPosX(dragX + x);
                tab.setPosY(dragY + y);
            }
        }

        context.getMatrices().popMatrix();
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // PORT: 1.8.9 GuiScreen.drawScreen drew no background dim; keep the world visible.
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        int mouseX = (int) click.x();
        int mouseY = (int) click.y();
        int mouseButton = click.button();

        int x = ScaleUtils.getScaledMouseCoordinates(client, mouseX, mouseY)[0];
        int y = ScaleUtils.getScaledMouseCoordinates(client, mouseX, mouseY)[1];
        for (Tab tab : tabs) {
            if (tab.isHovered(x, y) && mouseButton == 0) {
                if (!anyDragging()) {
                    tab.dragging = true;
                    dragX = (int) (tab.getPosX() - x);
                    dragY = (int) (tab.getPosY() - y);
                }
            }
            tab.mouseClicked(x, y, mouseButton);
        }
        return super.mouseClicked(click, doubled);
    }

    private boolean anyDragging() {
        for (Tab tab : tabs) {
            if (tab.dragging) {
                return true;
            }
        }
        return false;
    }

    protected void keyTyped(char typedChar, int keyCode) {
        if (keyCode == Keyboard.KEY_ESCAPE && !areAnyHovered()) {
            client.setScreen(null);
        } else {
            tabs.forEach(tab -> tab.keyTyped(typedChar, keyCode));
        }

    }

    @Override
    public boolean keyPressed(KeyInput input) {
        keyTyped('\0', Keyboard.fromGlfw(input.key()));
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (input.isValidChar()) {
            keyTyped((char) input.codepoint(), Keyboard.getEventKey());
        }
        return true;
    }

    private boolean areAnyHovered() {
        for (Setting setting : Manager.getSettingList()) {
            if (setting.isTextHovered()) {
                System.out.println(setting.getDisplayName());
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseReleased(Click click) {
        int mouseX = (int) click.x();
        int mouseY = (int) click.y();
        int state = click.button();

        if (state == 0) {
            tabs.forEach(tab -> tab.dragging = false);
        }

        tabs.forEach(tab -> tab.mouseReleased(mouseX, mouseY, state));
        return super.mouseReleased(click);
    }

    public List<Tab> getTabs() {
        return tabs;
    }
}
