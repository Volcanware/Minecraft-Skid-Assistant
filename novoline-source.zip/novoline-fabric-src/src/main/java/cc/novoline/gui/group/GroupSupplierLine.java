package cc.novoline.gui.group;

import org.jetbrains.annotations.NotNull;

import java.util.function.Function;

/**
 * @author xDelsy
 */
public class GroupSupplierLine<T> implements GroupLine<T> {

    /* fields */
    @NotNull
    private final Function<T, String> stringFunction;

    /* constructors */
    protected GroupSupplierLine(@NotNull Function<T, String> stringFunction) {
        this.stringFunction = stringFunction;
    }

    @NotNull
    static <T> GroupSupplierLine<T> of(@NotNull Function<T, String> stringFunction) {
        return new GroupSupplierLine<>(stringFunction);
    }

    /* methods */
    @Override
    public String getText(T t) {
        return this.stringFunction.apply(t);
    }

}
