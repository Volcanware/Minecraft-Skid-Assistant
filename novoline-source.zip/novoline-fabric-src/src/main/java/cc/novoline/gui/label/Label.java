package cc.novoline.gui.label;

import cc.novoline.gui.Element;
import cc.novoline.utils.fonts.api.FontRenderer;
import java.awt.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author xDelsy
 */
public interface Label extends Element {

    @Nullable String getText();

    void setText(@Nullable String text);

    int getColor();

    void setColor(int color);

    default void setColor(@NotNull Color color) {
        setColor(color.getRGB());
    }

    @NotNull FontRenderer getFontRenderer();

    void setFontRenderer(@NotNull FontRenderer fontRenderer);

    default int getWidth() {
        return getFontRenderer().stringWidth(getText());
    }

}
