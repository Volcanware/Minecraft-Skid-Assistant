package cc.novoline.gui.button;

import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.fonts.api.FontRenderer;
import java.awt.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.sound.SoundEvents;
import org.jetbrains.annotations.NotNull;

/**
 * PORT: standalone reimplementation of the 1.8.9 GuiButton-based RoundedButton —
 * the screens manage it manually (drawButton / mousePressed / playPressSound),
 * so it is not a vanilla widget anymore.
 *
 * @author xDelsy
 */
public class RoundedButton {

    public int id;
    public String displayString;
    public int xPosition;
    public int yPosition;
    public int width;
    public int height;
    public boolean enabled = true;
    public boolean visible = true;
    protected boolean hovered;

    private final int radius;
    private final FontRenderer fontRenderer;

    public RoundedButton(String buttonText,
                         int id,
                         int x,
                         int y,
                         int width,
                         int height,
                         int radius,
                         @NotNull FontRenderer fontRenderer) {
        this.displayString = buttonText;
        this.id = id;
        this.xPosition = x;
        this.yPosition = y;
        this.width = width;
        this.height = height;
        this.radius = radius;
        this.fontRenderer = fontRenderer;
    }

    public RoundedButton(String buttonText,
                         int id,
                         int x,
                         int y,
                         int radius,
                         @NotNull FontRenderer fontRenderer) {
        this(buttonText, id, x, y, 200, 20, radius, fontRenderer);
    }

    public void drawButton(MinecraftClient mc, int mouseX, int mouseY) {
        if (!visible) {
            return;
        }

        this.hovered = mouseX >= xPosition && mouseY >= yPosition && mouseX < xPosition + width && mouseY < yPosition + height;
        int alpha = !hovered ? 75 : 100;

        RenderUtils.drawRoundedRect(xPosition,
                yPosition + 1, width, height,
                radius,
                0x000000 | alpha << 24);
        mouseDragged(mc, mouseX, mouseY);

        fontRenderer.drawString(displayString, // @off
                xPosition + (width - fontRenderer.stringWidth(displayString)) / 2.0F,
                yPosition + 2 + (height - fontRenderer.getHeight()) / 2.0F,
                new Color(198, 198, 198).getRGB()); // @on
    }

    public boolean mousePressed(MinecraftClient mc, int mouseX, int mouseY) {
        return this.enabled && this.visible
            && mouseX >= xPosition && mouseY >= yPosition
            && mouseX < xPosition + width && mouseY < yPosition + height;
    }

    public void playPressSound(@NotNull SoundManager soundManager) {
        soundManager.play(PositionedSoundInstance.ui(SoundEvents.UI_BUTTON_CLICK.value(), 1.0F));
    }

    /* PORT: GuiButton.mouseDragged(Minecraft, int, int) hook called from drawButton; no-op as before */
    protected void mouseDragged(MinecraftClient mc, int mouseX, int mouseY) {
    }

    //region Lombok
    public int getRadius() { return radius; }
    //endregion
}
