package cc.novoline.gui.screen.alt.repository;

import cc.novoline.Novoline;

import static cc.novoline.Novoline.getLogger;

import cc.novoline.gui.screen.alt.login.AltLoginThread;
import cc.novoline.gui.screen.alt.login.AltType;
import cc.novoline.gui.screen.alt.login.SessionUpdatingAltLoginListener;
import cc.novoline.gui.screen.alt.repository.credential.AltCredential;
import cc.novoline.gui.screen.alt.repository.hypixel.HypixelProfile;
import cc.novoline.gui.screen.alt.repository.hypixel.HypixelProfileFactory;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.Timer;

import static cc.novoline.utils.fonts.impl.Fonts.SFBOLD.SFBOLD_12.SFBOLD_12;
import static cc.novoline.utils.fonts.impl.Fonts.SFBOLD.SFBOLD_20.SFBOLD_20;
import static cc.novoline.utils.fonts.impl.Fonts.SFTHIN.SFTHIN_12.SFTHIN_12;

import cc.novoline.utils.java.Checks;
import cc.novoline.utils.minecraft.FakeEntityPlayer;
import cc.novoline.utils.notifications.NotificationType;
import cc.novoline.utils.web.JsonObtainer;
import com.google.gson.JsonObject;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import java.awt.*;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ForkJoinPool;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.session.Session;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author xDelsy
 */
public class Alt {

    private static final GameProfile FAKE_GAME_PROFILE = new GameProfile(new UUID(0, 0), "Ловушка джокера");
    static final FakeEntityPlayer FAKE_ENTITY_PLAYER = new FakeEntityPlayer(FAKE_GAME_PROFILE, null);

    /* fields */
    private final AltRepositoryGUI repository;

    private final AltCredential credential;
    private FakeEntityPlayer player;
    private HypixelProfile hypixelProfile;
    private long unbanDate;

    private String rank;
    private double networkLevel;
    private boolean invalid;

    /* constructors */
    public Alt(@NotNull AltCredential credential,
               @NotNull FakeEntityPlayer player,
               @Nullable HypixelProfile hypixelProfile,
               @NotNull AltRepositoryGUI repository, Long unbanDate, String rank, double networkLevel, boolean invalid) {
        this.repository = repository;
        this.credential = credential;
        this.player = player;
        this.hypixelProfile = hypixelProfile;
        this.unbanDate = unbanDate;
        this.networkLevel = networkLevel;
        this.rank = rank;
        this.invalid = invalid;
    }

    /* methods */
    protected boolean mouseClicked(float width, float y, int mouseX, int mouseY) {
        if (!isHovered(width, y, mouseX, mouseY)) return false;

        if (Util.getMeasuringTimeMs() - lastClickTime < 250L) {
            logIn(true);
        } else {
            select();
        }

        this.lastClickTime = Util.getMeasuringTimeMs();
        return true;
    }

    public void drawAlt(float width, int y, int mouseX, int mouseY) {
        //region Rendering alt box
        RenderUtils.drawRoundedRect(AltRepositoryGUI.HORIZONTAL_MARGIN, y, width, AltRepositoryGUI.PLAYER_BOX_HEIGHT, 5,
                (!isSelected() ? DEFAULT_COLOR : SELECTED_COLOR));

        if (triedAuthorizing() && alpha > 0) {
            RenderUtils.drawRoundedRect(AltRepositoryGUI.HORIZONTAL_MARGIN, y, animationX,
                    AltRepositoryGUI.PLAYER_BOX_HEIGHT, 5, (int) Math.max(0, alpha) << 24 | (isLoginSuccessful() ?
                            SUCCESS_LOGIN_COLOR :
                            FAILED_LOGIN_COLOR));
            renderAltBox(width, mouseX, mouseY);
        }

        //endregion
        //region Rendering skull with name
        // if(this.player != null) { /* rendering skull */
        drawSkull(player, y);
        SFBOLD_20.drawString((invalid ? Formatting.STRIKETHROUGH : "") + player.getName().getString(), 53, y + 3, TEXT_SELECTED_COLOR);
		/*} else {
			drawSkull(FAKE_ENTITY_PLAYER, y);
			Fonts.SFBOLD_20.drawString("<Unknown Name>", 53, y + 3, TEXT_SELECTED_COLOR);
		}*/
        //endregion
        //region Rendering player-related info
        SFBOLD_12.drawString("Email: " + credential.getLogin(), 53, y + AltRepositoryGUI.HORIZONTAL_MARGIN,
                TEXT_SELECTED_COLOR);

        String password = credential.getPassword();

        if (StringUtils.isNotBlank(password)) {
            // рендер пароля двумя строками для смещения символа пароля на 2 пикселя вниз (больно уж он высоко иначе находится)
            SFBOLD_12.drawString("Password:", 53, y + 24, TEXT_SELECTED_COLOR);
            SFBOLD_12.drawString(new String(new char[password.length()]).replace('\0', '*'),
                    SFTHIN_12.stringWidth("Password:") + 57, y + 25, TEXT_SELECTED_COLOR);
        } /*else if(hypixelProfile != null) {
			FBOLD.kiona12.drawString("Level: " + hypixelProfile.getLevel(), 53, y + 24, TEXT_SELECTED_COLOR);
		}*/
        //endregion
        //region Выделение залогиненного аккаунта
        if (repository.getCurrentAlt() == this) {
            SFBOLD_20.drawString("Logged", width - 35, y + AltRepositoryGUI.PLAYER_BOX_HEIGHT / 2F - 5,
                    new Color(255, 255, 255, 50).getRGB());
        }

        if (unbanDate != -1) {
            if (unbanDate - System.currentTimeMillis() < 0) {
                unbanDate = 0;
            }
        }

        if (unbanDate != 0) {
            String unbansIn;
            if (unbanDate != -1) {
                int seconds = (int) ((unbanDate - System.currentTimeMillis()) / 1000);
                String days = seconds > 86400 ? (seconds / 86400) + "d " : "";
                seconds = !days.equals("") ? seconds % 86400 : seconds;
                String hours = seconds > 3600 ? seconds / 3600 + "h " : "";
                seconds = !hours.equals("") ? seconds % 3600 : seconds;
                String minutes = seconds > 60 ? seconds / 60 + "m " : "";
                unbansIn = days + hours + minutes;
            } else {
                unbansIn = "Permed";
            }

            SFBOLD_20.drawString(unbansIn, width - SFBOLD_20.stringWidth(unbansIn) - (repository.getCurrentAlt() == this ? 45 : 0) + 5, y + AltRepositoryGUI.PLAYER_BOX_HEIGHT / 2F - 5,
                    TEXT_SELECTED_COLOR);
        }

        //endregion
    }

    private void drawSkull(@NotNull FakeEntityPlayer player, int scrolled) {
        MinecraftClient mc = MinecraftClient.getInstance();

        // PORT: was texture bind + drawScaledCustomSizeModalRect (face region of the skin)
        RenderUtils.context().drawTexture(RenderPipelines.GUI_TEXTURED, player.getLocationSkin(),
                18, scrolled + 2, 8.0F, 8.0F, 32, 32, 8, 8, 64, 64);
    }

    private final Timer timer = new Timer();
    private float alpha = 255;
    private float animationX = 0;

    private void renderAltBox(float width, int mouseX, int mouseY) {
        float altBoxAlphaStep = repository.getAltBoxAlphaStep();

        if (timer.delay(UPDATE_MILLIS_DELAY) && alpha > 0) {
            this.alpha -= altBoxAlphaStep;
            timer.reset();
        }

        if (animationX < width) {
            this.animationX = Math.min(animationX + repository.getAltBoxAnimationStep(), width);
        }
    }

    private long lastTimeAlreadyLogged;

    public CompletableFuture<Session> logIn(boolean trippsol) {
        CompletableFuture<Session> sessionCompletableFuture = CompletableFuture.supplyAsync(() -> {
            Session session = null;

            if (!isLoggingIn() && !isLoginSuccessful()) {
                setLoggingIn(true);

                session = new AltLoginThread(credential, new SessionUpdatingAltLoginListener() {

                    @Override
                    public void onLoginSuccess(AltType type, Session session) {
                        super.onLoginSuccess(type, session);

                        repository.getAlts().forEach(Alt::resetLogged);
                        repository.setCurrentAlt(Alt.this);
                        setGameProfile(new GameProfile(session.getUuidOrNull(), session.getUsername()));
                        setLoginProperty(true);
                        setInvalid(false);

                        if (hypixelProfile != null) {
                            Novoline.getInstance().getNotificationManager().pop("Logged in! " + Alt.this.toString(), NotificationType.INFO);
                        }

                        try {
                            JsonObject object = JsonObtainer.obtainJson("https://api.sk1er.club/player/" + session.getUsername());
                            if (!object.has("success") || !object.get("success").getAsBoolean()) {
                                if (object.has("cause") && object.get("cause").getAsString().equals("non-player")) {
                                    rank = "Never logged in";
                                } else {
                                    rank = "API DOWN";
                                }
                                networkLevel = 1;
                            } else {
                                JsonObject player = object.getAsJsonObject("player");
                                networkLevel = player.has("networkLevel") ? player.get("networkLevel").getAsDouble() : 0;
                                rank = player.has("rank_for_mod") ? player.get("rank_for_mod").getAsString() : null;
                            }
                        } catch (Exception e) {

                        }

                    }

                    @Override
                    public void onLoginFailed() {
                        setLoginProperty(false);
                        setInvalid(true);
                        Novoline.getInstance().getNotificationManager().pop("Invalid credentials!", NotificationType.ERROR);
                    }
                }).run();

                setLoggingIn(false);

                this.alpha = 255;
                this.animationX = 0;
            } else if (isLoggingIn()) {
                if (System.currentTimeMillis() > lastTimeAlreadyLogged + 150) {
                    Novoline.getInstance().getNotificationManager().pop("Already trying logging in!", NotificationType.ERROR);
                    this.lastTimeAlreadyLogged = System.currentTimeMillis();
                }
            } else if (isLoginSuccessful()) {
                if (System.currentTimeMillis() > lastTimeAlreadyLogged + 150) {
                    Novoline.getInstance().getNotificationManager().pop("Already logged in!", NotificationType.ERROR);
                    this.lastTimeAlreadyLogged = System.currentTimeMillis();
                }
            }

            return session;
        }, ForkJoinPool.commonPool());

        if (/*trippsol*/true) {
            return sessionCompletableFuture.whenCompleteAsync((session, throwable) -> {
                if (throwable != null) {
                    getLogger().warn("An error occurred while logging in!", throwable);
                    return;
                }

                if (isLoginSuccessful() && session != null && session.getUuidOrNull() != null) {
                    boolean wasNull = hypixelProfile == null;

                    try {
                        Novoline.getInstance().getNotificationManager().pop("Logged in! " + toString(), NotificationType.SUCCESS);

                        repository.saveAlts();
                    } catch (Throwable t) {
                        getLogger().warn("An unexpected error occurred while loading Hypixel profile!", t);
                    }
                }
            });
        } else {
            return sessionCompletableFuture;
        }
    }

    //region State-related stuff
    private static final byte SELECTED_POSITION = 0;
    private static final byte AUTHORIZED_POSITION = 1;
    private static final byte LOGGED_POSITION = 2;
    private static final byte LOGGING_IN_POSITION = 3;

    /**
     * & 0b100: 1 — сейчас в этом аккаунте, 0 — пытался войти, но данные не подошли
     * & 0b010: 1 — пытался авторизоваться, 0 — не пытался авторизоваться
     * & 0b001: 1 — аккаунт выделен, 0 — аккаунт не выделен
     */
    private byte state = 0b000;

    private void modifyState(byte pos, boolean b) {
        byte mask = (byte) (1 << pos);

        if (!b) {
            this.state = (byte) (state & ~mask);
        } else {
            this.state = (byte) (state & ~mask | 1 << pos & mask);
        }
    }

    private boolean state(byte pos) {
        byte mask = (byte) (1 << pos);
        return (state & mask) == mask;
    }

    public void resetLogged() {
        modifyState(AUTHORIZED_POSITION, false);
        modifyState(LOGGED_POSITION, false);
    }

    private void setLoginProperty(boolean b) {
        modifyState(AUTHORIZED_POSITION, true);
        modifyState(LOGGED_POSITION, b);
    }

    public boolean isLoginSuccessful() {
        return triedAuthorizing() && state(LOGGED_POSITION);
    }

    public boolean isLoginUnsuccessful() {
        return triedAuthorizing() && !state(LOGGED_POSITION);
    }

    public boolean triedAuthorizing() {
        return state(AUTHORIZED_POSITION);
    }

    void setSelectedProperty(boolean b) {
        modifyState(SELECTED_POSITION, b);
    }

    public boolean isSelected() {
        return state(SELECTED_POSITION);
    }

    public boolean isLoggingIn() {
        return state(LOGGING_IN_POSITION);
    }

    private void setLoggingIn(boolean b) {
        modifyState(LOGGING_IN_POSITION, b);
    }

    public void setUnbanDate(long unbanDate) {
        this.unbanDate = unbanDate;
    }

    public long getUnbanDate() {
        return unbanDate;
    }

    public boolean isInvalid() {
        return invalid;
    }

    //endregion

    public void setGameProfile(@NotNull GameProfile gameProfile) {
        setupPlayer(gameProfile, null);

        MinecraftClient mc = MinecraftClient.getInstance();

        gameProfile.properties().clear();

        // PORT: was fillSessionProfileProperties + getSessionService().getTextures +
        // getSkinManager().loadSkin; the skin provider now performs the whole
        // profile fill / texture download / registration pipeline.
        mc.getSkinProvider().fetchSkinTextures(gameProfile).thenAccept(textures ->
                textures.ifPresent(skinTextures ->
                        mc.execute(() -> setupPlayer(gameProfile, skinTextures.body().texturePath()))));
    }

    void setupPlayer(@NotNull GameProfile gameProfile, @Nullable Identifier skinLocation) {
        MinecraftClient mc = MinecraftClient.getInstance();
        this.player = new FakeEntityPlayer(gameProfile, skinLocation);

        // PORT: RenderManager#cacheActiveRenderInfo no longer exists; the entity
        // render dispatcher manages the camera context per draw.
    }

    long lastClickTime;

    public void select() {
        Alt selected = repository.getAlts().stream().filter(Alt::isSelected).findAny().orElse(null);
        if (selected != null) selected.setSelectedProperty(false);

        setSelectedProperty(true);
        repository.selectAlt(selected, this, null);
    }

    private static final float MODEL_SCALE_FACTOR = 0.71F;
    private static final int MODEL_BOTTOM_MARGIN = 24;

    public void drawEntity(int mouseX, int mouseY) {
        if (player != null) {
            MinecraftClient mc = MinecraftClient.getInstance();

            int width = repository.width;
            int height = repository.height;

            final int distanceToSide = (int) (AltRepositoryGUI.HORIZONTAL_MARGIN + AltRepositoryGUI.PLAYER_BOX_WIDTH / 2F);
            float targetHeight = height / 3f * MODEL_SCALE_FACTOR;

            int posX = width - distanceToSide;
            int posY = AltRepositoryGUI.VERTICAL_MARGIN + height - AltRepositoryGUI.VERTICAL_MARGIN - 6 * 4 - 3 * AltRepositoryGUI.BUTTON_HEIGHT - MODEL_BOTTOM_MARGIN;
            int mouseX1 = width - distanceToSide - mouseX;
            float mouseY1 = height / 2F + player.getHeight() * targetHeight - player.getHeight() * targetHeight * (player
                    .getStandingEyeHeight() / player.getHeight()) - mouseY;

            // PORT: the manual GL matrix / RenderManager block was replaced by
            // InventoryScreen.drawEntity, which renders a GUI entity with the
            // same look-at-mouse head tracking.
            float size = targetHeight / player.getHeight();
            int halfWidth = (int) (player.getWidth() * size / 2);
            int entityHeight = (int) (player.getHeight() * size);

            try {
                InventoryScreen.drawEntity(RenderUtils.context(), posX - halfWidth, posY - entityHeight,
                        posX + halfWidth, posY, (int) size, 0.0625F, mouseX, mouseY, player);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    static final float FHD_ANIMATION_STEP = 5;
    private static final int UPDATES_PER_SECOND = 100;

    private static final int UPDATE_MILLIS_DELAY = 1_000 / UPDATES_PER_SECOND;

    private static final int DEFAULT_COLOR = new Color(0, 0, 0,75).getRGB();
    private static final int SELECTED_COLOR = new Color(0, 0, 0,100).getRGB();
    private static final int TEXT_DEFAULT_COLOR = 0xFF868386;
    private static final int TEXT_SELECTED_COLOR = new Color(198, 198, 198).getRGB();
    private static final int SUCCESS_LOGIN_COLOR = 0x6E8D3D;
    private static final int FAILED_LOGIN_COLOR = 0x9E3939;

    private boolean isHovered(float width, float y, int mouseX, int mouseY) {
        return mouseX >= AltRepositoryGUI.HORIZONTAL_MARGIN && mouseX <= width + AltRepositoryGUI.HORIZONTAL_MARGIN && mouseY >= y && mouseY <= y + AltRepositoryGUI.PLAYER_BOX_HEIGHT;
    }

    @NotNull
    public static Alt fromNBT(AltRepositoryGUI gui, @NotNull NbtCompound tagCompound) {
        String login = Checks.notBlank(tagCompound.getString("login", ""), "login");
        String password = tagCompound.getString("password", null);
        HypixelProfile hypixelProfile = HypixelProfileFactory.fromNBT(tagCompound.getCompound("hypixel").orElse(null));
        hypixelProfile = hypixelProfile != null ? hypixelProfile : HypixelProfile.empty();

        NbtCompound profileTag = tagCompound.getCompound("profile").orElse(null);
        GameProfile profile = readGameProfile(profileTag);
        FakeEntityPlayer fakeEntityPlayer = new FakeEntityPlayer(Objects.requireNonNull(profile), null);
        Long unbanDate = Long.parseLong(tagCompound.getString("unbanDate", null));
        String rank = "NONE";
        double networkLevel = 1;
        if (tagCompound.contains("networkLevel")) {
            networkLevel = Double.parseDouble(tagCompound.getString("networkLevel", null));
        }
        if (tagCompound.contains("rank")) {
            rank = tagCompound.getString("rank", null);
        }
        boolean invalid = false;
        if(tagCompound.contains("invalid")){
            invalid = tagCompound.getBoolean("invalid", false);
        }

        AltCredential credential = new AltCredential(login, password);
        return new Alt(credential, fakeEntityPlayer, hypixelProfile, gui, unbanDate, rank, networkLevel,invalid);
    }

    public NbtElement asNBTCompound() {
        NbtCompound compound = new NbtCompound();

        compound.putString("unbanDate", String.valueOf(unbanDate));
        compound.putString("rank", this.rank);
        compound.putString("networkLevel", String.valueOf(this.networkLevel));
        compound.putString("login", credential.getLogin());
        compound.putBoolean("invalid",invalid);
        if (credential.getPassword() != null) compound.putString("password", credential.getPassword());
        if (hypixelProfile != null) compound.put("hypixel", hypixelProfile.asNBTCompound());
        compound.put("profile", writeGameProfile(new NbtCompound(), player.getGameProfile()));
        return compound;
    }

    /* PORT: NBTUtil.writeGameProfile / readGameProfileFromNBT replacements;
       serializes the same Name/Id/Properties layout. */
    @NotNull
    private static NbtCompound writeGameProfile(@NotNull NbtCompound compound, @NotNull GameProfile profile) {
        if (!StringUtils.isEmpty(profile.name())) {
            compound.putString("Name", profile.name());
        }

        if (profile.id() != null) {
            compound.putString("Id", profile.id().toString());
        }

        if (!profile.properties().isEmpty()) {
            NbtCompound properties = new NbtCompound();

            for (String key : profile.properties().keySet()) {
                NbtList list = new NbtList();

                for (Property property : profile.properties().get(key)) {
                    NbtCompound prop = new NbtCompound();
                    prop.putString("Value", property.value());
                    if (property.signature() != null) prop.putString("Signature", property.signature());
                    list.add(prop);
                }

                properties.put(key, list);
            }

            compound.put("Properties", properties);
        }

        return compound;
    }

    @Nullable
    private static GameProfile readGameProfile(@Nullable NbtCompound compound) {
        if (compound == null) return null;

        String name = compound.getString("Name", null);
        UUID uuid = null;

        if (compound.contains("Id")) {
            try {
                uuid = UUID.fromString(compound.getString("Id", ""));
            } catch (Throwable ignored) {
            }
        }

        GameProfile profile = new GameProfile(uuid, name);

        NbtCompound properties = compound.getCompoundOrEmpty("Properties");
        for (String key : properties.getKeys()) {
            NbtList list = properties.getListOrEmpty(key);

            for (int i = 0; i < list.size(); i++) {
                NbtCompound prop = list.getCompoundOrEmpty(i);
                profile.properties().put(key, new Property(key, prop.getString("Value", ""),
                        prop.getString("Signature", null)));
            }
        }

        return profile;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("Username: " + player.getGameProfile().name());

        if (hypixelProfile != null) {
            String hypixelRank = hypixelProfile.getRank();
            int hypixelLevel = hypixelProfile.getLevel();

            if (hypixelLevel > 1) builder.append(" | ").append(hypixelLevel).append(" Lvl");
            if (hypixelRank != null && !hypixelRank.equalsIgnoreCase("default"))
                builder.append(" | ").append(hypixelRank);
        }

        return builder.toString();
    }

    //region Lombok-alternative
    public AltCredential getCredential() {
        return credential;
    }

    public double getNetworkLevel() {
        return networkLevel;
    }

    public String getRank() {
        return rank;
    }

    public void setInvalid(boolean invalid) {
        this.invalid = invalid;
    }

    public FakeEntityPlayer getPlayer() {
        return player;
    }

    public HypixelProfile getHypixelProfile() {
        return hypixelProfile;
    }
    //endregion

}
