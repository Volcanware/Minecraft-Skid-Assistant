package cc.novoline.gui;

import cc.novoline.utils.RenderUtils;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.awt.*;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import static cc.novoline.Novoline.getLogger;

/**
 * @author xDelsy
 */
public abstract class NovoGuiScreen extends Screen {

    /* fields */
    @NotNull
    private final List<Element> elements;

    /* constructors */
    public NovoGuiScreen(@Nullable Collection<Element> elements) {
        super(Text.empty()); // PORT: Screen requires a title; GuiScreen had none
        this.elements = elements == null ? new ObjectArrayList<>() : new ObjectArrayList<>(elements);
    }

    public NovoGuiScreen() {
        this(null);
    }

    /* methods */
    protected void register(@NotNull Element element) {
        elements.add(element);
        // System.out.println("Registered an element: " + element.getClass().getSimpleName());
    }

    private long lastMessageTimestamp;

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        RenderUtils.setContext(context);

        context.fillGradient(0, 0, this.width, this.height, new Color(100, 200, 200).getRGB(),
                new Color(100, 100, 200).getRGB());

        for (int i = 0; i < elements.size(); i++) {
            elements.get(i).draw(mouseX, mouseY);
        }

        if (System.currentTimeMillis() - lastMessageTimestamp >= 1_000) {
            getLogger().info("Drew: {}", elements.stream()
                    .map(element -> element.getClass().getSimpleName())
                    .collect(Collectors.groupingBy(Function.identity(), Collectors.counting())));
            this.lastMessageTimestamp = System.currentTimeMillis();
        }

        super.render(context, mouseX, mouseY, delta);
    }

    protected void onInitialize() {
    }

    protected void onClosing() {
    }

    @Override
    protected final void init() {
        elements.clear();

        onInitialize();
        super.init();
    }

    @Override
    public void removed() {
        onClosing();
        super.removed();
    }
}
