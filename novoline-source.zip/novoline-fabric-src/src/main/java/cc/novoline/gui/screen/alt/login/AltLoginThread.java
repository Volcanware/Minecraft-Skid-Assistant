package cc.novoline.gui.screen.alt.login;

import cc.novoline.gui.screen.alt.repository.credential.AltCredential;
import cc.novoline.utils.thealtening.TheAlteningAuthentication;
import cc.novoline.utils.thealtening.service.AlteningServiceType;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.session.Session;
import net.minecraft.util.Uuids;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.UUID;

public final class AltLoginThread {

    private static final TheAlteningAuthentication MOJANG = TheAlteningAuthentication.mojang();

    /* fields */
    @NotNull
    public final AltCredential credentials;
    @Nullable
    public AltLoginListener handler;
    @Nullable
    private String caller;

    // constructors
    public AltLoginThread(@NotNull AltCredential credential, @NotNull AltLoginListener handler) {
        // super("Alt Login Thread");

        this.credentials = credential;
        this.handler = handler;

        if (credential.getLogin().endsWith("@alt.com")) {
            MOJANG.updateService(AlteningServiceType.THEALTENING);
        } else {
            MOJANG.updateService(AlteningServiceType.MOJANG);
        }
    }

    public AltLoginThread(@NotNull AltCredential credential, @Nullable String caller) {
        // super("Alt Login Thread");

        this.credentials = credential;
        this.caller = caller;

        if (credential.getLogin().endsWith("@alt.com")) {
            MOJANG.updateService(AlteningServiceType.THEALTENING);
        } else {
            MOJANG.updateService(AlteningServiceType.MOJANG);
        }
    }

    /* methods */
    @Nullable
    public Session run() {
        final String password = !this.credentials.getLogin().endsWith("@alt.com") ?
                this.credentials.getPassword() :
                "1";

        if (password == null) {
            // PORT: the modern Session wants a real UUID, so the offline-mode
            // (name-derived) UUID is used instead of an empty string
            final Session crackedSession = new Session(this.credentials.getLogin(),
                    Uuids.getOfflinePlayerUuid(this.credentials.getLogin()), "", Optional.empty(), Optional.empty());

            if (this.handler != null) this.handler.onLoginSuccess(AltType.CRACKED, crackedSession);
            return crackedSession;
        }

        final Session session = createSession(this.credentials.getLogin(), password);

        if (session == null) {
            if (this.handler != null) this.handler.onLoginFailed();
            return null;
        }

        if (this.handler != null) this.handler.onLoginSuccess(AltType.PREMIUM, session);
        return session;
    }


    @Nullable
    public static Session createSession(String username, String password) {
        try {
            // PORT: authlib 7.0.61 removed YggdrasilUserAuthentication, so the
            // /authenticate call is performed manually against whichever service
            // TheAlteningAuthentication last switched to.
            final HttpURLConnection connection = (HttpURLConnection) new URL(
                    MOJANG.getService().getAuthServer() + "authenticate").openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            final JsonObject agent = new JsonObject();
            agent.addProperty("name", "Minecraft");
            agent.addProperty("version", 1);

            final JsonObject request = new JsonObject();
            request.add("agent", agent);
            request.addProperty("username", username);
            request.addProperty("password", password);
            request.addProperty("requestUser", true);

            try (OutputStream out = connection.getOutputStream()) {
                out.write(request.toString().getBytes(StandardCharsets.UTF_8));
            }

            if (connection.getResponseCode() != 200) return null;

            final JsonObject response = JsonParser.parseString(new String(
                    connection.getInputStream().readAllBytes(), StandardCharsets.UTF_8)).getAsJsonObject();

            final String accessToken = response.get("accessToken").getAsString();
            final JsonObject selectedProfile = response.getAsJsonObject("selectedProfile");

            return new Session(selectedProfile.get("name").getAsString(), toUuid(selectedProfile.get("id").getAsString()),
                    accessToken, Optional.empty(), Optional.empty());
        } catch (IOException | IllegalStateException e) {
            e.printStackTrace();
            return null;
        }
    }

    /* the authenticate response carries the undashed 32-char uuid */
    private static UUID toUuid(String undashed) {
        if (undashed.indexOf('-') >= 0) return UUID.fromString(undashed);
        return UUID.fromString(undashed.replaceFirst(
                "(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{12})",
                "$1-$2-$3-$4-$5"));
    }

}
