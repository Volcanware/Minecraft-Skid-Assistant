package cc.novoline.gui.group2;

import cc.novoline.gui.Element;
import org.jetbrains.annotations.NotNull;

import java.awt.*;

/**
 * @author xDelsy
 */
public interface Group extends Element {

    int getColor();

    void setColor(int color);

    default void setColor(@NotNull Color color) {
        setColor(color.getRGB());
    }

}
