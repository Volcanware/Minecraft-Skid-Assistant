package cc.novoline.gui.group;

import org.jetbrains.annotations.NotNull;

import java.util.function.Function;

/**
 * @author xDelsy
 */
public class GroupNullableLine<T> extends GroupSupplierLine<T> {

    protected GroupNullableLine(@NotNull Function<T, String> stringFunction) {
        super(stringFunction);
    }

    @NotNull
    static <T> GroupNullableLine<T> of(@NotNull Function<T, String> stringFunction) {
        return new GroupNullableLine<>(stringFunction);
    }

}
