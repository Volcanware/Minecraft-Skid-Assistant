package cc.novoline.gui.label;

import cc.novoline.utils.fonts.api.FontRenderer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author xDelsy
 */
public final class BasicLabel extends AbstractLabel {

    public BasicLabel(@Nullable String text, int color, @NotNull FontRenderer fontRenderer, int x, int y) {
        super(text, color, fontRenderer, x, y);
    }

    public BasicLabel(@Nullable String text, int color, @NotNull FontRenderer fontRenderer) {
        super(text, color, fontRenderer);
    }

}
