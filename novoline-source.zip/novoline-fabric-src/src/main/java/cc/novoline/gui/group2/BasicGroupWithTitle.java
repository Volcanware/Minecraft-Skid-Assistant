package cc.novoline.gui.group2;

import cc.novoline.gui.label.Label;
import org.jetbrains.annotations.Nullable;

/**
 * @author xDelsy
 */
public final class BasicGroupWithTitle extends AbstractGroupWithTitle {

    public BasicGroupWithTitle(@Nullable Label title, int color, int x, int y, int width, int height) {
        super(title, color, x, y, width, height);
    }

}
