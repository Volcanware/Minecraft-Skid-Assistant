package cc.novoline.gui.screen.menu;

import cc.novoline.Novoline;
import cc.novoline.gui.button.HydraButton;
import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.ScaledResolution;
import cc.novoline.utils.fonts.impl.Fonts;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.DynamicUniformStorage;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.awt.*;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * PORT: cc.novoline's 1.8.9 GuiMainMenu — custom title screen with the
 * raymarched shader background, sliding panel, interpolated theme colors and
 * the 5 HydraButtons (Singleplayer / Multiplayer / Alt Repository / Options /
 * Shutdown). Replaces TitleScreen via MinecraftClientMixin#setScreen.
 *
 * The fullscreen shader is drawn in its own render pass before the regular
 * GUI elements — GUI element state cannot carry custom uniform buffers, so the
 * pass writes the MenuData UBO itself.
 */
public class NovoMainMenu extends Screen {

    private static final int MENU_UBO_SIZE = new Std140SizeCalculator().putFloat().putVec2().putVec2().get();

    private static final RenderPipeline MENU_PIPELINE = RenderPipelines.register(
            RenderPipeline.builder()
                    .withLocation(Identifier.of("novoline", "pipeline/menu_background"))
                    .withVertexShader(Identifier.of("novoline", "novoline_menu"))
                    .withFragmentShader(Identifier.of("novoline", "novoline_menu"))
                    .withUniform("MenuData", net.minecraft.client.gl.UniformType.UNIFORM_BUFFER)
                    .withVertexFormat(VertexFormats.POSITION, VertexFormat.DrawMode.QUADS)
                    .withDepthTestFunction(com.mojang.blaze3d.platform.DepthTestFunction.NO_DEPTH_TEST)
                    .withCull(false)
                    .build());

    private record MenuUniforms(float time, float resX, float resY, float mouseX, float mouseY)
            implements DynamicUniformStorage.Uploadable {
        @Override
        public void write(ByteBuffer buffer) {
            Std140Builder.intoBuffer(buffer).putFloat(time).putVec2(resX, resY).putVec2(mouseX, mouseY);
        }
    }

    private final DynamicUniformStorage<MenuUniforms> menuUniforms =
            new DynamicUniformStorage<>("Novoline menu UBO", MENU_UBO_SIZE, 2);
    private GpuBuffer quadBuffer;

    public boolean darkTheme = true, guiWasSwitched;
    public int alpha = 0;

    float hHeight = 540;
    float hWidth = 960;
    public static int BUTTON_COUNT = 5;
    public float totalHeight = BUTTON_COUNT * 20 + 20 + BUTTON_COUNT * 3;
    public float halfTotalHeight = totalHeight / 2, fraction = 0;

    private final Color blackish = new Color(20, 23, 26);
    private final Color black = new Color(40, 46, 51);
    private final Color blueish = new Color(0, 150, 135);
    private final Color blue = new Color(0xFF2B71B1);

    private final List<HydraButton> buttonList = new ArrayList<>();
    private HydraButton selectedButton;

    private final HydraButton singleplayerworlds = new HydraButton(1, 0, 0, 140, 20, "Singleplayer");
    private final HydraButton multiplayer = new HydraButton(2, 0, 0, 140, 20, "Multiplayer");
    private final HydraButton altrepository = new HydraButton(1337, 0, 0, 140, 20, "Alt Repository");
    private final HydraButton options = new HydraButton(0, 0, 0, 140, 20, "Options");
    private final HydraButton shutdown = new HydraButton(4, 0, 0, 140, 20, "Shutdown");

    private final long initTime = System.currentTimeMillis();

    public NovoMainMenu() {
        super(Text.literal("Novoline"));
    }

    @Override
    protected void init() {
        buttonList.clear();
        buttonList.add(singleplayerworlds);
        buttonList.add(multiplayer);
        buttonList.add(altrepository);
        buttonList.add(options);
        buttonList.add(shutdown);
        alpha = 100;

        if (cc.novoline.gui.screen.dropdown.DropdownGUI.previousScreen != this && !guiWasSwitched) {
            guiWasSwitched = true;
        }

        darkTheme = true;

        super.init();
    }

    @Override
    public boolean shouldCloseOnEsc() {
        /* the original keyTyped() swallowed every key */
        return false;
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyInput input) {
        return true;
    }

    private GpuBuffer quadBuffer() {
        if (quadBuffer == null) {
            try (BufferAllocator allocator = BufferAllocator.fixedSized(4 * VertexFormats.POSITION.getVertexSize())) {
                BufferBuilder builder = new BufferBuilder(allocator, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION);
                builder.vertex(-1.0F, -1.0F, 0.0F);
                builder.vertex(-1.0F, 1.0F, 0.0F);
                builder.vertex(1.0F, 1.0F, 0.0F);
                builder.vertex(1.0F, -1.0F, 0.0F);
                try (BuiltBuffer built = builder.end()) {
                    quadBuffer = RenderSystem.getDevice().createBuffer(
                            () -> "Novoline menu quad", GpuBuffer.USAGE_VERTEX, built.getBuffer());
                }
            }
        }
        return quadBuffer;
    }

    /** Fullscreen pass rendering the raymarched menu shader behind the UI. */
    private void renderMenuShader(int mouseX, int mouseY) {
        MinecraftClient mc = this.client;
        Framebuffer framebuffer = mc.getFramebuffer();
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();

        GpuBufferSlice menuData = menuUniforms.write(new MenuUniforms(
                (System.currentTimeMillis() - initTime) / 1000.0F,
                framebuffer.textureWidth, framebuffer.textureHeight,
                mouseX, mouseY));

        try (RenderPass pass = encoder.createRenderPass(
                () -> "Novoline menu background",
                framebuffer.getColorAttachmentView(), OptionalInt.empty(),
                null, OptionalDouble.empty())) {
            pass.setPipeline(MENU_PIPELINE);
            pass.setUniform("MenuData", menuData);
            pass.setVertexBuffer(0, quadBuffer());
            RenderSystem.ShapeIndexBuffer indices = RenderSystem.getSequentialBuffer(VertexFormat.DrawMode.QUADS);
            pass.setIndexBuffer(indices.getIndexBuffer(6), indices.getIndexType());
            pass.drawIndexed(0, 0, 6, 1);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float partialTicks) {
        RenderUtils.setContext(context);

        if (guiWasSwitched && darkTheme && fraction != 1.0049993F) {
            fraction = 1.0049993F;
        }

        if (darkTheme && fraction < 1) {
            fraction += 0.015;
        } else if (!darkTheme && fraction > 0) {
            fraction -= 0.015;
        }

        if (mouseX <= 20 && mouseY <= 20 && alpha < 255) {
            alpha++;
        } else if (alpha > 100) {
            alpha--;
        }

        renderMenuShader(mouseX, mouseY);

        singleplayerworlds.setColor(interpolateColor(
                singleplayerworlds.hovered(mouseX, mouseY) ? blue.brighter() : blue,
                singleplayerworlds.hovered(mouseX, mouseY) ? blueish.brighter() : blueish,
                fraction));
        multiplayer.setColor(interpolateColor(
                multiplayer.hovered(mouseX, mouseY) ? blue.brighter() : blue,
                multiplayer.hovered(mouseX, mouseY) ? blueish.brighter() : blueish,
                fraction));
        altrepository.setColor(interpolateColor(
                altrepository.hovered(mouseX, mouseY) ? blue.brighter() : blue,
                altrepository.hovered(mouseX, mouseY) ? blueish.brighter() : blueish,
                fraction));
        options.setColor(interpolateColor(
                options.hovered(mouseX, mouseY) ? blue.brighter() : blue,
                options.hovered(mouseX, mouseY) ? blueish.brighter() : blueish,
                fraction));
        shutdown.setColor(interpolateColor(
                shutdown.hovered(mouseX, mouseY) ? blue.brighter() : blue,
                shutdown.hovered(mouseX, mouseY) ? blueish.brighter() : blueish,
                fraction));

        singleplayerworlds.updateCoordinates(hWidth - 70, hHeight - halfTotalHeight + 10);
        multiplayer.updateCoordinates(hWidth - 70, hHeight - halfTotalHeight + 33);
        altrepository.updateCoordinates(hWidth - 70, hHeight - halfTotalHeight + 56);
        options.updateCoordinates(hWidth - 70, hHeight - halfTotalHeight + 79);
        shutdown.updateCoordinates(hWidth - 70, hHeight - halfTotalHeight + 102);

        ScaledResolution scaledResolution = new ScaledResolution(client);
        int scaledWidthScaled = scaledResolution.getScaledWidth();
        int scaledHeightScaled = scaledResolution.getScaledHeight();
        hHeight = hHeight + (scaledHeightScaled / 2 - hHeight) * 0.02f;
        hWidth = scaledWidthScaled / 2;

        RenderUtils.drawRect(0, 0, scaledWidthScaled, scaledHeightScaled, new Color(0, 0, 0, 150).getRGB());
        RenderUtils.drawBorderedRect(
                hWidth - 80,
                hHeight - halfTotalHeight,
                hWidth + 80,
                hHeight + halfTotalHeight,
                0.3f,
                new Color(0, 0, 0, 50).getRGB(),
                new Color(0, 0, 0, 50).getRGB());

        // LOGO
        Fonts.OXIDE.OXIDE_55.OXIDE_55.drawString(
                "NOVOLINE",
                hWidth - Fonts.OXIDE.OXIDE_55.OXIDE_55.stringWidth("NOVOLINE") / 2,
                hHeight - halfTotalHeight - 35,
                interpolateColor(blue, blueish, fraction));

        singleplayerworlds.drawButton(client, mouseX, mouseY);
        multiplayer.drawButton(client, mouseX, mouseY);
        altrepository.drawButton(client, mouseX, mouseY);
        options.drawButton(client, mouseX, mouseY);
        shutdown.drawButton(client, mouseX, mouseY);
        super.render(context, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        int mouseX = (int) click.x();
        int mouseY = (int) click.y();

        for (HydraButton button : this.buttonList) {
            if (button.mousePressed(this.client, mouseX, mouseY)) {
                this.selectedButton = button;
                button.playPressSound(this.client.getSoundManager());
                actionPerformed(button);
            }
        }

        return super.mouseClicked(click, doubled);
    }

    protected void actionPerformed(HydraButton button) {
        switch (button.id) {
            case 1337:
                this.client.setScreen(Novoline.getInstance().getAltRepositoryGUI());
                break;
            case 0:
                this.client.setScreen(new OptionsScreen(this, this.client.options));
                break;
            case 1:
                this.client.setScreen(new SelectWorldScreen(this));
                break;
            case 2:
                this.client.setScreen(new MultiplayerScreen(this));
                break;
            case 4:
                this.client.scheduleStop();
                break;
        }
    }

    @Override
    public void close() {
        if (quadBuffer != null) {
            quadBuffer.close();
            quadBuffer = null;
        }
        super.close();
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        /* the shader pass replaces the vanilla blur/darkening */
    }

    private int interpolateColor(Color color1, Color color2, float fraction) {
        int red = (int) (color1.getRed() + (color2.getRed() - color1.getRed()) * fraction);
        int green = (int) (color1.getGreen() + (color2.getGreen() - color1.getGreen()) * fraction);
        int blue = (int) (color1.getBlue() + (color2.getBlue() - color1.getBlue()) * fraction);
        int alpha = (int) (color1.getAlpha() + (color2.getAlpha() - color1.getAlpha()) * fraction);
        try {
            return new Color(red, green, blue, alpha).getRGB();
        } catch (Exception ex) {
            return 0xffffffff;
        }
    }
}
