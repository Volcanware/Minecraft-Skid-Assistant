package cc.novoline.gui.screen.alt.repository;

import cc.novoline.utils.RenderUtils;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.input.Keyboard;

import java.awt.*;

import static cc.novoline.utils.fonts.impl.Fonts.SFBOLD.SFBOLD_16.SFBOLD_16;

/**
 * @author xDelsy
 */
public class PasswordTextField extends TextFieldWidget {

    private int firstCharacterIndex() {
        return ((cc.novoline.mixin.TextFieldWidgetAccessor) this).novoline$getFirstCharacterIndex();
    }

    private int selectionStart() {
        return ((cc.novoline.mixin.TextFieldWidgetAccessor) this).novoline$getSelectionStart();
    }

    private final String shit;
    private final TextRenderer fontRendererInstance;
    private boolean canLoseFocus = true;
    private int enabledColor = DEFAULT_EDITABLE_COLOR;
    private int disabledColor = 0xFF707070;
    private int maxStringLength = 32;

    public PasswordTextField(int id, TextRenderer fontRenderer, int x, int y, int width, int height, String shit) {
        super(fontRenderer, x, y, width, height, Text.empty());
        this.fontRendererInstance = fontRenderer;
        this.shit = shit;
    }

    @Override
    public void setEditableColor(int color) {
        this.enabledColor = color;
        super.setEditableColor(color);
    }

    @Override
    public void setUneditableColor(int color) {
        this.disabledColor = color;
        super.setUneditableColor(color);
    }

    @Override
    public void setMaxLength(int length) {
        this.maxStringLength = length;
        super.setMaxLength(length);
    }

    public int getMaxStringLength() {
        return this.maxStringLength;
    }

    public void setCanLoseFocus(boolean canLoseFocus) {
        this.canLoseFocus = canLoseFocus;
    }

    public void setCursorPosition(int position) {
        setCursor(position, false);
    }

    public void setSelectionPos(int position) {
        setSelectionEnd(position);
    }

    /* keeps the old GuiTextField#textboxKeyTyped(char, int) entry point */
    public boolean textboxKeyTyped(char typedChar, int keyCode) {
        boolean result = keyPressed(new KeyInput(Keyboard.toGlfw(keyCode), 0, currentModifiers()));

        if (typedChar >= ' ') {
            result |= charTyped(new CharInput(typedChar, currentModifiers()));
        }

        return result;
    }

    /* GLFW modifier bits: 1 = shift, 2 = ctrl, 4 = alt, 8 = super */
    private static int currentModifiers() {
        int modifiers = 0;
        if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT)) modifiers |= 1;
        if (Keyboard.isKeyDown(Keyboard.KEY_LCONTROL) || Keyboard.isKeyDown(Keyboard.KEY_RCONTROL)) modifiers |= 2;
        return modifiers;
    }

    /* keeps the old GuiTextField#mouseClicked(int, int, int) entry point */
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        boolean flag = mouseX >= this.getX() && mouseX < this.getX() + this.getWidth()
                && mouseY >= this.getY() && mouseY < this.getY() + this.getHeight(); // PORT: was direct field reads

        if (this.canLoseFocus) {
            setFocused(flag);
        }

        if (this.isFocused() && flag && mouseButton == 0) {
            int i = mouseX - this.getX();

            if (this.drawsBackground()) {
                i -= 4;
            }

            int lineScrollOffset = firstCharacterIndex();
            final String s = this.fontRendererInstance
                    .trimToWidth(this.getText().substring(lineScrollOffset).replaceAll("(?s).", "*"), this.getInnerWidth());
            setCursorPosition(this.fontRendererInstance.trimToWidth(s, i).length() + lineScrollOffset);
        }
    }

    public void drawTextBox() {
        if (this.isVisible()) {
            SFBOLD_16.drawString(this.shit, this.getX() - SFBOLD_16.stringWidth(this.shit) - 5,
                    this.getY() + 5, new Color(198, 198, 198).getRGB());
            RenderUtils.drawRect(this.getX(), this.getY() + 15, this.getX() + this.getWidth(), this.getY() + 16,
                    new Color(198, 198, 198).getRGB());
            int i = this.active ? this.enabledColor : this.disabledColor;
            int lineScrollOffset = firstCharacterIndex();
            int j = this.getCursor() - lineScrollOffset;
            int k = selectionStart() - lineScrollOffset;
            String text = this.getText();
            String s = this.fontRendererInstance
                    .trimToWidth(text.substring(lineScrollOffset).replaceAll("(?s).", "*"),
                            this.getInnerWidth());
            boolean flag = j >= 0 && j <= s.length();
            // PORT: cursorCounter/6 % 2 became a wall-clock blink (~300 ms half-period)
            boolean flag1 = this.isFocused() && Util.getMeasuringTimeMs() / 300 % 2 == 0 && flag;
            int l = this.drawsBackground() ? this.getX() + 4 : this.getX();
            int i1 = this.drawsBackground() ? this.getY() + (this.getHeight() - 8) / 2 : this.getY();
            int j1 = l;

            if (k > s.length()) {
                k = s.length();
            }

            if (!s.isEmpty()) {
                String s1 = flag ? s.substring(0, j) : s;
                RenderUtils.context().drawTextWithShadow(this.fontRendererInstance, s1, l, i1, i);
                j1 = l + this.fontRendererInstance.getWidth(s1);
            }

            boolean flag2 = this.getCursor() < text.length() || text.length() >= this.getMaxStringLength();
            int k1 = j1;

            if (!flag) {
                k1 = j > 0 ? l + this.getWidth() : l;
            } else if (flag2) {
                k1 = j1 - 1;
                --j1;
            }

            if (!s.isEmpty() && flag && j < s.length()) {
                RenderUtils.context().drawTextWithShadow(this.fontRendererInstance, s.substring(j), j1, i1, i);
            }

            if (flag1) {
                if (flag2) {
                    RenderUtils.drawRect(k1, i1 - 1, k1 + 1, i1 + 1 + this.fontRendererInstance.fontHeight, -3092272);
                } else {
                    RenderUtils.context().drawTextWithShadow(this.fontRendererInstance, "_", k1, i1, i);
                }
            }

            if (k != j) {
                int l1 = l + this.fontRendererInstance.getWidth(s.substring(0, k));
                this.drawCursorVertical(k1, i1 - 1, l1 - 1, i1 + 1 + this.fontRendererInstance.fontHeight);
            }
        }
    }

    /* PORT: was an invert-blend quad, now a translucent selection highlight */
    private void drawCursorVertical(int x1, int y1, int x2, int y2) {
        int x = Math.min(x1, x2);
        int x2_ = Math.max(x1, x2);
        RenderUtils.guiQuad(x, y1, x2_, y2, 0x7F3080C8);
    }

}
