package cc.novoline.gui.screen.alt.repository.hypixel;

import net.minecraft.nbt.NbtCompound;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class HypixelProfileFactory {

    private HypixelProfileFactory() {
        throw new java.lang.UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static @NotNull HypixelProfile hypixelProfile(@NotNull String rank, int level) {
        return HypixelProfile.of(rank, level, null, null, null, null, null, null, System.currentTimeMillis());
    }

    public static @NotNull HypixelProfile hypixelProfile(@Nullable String rank,
                                                         int level,
                                                         @Nullable String guild,
                                                         @Nullable Integer achievementPoints,
                                                         @Nullable Integer quests,
                                                         @Nullable Integer friends,
                                                         @Nullable Long firstLogin,
                                                         @Nullable Long lastLogin,
                                                         @Nullable Long cached) {
        return HypixelProfile.of(rank, level, guild, achievementPoints, quests, friends, firstLogin, lastLogin, cached);
    }

    @Nullable
    public static HypixelProfile fromNBT(@Nullable NbtCompound tagCompound) {
        if (tagCompound == null) return null;

        String rank = tagCompound.getString("rank", "Default");
        int level = tagCompound.getInt("level", 1);
        String guild = tagCompound.getString("rank", null);
        int achievementPoints = tagCompound.getInt("ap", 0);
        int quests = tagCompound.getInt("quests", 0);
        int friends = tagCompound.getInt("friends", 0);
        Long firstLogin = tagCompound.getLong("first_login").orElse(null);
        Long lastLogin = tagCompound.getLong("last_login").orElse(null);
        Long cached = tagCompound.getLong("cached").orElse(null);

        return HypixelProfile.of(rank, level, guild, achievementPoints, quests, friends, firstLogin, lastLogin, cached);
    }

}
