package cc.novoline.gui.button;

import cc.novoline.utils.RenderUtils;
import cc.novoline.utils.fonts.impl.Fonts;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.sound.SoundEvents;
import org.jetbrains.annotations.NotNull;

import java.awt.*;

/**
 * PORT: standalone reimplementation — managed manually by GuiLogin.
 */
public class HydraButton {

    public int id;
    public String displayString;
    public int xPosition;
    public int yPosition;
    public int width;
    public int height;
    public boolean enabled = true;
    public boolean visible = true;
    protected boolean hovered;

    private int color;

    public HydraButton(int buttonId, int x, int y, int widthIn, int heightIn, String buttonText) {
        this.id = buttonId;
        this.xPosition = x;
        this.yPosition = y;
        this.width = widthIn;
        this.height = heightIn;
        this.displayString = buttonText;
    }

    public void drawButton(MinecraftClient mc, int mouseX, int mouseY) {
        if (this.visible) {
            this.hovered = mouseX >= xPosition && mouseY >= yPosition && mouseX < xPosition + this.width && mouseY < yPosition + this.height;
            RenderUtils.drawRect(xPosition, yPosition, xPosition + this.width, yPosition + this.height, color);

            Fonts.SF.SF_20.SF_20.drawString(displayString, (float) xPosition + this.width / 2F - Fonts.SF.SF_20.SF_20.stringWidth(displayString) / 2F, (float) yPosition + this.height / 2F - Fonts.SF.SF_20.SF_20.getHeight() / 2F, Color.WHITE.getRGB(), true);
        }
    }

    public boolean mousePressed(MinecraftClient mc, int mouseX, int mouseY) {
        return this.enabled && this.visible
            && mouseX >= xPosition && mouseY >= yPosition
            && mouseX < xPosition + this.width && mouseY < yPosition + this.height;
    }

    public void playPressSound(@NotNull SoundManager soundManager) {
        soundManager.play(PositionedSoundInstance.ui(SoundEvents.UI_BUTTON_CLICK.value(), 1.0F));
    }

    public void updateCoordinates(float x, float y) {
        this.xPosition = (int) x;
        this.yPosition = (int) y;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public boolean hovered(int mouseX, int mouseY) {
        return mouseX >= xPosition && mouseY >= yPosition && mouseX < xPosition + this.width && mouseY < yPosition + this.height;
    }
}
