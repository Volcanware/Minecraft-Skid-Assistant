package cc.novoline.gui.screen.alt.login;

import net.minecraft.client.session.Session;

/**
 * @author xDelsy
 */
public interface AltLoginListener {

    void onLoginSuccess(AltType altType, Session session);

    void onLoginFailed();

}
