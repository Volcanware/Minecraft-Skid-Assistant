package cc.novoline.gui.group;

import cc.novoline.gui.label.Label;
import org.jetbrains.annotations.Nullable;

/**
 * @author xDelsy
 */
public interface Group {

    @Nullable Label getTitle();

}
