package cc.novoline.gui.group;

import org.jetbrains.annotations.NotNull;

/**
 * @author xDelsy
 */
public final class GroupConstantLine implements GroupLine<Object> {

    /* fields */
    @NotNull
    private final String text;

    /* constructors */
    private GroupConstantLine(@NotNull String text) {
        this.text = text;
    }

    /* methods */
    @NotNull
    static GroupConstantLine of(@NotNull String text) {
        return new GroupConstantLine(text);
    }

    //region Lombok
    @Override
    public String getText(Object o) {
        return this.text;
    }
    //endregion

}
