package cc.novoline.gui.screen.alt.login;

import cc.novoline.mixin.MinecraftClientAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

/**
 * @author xDelsy
 */
public abstract class SessionUpdatingAltLoginListener implements AltLoginListener {

    @Override
    public void onLoginSuccess(AltType type, Session session) {
        updateMinecraftSession(session);
    }

    private void updateMinecraftSession(Session newSession) {
        ((MinecraftClientAccessor) MinecraftClient.getInstance()).novoline$setSession(newSession);
    }

}
