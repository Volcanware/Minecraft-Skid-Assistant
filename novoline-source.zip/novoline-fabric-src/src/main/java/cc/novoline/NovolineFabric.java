package cc.novoline;

import cc.novoline.events.EventManager;
import cc.novoline.events.events.Render3DEvent;
import cc.novoline.utils.RenderUtils;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;

/**
 * Fabric entrypoint. The actual bootstrap happens from the MinecraftClient
 * constructor hook once the game's internals are ready (mirrors the original
 * jar-mod init point inside Minecraft.run()).
 */
public class NovolineFabric implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // Defer to Initializer.init() from the MinecraftClient init hook.

        // Fire Render3DEvent near the end of the world render so ESP/tracer
        // geometry lands on top of the world.
        WorldRenderEvents.END_MAIN.register(context -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            RenderUtils.setWorldContext(
                context.commandQueue(),
                context.matrices(),
                mc.gameRenderer.getCamera().getCameraPos());
            try {
                EventManager.call(new Render3DEvent(
                    mc.getRenderTickCounter().getTickProgress(true), context.matrices()));
            } finally {
                RenderUtils.clearWorldContext();
            }
        });
    }
}
