package com.thealtening.api;

public class TheAlteningException extends Exception {

    private final String error;

    public TheAlteningException(String error) {
        super(error);
        this.error = error;
    }

    public TheAlteningException(String error, Throwable cause) {
        super(error, cause);
        this.error = error;
    }

    public String getError() {
        return error;
    }
}
