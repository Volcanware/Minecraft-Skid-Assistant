package com.thealtening.api.response;

/**
 * A generated TheAltening account.
 */
public class Account {

    private final String token;
    private final String password;
    private final String username;
    private final AccountDetails info;

    public Account(String token, String password, String username, AccountDetails info) {
        this.token = token;
        this.password = password;
        this.username = username;
        this.info = info;
    }

    public String getToken() {
        return token;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public AccountDetails getInfo() {
        return info;
    }

    @Override
    public String toString() {
        return username;
    }
}
