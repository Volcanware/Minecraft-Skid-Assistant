package com.thealtening.api.retriever;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.thealtening.api.TheAlteningException;
import com.thealtening.api.response.Account;
import com.thealtening.api.response.AccountDetails;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

/**
 * Minimal async port of TheAlteningAPI4's AsynchronousDataRetriever:
 * generates an account against api.thealtening.com using the stored api key.
 */
public class AsynchronousDataRetriever {

    private static final String GENERATE_URL = "https://api.thealtening.com/v2/generate?info=true&key=";

    private String apiKey;

    public AsynchronousDataRetriever(String apiKey) {
        this.apiKey = apiKey;
    }

    public void updateKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public CompletableFuture<Account> getAccountDataAsync() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return getAccountData();
            } catch (TheAlteningException e) {
                throw new java.util.concurrent.CompletionException(e);
            }
        });
    }

    public Account getAccountData() throws TheAlteningException {
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(GENERATE_URL + apiKey).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(15_000);
            conn.setReadTimeout(15_000);

            JsonObject root;
            try (InputStreamReader reader = new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)) {
                root = JsonParser.parseReader(reader).getAsJsonObject();
            }

            if (root.has("error") && !root.get("error").isJsonNull()) {
                throw new TheAlteningException(root.get("error").getAsString());
            }
            if (root.has("success") && !root.get("success").getAsBoolean()) {
                throw new TheAlteningException(root.has("errorMessage") ? root.get("errorMessage").getAsString() : "Unknown error");
            }

            JsonObject infoJson = root.has("info") && root.get("info").isJsonObject()
                ? root.getAsJsonObject("info") : new JsonObject();
            AccountDetails details = new com.google.gson.Gson().fromJson(infoJson, AccountDetails.class);

            return new Account(
                root.has("token") ? root.get("token").getAsString() : "",
                root.has("password") ? root.get("password").getAsString() : "",
                root.has("username") ? root.get("username").getAsString() : "",
                details);
        } catch (IOException | IllegalStateException e) {
            throw new TheAlteningException("Failed to contact TheAltening", e);
        }
    }
}
