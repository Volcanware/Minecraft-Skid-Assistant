package com.thealtening.api.response;

/**
 * Extra info returned when generating an account with info=true.
 */
public class AccountDetails {

    private String hypixelLevel;
    private String hypixelRank;
    private boolean mineconCape;
    private String mineconYear;
    private boolean optifineCape;
    private boolean labymodCape;
    private boolean liquidbounceCape;
    private String wynncraftLevel;
    private String replaymodLevel;
    private String noteblockLevel;

    public String getHypixelLevel() {
        return hypixelLevel;
    }

    public String getHypixelRank() {
        return hypixelRank;
    }

    public boolean isMineconCape() {
        return mineconCape;
    }

    public String getMineconYear() {
        return mineconYear;
    }

    public boolean isOptifineCape() {
        return optifineCape;
    }

    public boolean isLabymodCape() {
        return labymodCape;
    }

    public boolean isLiquidbounceCape() {
        return liquidbounceCape;
    }

    public String getWynncraftLevel() {
        return wynncraftLevel;
    }

    public String getReplaymodLevel() {
        return replaymodLevel;
    }

    public String getNoteblockLevel() {
        return noteblockLevel;
    }
}
