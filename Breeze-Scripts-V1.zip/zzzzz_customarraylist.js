/*
name: CustomArrayList
author: Karos & Shoffli
*/

//ALWAYS LEAVE THE 'ZZZZZ' AT THE START OF THE FILE NAME

//REMOVE THE // FROM THE WATERMARK YOU WANT
var watermark = 'https://iili.io/dnxkGyB.png'; //NEW
var shadowwatermark = 'https://iili.io/dnxkEvV.png'; //NEW
//var watermark = 'https://iili.io/dFtFpol.png'; //NEWCLOUD
//var shadowwatermark = 'https://iili.io/dFtFbt4.png'; //NEWCLOUD
//var watermark = 'https://iili.io/JLPnDge.png'; //OLD
//var shadowwatermark = 'https://iili.io/JLPnmdu.png'; //OLD
//var watermark = 'https://iili.io/dFRnWSR.png'; //NOSTALGIC
//var shadowwatermark = 'https://iili.io/dFRnVcv.png'; //NOSTALGIC
//var watermark = 'https://iili.io/dCsbct1.png'; //BORDER
//var shadowwatermark = 'https://iili.io/dCsDgTP.png'; //BORDER
//var watermark = 'https://iili.io/JmEyxup.png'; //VAPE
//var shadowwatermark = 'https://iili.io/JmEyzwN.png'; //VAPE
//var watermark = 'https://iili.io/d244nGp.png'; //WURST
//var shadowwatermark = ''; //WURST

var modulesToDisable = [
  'CustomArrayList',
  'Notifications',
  'ModuleList',
  'Watermark',
  'Coordinates',
  'Hotbar',
  'KeyStrokes',
  'ScaffoldBlocks',
  'SessionInfo',
  'TargetHUD',
];

var moduleFontLengths = {};

function getMinecraftFontLength(text) {
  var characterWidths = {
'f': 5,
'i': 2,
'k': 5,
'l': 2.67,
't': 4,

'I': 4,
  };

  var totalWidth = 0;
  for (var i = 0; i < text.length; i++) {
    var char = text[i];
    var width;
    if (char === char.toUpperCase()) {
      width = characterWidths[char];
    } else {
      width = characterWidths[char.toLowerCase()];
    }
    totalWidth += width || 6;
  }
  return totalWidth;
}

function sortByMinecraftFontLength(a, b) {
  var aLength = moduleFontLengths[a] || (moduleFontLengths[a] = getMinecraftFontLength(a));
  var bLength = moduleFontLengths[b] || (moduleFontLengths[b] = getMinecraftFontLength(b));
  var lengthDifference = bLength - aLength;
  if (lengthDifference!== 0) {
    return lengthDifference;
  }
  return a.localeCompare(b);
}

breeze.registerHud('CustomArrayList', 'Shows enabled modules in old fashion.', {
    padding: new IntSetting('Padding', 'The space inbetween each module in the arraylist.', 29, 10, 100),
    fontsize: new DoubleSetting('FontSize', 'The size of the font.', 3, 0.2, 10),
    watermarksize: new DoubleSetting('WatermarkSize', 'The size of the watermark.', 1, 0.1, 2),
    watermarkx: new IntSetting('XWatermarkOffset', 'Watermark offset on the X axis.', -1, -150, 150),
    watermarky: new IntSetting('YWatermarkOffset', 'Watermark offset on the Y axis.', -37, -150, 150),
    offsetx: new IntSetting('XOffset', 'Offset on the X axis.', 13, -60, 60),
    offsety: new IntSetting('YOffset', 'Offset on the Y axis.', 11, -60, 60),
    watermark: new BooleanSetting('Watermark', 'Enables the watermark.', true),
    fancytext: new BooleanSetting('Fancy', 'Syncs the color with your active theme.', false),
    position: new PositionSetting('Position', 'The position of the CustomHud.', 200, 100),

draw: function() {
    modulesToRender.sort(sortByMinecraftFontLength);
    var shadowoffset = Math.round(this.fontsize.getValue());
    var verticalPadding = this.padding.getValue();
    var indexOffset = 0;

    if (this.watermark.getValue()) {
        UIRenderer.remoteTexture(shadowwatermark, this.position.getX() + this.offsetx.getValue() + this.watermarkx.getValue(), this.position.getY() + this.offsety.getValue() + this.watermarky.getValue(), (this.watermarksize.getValue() * 235), (this.watermarksize.getValue() * 133), 1, 10, new Color(255, 255, 255, 200));
    }

    if (this.watermark.getValue() && !this.fancytext.getValue()) {
        UIRenderer.remoteTexture(watermark, this.position.getX() + this.offsetx.getValue() + this.watermarkx.getValue(), this.position.getY() + this.offsety.getValue() + this.watermarky.getValue(), (this.watermarksize.getValue() * 235), (this.watermarksize.getValue() * 133), 1, 10, new Color(255, 255, 255, 255));
    }

    modulesToRender.forEach((moduleName, index) => {
        var module = breeze.getModule(moduleName);
        if (module && module.enabled() && !modulesToDisable.includes(moduleName)) {
            var modulePosY = this.position.getY() + ((index - indexOffset) * verticalPadding);

            // Render main shadow
            var shadowColor = this.fancytext.getValue() ? new Color(0, 0, 0, 255) : new Color(70, 70, 70, 255);
            renderTextMCWithSize(moduleName, this.position.getX() + shadowoffset + this.offsetx.getValue(), modulePosY + 35 + shadowoffset + this.offsety.getValue(), shadowColor, this.fontsize.getValue());

            // Render main text
            if (!this.fancytext.getValue()) {
                renderTextMCWithSize(moduleName, this.position.getX() + this.offsetx.getValue(), modulePosY + 35 + this.offsety.getValue(), new Color(255, 255, 255, 255), this.fontsize.getValue());
            }
        } else {
            indexOffset++;
        }
    });
},
      drawFancy: function() {
        if (!this.fancytext.getValue()) {
            return;
        }
		modulesToRender.sort(sortByMinecraftFontLength);
        var shadowoffset = Math.round(this.fontsize.getValue());
        var verticalPadding = this.padding.getValue();
        var indexOffset = 0;

        if (this.watermark.getValue() && this.fancytext.getValue()) {
            UIRenderer.remoteTexture(watermark, this.position.getX() + this.offsetx.getValue() + this.watermarkx.getValue(), this.position.getY() + this.offsety.getValue() + this.watermarky.getValue(), (this.watermarksize.getValue() * 235), (this.watermarksize.getValue() * 133), 1, 10, new Color(255, 255, 255, 255));
        }

modulesToRender.forEach((moduleName, index) => {
            var module = breeze.getModule(moduleName);
            if (module && module.enabled() &&!modulesToDisable.includes(moduleName)) {
                var modulePosY = this.position.getY() + ((index - indexOffset) * verticalPadding);
                renderTextMCWithSize(moduleName, this.position.getX() + shadowoffset + this.offsetx.getValue(), modulePosY + 35 + shadowoffset + this.offsety.getValue(), new Color(12, 12, 12, 90), this.fontsize.getValue());
                renderTextMCWithSize(moduleName, this.position.getX() + this.offsetx.getValue(), modulePosY + 35 + this.offsety.getValue(), new Color(255, 255, 255, 255), this.fontsize.getValue());
            } else {
                indexOffset++;
            }
        });
    },
});

modulesToRender = []
    breeze.getModules().forEach((module, index) => {
      if (!modulesToDisable.includes(module.getName())) {
        modulesToRender.push(module.getName());
      }
    });
    modulesToRender = modulesToRender.join(',').split(',');

function renderTextMCWithSize(text, posX, posY, color, size) {
    render3D.pushMatrix();
    render3D.translate(posX, posY, 0);
    render3D.scale(size, size, 1);
    render3D.textMC(text, 0, 0, color); 
    render3D.popMatrix();
}