/*
name: Disabler
author: Shoffli
*/

breeze.registerModule('Disabler', 'Disables AntiCheats.', {
    minelandOld: new BooleanSetting('MinelandOld', 'Disables MinelandOld AntiCheat.', false),

    packetSend: function(event) {
        if (this.minelandOld.getValue()) {
            if (event.getPacket() instanceof C0FPacketConfirmTransaction) {
                event.cancel();
            } else if (event.getPacket() instanceof C03PacketPlayer) {
                if (!(event.getPacket() instanceof C04PacketPlayerPosition) &&
                    !(event.getPacket() instanceof C05PacketPlayerLook) &&
                    !(event.getPacket() instanceof C06PacketPlayerPosLook)) {
                    event.cancel();
                }
            }
        }
    },

    tick: function() {
        // No logic yet
    }
});