/*
name: NoSneak
author: Shoffli
*/

var noSlowEnabled = false;

breeze.registerModule('NoSneak', 'Stops you from slowing down when sneaking.', {
    tick: function() {
        if (breeze.getModule('NoSlow').enabled) {
            noSlowEnabled = true;
        } else {
            noSlowEnabled = false;
        }
    },
    preMotion: function(event) {
        if (mc.getPlayer().isSneaking() && (!noSlowEnabled || !mc.getPlayer().isUsingItem())) {
            if (event.getForward() > 0) event.setForward(0.98)
            if (event.getForward() < 0) event.setForward(-0.98)
            if (event.getStrafe() > 0) event.setStrafe(0.98)
            if (event.getStrafe() < 0) event.setStrafe(-0.98)
        }
    }
});