/*
name: NoSlow
author: Shoffli
*/

var noSneakEnabled = false;

breeze.registerModule('NoSlow', 'Stops you from slowing down when using items.', {
    'tick': function() {
        if (breeze.getModule('NoSneak').enabled) {
            noSneakEnabled = true;
        } else {
            noSneakEnabled = false;
        }
    },
    'preMotion': function(event) {
        if (mc.getPlayer().isUsingItem()) {
            if (mc.getPlayer().isSneaking()) {
                if (event.getForward() > 0) event.setForward(0.294)
                if (event.getForward() < 0) event.setForward(-0.294)
                if (event.getStrafe() > 0) event.setStrafe(0.294)
                if (event.getStrafe() < 0) event.setStrafe(-0.294)
            } else {
                if (noSneakEnabled) {
                    if (event.getForward() > 0) event.setForward(0.98)
                    if (event.getForward() < 0) event.setForward(-0.98)
                    if (event.getStrafe() > 0) event.setStrafe(0.98)
                    if (event.getStrafe() < 0) event.setStrafe(-0.98)
                } else {
                    if (event.getForward() > 0) event.setForward(0.294)
                    if (event.getForward() < 0) event.setForward(-0.294)
                    if (event.getStrafe() > 0) event.setStrafe(0.294)
                    if (event.getStrafe() < 0) event.setStrafe(-0.294)
                }
            }
        }
    }
});