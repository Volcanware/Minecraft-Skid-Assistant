/*
name: NoFall
author: Shoffli
*/

var falling = false
var fallDistance = 0
var sendPackets = false

breeze.registerModule('NoFall', 'Makes you take no fall damage.', {
    motion: function(event) {
        if (!mc.getPlayer().onGround() && event.getY() < 0) {
            falling = true;
        }
        if (falling) {
            fallDistance += Math.abs(event.getY());
        }
        if (fallDistance >= 1.75) {
            sendPackets = true;
        }
    },
    tick: function(event) {
        if (sendPackets) {
            breeze.sendPacket(new C03PacketPlayer(true), false);
        }
        if (mc.getPlayer().onGround()) {
            sendPackets = false;
            fallDistance = 0;
            falling = false;
        }
    }
});