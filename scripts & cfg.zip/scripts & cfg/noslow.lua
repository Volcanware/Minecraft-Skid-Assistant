
function is_holding_gap()
    return player.held_item() ~= nil and ((string.match(player.held_item(), 'Apple')) or (string.match(player.held_item(), 'Bow')) or (string.match(player.held_item(), 'Steak')) or (string.match(player.held_item(), 'Sword')))
end
local set_module_state = function(mod, state)
    if module_manager.is_module_on(mod) ~= state then
        player.message("." .. mod)
    end
end
module_manager.register('No Slow\194\1677 NextTick', {
--module_manager.register('NoSlo', {
    on_pre_motion = function(t)
        item = player.inventory.item_information(35 + player.held_item_slot())
        if is_holding_gap() then
            set_module_state('noslow', true) 
        else
            set_module_state('noslow', false) 
        end
        if player.using_item() and is_holding_gap() then
            if player.ticks_existed() % 2 == 0 then
                for i = 10, 45 do
                    if not player.inventory.item_information(i - 1) then
                        player.place_block((i - 1) % 36 + 1, -1, -1, -1, 1, -1, -1, -1)
                        return
                    end
                end
            end
        end
    end
})