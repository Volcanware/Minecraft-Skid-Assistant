
        --  made by xzto

local set_module_state = function(mod, state)
    if module_manager.is_module_on(mod) ~= state then
        player.message("." .. mod)
    end
end
local function voidcheck()
    local x,y,z = player.position()
    for i = y, 0, -1 do
        if world.block(x, i, z) ~= 'tile.air' then
            return false
        end
    end
    return true
end
function falldist()
    for i = 1, 4 do
        local x,y,z = player.position()
        if world.block(x, y-i, z) ~= "tile.air" then
            return false
        end
    end
    return true
end
local started = false
local ticks = 0
local waiticks = 0
local ticks = 0
local r = 0
local g = 0
local color = 0,0,0
local red = 0
local green = 0
local blue = 0
local stage = 1
local rainbow = 5
local safe = true
local safet = 0
local lastY = 0
local anti = {
on_render_screen = function(t)
    if stage == 1 then
        if green < 255 then
            green = green + rainbow
        else
            stage = 2
        end
    elseif stage == 2 then
        if red > 0 then
            red = red - rainbow
        else
            stage = 3
        end
    elseif stage == 3 then
        if blue < 255 then
            blue = blue + rainbow
        else
            stage = 4
        end
    elseif stage == 4 then
        if green > 0 then
            green = green - rainbow
        else
            stage = 5
        end
    elseif stage == 5 then
        if red < 255 then
            red = red + rainbow
        else
            stage = 6
        end
    elseif stage == 6 then
        if blue > 0 then
            blue = blue - rainbow
        else
            stage = 1
        end
    end
    if module_manager.is_module_on("Blink") and started then -- blink indicator
        render.scale(1)
        --render.string_shadow("Blinking:", (t.width/2 - 25)/1, (t.height/2 + 12)/1, 255, 255, 255, 255)
        render.string_shadow("\194\167fBlinking: \194\167r\194\167l"..tostring(ticks), (t.width/2) - (render.get_string_width("Blinking: "..tostring(ticks)) / 2) - module_manager.option('No Fall\194\1677 Spoof', 'Offset'), t.height/100 * 60, red, green, blue, 255)
        render.scale(1/1) 
    end
end,
on_pre_motion = function(t)
    if module_manager.is_module_on("Blink") then 
        ticks = ticks + 1
        waiticks = ticks
    else
        ticks = 0
    end
    if module_manager.is_module_on("Bridger") then
        safe = false
        safet = module_manager.option('No Fall\194\1677 Spoof', "Scaffold Safety")
    end
    if not safe and not module_manager.is_module_on("Bridger") then
        safet = safet - 1
    end
    if safet == 0 then
        safe = true
    end
    if module_manager.option('No Fall\194\1677 Spoof', 'enable') then
        if player.on_ground() then
            lastY = t.y
        end
        if player.kill_aura_target() == nil and not voidcheck() and not module_manager.is_module_on("Bridger") and player.is_on_edge() and player.on_ground() and not module_manager.is_module_on("Long-Jump") and not module_manager.is_module_on("Nofall") and falldist() and not input.is_key_down(57) and safe then
            player.message(".nofall mode spoof")
            player.message('.killaura Entities Players false')
            set_module_state("Nofall", true)
            set_module_state("Blink", true)
            started = true
        end
        if started then
            if player.on_ground() and not player.is_on_edge() then
                set_module_state("Nofall", false)
                set_module_state("Blink", false)
                player.message('.killaura Entities Players true')
                stage = 1
                started = false
            end
            if t.y > lastY and not player.on_ground() then
                set_module_state("Nofall", false)
                set_module_state("Blink", false)
                player.message('.killaura Entities Players true')
                stage = 1
                started = false
            end
        end
    end
end,
on_player_move = function(t)
    if started then
        if t.y > 0 then
            set_module_state("Nofall", false)
            set_module_state("Blink", false)
            player.message('.killaura Entities Players true')
            stage = 1
            started = false
        end
    end
end
}
module_manager.register('No Fall\194\1677 Spoof', anti)
module_manager.register_boolean('No Fall\194\1677 Spoof', 'enable')
module_manager.register_number('No Fall\194\1677 Spoof', "Offset", -4,3,0)
module_manager.register_number('No Fall\194\1677 Spoof', "Scaffold Safety", 1,20,5)
--module_manager.register_boolean('No Fall\194\1677 Spoof', 'AB') -- enables and disables autoblock 