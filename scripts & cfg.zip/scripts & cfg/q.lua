-- Frog <3
module_manager.register("Queue", {
    on_pre_motion = function(t)
        if module_manager.option("Queue","Gamemode") == 2 then
            if module_manager.option("Queue","Mode") == 1 then
                player.message("/play bedwars_eight_one")
            elseif module_manager.option("Queue","Mode") == 2 then
                player.message("/play bedwars_eight_two")
            elseif module_manager.option("Queue","Mode") == 3 then
                player.message("/play bedwars_four_three")
            else 
                player.message("/play bedwars_four_four")
            end
        else
            if module_manager.option("Queue","Mode") == 1 then
                player.message("/play solo_normal")
            elseif module_manager.option("Queue","Mode") == 2 then
                player.message("/play solo_insane")
            elseif module_manager.option("Queue","Mode") == 3 then
                player.message("/play teams_normal")
            else 
                player.message("/play teams_insane")
            end
        end
        player.message(".Queue")
    end
})
module_manager.register_number("Queue","Gamemode",1,2,1) -- 2 = bw, 1 = sw
module_manager.register_number("Queue","Mode",1,4,1) -- 1s,2s,3s,4s for bw
-- normal solo = 1, insane solo = 2, normal teams = 3, insane teams = 4 for sw