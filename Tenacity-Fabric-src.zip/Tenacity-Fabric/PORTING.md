# Tenacity 5.0 → Fabric 1.21.11 porting conventions

## Layout
- Original: `/home/ubuntu/repos/Minecraft-Skid-Assistant/Tenacity 5.0/dev/tenacity/`
- Target: `~/repos/Tenacity-Fabric/src/main/java/dev/tenacity/`
- Keep the same package structure (`dev.tenacity.module.impl.<category>.<Name>`).

## Lombok → manual
Original uses lombok @Getter/@Setter — write plain getters/setters.

## Minecraft renames (1.8.9 → 1.21.11 Yarn)
- `Minecraft.getMinecraft()` → `mc` (from `Utils` interface — implement it)
- `mc.thePlayer` → `mc.player`; `mc.theWorld` → `mc.world`
- `mc.gameSettings` → `mc.options`; `mc.displayGuiScreen(s)` → `mc.setScreen(s)`
- `ScaledResolution` → `ctx().getScaledWindowWidth()/getScaledWindowHeight()`
- `EntityPlayerSP` → `ClientPlayerEntity`; `Entity` → `Entity`; `EntityLivingBase` → `LivingEntity`
- `player.posX` → `player.getX()`; `player.motionX` → `player.getVelocity().x`
- `Keyboard.KEY_*` → `GLFW.GLFW_KEY_*` (lwjgl `org.lwjgl.glfw.GLFW`)
- `Keyboard.isKeyDown(k)` → `GLFW.glfwGetKey(mc.getWindow().getHandle(), k) == GLFW.GLFW_PRESS`
- `player.inventory.mainInventory[i]` → `player.getInventory().getStack(i)`
- `player.getHeldItem()` → `player.getMainHandStack()`
- `World#getBlockState` same; `BlockPos` same; `Vec3` → `Vec3d`
- `EnumFacing` → `net.minecraft.util.math.Direction`
- `AxisAlignedBB` → `net.minecraft.util.math.Box`
- `ItemSword` → check `stack.isIn(ItemTags.SWORDS)` (no SwordItem class in 1.21.11)
- `MathHelper.cos/sin/wrapDegrees` same-ish: `MathHelper.cos`, `MathHelper.sin`, `MathHelper.wrapDegrees`
- `player.movementInput.moveForward` → `mc.player.input.getMovementInput().y`; `.moveStrafe` → `.x`
- `player.onGround` → `player.isOnGround()`; `player.isSprinting()` same; `player.setSprinting(b)` same
- `player.fallDistance` → `player.fallDistance` (field exists, private — use `player.fallDistance` won't compile; use accessor or `player.getVelocity().y < 0` checks). Actually `LivingEntity.fallDistance` is public in yarn: `player.fallDistance` works.
- `player.jump()` same; `player.isSneaking()` same
- `Packet` → `net.minecraft.network.packet.Packet`; `C03PacketPlayer` → `PlayerMoveC2SPacket`; `C02PacketUseEntity` → `PlayerInteractEntityC2SPacket`; `C0APacketAnimation` → `HandSwingC2SPacket`
- `mc.getNetHandler().addToSendQueue(p)` → `PacketUtils.sendPacket(p)`
- `EntityRenderer.getFontRenderer()` → `mc.textRenderer`
- `GlStateManager` / `GL11` calls → `ctx()` 2D draw methods via `RenderUtil`/`RoundedUtil`, or no-op if pure GL state

## Utils & font
- Implement `dev.tenacity.utils.Utils` for `mc`, `ctx()`, font methods (`tenacityFont18()`, `iconFont20()`, `tenacityBoldFont22()`, etc.) — they are `default` methods, call unqualified.
- `ctx()` returns the current frame's `DrawContext` — ONLY valid during render callbacks (onRender2DEvent, drawScreen). NEVER call during game logic/ticks.
- `CustomFont.drawString(str, x, y, color)`, `.drawCenteredString`, `.getStringWidthFloat`, `.getHeight`, `.getMiddleOfBox(h)`

## Events
- All events in `dev.tenacity.event.impl.{player,render,game,network}`; dispatch = `event.call()`; cancel = `event.cancel()`/`event.setCancelled(true)`
- Module handlers: override `onRender2DEvent(Render2DEvent e)`, `onUpdateEvent(UpdateEvent e)`, `onMotionEvent(MotionEvent e)`, `onMoveEvent(MoveEvent e)`, `onPlayerPacketsEvent(PlayerPacketsEvent e)` — check `ListenerAdapter` for exact handler names; the port keeps the same `on<Event>` naming as original.
- `MotionEvent(double x, double y, double z, float yaw, float pitch, boolean onGround)`; `MoveEvent(x,y,z)` mutable; `Render2DEvent(DrawContext)`; `Render3DEvent(float partialTicks)`; `TickEvent(int ticks)`

## Settings
- `BooleanSetting(name, def)`, `NumberSetting(name, def, max, min, increment)`, `ModeSetting(name, def, modes...)`, `StringSetting(name)`, `ColorSetting(name, Color)`, `KeybindSetting(code)`, `MultipleBoolSetting(name, BooleanSetting...)`
- Access: `.isEnabled()`, `.setState(b)`, `.getValue()` (double), `.getMode()`, `.is("Mode")`, `.getString()`, `.getColor()`, `.setColor(c)`, `.getCode()`, `.setCode(i)`
- Parent visibility: `setting.addParent(parentSetting, s -> s.is("X"))`
- `this.addSettings(a, b, c)` in constructor

## Module skeleton
```java
public class X extends Module {
    public X() {
        super("X", Category.MOVEMENT, "description");
        this.addSettings(...);
    }
    @Override public void onEnable() {}
    @Override public void onDisable() {}
    @Override public void onUpdateEvent(UpdateEvent e) {}
}
```
- `setKey(k)` → `this.getKeybind().setCode(GLFW.GLFW_KEY_X)`
- `this.setSuffix(...)` for arraylist suffix

## Render helpers (already ported — use them)
- `RoundedUtil.drawRound(x,y,w,h,radius,color)` / `drawGradientRound`
- `RenderUtil.drawRect/drawBorderedRect/drawImage/scissorStart/scissorEnd/scaleStart/scaleEnd/rotateStart/rotateEnd/animate`
- `ColorUtil.applyOpacity(color, a)` / `.interpolateColorC` / `.rainbow` / `.getColor`
- `Theme.getCurrentTheme()`, `Theme.getThemeColors(name)`, `HUDMod.getClientColors()` → `Pair<Color,Color>`
- `HoveringUtil.isHovering(x,y,w,h,mx,my)`
- `ESPUtil.isInView/getInterpolatedPos/getInterpolatedBoundingBox`
- GL texture draw: `ctx().drawTexture(RenderPipelines.GUI_TEXTURED, id, x, y, u, v, w, h, texW, texH)` or `.fill(x0,y0,x1,y1,argb)`

## Player/server utils (ported)
- `MovementUtils.isMoving/setSpeed/getSpeed/getBaseMoveSpeed/isOnGround/getMoveYaw`
- `RotationUtils.getRotationsNeeded/getSmoothRotations/setVisualRotations/isMouseOver`
- `PacketUtils.sendPacket(p[,silent])/sendPacketNoEvent(p)`
- `InventoryUtils.getItemSlot/click/swap/drop/isHoldingSword`
- `ServerUtils.isOnHypixel/getRemoteIp/isOnSameTeam`
- `ChatUtil.print(msg)` — prints to chat hud
- `Multithreading.schedule(runnable, delay, TimeUnit)` / `runAsync(runnable)`
- `TimerUtil.hasTimeElapsed(ms)/reset/hasTimePassed`

## DO NOT
- run gradle/javac (the parent compiles all ports centrally — concurrent builds corrupt the build dir)
- touch files outside your assigned module list
- run git commands or modify files other than your assigned modules
- port cloud/server features (script browser, config upload, discord RPC, auth, ViaVersion internals)
