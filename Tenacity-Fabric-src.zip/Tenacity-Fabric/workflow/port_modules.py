import asyncio

BUNDLE = "https://app.devin.ai/attachments/9786dae7-54b1-465b-96a7-7231b3949563/port-bundle.zip"

SCHEMA = {
    "type": "object",
    "properties": {
        "result_zip_url": {"type": "string"},
        "ported": {"type": "array", "items": {"type": "string"}},
        "skipped": {"type": "array", "items": {"type": "string"}},
        "notes": {"type": "string"},
    },
    "required": ["result_zip_url", "ported", "skipped", "notes"],
}

BATCHES = {
    "combat+exploit": [
        "combat.AutoHead","combat.AutoPot","combat.Criticals","combat.FastBow","combat.IdleFighter",
        "combat.KeepSprint","combat.KillAura","combat.SuperKnockback","combat.TargetStrafe","combat.Velocity",
        "exploit.AntiAura","exploit.AntiInvis","exploit.Crasher","exploit.Disabler",
        "exploit.Regen","exploit.ResetVL","exploit.TPAKiller",
    ],
    "misc": [
        "misc.AntiDesync","misc.AntiFreeze","misc.AntiTabComplete","misc.AutoAuthenticate","misc.AutoHypixel",
        "misc.AutoRespawn","misc.HackerDetector","misc.Killsults","misc.LightningTracker","misc.MCF",
        "misc.NoRotate","misc.Sniper","misc.Spammer",
    ],
    "movement": [
        "movement.AutoHeadHitter","movement.FastLadder","movement.Flight","movement.InventoryMove",
        "movement.Jesus","movement.LongJump","movement.Scaffold","movement.Speed","movement.Spider",
        "movement.Sprint","movement.Step",
    ],
    "player": [
        "player.AntiVoid","player.AutoArmor","player.AutoTool","player.Blink","player.ChestStealer",
        "player.FastPlace","player.Freecam","player.InvManager","player.NoFall","player.NoSlow",
        "player.SafeWalk","player.SpeedMine","player.Timer",
    ],
    "render-a": [
        "render.Ambience","render.Animations","render.Breadcrumbs","render.BrightPlayers","render.Brightness",
        "render.Chams","render.ChinaHat","render.CustomModel","render.EntityEffects","render.Glint",
        "render.Hitmarkers","render.ItemPhysics","render.JumpCircle","render.MotionGraph","render.PlayerList",
    ],
    "render-b": [
        "render.ESP2D","render.GlowESP","render.IRC","render.PostProcessing","render.Radar",
        "render.SpotifyMod","render.Statistics","render.Streamer","render.XRay",
        "render.killeffects.EffectManager","render.killeffects.KillEffects",
    ],
    "render-targethud+wings": [
        "render.targethud.AkrienTargetHUD","render.targethud.AstolfoTargetHUD","render.targethud.AutoDoxTargetHUD",
        "render.targethud.ExhiTargetHUD","render.targethud.NovolineTargetHUD","render.targethud.OldTenacityTargetHUD",
        "render.targethud.RiseTargetHUD","render.targethud.TargetHUD","render.targethud.TenacityTargetHUD",
        "render.wings.DragonWings","render.wings.WingModel",
    ],
}

PROMPT = """You are porting part of the Tenacity 5.0 Minecraft cheat client from 1.8.9 (Forge/LWJGL2) to a Fabric 1.21.11 (Yarn) client mod.

A bundle with everything you need is attached to this session. Download it (it is already a session attachment — use the download_attachment tool with the URL below), unzip into a scratch dir.

ATTACHMENT: {bundle}

Inside the bundle:
- src-orig/dev/tenacity/ — the ORIGINAL 1.8.9 source
- PORTING.md — the API-conversion guide (yarn renames, event names, settings API, render helpers). READ IT FIRST.
- examples/ — already-ported files showing target conventions (HUDMod.java, Keystrokes.java, Module.java, settings/, event/, MovementUtils/RotationUtils/PacketUtils/ServerUtils/InventoryUtils, Utils.java).

YOUR ASSIGNMENT — port ONLY these modules, one .java file each, into package dev.tenacity.module.impl.<cat>.<Name> (keep the original subpackage):
{mods}

Write each ported file under ~/out/dev/tenacity/module/impl/<cat>/<Name>.java.

Rules:
- Faithful port: keep logic, settings (names/defaults/ranges), modes, behavior; translate only Minecraft API calls per PORTING.md.
- If a util the module needs is missing, create it under ~/out/dev/tenacity/utils/ following conventions.
- Skip original-only features (ViaVersion internals, auth servers, Discord/cloud, ScriptManager). Note them in `skipped`.
- Valid Java 21; no lombok (manual getters/setters).
- Do NOT try to compile (no toolchain needed) — the integrator compiles centrally.
- Match the examples' style: modules extend dev.tenacity.module.Module, implement dev.tenacity.utils.Utils, use ctx() during render only, event.call().

When done: zip the entire ~/out dir -> /tmp/out.zip and upload it via upload_attachment. Put the returned URL in `result_zip_url`, list ported class names in `ported`, skipped in `skipped`, and integration notes (new utils added, risky spots) in `notes`."""

async def main():
    await register_workflow({
        "name": "tenacity-module-port",
        "description": "Port Tenacity 5.0 modules to Fabric 1.21.11 (separate-VM, bundle handoff)",
        "product": "Tenacity-Fabric",
        "soft_time_limit_minutes": 45,
        "phases": [{"title": "port", "detail": "Port module batches in isolated sessions",
                    "labels": list(BATCHES.keys())}],
    })
    log(f"Launching {len(BATCHES)} module-port agents (separate-VM)")

    async def do_batch(name, mods):
        files = "\n".join(f"- {m}" for m in mods)
        prompt = PROMPT.format(bundle=BUNDLE, mods=files)
        try:
            return await agent(prompt, phase="port", schema=SCHEMA, label=name)
        except Exception as e:
            log(f"batch {name} failed: {e}")
            return {"result_zip_url": "", "ported": [], "skipped": mods, "notes": f"agent error: {e}"}

    results = await parallel([lambda n=n, m=m: do_batch(n, m) for n, m in BATCHES.items()])
    total = 0
    for name, res in zip(BATCHES.keys(), results):
        log(f"[{name}] zip={res['result_zip_url'] or 'NONE'} ported={len(res['ported'])} skipped={len(res['skipped'])} notes={res['notes'][:150]}")
        total += len(res["ported"])
    log(f"DONE: {total} modules reported ported; fetch zips from agent sessions")

asyncio.run(main())
