package dev.tenacity.utils.font;

import java.awt.*;

public interface AbstractFontRenderer {

    default int drawString(String name, float x, float y, int color) {
        return drawString(name, x, y, color, false);
    }

    default void drawString(String name, float x, float y, Color color) {
        drawString(name, x, y, color.getRGB(), false);
    }

    int drawString(String name, float x, float y, int color, boolean shadow);

    default void drawSmoothString(String text, double x, float y, int color) {
        drawString(text, (float) x, y, color, false);
    }

    default void drawSmoothStringWithShadow(String text, double x, float y, int color) {
        drawString(text, (float) x, y, color, true);
    }

    default int drawCenteredString(String name, float x, float y, int color) {
        return drawString(name, x - getStringWidth(name) / 2f, y, color, false);
    }

    default void drawCenteredString(String name, float x, float y, Color color) {
        drawCenteredString(name, x, y, color.getRGB());
    }

    default void drawCenteredStringWithShadow(String text, float x, float y, int color) {
        drawString(text, x - getStringWidth(text) / 2f, y, color, true);
    }

    default int drawStringWithShadow(String name, float x, float y, int color) {
        return drawString(name, x, y, color, true);
    }

    default void drawStringWithShadow(String name, float x, float y, Color color) {
        drawString(name, x, y, color.getRGB(), true);
    }

    int getStringWidth(String name);

    float getStringWidthFloat(String name);

    int getHeight();

    float getMiddleOfBox(float height);

    default String trimStringToWidth(String text, int width) {
        return trimStringToWidth(text, width, false);
    }

    default String trimStringToWidth(String text, int width, boolean reverse) {
        StringBuilder stringbuilder = new StringBuilder();
        float lineWidth = 0.0F;
        int offset = reverse ? text.length() - 1 : 0;
        int increment = reverse ? -1 : 1;

        for (int index = offset; index >= 0 && index < text.length() && lineWidth < (float) width; index += increment) {
            char character = text.charAt(index);
            float charWidth = this.getStringWidthFloat(String.valueOf(character));

            if (reverse) {
                stringbuilder.insert(0, character);
            } else {
                stringbuilder.append(character);
            }

            lineWidth += charWidth;

            if (lineWidth > (float) width) {
                break;
            }
        }

        return stringbuilder.toString();
    }
}
