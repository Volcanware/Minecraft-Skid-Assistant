package dev.tenacity.utils.render;

import dev.tenacity.utils.Utils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

/**
 * GL20 shader program wrapper ported to the core-profile context used by 1.21.
 * <p>
 * Differences from the 1.8.9 version:
 * <ul>
 *   <li>Embedded shaders were rewritten from {@code #version 120} (gl_TexCoord /
 *   gl_FragColor / texture2D) to {@code #version 330 core}.</li>
 *   <li>The fixed-function quads ({@code glBegin(GL_QUADS)}) were replaced by a
 *   dynamic VBO + VAO fullscreen quad; {@link #drawQuads} emits vertices in NDC
 *   with the same (x,y)->uv mapping as before, so all GLSL semantics are
 *   preserved.</li>
 *   <li>File shaders ({@code Tenacity/Shaders/*.frag}) are still loaded from the
 *   mod jar but MUST themselves be converted to {@code #version 330 core} with
 *   {@code in vec2 texCoord; out vec4 fragColor;}.</li>
 * </ul>
 */
public class ShaderUtil implements Utils {

    private final int programID;

    private static final String VERTEX_SHADER =
            "#version 330 core\n" +
            "layout(location = 0) in vec2 position;\n" +
            "layout(location = 1) in vec2 uv;\n" +
            "out vec2 texCoord;\n" +
            "void main() {\n" +
            "    gl_Position = vec4(position, 0.0, 1.0);\n" +
            "    texCoord = uv;\n" +
            "}";

    public ShaderUtil(String fragmentShaderLoc, String vertexShaderLoc) {
        int program = glCreateProgram();
        try {
            int fragmentShaderID;
            switch (fragmentShaderLoc) {
                case "kawaseUpGlow":
                    fragmentShaderID = createShader(new ByteArrayInputStream(kawaseUpGlow.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "glow":
                    fragmentShaderID = createShader(new ByteArrayInputStream(glowShader.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "chams":
                    fragmentShaderID = createShader(new ByteArrayInputStream(chams.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "roundRectTexture":
                    fragmentShaderID = createShader(new ByteArrayInputStream(roundRectTexture.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "roundRectOutline":
                    fragmentShaderID = createShader(new ByteArrayInputStream(roundRectOutline.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "kawaseUpBloom":
                    fragmentShaderID = createShader(new ByteArrayInputStream(kawaseUpBloom.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "kawaseDownBloom":
                    fragmentShaderID = createShader(new ByteArrayInputStream(kawaseDownBloom.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "kawaseUp":
                    fragmentShaderID = createShader(new ByteArrayInputStream(kawaseUp.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "kawaseDown":
                    fragmentShaderID = createShader(new ByteArrayInputStream(kawaseDown.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "gradientMask":
                    fragmentShaderID = createShader(new ByteArrayInputStream(gradientMask.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "mask":
                    fragmentShaderID = createShader(new ByteArrayInputStream(mask.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "gradient":
                    fragmentShaderID = createShader(new ByteArrayInputStream(gradient.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "roundedRect":
                    fragmentShaderID = createShader(new ByteArrayInputStream(roundedRect.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                case "roundedRectGradient":
                    fragmentShaderID = createShader(new ByteArrayInputStream(roundedRectGradient.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
                    break;
                default:
                    fragmentShaderID = createShader(getResource(fragmentShaderLoc), GL_FRAGMENT_SHADER);
                    break;
            }
            glAttachShader(program, fragmentShaderID);

            int vertexShaderID;
            if (vertexShaderLoc.equals(VERTEX_SHADER)) {
                vertexShaderID = createShader(new ByteArrayInputStream(VERTEX_SHADER.getBytes(StandardCharsets.UTF_8)), GL_VERTEX_SHADER);
            } else {
                vertexShaderID = createShader(getResource(vertexShaderLoc), GL_VERTEX_SHADER);
            }
            glAttachShader(program, vertexShaderID);

            glLinkProgram(program);
            int status = glGetProgrami(program, GL_LINK_STATUS);
            if (status == 0) {
                throw new IllegalStateException("Shader failed to link: " + glGetProgramInfoLog(program, 4096));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.programID = program;
    }

    public ShaderUtil(String fragmentShadersrc, boolean notUsed) {
        int program = glCreateProgram();
        int fragmentShaderID = createShader(new ByteArrayInputStream(fragmentShadersrc.getBytes(StandardCharsets.UTF_8)), GL_FRAGMENT_SHADER);
        int vertexShaderID = createShader(new ByteArrayInputStream(VERTEX_SHADER.getBytes(StandardCharsets.UTF_8)), GL_VERTEX_SHADER);

        glAttachShader(program, fragmentShaderID);
        glAttachShader(program, vertexShaderID);

        glLinkProgram(program);
        int status = glGetProgrami(program, GL_LINK_STATUS);
        if (status == 0) {
            throw new IllegalStateException("Shader failed to link!");
        }
        this.programID = program;
    }

    public ShaderUtil(String fragmentShaderLoc) {
        this(fragmentShaderLoc, VERTEX_SHADER);
    }

    private static InputStream getResource(String location) throws IOException {
        Identifier id = location.contains(":") ? Identifier.of(location.split(":")[0], location.split(":")[1])
                : Identifier.of("tenacity", location);
        Optional<Resource> resource = mc.getResourceManager().getResource(id);
        if (resource.isEmpty()) {
            throw new IOException("Missing shader resource " + id);
        }
        return resource.get().getInputStream();
    }

    public void init() {
        glUseProgram(programID);
    }

    public void unload() {
        glUseProgram(0);
    }

    public int getUniform(String name) {
        return glGetUniformLocation(programID, name);
    }

    public void setUniformf(String name, float... args) {
        int loc = glGetUniformLocation(programID, name);
        switch (args.length) {
            case 1 -> glUniform1f(loc, args[0]);
            case 2 -> glUniform2f(loc, args[0], args[1]);
            case 3 -> glUniform3f(loc, args[0], args[1], args[2]);
            case 4 -> glUniform4f(loc, args[0], args[1], args[2], args[3]);
        }
    }

    public void setUniformi(String name, int... args) {
        int loc = glGetUniformLocation(programID, name);
        if (args.length > 1) glUniform2i(loc, args[0], args[1]);
        else glUniform1i(loc, args[0]);
    }

    // ---- Quad rendering -------------------------------------------------------

    private static int vaoId = -1, vboId = -1;

    private static void ensureQuad() {
        if (vaoId == -1) {
            vaoId = glGenVertexArrays();
            vboId = glGenBuffers();
            glBindVertexArray(vaoId);
            glBindBuffer(GL_ARRAY_BUFFER, vboId);
            glBufferData(GL_ARRAY_BUFFER, 4L * 4 * 4, GL_DYNAMIC_DRAW);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 2, GL_FLOAT, false, 16, 0L);
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 2, GL_FLOAT, false, 16, 8L);
            glBindVertexArray(0);
        }
    }

    /** Uploads 4 interleaved (x,y,u,v) vertices and draws them as a fan. */
    private static void drawFan(float... verts) {
        ensureQuad();
        float[] buffer = verts;
        glBindVertexArray(vaoId);
        glBindBuffer(GL_ARRAY_BUFFER, vboId);
        glBufferSubData(GL_ARRAY_BUFFER, 0, buffer);
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        glBindVertexArray(0);
    }

    /**
     * Fullscreen quad in framebuffer space; same uv orientation as the original
     * (top-left gets v=1, since MC framebuffer textures are bottom-up).
     */
    public static void drawQuads() {
        drawFan(
                -1f, 1f, 0f, 1f,
                -1f, -1f, 0f, 0f,
                1f, -1f, 1f, 0f,
                1f, 1f, 1f, 1f);
    }

    public static void drawQuads(float width, float height) {
        drawQuads();
    }

    /**
     * Rect in scaled screen pixels; top-left uv = (0,0) like the original.
     */
    public static void drawQuads(float x, float y, float width, float height) {
        float sw = MinecraftClient.getInstance().getWindow().getScaledWidth();
        float sh = MinecraftClient.getInstance().getWindow().getScaledHeight();
        float x0 = x / sw * 2f - 1f, y0 = 1f - y / sh * 2f;
        float x1 = (x + width) / sw * 2f - 1f, y1 = 1f - (y + height) / sh * 2f;
        drawFan(
                x0, y0, 0f, 0f,
                x0, y1, 0f, 1f,
                x1, y1, 1f, 1f,
                x1, y0, 1f, 0f);
    }

    private int createShader(InputStream inputStream, int shaderType) {
        int shader = glCreateShader(shaderType);
        glShaderSource(shader, readInputStream(inputStream));
        glCompileShader(shader);

        if (glGetShaderi(shader, GL_COMPILE_STATUS) == 0) {
            System.out.println(glGetShaderInfoLog(shader, 4096));
            throw new IllegalStateException(String.format("Shader (%s) failed to compile!", shaderType));
        }

        return shader;
    }

    private static String readInputStream(InputStream inputStream) {
        try {
            return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // ---- Embedded fragment shaders (converted to GLSL 330 core) ---------------

    private final String kawaseUpGlow = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D inTexture, textureToCheck;\n" +
            "uniform vec2 halfpixel, offset, iResolution;\n" +
            "uniform bool check;\n" +
            "uniform float lastPass;\n" +
            "uniform float exposure;\n" +
            "\n" +
            "void main() {\n" +
            "    if(check && texture(textureToCheck, texCoord).a != 0.0) discard;\n" +
            "    vec2 uv = vec2(gl_FragCoord.xy / iResolution);\n" +
            "\n" +
            "    vec4 sum = texture(inTexture, uv + vec2(-halfpixel.x * 2.0, 0.0) * offset);\n" +
            "    sum.rgb *= sum.a;\n" +
            "    vec4 smpl1 =  texture(inTexture, uv + vec2(-halfpixel.x, halfpixel.y) * offset);\n" +
            "    smpl1.rgb *= smpl1.a;\n" +
            "    sum += smpl1 * 2.0;\n" +
            "    vec4 smp2 = texture(inTexture, uv + vec2(0.0, halfpixel.y * 2.0) * offset);\n" +
            "    smp2.rgb *= smp2.a;\n" +
            "    sum += smp2;\n" +
            "    vec4 smp3 = texture(inTexture, uv + vec2(halfpixel.x, halfpixel.y) * offset);\n" +
            "    smp3.rgb *= smp3.a;\n" +
            "    sum += smp3 * 2.0;\n" +
            "    vec4 smp4 = texture(inTexture, uv + vec2(halfpixel.x * 2.0, 0.0) * offset);\n" +
            "    smp4.rgb *= smp4.a;\n" +
            "    sum += smp4;\n" +
            "    vec4 smp5 = texture(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset);\n" +
            "    smp5.rgb *= smp5.a;\n" +
            "    sum += smp5 * 2.0;\n" +
            "    vec4 smp6 = texture(inTexture, uv + vec2(0.0, -halfpixel.y * 2.0) * offset);\n" +
            "    smp6.rgb *= smp6.a;\n" +
            "    sum += smp6;\n" +
            "    vec4 smp7 = texture(inTexture, uv + vec2(-halfpixel.x, -halfpixel.y) * offset);\n" +
            "    smp7.rgb *= smp7.a;\n" +
            "    sum += smp7 * 2.0;\n" +
            "    vec4 result = sum / 12.0;\n" +
            "    fragColor = vec4(result.rgb / result.a, mix(result.a, 1.0 - exp(-result.a * exposure), step(0.0, lastPass)));\n" +
            "}";

    private final String glowShader = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D textureIn, textureToCheck;\n" +
            "uniform vec2 texelSize, direction;\n" +
            "uniform vec3 color;\n" +
            "uniform bool avoidTexture;\n" +
            "uniform float exposure, radius;\n" +
            "uniform float weights[256];\n" +
            "\n" +
            "#define offset direction * texelSize\n" +
            "\n" +
            "void main() {\n" +
            "    if (direction.y == 1 && avoidTexture) {\n" +
            "        if (texture(textureToCheck, texCoord).a != 0.0) discard;\n" +
            "    }\n" +
            "    vec4 innerColor = texture(textureIn, texCoord);\n" +
            "    innerColor.rgb *= innerColor.a;\n" +
            "    innerColor *= weights[0];\n" +
            "    for (float r = 1.0; r <= radius; r++) {\n" +
            "        vec4 colorCurrent1 = texture(textureIn, texCoord + offset * r);\n" +
            "        vec4 colorCurrent2 = texture(textureIn, texCoord - offset * r);\n" +
            "\n" +
            "        colorCurrent1.rgb *= colorCurrent1.a;\n" +
            "        colorCurrent2.rgb *= colorCurrent2.a;\n" +
            "\n" +
            "        innerColor += (colorCurrent1 + colorCurrent2) * weights[int(r)];\n" +
            "    }\n" +
            "\n" +
            "    fragColor = vec4(innerColor.rgb / innerColor.a, mix(innerColor.a, 1.0 - exp(-innerColor.a * exposure), step(0.0, direction.y)));\n" +
            "}\n";

    private final String chams =
            "#version 330 core\n" +
                    "\n" +
                    "in vec2 texCoord;\n" +
                    "out vec4 fragColor;\n" +
                    "uniform sampler2D textureIn;\n" +
                    "uniform vec4 color;\n" +
                    "void main() {\n" +
                    "    float alpha = texture(textureIn, texCoord).a;\n" +
                    "\n" +
                    "    fragColor = vec4(color.rgb, color.a * mix(0.0, alpha, step(0.0, alpha)));\n" +
                    "}\n";

    private final String roundRectTexture = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform vec2 location, rectSize;\n" +
            "uniform sampler2D textureIn;\n" +
            "uniform float radius, alpha;\n" +
            "\n" +
            "float roundedBoxSDF(vec2 centerPos, vec2 size, float radius) {\n" +
            "    return length(max(abs(centerPos) -size, 0.)) - radius;\n" +
            "}\n" +
            "\n" +
            "\n" +
            "void main() {\n" +
            "    float distance = roundedBoxSDF((rectSize * .5) - (texCoord * rectSize), (rectSize * .5) - radius - 1., radius);\n" +
            "    float smoothedAlpha =  (1.0-smoothstep(0.0, 2.0, distance)) * alpha;\n" +
            "    fragColor = vec4(texture(textureIn, texCoord).rgb, smoothedAlpha);\n" +
            "}";

    private final String roundRectOutline = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform vec2 location, rectSize;\n" +
            "uniform vec4 color, outlineColor;\n" +
            "uniform float radius, outlineThickness;\n" +
            "\n" +
            "float roundedSDF(vec2 centerPos, vec2 size, float radius) {\n" +
            "    return length(max(abs(centerPos) - size + radius, 0.0)) - radius;\n" +
            "}\n" +
            "\n" +
            "void main() {\n" +
            "    float distance = roundedSDF(gl_FragCoord.xy - location - (rectSize * .5), (rectSize * .5) + (outlineThickness *.5) - 1.0, radius);\n" +
            "\n" +
            "    float blendAmount = smoothstep(0., 2., abs(distance) - (outlineThickness * .5));\n" +
            "\n" +
            "    vec4 insideColor = (distance < 0.) ? color : vec4(outlineColor.rgb,  0.0);\n" +
            "    fragColor = mix(outlineColor, insideColor, blendAmount);\n" +
            "\n" +
            "}";

    private final String kawaseUpBloom = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D inTexture, textureToCheck;\n" +
            "uniform vec2 halfpixel, offset, iResolution;\n" +
            "uniform int check;\n" +
            "\n" +
            "void main() {\n" +
            "    vec2 uv = vec2(gl_FragCoord.xy / iResolution);\n" +
            "\n" +
            "    vec4 sum = texture(inTexture, uv + vec2(-halfpixel.x * 2.0, 0.0) * offset);\n" +
            "    sum.rgb *= sum.a;\n" +
            "    vec4 smpl1 =  texture(inTexture, uv + vec2(-halfpixel.x, halfpixel.y) * offset);\n" +
            "    smpl1.rgb *= smpl1.a;\n" +
            "    sum += smpl1 * 2.0;\n" +
            "    vec4 smp2 = texture(inTexture, uv + vec2(0.0, halfpixel.y * 2.0) * offset);\n" +
            "    smp2.rgb *= smp2.a;\n" +
            "    sum += smp2;\n" +
            "    vec4 smp3 = texture(inTexture, uv + vec2(halfpixel.x, halfpixel.y) * offset);\n" +
            "    smp3.rgb *= smp3.a;\n" +
            "    sum += smp3 * 2.0;\n" +
            "    vec4 smp4 = texture(inTexture, uv + vec2(halfpixel.x * 2.0, 0.0) * offset);\n" +
            "    smp4.rgb *= smp4.a;\n" +
            "    sum += smp4;\n" +
            "    vec4 smp5 = texture(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset);\n" +
            "    smp5.rgb *= smp5.a;\n" +
            "    sum += smp5 * 2.0;\n" +
            "    vec4 smp6 = texture(inTexture, uv + vec2(0.0, -halfpixel.y * 2.0) * offset);\n" +
            "    smp6.rgb *= smp6.a;\n" +
            "    sum += smp6;\n" +
            "    vec4 smp7 = texture(inTexture, uv + vec2(-halfpixel.x, -halfpixel.y) * offset);\n" +
            "    smp7.rgb *= smp7.a;\n" +
            "    sum += smp7 * 2.0;\n" +
            "    vec4 result = sum / 12.0;\n" +
            "    fragColor = vec4(result.rgb / result.a, mix(result.a, result.a * (1.0 - texture(textureToCheck, texCoord).a),check));\n" +
            "}";

    private final String kawaseDownBloom = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D inTexture;\n" +
            "uniform vec2 offset, halfpixel, iResolution;\n" +
            "\n" +
            "void main() {\n" +
            "    vec2 uv = vec2(gl_FragCoord.xy / iResolution);\n" +
            "    vec4 sum = texture(inTexture, texCoord);\n" +
            "    sum.rgb *= sum.a;\n" +
            "    sum *= 4.0;\n" +
            "    vec4 smp1 = texture(inTexture, uv - halfpixel.xy * offset);\n" +
            "    smp1.rgb *= smp1.a;\n" +
            "    sum += smp1;\n" +
            "    vec4 smp2 = texture(inTexture, uv + halfpixel.xy * offset);\n" +
            "    smp2.rgb *= smp2.a;\n" +
            "    sum += smp2;\n" +
            "    vec4 smp3 = texture(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset);\n" +
            "    smp3.rgb *= smp3.a;\n" +
            "    sum += smp3;\n" +
            "    vec4 smp4 = texture(inTexture, uv - vec2(halfpixel.x, -halfpixel.y) * offset);\n" +
            "    smp4.rgb *= smp4.a;\n" +
            "    sum += smp4;\n" +
            "    vec4 result = sum / 8.0;\n" +
            "    fragColor = vec4(result.rgb / result.a, result.a);\n" +
            "}";

    private final String kawaseUp = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D inTexture, textureToCheck;\n" +
            "uniform vec2 halfpixel, offset, iResolution;\n" +
            "uniform int check;\n" +
            "\n" +
            "void main() {\n" +
            "    vec2 uv = vec2(gl_FragCoord.xy / iResolution);\n" +
            "    vec4 sum = texture(inTexture, uv + vec2(-halfpixel.x * 2.0, 0.0) * offset);\n" +
            "    sum += texture(inTexture, uv + vec2(-halfpixel.x, halfpixel.y) * offset) * 2.0;\n" +
            "    sum += texture(inTexture, uv + vec2(0.0, halfpixel.y * 2.0) * offset);\n" +
            "    sum += texture(inTexture, uv + vec2(halfpixel.x, halfpixel.y) * offset) * 2.0;\n" +
            "    sum += texture(inTexture, uv + vec2(halfpixel.x * 2.0, 0.0) * offset);\n" +
            "    sum += texture(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset) * 2.0;\n" +
            "    sum += texture(inTexture, uv + vec2(0.0, -halfpixel.y * 2.0) * offset);\n" +
            "    sum += texture(inTexture, uv + vec2(-halfpixel.x, -halfpixel.y) * offset) * 2.0;\n" +
            "\n" +
            "    fragColor = vec4(sum.rgb /12.0, mix(1.0, texture(textureToCheck, texCoord).a, check));\n" +
            "}\n";

    private final String kawaseDown = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D inTexture;\n" +
            "uniform vec2 offset, halfpixel, iResolution;\n" +
            "\n" +
            "void main() {\n" +
            "    vec2 uv = vec2(gl_FragCoord.xy / iResolution);\n" +
            "    vec4 sum = texture(inTexture, texCoord) * 4.0;\n" +
            "    sum += texture(inTexture, uv - halfpixel.xy * offset);\n" +
            "    sum += texture(inTexture, uv + halfpixel.xy * offset);\n" +
            "    sum += texture(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset);\n" +
            "    sum += texture(inTexture, uv - vec2(halfpixel.x, -halfpixel.y) * offset);\n" +
            "    fragColor = vec4(sum.rgb * .125, 1.0);\n" +
            "}\n";

    private final String gradientMask = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform vec2 location, rectSize;\n" +
            "uniform sampler2D tex;\n" +
            "uniform vec3 color1, color2, color3, color4;\n" +
            "uniform float alpha;\n" +
            "\n" +
            "#define NOISE .5/255.0\n" +
            "\n" +
            "vec3 createGradient(vec2 coords, vec3 color1, vec3 color2, vec3 color3, vec3 color4){\n" +
            "    vec3 color = mix(mix(color1.rgb, color2.rgb, coords.y), mix(color3.rgb, color4.rgb, coords.y), coords.x);\n" +
            "    color += mix(NOISE, -NOISE, fract(sin(dot(coords.xy, vec2(12.9898,78.233))) * 43758.5453));\n" +
            "    return color;\n" +
            "}\n" +
            "\n" +
            "void main() {\n" +
            "    vec2 coords = (gl_FragCoord.xy - location) / rectSize;\n" +
            "    float texColorAlpha = texture(tex, texCoord).a;\n" +
            "    fragColor = vec4(createGradient(coords, color1, color2, color3, color4), texColorAlpha * alpha);\n" +
            "}";

    private final String mask = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform vec2 location, rectSize;\n" +
            "uniform sampler2D u_texture, u_texture2;\n" +
            "void main() {\n" +
            "    vec2 coords = (gl_FragCoord.xy - location) / rectSize;\n" +
            "    float texColorAlpha = texture(u_texture, texCoord).a;\n" +
            "    vec3 tex2Color = texture(u_texture2, texCoord).rgb;\n" +
            "    fragColor = vec4(tex2Color, texColorAlpha);\n" +
            "}";

    private final String gradient = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform vec2 location, rectSize;\n" +
            "uniform sampler2D tex;\n" +
            "uniform vec4 color1, color2, color3, color4;\n" +
            "#define NOISE .5/255.0\n" +
            "\n" +
            "vec4 createGradient(vec2 coords, vec4 color1, vec4 color2, vec4 color3, vec4 color4){\n" +
            "    vec4 color = mix(mix(color1, color2, coords.y), mix(color3, color4, coords.y), coords.x);\n" +
            "    color += mix(NOISE, -NOISE, fract(sin(dot(coords.xy, vec2(12.9898, 78.233))) * 43758.5453));\n" +
            "    return color;\n" +
            "}\n" +
            "\n" +
            "void main() {\n" +
            "    vec2 coords = (gl_FragCoord.xy - location) / rectSize;\n" +
            "    fragColor = createGradient(coords, color1, color2, color3, color4);\n" +
            "}";

    private final String roundedRectGradient = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform vec2 location, rectSize;\n" +
            "uniform vec4 color1, color2, color3, color4;\n" +
            "uniform float radius;\n" +
            "\n" +
            "#define NOISE .5/255.0\n" +
            "\n" +
            "float roundSDF(vec2 p, vec2 b, float r) {\n" +
            "    return length(max(abs(p) - b , 0.0)) - r;\n" +
            "}\n" +
            "\n" +
            "vec4 createGradient(vec2 coords, vec4 color1, vec4 color2, vec4 color3, vec4 color4){\n" +
            "    vec4 color = mix(mix(color1, color2, coords.y), mix(color3, color4, coords.y), coords.x);\n" +
            "    color += mix(NOISE, -NOISE, fract(sin(dot(coords.xy, vec2(12.9898, 78.233))) * 43758.5453));\n" +
            "    return color;\n" +
            "}\n" +
            "\n" +
            "void main() {\n" +
            "    vec2 st = texCoord;\n" +
            "    vec2 halfSize = rectSize * .5;\n" +
            "    \n" +
            "    float smoothedAlpha =  (1.0-smoothstep(0.0, 2., roundSDF(halfSize - (texCoord * rectSize), halfSize - radius - 1., radius)));\n" +
            "    vec4 gradient = createGradient(st, color1, color2, color3, color4);" +
            "    fragColor = vec4(gradient.rgb, gradient.a * smoothedAlpha);\n" +
            "}";

    private final String roundedRect = "#version 330 core\n" +
            "\n" +
            "in vec2 texCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform vec2 location, rectSize;\n" +
            "uniform vec4 color;\n" +
            "uniform float radius;\n" +
            "uniform bool blur;\n" +
            "\n" +
            "float roundSDF(vec2 p, vec2 b, float r) {\n" +
            "    return length(max(abs(p) - b, 0.0)) - r;\n" +
            "}\n" +
            "\n" +
            "\n" +
            "void main() {\n" +
            "    vec2 rectHalf = rectSize * .5;\n" +
            "    float smoothedAlpha =  (1.0-smoothstep(0.0, 1.0, roundSDF(rectHalf - (texCoord * rectSize), rectHalf - radius - 1., radius))) * color.a;\n" +
            "    fragColor = vec4(color.rgb, smoothedAlpha);\n" +
            "\n" +
            "}";
}
