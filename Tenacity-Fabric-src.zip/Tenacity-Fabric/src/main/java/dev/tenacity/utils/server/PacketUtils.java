package dev.tenacity.utils.server;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.player.UpdateEvent;
import dev.tenacity.utils.Utils;
import net.minecraft.network.packet.Packet;

public class PacketUtils implements Utils {

    public static boolean skipSendEvent;

    public static void sendPacket(Packet<?> packet, boolean silent) {
        if (mc.getNetworkHandler() == null) return;
        if (silent) {
            skipSendEvent = true;
        }
        mc.getNetworkHandler().sendPacket(packet);
        skipSendEvent = false;
    }

    public static void sendPacketNoEvent(Packet packet) {
        sendPacket(packet, true);
    }

    public static void sendPacket(Packet packet) {
        sendPacket(packet, false);
    }

    public static boolean isPacketValid(final Packet packet) {
        return packet != null && mc.getNetworkHandler() != null && mc.getNetworkHandler().getConnection().isOpen();
    }
}
