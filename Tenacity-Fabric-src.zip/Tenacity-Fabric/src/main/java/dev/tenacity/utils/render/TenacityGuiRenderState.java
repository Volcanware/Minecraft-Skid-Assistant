package dev.tenacity.utils.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;

import java.util.ArrayList;
import java.util.List;

/**
 * A SimpleGuiElementRenderState that submits an arbitrary set of quads
 * (each with per-vertex colors, optional UVs) under one pipeline.
 * Used for rounded-rect corner fans and multi-corner gradients — the things
 * the stock fill/drawTexture helpers can't express.
 */
public class TenacityGuiRenderState implements SimpleGuiElementRenderState {

    private final RenderPipeline pipeline;
    private final TextureSetup textureSetup;
    private final Matrix3x2f pose;
    private final ScreenRect scissorArea;
    private final boolean textured;

    private final List<float[]> positions = new ArrayList<>();
    private final List<float[]> uvs = new ArrayList<>();
    private final List<int[]> colors = new ArrayList<>();

    public TenacityGuiRenderState(RenderPipeline pipeline, TextureSetup textureSetup,
                                  Matrix3x2fc pose, ScreenRect scissorArea, boolean textured) {
        this.pipeline = pipeline;
        this.textureSetup = textureSetup;
        this.pose = new Matrix3x2f(pose);
        this.scissorArea = scissorArea;
        this.textured = textured;
    }

    /** Adds a quad: 4 corner positions (x0,y0..x3,y3), 4 colors, 4 uv pairs if textured. */
    public void addQuad(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3,
                        int c0, int c1, int c2, int c3) {
        positions.add(new float[]{x0, y0, x1, y1, x2, y2, x3, y3});
        colors.add(new int[]{c0, c1, c2, c3});
        uvs.add(null);
    }

    public void addQuad(float x0, float y0, float u0, float v0,
                        float x1, float y1, float u1, float v1,
                        float x2, float y2, float u2, float v2,
                        float x3, float y3, float u3, float v3,
                        int c0, int c1, int c2, int c3) {
        positions.add(new float[]{x0, y0, x1, y1, x2, y2, x3, y3});
        uvs.add(new float[]{u0, v0, u1, v1, u2, v2, u3, v3});
        colors.add(new int[]{c0, c1, c2, c3});
    }

    @Override
    public ScreenRect bounds() {
        if (positions == null || positions.isEmpty()) return ScreenRect.empty();
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (float[] q : positions) {
            minX = Math.min(minX, Math.min(q[0], q[2]));
            minY = Math.min(minY, Math.min(q[1], q[3]));
            maxX = Math.max(maxX, Math.max(q[4], q[6]));
            maxY = Math.max(maxY, Math.max(q[5], q[7]));
        }
        return new ScreenRect((int) minX, (int) minY, (int) Math.ceil(maxX - minX), (int) Math.ceil(maxY - minY));
    }

    @Override
    public void setupVertices(VertexConsumer vertexConsumer) {
        for (int i = 0; i < positions.size(); i++) {
            float[] p = positions.get(i);
            int[] c = colors.get(i);
            float[] uv = uvs.get(i);
            // Vanilla quads emit TL,BL,BR,TR; our addQuad callers pass TL,TR,BR,BL.
            // Reorder so winding matches the GUI pipeline (backfaces get culled otherwise).
            int[] order = {0, 3, 2, 1};
            for (int vi = 0; vi < 4; vi++) {
                int v = order[vi];
                VertexConsumer vc = vertexConsumer.vertex(pose, p[v * 2], p[v * 2 + 1]);
                if (textured && uv != null) {
                    vc = vc.texture(uv[v * 2], uv[v * 2 + 1]);
                }
                vc.color(c[v]);
            }
        }
    }

    @Override
    public RenderPipeline pipeline() {
        return pipeline;
    }

    @Override
    public TextureSetup textureSetup() {
        return textureSetup;
    }

    @Override
    public ScreenRect scissorArea() {
        return scissorArea;
    }
}
