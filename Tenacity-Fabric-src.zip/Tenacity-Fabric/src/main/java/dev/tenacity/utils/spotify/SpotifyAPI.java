package dev.tenacity.utils.spotify;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpServer;
import dev.tenacity.Tenacity;

import java.awt.*;
import java.io.File;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Spotify Web API backend — PKCE auth flow + playback polling via java.net.http.
 * Set a client ID (from a Spotify developer app with redirect http://localhost:4030)
 * in the module settings, then enable to connect.
 */
public class SpotifyAPI {

    private static final String CODE_CHALLENGE = "w6iZIj99vHGtEx_NVl9u3sthTN646vvkiP8OMCGfPmo";
    private static final String CODE_VERIFIER = "NlJx4kD4opk4HY7zBM6WfUHxX7HoF8A2TUhOIPGA74w";
    private static final String REDIRECT = "http://localhost:4030";
    public static final File CLIENT_ID_DIR = new File(Tenacity.DIRECTORY, "SpotifyID.json");

    public static boolean hasTrack;
    public static boolean isPlaying;
    public static String currentTrackName = "";
    public static String currentArtistName = "";
    public static int duration = 1;
    public static int position = 0;
    public static boolean authenticated;

    private static String clientId;
    private static String accessToken;
    private static String refreshToken;
    private static HttpServer callbackServer;
    private static ScheduledExecutorService pollThread;
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    public static void build(String id) {
        clientId = id;
    }

    public static void connect() {
        if (authenticated || clientId == null || clientId.isEmpty()) return;
        try {
            String scope = URLEncoder.encode("user-read-playback-state user-read-playback-position user-modify-playback-state user-read-currently-playing", StandardCharsets.UTF_8);
            URI authUri = URI.create("https://accounts.spotify.com/authorize?client_id=" + clientId
                    + "&response_type=code&redirect_uri=" + URLEncoder.encode(REDIRECT, StandardCharsets.UTF_8)
                    + "&code_challenge_method=S256&code_challenge=" + CODE_CHALLENGE + "&scope=" + scope);
            Desktop.getDesktop().browse(authUri);
            if (callbackServer != null) callbackServer.stop(0);
            callbackServer = HttpServer.create(new InetSocketAddress(4030), 0);
            callbackServer.createContext("/", ctx -> {
                String query = ctx.getRequestURI().getQuery();
                String msg;
                if (query != null && query.startsWith("code=")) {
                    exchangeCode(query.substring(5));
                    msg = "Successfully authorized. You can close this window, have fun on Tenacity!";
                } else {
                    msg = "Unable to authorize client, re-toggle the module.";
                }
                ctx.sendResponseHeaders(200, msg.length());
                ctx.getResponseBody().write(msg.getBytes());
                ctx.getResponseBody().close();
                callbackServer.stop(0);
            });
            callbackServer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void exchangeCode(String code) {
        try {
            String body = "grant_type=authorization_code&code=" + code
                    + "&redirect_uri=" + URLEncoder.encode(REDIRECT, StandardCharsets.UTF_8)
                    + "&client_id=" + clientId + "&code_verifier=" + CODE_VERIFIER;
            JsonObject res = tokenRequest(body);
            if (res == null) return;
            accessToken = res.get("access_token").getAsString();
            if (res.has("refresh_token")) refreshToken = res.get("refresh_token").getAsString();
            authenticated = true;
            startPolling(res.has("expires_in") ? res.get("expires_in").getAsInt() : 3600);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void refresh() {
        try {
            String body = "grant_type=refresh_token&refresh_token=" + refreshToken + "&client_id=" + clientId;
            JsonObject res = tokenRequest(body);
            if (res == null) return;
            accessToken = res.get("access_token").getAsString();
            if (res.has("refresh_token")) refreshToken = res.get("refresh_token").getAsString();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static JsonObject tokenRequest(String formBody) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create("https://accounts.spotify.com/api/token"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(formBody)).build();
        HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) return null;
        return JsonParser.parseString(resp.body()).getAsJsonObject();
    }

    private static void startPolling(int expiresIn) {
        stopPolling();
        pollThread = Executors.newScheduledThreadPool(2);
        // token refresh at ~80% of expiry
        pollThread.scheduleAtFixedRate(SpotifyAPI::refresh, (long) (expiresIn * 0.8), (long) (expiresIn * 0.8), TimeUnit.SECONDS);
        pollThread.scheduleAtFixedRate(SpotifyAPI::pollPlayback, 0, 1, TimeUnit.SECONDS);
    }

    private static void stopPolling() {
        if (pollThread != null) pollThread.shutdownNow();
        pollThread = null;
    }

    private static void pollPlayback() {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1/me/player"))
                    .header("Authorization", "Bearer " + accessToken).GET().build();
            HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 401) { refresh(); return; }
            if (resp.statusCode() != 200 || resp.body() == null || resp.body().isEmpty()) { hasTrack = false; return; }
            JsonObject player = JsonParser.parseString(resp.body()).getAsJsonObject();
            isPlaying = player.has("is_playing") && player.get("is_playing").getAsBoolean();
            position = player.has("progress_ms") && !player.get("progress_ms").isJsonNull() ? player.get("progress_ms").getAsInt() : 0;
            if (player.has("item") && !player.get("item").isJsonNull()) {
                JsonObject item = player.getAsJsonObject("item");
                currentTrackName = item.has("name") ? item.get("name").getAsString() : "";
                duration = item.has("duration_ms") ? item.get("duration_ms").getAsInt() : 1;
                if (item.has("artists") && item.getAsJsonArray("artists").size() > 0) {
                    currentArtistName = item.getAsJsonArray("artists").get(0).getAsJsonObject().get("name").getAsString();
                }
                hasTrack = true;
            } else {
                hasTrack = false;
            }
        } catch (Exception e) {
            hasTrack = false;
        }
    }

    private static void playerRequest(String method, String path) {
        if (!authenticated) return;
        try {
            HttpRequest.Builder b = HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1/me/player" + path))
                    .header("Authorization", "Bearer " + accessToken);
            if (method.equals("PUT")) b.PUT(HttpRequest.BodyPublishers.noBody());
            else b.method(method, HttpRequest.BodyPublishers.noBody());
            HTTP.sendAsync(b.build(), HttpResponse.BodyHandlers.discarding());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void play() { playerRequest("PUT", "/play"); }
    public static void pause() { playerRequest("PUT", "/pause"); }
    public static void next() { playerRequest("POST", "/next"); }
    public static void prev() { playerRequest("POST", "/previous"); }
    public static void togglePlay() { if (isPlaying) pause(); else play(); }
    public static void setVolume(int v) { playerRequest("PUT", "/volume?volume_percent=" + Math.max(0, Math.min(100, v))); }

    public static void disconnect() {
        authenticated = false;
        hasTrack = false;
        stopPolling();
        if (callbackServer != null) callbackServer.stop(0);
        callbackServer = null;
    }
}
