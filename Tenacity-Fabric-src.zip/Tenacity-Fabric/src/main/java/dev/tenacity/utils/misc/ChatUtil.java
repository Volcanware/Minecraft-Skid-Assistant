package dev.tenacity.utils.misc;

import dev.tenacity.utils.Utils;
import net.minecraft.text.Text;

public class ChatUtil implements Utils {

    public static void print(boolean prefix, String message) {
        if (mc.player != null) {
            if (prefix) message = "§7[§d§lTENACITY§r§7] " + message;
            mc.player.sendMessage(Text.literal(message), false);
        }
    }

    public static void print(String message) {
        print(true, message);
    }

    public static void error(String message) {
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("§7[§c§lERROR§r§7] " + message), false);
        }
    }

    public static void send(String message) {
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        if (message.startsWith("/")) {
            mc.getNetworkHandler().sendChatCommand(message.substring(1));
        } else {
            mc.getNetworkHandler().sendChatMessage(message);
        }
    }

    public static void irc(String message) {
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("IRC-" + message), false);
        }
    }
}
