package dev.tenacity.utils.render;

public class StencilUtil {
    // Stencil clipping isn't wired into the 1.21.11 GUI pipeline; scissor-based
    // clipping via RenderUtil.scissor covers the same GUI cases.
}
