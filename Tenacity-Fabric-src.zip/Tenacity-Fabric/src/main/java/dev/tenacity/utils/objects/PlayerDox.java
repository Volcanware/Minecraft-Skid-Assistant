package dev.tenacity.utils.objects;

import dev.tenacity.utils.misc.DoxUtil;
import net.minecraft.entity.LivingEntity;

/**
 * @author cedo
 * @since 03/15/2022
 */
public class PlayerDox {
    private final LivingEntity player;
    private final String state, liscenseNumber, DOB, expirationDate, topAddress, bottomAddress;
    private final boolean male;

    public PlayerDox(LivingEntity entity) {
        this.player = entity;
        this.state = DoxUtil.getRandomState();
        liscenseNumber = DoxUtil.randomAlphaNumeric(9).toUpperCase();
        DOB = DoxUtil.randomDOB();
        expirationDate = DoxUtil.randomExpirationDate(DOB);
        this.topAddress = DoxUtil.getTopAddress();
        this.bottomAddress = DoxUtil.getBottomAddress(state);
        male = Math.random() > .2;
    }

    public LivingEntity getPlayer() {
        return player;
    }

    public String getState() {
        return state;
    }

    public String getLiscenseNumber() {
        return liscenseNumber;
    }

    public String getDOB() {
        return DOB;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public String getTopAddress() {
        return topAddress;
    }

    public String getBottomAddress() {
        return bottomAddress;
    }

    public boolean isMale() {
        return male;
    }
}
