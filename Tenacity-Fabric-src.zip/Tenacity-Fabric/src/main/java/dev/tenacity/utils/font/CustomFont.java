package dev.tenacity.utils.font;

import dev.tenacity.utils.Utils;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.render.RenderUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

/**
 * Custom TTF font renderer. Builds a glyph atlas with AWT and draws it through
 * DrawContext textured quads (GUI_TEXTURED pipeline), mirroring the 1.8.9
 * immediate-mode renderer.
 */
public class CustomFont implements AbstractFontRenderer {

    /** Render scale for the atlas — original draws the 2x atlas at half size. */
    public static final float SCALE = 0.5f;

    private static int[] colorCode;
    private static final String colorcodeIdentifiers = "0123456789abcdefklmnor";
    private final Font font;
    private final String resourceId;
    private CustomFont boldFont;
    private final FontData regular = new FontData(Font.PLAIN), italic = new FontData(Font.ITALIC);

    private int fontHeight;
    private static final float KERNING = 8.2f;

    public CustomFont(Font font, String resourceId) {
        generateColorCodes();
        this.font = font;
        this.resourceId = resourceId;
        setupTexture(regular);
        setupTexture(italic);
    }

    public void setBoldFont(CustomFont boldFont) { this.boldFont = boldFont; }
    public CustomFont getBoldFont() { return boldFont; }
    public boolean hasBoldFont() { return this.boldFont != null; }

    private void setupTexture(FontData fontData) {
        BufferedImage fakeImage = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = (Graphics2D) fakeImage.getGraphics();
        Font currentFont = fontData.textType == 0 ? font : font.deriveFont(fontData.textType);
        graphics.setFont(currentFont);
        handleSprites(fontData, currentFont, graphics);
    }

    @Override
    public void drawSmoothString(String text, double x2, float y2, int color) {
        this.drawString(text, x2, y2, color, false, KERNING, true);
    }

    @Override
    public void drawSmoothStringWithShadow(String text, double x2, float y2, int color) {
        this.drawString(text, x2, y2, color, true, KERNING, true);
    }

    @Override
    public int drawCenteredString(String name, float x, float y, int color) {
        return this.drawString(name, x - getStringWidth(name) / 2f, y, color, false);
    }

    @Override
    public void drawCenteredString(String name, float x, float y, Color color) {
        this.drawCenteredString(name, x, y, color.getRGB());
    }

    @Override
    public void drawCenteredStringWithShadow(String text, float x, float y, int color) {
        this.drawString(text, x - getStringWidth(text) / 2f, y, color, true);
    }

    @Override
    public int drawStringWithShadow(String name, float x, float y, int color) {
        return this.drawString(name, x, y, color, true);
    }

    @Override
    public void drawStringWithShadow(String name, float x, float y, Color color) {
        this.drawString(name, x, y, color.getRGB(), true);
    }

    @Override
    public int drawString(String text, float x, float y, int color, boolean shadow) {
        return (int) this.drawString(text, x, y, color, shadow, KERNING, false);
    }

    @Override
    public int drawString(String name, float x, float y, int color) {
        return this.drawString(name, x, y, color, false);
    }

    @Override
    public void drawString(String name, float x, float y, Color color) {
        this.drawString(name, x, y, color.getRGB());
    }

    public float drawString(String text, double x, double y, int color, boolean shadow, float kerning, boolean smooth) {
        DrawContext ctx = Utils.getCtx();
        if (ctx == null || text == null || text.isEmpty()) return (float) x;
        float returnVal = drawCustomChars(ctx, text, x, y, kerning, color, shadow);
        return returnVal;
    }

    private float drawCustomChars(DrawContext ctx, String text, double x, double y, float kerning, int color, boolean shadow) {
        FontData currentData = this.regular;
        float alpha = (float) (color >> 24 & 255) / 255f;
        // Original renders the glyph atlas at 2x and scales down via GL
        // (GlStateManager.scale(.5)); DrawContext has no src/dst size overload,
        // so replicate it with the GUI matrix.
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(SCALE, SCALE);
        // original: x=(x-1)*2, y=(y-3)*2 — glyphs sit 1px left / 3px up
        x = x * 2 - 2;
        y = y * 2 - 6;

        boolean bold = false, italic = false, strikethrough = false, underline = false;

        for (int index = 0; index < text.length(); index++) {
            char character = text.charAt(index);

            if (character == '\u00a7') {
                int colorIndex = 21;
                try {
                    colorIndex = colorcodeIdentifiers.indexOf(text.charAt(index + 1));
                } catch (Exception ignored) {
                }

                if (colorIndex < 16) {
                    bold = false;
                    italic = false;
                    underline = false;
                    strikethrough = false;
                    currentData = this.regular;

                    if (colorIndex < 0) {
                        colorIndex = 15;
                    }
                    if (shadow) {
                        colorIndex += 16;
                    }
                    color = withAlpha(colorCode[colorIndex], alpha);
                } else {
                    switch (colorIndex) {
                        case 17:
                            if (hasBoldFont()) {
                                bold = true;
                                currentData = italic ? this.boldFont.italic : this.boldFont.regular;
                            }
                            break;
                        case 18:
                            strikethrough = true;
                            break;
                        case 19:
                            underline = true;
                            break;
                        case 20:
                            italic = true;
                            if (bold && hasBoldFont()) {
                                currentData = this.boldFont.italic;
                            } else {
                                currentData = this.italic;
                            }
                            break;
                        default:
                            bold = false;
                            italic = false;
                            underline = false;
                            strikethrough = false;
                            currentData = this.regular;
                            break;
                    }
                }
                ++index;
            } else if (character < currentData.chars.length && currentData.chars[character] != null) {
                drawLetter(ctx, x, y, currentData, strikethrough, underline, character, color);
                x += MathUtils.roundToHalf(currentData.chars[character].width - KERNING);
            }
        }
        ctx.getMatrices().popMatrix();
        return (float) (x * SCALE);
    }

    public void drawLetter(DrawContext ctx, double x, double y, FontData currentData,
                           boolean strikethrough, boolean underline, char character, int color) {
        CharData charData = currentData.chars[character];
        if (charData == null || currentData.textureId == null) return;
        // Called inside the 0.5-scaled matrix — draw the full-size glyph at the
        // doubled coordinates.
        int gw = (int) Math.ceil(charData.width - KERNING), gh = charData.height;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, currentData.textureId,
                Math.round((float) x), Math.round((float) y),
                charData.storedX + 2, charData.storedY,
                gw, gh,
                currentData.imageSize[0], Math.max(1, currentData.imageSize[1]),
                color);
        if (strikethrough) {
            ctx.fill(Math.round((float) x), (int) (y + gh / 2f), Math.round((float) (x + gw)), (int) (y + gh / 2f) + 1, color);
        }
        if (underline) {
            ctx.fill(Math.round((float) x), (int) (y + gh), Math.round((float) (x + gw)), (int) (y + gh) + 1, color);
        }
    }

    private static int withAlpha(int rgb, float alpha) {
        return ((int) (alpha * 255) << 24) | (rgb & 0xFFFFFF);
    }

    @Override
    public float getMiddleOfBox(float height) {
        return height / 2f - getHeight() / 2f;
    }

    @Override
    public String trimStringToWidth(String text, int width) {
        return this.trimStringToWidth(text, width, false);
    }

    @Override
    public String trimStringToWidth(String text, int width, boolean reverse) {
        StringBuilder stringbuilder = new StringBuilder();
        float lineWidth = 0.0F;
        int offset = reverse ? text.length() - 1 : 0;
        int increment = reverse ? -1 : 1;

        for (int index = offset; index >= 0 && index < text.length() && lineWidth < (float) width; index += increment) {
            char character = text.charAt(index);
            float charWidth = this.getCharWidthFloat(character);

            if (reverse) {
                stringbuilder.insert(0, character);
            } else {
                stringbuilder.append(character);
            }

            lineWidth += charWidth;
            if (lineWidth > (float) width) {
                break;
            }
        }
        return stringbuilder.toString();
    }

    private float getCharWidthFloat(char c) {
        if (c < regular.chars.length && regular.chars[c] != null) {
            return (regular.chars[c].width - KERNING);
        }
        return 0;
    }

    @Override
    public int getStringWidth(String name) {
        return (int) getStringWidthFloat(name);
    }

    /**
     * Word-wraps {@code text} into lines no wider than {@code maxWidth} and draws up to
     * {@code maxLines} of them starting at ({@code x}, {@code y}).
     */
    public void drawWrappedText(String text, float x, float y, int color, float maxWidth, int maxLines) {
        if (text == null || text.isEmpty() || maxLines <= 0) return;
        float lineY = y;
        int lines = 0;
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ", -1)) {
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (line.length() > 0 && getStringWidthFloat(candidate) > maxWidth) {
                drawString(line.toString(), x, lineY, color);
                if (++lines >= maxLines) return;
                lineY += getHeight();
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (line.length() > 0 && lines < maxLines) {
            drawString(line.toString(), x, lineY, color);
        }
    }

    @Override
    public float getStringWidthFloat(String name) {
        if (name == null) return 0;
        float width = 0;
        CharData[] currentData = regular.chars;
        for (int index = 0; index < name.length(); index++) {
            char character = name.charAt(index);
            if (character == '\u00a7') {
                int colorIndex = colorcodeIdentifiers.indexOf(name.charAt(index + 1));
                switch (colorIndex) {
                    case 17:
                        if (hasBoldFont()) {
                            currentData = this.boldFont.regular.chars;
                        }
                        break;
                    case 20:
                        currentData = this.regular.chars;
                        break;
                    default:
                        currentData = regular.chars;
                        break;
                }
                ++index;
            } else if (character < currentData.length && currentData[character] != null) {
                width += currentData[character].width - KERNING;
            }
        }
        return width * SCALE;
    }

    public CharData[] getChars() {
        return regular.chars;
    }

    @Override
    public int getHeight() {
        return (int) ((fontHeight - 8) * SCALE);
    }

    public int getFontHeight() {
        return fontHeight;
    }

    public static class FontData {
        private final CharData[] chars = new CharData[256];
        private final int textType;
        private Identifier textureId;
        private final int[] imageSize = new int[]{512, 0};

        public FontData(int textType) {
            this.textType = textType;
        }
    }

    public static class CharData {
        private float width;
        private int height, storedX, storedY;
    }

    private void generateColorCodes() {
        if (colorCode == null) {
            colorCode = new int[32];
            for (int i = 0; i < 32; ++i) {
                final int noClue = (i >> 3 & 0x1) * 85;
                int red = (i >> 2 & 0x1) * 170 + noClue;
                int green = (i >> 1 & 0x1) * 170 + noClue;
                int blue = (i & 0x1) * 170 + noClue;
                if (i == 6) {
                    red += 85;
                }
                if (i >= 16) {
                    red /= 4;
                    green /= 4;
                    blue /= 4;
                }
                colorCode[i] = ((red & 0xFF) << 16 | (green & 0xFF) << 8 | (blue & 0xFF));
            }
        }
    }

    private void handleSprites(FontData fontData, Font currentFont, Graphics2D graphics2D) {
        handleSprites(fontData, currentFont, graphics2D, false);
    }

    private void handleSprites(FontData fontData, Font currentFont, Graphics2D graphics2D, boolean drawString) {
        int charHeight = 0;
        int positionX = 0;
        int positionY = 1;
        int index = 0;
        FontMetrics fontMetrics = graphics2D.getFontMetrics();

        if (drawString) {
            BufferedImage image = new BufferedImage(fontData.imageSize[0], Math.max(1, fontData.imageSize[1]), BufferedImage.TYPE_INT_ARGB);
            Graphics2D graphics = (Graphics2D) image.getGraphics();

            graphics.setFont(currentFont);
            graphics.setColor(new Color(255, 255, 255, 0));
            graphics.fillRect(0, 0, fontData.imageSize[0], fontData.imageSize[1]);
            graphics.setColor(Color.WHITE);
            graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
            graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            for (CharData data : fontData.chars) {
                char c = (char) index;
                if (data != null) {
                    graphics.drawString(String.valueOf(c), data.storedX + 2, data.storedY + fontMetrics.getAscent());
                }
                index++;
            }

            fontData.textureId = registerAtlas(image, fontData.textType);
        } else {
            while (index < fontData.chars.length) {
                char c = (char) index;
                CharData charData = new CharData();
                Rectangle2D dimensions = fontMetrics.getStringBounds(String.valueOf(c), graphics2D);
                charData.width = (float) dimensions.getBounds().width + KERNING;
                charData.height = dimensions.getBounds().height;

                if (positionX + charData.width >= fontData.imageSize[0]) {
                    positionX = 0;
                    positionY += charHeight;
                    charHeight = 0;
                }

                if (charData.height > charHeight) {
                    charHeight = charData.height;
                }

                charData.storedX = positionX;
                charData.storedY = positionY;

                if (charData.height > this.fontHeight) {
                    this.fontHeight = charData.height;
                }

                fontData.chars[index] = charData;
                positionX += charData.width;
                fontData.imageSize[1] = positionY + fontMetrics.getAscent();
                ++index;
            }

            handleSprites(fontData, currentFont, graphics2D, true);
        }
    }

    private Identifier registerAtlas(BufferedImage image, int textType) {
        int w = image.getWidth(), h = image.getHeight();
        NativeImage nativeImage = new NativeImage(w, h, true);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                nativeImage.setColorArgb(x, y, image.getRGB(x, y));
            }
        }
        NativeImageBackedTexture texture = new NativeImageBackedTexture(() -> "tenacity_font", w, h, false);
        texture.setImage(nativeImage);
        texture.upload();
        Identifier id = Identifier.of("tenacity", ("font_" + resourceId + "_" + textType).toLowerCase(java.util.Locale.ROOT));
        Utils.mc.getTextureManager().registerTexture(id, texture);
        return id;
    }
}
