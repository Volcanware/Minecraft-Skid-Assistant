package dev.tenacity.utils.objects;

import dev.tenacity.utils.font.CustomFont;

/**
 * TextField that masks its contents. Only the display is masked;
 * getText() still returns the raw value.
 */
public class PasswordField extends TextField {

    public PasswordField(CustomFont font) {
        super(font);
    }

    @Override
    protected String getRenderText() {
        return "*".repeat(getText().length());
    }
}
