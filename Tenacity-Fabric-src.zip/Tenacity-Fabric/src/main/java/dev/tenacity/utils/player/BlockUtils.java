package dev.tenacity.utils.player;

import dev.tenacity.utils.Utils;
import net.minecraft.block.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

public class BlockUtils implements Utils {

    public static boolean isValidBlock(BlockPos pos) {
        return isValidBlock(mc.world.getBlockState(pos).getBlock(), false);
    }

    public static Block getBlockAtPos(BlockPos pos) {
        BlockState blockState = mc.world.getBlockState(pos);
        return blockState.getBlock();
    }

    public static boolean isValidBlock(Block block, boolean placing) {
        BlockState state = block.getDefaultState();
        if (block instanceof CarpetBlock
                || block instanceof SnowBlock
                || block instanceof BlockWithEntity
                || block instanceof AbstractPressurePlateBlock
                || !state.getFluidState().isEmpty()) {
            return false;
        }
        if (placing && (block instanceof SlabBlock
                || block instanceof StairsBlock
                || block instanceof LadderBlock
                || block instanceof PaneBlock
                || block instanceof WallBlock
                || block instanceof CobwebBlock
                || block instanceof CactusBlock
                || block instanceof FallingBlock
                || block == Blocks.GLASS_PANE
                || block == Blocks.IRON_BARS)) {
            return false;
        }
        return (state.isSolid() || state.isOpaque() || state.isOpaqueFullCube());
    }

    public static boolean isInLiquid() {
        if (mc.player == null) return false;
        Box boundingBox = mc.player.getBoundingBox();
        for (int x = MathHelper.floor(boundingBox.minX); x < MathHelper.floor(boundingBox.maxX) + 1; x++) {
            for (int z = MathHelper.floor(boundingBox.minZ); z < MathHelper.floor(boundingBox.maxZ) + 1; z++) {
                BlockPos pos = new BlockPos(x, (int) boundingBox.minY, z);
                BlockState state = mc.world.getBlockState(pos);
                if (!state.isAir()) {
                    return !state.getFluidState().isEmpty();
                }
            }
        }
        return false;
    }

    public static boolean isOnLiquid() {
        if (mc.player == null) return false;
        Box boundingBox = mc.player.getBoundingBox();
        boundingBox = boundingBox.contract(0.01D, 0.0D, 0.01D).offset(0.0D, -0.01D, 0.0D);
        boolean onLiquid = false;
        int y = (int) boundingBox.minY;

        for (int x = MathHelper.floor(boundingBox.minX); x < MathHelper.floor(boundingBox.maxX + 1.0D); ++x) {
            for (int z = MathHelper.floor(boundingBox.minZ); z < MathHelper.floor(boundingBox.maxZ + 1.0D); ++z) {
                BlockState state = mc.world.getBlockState(BlockPos.ofFloored(x, y, z));
                if (!state.isAir()) {
                    if (state.getFluidState().isEmpty()) return false;
                    onLiquid = true;
                }
            }
        }

        return onLiquid;
    }

}
