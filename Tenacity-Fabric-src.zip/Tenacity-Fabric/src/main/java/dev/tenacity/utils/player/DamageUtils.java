package dev.tenacity.utils.player;

import dev.tenacity.utils.Utils;
import dev.tenacity.utils.server.PacketUtils;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class DamageUtils implements Utils {

    public static void damage(DamageType type) {
        if (mc.player == null) return;
        double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
        switch (type) {
            case WATCHDOGUP:
                for (int i = 0; i < 49; i++) {
                    PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(), mc.player.getY() + 0.0625, mc.player.getZ(), false, false));
                    PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(), mc.player.getY(), mc.player.getZ(), false, false));
                }
                PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(), mc.player.getY(), mc.player.getZ(), true, false));
                break;
            case WATCHDOGDOWN:
                for (int i = 0; i < 49; i++) {
                    PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(), mc.player.getY() - 0.0625, mc.player.getZ(), false, false));
                    PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(), mc.player.getY(), mc.player.getZ(), false, false));
                }
                PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(), mc.player.getY(), mc.player.getZ(), true, false));
                break;
            case NCP:
                for (int i = 0; i <= MovementUtils.getMaxFallDist() / 0.0625; i++) {
                    send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0625, z, false, false));
                    send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, false));
                }
                send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, true, false));
                break;
            case VANILLA:
                send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 3.01, z, false, false));
                send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, false));
                send(new PlayerMoveC2SPacket.OnGroundOnly(true, false));
                break;
            case VERUS:
                for (int i = 0; i < 3; i++) {
                    for (double offset : new double[]{0.41999998688698, 0.7531999805212, 1.00133597911214, 1.16610926093821,
                            1.24918707874468, 1.1707870772188, 1.0155550727022, 0.78502770378924, 0.4807108763317, 0.10408037809304}) {
                        send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + offset, z, false, false));
                    }
                    send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, false));
                }
                send(new PlayerMoveC2SPacket.OnGroundOnly(true, false));
            case SUFFOCATE:
                send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y - 2, z, false, false));
                break;
        }
    }

    public enum DamageType {
        WATCHDOGUP, WATCHDOGDOWN, NCP, VANILLA, VERUS, SUFFOCATE
    }

    private static void send(Packet<?> packet) {
        PacketUtils.sendPacketNoEvent(packet);
    }

}
