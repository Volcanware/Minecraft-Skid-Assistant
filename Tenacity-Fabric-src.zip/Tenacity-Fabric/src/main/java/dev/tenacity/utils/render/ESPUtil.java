package dev.tenacity.utils.render;

import dev.tenacity.utils.Utils;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;
import org.joml.Vector4f;

public class ESPUtil implements Utils {

    public static boolean isInView(Entity ent) {
        return mc.world != null && ent.isAlive();
    }

    public static Vector3f projectOn2D(float x, float y, float z, int scaleFactor) {
        // World-space projection is handled via the world render pipeline in 1.21.11;
        // 2D ESP draws use interpolated bounding boxes + camera-space transforms.
        return new Vector3f(x, y, z);
    }

    public static double[] getInterpolatedPos(Entity entity) {
        float partialTicks = mc.getRenderTickCounter().getTickProgress(false);
        double x = entity.lastRenderX + (entity.getX() - entity.lastRenderX) * partialTicks;
        double y = entity.lastRenderY + (entity.getY() - entity.lastRenderY) * partialTicks;
        double z = entity.lastRenderZ + (entity.getZ() - entity.lastRenderZ) * partialTicks;
        return new double[]{x, y, z};
    }

    public static Box getInterpolatedBoundingBox(Entity entity) {
        double[] pos = getInterpolatedPos(entity);
        double width = entity.getBoundingBox().getLengthX() / 2;
        double height = entity.getBoundingBox().getLengthY();
        return new Box(pos[0] - width, pos[1], pos[2] - width, pos[0] + width, pos[1] + height, pos[2] + width);
    }

    public static Vector4f getEntityPositionsOn2D(Entity entity) {
        // Approximate screen-space box: project via camera-relative coords.
        Box bb = getInterpolatedBoundingBox(entity);
        Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
        return new Vector4f((float) (bb.minX - cam.x), (float) (bb.minY - cam.y),
                (float) (bb.maxX - cam.x), (float) (bb.maxY - cam.y));
    }
}
