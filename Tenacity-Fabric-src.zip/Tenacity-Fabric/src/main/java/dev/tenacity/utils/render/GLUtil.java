package dev.tenacity.utils.render;

import dev.tenacity.utils.Utils;

public class GLUtil implements Utils {

    public static int[] enabledCaps = new int[32];

    public static void enableDepth() {}
    public static void disableDepth() {}
    public static void enableCaps(int... caps) {}
    public static void disableCaps() {}
    public static void startBlend() {}
    public static void endBlend() {}
    public static void setup2DRendering(boolean blend) {}
    public static void setup2DRendering() { setup2DRendering(true); }
    public static void end2DRendering() {}

    public static void startRotate(float x, float y, float rotate) {
        if (Utils.getCtx() == null) return;
        Utils.getCtx().getMatrices().translate(x, y);
        Utils.getCtx().getMatrices().rotate((float) Math.toRadians(rotate));
        Utils.getCtx().getMatrices().translate(-x, -y);
    }

    public static void endRotate() {}
}
