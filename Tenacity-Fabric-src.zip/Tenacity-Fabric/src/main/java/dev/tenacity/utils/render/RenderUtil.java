package dev.tenacity.utils.render;

import net.minecraft.client.gl.RenderPipelines;
import dev.tenacity.mixin.DrawContextAccessor;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenPos;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.GuiRenderState;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2f;

import java.awt.*;

public class RenderUtil implements Utils {

    public static double ticks = 0;
    public static long lastFrame = 0;



    /** Submit a quad fan (arbitrary quads with per-vertex colors) through the GUI pipeline. */
    public static void submitQuads(TenacityGuiRenderState state) {
        if (Utils.getCtx() == null) return;
        ((DrawContextAccessor) Utils.getCtx()).tenacity$getState().addSimpleElement(state);
    }

    public static TenacityGuiRenderState newQuadState() {
        GuiRenderState guiState = ((DrawContextAccessor) Utils.getCtx()).tenacity$getState();
        Matrix3x2f pose = new Matrix3x2f(Utils.getCtx().getMatrices());
        ScreenRect scissor = ((DrawContextAccessor) Utils.getCtx()).tenacity$getScissorStack().peekLast();
        if (scissor == null) {
            scissor = new ScreenRect(0, 0, Utils.getCtx().getScaledWindowWidth(), Utils.getCtx().getScaledWindowHeight());
        }
        return new TenacityGuiRenderState(RenderPipelines.GUI, TextureSetup.empty(), pose, scissor, false);
    }

    /** Draws a single flat-color quad at arbitrary coordinates. */
    public static void drawQuad(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, int color) {
        TenacityGuiRenderState s = newQuadState();
        s.addQuad(x0, y0, x1, y1, x2, y2, x3, y3, color, color, color, color);
        submitQuads(s);
    }

    public static void drawRect(float x, float y, float width, float height, int color) {
        if (Utils.getCtx() == null) return;
        Utils.getCtx().fill((int) x, (int) y, (int) (x + width), (int) (y + height), color);
    }

    public static void drawRect(float x, float y, float width, float height, Color color) {
        drawRect(x, y, width, height, color.getRGB());
    }

    public static void drawBorderedRect(float x, float y, float width, float height, final float outlineThickness, int rectColor, int outlineColor) {
        drawRect(x, y, width, height, rectColor);
        drawRect(x, y, width, outlineThickness, outlineColor);
        drawRect(x + width - outlineThickness, y, outlineThickness, height, outlineColor);
        drawRect(x, y + height - outlineThickness, width, outlineThickness, outlineColor);
        drawRect(x, y, outlineThickness, height, outlineColor);
    }

    public static void drawImage(Identifier id, float x, float y, float imgWidth, float imgHeight) {
        if (Utils.getCtx() == null) return;
        Utils.getCtx().drawTexture(RenderPipelines.GUI_TEXTURED, id, (int) x, (int) y, 0, 0, (int) imgWidth, (int) imgHeight, (int) imgWidth, (int) imgHeight);
    }

    public static void drawImage(Identifier id, float x, float y, float imgWidth, float imgHeight, int color) {
        if (Utils.getCtx() == null) return;
        Utils.getCtx().drawTexture(RenderPipelines.GUI_TEXTURED, id, (int) x, (int) y, 0, 0, (int) imgWidth, (int) imgHeight, (int) imgWidth, (int) imgHeight, (int) imgWidth, (int) imgHeight, color);
    }

    public static void drawGradientRect(double left, double top, double right, double bottom, int startColor, int endColor) {
        if (Utils.getCtx() == null) return;
        Utils.getCtx().fillGradient((int) left, (int) top, (int) right, (int) bottom, startColor, endColor);
    }

    public static void drawGradientRectBordered(double left, double top, double right, double bottom, double width, int startColor, int endColor, int borderStartColor, int borderEndColor) {
        drawGradientRect(left + width, top + width, right - width, bottom - width, startColor, endColor);
        drawGradientRect(left + width, top, right - width, top + width, borderStartColor, borderEndColor);
        drawGradientRect(left, top, left + width, bottom, borderStartColor, borderEndColor);
        drawGradientRect(right - width, top, right, bottom, borderStartColor, borderEndColor);
        drawGradientRect(left + width, bottom - width, right - width, bottom, borderStartColor, borderEndColor);
    }

    public static void scissor(double x, double y, double width, double height, Runnable data) {
        scissorStart(x, y, width, height);
        data.run();
        scissorEnd();
    }

    public static void scissor(double x, double y, double width, double height) {
        scissorStart(x, y, width, height);
    }

    public static void scissorStart(double x, double y, double width, double height) {
        if (Utils.getCtx() == null) return;
        Utils.getCtx().enableScissor((int) x, (int) y, (int) (x + width), (int) (y + height));
    }

    public static void scissorEnd() {
        if (Utils.getCtx() == null) return;
        Utils.getCtx().disableScissor();
    }

    public static void setAlphaLimit(float limit) {
        // No-op in the new pipeline: alpha is per-vertex.
    }

    public static void color(int color, float alpha) {
        // Legacy GL color call — no-op; colors are per-vertex now.
    }

    public static void color(int color) {
    }

    public static void bindTexture(int texture) {
    }

    public static void resetColor() {
    }

    public static void fixBlendIssues() {
    }

    public static boolean isHovered(float mouseX, float mouseY, float x, float y, float width, float height) {
        return mouseX >= x && mouseX - x <= width && mouseY >= y && mouseY - y <= height;
    }

    public static void scaleStart(float x, float y, float scale) {
        if (Utils.getCtx() == null) return;
        Utils.getCtx().getMatrices().translate(x, y);
        Utils.getCtx().getMatrices().scale(scale, scale);
        Utils.getCtx().getMatrices().translate(-x, -y);
    }

    public static void scaleEnd() {
    }

    public static void rotateStart(float x, float y, float width, float height, float rotation) {
        if (Utils.getCtx() == null) return;
        Utils.getCtx().getMatrices().translate(x + width / 2, y + height / 2);
        Utils.getCtx().getMatrices().rotate((float) Math.toRadians(rotation));
        Utils.getCtx().getMatrices().translate(-(x + width / 2), -(y + height / 2));
    }

    public static void rotateStartReal(float x, float y, float width, float height, float rotation) {
        rotateStart(x, y, width, height, rotation);
    }

    public static void rotateEnd() {
    }

    public static void drawClickGuiArrow(float x, float y, float size, Animation animation, int color) {
        float size2 = size / 2f;
        float[][] arrowPoints = new float[][]{
                {-size2 + size / 5f, -size2 + size / 2f},
                {-size2 + size / 5f, size2 - size / 2f},
                {-size2 + size / 1.25f, 0},
                {size2 - size / 5f, -size2 + size / 2f},
                {size2 - size / 5f, size2 - size / 2f},
                {size2 - size / 1.25f, 0}
        };
        float interpolation = .5f;
        int iterations = (int) (size / 5f);
        if (animation != null) {
            interpolation = (float) (.5f * animation.getOutput().floatValue());
        }
        // Two arrow strokes approximated with quads
        TenacityGuiRenderState s = newQuadState();
        for (int i = 0; i < 2; i++) {
            int base = i * 3;
            float ax = x + arrowPoints[base][0], ay = y + arrowPoints[base][1];
            float bx = x + arrowPoints[base + 1][0], by = y + arrowPoints[base + 1][1];
            float cx = x + arrowPoints[base + 2][0] * (1 - interpolation * (i == 0 ? -1 : 1)), cy = y + arrowPoints[base + 2][1];
            s.addQuad(ax, ay, bx, by, cx, cy, ax, ay, color, color, color, color);
        }
        submitQuads(s);
    }

    public static void drawUnfilledCircle(double x, double y, float radius, float lineWidth, int color) {
        int alpha = (color >> 24) & 0xff;
        int r = (color >> 16) & 0xff;
        int g = (color >> 8) & 0xff;
        int b = color & 0xff;
        TenacityGuiRenderState s = newQuadState();
        int seg = 40;
        for (int i = 0; i < seg; i++) {
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            float xo0 = (float) (x + Math.cos(a0) * radius), yo0 = (float) (y + Math.sin(a0) * radius);
            float xi0 = (float) (x + Math.cos(a0) * (radius - lineWidth)), yi0 = (float) (y + Math.sin(a0) * (radius - lineWidth));
            float xo1 = (float) (x + Math.cos(a1) * radius), yo1 = (float) (y + Math.sin(a1) * radius);
            float xi1 = (float) (x + Math.cos(a1) * (radius - lineWidth)), yi1 = (float) (y + Math.sin(a1) * (radius - lineWidth));
            s.addQuad(xi0, yi0, xi1, yi1, xo1, yo1, xo0, yo0, color, color, color, color);
        }
        submitQuads(s);
    }

    public static void drawGoodCircle(double x, double y, float radius, int color) {
        drawFilledCircle((float) x, (float) y, radius, color, 30);
    }

    public static void drawCircleNotSmooth(double x, double y, double radius, int color) {
        drawFilledCircle((float) x, (float) y, (float) radius, color, 20);
    }

    public static void drawFilledCircle(float x, float y, float radius, int color, int seg) {
        TenacityGuiRenderState s = newQuadState();
        for (int i = 0; i < seg; i++) {
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            s.addQuad(x, y,
                    (float) (x + Math.cos(a0) * radius), (float) (y + Math.sin(a0) * radius),
                    (float) (x + Math.cos(a1) * radius), (float) (y + Math.sin(a1) * radius),
                    x, y,
                    color, color, color, color);
        }
        submitQuads(s);
    }

    public static void drawFilledCircleNoGL(int x, int y, double r, int c, int quality) {
        drawFilledCircle(x, y, (float) r, c, quality);
    }

    public static void fakeCircleGlow(float posX, float posY, float radius, Color color, float maxAlpha) {
        drawFilledCircle(posX, posY, radius, ColorUtil.applyOpacity(color, maxAlpha).getRGB(), 30);
    }

    public static void drawMicrosoftLogo(float x, float y, float size, float spacing, float alpha) {
        float rectSize = size / 2f - spacing;
        float alphaMod = alpha * 255;
        drawRect(x, y, rectSize, rectSize, new Color(244, 80, 54, (int) alphaMod).getRGB());
        drawRect(x + rectSize + spacing, y, rectSize, rectSize, new Color(129, 188, 6, (int) alphaMod).getRGB());
        drawRect(x, y + spacing + rectSize, rectSize, rectSize, new Color(0, 163, 239, (int) alphaMod).getRGB());
        drawRect(x + rectSize + spacing, y + spacing + rectSize, rectSize, rectSize, new Color(252, 186, 4, (int) alphaMod).getRGB());
    }

    public static void drawMicrosoftLogo(float x, float y, float size, float spacing) {
        drawMicrosoftLogo(x, y, size, spacing, 1);
    }

    public static double animate(double endPoint, double current, double speed) {
        boolean shouldContinueAnimation = endPoint > current;
        if (speed < 0.0) {
            speed = 0.0;
        } else if (speed > 1.0) {
            speed = 1.0;
        }
        double dif = Math.max(endPoint, current) - Math.min(endPoint, current);
        double dif2 = Math.abs((endPoint - (shouldContinueAnimation ? endPoint - 0.1 : endPoint + 0.1)) * speed);
        if (dif2 < dif) dif2 = dif;
        return current + (shouldContinueAnimation ? dif2 : -dif2);
    }

    public static void renderRoundedRect(float x, float y, float width, float height, float radius, int color) {
        RoundedUtil.drawRound(x, y, width, height, radius, new Color(color, true));
    }

    // ---- world-space helpers used by combat ESP (called inside Render3DEvent) ----

    public static void renderBoundingBox(net.minecraft.entity.LivingEntity entity, java.awt.Color color, float alpha) {
        net.minecraft.util.math.Box bb = ESPUtil.getInterpolatedBoundingBox(entity);
        WorldRenderUtil.start3D();
        WorldRenderUtil.begin(net.minecraft.client.render.RenderLayers.debugQuads());
        int argb = dev.tenacity.utils.render.ColorUtil.applyOpacity(color.getRGB(), alpha);
        WorldRenderUtil.color(argb);
        double minX = bb.minX, minY = bb.minY, minZ = bb.minZ, maxX = bb.maxX, maxY = bb.maxY, maxZ = bb.maxZ;
        double[][] faces = {
            {minX,minY,minZ, maxX,minY,minZ, maxX,minY,maxZ, minX,minY,maxZ},
            {minX,maxY,minZ, maxX,maxY,minZ, maxX,maxY,maxZ, minX,maxY,maxZ},
            {minX,minY,minZ, minX,maxY,minZ, minX,maxY,maxZ, minX,minY,maxZ},
            {maxX,minY,minZ, maxX,maxY,minZ, maxX,maxY,maxZ, maxX,minY,maxZ},
            {minX,minY,minZ, maxX,minY,minZ, maxX,maxY,minZ, minX,maxY,minZ},
            {minX,minY,maxZ, maxX,minY,maxZ, maxX,maxY,maxZ, minX,minY,maxZ},
        };
        net.minecraft.util.math.Vec3d cam = WorldRenderUtil.cameraPos();
        for (double[] f : faces)
            for (int i = 0; i < 12; i += 3)
                WorldRenderUtil.vertex(f[i] - cam.x, f[i+1] - cam.y, f[i+2] - cam.z);
        WorldRenderUtil.resetColor();
        WorldRenderUtil.end3D();
    }

    public static void drawCircle(net.minecraft.entity.LivingEntity entity, float partialTicks, float rad, int color, float alpha) {
        WorldRenderUtil.start3D();
        WorldRenderUtil.begin(net.minecraft.client.render.RenderLayers.LINES);
        double[] pos = ESPUtil.getInterpolatedPos(entity);
        net.minecraft.util.math.Vec3d cam = WorldRenderUtil.cameraPos();
        int c = dev.tenacity.utils.render.ColorUtil.applyOpacity(color, alpha);
        WorldRenderUtil.color(c);
        for (int i = 0; i <= 90; i++) {
            double a = i * Math.PI * 2 / 90;
            WorldRenderUtil.vertex(pos[0] - cam.x + Math.cos(a) * rad, pos[1] - cam.y, pos[2] - cam.z + Math.sin(a) * rad);
        }
        WorldRenderUtil.resetColor();
        WorldRenderUtil.end3D();
    }

    public static void drawTracerLine(net.minecraft.entity.LivingEntity entity, float width, java.awt.Color color, float alpha) {
        WorldRenderUtil.start3D();
        WorldRenderUtil.begin(net.minecraft.client.render.RenderLayers.LINES);
        double[] pos = ESPUtil.getInterpolatedPos(entity);
        net.minecraft.util.math.Vec3d cam = WorldRenderUtil.cameraPos();
        WorldRenderUtil.color(dev.tenacity.utils.render.ColorUtil.applyOpacity(color.getRGB(), alpha));
        WorldRenderUtil.vertex(0, 0, 0);
        WorldRenderUtil.vertex(pos[0] - cam.x, pos[1] - cam.y + entity.getHeight() / 2, pos[2] - cam.z);
        WorldRenderUtil.resetColor();
        WorldRenderUtil.end3D();
    }
}
