package dev.tenacity.utils.objects;

import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.font.CustomFont;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.misc.IOUtils;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.time.TimerUtil;
import org.lwjgl.glfw.GLFW;

import java.awt.*;

public class TextField implements Utils {
    public CustomFont font;

    private float xPosition, yPosition, radius = 2, alpha = 1;
    private float width, height, textAlpha = 1;

    private Color outline = Color.WHITE, fill = ColorUtil.tripleColor(32);

    private Color focusedTextColor = new Color(224, 224, 224);
    private Color unfocusedTextColor = new Color(130, 130, 130);

    protected String text = "";

    /** Text actually drawn; PasswordField overrides this to mask input. */
    protected String getRenderText() { return text; }
    private String backgroundText;

    private int maxStringLength = 32;

    private boolean drawingBackground = true;
    private boolean canLoseFocus = true;
    private boolean isFocused;

    private int lineScrollOffset;
    private int cursorPosition;
    private int selectionEnd;
    private final Animation textColor = new DecelerateAnimation(250, 1);
    private final Animation cursorBlinkAnimation = new DecelerateAnimation(750, 1);
    private final TimerUtil timerUtil = new TimerUtil();

    private boolean visible = true;

    public TextField(CustomFont font) {
        this.font = font;
    }

    public TextField(CustomFont font, float x, float y, float par5Width, float par6Height) {
        this.font = font;
        this.xPosition = x;
        this.yPosition = y;
        this.width = par5Width;
        this.height = par6Height;
    }

    public void setText(String text) {
        if (text.length() > this.maxStringLength) {
            this.text = text.substring(0, this.maxStringLength);
        } else {
            this.text = text;
        }
        setCursorPositionZero();
    }

    public String getText() {
        return this.text;
    }

    public String getSelectedText() {
        int i = Math.min(this.cursorPosition, this.selectionEnd);
        int j = Math.max(this.cursorPosition, this.selectionEnd);
        return this.text.substring(i, j);
    }

    public void writeText(String text) {
        String s = "";
        String s1 = filterAllowedCharacters(text);
        int min = Math.min(this.cursorPosition, this.selectionEnd);
        int max = Math.max(this.cursorPosition, this.selectionEnd);
        int len = this.maxStringLength - this.text.length() - (min - max);
        int l;

        if (this.text.length() > 0) {
            s = s + this.text.substring(0, min);
        }

        if (len < s1.length()) {
            s = s + s1.substring(0, len);
            l = len;
        } else {
            s = s + s1;
            l = s1.length();
        }

        if (this.text.length() > 0 && max < this.text.length()) {
            s = s + this.text.substring(max);
        }

        this.text = s;
        this.moveCursorBy(min - this.selectionEnd + l);
    }

    private static String filterAllowedCharacters(String input) {
        StringBuilder sb = new StringBuilder();
        for (char c : input.toCharArray()) {
            if (isAllowedCharacter(c)) sb.append(c);
        }
        return sb.toString();
    }

    private static boolean isAllowedCharacter(char c) {
        return c != 167 && c >= ' ' && c != 127;
    }

    private static boolean hasCtrlDown() {
        long h = mc.getWindow().getHandle();
        return GLFW.glfwGetKey(h, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(h, GLFW.GLFW_KEY_LEFT_SUPER) == GLFW.GLFW_PRESS;
    }

    private static boolean hasShiftDown() {
        long h = mc.getWindow().getHandle();
        return GLFW.glfwGetKey(h, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }

    private static boolean comboPressed(int keyCode, int letter) {
        return hasCtrlDown() && keyCode == letter;
    }

    private static void setClipboardString(String s) {
        if (mc.getWindow() != null) {
            GLFW.glfwSetClipboardString(mc.getWindow().getHandle(), s);
        }
    }

    public void deleteWords(int num) {
        if (this.text.length() != 0) {
            if (this.selectionEnd != this.cursorPosition) {
                this.writeText("");
            } else {
                this.deleteFromCursor(this.getNthWordFromCursor(num) - this.cursorPosition);
            }
        }
    }

    public void deleteFromCursor(int num) {
        if (this.text.length() != 0) {
            if (this.selectionEnd != this.cursorPosition) {
                this.writeText("");
            } else {
                boolean negative = num < 0;
                int i = negative ? this.cursorPosition + num : this.cursorPosition;
                int j = negative ? this.cursorPosition : this.cursorPosition + num;
                String s = "";

                if (i >= 0) {
                    s = this.text.substring(0, i);
                }

                if (j < this.text.length()) {
                    s = s + this.text.substring(j);
                }

                this.text = s;

                if (negative) {
                    this.moveCursorBy(num);
                }
            }
        }
    }

    public int getNthWordFromCursor(int n) {
        return this.getNthWordFromPos(n, this.getCursorPosition());
    }

    public int getNthWordFromPos(int n, int pos) {
        return this.func_146197_a(n, pos);
    }

    public int func_146197_a(int n, int pos) {
        int i = pos;
        boolean negative = n < 0;
        int j = Math.abs(n);

        for (int k = 0; k < j; ++k) {
            if (!negative) {
                int l = this.text.length();
                i = this.text.indexOf(32, i);

                if (i == -1) {
                    i = l;
                } else {
                    while (i < l && this.text.charAt(i) == 32) {
                        ++i;
                    }
                }
            } else {
                while (i > 0 && this.text.charAt(i - 1) == 32) {
                    --i;
                }

                while (i > 0 && this.text.charAt(i - 1) != 32) {
                    --i;
                }
            }
        }

        return i;
    }

    public void moveCursorBy(int p_146182_1_) {
        this.setCursorPosition(this.selectionEnd + p_146182_1_);
    }

    public void setCursorPosition(int p_146190_1_) {
        this.cursorPosition = p_146190_1_;
        int i = this.text.length();
        this.cursorPosition = Math.min(Math.max(this.cursorPosition, 0), i);
        this.setSelectionPos(this.cursorPosition);
    }

    public void setCursorPositionZero() {
        this.setCursorPosition(0);
    }

    public void setCursorPositionEnd() {
        this.setCursorPosition(this.text.length());
    }

    public boolean keyTyped(char cha, int keyCode) {
        if (!this.isFocused) {
            return false;
        }

        timerUtil.reset();

        if (comboPressed(keyCode, GLFW.GLFW_KEY_A)) {
            this.setCursorPositionEnd();
            this.setSelectionPos(0);
            return true;
        } else if (comboPressed(keyCode, GLFW.GLFW_KEY_C)) {
            setClipboardString(this.getSelectedText());
            return true;
        } else if (comboPressed(keyCode, GLFW.GLFW_KEY_V)) {
            this.writeText(IOUtils.getClipboardString());
            return true;
        } else if (comboPressed(keyCode, GLFW.GLFW_KEY_X)) {
            setClipboardString(this.getSelectedText());
            this.writeText("");
            return true;
        } else {
            switch (keyCode) {
                case GLFW.GLFW_KEY_BACKSPACE:
                    if (hasCtrlDown()) {
                        this.deleteWords(-1);
                    } else {
                        this.deleteFromCursor(-1);
                    }
                    return true;

                case GLFW.GLFW_KEY_HOME:
                    if (hasShiftDown()) {
                        this.setSelectionPos(0);
                    } else {
                        this.setCursorPositionZero();
                    }
                    return true;

                case GLFW.GLFW_KEY_LEFT:
                    if (hasShiftDown()) {
                        if (hasCtrlDown()) {
                            this.setSelectionPos(this.getNthWordFromPos(-1, this.getSelectionEnd()));
                        } else {
                            this.setSelectionPos(this.getSelectionEnd() - 1);
                        }
                    } else if (hasCtrlDown()) {
                        this.setCursorPosition(this.getNthWordFromCursor(-1));
                    } else {
                        this.moveCursorBy(-1);
                    }
                    return true;

                case GLFW.GLFW_KEY_RIGHT:
                    if (hasShiftDown()) {
                        if (hasCtrlDown()) {
                            this.setSelectionPos(this.getNthWordFromPos(1, this.getSelectionEnd()));
                        } else {
                            this.setSelectionPos(this.getSelectionEnd() + 1);
                        }
                    } else if (hasCtrlDown()) {
                        this.setCursorPosition(this.getNthWordFromCursor(1));
                    } else {
                        this.moveCursorBy(1);
                    }
                    return true;

                case GLFW.GLFW_KEY_END:
                    if (hasShiftDown()) {
                        this.setSelectionPos(this.text.length());
                    } else {
                        this.setCursorPositionEnd();
                    }
                    return true;

                case GLFW.GLFW_KEY_DELETE:
                    if (hasCtrlDown()) {
                        this.deleteWords(1);
                    } else {
                        this.deleteFromCursor(1);
                    }
                    return true;

                default:
                    if (isAllowedCharacter(cha)) {
                        this.writeText(Character.toString(cha));
                        return true;
                    } else {
                        return false;
                    }
            }
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        boolean flag = HoveringUtil.isHovering(xPosition, yPosition, width, height, mouseX, mouseY);

        if (this.canLoseFocus) {
            this.setFocused(flag);
        }

        if (this.isFocused && flag && mouseButton == 0) {
            float xPos = xPosition;
            if (backgroundText != null && backgroundText.equals("Search")) {
                xPos += 13;
            }

            float i = mouseX - xPos;

            String s = this.font.trimStringToWidth(getRenderText().substring(this.lineScrollOffset), (int) this.getWidth());
            this.setCursorPosition(this.font.trimStringToWidth(s, (int) i).length() + this.lineScrollOffset);
        }
    }

    public void drawTextBox() {
        if (this.getVisible()) {

            Color textColorWithAlpha = focusedTextColor;
            if (textAlpha != 1) {
                textColorWithAlpha = ColorUtil.applyOpacity(focusedTextColor, textAlpha);
            }


            float xPos = this.xPosition + 3;
            float yPos = this.yPosition + font.getMiddleOfBox(height);

            if (this.isDrawingBackground()) {
                if (outline != null) {
                    RoundedUtil.drawRound(this.xPosition - 1, this.yPosition - 1, this.width + 2f, this.height + 2f,
                            radius + 1, outline);
                }

                RoundedUtil.drawRound(this.xPosition, this.yPosition, this.width, this.height, radius, ColorUtil.applyOpacity(fill, alpha));
            } else {
                float rectHeight = 1;
                RenderUtil.drawRect(xPosition, yPosition + height - rectHeight, width, rectHeight,
                        ColorUtil.interpolateColor(focusedTextColor, unfocusedTextColor, textColor.getOutput().floatValue()));
            }

            textColor.setDirection(isFocused() ? Direction.BACKWARDS : Direction.FORWARDS);
            if (backgroundText != null) {
                Color backgroundTextColor = ColorUtil.applyOpacity(ColorUtil.applyOpacity(unfocusedTextColor, textAlpha), textColor.getOutput().floatValue());
                if (backgroundText.equals("Search")) {
                    iconFont16().drawString(FontUtil.SEARCH, xPos + 1.5f, this.yPosition + iconFont16().getMiddleOfBox(getHeight()), ColorUtil.applyOpacity(unfocusedTextColor, textAlpha));
                    xPos += 15;
                }

                if (text.equals("") && !textColor.finished(Direction.BACKWARDS)) {
                    font.drawString(backgroundText, xPos, yPos, backgroundTextColor);
                }
            }


            int cursorPos = this.cursorPosition - this.lineScrollOffset;
            int selEnd = this.selectionEnd - this.lineScrollOffset;
            String text = this.font.trimStringToWidth(getRenderText().substring(this.lineScrollOffset), (int) this.getWidth());
            boolean cursorInBounds = cursorPos >= 0 && cursorPos <= text.length();
            boolean canShowCursor = this.isFocused && cursorInBounds;
            float j1 = xPos;


            if (selEnd > text.length()) {
                selEnd = text.length();
            }


            if (text.length() > 0) {
                String s1 = cursorInBounds ? getRenderText().substring(0, cursorPos) : text;
                j1 = this.font.drawStringWithShadow(s1, xPos, yPos, textColorWithAlpha.getRGB()) + .5f;
            }

            boolean cursorEndPos = this.cursorPosition < this.text.length() || this.text.length() >= this.getMaxStringLength();
            float k1 = j1;

            if (!cursorInBounds) {
                k1 = cursorPos > 0 ? xPos + this.width : xPos;
            } else if (cursorEndPos) {
                k1 = j1;
                --j1;
            }

            if (text.length() > 0 && cursorInBounds && cursorPos < text.length()) {
                j1 = this.font.drawStringWithShadow(text.substring(cursorPos), j1 + 2f, yPos, textColorWithAlpha.getRGB());
            }

            boolean cursorBlink = timerUtil.hasTimeElapsed(2000) || cursorEndPos;

            if (canShowCursor) {
                if (cursorBlink) {
                    if (cursorBlinkAnimation.isDone()) {
                        cursorBlinkAnimation.changeDirection();
                    }
                } else cursorBlinkAnimation.setDirection(Direction.FORWARDS);

                RenderUtil.drawRect(k1 + 1, yPos - 2, .5f, font.getHeight() + 3,
                        ColorUtil.applyOpacity(textColorWithAlpha, cursorBlinkAnimation.getOutput().floatValue()).getRGB());
            }

            if (selEnd != cursorPos) {
                int l1 = (int) (xPos + this.font.getStringWidth(text.substring(0, selEnd)));
                int offset = selEnd > cursorPos ? 2 : 0;
                float widthOffset = selEnd > cursorPos ? .5f : 0;

                drawSelectionBox(k1 + offset, yPos - 1, l1 + widthOffset, yPos + 1 + font.getHeight());
            }
        }

    }

    private void drawSelectionBox(float x, float y, float width, float height) {
        if (x < width) {
            float i = x;
            x = width;
            width = i;
        }

        if (y < height) {
            float j = y;
            y = height;
            height = j;
        }

        if (width > this.xPosition + this.width) {
            width = this.xPosition + this.width;
        }

        if (x > this.xPosition + this.width) {
            x = this.xPosition + this.width;
        }

        RenderUtil.drawRect(x, y, width - x, height - y, new Color(80, 120, 255, 140).getRGB());
    }

    public void setMaxStringLength(int len) {
        this.maxStringLength = len;

        if (this.text.length() > len) {
            this.text = this.text.substring(0, len);
        }
    }

    public int getMaxStringLength() {
        return this.maxStringLength;
    }

    public int getCursorPosition() {
        return this.cursorPosition;
    }

    public void setTextColor(Color color) {
        this.focusedTextColor = color;
    }

    public void setDisabledTextColour(Color color) {
        this.unfocusedTextColor = color;
    }

    public int getSelectionEnd() {
        return this.selectionEnd;
    }

    public float getWidth() {
        boolean flag = backgroundText != null && backgroundText.equals("Search");
        return this.isDrawingBackground() ? this.width - (flag ? 17 : 4) : this.width;
    }

    public float getRealWidth() {
        return this.isDrawingBackground() ? this.width - 4 : this.width;
    }

    public float getHeight() {
        return this.height;
    }

    public void setSelectionPos(int selectionPos) {
        int i = this.text.length();

        if (selectionPos > i) {
            selectionPos = i;
        }

        if (selectionPos < 0) {
            selectionPos = 0;
        }

        this.selectionEnd = selectionPos;

        if (this.font != null) {
            if (this.lineScrollOffset > i) {
                this.lineScrollOffset = i;
            }

            float j = this.getWidth();
            String s = this.font.trimStringToWidth(getRenderText().substring(this.lineScrollOffset), (int) j);
            int k = s.length() + this.lineScrollOffset;

            if (selectionPos == this.lineScrollOffset) {
                this.lineScrollOffset -= this.font.trimStringToWidth(this.text, (int) j, true).length();
            }

            if (selectionPos > k) {
                this.lineScrollOffset += selectionPos - k;
            } else if (selectionPos <= this.lineScrollOffset) {
                this.lineScrollOffset -= this.lineScrollOffset - selectionPos;
            }

            this.lineScrollOffset = Math.min(Math.max(this.lineScrollOffset, 0), i);
        }
    }

    public void setCanLoseFocus(boolean canLoseFocus) {
        this.canLoseFocus = canLoseFocus;
    }

    public boolean getVisible() {
        return this.visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    // Accessors
    public void setFont(CustomFont font) { this.font = font; }
    public float getXPosition() { return xPosition; }
    public void setXPosition(float xPosition) { this.xPosition = xPosition; }
    public float getYPosition() { return yPosition; }
    public void setYPosition(float yPosition) { this.yPosition = yPosition; }
    public float getRadius() { return radius; }
    public void setRadius(float radius) { this.radius = radius; }
    public float getAlpha() { return alpha; }
    public void setAlpha(float alpha) { this.alpha = alpha; }
    public void setWidth(float width) { this.width = width; }
    public void setHeight(float height) { this.height = height; }
    public void setTextAlpha(float textAlpha) { this.textAlpha = textAlpha; }
    public Color getOutline() { return outline; }
    public void setOutline(Color outline) { this.outline = outline; }
    public Color getFill() { return fill; }
    public void setFill(Color fill) { this.fill = fill; }
    public void setBackgroundText(String backgroundText) { this.backgroundText = backgroundText; }
    public boolean isDrawingBackground() { return drawingBackground; }
    public void setDrawingBackground(boolean drawingBackground) { this.drawingBackground = drawingBackground; }
    public boolean isFocused() { return isFocused; }
    public void setFocused(boolean focused) { isFocused = focused; }
}
