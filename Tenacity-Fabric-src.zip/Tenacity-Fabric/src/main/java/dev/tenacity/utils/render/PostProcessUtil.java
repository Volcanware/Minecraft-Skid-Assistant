package dev.tenacity.utils.render;

import dev.tenacity.Tenacity;
import dev.tenacity.utils.Utils;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.render.FrameGraphBuilder;
import net.minecraft.client.util.Handle;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;

import java.util.Set;

public class PostProcessUtil implements Utils {

    private static PostEffectProcessor blurProcessor;
    private static PostEffectProcessor bloomProcessor;
    private static boolean bloomFailed;

    private static PostEffectProcessor getBlur() {
        if (blurProcessor == null) {
            try {
                blurProcessor = mc.getShaderLoader().loadPostEffect(
                        Identifier.of("tenacity", "blur"), Set.of(PostEffectProcessor.MAIN));
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
        return blurProcessor;
    }

    public static void renderBlur() {
        renderEffect(getBlur());
    }

    // Called at the start of ClickGUI/menu render: blurs the world behind the UI
    // and applies the bloom pass when PostProcessing is enabled.
    public static void renderGuiBlur() {
        if (Tenacity.INSTANCE == null || Tenacity.INSTANCE.getModuleCollection() == null) return;
        dev.tenacity.module.impl.render.PostProcessing pp =
                Tenacity.INSTANCE.getModuleCollection().getModule(dev.tenacity.module.impl.render.PostProcessing.class);
        if (pp == null || !pp.isEnabled()) return;
        if (pp.blur.isEnabled()) renderBlur();
        if (pp.bloomEnabled()) renderBloom();
    }

    private static PostEffectProcessor getBloom() {
        if (bloomProcessor == null && !bloomFailed) {
            try {
                bloomProcessor = mc.getShaderLoader().loadPostEffect(
                        Identifier.of("tenacity", "bloom"), Set.of(PostEffectProcessor.MAIN));
            } catch (Throwable t) {
                bloomFailed = true;
                t.printStackTrace();
            }
        }
        return bloomProcessor;
    }

    public static void renderBloom() {
        renderEffect(getBloom());
    }

    private static void renderEffect(PostEffectProcessor processor) {
        if (processor == null) return;
        try {
            Framebuffer main = mc.getFramebuffer();
            FrameGraphBuilder builder = new FrameGraphBuilder();
            Handle<Framebuffer> mainHandle = builder.createObjectNode("main", main);
            processor.render(builder, main.textureWidth, main.textureHeight,
                    PostEffectProcessor.FramebufferSet.singleton(PostEffectProcessor.MAIN, mainHandle));
            builder.run(ObjectAllocator.TRIVIAL);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public static void close() {
        if (bloomProcessor != null) bloomProcessor.close();
        bloomProcessor = null;
        bloomFailed = false;
    }
}
