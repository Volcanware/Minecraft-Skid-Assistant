package dev.tenacity.utils.misc;

import dev.tenacity.ui.notifications.NotificationManager;
import dev.tenacity.ui.notifications.NotificationType;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.io.IOException;
import java.net.URI;

public class IOUtils {

    public static void copy(String data) {
        try {
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(data), null);
        } catch (Throwable t) {
            // headless game JVM — no AWT toolkit
        }
    }

    public static String getClipboardString() {
        String ret = "";
        try {
            Clipboard sysClip = Toolkit.getDefaultToolkit().getSystemClipboard();
            Transferable clipTf = sysClip.getContents(null);
            if (clipTf != null && clipTf.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                ret = (String) clipTf.getTransferData(DataFlavor.stringFlavor);
            }
        } catch (Throwable t) {
            // headless — fall back to GLFW clipboard via screen handler if needed
        }
        return ret;
    }

    public static void openLink(String link) {
        try {
            Desktop.getDesktop().browse(URI.create(link));
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    public static void openFolder(File file) {
        if (file.exists()) {
            try {
                Desktop.getDesktop().open(file);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            NotificationManager.post(NotificationType.WARNING, "Error", "Folder does not exist, creating...");
            file.mkdirs();
        }
    }
}
