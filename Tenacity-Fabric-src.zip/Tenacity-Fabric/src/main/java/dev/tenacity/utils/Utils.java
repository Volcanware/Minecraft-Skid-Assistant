package dev.tenacity.utils;

import dev.tenacity.utils.font.CustomFont;
import dev.tenacity.utils.font.FontUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public interface Utils {

    MinecraftClient mc = MinecraftClient.getInstance();
    TextRenderer fr = mc.textRenderer;

    /** Current frame's DrawContext, updated every frame by the render hook. */
    final class CtxState { static DrawContext value = null; }
    static void setCtx(DrawContext c) { CtxState.value = c; }
    static DrawContext getCtx() { return CtxState.value; }
    default DrawContext ctx() { return CtxState.value; }

    FontUtil.FontType tenacityFont = FontUtil.FontType.TENACITY,
            iconFont = FontUtil.FontType.ICON,
            neverloseFont = FontUtil.FontType.NEVERLOSE,
            tahomaFont = FontUtil.FontType.TAHOMA,
            rubikFont = FontUtil.FontType.RUBIK;

    //Regular Fonts
    default CustomFont tenacityFont12() { return FontUtil.FontType.TENACITY.size(12); }
    default CustomFont tenacityFont14() { return FontUtil.FontType.TENACITY.size(14); }
    default CustomFont tenacityFont16() { return FontUtil.FontType.TENACITY.size(16); }
    default CustomFont tenacityFont18() { return FontUtil.FontType.TENACITY.size(18); }
    default CustomFont tenacityFont20() { return FontUtil.FontType.TENACITY.size(20); }
    default CustomFont tenacityFont22() { return FontUtil.FontType.TENACITY.size(22); }
    default CustomFont tenacityFont24() { return FontUtil.FontType.TENACITY.size(24); }
    default CustomFont tenacityFont26() { return FontUtil.FontType.TENACITY.size(26); }
    default CustomFont tenacityFont28() { return FontUtil.FontType.TENACITY.size(28); }
    default CustomFont tenacityFont32() { return FontUtil.FontType.TENACITY.size(32); }
    default CustomFont tenacityFont40() { return FontUtil.FontType.TENACITY.size(40); }
    default CustomFont tenacityFont80() { return FontUtil.FontType.TENACITY.size(80); }

    //Bold Fonts
    default CustomFont tenacityBoldFont14() { return FontUtil.FontType.TENACITY.boldSize(14); }
    default CustomFont tenacityBoldFont16() { return FontUtil.FontType.TENACITY.boldSize(16); }
    default CustomFont tenacityBoldFont18() { return FontUtil.FontType.TENACITY.boldSize(18); }
    default CustomFont tenacityBoldFont20() { return FontUtil.FontType.TENACITY.boldSize(20); }
    default CustomFont tenacityBoldFont22() { return FontUtil.FontType.TENACITY.boldSize(22); }
    default CustomFont tenacityBoldFont24() { return FontUtil.FontType.TENACITY.boldSize(24); }
    default CustomFont tenacityBoldFont26() { return FontUtil.FontType.TENACITY.boldSize(26); }
    default CustomFont tenacityBoldFont28() { return FontUtil.FontType.TENACITY.boldSize(28); }
    default CustomFont tenacityBoldFont30() { return FontUtil.FontType.TENACITY.boldSize(30); }
    default CustomFont tenacityBoldFont32() { return FontUtil.FontType.TENACITY.boldSize(32); }
    default CustomFont tenacityBoldFont40() { return FontUtil.FontType.TENACITY.boldSize(40); }
    default CustomFont tenacityBoldFont80() { return FontUtil.FontType.TENACITY.boldSize(80); }

    //Icon Fonts
    default CustomFont iconFont16() { return FontUtil.FontType.ICON.size(16); }
    default CustomFont iconFont20() { return FontUtil.FontType.ICON.size(20); }
    default CustomFont iconFont26() { return FontUtil.FontType.ICON.size(26); }
    default CustomFont iconFont35() { return FontUtil.FontType.ICON.size(35); }
    default CustomFont iconFont40() { return FontUtil.FontType.ICON.size(40); }

    default CustomFont neverloseFont12() { return FontUtil.FontType.NEVERLOSE.size(12); }
    default CustomFont neverloseFont18() { return FontUtil.FontType.NEVERLOSE.size(18); }
    default CustomFont neverloseFont22() { return FontUtil.FontType.NEVERLOSE.size(22); }
    default CustomFont tahomaFont10() { return FontUtil.FontType.TAHOMA.size(10); }
    default CustomFont tahomaFont12() { return FontUtil.FontType.TAHOMA.size(12); }
    default CustomFont tahomaFont14() { return FontUtil.FontType.TAHOMA.size(14); }
    default CustomFont tahomaFont16() { return FontUtil.FontType.TAHOMA.size(16); }
    default CustomFont tahomaFont18() { return FontUtil.FontType.TAHOMA.size(18); }
    default CustomFont tahomaFont27() { return FontUtil.FontType.TAHOMA.size(27); }
    default CustomFont rubikFont13() { return FontUtil.FontType.RUBIK.size(13); }
    default CustomFont rubikFont18() { return FontUtil.FontType.RUBIK.size(18); }
}
