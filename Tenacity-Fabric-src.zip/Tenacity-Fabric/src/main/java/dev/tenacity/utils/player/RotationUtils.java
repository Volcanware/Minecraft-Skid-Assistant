package dev.tenacity.utils.player;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.utils.Utils;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class RotationUtils implements Utils {

    public static float[] currentRotation;

    public static void setVisualRotations(float yaw, float pitch) {
        if (mc.player == null) return;
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
    }

    public static void setVisualRotations(float[] rotations) {
        setVisualRotations(rotations[0], rotations[1]);
    }

    public static void setVisualRotations(MotionEvent e) {
        setVisualRotations(e.getYaw(), e.getPitch());
    }

    public static float clampRotation() {
        float rotationYaw = mc.player.getYaw();
        float n = 1.0f;
        if (mc.player.input.getMovementInput().y < 0) {
            rotationYaw += 180.0f;
            n = -0.5f;
        } else if (mc.player.input.getMovementInput().y > 0) {
            n = 0.5f;
        }
        if (mc.player.input.getMovementInput().x > 0) {
            rotationYaw -= 90.0f * n;
        }
        if (mc.player.input.getMovementInput().x < 0) {
            rotationYaw += 90.0f * n;
        }
        return rotationYaw * MathHelper.RADIANS_PER_DEGREE;
    }

    public static float getSensitivityMultiplier() {
        float f = (float) mc.options.getMouseSensitivity().getValue().floatValue() * 0.6f + 0.2f;
        return f * f * f * 8f * 0.15f;
    }

    public static float smoothRotation(float from, float to, float speed) {
        float f = MathHelper.wrapDegrees(to - from);
        if (f > speed) f = speed;
        if (f < -speed) f = -speed;
        return from + f;
    }

    public static float[] getRotations(BlockPos blockPos, Direction enumFacing) {
        double x = blockPos.getX() + 0.5 - mc.player.getX() + (double) enumFacing.getOffsetX() / 2;
        double z = blockPos.getZ() + 0.5 - mc.player.getZ() + (double) enumFacing.getOffsetZ() / 2;
        double y = (blockPos.getY() + 0.5) - (mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()));
        double d1 = mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()) - (blockPos.getY() + 0.5);
        double d3 = MathHelper.sqrt((float) (x * x + z * z));
        float yaw = (float) (Math.atan2(z, x) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) (Math.atan2(d1, d3) * 180.0D / Math.PI);
        if (yaw < 0.0F) yaw += 360f;
        return new float[]{yaw, pitch};
    }

    public static float[] getRotationsNeeded(final Entity entity) {
        if (entity == null) return null;
        final double diffX = entity.getX() - mc.player.getX();
        final double diffZ = entity.getZ() - mc.player.getZ();
        double diffY;
        if (entity instanceof LivingEntity livingEntity) {
            diffY = livingEntity.getY() + livingEntity.getStandingEyeHeight() - (mc.player.getY() + mc.player.getStandingEyeHeight());
        } else {
            diffY = (entity.getBoundingBox().minY + entity.getBoundingBox().maxY) / 2.0 - (mc.player.getY() + mc.player.getStandingEyeHeight());
        }
        final double dist = MathHelper.sqrt((float) (diffX * diffX + diffZ * diffZ));
        final float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        final float pitch = (float) (-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        return new float[]{mc.player.getYaw() + MathHelper.wrapDegrees(yaw - mc.player.getYaw()), mc.player.getPitch() + MathHelper.wrapDegrees(pitch - mc.player.getPitch())};
    }

    public static float[] getRotations(double posX, double posY, double posZ) {
        final double x = posX - mc.player.getX();
        final double y = posY - (mc.player.getY() + mc.player.getStandingEyeHeight());
        final double z = posZ - mc.player.getZ();
        final double dist = MathHelper.sqrt((float) (x * x + z * z));
        final float yaw = (float) (Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        final float pitch = (float) (-(Math.atan2(y, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float[] getSmoothRotations(LivingEntity entity) {
        float[] rotations = getRotationsNeeded(entity);
        float smooth = 0.3f + (float) Math.random() * 0.1f;
        float yaw = smoothRotation(mc.player.getYaw(), rotations[0], smooth * 100);
        float pitch = smoothRotation(mc.player.getPitch(), rotations[1], smooth * 100);
        return new float[]{yaw, pitch};
    }

    public static float getEnumRotations(Direction facing) {
        if (facing == Direction.DOWN) return 90;
        else if (facing == Direction.UP) return -90;
        else if (facing == Direction.NORTH) return 180;
        else if (facing == Direction.SOUTH) return 0;
        else if (facing == Direction.WEST) return 90;
        else return -90;
    }

    public static float getYaw(Vec3d to) {
        final ClientPlayerEntity player = mc.player;
        final double diffX = to.x - player.getX();
        final double diffZ = to.z - player.getZ();
        return (float) (Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
    }

    public static Vec3d getVecRotations(float yaw, float pitch) {
        double d = Math.cos(Math.toRadians(-yaw) - Math.PI);
        double d1 = Math.sin(Math.toRadians(-yaw) - Math.PI);
        double d2 = -Math.cos(Math.toRadians(-pitch));
        double d3 = Math.sin(Math.toRadians(-pitch));
        return new Vec3d(d1 * d2, d3, d * d2);
    }

    public static boolean isMouseOver(final float yaw, final float pitch, final Entity target, final float range) {
        float partialTicks = mc.getRenderTickCounter().getTickProgress(false);
        Vec3d vec3 = mc.player.getCameraPosVec(partialTicks);
        Vec3d vec31 = RotationUtils.getVecRotations(yaw, pitch);
        Vec3d vec32 = vec3.add(vec31.x * range, vec31.y * range, vec31.z * range);
        return target.getBoundingBox().expand(0.1).raycast(vec3, vec32).isPresent();
    }
}
