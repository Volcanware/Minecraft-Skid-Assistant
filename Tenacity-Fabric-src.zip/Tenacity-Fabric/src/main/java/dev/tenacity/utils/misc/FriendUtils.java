package dev.tenacity.utils.misc;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import dev.tenacity.Tenacity;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Shared friend-list storage extracted from the original FriendCommand.
 * Keeps the same JSON file ({@code Tenacity.DIRECTORY/Friends.json}) and
 * {@link #isFriend(String)} lookup used by ESP2D. The /friend chat command
 * itself is a separate (command-system) feature; this util only preserves
 * the data store and query API it exposed.
 */
public class FriendUtils {

    private static final List<String> friends = new ArrayList<>();
    private static final Gson GSON = new Gson();

    public static List<String> getFriends() {
        return friends;
    }

    public static boolean isFriend(String name) {
        return friends.contains(name);
    }

    public static boolean addFriend(String name) {
        boolean added = friends.add(name);
        save();
        return added;
    }

    public static boolean removeFriend(String name) {
        boolean removed = friends.remove(name);
        save();
        return removed;
    }

    public static void load() {
        File file = getFile();
        if (!file.exists()) return;
        try (FileReader reader = new FileReader(file)) {
            JsonArray array = JsonParser.parseReader(reader).getAsJsonArray();
            friends.clear();
            for (JsonElement element : array) {
                friends.add(element.getAsString());
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try (FileWriter writer = new FileWriter(getFile())) {
            writer.write(GSON.toJson(friends));
        } catch (IOException ignored) {
        }
    }

    private static File getFile() {
        return new File(Tenacity.DIRECTORY, "Friends.json");
    }
}
