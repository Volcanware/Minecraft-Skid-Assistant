package dev.tenacity.utils.render;

import net.minecraft.client.gl.RenderPipelines;
import dev.tenacity.mixin.DrawContextAccessor;
import dev.tenacity.utils.Utils;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2f;

import java.awt.*;

public class RoundedUtil implements Utils {

    /**
     * Rounded rect via quad tessellation: center cross + 4 corner fans.
     * The 1.21 GUI pipeline only accepts quads, so each corner is a fan of
     * small quads approximating the arc.
     */
    private static final int ARC_SEGS = 8;

    public static void drawRound(float x, float y, float width, float height, float radius, Color color) {
        drawRoundInternal(x, y, width, height, radius, color.getRGB(), color.getRGB(), color.getRGB(), color.getRGB());
    }

    public static void drawRound(float x, float y, float width, float height, float radius, int color) {
        drawRoundInternal(x, y, width, height, radius, color, color, color, color);
    }

    public static void drawGradientHorizontal(float x, float y, float width, float height, float radius, Color left, Color right) {
        drawRoundInternal(x, y, width, height, radius, left.getRGB(), right.getRGB(), right.getRGB(), left.getRGB());
    }

    public static void drawGradientVertical(float x, float y, float width, float height, float radius, Color top, Color bottom) {
        drawRoundInternal(x, y, width, height, radius, top.getRGB(), top.getRGB(), bottom.getRGB(), bottom.getRGB());
    }

    public static void drawGradientCornerLR(float x, float y, float width, float height, float radius, Color topLeft, Color bottomRight) {
        drawRoundInternal(x, y, width, height, radius, topLeft.getRGB(), bottomRight.getRGB(), bottomRight.getRGB(), topLeft.getRGB());
    }

    public static void drawGradientCornerRL(float x, float y, float width, float height, float radius, Color bottomLeft, Color topRight) {
        drawRoundInternal(x, y, width, height, radius, bottomLeft.getRGB(), topRight.getRGB(), topRight.getRGB(), bottomLeft.getRGB());
    }

    public static void drawGradientRound(float x, float y, float width, float height, float radius,
                                         Color bottomLeft, Color topLeft, Color bottomRight, Color topRight) {
        drawRoundInternal(x, y, width, height, radius, topLeft.getRGB(), topRight.getRGB(), bottomRight.getRGB(), bottomLeft.getRGB());
    }

    /**
     * cTL/cTR/cBR/cBL are the corner colors — each corner fan and body quad
     * picks interpolated edge colors.
     */
    private static void drawRoundInternal(float x, float y, float w, float h, float r,
                                          int cTL, int cTR, int cBR, int cBL) {
        if (Utils.getCtx() == null) return;
        r = Math.min(r, Math.min(w, h) / 2f);
        if (r < 0) r = 0;

        TenacityGuiRenderState s = RenderUtil.newQuadState();

        // Top strip (between top corners)
        s.addQuad(x + r, y, x + w - r, y, x + w - r, y + r, x + r, y + r, cTL, cTR, cTR, cTL);
        // Middle band
        s.addQuad(x, y + r, x + w, y + r, x + w, y + h - r, x, y + h - r, cTL, cTR, cBR, cBL);
        // Bottom strip
        s.addQuad(x + r, y + h - r, x + w - r, y + h - r, x + w - r, y + h, x + r, y + h, cBL, cBR, cBR, cBL);

        addCornerFan(s, x + r, y + r, r, 180, 270, cTL, cTL, cBL, cTL, cTR);
        addCornerFan(s, x + w - r, y + r, r, 270, 360, cTR, cTR, cBR, cTL, cTR);
        addCornerFan(s, x + w - r, y + h - r, r, 0, 90, cBR, cTR, cBR, cBR, cBL);
        addCornerFan(s, x + r, y + h - r, r, 90, 180, cBL, cTL, cBL, cBR, cBL);

        RenderUtil.submitQuads(s);
    }

    private static void addCornerFan(TenacityGuiRenderState s, float cx, float cy, float r,
                                     float startDeg, float endDeg, int cCorner,
                                     int cInnerA, int cInnerB, int cEdgeTop, int cEdgeSide) {
        for (int i = 0; i < ARC_SEGS; i++) {
            double a0 = Math.toRadians(startDeg + (endDeg - startDeg) * i / ARC_SEGS);
            double a1 = Math.toRadians(startDeg + (endDeg - startDeg) * (i + 1) / ARC_SEGS);
            float ax0 = cx + (float) (Math.cos(a0) * r), ay0 = cy + (float) (Math.sin(a0) * r);
            float ax1 = cx + (float) (Math.cos(a1) * r), ay1 = cy + (float) (Math.sin(a1) * r);
            s.addQuad(cx, cy, ax0, ay0, ax1, ay1, cx, cy, cCorner, cCorner, cCorner, cCorner);
        }
    }

    private static int lerp(int a, int b, float t) {
        return a;
    }

    public static void drawRound(float x, float y, float width, float height, float radius, boolean blur, Color color) {
        drawRound(x, y, width, height, radius, color);
    }

    public static void drawRoundOutline(float x, float y, float width, float height, float radius, float outlineThickness, Color color, Color outlineColor) {
        drawRound(x, y, width, height, radius, outlineColor);
        drawRound(x + outlineThickness, y + outlineThickness, width - outlineThickness * 2, height - outlineThickness * 2, radius, color);
    }

    public static void drawRoundTextured(float x, float y, float width, float height, float radius, float alpha) {
        drawRound(x, y, width, height, radius, new Color(255, 255, 255, (int) (alpha * 255)));
    }
}
