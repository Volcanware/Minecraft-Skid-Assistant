package dev.tenacity.utils.tuples;

public class Pair<A, B> {

    private final A first;
    private final B second;

    private Pair(A first, B second) {
        this.first = first;
        this.second = second;
    }

    public static <A, B> Pair<A, B> of(A first, B second) {
        return new Pair<>(first, second);
    }

    public A getFirst() { return first; }

    public <T> T apply(java.util.function.BiFunction<A, B, T> f) {
        return f.apply(first, second);
    }
    public B getSecond() { return second; }
}
