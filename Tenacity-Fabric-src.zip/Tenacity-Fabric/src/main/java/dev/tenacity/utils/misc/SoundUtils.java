package dev.tenacity.utils.misc;

import dev.tenacity.utils.Utils;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.util.Optional;

public class SoundUtils implements Utils {

    public static void playSound(Identifier location, float volume) {
        Multithreading.runAsync(() -> {
            try {
                Optional<Resource> resource = mc.getResourceManager().getResource(location);
                if (resource.isEmpty()) return;
                BufferedInputStream bufferedInputStream = new BufferedInputStream(resource.get().getInputStream());
                AudioInputStream audioIn = AudioSystem.getAudioInputStream(bufferedInputStream);

                Clip clip = AudioSystem.getClip();
                clip.open(audioIn);

                FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                float range = gainControl.getMaximum() - gainControl.getMinimum();
                float gain = (range * volume) + gainControl.getMinimum();
                gainControl.setValue(gain);

                clip.start();
            } catch (UnsupportedAudioFileException | LineUnavailableException | java.io.IOException e) {
                e.printStackTrace();
            }
        });
    }

}
