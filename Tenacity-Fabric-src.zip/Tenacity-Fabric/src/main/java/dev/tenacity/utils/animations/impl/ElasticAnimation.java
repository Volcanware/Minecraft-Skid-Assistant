package dev.tenacity.utils.animations.impl;

import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;

public class ElasticAnimation extends Animation {

    float easeAmount;
    float smooth;
    boolean elastic;

    public ElasticAnimation(int ms, double endPoint, boolean elastic, float smooth, float easeAmount) {
        super(ms, endPoint);
        this.smooth = smooth;
        this.easeAmount = easeAmount;
        this.elastic = elastic;
    }

    public ElasticAnimation(int ms, double endPoint, boolean elastic, float smooth, float easeAmount, Direction direction) {
        super(ms, endPoint, direction);
        this.smooth = smooth;
        this.easeAmount = easeAmount;
        this.elastic = elastic;
    }

    protected double getEquation(double x1) {
        float x = (float) x1;
        double elasticity = Math.max(0, easeAmount);
        float smoothness = Math.max(1, smooth);
        if (elastic) {
            return Math.pow(2, -10 * x) * Math.sin((x - (elasticity / 4)) * ((2 * Math.PI) / elasticity)) + 1;
        } else {
            return Math.pow(smoothness, 10 * (x - 1)) * Math.cos((x - 1) * (smoothness * (Math.PI / 2)));
        }
    }
}
