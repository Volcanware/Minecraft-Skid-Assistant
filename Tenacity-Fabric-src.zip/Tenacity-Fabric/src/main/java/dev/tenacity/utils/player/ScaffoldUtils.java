package dev.tenacity.utils.player;

import dev.tenacity.Tenacity;
import dev.tenacity.module.impl.movement.Scaffold;
import dev.tenacity.module.impl.movement.Speed;
import dev.tenacity.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class ScaffoldUtils implements Utils {

    public static class BlockCache {

        private final BlockPos position;
        private final Direction facing;

        public BlockCache(final BlockPos position, final Direction facing) {
            this.position = position;
            this.facing = facing;
        }

        public BlockPos getPosition() {
            return this.position;
        }

        public Direction getFacing() {
            return this.facing;
        }
    }

    public static double getYLevel() {
        if (!Scaffold.keepY.isEnabled() || Scaffold.keepYMode.is("Speed toggled") && !Tenacity.INSTANCE.isEnabled(Speed.class)) {
            return mc.player.getY() - 1.0;
        }
        return mc.player.getY() - 1.0 >= Scaffold.keepYCoord && Math.max(mc.player.getY(), Scaffold.keepYCoord)
                - Math.min(mc.player.getY(), Scaffold.keepYCoord) <= 3.0 && !mc.options.jumpKey.isPressed()
                ? Scaffold.keepYCoord
                : mc.player.getY() - 1.0;
    }

    public static BlockCache getBlockInfo() {
        final BlockPos belowBlockPos = BlockPos.ofFloored(mc.player.getX(), getYLevel() - (Scaffold.isDownwards() ? 1 : 0), mc.player.getZ());
        if (mc.world.getBlockState(belowBlockPos).isAir()) {
            for (int x = 0; x < 4; x++) {
                for (int z = 0; z < 4; z++) {
                    for (int i = 1; i > -3; i -= 2) {
                        final BlockPos blockPos = belowBlockPos.add(x * i, 0, z * i);
                        if (mc.world.getBlockState(blockPos).isAir()) {
                            for (Direction direction : Direction.values()) {
                                final BlockPos block = blockPos.offset(direction);
                                if (mc.world.getBlockState(block).isSolidBlock(mc.world, block)) {
                                    return new BlockCache(block, direction.getOpposite());
                                }
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    public static int getBlockSlot() {
        for (int i = 0; i < 9; i++) {
            final ItemStack itemStack = mc.player.getInventory().getStack(i);
            if (!itemStack.isEmpty() && itemStack.getItem() instanceof BlockItem && itemStack.getCount() > 0) {
                final BlockItem itemBlock = (BlockItem) itemStack.getItem();
                if (isBlockValid(itemBlock.getBlock())) {
                    return i;
                }
            }
        }
        return -1;
    }

    public static int getBlockCount() {
        int count = 0;
        for (int i = 0; i < 9; i++) {
            final ItemStack itemStack = mc.player.getInventory().getStack(i);
            if (!itemStack.isEmpty() && itemStack.getItem() instanceof BlockItem && itemStack.getCount() > 0) {
                final BlockItem itemBlock = (BlockItem) itemStack.getItem();
                if (isBlockValid(itemBlock.getBlock())) {
                    count += itemStack.getCount();
                }
            }
        }
        return count;
    }

    private static boolean isBlockValid(final Block block) {
        return (block.getDefaultState().isOpaque() || block == Blocks.GLASS) &&
                block != Blocks.SAND &&
                block != Blocks.GRAVEL &&
                block != Blocks.DISPENSER &&
                block != Blocks.COMMAND_BLOCK &&
                block != Blocks.NOTE_BLOCK &&
                block != Blocks.FURNACE &&
                block != Blocks.CRAFTING_TABLE &&
                block != Blocks.TNT &&
                block != Blocks.DROPPER &&
                block != Blocks.BEACON;
    }

    public static Vec3d getHypixelVec3(BlockCache data) {
        BlockPos pos = data.position;
        Direction face = data.facing;
        double x = (double) pos.getX() + 0.5, y = (double) pos.getY() + 0.5, z = (double) pos.getZ() + 0.5;
        if (face != Direction.UP && face != Direction.DOWN) {
            y += 0.5;
        } else {
            x += 0.3;
            z += 0.3;
        }
        if (face == Direction.WEST || face == Direction.EAST) {
            z += 0.15;
        }
        if (face == Direction.SOUTH || face == Direction.NORTH) {
            x += 0.15;
        }
        return new Vec3d(x, y, z);
    }

}
