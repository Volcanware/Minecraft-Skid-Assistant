package dev.tenacity.utils.misc;

import dev.tenacity.module.Module;

import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StringUtils {

    public static String findLongestModuleName(List<Module> modules) {
        return Collections.max(modules, Comparator.comparing(module -> (module.getName() + (module.getSuffix() != null ? " " + module.getSuffix() : "")).length())).getName();
    }

    public static String getLongestModeName(List<String> listOfWords) {
        String longestWord = null;
        for (String word : listOfWords) {
            if (longestWord == null || word.length() > longestWord.length()) {
                longestWord = word;
            }
        }
        return longestWord != null ? longestWord : "";
    }

    public static String b64(Object o) {
        return Base64.getEncoder().encodeToString(String.valueOf(o).getBytes());
    }

    public static boolean contains(String name, String... keywords) {
        for (String keyword : keywords) {
            if (name.toLowerCase().contains(keyword.toLowerCase())) return true;
        }
        return false;
    }

    public static int getPingColor(int ping) {
        return ping < 0 ? 11141120 : ping < 150 ? 5011001 : ping < 300 ? 16579584 : 11141120;
    }
}
