package dev.tenacity.utils.misc;

import dev.tenacity.utils.Utils;

/**
 * Client-side game-speed multiplier (the 1.8.9 {@code mc.timer.timerSpeed} hack).
 * On 1.21.11 this is implemented through the client world's tick manager:
 * {@code mc.world.getTickManager().setTickRate(20f * mult)}.
 */
public class TimerUtils implements Utils {

    private static final float DEFAULT_TICK_RATE = 20f;

    public static float getTimerSpeed() {
        if (mc.world == null) return 1f;
        return mc.world.getTickManager().getTickRate() / DEFAULT_TICK_RATE;
    }

    public static void setTimerSpeed(float timerSpeed) {
        if (mc.world == null) return;
        mc.world.getTickManager().setTickRate(DEFAULT_TICK_RATE * timerSpeed);
    }

}
