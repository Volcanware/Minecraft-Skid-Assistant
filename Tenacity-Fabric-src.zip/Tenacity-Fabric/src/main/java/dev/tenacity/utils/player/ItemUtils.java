package dev.tenacity.utils.player;

import dev.tenacity.utils.Utils;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;

public class ItemUtils implements Utils {

    /**
     * Level of an enchantment on a stack, 0 when absent.
     * Replaces EnchantmentHelper.getEnchantmentLevel(id, stack).
     */
    public static int getEnchantLevel(ItemStack stack, RegistryKey<Enchantment> enchantment) {
        if (stack == null || stack.isEmpty() || mc.world == null) return 0;
        return mc.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT)
                .getOptional(enchantment)
                .map(entry -> EnchantmentHelper.getLevel(entry, stack))
                .orElse(0);
    }

    /**
     * Sum of an attribute's modifier values provided by the stack
     * (e.g. EntityAttributes.ARMOR for armor points, EntityAttributes.ATTACK_DAMAGE for weapons).
     */
    public static double getAttributeValue(ItemStack stack, RegistryEntry<EntityAttribute> attribute) {
        if (stack == null || stack.isEmpty()) return 0;
        AttributeModifiersComponent component = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        if (component == null) component = stack.getItem().getComponents().get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        double value = 0;
        if (component != null) {
            for (AttributeModifiersComponent.Entry entry : component.modifiers()) {
                if (entry.attribute() == attribute) {
                    value += entry.modifier().value();
                }
            }
        }
        return value;
    }

    public static EquippableComponent getEquippable(ItemStack stack) {
        return stack == null || stack.isEmpty() ? null : stack.get(DataComponentTypes.EQUIPPABLE);
    }

    /** Replaces {@code item instanceof ItemArmor}. */
    public static boolean isArmor(ItemStack stack) {
        EquippableComponent equippable = getEquippable(stack);
        return equippable != null && (equippable.slot() == EquipmentSlot.HEAD
                || equippable.slot() == EquipmentSlot.CHEST
                || equippable.slot() == EquipmentSlot.LEGS
                || equippable.slot() == EquipmentSlot.FEET);
    }

    /** Whether the stack equips into the given armor slot. */
    public static boolean isArmorFor(ItemStack stack, EquipmentSlot slot) {
        EquippableComponent equippable = getEquippable(stack);
        return equippable != null && equippable.slot() == slot;
    }

    /** EquipmentSlot for armor type: 1=helmet, 2=chestplate, 3=leggings, 4=boots. */
    public static EquipmentSlot getArmorEquipmentSlot(int type) {
        switch (type) {
            case 1: return EquipmentSlot.HEAD;
            case 2: return EquipmentSlot.CHEST;
            case 3: return EquipmentSlot.LEGS;
            default: return EquipmentSlot.FEET;
        }
    }

    /** Replaces {@code item instanceof ItemTool} (pickaxe/axe/shovel families). */
    public static boolean isTool(ItemStack stack) {
        return stack.isIn(ItemTags.PICKAXES) || stack.isIn(ItemTags.AXES) || stack.isIn(ItemTags.SHOVELS);
    }
}
