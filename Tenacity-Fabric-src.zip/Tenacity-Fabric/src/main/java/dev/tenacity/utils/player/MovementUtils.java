package dev.tenacity.utils.player;

import dev.tenacity.event.impl.player.MoveEvent;
import dev.tenacity.event.impl.player.PlayerMoveUpdateEvent;
import dev.tenacity.utils.Utils;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

public class MovementUtils implements Utils {

    public static boolean isMoving() {
        return mc.player != null && (mc.player.input.getMovementInput().y != 0F || mc.player.input.getMovementInput().x != 0F);
    }

    public static float getMoveYaw(float yaw) {
        if (mc.player.input.getMovementInput().y < 0) {
            yaw += 180;
        }
        float forward = 1;
        if (mc.player.input.getMovementInput().y < 0) {
            forward = -0.5f;
        } else if (mc.player.input.getMovementInput().y > 0) {
            forward = 0.5f;
        }
        if (mc.player.input.getMovementInput().x > 0) {
            yaw -= 90 * forward;
        }
        if (mc.player.input.getMovementInput().x < 0) {
            yaw += 90 * forward;
        }
        return (float) Math.toRadians(yaw);
    }

    public static void setSpeed(double moveSpeed, float yaw, double strafe, double forward) {
        if (forward != 0.0D) {
            if (strafe > 0.0D) {
                yaw += ((forward > 0.0D) ? -45 : 45);
            } else if (strafe < 0.0D) {
                yaw += ((forward > 0.0D) ? 45 : -45);
            }
            strafe = 0.0D;
            if (forward > 0.0D) {
                forward = 1.0D;
            } else if (forward < 0.0D) {
                forward = -1.0D;
            }
        }
        if (strafe > 0.0D) {
            strafe = 1.0D;
        } else if (strafe < 0.0D) {
            strafe = -1.0D;
        }
        double mx = Math.cos(Math.toRadians((yaw + 90.0F)));
        double mz = Math.sin(Math.toRadians((yaw + 90.0F)));
        mc.player.setVelocity(forward * moveSpeed * mx + strafe * moveSpeed * mz,
                mc.player.getVelocity().y,
                forward * moveSpeed * mz - strafe * moveSpeed * mx);
    }

    public static void setSpeedHypixel(PlayerMoveUpdateEvent event, float moveSpeed, float strafeMotion) {
        event.applyMotion(moveSpeed, strafeMotion);
    }

    public static void setSpeed(double moveSpeed) {
        setSpeed(moveSpeed, mc.player.getYaw(), mc.player.input.getMovementInput().x, mc.player.input.getMovementInput().y);
    }

    public static void setSpeed(MoveEvent moveEvent, double moveSpeed, float yaw, double strafe, double forward) {
        if (forward != 0.0D) {
            if (strafe > 0.0D) {
                yaw += ((forward > 0.0D) ? -45 : 45);
            } else if (strafe < 0.0D) {
                yaw += ((forward > 0.0D) ? 45 : -45);
            }
            strafe = 0.0D;
            forward = forward > 0.0D ? 1.0D : -1.0D;
        }
        strafe = strafe > 0.0D ? 1.0D : (strafe < 0.0D ? -1.0D : strafe);
        double mx = Math.cos(Math.toRadians((yaw + 90.0F)));
        double mz = Math.sin(Math.toRadians((yaw + 90.0F)));
        moveEvent.setX(forward * moveSpeed * mx + strafe * moveSpeed * mz);
        moveEvent.setZ(forward * moveSpeed * mz - strafe * moveSpeed * mx);
    }

    public static void setSpeed(MoveEvent moveEvent, double moveSpeed) {
        setSpeed(moveEvent, moveSpeed, mc.player.getYaw(), mc.player.input.getMovementInput().x, mc.player.input.getMovementInput().y);
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = mc.player.getMovementSpeed();
        if (mc.player.hasStatusEffect(StatusEffects.SPEED)) {
            double amplifier = mc.player.getStatusEffect(StatusEffects.SPEED).getAmplifier();
            baseSpeed *= 1 + 0.2 * (amplifier + 1);
        }
        return baseSpeed;
    }

    public static void sendFlyingCapabilities(final boolean isFlying, final boolean allowFlying) {
        mc.player.getAbilities().flying = isFlying;
        mc.player.getAbilities().allowFlying = allowFlying;
    }

    public static double getBaseMoveSpeed2() {
        double baseSpeed = 0.2875;
        if (mc.player.hasStatusEffect(StatusEffects.SPEED)) {
            int amplifier = mc.player.getStatusEffect(StatusEffects.SPEED).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (amplifier + 1);
        }
        return baseSpeed;
    }

    public static double getBaseMoveSpeedStupid() {
        return mc.player.getMovementSpeed();
    }

    public static boolean isOnGround(double height) {
        return !mc.world.getCollisions(mc.player, mc.player.getBoundingBox().offset(0.0, -height, 0.0)).iterator().hasNext();
    }

    public static float getSpeed() {
        return (float) Math.sqrt(mc.player.getVelocity().x * mc.player.getVelocity().x + mc.player.getVelocity().z * mc.player.getVelocity().z);
    }

    public static float getMaxFallDist() {
        float maxDistance = 0;
        for (int i = 0; i <= 300; i++) {
            BlockPos pos = mc.player.getBlockPos().down(i);
            if (!mc.world.getBlockState(pos).isAir()) {
                maxDistance = i;
                break;
            }
        }
        return maxDistance;
    }
}
