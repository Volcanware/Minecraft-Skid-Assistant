package dev.tenacity.utils.objects;

import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.SmoothStepAnimation;

public class Scroll {

    private float maxScroll = Float.MAX_VALUE, minScroll = 0, rawScroll = 0;
    private float scroll;
    private Animation scrollAnimation = new SmoothStepAnimation(0, 0, Direction.BACKWARDS);
    private int lastWheel;

    public void onScroll(int ms, int wheelDelta) {
        scroll = rawScroll - scrollAnimation.getOutput().floatValue();
        rawScroll += wheelDelta / 4f;
        rawScroll = Math.max(Math.min(minScroll, rawScroll), -maxScroll);
        scrollAnimation = new SmoothStepAnimation(ms, rawScroll - scroll, Direction.BACKWARDS);
        lastWheel = wheelDelta;
    }

    public boolean isScrollAnimationDone() {
        return scrollAnimation.isDone();
    }

    public float getScroll() {
        scroll = rawScroll - scrollAnimation.getOutput().floatValue();
        return scroll;
    }

    public float getMaxScroll() { return maxScroll; }
    public void setMaxScroll(float maxScroll) { this.maxScroll = maxScroll; }
    public float getMinScroll() { return minScroll; }
    public void setMinScroll(float minScroll) { this.minScroll = minScroll; }
    public float getRawScroll() { return rawScroll; }
    public void setRawScroll(float rawScroll) { this.rawScroll = rawScroll; }
    public Animation getScrollAnimation() { return scrollAnimation; }
    public void setScrollAnimation(Animation a) { this.scrollAnimation = a; }
}
