package dev.tenacity.utils.player;

import dev.tenacity.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;

public class InventoryUtils implements Utils {

    public static int getItemSlot(Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == item) return i;
        }
        return -1;
    }

    public static int getBlockSlot(Block block) {
        return getItemSlot(block.asItem());
    }

    public static Item getHeldItem() {
        return mc.player.getMainHandStack().getItem();
    }

    public static boolean isHoldingSword() {
        return mc.player.getMainHandStack().isIn(ItemTags.SWORDS);
    }

    public static void click(int slot, int mouseButton, boolean shiftClick) {
        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot, mouseButton,
                shiftClick ? SlotActionType.QUICK_MOVE : SlotActionType.PICKUP, mc.player);
    }

    public static void drop(int slot) {
        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot, 1, SlotActionType.THROW, mc.player);
    }

    public static void swap(int slot, int hSlot) {
        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot, hSlot, SlotActionType.SWAP, mc.player);
    }

    public static float getSwordStrength(ItemStack stack) {
        return stack.isIn(ItemTags.SWORDS) ? 4f : 1f;
    }
}
