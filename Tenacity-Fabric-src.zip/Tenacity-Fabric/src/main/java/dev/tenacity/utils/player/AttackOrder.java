package dev.tenacity.utils.player;

import dev.tenacity.utils.Utils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

/**
 * Ported from dev.tenacity.viamcp.utils.AttackOrder. The ViaVersion protocol check is
 * dropped: on 1.21 the 1.9+ attack order (attack packet before swing) always applies.
 */
public class AttackOrder implements Utils {

    public static void sendFixedAttack(PlayerEntity player, Entity target) {
        mc.interactionManager.attackEntity(player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
