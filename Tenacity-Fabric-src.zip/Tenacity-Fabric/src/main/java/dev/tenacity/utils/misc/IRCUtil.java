package dev.tenacity.utils.misc;

import dev.tenacity.utils.Utils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Stub for the original dev.tenacity.intent.irc.IRCUtil.
 * <p>
 * The original implementation connected to an external IRC backend
 * ({@code store.intent.irc.IntentIRC}) which is cloud/server-side
 * infrastructure and is therefore not ported. This stub preserves the
 * public surface the render modules use — the static {@link #usersMap}
 * mapping game usernames to IRC display names — so ESP2D / IRC compile
 * and behave as if the IRC client had no users online.
 */
public class IRCUtil implements Utils {

    /** Maps in-game username -> IRC display name. Filled by the (unported) IRC backend. */
    public static final Map<String, String> usersMap = new LinkedHashMap<>();

    public void onTick() {
    }

    public void onMessage(String message) {
    }

    public void onUsernameChange(String oldName, String newName) {
        String display = usersMap.remove(oldName);
        if (display != null) {
            usersMap.put(newName, display);
        }
    }

    public void onServerChange() {
    }

    public void onShutdown() {
    }
}
