package dev.tenacity.utils.tuples.mutable;

public class MutablePair<A, B> {

    private A first;
    private B second;

    private MutablePair(A first, B second) {
        this.first = first;
        this.second = second;
    }

    public static <A, B> MutablePair<A, B> of(A first, B second) {
        return new MutablePair<>(first, second);
    }

    public A getFirst() { return first; }
    public void setFirst(A first) { this.first = first; }
    public B getSecond() { return second; }
    public void setSecond(B second) { this.second = second; }
}
