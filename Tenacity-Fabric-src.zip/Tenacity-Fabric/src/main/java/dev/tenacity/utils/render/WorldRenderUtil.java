package dev.tenacity.utils.render;

import dev.tenacity.utils.Utils;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

/**
 * Emulates the old GL11 immediate-mode world rendering used by the 1.8.9 render modules.
 * Vertices are emitted camera-relative (like glTranslated(-renderPos)); drawing happens
 * through Minecraft's entity vertex consumers with debug RenderLayers, which are drawn
 * without depth-test obstruction and flushed automatically during world rendering.
 *
 * Usage mirrors glPushMatrix/glBegin/glVertex/glEnd:
 *   WorldRenderUtil.start3D();
 *   WorldRenderUtil.begin(RenderLayers.debugTriangleFan());
 *   WorldRenderUtil.color(argb);
 *   WorldRenderUtil.vertex(x, y, z);
 *   WorldRenderUtil.end3D();
 *
 * LINE_LOOP should be emitted via getDebugLineStrip by repeating the first vertex at the
 * end; TRIANGLE_STRIP pairs should be emitted as getDebugQuads quads.
 */
public class WorldRenderUtil implements Utils {

    private static final MatrixStack matrices = new MatrixStack();
    private static net.minecraft.client.render.VertexConsumer buffer;
    private static float red = 1, green = 1, blue = 1, alpha = 1;

    public static MatrixStack matrices() {
        return matrices;
    }

    public static Camera camera() {
        return mc.gameRenderer.getCamera();
    }

    public static Vec3d cameraPos() {
        return camera().getCameraPos();
    }

    private static VertexConsumerProvider.Immediate consumers() {
        return mc.getBufferBuilders().getEntityVertexConsumers();
    }

    public static void begin(RenderLayer layer) {
        buffer = consumers().getBuffer(layer);
    }

    /**
     * Flush every queued layer at once. Immediate.draw() goes through each layer's
     * own index-buffer setup; the per-layer getBuffer() flush NPEs on debug layers.
     */
    private static void draw() {
        try {
            consumers().draw();
        } catch (RuntimeException ignored) {
        }
    }

    /**
     * Pushes a fresh matrix positioned at the camera origin, so emitted vertices use
     * camera-relative coordinates exactly like the old glTranslated(-renderPos) modelview.
     */
    public static void start3D() {
        Vec3d cam = cameraPos();
        matrices.push();
        matrices.translate(-cam.x, -cam.y, -cam.z);
    }

    public static void end3D() {
        draw();
        matrices.pop();
    }

    /** Old glTranslated on the camera-relative stack. */
    public static void translate(double x, double y, double z) {
        matrices.translate(x, y, 0);
    }

    /** Billboard rotation matching glRotated(-playerViewY, Y) + glRotated(playerViewX, X). */
    public static void billboard() {
        Camera camera = camera();
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
    }



    public static void color(int argb) {
        alpha = ((argb >> 24) & 0xFF) / 255f;
        red = ((argb >> 16) & 0xFF) / 255f;
        green = ((argb >> 8) & 0xFF) / 255f;
        blue = (argb & 0xFF) / 255f;
    }

    public static void color(int rgb, float a) {
        red = ((rgb >> 16) & 0xFF) / 255f;
        green = ((rgb >> 8) & 0xFF) / 255f;
        blue = (rgb & 0xFF) / 255f;
        alpha = a;
    }

    public static void resetColor() {
        red = green = blue = alpha = 1;
    }

    /** Emits a vertex in the current (already camera-relative) space. */
    public static void vertex(double x, double y, double z) {
        buffer.vertex(matrices.peek(), (float) x, (float) y, (float) z)
                .color(red, green, blue, alpha)
                // Line pipelines (RenderLayers.LINES) require NORMAL + LINE_WIDTH;
                // they're no-ops on formats that don't declare them.
                .normal(0, 1, 0)
                .lineWidth(1f);
    }
}
