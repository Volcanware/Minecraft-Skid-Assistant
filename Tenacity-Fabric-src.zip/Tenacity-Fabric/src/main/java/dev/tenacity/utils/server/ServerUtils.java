package dev.tenacity.utils.server;

import dev.tenacity.utils.Utils;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.entity.LivingEntity;

public class ServerUtils implements Utils {

    public static ServerInfo lastServer;
    private static boolean onHypixel;

    public static boolean serverCheck(String ip) {
        ServerInfo server = mc.getCurrentServerEntry();
        if (server == null) return false;
        return server.address.equalsIgnoreCase(ip);
    }

    public static boolean isGeniuneHypixel() {
        return serverCheck("hypixel.net") || serverCheck("mc.hypixel.net");
    }

    public static boolean isOnHypixel() {
        return onHypixel;
    }

    public static void updateServerStatus() {
        ServerInfo server = mc.getCurrentServerEntry();
        onHypixel = server != null && server.address.toLowerCase().contains("hypixel");
        if (server != null) lastServer = server;
    }

    public static boolean isInLobby() {
        return mc.world != null && mc.player != null && mc.getCurrentServerEntry() == null;
    }

    public static boolean isOnSameTeam(LivingEntity ent) {
        if (mc.player == null || mc.world == null) return false;
        if (mc.player.getScoreboardTeam() == null || ent.getScoreboardTeam() == null) return false;
        return mc.player.getScoreboardTeam().isEqual(ent.getScoreboardTeam());
    }

    public static String getRemoteIp() {
        ServerInfo server = mc.getCurrentServerEntry();
        return server != null ? server.address : "singleplayer";
    }
}
