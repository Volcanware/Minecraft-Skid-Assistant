package dev.tenacity.utils.render;

import net.minecraft.client.gl.RenderPipelines;

import java.awt.*;

import dev.tenacity.utils.Utils;

public class GradientUtil implements Utils {

    public static void drawGradient(float x, float y, float width, float height, float alpha,
                                    Color bottomLeft, Color topLeft, Color bottomRight, Color topRight) {
        if (Utils.getCtx() == null) return;
        TenacityGuiRenderState s = RenderUtil.newQuadState();
        s.addQuad(x, y, x + width, y, x + width, y + height, x, y + height,
                topLeft.getRGB(), topRight.getRGB(), bottomRight.getRGB(), bottomLeft.getRGB());
        RenderUtil.submitQuads(s);
    }

    public static void drawGradient(float x, float y, float width, float height,
                                    Color bottomLeft, Color topLeft, Color bottomRight, Color topRight) {
        drawGradient(x, y, width, height, 1, bottomLeft, topLeft, bottomRight, topRight);
    }

    public static void drawGradientLR(float x, float y, float width, float height, float alpha, Color left, Color right) {
        drawGradient(x, y, width, height, alpha, left, left, right, right);
    }

    public static void drawGradientTB(float x, float y, float width, float height, float alpha, Color top, Color bottom) {
        drawGradient(x, y, width, height, alpha, bottom, top, bottom, top);
    }

    public static void applyGradientHorizontal(float x, float y, float width, float height, float alpha, Color left, Color right, Runnable content) {
        content.run();
    }

    public static void applyGradientVertical(float x, float y, float width, float height, float alpha, Color top, Color bottom, Runnable content) {
        content.run();
    }

    public static void applyGradientCornerRL(float x, float y, float width, float height, float alpha, Color bottomLeft, Color topRight, Runnable content) {
        content.run();
    }

    public static void applyGradientCornerLR(float x, float y, float width, float height, float alpha, Color bottomRight, Color topLeft, Runnable content) {
        content.run();
    }

    public static void applyGradient(float x, float y, float width, float height, float alpha,
                                     Color bottomLeft, Color topLeft, Color bottomRight, Color topRight, Runnable content) {
        content.run();
    }
}
