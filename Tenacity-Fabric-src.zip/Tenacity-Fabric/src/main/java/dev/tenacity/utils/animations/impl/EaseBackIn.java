package dev.tenacity.utils.animations.impl;

import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;

public class EaseBackIn extends Animation {

    private final float easeAmount;

    public EaseBackIn(int ms, double endPoint, float easeAmount) {
        super(ms, endPoint);
        this.easeAmount = easeAmount;
    }

    public EaseBackIn(int ms, double endPoint, float easeAmount, Direction direction) {
        super(ms, endPoint, direction);
        this.easeAmount = easeAmount;
    }

    protected double getEquation(double x1) {
        float x = (float) x1;
        float shrink = easeAmount + 1;
        return Math.max(0, Math.pow(x, 3) * ((shrink + 1) * x - shrink) + Math.pow(x, 2) * shrink * 0.5f);
    }
}
