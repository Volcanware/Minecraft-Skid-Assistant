package dev.tenacity.ui.clickguis.dropdown.components.settings;

import dev.tenacity.module.settings.impl.StringSetting;
import dev.tenacity.ui.clickguis.dropdown.components.SettingComponent;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;

public class StringComponent extends SettingComponent<StringSetting> {

    private boolean typing;

    public StringComponent(StringSetting setting) {
        super(setting);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        StringSetting setting = getSetting();
        RoundedUtil.drawRound(x + 6, y + 2, width - 12, height - 4, 3,
                ColorUtil.applyOpacity(new Color(45, 45, 45), alpha));
        String text = setting.getString() + (typing ? "_" : "");
        tenacityFont14().drawString(text, x + 9, y + 5,
                ColorUtil.applyOpacity(new Color(190, 190, 190), alpha).getRGB());
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (!typing) return;
        StringSetting setting = getSetting();
        if (keyCode == 259 && !setting.getString().isEmpty()) {
            setting.setString(setting.getString().substring(0, setting.getString().length() - 1));
        } else if (keyCode == 256 || keyCode == 257) {
            typing = false;
        } else if (typedChar >= 32 && typedChar < 127) {
            setting.setString(setting.getString() + typedChar);
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        typing = isHoveringBox(mouseX, mouseY) && button == 0 && isClickable(y + height);
    }
}
