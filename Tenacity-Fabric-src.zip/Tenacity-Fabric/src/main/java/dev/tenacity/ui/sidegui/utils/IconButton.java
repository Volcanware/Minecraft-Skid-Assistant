package dev.tenacity.ui.sidegui.utils;

import dev.tenacity.Tenacity;
import dev.tenacity.ui.Screen;
import dev.tenacity.ui.sidegui.SideGUI;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.font.CustomFont;
import dev.tenacity.utils.render.ColorUtil;

import java.awt.*;

public class IconButton implements Screen, Utils {

    private float x, y, alpha;
    public Color accentColor, textColor = new Color(191, 191, 191);
    private Runnable clickAction;
    private boolean clickable = true;
    private CustomFont iconFont;

    private final Animation hoverAnimation = new DecelerateAnimation(250, 1);

    private String icon;
    private TooltipObject tooltip;

    public IconButton(String icon) {
        this.icon = icon;
    }

    public IconButton(String icon, String tooltip) {
        this.icon = icon;
        this.tooltip = new TooltipObject();
        this.tooltip.setTip(tooltip);
    }

    private CustomFont iconFont() {
        return iconFont != null ? iconFont : iconFont16();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        CustomFont f = iconFont();
        float iconWidth = f.getStringWidth(icon);
        float iconHeight = f.getHeight();
        boolean hovering = SideGUI.isHovering(x - 3, y - 3, iconWidth + 6, iconHeight + 6, mouseX, mouseY);
        hoverAnimation.setDirection(hovering ? Direction.FORWARDS : Direction.BACKWARDS);

        Color iconColor = ColorUtil.interpolateColorC(textColor, accentColor, hoverAnimation.getOutput().floatValue());

        f.drawString(icon, x, y, ColorUtil.applyOpacity(iconColor, alpha));

        if (tooltip != null) {
            Tenacity.INSTANCE.getSideGui().addTooltip(tooltip);
            tooltip.setHovering(hovering);
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        CustomFont f = iconFont();
        boolean hovering = SideGUI.isHovering(x - 3, y - 3, f.getStringWidth(icon) + 6, f.getHeight() + 6, mouseX, mouseY);
        if (clickable && button == 0 && hovering && clickAction != null) {
            clickAction.run();
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {

    }

    public float getWidth() {
        return iconFont().getStringWidth(icon);
    }

    public float getHeight() {
        return iconFont().getHeight();
    }

    public void setTooltip(String tooltipText) {
        if (tooltip == null) {
            tooltip = new TooltipObject();
        }
        tooltip.setTip(tooltipText);
    }

    public float getX() { return x; }
    public void setX(float x) { this.x = x; }
    public float getY() { return y; }
    public void setY(float y) { this.y = y; }
    public float getAlpha() { return alpha; }
    public void setAlpha(float alpha) { this.alpha = alpha; }
    public Color getAccentColor() { return accentColor; }
    public void setAccentColor(Color accentColor) { this.accentColor = accentColor; }
    public Color getTextColor() { return textColor; }
    public void setTextColor(Color textColor) { this.textColor = textColor; }
    public Runnable getClickAction() { return clickAction; }
    public void setClickAction(Runnable clickAction) { this.clickAction = clickAction; }
    public boolean isClickable() { return clickable; }
    public void setClickable(boolean clickable) { this.clickable = clickable; }
    public CustomFont getIconFont() { return iconFont; }
    public void setIconFont(CustomFont iconFont) { this.iconFont = iconFont; }
    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }
}
