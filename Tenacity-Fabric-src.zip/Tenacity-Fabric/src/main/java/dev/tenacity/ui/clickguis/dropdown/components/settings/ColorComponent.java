package dev.tenacity.ui.clickguis.dropdown.components.settings;

import dev.tenacity.module.settings.impl.ColorSetting;
import dev.tenacity.ui.clickguis.dropdown.components.SettingComponent;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;

public class ColorComponent extends SettingComponent<ColorSetting> {

    private boolean expanded;
    private boolean draggingHue;
    private final Animation expandAnimation = new DecelerateAnimation(200, 1, Direction.BACKWARDS);

    public ColorComponent(ColorSetting setting) {
        super(setting);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        ColorSetting setting = getSetting();
        expandAnimation.setDirection(expanded ? Direction.FORWARDS : Direction.BACKWARDS);
        float out = expandAnimation.getOutput().floatValue();

        tenacityFont16().drawString(setting.getName(), x + 8, y + 4,
                ColorUtil.applyOpacity(new Color(190, 190, 190), alpha).getRGB());
        RoundedUtil.drawRound(x + width - 22, y + 3, 16, 8, 3,
                ColorUtil.applyOpacity(setting.getColor(), alpha));

        if (out > 0.01f) {
            float pickerY = y + 14;
            float pickerW = width - 16;
            // hue bar
            for (int i = 0; i < pickerW; i++) {
                Color c = Color.getHSBColor(i / pickerW, 1f, 1f);
                RenderUtil.drawRect(x + 8 + i, pickerY, 1, 6,
                        ColorUtil.applyOpacity(c, alpha * out).getRGB());
            }
            float[] hsb = Color.RGBtoHSB(setting.getColor().getRed(), setting.getColor().getGreen(),
                    setting.getColor().getBlue(), null);
            float hueX = x + 8 + hsb[0] * pickerW;
            RenderUtil.drawRect(hueX - 1, pickerY - 1, 2, 8,
                    ColorUtil.applyOpacity(Color.WHITE, alpha * out).getRGB());

            if (draggingHue) {
                float hue = Math.min(1, Math.max(0, (mouseX - (x + 8)) / pickerW));
                setting.setColor(Color.getHSBColor(hue, hsb[1], hsb[2]));
            }
        }
        countSize = 1 + (24f / 15f) * out;
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (isHoveringBox(mouseX, mouseY) && mouseY < y + 14 && button == 0 && isClickable(y + height)) {
            expanded = !expanded;
        }
        if (expanded && HoveringUtil.isHovering(x + 8, y + 13, width - 16, 8, mouseX, mouseY) && button == 0) {
            draggingHue = true;
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int button) {
        draggingHue = false;
    }
}
