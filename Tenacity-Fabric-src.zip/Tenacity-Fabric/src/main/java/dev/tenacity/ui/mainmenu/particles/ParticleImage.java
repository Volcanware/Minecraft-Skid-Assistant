package dev.tenacity.ui.mainmenu.particles;

import dev.tenacity.utils.tuples.Pair;
import net.minecraft.util.Identifier;

public class ParticleImage {
    private final Pair<Integer, Integer> dimensions;
    private final Identifier location;
    private final ParticleType particleType;

    public ParticleImage(int particleNumber, Pair<Integer, Integer> dimensions) {
        this.dimensions = dimensions;
        particleType = dimensions.getFirst() > 350 ? ParticleType.BIG : ParticleType.SMALL;
        location = Identifier.of("tenacity", "mainmenu/particles" + particleNumber + ".png");
    }

    public Pair<Integer, Integer> getDimensions() { return dimensions; }
    public Identifier getLocation() { return location; }
    public ParticleType getParticleType() { return particleType; }

}
