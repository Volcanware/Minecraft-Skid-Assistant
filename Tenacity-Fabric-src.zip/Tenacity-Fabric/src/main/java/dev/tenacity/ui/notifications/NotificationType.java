package dev.tenacity.ui.notifications;

import dev.tenacity.utils.font.FontUtil;

import java.awt.*;

public enum NotificationType {
    WARNING("Warning", FontUtil.WARNING, new Color(255, 215, 0)),
    DISABLE("Disabled", FontUtil.XMARK, new Color(255, 90, 90)),
    INFO("Info", FontUtil.INFO, new Color(28, 167, 222)),
    SUCCESS("Enabled", FontUtil.CHECKMARK, new Color(105, 255, 140));

    private final String name;
    private final String icon;
    private final Color color;

    NotificationType(String name, String icon, Color color) {
        this.name = name;
        this.icon = icon;
        this.color = color;
    }

    public String getName() { return name; }
    public String getIcon() { return icon; }
    public Color getColor() { return color; }
}
