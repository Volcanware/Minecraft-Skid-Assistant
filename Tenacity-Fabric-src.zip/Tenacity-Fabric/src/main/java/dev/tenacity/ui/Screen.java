package dev.tenacity.ui;

public interface Screen extends dev.tenacity.utils.Utils {

    default void initGui() {}

    default void drawScreen(int mouseX, int mouseY) {}

    default void keyTyped(char typedChar, int keyCode) {}

    default void mouseClicked(int mouseX, int mouseY, int button) {}

    default void mouseReleased(int mouseX, int mouseY, int button) {}

    default void onDrag(int mouseX, int mouseY) {}
}
