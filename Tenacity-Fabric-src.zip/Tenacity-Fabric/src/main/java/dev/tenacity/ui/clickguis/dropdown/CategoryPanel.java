package dev.tenacity.ui.clickguis.dropdown;

import dev.tenacity.Tenacity;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.render.ClickGUIMod;
import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.module.impl.render.PostProcessing;
import dev.tenacity.ui.Screen;
import dev.tenacity.ui.clickguis.dropdown.components.ModuleRect;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.render.Theme;
import dev.tenacity.utils.tuples.Pair;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class CategoryPanel implements Screen, Utils {

    private final Category category;

    private final float rectWidth = 105;
    private final float categoryRectHeight = 15;
    private boolean typing;

    public final Pair<Animation, Animation> openingAnimations;
    private List<ModuleRect> moduleRects;

    public CategoryPanel(Category category, Pair<Animation, Animation> openingAnimations) {
        this.category = category;
        this.openingAnimations = openingAnimations;
    }

    public Category getCategory() { return category; }

    @Override
    public void initGui() {
        if (moduleRects == null) {
            moduleRects = new ArrayList<>();
            for (Module module : Tenacity.INSTANCE.getModuleCollection().getModulesInCategory(category)
                    .stream().sorted(Comparator.comparing(Module::getName)).collect(Collectors.toList())) {
                moduleRects.add(new ModuleRect(module));
            }
        }
        if (moduleRects != null) {
            moduleRects.forEach(ModuleRect::initGui);
        }
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (moduleRects != null) {
            moduleRects.forEach(moduleRect -> moduleRect.keyTyped(typedChar, keyCode));
        }
    }

    public void onDrag(int mouseX, int mouseY) {
        category.getDrag().onDraw(mouseX, mouseY);
    }

    float actualHeight = 0;

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        if (moduleRects == null || openingAnimations == null) return;

        float alpha = Math.min(1, openingAnimations.getFirst().getOutput().floatValue());
        Theme theme = Theme.getCurrentTheme();
        Pair<Color, Color> clientColors = HUDMod.getClientColors();

        float alphaValue = alpha * alpha;
        if (ClickGUIMod.transparent.isEnabled()) {
            alphaValue *= .75f;
        }
        Color clientFirst = ColorUtil.applyOpacity(clientColors.getFirst(), alphaValue);
        Color clientSecond = ColorUtil.applyOpacity(clientColors.getSecond(), alphaValue);
        int textColor = ColorUtil.applyOpacity(-1, alpha);

        float x = category.getDrag().getX();
        float y = category.getDrag().getY();

        float panelHeight = categoryRectHeight + actualHeight;

        // soft glow halo + accent outline behind the panel (original draws an
        // accent outline and a bloom pass gives the soft edge glow)
        Color outlineColor = ClickGUIMod.outlineAccent.isEnabled()
                ? clientFirst
                : ColorUtil.applyOpacity(Color.BLACK, alphaValue);
        for (int i = 14; i >= 1; i--) {
            RoundedUtil.drawRound(x - i, y - i, rectWidth + i * 2, panelHeight + i * 2, 5 + i,
                    ColorUtil.applyOpacity(outlineColor, 0.045f + 0.05f * (1f - i / 14f)));
        }
        RoundedUtil.drawRound(x - .75f, y - .5f, rectWidth + 1.5f, panelHeight + 1.5f, 5, outlineColor);

        // panel background
        RoundedUtil.drawRound(x, y, rectWidth, panelHeight, 5,
                ColorUtil.applyOpacity(theme.getBackgroundColor(), alphaValue));

        // header
        RoundedUtil.drawGradientRound(x, y, rectWidth, categoryRectHeight, 5,
                clientFirst, clientSecond, clientFirst, clientSecond);
        // header: name then icon, pair centered (original math)
        float textWidth = tenacityBoldFont22().getStringWidthFloat(category.name + " ") / 2f;
        iconFont20().drawCenteredString(category.icon, x + rectWidth / 2f + textWidth,
                y + iconFont20().getMiddleOfBox(categoryRectHeight) + 1, textColor);
        tenacityBoldFont22().drawString(category.name,
                x + ((rectWidth / 2f - textWidth) - (iconFont20().getStringWidthFloat(category.icon) / 2f)),
                y + tenacityBoldFont22().getMiddleOfBox(categoryRectHeight), textColor);

        float moduleY = y + categoryRectHeight + 2;
        float scrollOffset = category.getScroll().getScroll();

        // clip region for the scrollable module list
        RenderUtil.scissorStart(x, y + categoryRectHeight, x + rectWidth, y + panelHeight);

        float tempY = moduleY + scrollOffset;
        float count = 0;
        for (ModuleRect rect : moduleRects) {
            String searchText = Tenacity.INSTANCE.getSearchBar().getText();
            if (!searchText.isEmpty() && !rect.module.getName().toLowerCase().contains(searchText.toLowerCase())) {
                continue;
            }
            rect.x = x + 3;
            rect.y = tempY;
            rect.width = rectWidth - 6;
            rect.height = 14;
            rect.panelLimitY = y + categoryRectHeight;
            rect.alpha = alpha;
            rect.drawScreen(mouseX, mouseY);
            tempY += rect.height + (float) (rect.getSettingSize() * 16);
            count += rect.height + (float) (rect.getSettingSize() * 16);
        }

        RenderUtil.scissorEnd();

        actualHeight = Math.min(Module.allowedClickGuiHeight, count + 4);
        category.getScroll().setMaxScroll(Math.max(0, count - Module.allowedClickGuiHeight + 10));
        category.getScroll().setMinScroll(0);


        boolean hovering = HoveringUtil.isHovering(x, y, rectWidth, categoryRectHeight, mouseX, mouseY);
        // hover.setDirection(hovering ? Direction.FORWARDS : Direction.BACKWARDS);

        for (ModuleRect rect : moduleRects) {
            rect.tooltipObject.render(mouseX, mouseY);
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        float x = category.getDrag().getX();
        float y = category.getDrag().getY();
        boolean hoveringHeader = HoveringUtil.isHovering(x, y, rectWidth, categoryRectHeight, mouseX, mouseY);
        category.getDrag().onClick(mouseX, mouseY, button, hoveringHeader);
        if (moduleRects != null) {
            for (ModuleRect rect : moduleRects) {
                rect.mouseClicked(mouseX, mouseY, button);
            }
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int button) {
        category.getDrag().onRelease(button);
        if (moduleRects != null) {
            for (ModuleRect rect : moduleRects) {
                rect.mouseReleased(mouseX, mouseY, button);
            }
        }
    }
}
