package dev.tenacity.ui.notifications;

import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.time.TimerUtil;

import java.awt.*;

public class Notification implements Utils {

    private final NotificationType notificationType;
    private final String title, description;
    private final float time;
    private final TimerUtil timerUtil = new TimerUtil();
    private final Animation animation;
    private final Animation hoverAnimation = new DecelerateAnimation(250, 1, Direction.BACKWARDS);
    private float x, y, width, height;

    public Notification(NotificationType type, String title, String description, float time) {
        this.notificationType = type;
        this.title = title;
        this.description = description;
        this.time = time;
        animation = new DecelerateAnimation(300, 1, Direction.FORWARDS);
    }

    public void render(float x, float y, int mouseX, int mouseY) {
        this.x = x;
        this.y = y;
        float notifWidth = Math.max(tenacityFont18().getStringWidthFloat(title), tenacityFont16().getStringWidthFloat(description)) + 45;
        this.width = notifWidth;
        this.height = 34;

        float slide = (float) ((1 - animation.getOutput()) * (notifWidth + 20));
        float drawX = x - slide;

        RoundedUtil.drawRound(drawX, y, notifWidth, height, 6, ColorUtil.applyOpacity(new Color(20, 20, 20), .8f));
        RoundedUtil.drawRound(drawX, y, 4, height, 2, notificationType.getColor());

        boolean hovered = mouseX >= drawX && mouseX <= drawX + notifWidth && mouseY >= y && mouseY <= y + height;
        hoverAnimation.setDirection(hovered ? Direction.FORWARDS : Direction.BACKWARDS);

        float iconSize = 16;
        iconFont20().drawString(notificationType.getIcon(), drawX + 10, y + height / 2f - iconSize / 2f + 2, notificationType.getColor());
        tenacityBoldFont16().drawString(title, drawX + 10 + iconSize + 6, y + 6, Color.WHITE.getRGB());
        tenacityFont16().drawString(description, drawX + 10 + iconSize + 6, y + 6 + 12, new Color(200, 200, 200).getRGB());
    }

    public boolean checkTime() {
        return timerUtil.hasTimeElapsed((long) (time * 1000));
    }

    public Animation getAnimation() { return animation; }
    public float getHeight() { return height; }
}
