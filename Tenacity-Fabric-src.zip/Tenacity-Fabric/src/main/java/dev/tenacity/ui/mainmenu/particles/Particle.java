package dev.tenacity.ui.mainmenu.particles;

import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;

import java.util.Random;

/**
 * @author cedo
 * @since 05/23/2022
 */
public class Particle {
    private Animation fadeInAnimation;
    private final Animation rotateAnimation = new DecelerateAnimation(10000, 1);
    private float x, y;
    private final float initialX, initialY, speed, rotation;
    private float ticks;
    private final ParticleImage particleImage;

    static int seed = 0;

    public Particle(int scaledWidth, int scaledHeight, ParticleImage particleImage) {
        Random random = new Random();
        this.particleImage = particleImage;
        float randomX = scaledWidth + (random.nextFloat() * (scaledWidth / 2f));
        float randomY = random.nextFloat() * (-scaledHeight);
        initialX = randomX + (randomX * (seed * .1f));
        initialY = randomY + (randomY * (seed * .1f));
        ticks = random.nextFloat() * (scaledHeight / 4f);

        speed = particleImage.getParticleType().equals(ParticleType.BIG) ? 1.5f : 3;
        rotation = random.nextFloat() * 360;

        seed++;
        if (seed > 7) {
            seed = 0;
        }
    }

    public void draw() {
        if (fadeInAnimation == null) fadeInAnimation = new DecelerateAnimation(1000, 1);
        rotateAnimation.setDirection(fadeInAnimation.finished(Direction.FORWARDS) ? Direction.FORWARDS : Direction.BACKWARDS);
        float imgWidth = particleImage.getDimensions().getFirst() / 2f;
        float imgHeight = particleImage.getDimensions().getSecond() / 2f;

        float alpha = fadeInAnimation.getOutput().floatValue();
        int color = ColorUtil.applyOpacity(-1, alpha);

        dev.tenacity.utils.Utils.getCtx().getMatrices().pushMatrix();
        RenderUtil.rotateStartReal(x, y, imgWidth, imgHeight,
                (float) (rotation * rotateAnimation.getOutput().floatValue()));
        RenderUtil.drawImage(particleImage.getLocation(), x, y, imgWidth, imgHeight, color);
        dev.tenacity.utils.Utils.getCtx().getMatrices().popMatrix();
    }

    public float getX() { return x; }
    public void setX(float x) { this.x = x; }
    public float getY() { return y; }
    public void setY(float y) { this.y = y; }
    public float getInitialX() { return initialX; }
    public float getInitialY() { return initialY; }
    public float getSpeed() { return speed; }
    public float getTicks() { return ticks; }
    public void setTicks(float ticks) { this.ticks = ticks; }
    public ParticleImage getParticleImage() { return particleImage; }

}
