package dev.tenacity.ui.sidegui.panels.infopanel;

import dev.tenacity.ui.sidegui.panels.Panel;
import dev.tenacity.utils.render.ColorUtil;

import java.util.Arrays;

public class InfoPanel extends Panel {

    private final InfoRect configInfo, scriptInfo;

    public InfoPanel() {
        configInfo = new InfoRect();
        configInfo.faqButtons.addAll(Arrays.asList(
                new InfoButton("How do I save a config?",
                        "Go to the Configs panel and click the \"Save config\" button. " +
                                "You will then be prompted with a form to name your local config."),

                new InfoButton("How do I load a config?",
                        "Click the download arrow icon on the config card, or type \"Load\" into the search bar and hit enter."),

                new InfoButton("How do I delete a config?",
                        "Click the trash icon on the config card. This deletes the local config file."),

                new InfoButton("How do I see more info about a config?",
                        "Hover over the \"Hover for more information\" text on the config card to see who made it, what server it was made on, when it was updated, and more."),

                new InfoButton("Where are my configs stored?",
                        "Local configs are stored in the Tenacity/Configs folder inside your Minecraft directory.")
        ));

        scriptInfo = new InfoRect();
        scriptInfo.faqButtons.addAll(Arrays.asList(
                new InfoButton("How do I open the ClickGUI?",
                        "Press Right Shift (RSHIFT) by default. You can rebind it in the ClickGUI module settings."),

                new InfoButton("How do I switch ClickGUI styles?",
                        "Enable the ClickGUI module and change the ClickGUI mode setting between Dropdown, Modern, and Compact."),

                new InfoButton("How do I use commands?",
                        "Type commands in chat prefixed with a period. For example \".t fly\" toggles the Fly module."),

                new InfoButton("How do I bind a module to a key?",
                        "Open the ClickGUI, click a module's bind option, and press the key you want."),

                new InfoButton("How do I search for modules?",
                        "Press the search hotkey (grave/tilde by default) to open the search bar, then type a module name.")
        ));
    }


    @Override
    public void initGui() {

    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {

    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {

        tenacityBoldFont40().drawString("Info", getX() + 8, getY() + 8, getTextColor());
        tenacityFont18().drawString("developed by cedo, tear, and senoe", getX() + 8, getY() + 30, ColorUtil.applyOpacity(getTextColor(), .3f));

        float spacing = 8;
        float infoWidth = (getWidth() - (spacing * 3)) / 2f;
        configInfo.x = getX() + spacing;
        configInfo.y = getY() + 40 + spacing;
        configInfo.width = infoWidth;
        configInfo.height = getHeight() - (40 + spacing * 2);
        configInfo.alpha = getAlpha();
        configInfo.drawScreen(mouseX, mouseY);

        scriptInfo.x = configInfo.x + configInfo.width + spacing;
        scriptInfo.y = getY() + 40 + spacing;
        scriptInfo.width = infoWidth;
        scriptInfo.height = getHeight() - (40 + spacing * 2);
        scriptInfo.alpha = getAlpha();
        scriptInfo.drawScreen(mouseX, mouseY);

    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        configInfo.mouseClicked(mouseX, mouseY, button);
        scriptInfo.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {

    }
}
