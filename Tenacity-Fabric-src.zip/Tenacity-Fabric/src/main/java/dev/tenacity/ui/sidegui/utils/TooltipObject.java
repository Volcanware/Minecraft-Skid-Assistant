package dev.tenacity.ui.sidegui.utils;

import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;

public class TooltipObject implements Utils {

    private String tip;
    private boolean hovering;
    private final Animation animation = new DecelerateAnimation(250, 1, Direction.BACKWARDS);

    public void setTip(String tip) { this.tip = tip; }
    public void setHovering(boolean hovering) { this.hovering = hovering; }

    public void render(int mouseX, int mouseY) {
        animation.setDirection(hovering ? Direction.FORWARDS : Direction.BACKWARDS);
        if (!animation.isDone() && tip != null && !tip.isEmpty()) {
            float alpha = animation.getOutput().floatValue();
            float width = tenacityFont16().getStringWidthFloat(tip) + 10;
            float height = 16;
            float x = mouseX + 8;
            float y = mouseY + 10;
            RoundedUtil.drawRound(x, y, width, height, 4,
                    ColorUtil.applyOpacity(new Color(15, 15, 15), .9f * alpha));
            tenacityFont16().drawString(tip, x + 5, y + 4,
                    ColorUtil.applyOpacity(Color.WHITE, alpha).getRGB());
        }
    }
}
