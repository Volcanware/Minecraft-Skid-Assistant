package dev.tenacity.ui.sidegui.panels.infopanel;

import dev.tenacity.ui.Screen;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class InfoButton implements Screen, Utils {
    private final String question, answer;

    private float x, y, width, height, alpha, count = 1;

    private final Animation openAnimation = new DecelerateAnimation(250, 1).setDirection(Direction.BACKWARDS);
    private final Animation hoverAnimation = new DecelerateAnimation(250, 1).setDirection(Direction.BACKWARDS);

    public InfoButton(String question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    private List<String> wrapText(String text, float maxWidth) {
        List<String> lines = new ArrayList<>();
        for (String word : text.split(" ")) {
            if (lines.isEmpty()) {
                lines.add(word);
                continue;
            }
            int last = lines.size() - 1;
            String candidate = lines.get(last) + " " + word;
            if (tenacityFont16().getStringWidth(candidate) > maxWidth) {
                lines.add(word);
            } else {
                lines.set(last, candidate);
            }
        }
        return lines;
    }

    @Override
    public void initGui() {

    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {

    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        Color textColor = ColorUtil.applyOpacity(Color.WHITE, alpha);
        boolean hovering = HoveringUtil.isHovering(x, y, width, height, mouseX, mouseY);
        hoverAnimation.setDirection(hovering ? Direction.FORWARDS : Direction.BACKWARDS);
        hoverAnimation.setDuration(hovering ? 200 : 400);


        float additionalCount = 0;
        if (!openAnimation.isDone() || openAnimation.finished(Direction.FORWARDS)) {
            float heightIncrement = 3;
            float openAnim = openAnimation.getOutput().floatValue();
            List<String> lines = wrapText(answer, width - 5);
            int spacing = 3;
            float totalAnswerHeight = (lines.size() * (tenacityFont16().getHeight() + heightIncrement)) + 4;
            float additionalHeight = height + totalAnswerHeight + (spacing * 2);

            RenderUtil.scissorStart(x - 1, y + 5, width + 2, additionalHeight - 5);

            float answerY = (y + height + spacing) - (((spacing + totalAnswerHeight) * (1 - openAnim)));
            RoundedUtil.drawRound(x, answerY, width, totalAnswerHeight, 5, ColorUtil.tripleColor(55, alpha));


            for (String line : lines) {
                tenacityFont16().drawString(line, x + 3, answerY + 3.5f, textColor.getRGB());
                answerY += tenacityFont16().getHeight() + heightIncrement;
            }
            RenderUtil.scissorEnd();


            additionalCount = ((totalAnswerHeight + spacing) * openAnim) / height;
        }


        int additionalColor = (int) (5 * hoverAnimation.getOutput().floatValue());
        RoundedUtil.drawRound(x, y, width, height, 5, ColorUtil.tripleColor(37 + additionalColor, alpha));
        //Question Text
        tenacityBoldFont18().drawString(question, x + 5, y + tenacityBoldFont18().getMiddleOfBox(height), textColor.getRGB());


        float iconX = x + width - (iconFont20().getStringWidth(FontUtil.DROPDOWN_ARROW) + 5);
        float iconY = y + iconFont20().getMiddleOfBox(height) + 1;

        Utils.getCtx().getMatrices().pushMatrix();
        RenderUtil.rotateStart(iconX, iconY, iconFont20().getStringWidth(FontUtil.DROPDOWN_ARROW), iconFont20().getHeight(), 180 * openAnimation.getOutput().floatValue());
        iconFont20().drawString(FontUtil.DROPDOWN_ARROW, iconX, iconY, textColor.getRGB());
        Utils.getCtx().getMatrices().popMatrix();

        count = 1 + additionalCount;
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (HoveringUtil.isHovering(x, y, width, height, mouseX, mouseY) && button == 1) {
            openAnimation.changeDirection();
        }

    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {

    }

    public float getX() { return x; }
    public void setX(float x) { this.x = x; }
    public float getY() { return y; }
    public void setY(float y) { this.y = y; }
    public float getWidth() { return width; }
    public void setWidth(float width) { this.width = width; }
    public float getHeight() { return height; }
    public void setHeight(float height) { this.height = height; }
    public float getAlpha() { return alpha; }
    public void setAlpha(float alpha) { this.alpha = alpha; }
    public float getCount() { return count; }
    public void setCount(float count) { this.count = count; }
}
