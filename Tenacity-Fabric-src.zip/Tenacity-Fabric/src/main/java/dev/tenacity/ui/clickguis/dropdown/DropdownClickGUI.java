package dev.tenacity.ui.clickguis.dropdown;

import dev.tenacity.Tenacity;
import dev.tenacity.module.Category;
import dev.tenacity.ui.Screen;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.EaseBackIn;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.tuples.Pair;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class DropdownClickGUI extends net.minecraft.client.gui.screen.Screen implements Utils {

    private final Pair<Animation, Animation> openingAnimations = Pair.of(
            new EaseBackIn(400, 1, 2f),
            new EaseBackIn(400, .4f, 2f));

    private List<CategoryPanel> categoryPanels;

    public boolean binding;

    public DropdownClickGUI() {
        super(net.minecraft.text.Text.literal("Tenacity ClickGUI"));
    }

    public void onDrag(int mouseX, int mouseY) {
        if (categoryPanels == null) return;
        for (CategoryPanel catPanel : categoryPanels) {
            catPanel.onDrag(mouseX, mouseY);
        }
        Tenacity.INSTANCE.getSideGui().onDrag(mouseX, mouseY);
    }

    @Override
    protected void init() {
        openingAnimations.getFirst().setDirection(Direction.FORWARDS);
        openingAnimations.getSecond().setDirection(Direction.FORWARDS);

        if (categoryPanels == null) {
            categoryPanels = new ArrayList<>();
            for (Category category : Category.values()) {
                categoryPanels.add(new CategoryPanel(category, openingAnimations));
            }
        }

        Tenacity.INSTANCE.getSideGui().initGui();
        Tenacity.INSTANCE.getSideGui().getOpenAnimation().setDirection(Direction.FORWARDS);
        Tenacity.INSTANCE.getSearchBar().initGui();

        for (CategoryPanel catPanel : categoryPanels) {
            catPanel.initGui();
        }
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int keyCode = input.key();
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && !binding) {
            if (Tenacity.INSTANCE.getSearchBar().isFocused()) {
                Tenacity.INSTANCE.getSearchBar().getSearchField().setText("");
                Tenacity.INSTANCE.getSearchBar().getSearchField().setFocused(false);
                return true;
            }
            if (Tenacity.INSTANCE.getSideGui().isFocused()) {
                Tenacity.INSTANCE.getSideGui().setFocused(false);
            }
        }
        if (categoryPanels != null) {
            for (CategoryPanel catPanel : categoryPanels) {
                catPanel.keyTyped((char) 0, keyCode);
            }
        }
        Tenacity.INSTANCE.getSideGui().keyTyped((char) 0, keyCode);
        Tenacity.INSTANCE.getSearchBar().keyTyped((char) 0, keyCode);
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        char chr = (char) input.codepoint();
        if (categoryPanels != null) {
            for (CategoryPanel catPanel : categoryPanels) {
                catPanel.keyTyped(chr, -1);
            }
        }
        Tenacity.INSTANCE.getSideGui().keyTyped(chr, -1);
        Tenacity.INSTANCE.getSearchBar().keyTyped(chr, -1);
        return super.charTyped(input);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        int mouseX = (int) click.x();
        int mouseY = (int) click.y();
        int button = click.button();
        if (categoryPanels != null) {
            for (CategoryPanel catPanel : categoryPanels) {
                catPanel.mouseClicked(mouseX, mouseY, button);
            }
        }
        Tenacity.INSTANCE.getSideGui().mouseClicked(mouseX, mouseY, button);
        Tenacity.INSTANCE.getSearchBar().mouseClicked(mouseX, mouseY, button);
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseReleased(Click click) {
        int mouseX = (int) click.x();
        int mouseY = (int) click.y();
        if (categoryPanels != null) {
            for (CategoryPanel catPanel : categoryPanels) {
                catPanel.mouseReleased(mouseX, mouseY, click.button());
            }
        }
        Tenacity.INSTANCE.getSideGui().mouseReleased(mouseX, mouseY, click.button());
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseDragged(Click click, double deltaX, double deltaY) {
        onDrag((int) click.x(), (int) click.y());
        return super.mouseDragged(click, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        dev.tenacity.ui.sidegui.SideGUI.scrollDelta = (int) (verticalAmount * 120);
        if (categoryPanels != null) {
            for (CategoryPanel catPanel : categoryPanels) {
                catPanel.getCategory().getScroll().onScroll((int) (verticalAmount * 20), (int) (verticalAmount * 30));
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        Utils.setCtx(context);
        dev.tenacity.utils.render.PostProcessUtil.renderGuiBlur();
        float alpha = Math.min(1, openingAnimations.getFirst().getOutput().floatValue());

        RoundedUtil.drawRound(0, 0, context.getScaledWindowWidth(), context.getScaledWindowHeight(), 0,
                ColorUtil.applyOpacity(Color.BLACK, .3f * alpha));

        if (categoryPanels != null) {
            for (CategoryPanel catPanel : categoryPanels) {
                catPanel.drawScreen(mouseX, mouseY);
            }
        }

        Tenacity.INSTANCE.getSearchBar().drawScreen(mouseX, mouseY);
        Tenacity.INSTANCE.getSideGui().drawScreen(mouseX, mouseY);

        if (Tenacity.INSTANCE.getNotificationManager() != null) {
            Tenacity.INSTANCE.getNotificationManager().render(mouseX, mouseY);
        }
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // skip default darkened background — we draw our own dim
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        if (categoryPanels != null) {
            for (CategoryPanel catPanel : categoryPanels) {
                catPanel.getCategory().getDrag().onRelease(0);
            }
        }
        super.close();
    }
}
