package dev.tenacity.ui.sidegui.panels.configpanel;

import dev.tenacity.Tenacity;
import dev.tenacity.config.Config;
import dev.tenacity.ui.Screen;
import dev.tenacity.ui.sidegui.utils.IconButton;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LocalConfigRect implements Screen, Utils {

    private final Config config;
    private final Runnable refreshAction;

    public float x, y, width, height, alpha;

    private final Animation hoverAnimation = new DecelerateAnimation(250, 1).setDirection(Direction.BACKWARDS);
    private final List<IconButton> iconButtons = new ArrayList<>();

    public LocalConfigRect(Config config, Runnable refreshAction) {
        this.config = config;
        this.refreshAction = refreshAction;

        IconButton load = new IconButton(FontUtil.LOAD, "Load config");
        load.setClickAction(() -> {
            Tenacity.INSTANCE.getConfigManager().loadConfig(config);
        });
        iconButtons.add(load);

        IconButton delete = new IconButton(FontUtil.TRASH, "Delete config");
        delete.setClickAction(() -> {
            Tenacity.INSTANCE.getConfigManager().delete(config.getName());
            if (refreshAction != null) refreshAction.run();
        });
        iconButtons.add(delete);
    }

    @Override
    public void initGui() {

    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {

    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        boolean hovering = HoveringUtil.isHovering(x, y, width, height, mouseX, mouseY);
        hoverAnimation.setDirection(hovering ? Direction.FORWARDS : Direction.BACKWARDS);

        RoundedUtil.drawRound(x, y, width, height, 5, ColorUtil.tripleColor(27, alpha));
        RoundedUtil.drawRound(x, y, width, height, 5,
                ColorUtil.tripleColor(24, hoverAnimation.getOutput().floatValue() * .5f * alpha));

        Color textColor = ColorUtil.applyOpacity(Color.WHITE, alpha);
        tenacityBoldFont18().drawString(config.getName(), x + 8, y + 6, textColor.getRGB());
        tenacityFont14().drawString("Local config", x + 8, y + 6 + tenacityBoldFont18().getHeight() + 2,
                ColorUtil.applyOpacity(textColor, .5f).getRGB());

        // icon buttons right-aligned at bottom
        float spacing = 4;
        float iconY = y + height - (iconFont16().getHeight() + 4);
        float iconX = x + width - 8;
        for (IconButton b : iconButtons) {
            iconX -= (b.getWidth() + spacing);
            b.setX(iconX);
            b.setY(iconY);
            b.setAlpha(alpha);
            b.setAccentColor(ColorUtil.applyOpacity(getAccent(), alpha));
            b.drawScreen(mouseX, mouseY);
        }
    }

    private Color getAccent() {
        return dev.tenacity.module.impl.render.HUDMod.getClientColors().getFirst();
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        iconButtons.forEach(b -> b.mouseClicked(mouseX, mouseY, button));
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {

    }

    public Config getConfig() { return config; }
}
