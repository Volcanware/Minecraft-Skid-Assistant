package dev.tenacity.ui.clickguis.compact;

import dev.tenacity.Tenacity;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.movement.InventoryMove;
import dev.tenacity.module.impl.render.ClickGUIMod;
import dev.tenacity.module.settings.Setting;
import dev.tenacity.ui.clickguis.compact.impl.ModuleRect;
import dev.tenacity.ui.searchbar.SearchBar;
import dev.tenacity.ui.sidegui.SideGUI;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.misc.IOUtils;
import dev.tenacity.utils.objects.Drag;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;

public class CompactClickgui extends net.minecraft.client.gui.screen.Screen implements Utils {

    private static final Identifier MODERN_LOGO = Identifier.of("tenacity", "modernlogo.png");

    private final Animation openingAnimation = new DecelerateAnimation(250, 1);
    private final Drag drag = new Drag(40, 40);
    private final ModulePanel modulePanel = new ModulePanel();
    private float rectWidth = 400;
    private float rectHeight = 300;
    public boolean typing;
    private HashMap<Category, ArrayList<ModuleRect>> moduleRects;

    public CompactClickgui() {
        super(net.minecraft.text.Text.literal("Tenacity Compact ClickGUI"));
    }

    public void onDrag(int mouseX, int mouseY) {
        boolean focusedConfigGui = Tenacity.INSTANCE.getSideGui().isFocused();
        int fakeMouseX = focusedConfigGui ? 0 : mouseX, fakeMouseY = focusedConfigGui ? 0 : mouseY;

        drag.onDraw(fakeMouseX, fakeMouseY);
        Tenacity.INSTANCE.getSideGui().onDrag(mouseX, mouseY);
    }

    @Override
    protected void init() {
        openingAnimation.setDirection(Direction.FORWARDS);
        rectWidth = 500;
        rectHeight = 350;
        if (moduleRects != null) {
            moduleRects.forEach((cat, list) -> list.forEach(ModuleRect::initGui));
        }
        modulePanel.initGui();
        Tenacity.INSTANCE.getSideGui().initGui();
        Tenacity.INSTANCE.getSearchBar().initGui();
    }

    public void bloom() {
        float x = drag.getX(), y = drag.getY();
        if (!openingAnimation.isDone()) {
            x -= ctx().getScaledWindowWidth() + rectWidth / 2f;
            x += (ctx().getScaledWindowWidth() + rectWidth / 2f) * openingAnimation.getOutput().floatValue();
        }
        RenderUtil.drawRect(x, y, rectWidth, rectHeight, new Color(20, 20, 20).getRGB());
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int keyCode = input.key();
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (Tenacity.INSTANCE.getSearchBar().isFocused()) {
                Tenacity.INSTANCE.getSearchBar().getSearchField().setText("");
                Tenacity.INSTANCE.getSearchBar().getSearchField().setFocused(false);
                return true;
            }

            if (Tenacity.INSTANCE.getSideGui().isFocused()) {
                Tenacity.INSTANCE.getSideGui().setFocused(false);
                return true;
            }

            openingAnimation.setDirection(Direction.BACKWARDS);
        }
        modulePanel.keyTyped((char) 0, keyCode);
        Tenacity.INSTANCE.getSideGui().keyTyped((char) 0, keyCode);
        Tenacity.INSTANCE.getSearchBar().keyTyped((char) 0, keyCode);
        // Always consume: Escape runs the backwards closing animation instead of
        // the vanilla instant close (render() closes the screen once it ends).
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        char chr = (char) input.codepoint();
        modulePanel.keyTyped(chr, -1);
        Tenacity.INSTANCE.getSideGui().keyTyped(chr, -1);
        Tenacity.INSTANCE.getSearchBar().keyTyped(chr, -1);
        return true;
    }

    private Color firstColor = Color.BLACK, secondColor = Color.BLACK;

    private final List<ModuleRect> searchResults = new ArrayList<>();

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        Utils.setCtx(context);
        dev.tenacity.utils.render.PostProcessUtil.renderGuiBlur();
        // TODO: ModuleCollection.reloadModules doesn't exist in the port — rects
        // are built once when moduleRects is null.
        if (moduleRects == null) {
            moduleRects = new HashMap<>();
            for (Category category : Category.values()) {
                ArrayList<ModuleRect> modules = new ArrayList<>();
                for (Module module : Tenacity.INSTANCE.getModuleCollection().getModulesInCategory(category)) {
                    modules.add(new ModuleRect(module));
                }

                moduleRects.put(category, modules);
            }
            moduleRects.forEach((cat, list) -> list.forEach(ModuleRect::initGui));
            return;
        }

        // TODO: ported SideGUI/SearchBar expose no isTyping(); isFocused() is the
        // closest equivalent available.
        typing = modulePanel.typing || Tenacity.INSTANCE.getSideGui().isFocused()
                || Tenacity.INSTANCE.getSearchBar().isFocused();

        if (ClickGUIMod.walk.isEnabled() && !typing) {
            InventoryMove.updateStates();
        }

        boolean focusedConfigGui = Tenacity.INSTANCE.getSideGui().isFocused();
        int fakeMouseX = focusedConfigGui ? 0 : mouseX, fakeMouseY = focusedConfigGui ? 0 : mouseY;

        float x = drag.getX(), y = drag.getY();

        if (!openingAnimation.isDone()) {
            x -= ctx().getScaledWindowWidth() + rectWidth / 2f;
            x += (ctx().getScaledWindowWidth() + rectWidth / 2f) * openingAnimation.getOutput().floatValue();
        } else if (openingAnimation.getDirection().equals(Direction.BACKWARDS)) {
            close();
            return;
        }

        rectWidth = 475;
        rectHeight = 300;

        RenderUtil.drawRect(x, y, rectWidth, rectHeight, new Color(27, 27, 27).getRGB());

        RenderUtil.drawRect(x, y, 90, rectHeight, new Color(39, 39, 39).getRGB());

        // 41x41 logo drawn at ~20.5px like the original (whole texture, tinted white)
        ctx().drawTexture(RenderPipelines.GUI_TEXTURED, MODERN_LOGO, (int) (x + 5), (int) (y + 5),
                0f, 0f, 21, 21, 41, 41, 41, 41, -1);

        tenacityBoldFont22().drawString(Tenacity.NAME, x + 33, y + 7, -1);
        tenacityFont16().drawCenteredString(Tenacity.VERSION,
                (float) (x + 31 + tenacityBoldFont22().getStringWidth(Tenacity.NAME) / 2f), y + 19, -1);

        boolean searching = Tenacity.INSTANCE.getSearchBar().isFocused();

        float bannerHeight = 75 / 2f;
        RenderUtil.drawRect(x + 5, y + 31, 80, .5f, new Color(110, 110, 110).getRGB());

        RenderUtil.drawRect(x + 5, y + rectHeight - (bannerHeight + 3), 80, .5f, new Color(110, 110, 110).getRGB());

        // TODO: Discord/Intent accounts were not ported (Tenacity has no
        // getDiscordAccount()/getIntentAccount()); the discord banner/avatar block
        // from the original is omitted. bannerHeight is still reserved so the
        // left-column layout matches.

        float minus = (bannerHeight + 3) + 33;
        ClickGUIMod clickGUIMod = Tenacity.INSTANCE.getModuleCollection().getModule(ClickGUIMod.class);
        float catHeight = ((rectHeight - minus) / (Category.values().length));
        float seperation = 0;
        for (Category category : Category.values()) {
            float catY = y + 33 + seperation;
            boolean hovering = HoveringUtil.isHovering(x, catY + 8, 90, catHeight - 16, fakeMouseX, fakeMouseY);

            Color categoryColor = hovering ? ColorUtil.tripleColor(110).brighter() : ColorUtil.tripleColor(110);
            Color selectColor = (clickGUIMod.getActiveCategory() == category) ? Color.WHITE : categoryColor;

            if (!searching && (clickGUIMod.getActiveCategory() == category)) {
                RenderUtil.drawRect(x, catY, 90, catHeight, new Color(27, 27, 27).getRGB());
            }

            RenderUtil.resetColor();
            tenacityBoldFont22().drawString(category.name, x + 8, catY + tenacityFont22().getMiddleOfBox(catHeight), selectColor.getRGB());
            RenderUtil.resetColor();
            seperation += catHeight;
        }

        modulePanel.currentCat = searching ? null : clickGUIMod.getActiveCategory();
        modulePanel.moduleRects = getModuleRects(clickGUIMod.getActiveCategory());
        modulePanel.x = x;
        modulePanel.y = y;
        modulePanel.rectHeight = rectHeight;
        modulePanel.rectWidth = rectWidth;

        RenderUtil.scissorStart(x, y, rectWidth, rectHeight);
        modulePanel.drawScreen(fakeMouseX, fakeMouseY);
        RenderUtil.scissorEnd();

        modulePanel.drawTooltips(fakeMouseX, fakeMouseY);

        SideGUI sideGUI = Tenacity.INSTANCE.getSideGui();
        // TODO: ported SideGUI stub has no getOpenAnimation(); the original synced
        // it to openingAnimation's direction here.
        sideGUI.drawScreen(mouseX, mouseY);

        SearchBar searchBar = Tenacity.INSTANCE.getSearchBar();
        // TODO: ported SearchBar has no setAlpha(); the original faded it by
        // openingAnimation * (1 - sideGUI clickAnimation).
        searchBar.drawScreen(fakeMouseX, fakeMouseY);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // skip default darkened background — the GUI draws its own rects
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        int mouseX = (int) click.x();
        int mouseY = (int) click.y();
        int mouseButton = click.button();
        if (!Tenacity.INSTANCE.getSideGui().isFocused()) {
            drag.onClick(mouseX, mouseY, mouseButton, HoveringUtil.isHovering(drag.getX(), drag.getY(), rectWidth, 10, mouseX, mouseY));
            float bannerWidth = 180 / 2f;
            float bannerHeight = 75 / 2f;

            ClickGUIMod clickGUIMod = Tenacity.INSTANCE.getModuleCollection().getModule(ClickGUIMod.class);

            //If hovering the discord thing lol
            if (HoveringUtil.isHovering(drag.getX(), drag.getY() + rectHeight - bannerHeight, bannerWidth, bannerHeight, mouseX, mouseY)) {
                if (Math.random() < 0.5) {
                    IOUtils.openLink("https://www.youtube.com/channel/UC2tPaPIMGeDETMTr1FQuMSA?sub_confirmation=1");
                } else {
                    IOUtils.openLink("https://www.youtube.com/channel/UCC5eswf_s4GMyH4W-K0RUuA?sub_confirmation=1");
                }
            }

            int separation = 0;
            float minus = (bannerHeight + 3) + 33;
            float catHeight = ((rectHeight - minus) / (Category.values().length));
            for (Category category : Category.values()) {
                float catY = drag.getY() + 33 + separation;
                boolean hovering = HoveringUtil.isHovering(drag.getX(), catY + 8, 90, catHeight - 16, mouseX, mouseY);
                if (hovering) {
                    clickGUIMod.setActiveCategory(category);
                }
                separation += catHeight;
            }

            modulePanel.mouseClicked(mouseX, mouseY, mouseButton);
            Tenacity.INSTANCE.getSearchBar().mouseClicked(mouseX, mouseY, mouseButton);
        }
        Tenacity.INSTANCE.getSideGui().mouseClicked(mouseX, mouseY, mouseButton);
        return true;
    }

    @Override
    public boolean mouseReleased(Click click) {
        int mouseX = (int) click.x();
        int mouseY = (int) click.y();
        if (!Tenacity.INSTANCE.getSideGui().isFocused()) {
            drag.onRelease(click.button());
            modulePanel.mouseReleased(mouseX, mouseY, click.button());
        }
        Tenacity.INSTANCE.getSideGui().mouseReleased(mouseX, mouseY, click.button());
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double deltaX, double deltaY) {
        onDrag((int) click.x(), (int) click.y());
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        // 1.8.9's Scroll.onScroll polled Mouse.getDWheel() (~120/notch); the ported
        // Scroll takes the delta directly.
        modulePanel.onScroll((int) (verticalAmount * 120));
        return true;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        drag.onRelease(0);
        super.close();
    }

    private final List<String> searchTerms = new ArrayList<>();
    private String searchText;

    public List<ModuleRect> getModuleRects(Category category) {
        if (!Tenacity.INSTANCE.getSearchBar().isFocused()) {
            return moduleRects.get(category);
        }

        String search = Tenacity.INSTANCE.getSearchBar().getSearchField().getText();

        if (search.equals(searchText)) {
            return searchResults;
        } else {
            searchText = search;
        }

        List<ModuleRect> moduleRects1 = moduleRects.values().stream().flatMap(Collection::stream).collect(Collectors.toList());

        searchResults.clear();
        moduleRects1.forEach(moduleRect -> {
            searchTerms.clear();
            Module module = moduleRect.module;

            searchTerms.add(module.getName());
            searchTerms.add(module.getCategory().name);
            if (!module.getAuthor().isEmpty()) {
                searchTerms.add(module.getAuthor());
            }
            for (Setting setting : module.getSettingsList()) {
                searchTerms.add(setting.name);
            }

            moduleRect.setSearchScore(fuzzyScore(search, searchTerms));
        });

        searchResults.addAll(moduleRects1.stream().filter(moduleRect -> moduleRect.getSearchScore() > 60)
                .sorted(Comparator.comparingInt(ModuleRect::getSearchScore).reversed()).collect(Collectors.toList()));

        return searchResults;
    }

    /**
     * Replaces me.xdrop.fuzzywuzzy.FuzzySearch (dependency absent in the port).
     * Returns the best partial ratio (0-100) of {@code query} against each term —
     * the same scale the original >60 cut-off relied on.
     */
    private static int fuzzyScore(String query, List<String> terms) {
        int best = 0;
        String q = query.toLowerCase(Locale.ROOT);
        for (String term : terms) {
            if (term == null || term.isEmpty()) continue;
            best = Math.max(best, partialRatio(q, term.toLowerCase(Locale.ROOT)));
        }
        return best;
    }

    private static int partialRatio(String a, String b) {
        String shorter = a.length() <= b.length() ? a : b;
        String longer = shorter == a ? b : a;
        if (shorter.isEmpty() || longer.isEmpty()) return 0;
        int best = 0;
        for (int i = 0; i + shorter.length() <= longer.length(); i++) {
            best = Math.max(best, ratio(shorter, longer.substring(i, i + shorter.length())));
        }
        return best;
    }

    private static int ratio(String a, String b) {
        if (a.length() + b.length() == 0) return 100;
        return (int) ((matchingCharacters(a, b) * 200L) / (a.length() + b.length()));
    }

    private static int matchingCharacters(String a, String b) {
        // Ratcliff-Obershelp (gestalt): longest common substring, then recurse on
        // the left and right remainders.
        int len = 0, aEnd = 0, bEnd = 0;
        int[] prev = new int[b.length() + 1];
        for (int i = 1; i <= a.length(); i++) {
            int[] cur = new int[b.length() + 1];
            for (int j = 1; j <= b.length(); j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    cur[j] = prev[j - 1] + 1;
                    if (cur[j] > len) {
                        len = cur[j];
                        aEnd = i;
                        bEnd = j;
                    }
                }
            }
            prev = cur;
        }
        if (len == 0) return 0;
        int aStart = aEnd - len, bStart = bEnd - len;
        return len
                + matchingCharacters(a.substring(0, aStart), b.substring(0, bStart))
                + matchingCharacters(a.substring(aStart + len), b.substring(bStart + len));
    }
}
