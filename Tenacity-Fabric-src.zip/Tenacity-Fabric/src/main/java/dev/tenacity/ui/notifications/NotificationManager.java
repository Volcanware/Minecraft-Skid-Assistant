package dev.tenacity.ui.notifications;

import dev.tenacity.Tenacity;
import dev.tenacity.module.impl.render.NotificationsMod;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Direction;

import java.util.ArrayList;
import java.util.List;

public class NotificationManager implements Utils {

    private static final List<Notification> notifications = new ArrayList<>();

    public static void post(NotificationType type, String title, String description) {
        post(type, title, description, 4);
    }

    public static void post(NotificationType type, String title, String description, float time) {
        notifications.add(new Notification(type, title, description, time));
    }

    public void render(int mouseX, int mouseY) {
        if (!NotificationsMod.isToggled()) {
            notifications.clear();
            return;
        }
        float y = ctx().getScaledWindowHeight() - 60;
        List<Notification> toRemove = new ArrayList<>();
        for (int i = notifications.size() - 1; i >= 0; i--) {
            Notification n = notifications.get(i);
            if (n.checkTime()) {
                n.getAnimation().setDirection(Direction.BACKWARDS);
                if (n.getAnimation().finished(Direction.BACKWARDS)) {
                    toRemove.add(n);
                    continue;
                }
            }
            n.render(ctx().getScaledWindowWidth() - 10 - nWidth(n), y, mouseX, mouseY);
            y -= (n.getHeight() + 8);
        }
        notifications.removeAll(toRemove);
    }

    private float nWidth(Notification n) {
        return n.getHeight(); // width handled inside render via slide
    }
}
