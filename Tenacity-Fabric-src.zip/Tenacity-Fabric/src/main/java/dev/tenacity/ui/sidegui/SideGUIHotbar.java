package dev.tenacity.ui.sidegui;

import dev.tenacity.Tenacity;
import dev.tenacity.ui.Screen;
import dev.tenacity.ui.sidegui.utils.CarouselButtons;
import dev.tenacity.ui.sidegui.utils.DropdownObject;
import dev.tenacity.ui.sidegui.utils.IconButton;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.objects.TextField;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;

public class SideGUIHotbar implements Screen, Utils {

    public final TextField searchField = new TextField(tenacityFont20());

    // Cloud features dropped — only local configs are searchable
    public final DropdownObject searchType = new DropdownObject("Type", "Configs");

    private final CarouselButtons carouselButtons = new CarouselButtons("Configs", "Info");

    private final IconButton refreshButton = new IconButton(FontUtil.REFRESH);
    private final IconButton exit = new IconButton(FontUtil.XMARK);

    private float x, y, width, height, alpha;

    private String currentPanel;

    public SideGUIHotbar() {
        currentPanel = carouselButtons.getCurrentButton();
        exit.setTooltip("Click to exit");
        exit.setTextColor(Color.WHITE);
        exit.setClickAction(() -> Tenacity.INSTANCE.getSideGui().setFocused(false));
        refreshButton.setTooltip("Refresh local configs");
        refreshButton.setClickAction(() -> {
            Tenacity.INSTANCE.getConfigManager().collectConfigs();
            Tenacity.INSTANCE.getSideGui().getConfigPanel().queueRefresh();
        });
    }

    private final Animation searchAnimation = new DecelerateAnimation(250, 1);

    @Override
    public void initGui() {
        searchField.setText("");
        searchField.setFocused(false);
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (searchField.isFocused() || !searchField.getText().equals("")) {
            searchField.keyTyped(typedChar, keyCode);
            currentPanel = "Search";
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        boolean searching = searchField.isFocused() || !searchField.getText().equals("");

        RoundedUtil.drawRound(x + .625f, y + .625f, width - 1.25f, height - 1.25f, 5, ColorUtil.tripleColor(25, alpha));
        RenderUtil.drawRect(x, y + height - 4, width, 4, ColorUtil.tripleColor(25, alpha * alpha * alpha).getRGB());

        Color textColor = ColorUtil.applyOpacity(Color.WHITE, alpha);
        tenacityBoldFont32().drawString("Tenacity", x + 9.5f, y + tenacityBoldFont32().getMiddleOfBox(height), textColor.getRGB());
        tenacityFont18().drawString(Tenacity.VERSION, x + 9.5f + tenacityBoldFont32().getStringWidth("Tenacity") - 2,
                y + tenacityBoldFont32().getMiddleOfBox(height) - 2.5f, ColorUtil.applyOpacity(textColor, .5f).getRGB());

        searchAnimation.setDirection(searching ? Direction.FORWARDS : Direction.BACKWARDS);
        float searchAnim = searchAnimation.getOutput().floatValue();
        float carouselAlpha = alpha * (1 - searchAnim);

        //the carousel buttons in the middle of the panel
        carouselButtons.setAlpha(carouselAlpha);
        carouselButtons.setRectWidth(75);
        carouselButtons.setRectHeight(20.5f);
        carouselButtons.setX(x + width / 2f - carouselButtons.getTotalWidth() / 2f);
        carouselButtons.setY(y + height / 2f - carouselButtons.getRectHeight() / 2f);
        carouselButtons.drawScreen(mouseX, mouseY);

        if (!searching) {
            refreshButton.setAlpha(carouselAlpha);
            refreshButton.setX(carouselButtons.getX() - (refreshButton.getWidth() + 10));
            refreshButton.setY(carouselButtons.getY() + 1 + carouselButtons.getRectHeight() / 2f - refreshButton.getHeight() / 2f);
            refreshButton.setAccentColor(Color.WHITE);
            refreshButton.setIconFont(iconFont20());
            refreshButton.drawScreen(mouseX, mouseY);

            exit.setAlpha(alpha);
            exit.setX(carouselButtons.getX() + carouselButtons.getTotalWidth() + 10);
            exit.setY(carouselButtons.getY() + 1 + carouselButtons.getRectHeight() / 2f - exit.getHeight() / 2f);
            exit.setAccentColor(Color.WHITE);
            exit.setIconFont(iconFont20());
            exit.drawScreen(mouseX, mouseY);
        }

        searchField.setRadius(5);
        searchField.setFill(ColorUtil.tripleColor(17, alpha));
        searchField.setOutline(ColorUtil.applyOpacity(Color.WHITE, 0));
        searchField.setHeight(carouselButtons.getRectHeight());
        searchField.setWidth(145.5f + (200 * searchAnim));
        float searchX = x + width - (searchField.getRealWidth() + 11);
        searchField.setXPosition(MathUtils.interpolateFloat(searchX, x + width / 2f - searchField.getRealWidth() / 2f, searchAnim));
        searchField.setYPosition(y + height / 2f - (searchField.getHeight() / 2f));
        searchField.setBackgroundText("Search");
        searchField.drawTextBox();

        if (!searchAnimation.isDone() || searchAnimation.finished(Direction.FORWARDS)) {
            searchType.setWidth(75);
            searchType.setHeight(carouselButtons.getRectHeight() - 5.5f);
            searchType.setX(x + width - (searchType.getWidth() + 11));
            searchType.setY(searchField.getYPosition() + searchField.getHeight() + 5);
            searchType.setAlpha(alpha * searchAnim);
            searchType.setAccentColor(ColorUtil.applyOpacity(
                    dev.tenacity.module.impl.render.HUDMod.getClientColors().getFirst(), alpha));
            searchType.drawScreen(mouseX, mouseY);
        }

        if (!searching) {
            currentPanel = carouselButtons.getCurrentButton();
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (SideGUI.isHovering(searchField.getXPosition(), searchField.getYPosition(),
                searchField.getRealWidth(), searchField.getHeight(), mouseX, mouseY)) {
            searchField.setFocused(true);
        } else {
            searchField.setFocused(false);
        }
        searchField.mouseClicked(mouseX, mouseY, button);
        searchType.mouseClicked(mouseX, mouseY, button);
        refreshButton.mouseClicked(mouseX, mouseY, button);
        exit.mouseClicked(mouseX, mouseY, button);
        carouselButtons.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {

    }

    public String getCurrentPanel() { return currentPanel; }
    public void setCurrentPanel(String panel) { this.currentPanel = panel; }
    public CarouselButtons getCarouselButtons() { return carouselButtons; }
    public float getX() { return x; }
    public void setX(float x) { this.x = x; }
    public float getY() { return y; }
    public void setY(float y) { this.y = y; }
    public float getWidth() { return width; }
    public void setWidth(float width) { this.width = width; }
    public float getHeight() { return height; }
    public void setHeight(float height) { this.height = height; }
    public float getAlpha() { return alpha; }
    public void setAlpha(float alpha) { this.alpha = alpha; }
}
