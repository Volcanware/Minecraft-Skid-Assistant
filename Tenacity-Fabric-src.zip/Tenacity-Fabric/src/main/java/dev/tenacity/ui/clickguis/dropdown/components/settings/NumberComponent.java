package dev.tenacity.ui.clickguis.dropdown.components.settings;

import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.ui.clickguis.dropdown.components.SettingComponent;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;

public class NumberComponent extends SettingComponent<NumberSetting> {

    private boolean dragging;

    public NumberComponent(NumberSetting setting) {
        super(setting);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        NumberSetting setting = getSetting();
        if (dragging) {
            float percent = Math.min(1, Math.max(0, (mouseX - (x + 8)) / (width - 16)));
            setting.setValue(setting.getMin() + (setting.getMax() - setting.getMin()) * percent);
        }

        tenacityFont16().drawString(setting.getName() + ": " + setting.getValue(), x + 8, y + 4,
                ColorUtil.applyOpacity(new Color(190, 190, 190), alpha).getRGB());

        float barX = x + 8, barY = y + 10, barWidth = width - 16;
        RoundedUtil.drawRound(barX, barY, barWidth, 2.5f, 1.25f,
                ColorUtil.applyOpacity(new Color(60, 60, 60), alpha));
        double percent = (setting.getValue() - setting.getMin()) / (setting.getMax() - setting.getMin());
        RoundedUtil.drawRound(barX, barY, (float) (barWidth * percent), 2.5f, 1.25f,
                ColorUtil.applyOpacity(clientColors.getFirst(), alpha));
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (HoveringUtil.isHovering(x + 8, y + 8, width - 16, 6, mouseX, mouseY) && button == 0
                && isClickable(y + height)) {
            dragging = true;
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int button) {
        dragging = false;
    }
}
