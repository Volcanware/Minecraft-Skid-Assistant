package dev.tenacity.ui.clickguis.compact.impl;

import dev.tenacity.Tenacity;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.module.settings.impl.KeybindSetting;
import dev.tenacity.ui.Screen;
import dev.tenacity.ui.sidegui.utils.TooltipObject;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.time.TimerUtil;
import dev.tenacity.utils.tuples.Pair;
import org.lwjgl.glfw.GLFW;

import java.awt.*;

public class ModuleRect implements Screen, Utils {

    private int searchScore;
    public final Module module;
    private final Animation enableAnimation = new DecelerateAnimation(150, 1);
    private final SettingComponents settingComponents;
    public float x, y, width, height;
    public float rectHeight;
    public float rectWidth;
    public Module binding;
    public boolean typing;
    public final TooltipObject tooltipObject = new TooltipObject();
    private final TimerUtil timerUtil = new TimerUtil();

    public ModuleRect(Module module) {
        this.module = module;
        settingComponents = new SettingComponents(module);
    }

    public int getSearchScore() { return searchScore; }
    public void setSearchScore(int searchScore) { this.searchScore = searchScore; }

    @Override
    public void initGui() {
        settingComponents.initGui();
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (binding != null) {
            if (keyCode == GLFW.GLFW_KEY_SPACE || keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE)
                binding.getKeybind().setCode(GLFW.GLFW_KEY_UNKNOWN);
            else if (keyCode >= 0)
                binding.getKeybind().setCode(keyCode);
            binding = null;
        } else {
            settingComponents.keyTyped(typedChar, keyCode);
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        typing = false;
        RenderUtil.drawRect(x, y, rectWidth, 20, new Color(39, 39, 39).getRGB());

        HUDMod hudMod = Tenacity.INSTANCE.getModuleCollection().getModule(HUDMod.class);
        Pair<Color, Color> colors = HUDMod.getClientColors();
        Color actualColor = colors.getFirst();

        if (binding != null && !typing) {
            typing = true;
        }

        tenacityBoldFont20().drawString(module.getName(), x + 5, y + tenacityBoldFont20().getMiddleOfBox(20), -1);

        KeybindSetting keybindSetting = module.getKeybind();

        String keyName = keyName(keybindSetting.getCode());
        float bindWidth = (float) (tenacityFont14().getStringWidth(keyName) + 4);

        boolean hovered = HoveringUtil.isHovering((float) (x + tenacityFont20().getStringWidth(module.getName()) + 13), y + 6, bindWidth, 8, mouseX, mouseY);
        boolean hoveringModule = HoveringUtil.isHovering(x, y, width, 20, mouseX, mouseY);

        if (!hoveringModule) {
            timerUtil.reset();
        }

        tooltipObject.setTip(module.getDescription());
        // TODO: ported TooltipObject has no setRound(); the original disabled rounding here.
        tooltipObject.setHovering(timerUtil.hasTimeElapsed(900));

        Color bindRect = new Color(64, 68, 75);
        RenderUtil.drawRect(x + tenacityFont20().getStringWidth(module.getName()) + 13, y + 6,
                tenacityFont14().getStringWidth(keyName) + 4, 8,
                hovered ? bindRect.brighter().getRGB() : bindRect.getRGB());

        tenacityFont14().drawCenteredString(keyName, (float) (x + tenacityFont20().getStringWidth(module.getName()) + 13 + bindWidth / 2f),
                y + 8, -1);

        RenderUtil.drawRect(x, y + 20, rectWidth, rectHeight, new Color(35, 35, 35).getRGB());

        enableAnimation.setDirection(module.isEnabled() ? Direction.FORWARDS : Direction.BACKWARDS);

        float o = (float) enableAnimation.getOutput().floatValue();

        RenderUtil.drawGoodCircle(x + rectWidth - 10, y + 10, 4, ColorUtil.interpolateColor(new Color(64, 68, 75), actualColor, o));

        if (o > 0.01f) {
            ctx().getMatrices().pushMatrix();
            ctx().getMatrices().translate(3.5f, 2f);
            ctx().getMatrices().scale(o, o);
            ctx().getMatrices().translate(-3.5f, -2f);
            iconFont16().drawString(FontUtil.CHECKMARK, (x + rectWidth - 13.5f) / o, (y + 8) / o,
                    ColorUtil.interpolateColor(new Color(45, 45, 45), Color.WHITE, o));
            ctx().getMatrices().popMatrix();
        }

        settingComponents.x = x;
        settingComponents.y = y + 20;
        settingComponents.actualColor = actualColor;
        settingComponents.rectWidth = rectWidth;
        settingComponents.drawScreen(mouseX, mouseY);

        if (!typing) {
            typing = settingComponents.typing;
        }

        rectHeight = settingComponents.size > 0 ? settingComponents.size : 0;
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        String keyName = keyName(module.getKeybind().getCode());
        float bindWidth = tenacityFont14().getStringWidth(keyName) + 4;
        boolean hovered = HoveringUtil.isHovering(x + tenacityFont20().getStringWidth(module.getName()) + 13, y + 6, bindWidth, 8, mouseX, mouseY);
        if (!hovered && HoveringUtil.isHovering(x, y, rectWidth, 20, mouseX, mouseY)) {
            if (button == 0) {
                module.toggleSilent();
            }
        } else if (hovered) {
            binding = module;
            return;
        }
        settingComponents.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        settingComponents.mouseReleased(mouseX, mouseY, state);
    }

    private static String keyName(int code) {
        if (code == GLFW.GLFW_KEY_UNKNOWN || code < 0) return "None";
        String name = GLFW.glfwGetKeyName(code, 0);
        return name == null ? "None" : name.toUpperCase();
    }
}
