package dev.tenacity.ui.clickguis.dropdown.components;

import dev.tenacity.module.Module;
import dev.tenacity.module.settings.Setting;
import dev.tenacity.module.settings.impl.*;
import dev.tenacity.ui.Screen;
import dev.tenacity.ui.clickguis.dropdown.components.settings.*;
import dev.tenacity.ui.sidegui.utils.TooltipObject;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.animations.impl.EaseInOutQuad;
import dev.tenacity.utils.animations.impl.EaseOutSine;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.render.Theme;
import dev.tenacity.utils.tuples.Pair;
import dev.tenacity.utils.time.TimerUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ModuleRect implements Screen, Utils {

    public final Module module;
    private int searchScore;
    private final Animation toggleAnimation = new EaseInOutQuad(300, 1);
    private final Animation hoverAnimation = new EaseOutSine(400, 1, Direction.BACKWARDS);
    private final Animation hoverKeybindAnimation = new DecelerateAnimation(200, 1, Direction.BACKWARDS);
    private final Animation settingAnimation = new DecelerateAnimation(250, 1).setDirection(Direction.BACKWARDS);
    public final TooltipObject tooltipObject = new TooltipObject();
    private final TimerUtil timerUtil = new TimerUtil();

    private boolean typing;
    public float x, y, width, height, panelLimitY, alpha;

    private double settingSize = 1;
    private final List<SettingComponent> settingComponents;

    public ModuleRect(Module module) {
        this.module = module;
        settingComponents = new ArrayList<>();
        for (Setting setting : module.getSettingsList()) {
            if (setting instanceof KeybindSetting) {
                settingComponents.add(new KeybindComponent((KeybindSetting) setting));
            }
            if (setting instanceof BooleanSetting) {
                settingComponents.add(new BooleanComponent((BooleanSetting) setting));
            }
            if (setting instanceof ModeSetting) {
                settingComponents.add(new ModeComponent((ModeSetting) setting));
            }
            if (setting instanceof NumberSetting) {
                settingComponents.add(new NumberComponent((NumberSetting) setting));
            }
            if (setting instanceof MultipleBoolSetting) {
                settingComponents.add(new MultipleBoolComponent((MultipleBoolSetting) setting));
            }
            if (setting instanceof StringSetting) {
                settingComponents.add(new StringComponent((StringSetting) setting));
            }
            if (setting instanceof ColorSetting) {
                settingComponents.add(new ColorComponent((ColorSetting) setting));
            }
        }
    }

    public double getSettingSize() { return settingSize; }
    public boolean isTyping() { return typing; }

    @Override
    public void initGui() {
        settingAnimation.setDirection(Direction.BACKWARDS);
        toggleAnimation.setDirection(Direction.BACKWARDS);
        if (settingComponents != null) {
            settingComponents.forEach(SettingComponent::initGui);
        }
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (module.isExpanded()) {
            for (SettingComponent settingComponent : settingComponents) {
                if (settingComponent.getSetting().cannotBeShown()) continue;
                settingComponent.keyTyped(typedChar, keyCode);
            }
        }
    }

    private double actualSettingCount;

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        toggleAnimation.setDirection(module.isEnabled() ? Direction.FORWARDS : Direction.BACKWARDS);
        settingAnimation.setDirection(module.isExpanded() ? Direction.FORWARDS : Direction.BACKWARDS);

        boolean hoveringModule = HoveringUtil.isHovering(x, y, width, height, mouseX, mouseY);
        hoverAnimation.setDirection(hoveringModule ? Direction.FORWARDS : Direction.BACKWARDS);
        hoverAnimation.setDuration(hoveringModule ? 250 : 400);

        boolean hoveringText = HoveringUtil.isHovering(x, y, width, height, mouseX, mouseY);

        tooltipObject.setTip(module.getDescription());
        tooltipObject.setHovering(hoveringText);

        Theme theme = Theme.getCurrentTheme();
        Pair<Color, Color> colors = theme.getColors().apply((color1, color2) ->
                Pair.of(ColorUtil.applyOpacity(color1, alpha), ColorUtil.applyOpacity(color2, alpha)));

        // module row background — tinted by enable animation
        float toggleOut = toggleAnimation.getOutput().floatValue();
        Color rectColor = ColorUtil.interpolateColorC(theme.getModuleRectColor(),
                colors.getFirst(), toggleOut);
        RoundedUtil.drawRound(x, y, width, height, 4,
                ColorUtil.applyOpacity(rectColor, alpha * (0.4f + 0.4f * toggleOut)));

        // enabled indicator bar
        if (toggleOut > 0.03f) {
            RoundedUtil.drawRound(x, y + 2, 2.5f, height - 4, 1.5f,
                    ColorUtil.applyOpacity(colors.getFirst(), alpha * toggleOut));
        }

        Color nameColor = ColorUtil.interpolateColorC(
                new Color(160, 160, 160), Color.WHITE, toggleOut);
        tenacityFont18().drawCenteredString(module.getDisplayName(), x + width / 2f,
                y + tenacityFont18().getMiddleOfBox(height),
                ColorUtil.applyOpacity(nameColor, alpha).getRGB());

        // settings expand arrow
        if (!settingComponents.isEmpty()) {
            RenderUtil.drawClickGuiArrow(x + width - 10, y + height / 2f - 1, 5, settingAnimation,
                    ColorUtil.applyOpacity(new Color(150, 150, 150), alpha).getRGB());
        }

        // expanded settings — clipped to the animated open height like the
        // original, otherwise every module would paint its settings over the
        // rows below even while collapsed
        if (!settingComponents.isEmpty()) {
            float out = settingAnimation.getOutput().floatValue();
            actualSettingCount = 0;
            for (SettingComponent component : settingComponents) {
                if (component.getSetting().cannotBeShown()) continue;
                actualSettingCount += component.countSize;
            }
            if (out > 0.01f) {
                float settingY = y + height + 1;
                float clipHeight = (float) (actualSettingCount * 16 * out);
                RenderUtil.scissorStart(x, y + height, x + width, y + height + clipHeight);
                for (SettingComponent component : settingComponents) {
                    if (component.getSetting().cannotBeShown()) continue;
                    component.x = x;
                    component.y = settingY;
                    component.width = width;
                    component.height = 16;
                    component.alpha = alpha;
                    component.panelLimitY = panelLimitY;
                    component.clientColors = colors;
                    component.drawScreen(mouseX, mouseY);
                    settingY += component.countSize * 16;
                }
                RenderUtil.scissorEnd();
            }
            settingSize = actualSettingCount * out;
        } else {
            settingSize = 0;
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        boolean hoveringModule = HoveringUtil.isHovering(x, y, width, height, mouseX, mouseY);
        if (hoveringModule) {
            if (button == 0) {
                module.toggle();
            } else if (button == 1) {
                module.setExpanded(!module.isExpanded());
            }
        }
        if (module.isExpanded() && settingAnimation.getOutput().floatValue() > 0.5f) {
            for (SettingComponent component : settingComponents) {
                if (component.getSetting().cannotBeShown()) continue;
                component.mouseClicked(mouseX, mouseY, button);
            }
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int button) {
        for (SettingComponent component : settingComponents) {
            component.mouseReleased(mouseX, mouseY, button);
        }
    }
}
