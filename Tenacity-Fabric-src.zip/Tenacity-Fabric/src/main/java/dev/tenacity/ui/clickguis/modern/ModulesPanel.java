package dev.tenacity.ui.clickguis.modern;

import dev.tenacity.Tenacity;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.ModuleCollection;
import dev.tenacity.module.impl.render.ClickGUIMod;
import dev.tenacity.ui.clickguis.modern.components.ModuleRect;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.objects.Scroll;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;
import java.util.HashMap;
import java.util.List;

public class ModulesPanel extends Panel {

    public List<ModuleRect> modules;
    public Animation expandAnim;
    public Animation expandAnim2;
    Scroll settingScroll = new Scroll();
    private HashMap<Module, SettingsPanel> settingsPanelHashMap;
    private HashMap<Category, Scroll> scrollHashMap;
    private boolean rightClicked = false;
    public Category currentCategory;
    private boolean typing = false;
    private ModuleRect currentlySelected;

    public boolean isTyping() {
        return typing;
    }

    @Override
    public void initGui() {
        expandAnim2 = new DecelerateAnimation(300, 1, Direction.FORWARDS);
        expandAnim2.setDirection(Direction.BACKWARDS);
        if (scrollHashMap == null) {
            scrollHashMap = new HashMap<>();
            for (Category category : Category.values()) {
                scrollHashMap.put(category, new Scroll());
            }
            //this is so damn aids but it just might work
            scrollHashMap.put(null, new Scroll());
        }

        refreshSettingMap();

    }

    public void refreshSettingMap() {
        if (settingsPanelHashMap == null || ModuleCollection.reloadModules) {
            settingsPanelHashMap = new HashMap<>();
            for (Module module : Tenacity.INSTANCE.getModuleCollection().getModules()) {
                SettingsPanel settingsPanel = new SettingsPanel(module);
                settingsPanel.initGui();
                settingsPanelHashMap.put(module, settingsPanel);
            }
        } else {
            settingsPanelHashMap.forEach((m, p) -> p.initGui());
        }
    }


    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (modules != null) {
            modules.forEach(moduleRect -> moduleRect.keyTyped(typedChar, keyCode));
        }

        if (currentlySelected != null) {
            settingsPanelHashMap.get(currentlySelected.module).keyTyped(typedChar, keyCode);
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        typing = false;
        if (ModuleCollection.reloadModules) {
            initGui();
            ModuleCollection.reloadModules = false;
            return;
        }

        if (modules == null) return;

        expandAnim2.setDirection(rightClicked ? Direction.FORWARDS : Direction.BACKWARDS);
        int spacing = 0;
        Scroll scroll = scrollHashMap.get(currentCategory);

        double scrollVal = MathUtils.roundToHalf(scroll.getScroll());

        tenacityFont18().drawCenteredString("Click your scroll wheel while hovering a module to change a keybind", x + 305 / 2f, (float) (y - 15 + scrollVal),
                new Color(128, 134, 141, 150));


        scroll.setMaxScroll(Math.max(0, (modules.size() - 4) * 50));
        for (ModuleRect module : modules) {
            module.rectWidth = (float) (305);
            module.x = this.x;
            module.y = (float) (this.y + spacing + scrollVal);
            module.bigRecty = this.bigRecty;

            if (!typing) {
                typing = module.binding != null;
            }

            module.drawSettingThing = currentlySelected == module;

            module.drawScreen(mouseX, mouseY);
            spacing += 50;


            if (module.rightClicked) {
                if (currentlySelected == module) {
                    rightClicked = false;
                    currentlySelected = null;
                    module.rightClicked = false;
                    continue;
                } else {
                    rightClicked = true;
                }
                settingScroll = new Scroll();
                currentlySelected = module;
                module.rightClicked = false;
            }
        }


        if (currentlySelected != null) {
            //  settingScroll.setMaxScroll(Math.max(0,(Mo - 4) * 50));
            float newX = x + 5 + (float) (305);
            RoundedUtil.drawRound(newX, y - 20, 130, 255, 8, new Color(47, 49, 54));
            RenderUtil.setAlphaLimit(0);
            RenderUtil.drawGradientRect(newX - .5f, y, newX - .5f + 130.5f, y + 8, new Color(0, 0, 0, 70).getRGB(), new Color(0, 0, 0, 0).getRGB());
            tenacityBoldFont22().drawCenteredString(currentlySelected.module.getName(), newX + 125 / 2f, y - 15, -1);

            RenderUtil.scissorStart(newX, y + .5f, 135, 255);

            SettingsPanel settingsPanel = settingsPanelHashMap.get(currentlySelected.module);
            settingScroll.setMaxScroll(Math.max(0, settingsPanel.maxScroll - 100));
            settingsPanel.x = x + 305;
            settingsPanel.y = (float) (y - 20 + MathUtils.roundToHalf(settingScroll.getScroll()));
            settingsPanel.drawScreen(mouseX, mouseY);

            if (!typing) {
                typing = settingsPanel.typing;
            }

            RenderUtil.scissorEnd();
        }

        ClickGUIMod.modernClickGui.adjustWidth((125 * expandAnim2.getOutput().floatValue()));
    }

    @Override
    public void mouseScrolled(int mouseX, int mouseY, double verticalAmount) {
        int wheel = (int) (verticalAmount * 30);
        float expandOut = expandAnim != null ? expandAnim.getOutput().floatValue() : 0;
        // category module list scrolls unless the pointer is over the open settings panel
        if (!(HoveringUtil.isHovering(x + (250 + (55 * expandOut)), y, 135, 250, mouseX, mouseY) && currentlySelected != null) &&
                !Tenacity.INSTANCE.getSideGui().isFocused()) {
            scrollHashMap.get(currentCategory).onScroll(25, wheel);
        }
        if (currentlySelected != null && HoveringUtil.isHovering(x + (float) (305), y, 135, 250, mouseX, mouseY)) {
            settingScroll.onScroll(25, wheel);
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (modules != null) {
            modules.forEach(moduleRect -> moduleRect.mouseClicked(mouseX, mouseY, button));
        }
        if (currentlySelected != null) {
            settingsPanelHashMap.get(currentlySelected.module).mouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        if (modules != null) {
            modules.forEach(moduleRect -> moduleRect.mouseReleased(mouseX, mouseY, state));
        }
        if (currentlySelected != null) {
            settingsPanelHashMap.get(currentlySelected.module).mouseReleased(mouseX, mouseY, state);
        }
    }
}
