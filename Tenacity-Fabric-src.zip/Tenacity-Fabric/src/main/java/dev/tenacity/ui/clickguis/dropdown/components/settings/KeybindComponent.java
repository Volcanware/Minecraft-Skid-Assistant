package dev.tenacity.ui.clickguis.dropdown.components.settings;

import dev.tenacity.module.settings.impl.KeybindSetting;
import dev.tenacity.ui.clickguis.dropdown.components.SettingComponent;
import dev.tenacity.utils.render.ColorUtil;
import org.lwjgl.glfw.GLFW;

import java.awt.*;

public class KeybindComponent extends SettingComponent<KeybindSetting> {

    private boolean binding;

    public KeybindComponent(KeybindSetting setting) {
        super(setting);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        KeybindSetting setting = getSetting();
        String keyName = binding ? "..." : (setting.getCode() == GLFW.GLFW_KEY_UNKNOWN ? "None"
                : GLFW.glfwGetKeyName(setting.getCode(), 0));
        tenacityFont16().drawString("Bind: " + keyName, x + 8, y + 4,
                ColorUtil.applyOpacity(new Color(190, 190, 190), alpha).getRGB());
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (binding) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) {
                getSetting().setCode(GLFW.GLFW_KEY_UNKNOWN);
            } else if (keyCode > 0) {
                getSetting().setCode(keyCode);
            }
            binding = false;
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (isHoveringBox(mouseX, mouseY) && isClickable(y + height)) {
            if (button == 0) {
                binding = true;
            } else if (button == 2) {
                getSetting().setCode(GLFW.GLFW_KEY_UNKNOWN);
            }
        }
    }
}
