package dev.tenacity.ui.sidegui.panels.searchpanel;

import dev.tenacity.Tenacity;
import dev.tenacity.config.Config;
import dev.tenacity.ui.sidegui.panels.Panel;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.objects.Scroll;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SearchPanel extends Panel {

    private final Scroll scroll = new Scroll();
    private List<Config> filtered = new ArrayList<>();

    @Override
    public void initGui() {
        Tenacity.INSTANCE.getConfigManager().collectConfigs();
        filtered = new ArrayList<>(Tenacity.INSTANCE.getConfigManager().getConfigs());
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {

    }

    public void updateSearch(String query) {
        List<Config> configs = Tenacity.INSTANCE.getConfigManager().getConfigs();
        if (query == null || query.trim().isEmpty()) {
            filtered = new ArrayList<>(configs);
        } else {
            String q = query.trim().toLowerCase();
            filtered = configs.stream()
                    .filter(c -> c.getName().toLowerCase().contains(q))
                    .collect(Collectors.toList());
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        tenacityBoldFont40().drawString("Search", getX() + 8, getY() + 8, getTextColor());
        tenacityFont18().drawString("Type in the search bar to filter configs",
                getX() + 8, getY() + 30, ColorUtil.applyOpacity(getTextColor(), .3f));

        float spacing = 8;
        float listY = getY() + 40 + spacing;
        float listHeight = getHeight() - (40 + spacing * 2);

        if (HoveringUtil.isHovering(getX(), listY, getWidth(), listHeight, mouseX, mouseY)) {
            scroll.onScroll(35, dev.tenacity.ui.sidegui.SideGUI.scrollDelta);
        }

        RenderUtil.scissorStart(getX() - 1, listY - 1, getWidth() + 2, listHeight + 2);

        float cardHeight = 30;
        float cardSpacing = 5;
        int count = 0;
        for (Config config : filtered) {
            float cardX = getX() + 5;
            float cardY = (float) (listY + 4 + (count * (cardHeight + cardSpacing)) + MathUtils.roundToHalf(scroll.getScroll()));
            float cardWidth = getWidth() - 10;

            RoundedUtil.drawRound(cardX, cardY, cardWidth, cardHeight, 5, ColorUtil.tripleColor(27, getAlpha()));
            tenacityBoldFont18().drawString(config.getName(), cardX + 8,
                    cardY + tenacityBoldFont18().getMiddleOfBox(cardHeight), getTextColor());
            iconFont16().drawString(FontUtil.LOAD, cardX + cardWidth - 14,
                    cardY + iconFont16().getMiddleOfBox(cardHeight), ColorUtil.applyOpacity(getAccentColor(), getAlpha()).getRGB());
            count++;
        }

        float hiddenHeight = (count * (cardHeight + cardSpacing)) - (listHeight - 8);
        scroll.setMaxScroll(Math.max(0, hiddenHeight));

        RenderUtil.scissorEnd();

        if (filtered.isEmpty()) {
            tenacityFont18().drawCenteredString("No matching configs",
                    getX() + getWidth() / 2f, listY + listHeight / 2f,
                    ColorUtil.applyOpacity(getTextColor(), .4f));
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        float spacing = 8;
        float listY = getY() + 40 + spacing;
        float cardHeight = 30;
        float cardSpacing = 5;
        int count = 0;
        for (Config config : filtered) {
            float cardX = getX() + 5;
            float cardY = (float) (listY + 4 + (count * (cardHeight + cardSpacing)) + MathUtils.roundToHalf(scroll.getScroll()));
            float cardWidth = getWidth() - 10;
            if (button == 0 && HoveringUtil.isHovering(cardX, cardY, cardWidth, cardHeight, mouseX, mouseY)) {
                Tenacity.INSTANCE.getConfigManager().loadConfig(config);
            }
            count++;
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {

    }
}
