package dev.tenacity.ui.clickguis.dropdown.components.settings;

import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.ui.clickguis.dropdown.components.SettingComponent;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;

public class ModeComponent extends SettingComponent<ModeSetting> {

    private boolean expanded;
    private final Animation expandAnimation = new DecelerateAnimation(200, 1, Direction.BACKWARDS);

    public ModeComponent(ModeSetting setting) {
        super(setting);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        ModeSetting setting = getSetting();
        expandAnimation.setDirection(expanded ? Direction.FORWARDS : Direction.BACKWARDS);
        float out = expandAnimation.getOutput().floatValue();

        tenacityFont16().drawString(setting.getName() + ": " + setting.getMode(), x + 8, y + 4,
                ColorUtil.applyOpacity(new Color(190, 190, 190), alpha).getRGB());

        if (out > 0.01f) {
            float optionY = y + 13;
            for (String mode : setting.modes) {
                boolean selected = mode.equals(setting.getMode());
                tenacityFont14().drawString(mode, x + 12, optionY,
                        ColorUtil.applyOpacity(selected ? clientColors.getFirst() : new Color(140, 140, 140),
                                alpha * out).getRGB());
                optionY += 11;
            }
        }
        countSize = 1 + (setting.modes.size() * 11f / 15f) * out;
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        ModeSetting setting = getSetting();
        if (isHoveringBox(mouseX, mouseY) && mouseY < y + 14 && button == 0 && isClickable(y + height)) {
            expanded = !expanded;
        }
        if (expanded) {
            float optionY = y + 13;
            for (String mode : setting.modes) {
                if (mouseX >= x + 10 && mouseX <= x + width - 4 && mouseY >= optionY && mouseY <= optionY + 11) {
                    setting.setCurrentMode(mode);
                    expanded = false;
                    break;
                }
                optionY += 11;
            }
        }
    }
}
