package dev.tenacity.ui.mainmenu;

import dev.tenacity.Tenacity;
import dev.tenacity.ui.Screen;
import dev.tenacity.ui.mainmenu.particles.ParticleEngine;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.misc.IOUtils;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class CustomMainMenu extends net.minecraft.client.gui.screen.Screen implements Utils {
    private ParticleEngine particleEngine;

    public static boolean animatedOpen = false;

    private final List<MenuButton> buttons = new ArrayList<>() {{
        add(new MenuButton("Singleplayer"));
        add(new MenuButton("Multiplayer"));
        add(new MenuButton("Alt Manager"));
        add(new MenuButton("Settings"));
        add(new MenuButton("Exit"));
    }};

    private final List<TextButton> textButtons = new ArrayList<>() {{
        add(new TextButton("Scripting"));
        add(new TextButton("Discord"));
    }};

    private final Identifier backgroundResource = Identifier.of("tenacity", "mainmenu/funny.png");
    private final Identifier blurredRect = Identifier.of("tenacity", "mainmenu/rect-test.png");

    public CustomMainMenu() {
        super(Text.literal("Tenacity"));
    }

    @Override
    protected void init() {
        if (particleEngine == null) particleEngine = new ParticleEngine();
        if (mc.options.getGuiScale().getValue() != 2) {
            Tenacity.prevGuiScale = mc.options.getGuiScale().getValue();
            Tenacity.updateGuiScale = true;
            mc.options.getGuiScale().setValue(2);
            mc.onResolutionChanged();
        }
        buttons.forEach(MenuButton::initGui);
        textButtons.forEach(TextButton::initGui);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Utils.setCtx(ctx);
        this.width = mc.getWindow().getScaledWidth();
        this.height = mc.getWindow().getScaledHeight();

        RenderUtil.drawImage(backgroundResource, 0, 0, width, height);

        particleEngine.render();

        float rectWidth = 277;
        float rectHeight = 275.5f;

        // Frosted menu panel: blur the frame behind the UI (1.21.11 post-effect path).
        dev.tenacity.utils.render.PostProcessUtil.renderBlur();
        RoundedUtil.drawRound(width / 2f - rectWidth / 2f, height / 2f - rectHeight / 2f,
                rectWidth, rectHeight, 10, ColorUtil.applyOpacity(Color.BLACK.getRGB(), .45f));

        float outlineImgWidth = 688 / 2f;
        float outlineImgHeight = 681 / 2f;
        RenderUtil.drawImage(blurredRect, width / 2f - outlineImgWidth / 2f, height / 2f - outlineImgHeight / 2f,
                outlineImgWidth, outlineImgHeight, -1);


        // The original drew a cursor-following circle stencil-clipped to the button outlines.
        // Scissor to the button column gives the same visible result without stencil state.
        float buttonWidth = 140;
        float buttonHeight = 25;
        float columnTop = (height / 2f - buttonHeight / 2f) - 25;
        float columnHeight = buttons.size() * (buttonHeight + 5);
        RenderUtil.scissorStart(width / 2f - buttonWidth / 2f, columnTop, buttonWidth, columnHeight);
        float circleW = 174 / 2f;
        float circleH = 140 / 2f;
        Identifier rs = Identifier.of("tenacity", "mainmenu/circle-funny.png");
        RenderUtil.drawImage(rs, mouseX - circleW / 2f, mouseY - circleH / 2f, circleW, circleH);
        RenderUtil.scissorEnd();


        int count = 0;
        for (MenuButton button : buttons) {
            button.x = width / 2f - buttonWidth / 2f;
            button.y = columnTop + count;
            button.width = buttonWidth;
            button.height = buttonHeight;
            button.clickAction = () -> {
                switch (button.text) {
                    case "Singleplayer":
                        mc.setScreen(new SelectWorldScreen(this));
                        break;
                    case "Multiplayer":
                        mc.setScreen(new MultiplayerScreen(this));
                        break;
                    case "Alt Manager":
                        // Alt manager is out of scope for the port — send to multiplayer instead.
                        mc.setScreen(new MultiplayerScreen(this));
                        break;
                    case "Settings":
                        mc.setScreen(new OptionsScreen(this, mc.options));
                        break;
                    case "Exit":
                        mc.scheduleStop();
                        break;
                }
            };
            button.drawScreen(mouseX, mouseY);
            count += buttonHeight + 5;
        }


        float buttonCount = 0;
        float buttonsWidth = (float) textButtons.stream().mapToDouble(TextButton::getWidth).sum();
        int buttonsSize = textButtons.size();
        buttonsWidth += tenacityFont16().getStringWidth(" | ") * (buttonsSize - 1);

        int buttonIncrement = 0;
        for (TextButton button : textButtons) {
            button.x = width / 2f - buttonsWidth / 2f + buttonCount;
            button.y = (height / 2f) + 120;
            switch (button.text) {
                case "Scripting":
                    button.clickAction = () -> IOUtils.openLink("https://scripting.tenacity.dev");
                    break;
                case "Discord":
                    button.clickAction = () -> IOUtils.openLink("https://tenacity.dev/discord");
                    break;
            }

            button.addToEnd = (buttonIncrement != (buttonsSize - 1));

            button.drawScreen(mouseX, mouseY);


            buttonCount += button.getWidth() + tenacityFont14().getStringWidth(" | ");
            buttonIncrement++;
        }

        tenacityBoldFont80().drawCenteredString("Tenacity", width / 2f, height / 2f - 110, Color.WHITE.getRGB());
        tenacityFont32().drawString(Tenacity.VERSION, width / 2f + tenacityBoldFont80().getStringWidth("Tenacity") / 2f - (tenacityFont32().getStringWidth(Tenacity.VERSION) / 2f), height / 2f - 113, Color.WHITE.getRGB());
        tenacityFont18().drawCenteredString("by cedo, senoe, and tear", width / 2f, height / 2f - 68, Color.WHITE.getRGB());

    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        int mouseX = (int) click.x();
        int mouseY = (int) click.y();
        int button = click.button();
        buttons.forEach(b -> b.mouseClicked(mouseX, mouseY, button));
        textButtons.forEach(b -> b.mouseClicked(mouseX, mouseY, button));
        return super.mouseClicked(click, doubled);
    }

    @Override
    public void close() {
        if (Tenacity.updateGuiScale) {
            mc.options.getGuiScale().setValue(Tenacity.prevGuiScale);
            Tenacity.updateGuiScale = false;
        }
        super.close();
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static class TextButton implements Screen, Utils {
        public float x, y;
        private final float width, height;

        public float getWidth() { return width; }
        public float getHeight() { return height; }
        public Runnable clickAction;
        private final String text;

        private final Animation hoverAnimation = new DecelerateAnimation(150, 1);

        public boolean addToEnd;

        public TextButton(String text) {
            this.text = text;
            width = tenacityFont16().getStringWidth(text);
            height = tenacityFont16().getHeight();
        }

        @Override
        public void initGui() {

        }

        @Override
        public void keyTyped(char typedChar, int keyCode) {

        }

        @Override
        public void drawScreen(int mouseX, int mouseY) {
            boolean hovered = HoveringUtil.isHovering(x, y, width, height, mouseX, mouseY);
            hoverAnimation.setDirection(hovered ? Direction.FORWARDS : Direction.BACKWARDS);
            tenacityFont16().drawString(text, x, y - (height / 2f * hoverAnimation.getOutput().floatValue()), Color.WHITE.getRGB());
            if (addToEnd) {
                tenacityFont16().drawString(" | ", x + width, y, Color.WHITE.getRGB());
            }
        }

        @Override
        public void mouseClicked(int mouseX, int mouseY, int button) {
            boolean hovered = HoveringUtil.isHovering(x, y, width, height, mouseX, mouseY);
            if (hovered && button == 0) {
                clickAction.run();
            }
        }

        @Override
        public void mouseReleased(int mouseX, int mouseY, int state) {

        }
    }

}
