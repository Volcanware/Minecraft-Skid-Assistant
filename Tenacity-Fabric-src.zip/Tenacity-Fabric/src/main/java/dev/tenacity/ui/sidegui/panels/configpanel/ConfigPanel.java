package dev.tenacity.ui.sidegui.panels.configpanel;

import dev.tenacity.Tenacity;
import dev.tenacity.config.Config;
import dev.tenacity.ui.sidegui.forms.impl.SaveForm;
import dev.tenacity.ui.sidegui.panels.Panel;
import dev.tenacity.ui.sidegui.utils.ActionButton;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.objects.Scroll;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ConfigPanel extends Panel {

    private final List<LocalConfigRect> configRects = new ArrayList<>();
    private final Scroll configScroll = new Scroll();
    private final Animation fadeIn = new DecelerateAnimation(400, 1);
    private final ActionButton saveButton = new ActionButton("Save config");

    private boolean refreshQueued = true;

    public void queueRefresh() {
        refreshQueued = true;
    }

    private void refresh() {
        configRects.clear();
        Tenacity.INSTANCE.getConfigManager().collectConfigs();
        for (Config config : Tenacity.INSTANCE.getConfigManager().getConfigs()) {
            configRects.add(new LocalConfigRect(config, this::queueRefresh));
        }
    }

    @Override
    public void initGui() {
        fadeIn.setDirection(Direction.FORWARDS);
        fadeIn.reset();
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {

    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        if (refreshQueued) {
            refreshQueued = false;
            refresh();
        }

        tenacityBoldFont40().drawString("Configs", getX() + 8, getY() + 8, getTextColor());
        tenacityFont18().drawString("Local configs stored on your machine", getX() + 8, getY() + 30,
                ColorUtil.applyOpacity(getTextColor(), .3f));

        float spacing = 8;
        float rectY = getY() + 40 + spacing;
        float rectHeight = getHeight() - (40 + spacing * 2 + 24);

        // save button at bottom
        saveButton.setWidth(90);
        saveButton.setHeight(18);
        saveButton.setBold(true);
        saveButton.setX(getX() + getWidth() / 2f - saveButton.getWidth() / 2f);
        saveButton.setY(getY() + getHeight() - (saveButton.getHeight() + spacing));
        saveButton.setAlpha(getAlpha());
        saveButton.setClickAction(() -> {
            SaveForm form = (SaveForm) Tenacity.INSTANCE.getSideGui().getForms().get("SaveConfig");
            form.clear();
            Tenacity.INSTANCE.getSideGui().displayForm(form);
        });

        boolean hoveringList = HoveringUtil.isHovering(getX(), rectY, getWidth(), rectHeight, mouseX, mouseY);
        if (hoveringList) {
            configScroll.onScroll(35, dev.tenacity.ui.sidegui.SideGUI.scrollDelta);
        }

        RenderUtil.scissorStart(getX() - 1, rectY - 1, getWidth() + 2, rectHeight + 2);

        int count = 0;
        float cardHeight = 40;
        float cardSpacing = 6;
        for (LocalConfigRect rect : configRects) {
            rect.width = getWidth() - 10;
            rect.height = cardHeight;
            rect.x = getX() + 5;
            rect.y = (float) (rectY + 4 + (count * (cardHeight + cardSpacing)) + MathUtils.roundToHalf(configScroll.getScroll()));
            rect.alpha = getAlpha();
            rect.drawScreen(mouseX, mouseY);
            count++;
        }

        float hiddenHeight = (count * (cardHeight + cardSpacing)) - (rectHeight - 8);
        configScroll.setMaxScroll(Math.max(0, hiddenHeight));

        RenderUtil.scissorEnd();

        if (configRects.isEmpty()) {
            tenacityFont18().drawCenteredString("No local configs saved yet",
                    getX() + getWidth() / 2f, rectY + rectHeight / 2f,
                    ColorUtil.applyOpacity(getTextColor(), .4f));
        }

        saveButton.drawScreen(mouseX, mouseY);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        configRects.forEach(rect -> rect.mouseClicked(mouseX, mouseY, button));
        saveButton.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {

    }
}
