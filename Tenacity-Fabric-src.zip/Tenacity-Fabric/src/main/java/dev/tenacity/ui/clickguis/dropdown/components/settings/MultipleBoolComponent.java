package dev.tenacity.ui.clickguis.dropdown.components.settings;

import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.ui.clickguis.dropdown.components.SettingComponent;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.render.ColorUtil;

import java.awt.*;

public class MultipleBoolComponent extends SettingComponent<MultipleBoolSetting> {

    private boolean expanded;
    private final Animation expandAnimation = new DecelerateAnimation(200, 1, Direction.BACKWARDS);

    public MultipleBoolComponent(MultipleBoolSetting setting) {
        super(setting);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        MultipleBoolSetting setting = getSetting();
        expandAnimation.setDirection(expanded ? Direction.FORWARDS : Direction.BACKWARDS);
        float out = expandAnimation.getOutput().floatValue();

        tenacityFont16().drawString(setting.getName() + "...", x + 8, y + 4,
                ColorUtil.applyOpacity(new Color(190, 190, 190), alpha).getRGB());

        float optionY = y + 13;
        for (BooleanSetting bool : setting.getBoolSettings()) {
            if (out > 0.01f) {
                Color c = bool.isEnabled() ? clientColors.getFirst() : new Color(120, 120, 120);
                tenacityFont14().drawString(bool.getName(), x + 12, optionY,
                        ColorUtil.applyOpacity(c, alpha * out).getRGB());
            }
            optionY += 11;
        }
        countSize = 1 + (setting.getBoolSettings().size() * 11f / 15f) * out;
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (isHoveringBox(mouseX, mouseY) && mouseY < y + 13 && button == 0 && isClickable(y + height)) {
            expanded = !expanded;
        }
        if (expanded) {
            float optionY = y + 13;
            for (BooleanSetting bool : getSetting().getBoolSettings()) {
                if (mouseX >= x + 8 && mouseX <= x + width - 4 && mouseY >= optionY && mouseY <= optionY + 11 && button == 0) {
                    bool.setState(!bool.isEnabled());
                    break;
                }
                optionY += 11;
            }
        }
    }
}
