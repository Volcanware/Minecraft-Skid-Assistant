package dev.tenacity.ui.mainmenu.particles;

public enum ParticleType {
    BIG,
    SMALL
}
