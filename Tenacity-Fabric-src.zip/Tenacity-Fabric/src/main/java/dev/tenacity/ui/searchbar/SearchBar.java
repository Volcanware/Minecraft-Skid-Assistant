package dev.tenacity.ui.searchbar;

import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.misc.HoveringUtil;

import java.awt.*;

public class SearchBar implements Utils {

    private final Animation openAnimation = new DecelerateAnimation(300, 1);
    private float alpha = 1f;
    private boolean focused;
    private String text = "";
    private final SearchField field = new SearchField();

    public void initGui() {}

    public boolean isFocused() { return focused; }
    public void mouseReleased(int mouseX, int mouseY, int state) {}
    public Animation getOpenAnimation() { return openAnimation; }
    /** The Modern click GUI fades the bar out while opening/side-panel animations play. */
    public void setAlpha(float alpha) { this.alpha = alpha; }
    /** Keystrokes go to the search text while the bar is focused. */
    public boolean isTyping() { return focused; }
    public void setFocused(boolean focused) { this.focused = focused; }
    public String getText() { return text; }
    public SearchField getSearchField() { return field; }

    public class SearchField {
        public void setText(String t) { text = t; }
        public void setFocused(boolean f) { focused = f; }
        public String getText() { return text; }
    }

    public boolean matchesSearch(String name) {
        return text.isEmpty() || name.toLowerCase().contains(text.toLowerCase());
    }

    public void drawScreen(int mouseX, int mouseY) {
        float x = ctx().getScaledWindowWidth() - 160;
        float y = 12;
        RoundedUtil.drawRound(x, y, 140, 18, 6, ColorUtil.applyOpacity(new Color(20, 20, 20), .8f * alpha));
        String display = text.isEmpty() && !focused ? "Search..." : text + (focused ? "_" : "");
        tenacityFont16().drawString(display, x + 8, y + 5,
                ColorUtil.applyOpacity(text.isEmpty() && !focused ? new Color(120, 120, 120).getRGB() : Color.WHITE.getRGB(), alpha));
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        float x = ctx().getScaledWindowWidth() - 160;
        focused = HoveringUtil.isHovering(x, 12, 140, 18, mouseX, mouseY);
    }

    public void keyTyped(char typedChar, int keyCode) {
        if (!focused) return;
        if (keyCode == 259 && !text.isEmpty()) {
            text = text.substring(0, text.length() - 1);
        } else if (keyCode == 256) {
            focused = false;
        } else if (typedChar >= 32 && typedChar < 127) {
            text += typedChar;
        }
    }
}
