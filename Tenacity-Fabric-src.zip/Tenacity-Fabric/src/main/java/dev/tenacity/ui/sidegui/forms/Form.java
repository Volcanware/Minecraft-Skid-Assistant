package dev.tenacity.ui.sidegui.forms;

import dev.tenacity.Tenacity;
import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.ui.Screen;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;
import java.util.function.BiConsumer;

public abstract class Form implements Screen, Utils {
    private float x, y, width, height, alpha;
    private final String title;
    private BiConsumer<String, String> uploadAction;

    protected Form(String title) {
        this.title = title;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        RoundedUtil.drawRound(x, y, width, height, 5, ColorUtil.tripleColor(37, alpha));
        tenacityBoldFont40().drawString(title, x + 5, y + 3, getTextColor());
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (!HoveringUtil.isHovering(x, y, width, height, mouseX, mouseY)) {
            Tenacity.INSTANCE.getSideGui().displayForm(null);
        }
    }

    public float getSpacing() { return 8; }

    public Color getTextColor() { return ColorUtil.applyOpacity(Color.WHITE, alpha); }

    public Color getAccentColor() { return ColorUtil.applyOpacity(HUDMod.getClientColors().getFirst(), alpha); }

    public abstract void clear();

    public float getX() { return x; }
    public void setX(float x) { this.x = x; }
    public float getY() { return y; }
    public void setY(float y) { this.y = y; }
    public float getWidth() { return width; }
    public void setWidth(float width) { this.width = width; }
    public float getHeight() { return height; }
    public void setHeight(float height) { this.height = height; }
    public float getAlpha() { return alpha; }
    public void setAlpha(float alpha) { this.alpha = alpha; }
    public String getTitle() { return title; }
    public BiConsumer<String, String> getUploadAction() { return uploadAction; }
    public void setUploadAction(BiConsumer<String, String> uploadAction) { this.uploadAction = uploadAction; }
}
