package dev.tenacity.ui.clickguis.dropdown.components.settings;

import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.ui.clickguis.dropdown.components.SettingComponent;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.EaseInOutQuad;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;

public class BooleanComponent extends SettingComponent<BooleanSetting> {

    private final Animation toggleAnimation = new EaseInOutQuad(200, 1);

    public BooleanComponent(BooleanSetting setting) {
        super(setting);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        BooleanSetting setting = getSetting();
        toggleAnimation.setDirection(setting.isEnabled() ? Direction.FORWARDS : Direction.BACKWARDS);
        float out = toggleAnimation.getOutput().floatValue();

        tenacityFont16().drawString(setting.getName(), x + 8, y + 4,
                ColorUtil.applyOpacity(new Color(190, 190, 190), alpha).getRGB());

        float switchX = x + width - 24;
        float switchY = y + 3;
        RoundedUtil.drawRound(switchX, switchY, 18, 8, 4,
                ColorUtil.applyOpacity(ColorUtil.interpolateColorC(new Color(60, 60, 60),
                        clientColors.getFirst(), out), alpha));
        RenderUtil.drawGoodCircle(switchX + 4 + out * 10, switchY + 4, 3.5f,
                ColorUtil.applyOpacity(Color.WHITE, alpha).getRGB());
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (isHoveringBox(mouseX, mouseY) && button == 0 && isClickable(y + height)) {
            getSetting().setState(!getSetting().isEnabled());
        }
    }
}
