package dev.tenacity.ui.sidegui.utils;

import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.ui.Screen;
import dev.tenacity.ui.sidegui.SideGUI;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.ContinualAnimation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.misc.HoveringUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

public class CarouselButtons implements Screen, Utils {
    private float x, y, rectWidth, rectHeight, alpha;
    private boolean hovering = false;
    private Color backgroundColor = new Color(39, 39, 39);
    private String currentButton;
    private final Map<String, Animation> options;

    public CarouselButtons(String... options) {
        this.options = new LinkedHashMap<>();
        for (String option : options) {
            this.options.put(option, new DecelerateAnimation(250, 1));
        }
        currentButton = options[0];
    }

    private final ContinualAnimation rectAnimation = new ContinualAnimation();

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        float buttonWidth = options.size() * rectWidth;
        Color textColor = ColorUtil.applyOpacity(Color.WHITE, alpha);

        hovering = HoveringUtil.isHovering(x, y, buttonWidth, rectHeight, mouseX, mouseY);

        RoundedUtil.drawRound(x, y, buttonWidth, rectHeight, 5, ColorUtil.applyOpacity(backgroundColor, alpha));

        Color accentColor = ColorUtil.applyOpacity(HUDMod.getClientColors().getFirst(), getAlpha());

        float coloredX = rectAnimation.getOutput();

        RoundedUtil.drawRound(x + coloredX, y, rectWidth, rectHeight, 5, accentColor);

        int seperation = 0;
        for (Map.Entry<String, Animation> entry : options.entrySet()) {
            float buttonX = x + seperation;
            boolean isCurrentButton = entry.getKey().equals(currentButton);
            Animation animation = entry.getValue();

            if (isCurrentButton) {
                rectAnimation.animate(seperation, 18);
            }

            boolean hovering = SideGUI.isHovering(buttonX, y, rectWidth, rectHeight, mouseX, mouseY);
            animation.setDirection(hovering ? Direction.FORWARDS : Direction.BACKWARDS);

            float textAlpha = (.5f + (.3f * animation.getOutput().floatValue()));
            tenacityFont24().drawCenteredString(entry.getKey(), x + rectWidth / 2f + seperation, y + tenacityFont24().getMiddleOfBox(rectHeight),
                    ColorUtil.applyOpacity(isCurrentButton ? textColor : ColorUtil.applyOpacity(textColor, textAlpha), getAlpha()));


            seperation += rectWidth;
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        int seperation = 0;
        for (Map.Entry<String, Animation> entry : options.entrySet()) {
            float buttonX = x + seperation;

            boolean hovering = SideGUI.isHovering(buttonX, y, rectWidth, rectHeight, mouseX, mouseY);
            if (hovering) {
                currentButton = entry.getKey();
            }
            seperation += rectWidth;
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {

    }

    public float getTotalWidth() {
        return options.size() * rectWidth;
    }

    public float getX() { return x; }
    public void setX(float x) { this.x = x; }
    public float getY() { return y; }
    public void setY(float y) { this.y = y; }
    public float getRectWidth() { return rectWidth; }
    public void setRectWidth(float rectWidth) { this.rectWidth = rectWidth; }
    public float getRectHeight() { return rectHeight; }
    public void setRectHeight(float rectHeight) { this.rectHeight = rectHeight; }
    public float getAlpha() { return alpha; }
    public void setAlpha(float alpha) { this.alpha = alpha; }
    public boolean isHovering() { return hovering; }
    public void setBackgroundColor(Color backgroundColor) { this.backgroundColor = backgroundColor; }
    public String getCurrentButton() { return currentButton; }
}
