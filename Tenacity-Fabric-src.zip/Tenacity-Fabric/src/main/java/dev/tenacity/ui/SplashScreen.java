package dev.tenacity.ui;

import dev.tenacity.Tenacity;
import dev.tenacity.ui.mainmenu.CustomMainMenu;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.animations.impl.EaseBackIn;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.joml.Matrix3x2fStack;

import java.awt.*;

/**
 * Tenacity splash screen — shown once on startup before the custom main menu.
 * The original drove this through a raw-framebuffer static path during client boot
 * ("Authenticating..."); the port renders it as a normal Screen since boot-time GL
 * is gone in 1.21.11.
 */
public class SplashScreen extends Screen implements Utils {

    private Animation fadeAnim, moveAnim, versionAnim, progressAnim, progress2Anim;
    private int ticks;
    private boolean finished;

    public SplashScreen() {
        super(Text.literal("Splash"));
    }

    @Override
    protected void init() {
        fadeAnim = new DecelerateAnimation(600, 1);
        moveAnim = new DecelerateAnimation(600, 1);
        ticks = 0;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        float width = this.width;
        float height = this.height;

        context.fill(0, 0, (int) width, (int) height, Color.BLACK.getRGB());

        dev.tenacity.utils.font.CustomFont fr = tenacityBoldFont80();

        float yMovement = progressAnim != null && progressAnim.getDirection().backwards() ? 1 - progressAnim.getOutput().floatValue() : 0;
        float actualY = (fr.getMiddleOfBox(height) - 40) - (48 * yMovement);

        fr.drawCenteredString("Tenacity", width / 2f, actualY,
                ColorUtil.applyOpacity(-1, moveAnim.getOutput().floatValue()));

        if (moveAnim.isDone() && versionAnim == null) {
            versionAnim = new EaseBackIn(500, 1, 2);
        }

        if (versionAnim != null) {
            float versionWidth = tenacityFont32().getStringWidth(Tenacity.VERSION) / 2f;
            float versionX = width / 2f + fr.getStringWidth("Tenacity") / 2f - (versionWidth);
            float versionY = (tenacityFont32().getMiddleOfBox(height) - 57) - (48 * yMovement);
            Matrix3x2fStack matrices = context.getMatrices();
            matrices.pushMatrix();
            RenderUtil.scaleStart(versionX + versionWidth, versionY + tenacityFont32().getHeight() / 2f, versionAnim.getOutput().floatValue());
            tenacityFont32().drawString(Tenacity.VERSION, versionX, versionY,
                    ColorUtil.applyOpacity(-1, versionAnim.getOutput().floatValue()));
            matrices.popMatrix();
        }

        if (progressAnim == null) {
            if (moveAnim.isDone()) {
                progressAnim = new DecelerateAnimation(250, 1);
                progress2Anim = new DecelerateAnimation(1800, 1);
            }
        } else {
            float rectWidth = fr.getStringWidth("Tenacity") + 10;
            float rectHeight = 5;
            float roundX = (width / 2f - rectWidth / 2f);
            float roundAlpha = progressAnim.getOutput().floatValue();

            RoundedUtil.drawRound(roundX, height / 2f - rectHeight / 2f, rectWidth, rectHeight,
                    (rectHeight / 2f) - .25f, ColorUtil.tripleColor(50, roundAlpha));

            RoundedUtil.drawRound(roundX, height / 2f - rectHeight / 2f,
                    rectWidth * progress2Anim.getOutput().floatValue(), rectHeight,
                    (rectHeight / 2f) - .25f, ColorUtil.applyOpacity(Color.WHITE, roundAlpha));
        }

        ticks++;
        if (!finished && progress2Anim != null && progress2Anim.isDone()) {
            finished = true;
            MinecraftClient.getInstance().setScreen(new CustomMainMenu());
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
