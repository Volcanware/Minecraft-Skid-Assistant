package dev.tenacity.config;

import java.util.ArrayList;
import java.util.List;

public class FriendCollection {

    private static final List<String> friends = new ArrayList<>();

    public static List<String> getFriends() {
        return friends;
    }

    public static void addFriend(String name) {
        if (!friends.contains(name)) friends.add(name);
    }

    public static void removeFriend(String name) {
        friends.remove(name);
    }

    public static boolean isFriend(String name) {
        return friends.contains(name);
    }
}
