package dev.tenacity.config;

import com.google.gson.*;
import dev.tenacity.Tenacity;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.Setting;
import dev.tenacity.module.settings.impl.*;
import dev.tenacity.ui.notifications.NotificationManager;
import dev.tenacity.ui.notifications.NotificationType;
import net.minecraft.client.MinecraftClient;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

public class ConfigManager {

    public static final List<LocalConfig> localConfigs = new ArrayList<>();
    public static boolean loadVisuals;
    public static File defaultConfig;
    public final File file = new File(MinecraftClient.getInstance().runDirectory, "Tenacity/Configs");
    private final Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create();

    public void collectConfigs() {
        localConfigs.clear();
        file.mkdirs();
        Arrays.stream(Objects.requireNonNull(file.listFiles())).forEach(f -> localConfigs.add(new LocalConfig(f.getName().split("\\.")[0])));
        defaultConfig = new File(file, "default.json");
    }

    public List<Config> getConfigs() {
        file.mkdirs();
        List<Config> configs = new ArrayList<>();
        File[] files = file.listFiles();
        if (files != null) {
            for (File f : files) {
                configs.add(new Config(f.getName().replace(".json", ""), f));
            }
        }
        return configs;
    }

    public Config getConfig(String name) {
        return getConfigs().stream().filter(c -> c.getName().equalsIgnoreCase(name.replace(".json", ""))).findFirst().orElse(null);
    }

    public boolean saveConfig(String name, String content) {
        LocalConfig localConfig = new LocalConfig(name);
        localConfig.getFile().getParentFile().mkdirs();
        try {
            Files.write(localConfig.getFile().toPath(), content.getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean saveConfig(String name) {
        return saveConfig(name, serialize());
    }

    public boolean delete(String configName) {
        List<LocalConfig> configsMatch = localConfigs.stream().filter(localConfig -> localConfig.getName().equals(configName)).collect(Collectors.toList());
        try {
            LocalConfig configToDelete = configsMatch.get(0);
            Files.deleteIfExists(configToDelete.getFile().toPath());
        } catch (IOException | IndexOutOfBoundsException e) {
            e.printStackTrace();
            NotificationManager.post(NotificationType.WARNING, "Config Manager", "Failed to delete config!");
            return false;
        }
        return true;
    }

    public void saveDefaultConfig() {
        if (defaultConfig == null) return;
        defaultConfig.getParentFile().mkdirs();
        try {
            Files.write(defaultConfig.toPath(), serialize().getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String serialize() {
        List<Module> modules = new ArrayList<>();
        for (Module module : Tenacity.INSTANCE.getModuleCollection().getModules()) {
            if (module.getCategory().equals(Category.SCRIPTS)) continue;
            List<ConfigSetting> settings = new ArrayList<>();
            for (Setting setting : module.getSettingsList()) {
                ConfigSetting cfgSetting = new ConfigSetting(setting.getName(), setting.getConfigValue());
                if (setting instanceof ColorSetting cs) {
                    cfgSetting.value = cs.getConfigValueJSON().toString();
                }
                settings.add(cfgSetting);
            }
            module.cfgSettings = settings.toArray(new ConfigSetting[0]);
            modules.add(module);
        }
        return gson.toJson(modules);
    }

    public void loadConfig(Config config) {
        if (config == null) return;
        loadConfig(config.getFile());
    }

    public void loadConfig(File file) {
        if (!file.exists()) return;
        try {
            String json = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
            JsonArray arr = JsonParser.parseString(json).getAsJsonArray();
            Map<String, JsonObject> byName = new HashMap<>();
            for (JsonElement el : arr) {
                JsonObject o = el.getAsJsonObject();
                byName.put(o.get("name").getAsString().toLowerCase(), o);
            }
            for (Module module : Tenacity.INSTANCE.getModuleCollection().getModules()) {
                JsonObject o = byName.get(module.getName().toLowerCase());
                if (o == null) continue;
                boolean toggled = o.has("toggled") && o.get("toggled").getAsBoolean();
                if (toggled != module.isEnabled()) {
                    module.setToggled(toggled);
                }
                if (o.has("settings")) {
                    for (JsonElement sel : o.getAsJsonArray("settings")) {
                        JsonObject sObj = sel.getAsJsonObject();
                        String sName = sObj.get("name").getAsString();
                        JsonElement val = sObj.get("value");
                        for (Setting setting : module.getSettingsList()) {
                            if (!setting.getName().equals(sName)) continue;
                            applySetting(setting, val);
                        }
                    }
                }
            }
            DragManager.loadDragData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void applySetting(Setting setting, JsonElement val) {
        try {
            if (setting instanceof BooleanSetting bs) {
                bs.setState(val.getAsBoolean());
            } else if (setting instanceof NumberSetting ns) {
                ns.setValue(val.getAsDouble());
            } else if (setting instanceof ModeSetting ms) {
                ms.setCurrentMode(val.getAsString());
            } else if (setting instanceof KeybindSetting ks) {
                ks.setCode(val.getAsInt());
            } else if (setting instanceof StringSetting ss) {
                ss.setString(val.getAsString());
            } else if (setting instanceof ColorSetting cs) {
                cs.loadConfigValue(JsonParser.parseString(val.getAsString()).getAsJsonObject());
            } else if (setting instanceof MultipleBoolSetting ms && val.isJsonObject()) {
                JsonObject obj = val.getAsJsonObject();
                for (BooleanSetting b : ms.getBoolSettings()) {
                    if (obj.has(b.getName())) b.setState(obj.get(b.getName()).getAsBoolean());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
