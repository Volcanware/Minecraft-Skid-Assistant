package dev.tenacity.config;

import dev.tenacity.Tenacity;

import java.io.File;

public class LocalConfig {

    private final String name;
    private final File file;

    public LocalConfig(String name) {
        this.name = name;
        this.file = new File(new File(Tenacity.DIRECTORY, "Configs"), name + ".json");
    }

    public String getName() { return name; }
    public File getFile() { return file; }
}
