package dev.tenacity.config;

import java.io.File;

public class Config {

    private final String name;
    private final File file;

    public Config(String name, File file) {
        this.name = name;
        this.file = file;
    }

    public String getName() { return name; }
    public File getFile() { return file; }
}
