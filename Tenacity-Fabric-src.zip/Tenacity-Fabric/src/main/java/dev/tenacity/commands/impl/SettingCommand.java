package dev.tenacity.commands.impl;

import dev.tenacity.Tenacity;
import dev.tenacity.commands.Command;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.Setting;
import dev.tenacity.module.settings.impl.*;

public class SettingCommand extends Command {

    public SettingCommand() {
        super("setting", "Changes a module setting", ".setting [module] [setting] [value]", "set");
    }

    @Override
    public void execute(String[] args) {
        if (args.length < 3) {
            usage();
            return;
        }
        Module module = Tenacity.INSTANCE.getModuleCollection().get(args[0]);
        if (module == null) {
            sendChatWithPrefix("Module \"" + args[0] + "\" does not exist!");
            return;
        }
        String settingName = args[1];
        String value = args[2];
        for (Setting setting : module.getSettingsList()) {
            if (setting.getName().replace(" ", "").equalsIgnoreCase(settingName)) {
                if (setting instanceof BooleanSetting bs) {
                    bs.setState(Boolean.parseBoolean(value));
                } else if (setting instanceof NumberSetting ns) {
                    ns.setValue(Double.parseDouble(value));
                } else if (setting instanceof ModeSetting ms) {
                    ms.setCurrentMode(value);
                } else if (setting instanceof StringSetting ss) {
                    ss.setString(value);
                }
                sendChatWithPrefix("Set " + setting.getName() + " to " + value);
                return;
            }
        }
        sendChatWithPrefix("Setting \"" + settingName + "\" not found on " + module.getName());
    }
}
