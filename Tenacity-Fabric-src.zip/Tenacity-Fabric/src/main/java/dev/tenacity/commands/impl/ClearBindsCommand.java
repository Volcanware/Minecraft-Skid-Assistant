package dev.tenacity.commands.impl;

import dev.tenacity.Tenacity;
import dev.tenacity.commands.Command;
import dev.tenacity.module.Module;
import org.lwjgl.glfw.GLFW;

public class ClearBindsCommand extends Command {

    public ClearBindsCommand() {
        super("clearbinds", "Clears all binds", ".clearbinds", "cb");
    }

    @Override
    public void execute(String[] args) {
        for (Module module : Tenacity.INSTANCE.getModuleCollection().getModules()) {
            module.getKeybind().setCode(GLFW.GLFW_KEY_UNKNOWN);
        }
        sendChatWithPrefix("Cleared all binds!");
    }
}
