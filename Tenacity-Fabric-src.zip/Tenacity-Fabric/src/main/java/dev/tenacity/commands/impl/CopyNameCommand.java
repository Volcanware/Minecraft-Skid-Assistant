package dev.tenacity.commands.impl;

import dev.tenacity.commands.Command;
import dev.tenacity.utils.misc.IOUtils;

public class CopyNameCommand extends Command {

    public CopyNameCommand() {
        super("copyname", "Copies your username to the clipboard", ".copyname", "cn");
    }

    @Override
    public void execute(String[] args) {
        if (mc.player != null) {
            IOUtils.copy(mc.player.getName().getString());
            sendChatWithPrefix("Copied your name to clipboard!");
        }
    }
}
