package dev.tenacity.commands.impl;

import dev.tenacity.Tenacity;
import dev.tenacity.commands.Command;
import dev.tenacity.module.Module;
import org.lwjgl.glfw.GLFW;

public class UnbindCommand extends Command {

    public UnbindCommand() {
        super("unbind", "Unbinds a module", ".unbind [module]", "ub");
    }

    @Override
    public void execute(String[] args) {
        if (args.length == 0) {
            usage();
            return;
        }
        Module module = Tenacity.INSTANCE.getModuleCollection().get(args[0]);
        if (module != null) {
            module.getKeybind().setCode(GLFW.GLFW_KEY_UNKNOWN);
            sendChatWithPrefix("Unbound " + module.getName() + "!");
        } else {
            sendChatWithPrefix("The module \"" + args[0] + "\" does not exist!");
        }
    }
}
