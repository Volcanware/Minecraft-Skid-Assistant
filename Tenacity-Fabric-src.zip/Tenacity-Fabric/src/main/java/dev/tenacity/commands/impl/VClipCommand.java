package dev.tenacity.commands.impl;

import dev.tenacity.commands.Command;

public class VClipCommand extends Command {

    public VClipCommand() {
        super("vclip", "Teleports you vertically", ".vclip [amount]", "vc");
    }

    @Override
    public void execute(String[] args) {
        if (args.length == 0 || mc.player == null) {
            usage();
            return;
        }
        try {
            double amount = Double.parseDouble(args[0]);
            mc.player.setPosition(mc.player.getX(), mc.player.getY() + amount, mc.player.getZ());
            sendChatWithPrefix("Teleported " + amount + " blocks vertically!");
        } catch (NumberFormatException e) {
            usage();
        }
    }
}
