package dev.tenacity.commands.impl;

import dev.tenacity.Tenacity;
import dev.tenacity.commands.Command;
import dev.tenacity.utils.misc.ChatUtil;

public class HelpCommand extends Command {

    public HelpCommand() {
        super("help", "Lists all commands", ".help", "h");
    }

    @Override
    public void execute(String[] args) {
        for (Command command : Tenacity.INSTANCE.getCommandHandler().getCommands()) {
            ChatUtil.print(command.getUsage() + " - " + command.getDescription());
        }
    }
}
