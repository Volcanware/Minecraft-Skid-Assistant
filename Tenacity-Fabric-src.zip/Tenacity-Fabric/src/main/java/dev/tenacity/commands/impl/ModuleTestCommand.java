package dev.tenacity.commands.impl;

import dev.tenacity.Tenacity;
import dev.tenacity.commands.Command;
import dev.tenacity.event.Event;
import dev.tenacity.event.EventListener;
import dev.tenacity.module.Module;
import dev.tenacity.module.ModuleCollection;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Automated smoke test: enables every module for a few seconds each under live
 * gameplay and captures exceptions from their event handlers via
 * {@link EventProtocol}'s per-listener error recording.
 */
public class ModuleTestCommand extends Command {

    public static final List<String> ERRORS = new CopyOnWriteArrayList<>();
    public static boolean testing = false;

    public ModuleTestCommand() {
        super("testmodules", "Smoke-tests every module", ".testmodules [ms]", "moduletest");
    }

    @Override
    public void execute(String[] args) {
        if (testing) {
            sendChatWithPrefix("A module test is already running.");
            return;
        }
        if (mc.player == null) {
            sendChatError("Join a world first.");
            return;
        }
        long holdMs = 2500;
        try {
            if (args.length > 0) holdMs = Math.max(200, Long.parseLong(args[0]));
        } catch (NumberFormatException ignored) {
        }

        final long hold = holdMs;
        testing = true;
        ERRORS.clear();
        new Thread(() -> {
            List<String> lines = new ArrayList<>();
            lines.add("Tenacity module test — " + new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()));
            lines.add("hold=" + hold + "ms per module");
            lines.add("");

            List<Module> modules = Tenacity.INSTANCE.getModuleCollection().getModules();
            int pass = 0, fail = 0, skip = 0;
            for (Module module : modules) {
                String name = module.getName();
                int errorsBefore = ERRORS.size();
                try {
                    if (!module.isEnabled()) module.toggle();
                    Thread.sleep(hold);
                } catch (Throwable t) {
                    ERRORS.add(name + " | enable | " + t);
                }
                try {
                    if (module.isEnabled()) module.toggle();
                } catch (Throwable t) {
                    ERRORS.add(name + " | disable | " + t);
                }
                try {
                    Thread.sleep(150);
                } catch (InterruptedException ignored) {
                }

                int newErrors = ERRORS.size() - errorsBefore;
                if (newErrors == 0) {
                    pass++;
                    lines.add("PASS  " + name);
                } else {
                    fail++;
                    lines.add("FAIL  " + name + "  (" + newErrors + " errors)");
                    for (int i = ERRORS.size() - newErrors; i < ERRORS.size(); i++) {
                        lines.add("        " + ERRORS.get(i));
                    }
                }
                if ((pass + fail + skip) % 10 == 0) {
                    try {
                        sendMsg("[Test] " + (pass + fail + skip) + "/" + modules.size() + " done — " + fail + " failures so far");
                    } catch (Throwable ignored) {
                    }
                }
            }
            lines.add("");
            lines.add("SUMMARY: " + pass + " pass, " + fail + " fail, " + skip + " skipped, " + modules.size() + " total");

            File out = new File(mc.runDirectory, "moduletest-results.txt");
            try (FileWriter w = new FileWriter(out)) {
                for (String line : lines) w.write(line + "\n");
            } catch (Throwable t) {
                t.printStackTrace();
            }
            for (String line : lines) System.out.println("[ModuleTest] " + line);
            try {
                sendMsg("[Test] DONE — " + pass + " pass, " + fail + " fail. Results: " + out.getAbsolutePath());
            } catch (Throwable ignored) {
            }
            testing = false;
        }, "ModuleTest").start();
        sendChatWithPrefix("Testing " + Tenacity.INSTANCE.getModuleCollection().getModules().size()
                + " modules, " + hold + "ms each. Watch chat for progress.");
    }

    private void sendMsg(String msg) {
        mc.execute(() -> dev.tenacity.utils.misc.ChatUtil.print(msg));
    }
}
