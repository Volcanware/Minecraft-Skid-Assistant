package dev.tenacity.commands.impl;

import dev.tenacity.Tenacity;
import dev.tenacity.commands.Command;
import dev.tenacity.config.Config;

public class LoadCommand extends Command {

    public LoadCommand() {
        super("load", "Loads a config", ".load [config]", "l");
    }

    @Override
    public void execute(String[] args) {
        if (args.length == 0) {
            sendChatWithInfo("Configs: " + String.join(", ",
                    Tenacity.INSTANCE.getConfigManager().getConfigs().stream().map(Config::getName).toList()));
            return;
        }
        String name = args[0];
        Config config = Tenacity.INSTANCE.getConfigManager().getConfig(name.endsWith(".json") ? name : name + ".json");
        if (config != null) {
            Tenacity.INSTANCE.getConfigManager().loadConfig(config);
            sendChatWithPrefix("Loaded config " + name + "!");
        } else {
            sendChatWithPrefix("Config \"" + name + "\" does not exist!");
        }
    }
}
