package dev.tenacity.commands.impl;

import dev.tenacity.Tenacity;
import dev.tenacity.commands.Command;
import dev.tenacity.module.Module;
import org.lwjgl.glfw.GLFW;

import java.util.Arrays;
import java.util.stream.Collectors;

public class BindCommand extends Command {

    public BindCommand() {
        super("bind", "Binds a module to a key", ".bind [module] [key]", "b");
    }

    @Override
    public void execute(String[] args) {
        if (args.length == 0) {
            usage();
        } else if (args.length == 1) {
            String moduleName = args[0];
            Module module = Tenacity.INSTANCE.getModuleCollection().get(moduleName);
            if (module != null) {
                sendChatWithInfo(module.getName() + " is bound to " + org.lwjgl.glfw.GLFW.glfwGetKeyName(module.getKeybind().getCode(), 0));
            } else {
                sendChatWithPrefix("The module \"" + moduleName + "\" does not exist!");
            }
        } else {
            String moduleName = Arrays.stream(args).limit(args.length - 1).collect(Collectors.joining(" "));
            Module module = Tenacity.INSTANCE.getModuleCollection().get(moduleName);
            if (module != null) {
                int keyCode = getKeyCode(args[args.length - 1]);
                if (keyCode != -1) {
                    module.getKeybind().setCode(keyCode);
                    sendChatWithPrefix("Bound " + module.getName() + " to " + args[args.length - 1].toUpperCase());
                }
            } else {
                sendChatWithPrefix("The module \"" + moduleName + "\" does not exist!");
            }
        }
    }

    private int getKeyCode(String keyName) {
        if (keyName.length() == 1) {
            char c = Character.toUpperCase(keyName.charAt(0));
            if (c >= 'A' && c <= 'Z') return GLFW.GLFW_KEY_A + (c - 'A');
            if (c >= '0' && c <= '9') return GLFW.GLFW_KEY_0 + (c - '0');
        }
        if (keyName.equalsIgnoreCase("none")) return GLFW.GLFW_KEY_UNKNOWN;
        for (int i = 0; i < GLFW.GLFW_KEY_LAST; i++) {
            String name = GLFW.glfwGetKeyName(i, 0);
            if (name != null && name.equalsIgnoreCase(keyName)) return i;
        }
        return -1;
    }
}
