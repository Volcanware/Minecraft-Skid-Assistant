package dev.tenacity.commands.impl;

import dev.tenacity.commands.Command;

public class ClearConfigCommand extends Command {

    public ClearConfigCommand() {
        super("clearconfig", "Clears the current config", ".clearconfig", "ccfg");
    }

    @Override
    public void execute(String[] args) {
        sendChatWithPrefix("Config cleared!");
    }
}
