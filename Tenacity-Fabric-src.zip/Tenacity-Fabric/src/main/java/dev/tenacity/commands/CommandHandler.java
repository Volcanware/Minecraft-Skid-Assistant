package dev.tenacity.commands;

import dev.tenacity.commands.impl.*;
import dev.tenacity.utils.misc.ChatUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommandHandler {

    public static String CHAT_PREFIX = ".";
    public List<Command> commands = new ArrayList<>();

    public boolean execute(String txt) {
        if (!txt.startsWith(CHAT_PREFIX)) return false;
        String[] arguments = txt.substring(1).split(" ");
        for (Command command : commands) {
            if (command.getName().equalsIgnoreCase(arguments[0])
                    || Arrays.stream(command.getOtherPrefixes()).anyMatch(p -> p.equalsIgnoreCase(arguments[0]))) {
                command.execute(Arrays.copyOfRange(arguments, 1, arguments.length));
                return true;
            }
        }
        ChatUtil.print("Invalid command.");
        return true;
    }

    public void registerCommands() {
        commands.add(new BindCommand());
        commands.add(new ClearBindsCommand());
        commands.add(new ClearConfigCommand());
        commands.add(new CopyNameCommand());
        commands.add(new FriendCommand());
        commands.add(new HelpCommand());
        commands.add(new LoadCommand());
        commands.add(new ModuleTestCommand());
        commands.add(new SettingCommand());
        commands.add(new ToggleCommand());
        commands.add(new UnbindCommand());
        commands.add(new VClipCommand());
    }

    public List<Command> getCommands() {
        return commands;
    }

    public Command getCommand(Class<? extends Command> command) {
        return getCommands().stream().filter(com -> command == com.getClass()).findFirst().orElse(null);
    }
}
