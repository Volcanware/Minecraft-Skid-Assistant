package dev.tenacity.commands.impl;

import dev.tenacity.commands.Command;
import dev.tenacity.config.FriendCollection;

public class FriendCommand extends Command {

    public FriendCommand() {
        super("friend", "Adds/removes friends", ".friend [add/remove] [name]", "f");
    }

    @Override
    public void execute(String[] args) {
        if (args.length == 0) {
            sendChatWithPrefix("Friends: " + String.join(", ", FriendCollection.getFriends()));
            return;
        }
        if (args.length < 2) {
            usage();
            return;
        }
        String action = args[0];
        String name = args[1];
        if (action.equalsIgnoreCase("add")) {
            FriendCollection.addFriend(name);
            sendChatWithPrefix("Added " + name + " as a friend!");
        } else if (action.equalsIgnoreCase("remove") || action.equalsIgnoreCase("del")) {
            FriendCollection.removeFriend(name);
            sendChatWithPrefix("Removed " + name + " from friends!");
        } else {
            usage();
        }
    }
}
