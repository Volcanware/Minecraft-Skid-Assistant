package dev.tenacity.hackerdetector.utils;

import net.minecraft.entity.player.PlayerEntity;

public class MovementUtils {

    public static boolean isMoving(PlayerEntity player) {
        return player.forwardSpeed != 0F || player.sidewaysSpeed != 0F;
    }

    public static boolean isFalseFlaggable(PlayerEntity player) {
        return player.isTouchingWater() || player.isInLava() || player.isClimbing() || player.age < 10;
    }

}
