package dev.tenacity.hackerdetector.checks;

import dev.tenacity.hackerdetector.Category;
import dev.tenacity.hackerdetector.Detection;
import dev.tenacity.hackerdetector.utils.MovementUtils;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Map;
import java.util.WeakHashMap;

public class FlightB extends Detection {

    private final Map<PlayerEntity, Integer> airTicks = new WeakHashMap<>();

    public FlightB() {
        super("Flight B", Category.MOVEMENT);
    }

    @Override
    public boolean runCheck(PlayerEntity player) {
        int ticks = player.isOnGround() ? 0 : airTicks.getOrDefault(player, 0) + 1;
        airTicks.put(player, ticks);
        return ticks > 20 && player.getVelocity().y == 0 && MovementUtils.isMoving(player);
    }
}
