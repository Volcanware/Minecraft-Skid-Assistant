package dev.tenacity.hackerdetector.checks;

import dev.tenacity.hackerdetector.Category;
import dev.tenacity.hackerdetector.Detection;
import dev.tenacity.hackerdetector.utils.MovementUtils;
import net.minecraft.entity.player.PlayerEntity;

public class FlightA extends Detection {

    public FlightA() {
        super("Flight A", Category.MOVEMENT);
    }

    @Override
    public boolean runCheck(PlayerEntity player) {
        return !player.isOnGround() && player.getVelocity().y == 0 && MovementUtils.isMoving(player);
    }
}
