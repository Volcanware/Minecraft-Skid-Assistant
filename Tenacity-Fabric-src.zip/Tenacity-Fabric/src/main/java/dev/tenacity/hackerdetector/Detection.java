package dev.tenacity.hackerdetector;

import net.minecraft.entity.player.PlayerEntity;

public abstract class Detection {

    private String name;
    private Category type;
    private long lastViolated;

    public Detection(String name, Category type) {
        this.name = name;
        this.type = type;
    }

    public abstract boolean runCheck(PlayerEntity player);

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Category getType() {
        return type;
    }

    public void setType(Category type) {
        this.type = type;
    }

    public long getLastViolated() {
        return lastViolated;
    }

    public void setLastViolated(long lastViolated) {
        this.lastViolated = lastViolated;
    }
}
