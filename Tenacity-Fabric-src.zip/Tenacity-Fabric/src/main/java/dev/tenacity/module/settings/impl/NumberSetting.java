package dev.tenacity.module.settings.impl;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import dev.tenacity.module.settings.Setting;

public class NumberSetting extends Setting {

    @Expose
    @SerializedName("value")
    private double value;
    private final double min, max, increment;
    private final boolean index;

    public NumberSetting(String name, double value, double min, double max, double increment) {
        this(name, value, min, max, increment, false);
    }

    public NumberSetting(String name, double value, double min, double max, double increment, boolean index) {
        this.name = name;
        this.value = value;
        // Ported call sites pass (min, max) in either order; normalize so both work.
        this.min = Math.min(min, max);
        this.max = Math.max(min, max);
        this.increment = increment;
        this.index = index;
    }

    public static String formatNumber(double value, double increment) {
        double precision = Math.max(0, -Math.log10(increment) + (increment == (int) increment ? 0 : 1));
        if (precision > 5 || precision < 0) precision = 1;
        String format = "%." + (int) Math.ceil(precision) + "f";
        return String.format(format, value).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    public String getStringValue() {
        return formatNumber(value, increment);
    }

    public double getValue() {
        return index ? (int) value : value;
    }

    public int getIntValue() {
        return (int) value;
    }

    public float getFloatValue() {
        return (float) (index ? (int) value : value);
    }

    public void setValue(double value) {
        this.value = Math.max(min, Math.min(max, value));
    }

    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getIncrement() { return increment; }

    @Override
    public Double getConfigValue() {
        return value;
    }
}
