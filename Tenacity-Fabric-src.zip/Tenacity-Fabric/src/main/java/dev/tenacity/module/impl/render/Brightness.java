package dev.tenacity.module.impl.render;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;

public final class Brightness extends Module {

    @Override
    public void onMotionEvent(MotionEvent event) {
        mc.options.getGamma().setValue(100.0);
    }

    @Override
    public void onDisable() {
        mc.options.getGamma().setValue(0.0);
        super.onDisable();
    }

    public Brightness() {
        super("Brightness", Category.RENDER, "changes the game brightness");
    }

}
