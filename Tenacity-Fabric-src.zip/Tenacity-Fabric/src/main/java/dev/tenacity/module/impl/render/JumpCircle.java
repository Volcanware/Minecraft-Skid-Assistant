package dev.tenacity.module.impl.render;

import dev.tenacity.utils.tuples.Pair;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.render.Render3DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.WorldRenderUtil;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.util.math.Vec3d;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class JumpCircle extends Module {

    private static final NumberSetting radius = new NumberSetting("Radius", 2.5, 10, 1, .25);

    public JumpCircle() {
        super("JumpCircle", Category.RENDER, "Draws a circle when you land on the ground.");
        addSettings(radius);
    }

    private boolean inAir = false;

    private final List<Circle> circles = new ArrayList<>();
    private final List<Circle> toRemove = new ArrayList<>();

    @Override
    public void onMotionEvent(MotionEvent event) {
        if (event.isPre()) {
            if (!event.isOnGround()) {
                inAir = true;
            } else if (event.isOnGround() && inAir) {
                circles.add(new Circle(mc.player.getX(), mc.player.getY(), mc.player.getZ()));
                inAir = false;
            }
        }
    }

    @Override
    public void onRender3DEvent(Render3DEvent event) {
        WorldRenderUtil.start3D();
        for (Circle circle : circles) {
            circle.drawCircle();
            if (circle.fadeAnimation != null && circle.fadeAnimation.finished(Direction.BACKWARDS)) {
                toRemove.add(circle);
            }
        }
        WorldRenderUtil.end3D();

        for (Circle circle : toRemove) {
            circles.remove(circle);
        }


    }


    private static class Circle {
        private final float x, y, z;
        private final Animation expandAnimation;
        private final Animation fadeAnimation;


        public Circle(double x, double y, double z) {
            this.x = (float) x;
            this.y = (float) y;
            this.z = (float) z;
            this.fadeAnimation = new DecelerateAnimation(600, 1);
            this.expandAnimation = new DecelerateAnimation(1000, radius.getValue());
        }


        public void drawCircle() {
            Pair<Color, Color> colors = HUDMod.getClientColors();
            if (expandAnimation.getOutput() > (radius.getValue() * .7f)) {
                fadeAnimation.setDirection(Direction.BACKWARDS);
            }


            float animation = expandAnimation.getOutput().floatValue();
            float fade = fadeAnimation.getOutput().floatValue();
            double pi2 = Math.PI * 2;

            Vec3d cam = WorldRenderUtil.cameraPos();
            double xVal = x - cam.x;
            double yVal = y - cam.y;
            double zVal = z - cam.z;

            int color1 = colors.getSecond().getRGB();
            int color2 = colors.getFirst().getRGB();

            float newAnim = (float) Math.max(0, animation - (.3f * (animation / expandAnimation.getEndPoint())));

            // original emitted a TRIANGLE_STRIP of (outer, inner) pairs; emit the same
            // ring as quads (outer_i, inner_i, inner_i+1, outer_i+1)
            WorldRenderUtil.begin(RenderLayers.debugQuads());
            for (int i = 0; i <= 90; ++i) {
                float value = (float) Math.sin((i * 4) * (Math.PI / 180));
                int color = interpolateColor(color1, color2, Math.abs(value));
                if (i < 90) {
                    emitStripVertex(xVal, yVal, zVal, animation, i, pi2, color, fade * .6f);
                    emitStripVertex(xVal, yVal, zVal, newAnim, i, pi2, color, fade * .15f);
                    emitStripVertex(xVal, yVal, zVal, newAnim, i + 1, pi2,
                            interpolateColor(color1, color2, Math.abs((float) Math.sin(((i + 1) * 4) * (Math.PI / 180)))), fade * .15f);
                    emitStripVertex(xVal, yVal, zVal, animation, i, pi2, color, fade * .6f);
                }
            }

            WorldRenderUtil.resetColor();

        }

        private void emitStripVertex(double xVal, double yVal, double zVal, double r, int i, double pi2, int color, float alpha) {
            WorldRenderUtil.color(color, alpha);
            WorldRenderUtil.vertex(xVal + r * Math.cos(i * pi2 / 45), yVal, zVal + r * Math.sin(i * pi2 / 45));
        }

        private int interpolateColor(int color1, int color2, float amount) {
            amount = Math.min(1, Math.max(0, amount));
            return ColorUtil.interpolateColorC(new Color(color1), new Color(color2), amount).getRGB();
        }

    }

}
