package dev.tenacity.module.impl.movement;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.game.TickEvent;
import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.BlockPlaceableEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.SafeWalkEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.misc.TimerUtils;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.player.RotationUtils;
import dev.tenacity.utils.player.ScaffoldUtils;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.awt.*;

public class Scaffold extends Module {

    private final ModeSetting countMode = new ModeSetting("Block Counter", "Tenacity", "None", "Tenacity", "Basic", "Polar");
    private final BooleanSetting rotations = new BooleanSetting("Rotations", true);
    private final ModeSetting rotationMode = new ModeSetting("Rotation Mode", "Watchdog", "Watchdog", "NCP", "Back", "45", "Enum", "Down", "0");
    private final ModeSetting placeType = new ModeSetting("Place Type", "Post", "Pre", "Post", "Legit", "Dynamic");
    public static ModeSetting keepYMode = new ModeSetting("Keep Y Mode", "Always", "Always", "Speed toggled");
    public static ModeSetting sprintMode = new ModeSetting("Sprint Mode", "Vanilla", "Vanilla", "Watchdog", "Cancel");
    public static ModeSetting towerMode = new ModeSetting("Tower Mode", "Watchdog", "Vanilla", "NCP", "Watchdog", "Verus");
    public static ModeSetting swingMode = new ModeSetting("Swing Mode", "Client", "Client", "Silent");
    public static NumberSetting delay = new NumberSetting("Delay", 0, 0, 2, 0.05);
    private final NumberSetting timer = new NumberSetting("Timer", 1, 0.1, 5, 0.1);
    public static final BooleanSetting auto3rdPerson = new BooleanSetting("Auto 3rd Person", false);
    public static final BooleanSetting speedSlowdown = new BooleanSetting("Speed Slowdown", true);
    public static final NumberSetting speedSlowdownAmount = new NumberSetting("Slowdown Amount", 0.1, 0.01, 0.2, 0.01);
    public static final BooleanSetting itemSpoof = new BooleanSetting("Item Spoof", false);
    public static final BooleanSetting downwards = new BooleanSetting("Downwards", false);
    public static final BooleanSetting safewalk = new BooleanSetting("Safewalk", false);
    public static final BooleanSetting sprint = new BooleanSetting("Sprint", false);
    private final BooleanSetting sneak = new BooleanSetting("Sneak", false);
    public static final BooleanSetting tower = new BooleanSetting("Tower", false);
    private final NumberSetting towerTimer = new NumberSetting("Tower Timer Boost", 1.2, 0.1, 5, 0.1);
    private final BooleanSetting swing = new BooleanSetting("Swing", true);
    private final BooleanSetting autoJump = new BooleanSetting("Auto Jump", false);
    private final BooleanSetting hideJump = new BooleanSetting("Hide Jump", false);
    private final BooleanSetting baseSpeed = new BooleanSetting("Base Speed", false);
    public static BooleanSetting keepY = new BooleanSetting("Keep Y", false);
    private ScaffoldUtils.BlockCache blockCache, lastBlockCache;
    private float y;
    private float speed;
    private final TimerUtil delayTimer = new TimerUtil();
    private final TimerUtil timerUtil = new TimerUtil();
    public static double keepYCoord;
    private boolean shouldSendPacket;
    private boolean shouldTower;
    private boolean firstJump;
    private boolean pre;
    private int jumpTimer;
    private int slot;
    private int prevSlot;
    private float[] cachedRots = new float[2];

    private final Animation anim = new DecelerateAnimation(250, 1);

    public Scaffold() {
        super("Scaffold", Category.MOVEMENT, "Automatically places blocks under you");
        this.addSettings(countMode, rotations, rotationMode, placeType, keepYMode, sprintMode, towerMode, swingMode, delay, timer,
                auto3rdPerson, speedSlowdown, speedSlowdownAmount, itemSpoof, downwards, safewalk, sprint, sneak, tower, towerTimer,
                swing, autoJump, hideJump, baseSpeed, keepY);
        rotationMode.addParent(rotations, BooleanSetting::isEnabled);
        sprintMode.addParent(sprint, BooleanSetting::isEnabled);
        towerMode.addParent(tower, BooleanSetting::isEnabled);
        swingMode.addParent(swing, BooleanSetting::isEnabled);
        towerTimer.addParent(tower, BooleanSetting::isEnabled);
        keepYMode.addParent(keepY, BooleanSetting::isEnabled);
        hideJump.addParent(autoJump, BooleanSetting::isEnabled);
        speedSlowdownAmount.addParent(speedSlowdown, BooleanSetting::isEnabled);
    }

    // yaw of the direction the player is currently moving, in degrees
    private float getMoveYawDeg(float yaw) {
        return (float) Math.toDegrees(MovementUtils.getMoveYaw(yaw));
    }

    private static boolean isKeyDown(KeyBinding keyBinding) {
        InputUtil.Key key = InputUtil.fromTranslationKey(keyBinding.getBoundKeyTranslationKey());
        long handle = mc.getWindow().getHandle();
        if (key.getCategory() == InputUtil.Type.KEYSYM) {
            return InputUtil.isKeyPressed(mc.getWindow(), key.getCode());
        }
        return GLFW.glfwGetMouseButton(handle, key.getCode()) == GLFW.GLFW_PRESS;
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        // Timer Stuff
        if (!mc.options.jumpKey.isPressed()) {
            TimerUtils.setTimerSpeed(timer.getFloatValue());
        } else {
            TimerUtils.setTimerSpeed(tower.isEnabled() ? towerTimer.getFloatValue() : 1);
        }

        if (e.isPre()) {
            // Auto Jump
            if (baseSpeed.isEnabled()) {
                MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * 0.7);
            }
            if (autoJump.isEnabled() && mc.player.isOnGround() && MovementUtils.isMoving() && !mc.options.jumpKey.isPressed()) {
                mc.player.jump();
            }

            if (sprint.isEnabled() && sprintMode.is("Watchdog") && mc.player.isOnGround() && MovementUtils.isMoving() && !mc.options.jumpKey.isPressed() && !isDownwards() && mc.player.isSprinting()) {
                final double[] offset = MathUtils.yawPos(mc.player.getYaw() * MathHelper.RADIANS_PER_DEGREE, MovementUtils.getSpeed() / 2);
                PacketUtils.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX() - offset[0], mc.player.getY(), mc.player.getZ() - offset[1], true, false));
            }

            // Rotations
            if (rotations.isEnabled()) {
                float[] rotations = new float[]{0, 0};
                switch (rotationMode.getMode()) {
                    case "Watchdog":
                        rotations = new float[]{getMoveYawDeg(e.getYaw()) - 180, y};
                        e.setYaw(rotations[0]);
                        e.setPitch(rotations[1]);
                        break;
                    case "NCP":
                        float lastYaw = cachedRots[0];
                        if ((blockCache = ScaffoldUtils.getBlockInfo()) == null) {
                            blockCache = lastBlockCache;
                        }
                        if (blockCache != null && (mc.player.age % 3 == 0
                                || mc.world.getBlockState(BlockPos.ofFloored(e.getX(), ScaffoldUtils.getYLevel(), e.getZ())).isAir())) {
                            cachedRots = RotationUtils.getRotations(blockCache.getPosition(), blockCache.getFacing());
                        }
                        if ((mc.player.isOnGround() || (MovementUtils.isMoving() && tower.isEnabled() && mc.options.jumpKey.isPressed())) && Math.abs(cachedRots[0] - lastYaw) >= 90) {
                            cachedRots[0] = getMoveYawDeg(e.getYaw()) - 180;
                        }
                        rotations = cachedRots;
                        e.setYaw(rotations[0]);
                        e.setPitch(rotations[1]);
                        break;
                    case "Back":
                        rotations = new float[]{getMoveYawDeg(e.getYaw()) - 180, 77};
                        e.setYaw(rotations[0]);
                        e.setPitch(rotations[1]);
                        break;
                    case "Down":
                        e.setPitch(90);
                        break;
                    case "45":
                        float val;
                        if (MovementUtils.isMoving()) {
                            float f = getMoveYawDeg(e.getYaw()) - 180;
                            float[] numbers = new float[]{-135, -90, -45, 0, 45, 90, 135, 180};
                            float lastDiff = 999;
                            val = f;
                            for (float v : numbers) {
                                float diff = Math.abs(v - f);
                                if (diff < lastDiff) {
                                    lastDiff = diff;
                                    val = v;
                                }
                            }
                        } else {
                            val = rotations[0];
                        }
                        rotations = new float[]{
                                (val + MathHelper.wrapDegrees(mc.player.lastHeadYaw)) / 2.0F,
                                (77 + MathHelper.wrapDegrees(mc.player.lastPitch)) / 2.0F};
                        e.setYaw(rotations[0]);
                        e.setPitch(rotations[1]);
                        break;
                    case "Enum":
                        if (lastBlockCache != null) {
                            float yaw = RotationUtils.getEnumRotations(lastBlockCache.getFacing());
                            e.setYaw(yaw);
                            e.setPitch(77);
                        } else {
                            e.setYaw(mc.player.getYaw() + 180);
                            e.setPitch(77);
                        }
                        break;
                    case "0":
                        e.setYaw(0);
                        e.setPitch(0);
                        break;
                }
                RotationUtils.setVisualRotations(e);
            }

            // Speed 2 Slowdown
            if (speedSlowdown.isEnabled() && mc.player.hasStatusEffect(StatusEffects.SPEED) && !mc.options.jumpKey.isPressed() && mc.player.isOnGround()) {
                MovementUtils.setSpeed(speedSlowdownAmount.getValue());
            }

            if (sneak.isEnabled()) mc.options.sneakKey.setPressed(true);

            // Save ground Y level for keep Y
            if (mc.player.isOnGround()) {
                keepYCoord = Math.floor(mc.player.getY() - 1.0);
            }

            if (tower.isEnabled() && mc.options.jumpKey.isPressed()) {
                double centerX = Math.floor(e.getX()) + 0.5, centerZ = Math.floor(e.getZ()) + 0.5;
                switch (towerMode.getMode()) {
                    case "Vanilla":
                        mc.player.setVelocity(mc.player.getVelocity().x, 0.42f, mc.player.getVelocity().z);
                        break;
                    case "Verus":
                        if (mc.player.age % 2 == 0)
                            mc.player.setVelocity(mc.player.getVelocity().x, 0.42f, mc.player.getVelocity().z);
                        break;
                    case "Watchdog":
                        if (!MovementUtils.isMoving() && !mc.world.getBlockState(mc.player.getBlockPos().down()).isAir() && lastBlockCache != null) {
                            if (mc.player.age % 6 == 0) {
                                e.setX(centerX + 0.1);
                                e.setZ(centerZ + 0.1);
                            } else {
                                e.setX(centerX - 0.1);
                                e.setZ(centerZ - 0.1);
                            }
                            MovementUtils.setSpeed(0);
                        }

                        mc.player.setVelocity(mc.player.getVelocity().x, 0.3, mc.player.getVelocity().z);
                        e.setOnGround(true);
                        break;
                    case "NCP":
                        if (!MovementUtils.isMoving() || MovementUtils.getSpeed() < 0.16) {
                            if (mc.player.isOnGround()) {
                                mc.player.setVelocity(mc.player.getVelocity().x, 0.42, mc.player.getVelocity().z);
                            } else if (mc.player.getVelocity().y < 0.23) {
                                mc.player.setPosition(mc.player.getX(), (int) mc.player.getY(), mc.player.getZ());
                                mc.player.setVelocity(mc.player.getVelocity().x, 0.42, mc.player.getVelocity().z);
                            }
                        }
                        break;
                }
            }

            // Setting Block Cache
            blockCache = ScaffoldUtils.getBlockInfo();
            if (blockCache != null) {
                lastBlockCache = ScaffoldUtils.getBlockInfo();
            } else {
                return;
            }

            if (mc.player.age % 4 == 0) {
                pre = true;
            }

            // Placing Blocks (Pre)
            if (placeType.is("Pre") || (placeType.is("Dynamic") && pre)) {
                if (place()) {
                    pre = false;
                }
            }
        } else {
            // Setting Item Slot
            if (!itemSpoof.isEnabled()) {
                mc.player.getInventory().setSelectedSlot(slot);
            }

            // Placing Blocks (Post)
            if (placeType.is("Post") || (placeType.is("Dynamic") && !pre)) {
                place();
            }

            pre = false;
        }
    }

    private boolean place() {
        int slot = ScaffoldUtils.getBlockSlot();
        if (blockCache == null || lastBlockCache == null || slot == -1) return false;

        if (this.slot != slot) {
            this.slot = slot;
            PacketUtils.sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(this.slot));
        }

        boolean placed = false;
        if (delayTimer.hasTimeElapsed(delay.getValue() * 1000)) {
            firstJump = false;
            if (mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                    new BlockHitResult(ScaffoldUtils.getHypixelVec3(lastBlockCache),
                            lastBlockCache.getFacing(), lastBlockCache.getPosition(), false)).isAccepted()) {
                placed = true;
                y = MathUtils.getRandomInRange(79.5f, 83.5f);
                if (swing.isEnabled()) {
                    if (swingMode.is("Client")) {
                        mc.player.swingHand(Hand.MAIN_HAND);
                    } else {
                        PacketUtils.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
                    }
                }
            }
            delayTimer.reset();
            blockCache = null;
        }
        return placed;
    }

    @Override
    public void onBlockPlaceable(BlockPlaceableEvent event) {
        if (placeType.is("Legit")) {
            place();
        }
    }

    @Override
    public void onTickEvent(TickEvent event) {
        if (mc.player == null) return;
        if (hideJump.isEnabled() && !mc.options.jumpKey.isPressed() && MovementUtils.isMoving() && !mc.player.isOnGround() && autoJump.isEnabled()) {
            mc.player.setPosition(mc.player.getX(), mc.player.lastRenderY, mc.player.getZ());
            mc.player.lastY -= mc.player.getY() - mc.player.lastY;
            mc.player.setYaw(mc.player.getYaw() + 0.1f);
        }
        if (downwards.isEnabled()) {
            mc.options.sneakKey.setPressed(false);
            mc.player.setSneaking(false);
        }
    }

    @Override
    public void onDisable() {
        if (mc.player != null) {
            if (!itemSpoof.isEnabled()) mc.player.getInventory().setSelectedSlot(prevSlot);
            if (slot != mc.player.getInventory().getSelectedSlot() && itemSpoof.isEnabled())
                PacketUtils.sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().getSelectedSlot()));

            if (auto3rdPerson.isEnabled()) {
                mc.options.setPerspective(Perspective.FIRST_PERSON);
            }
            if (mc.player.isSneaking() && sneak.isEnabled())
                mc.options.sneakKey.setPressed(isKeyDown(mc.options.sneakKey));
        }
        TimerUtils.setTimerSpeed(1);
        super.onDisable();
    }

    @Override
    public void onEnable() {
        lastBlockCache = null;
        if (mc.player != null) {
            prevSlot = mc.player.getInventory().getSelectedSlot();
            slot = mc.player.getInventory().getSelectedSlot();
            if (mc.player.isSprinting() && sprint.isEnabled() && sprintMode.is("Cancel")) {
                PacketUtils.sendPacketNoEvent(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            }
            if (auto3rdPerson.isEnabled()) {
                mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            }
        }
        firstJump = true;
        speed = 1.1f;
        timerUtil.reset();
        jumpTimer = 0;
        y = 80;
        super.onEnable();
    }

    private void drawOutlinedString(String str, float x, float y, int color) {
        for (float ox = -1; ox <= 1; ox++) {
            for (float oy = -1; oy <= 1; oy++) {
                if (ox != 0 || oy != 0) {
                    ctx().drawTextWithShadow(mc.textRenderer, str, (int) (x + ox), (int) (y + oy), 0xFF000000);
                }
            }
        }
        ctx().drawTextWithShadow(mc.textRenderer, str, (int) x, (int) y, color);
    }

    public void renderCounterBlur() {
        if (!enabled && anim.isDone()) return;
        int slot = ScaffoldUtils.getBlockSlot();
        ItemStack heldItem = slot == -1 ? ItemStack.EMPTY : mc.player.getInventory().getStack(slot);
        int count = slot == -1 ? 0 : ScaffoldUtils.getBlockCount();
        String countStr = String.valueOf(count);
        TextRenderer fr = mc.textRenderer;
        int scaledWidth = ctx().getScaledWindowWidth(), scaledHeight = ctx().getScaledWindowHeight();
        int color;
        float x, y;
        String str = countStr + " block" + (count != 1 ? "s" : "");
        float output = anim.getOutput().floatValue();
        switch (countMode.getMode()) {
            case "Tenacity":
                float blockWH = !heldItem.isEmpty() ? 15 : -2;
                int spacing = 3;
                String text = "§l" + countStr + "§r block" + (count != 1 ? "s" : "");
                float textWidth = tenacityFont18().getStringWidthFloat(text);

                float totalWidth = ((textWidth + blockWH + spacing) + 6) * output;
                x = scaledWidth / 2f - (totalWidth / 2f);
                y = scaledHeight - (scaledHeight / 2f - 20);
                float height = 20;
                RenderUtil.scissorStart(x - 1.5, y - 1.5, totalWidth + 3, height + 3);

                RoundedUtil.drawRound(x, y, totalWidth, height, 5, Color.BLACK);
                RenderUtil.scissorEnd();
                break;
            case "Basic":
                x = scaledWidth / 2F - fr.getWidth(str) / 2F + 1;
                y = scaledHeight / 2F + 10;
                RenderUtil.scaleStart(scaledWidth / 2.0F, y + fr.fontHeight / 2.0F, output);
                ctx().drawTextWithShadow(fr, str, (int) x, (int) y, 0x000000);
                RenderUtil.scaleEnd();
                break;
            case "Polar":
                x = scaledWidth / 2F - fr.getWidth(countStr) / 2F + (!heldItem.isEmpty() ? 6 : 1);
                y = scaledHeight / 2F + 10;

                ctx().getMatrices().pushMatrix();
                ctx().getMatrices().translate(x + (heldItem.isEmpty() ? 1 : 0), y);
                ctx().getMatrices().scale(output, output);
                ctx().getMatrices().translate(-x - (heldItem.isEmpty() ? 1 : 0), -y);

                drawOutlinedString(countStr, x, y, ColorUtil.applyOpacity(0x000000, output));

                if (!heldItem.isEmpty()) {
                    double scale = 0.7;
                    ctx().getMatrices().pushMatrix();
                    ctx().getMatrices().scale((float) scale, (float) scale);
                    ctx().drawItem(heldItem,
                            (int) ((scaledWidth / 2F - fr.getWidth(countStr) / 2F - 7) / scale),
                            (int) ((scaledHeight / 2F + 8.5F) / scale));
                    ctx().getMatrices().popMatrix();
                }
                ctx().getMatrices().popMatrix();
                break;
        }
    }

    public void renderCounter() {
        anim.setDirection(enabled ? Direction.FORWARDS : Direction.BACKWARDS);
        if (!enabled && anim.isDone()) return;
        int slot = ScaffoldUtils.getBlockSlot();
        ItemStack heldItem = slot == -1 ? ItemStack.EMPTY : mc.player.getInventory().getStack(slot);
        int count = slot == -1 ? 0 : ScaffoldUtils.getBlockCount();
        String countStr = String.valueOf(count);
        TextRenderer fr = mc.textRenderer;
        int scaledWidth = ctx().getScaledWindowWidth(), scaledHeight = ctx().getScaledWindowHeight();
        int color;
        float x, y;
        String str = countStr + " block" + (count != 1 ? "s" : "");
        float output = anim.getOutput().floatValue();
        switch (countMode.getMode()) {
            case "Tenacity":
                float blockWH = !heldItem.isEmpty() ? 15 : -2;
                int spacing = 3;
                String text = "§l" + countStr + "§r block" + (count != 1 ? "s" : "");
                float textWidth = tenacityFont18().getStringWidthFloat(text);

                float totalWidth = ((textWidth + blockWH + spacing) + 6) * output;
                x = scaledWidth / 2f - (totalWidth / 2f);
                y = scaledHeight - (scaledHeight / 2f - 20);
                float height = 20;
                RenderUtil.scissorStart(x - 1.5, y - 1.5, totalWidth + 3, height + 3);

                RoundedUtil.drawRound(x, y, totalWidth, height, 5, ColorUtil.tripleColor(20, .45f));

                tenacityFont18().drawString(text, x + 3 + blockWH + spacing, y + tenacityFont18().getMiddleOfBox(height) + .5f, -1);

                if (!heldItem.isEmpty()) {
                    ctx().drawItem(heldItem, (int) x + 3, (int) (y + 10 - (blockWH / 2)));
                }
                RenderUtil.scissorEnd();
                break;
            case "Basic":
                x = scaledWidth / 2F - fr.getWidth(str) / 2F + 1;
                y = scaledHeight / 2F + 10;
                RenderUtil.scaleStart(scaledWidth / 2.0F, y + fr.fontHeight / 2.0F, output);
                ctx().drawTextWithShadow(fr, str, (int) x, (int) y, -1);
                RenderUtil.scaleEnd();
                break;
            case "Polar":
                color = count < 24 ? 0xFFFF5555 : count < 128 ? 0xFFFFFF55 : 0xFF55FF55;
                x = scaledWidth / 2F - fr.getWidth(countStr) / 2F + (!heldItem.isEmpty() ? 6 : 1);
                y = scaledHeight / 2F + 10;

                ctx().getMatrices().pushMatrix();
                ctx().getMatrices().translate(x + (heldItem.isEmpty() ? 1 : 0), y);
                ctx().getMatrices().scale(output, output);
                ctx().getMatrices().translate(-x - (heldItem.isEmpty() ? 1 : 0), -y);

                drawOutlinedString(countStr, x, y, ColorUtil.applyOpacity(color, output));

                if (!heldItem.isEmpty()) {
                    double scale = 0.7;
                    ctx().getMatrices().pushMatrix();
                    ctx().getMatrices().scale((float) scale, (float) scale);
                    ctx().drawItem(heldItem,
                            (int) ((scaledWidth / 2F - fr.getWidth(countStr) / 2F - 7) / scale),
                            (int) ((scaledHeight / 2F + 8.5F) / scale));
                    ctx().getMatrices().popMatrix();
                }
                ctx().getMatrices().popMatrix();
                break;
        }
    }

    @Override
    public void onPacketSendEvent(PacketSendEvent e) {
        if (e.getPacket() instanceof ClientCommandC2SPacket
                && ((ClientCommandC2SPacket) e.getPacket()).getMode() == ClientCommandC2SPacket.Mode.START_SPRINTING
                && sprint.isEnabled() && sprintMode.is("Cancel")) {
            e.cancel();
        }
        if (e.getPacket() instanceof UpdateSelectedSlotC2SPacket && itemSpoof.isEnabled()) {
            e.cancel();
        }
    }

    @Override
    public void onSafeWalkEvent(SafeWalkEvent event) {
        if ((safewalk.isEnabled() && !isDownwards()) || ScaffoldUtils.getBlockCount() == 0) {
            event.setSafe(true);
        }
    }

    public static boolean isDownwards() {
        return downwards.isEnabled() && isKeyDown(mc.options.sneakKey);
    }

}
