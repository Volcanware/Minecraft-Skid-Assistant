package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.render.ColorUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.awt.*;

public class ExhiTargetHUD extends TargetHUD {

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};

    public ExhiTargetHUD() {
        super("Exhibition");
    }

    @Override
    public void render(float x, float y, float alpha, LivingEntity target) {
        setWidth(Math.max(135, tenacityFont20().getStringWidthFloat("Name: " + "bruh") + 60));
        setHeight(46);

        Color darkest = ColorUtil.applyOpacity(new Color(10, 10, 10), alpha);
        Color secondDarkest = ColorUtil.applyOpacity(new Color(22, 22, 22), alpha);
        Color lightest = ColorUtil.applyOpacity(new Color(44, 44, 44), alpha);
        Color middleColor = ColorUtil.applyOpacity(new Color(34, 34, 34), alpha);
        Color textColor = ColorUtil.applyOpacity(Color.WHITE, alpha);
        fillRect(x - 3.5f, y - 3.5f, getWidth() + 7, getHeight() + 7, darkest.getRGB());
        fillRect(x - 3, y - 3, getWidth() + 6, getHeight() + 6, middleColor.getRGB());
        fillRect(x - 1, y - 1, getWidth() + 2, getHeight() + 2, lightest.getRGB());
        fillRect(x, y, getWidth(), getHeight(), secondDarkest.getRGB());


        float size = getHeight() - 6;
        fillRect(x + 3, y + 3, .5f, size, lightest.getRGB());
        fillRect(x + 3, y + 3 + size, size, .5f, lightest.getRGB());
        fillRect(x + 3 + size, y + 3, .5f, size + .5f, lightest.getRGB());
        fillRect(x + 3, y + 3, size, .5f, lightest.getRGB());

        tahomaFont.boldSize(16).drawString(target.getName().getString(), x + 8 + size, y + 6, textColor.getRGB());
        float healthValue = (target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount());

        Color healthColor = healthValue > .5f ? ColorUtil.interpolateColorC(new Color(255, 255, 10), new Color(10, 255, 10), (healthValue - .5f) / .5f) :
                ColorUtil.interpolateColorC(new Color(255, 10, 10), new Color(255, 255, 10), healthValue * 2);

        healthColor = ColorUtil.applyOpacity(healthColor, alpha);

        float healthBarWidth = getWidth() - (size + 12);
        fillRect(x + 8 + size, y + 15, healthBarWidth, 5, darkest.getRGB());
        fillRect(x + 8 + size + .5f, y + 15.5F, healthBarWidth - 1, 4, ColorUtil.interpolateColor(darkest, healthColor, .2f));

        float heathBarActualWidth = healthBarWidth - 1;
        fillRect(x + 8 + size + .5f, y + 15.5F, heathBarActualWidth * healthValue, 4, healthColor.getRGB());

        float increment = heathBarActualWidth / 11;
        for (int i = 1; i < 11; i++) {
            fillRect(x + 8 + size + (increment * i), y + 15.5F, .5f, 4, darkest.getRGB());
        }

        tahomaFont.size(12).drawString("HP: " + MathUtils.round(target.getHealth() + target.getAbsorptionAmount(), 1) + " | Dist: " + MathUtils.round(mc.player.distanceTo(target), 1),
                x + 8 + size, y + 25, textColor.getRGB());


        float seperation = healthBarWidth / 5;
        renderEntityOnScreen(x + 3 + size / 2f, y + size + 1, 18, target.getYaw(), -target.getPitch(), target);

        for (int i = 0; i <= 3; i++) {
            ItemStack armorPiece = target.getEquippedStack(ARMOR_SLOTS[i]);
            if (armorPiece.isEmpty()) continue;
            renderItemStack(armorPiece, (int) (x + size + 7 + (seperation * (3 - i))), (int) (y + 28));
        }

        ItemStack heldItem = target.getMainHandStack();
        if (!heldItem.isEmpty()) {
            renderItemStack(heldItem, (int) (x + size + 7 + (seperation * 4)), (int) (y + 28));
        }

    }


    @Override
    public void renderEffects(float x, float y, float alpha, boolean glow) {
        fillRect(x - 3.5f, y - 3.5f, getWidth() + 7, getHeight() + 7,
                ColorUtil.applyOpacity(Color.BLACK.getRGB(), alpha));
    }
}
