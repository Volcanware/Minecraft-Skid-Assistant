package dev.tenacity.module.impl.movement;

import dev.tenacity.event.impl.player.BoundingBoxEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import net.minecraft.util.math.Box;

public final class Jesus extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Verus");

    private boolean shouldJesus;

    public Jesus() {
        super("Jesus", Category.MOVEMENT, "Walks on water, like jesus");
        this.addSettings(mode);
    }

    @Override
    public void onBoundingBoxEvent(BoundingBoxEvent event) {
        if (!event.getBlock().getDefaultState().getFluidState().isEmpty()) {
            final Box axisAlignedBB = new Box(-5, -1, -5, 5, 1, 5).offset(event.getBlockPos().getX(), event.getBlockPos().getY(), event.getBlockPos().getZ());
            shouldJesus = true;
            event.setBoundingBox(axisAlignedBB);
        }
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        setSuffix(mode.getMode());
        if (event.isPre()) {
            if (shouldJesus) {
                switch (mode.getMode()) {
                    case "Verus":
                        if (mc.player.age % 5 == 0)
                            mc.player.setPosition(mc.player.getX(), mc.player.getY() + 0.1, mc.player.getZ());
                        break;
                }
            }
            shouldJesus = false;
        }
    }
}
