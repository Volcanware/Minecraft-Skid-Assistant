package dev.tenacity.module.impl.player;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.render.Render3DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.render.Breadcrumbs;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.server.PacketUtils;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class Blink extends Module {
    final ConcurrentLinkedQueue<Packet<?>> packets = new ConcurrentLinkedQueue<>();
    private final BooleanSetting pulse = new BooleanSetting("Pulse", false);
    private final NumberSetting delayPulse = new NumberSetting("Tick Delay", 20, 100, 4, 1);

    private OtherClientPlayerEntity blinkEntity;

    List<Vec3d> path = new ArrayList<>();

    public Blink() {
        super("Blink", Category.PLAYER, "holds movement packets");
        delayPulse.addParent(pulse, s -> s.isEnabled());
        this.addSettings(pulse, delayPulse);
    }

    @Override
    public void onPacketSendEvent(PacketSendEvent event) {
        if (mc.player == null || !mc.player.isAlive() || mc.isInSingleplayer() || mc.player.age < 50) {
            packets.clear();
            return;
        }

        if (event.getPacket() instanceof PlayerMoveC2SPacket) {
            packets.add(event.getPacket());
            event.cancel();
        }

        if (pulse.isEnabled()) {
            if (!packets.isEmpty() && mc.player.age % delayPulse.getIntValue() == 0 && Math.random() > 0.1) {
                packets.forEach(PacketUtils::sendPacketNoEvent);
                packets.clear();
            }
        }
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        if (event.isPre()) {
            if (mc.player.age < 50) return;

            if (mc.player.lastX != mc.player.getX() || mc.player.lastY != mc.player.getY() || mc.player.lastZ != mc.player.getZ()) {
                path.add(new Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ()));
            }

            if (pulse.isEnabled()) {
                while (path.size() > delayPulse.getIntValue()) {
                    path.remove(0);
                }
            }

            if (pulse.isEnabled() && blinkEntity != null) {
                mc.world.removeEntity(blinkEntity.getId(), Entity.RemovalReason.DISCARDED);
            }
        }
    }

    @Override
    public void onRender3DEvent(Render3DEvent event) {
        Tenacity.INSTANCE.getModuleCollection().getModule(Breadcrumbs.class).renderLine(path);
    }

    @Override
    public void onEnable() {
        path.clear();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        packets.forEach(PacketUtils::sendPacketNoEvent);
        packets.clear();
        super.onDisable();
    }
}
