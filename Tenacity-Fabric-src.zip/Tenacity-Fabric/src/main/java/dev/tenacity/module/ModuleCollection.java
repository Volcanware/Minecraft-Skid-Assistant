package dev.tenacity.module;

import dev.tenacity.Tenacity;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.misc.ChatUtil;
import dev.tenacity.utils.misc.Multithreading;
import dev.tenacity.utils.objects.Dragging;
import dev.tenacity.config.DragManager;

import java.io.File;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/** Set by config reloads; the Modern click GUI rebuilds its module rects when true. */
public class ModuleCollection implements Utils {

    /** Set by config reloads; the Modern click GUI rebuilds its module rects when true. */
    public static boolean reloadModules = false;

    private static List<Module> modules = new CopyOnWriteArrayList<>();

    /**
     * Every Tenacity module class, by simple name within dev.tenacity.module.impl.
     * Classes are instantiated reflectively so a missing/not-yet-ported module
     * is skipped at runtime instead of breaking the build.
     */
    private static final String[] MODULE_NAMES = {
            // combat
            "combat.AutoHead", "combat.AutoPot", "combat.Criticals", "combat.FastBow",
            "combat.IdleFighter", "combat.KeepSprint", "combat.KillAura", "combat.SuperKnockback",
            "combat.TargetStrafe", "combat.Velocity",
            // exploit
            "exploit.AntiAura", "exploit.AntiInvis", "exploit.Crasher", "exploit.Disabler",
            "exploit.Regen", "exploit.ResetVL", "exploit.TPAKiller",
            // misc
            "misc.AntiDesync", "misc.AntiFreeze", "misc.AntiTabComplete", "misc.AutoAuthenticate",
            "misc.AutoHypixel", "misc.AutoRespawn", "misc.HackerDetector", "misc.Killsults",
            "misc.LightningTracker", "misc.MCF", "misc.NoRotate", "misc.Sniper", "misc.Spammer",
            // movement
            "movement.AutoHeadHitter", "movement.FastLadder", "movement.Flight", "movement.InventoryMove",
            "movement.Jesus", "movement.LongJump", "movement.Scaffold", "movement.Speed",
            "movement.Spider", "movement.Sprint", "movement.Step",
            // player
            "player.AntiVoid", "player.AutoArmor", "player.AutoTool", "player.Blink",
            "player.ChestStealer", "player.FastPlace", "player.Freecam", "player.InvManager",
            "player.NoFall", "player.NoSlow", "player.SafeWalk", "player.SpeedMine", "player.Timer",
            // render
            "render.Ambience", "render.Animations", "render.ArrayListMod", "render.Breadcrumbs",
            "render.BrightPlayers", "render.Brightness", "render.Chams", "render.ChinaHat",
            "render.ClickGUIMod", "render.CustomModel", "render.ESP2D", "render.EntityEffects",
            "render.Glint", "render.GlowESP", "render.HUDMod", "render.Hitmarkers",
            "render.IRC", "render.ItemPhysics", "render.JumpCircle", "render.Keystrokes",
            "render.MotionGraph", "render.NoHurtCam", "render.NotificationsMod", "render.PlayerList",
            "render.PostProcessing", "render.Radar", "render.ScoreboardMod", "render.SpotifyMod",
            "render.Statistics", "render.Streamer", "render.TargetHUDMod", "render.XRay",
            "render.killeffects.KillEffects"
    };

    public void registerModules() {
        List<Module> loaded = new ArrayList<>();
        for (String name : MODULE_NAMES) {
            try {
                Class<?> clazz = Class.forName("dev.tenacity.module.impl." + name);
                loaded.add((Module) clazz.getDeclaredConstructor().newInstance());
            } catch (ClassNotFoundException e) {
                // not ported yet
            } catch (Exception e) {
                System.out.println("[Tenacity] Failed to load module " + name + ": " + e);
                Throwable cause = e instanceof java.lang.reflect.InvocationTargetException ? e.getCause() : e;
                if (cause != null) cause.printStackTrace();
            }
        }
        modules = loaded;

        loaded.forEach(Module::initModule);

        DragManager.loadDragData();
    }

    public List<Module> getModules() {
        return modules;
    }

    public Module get(Class<? extends Module> clazz) {
        return modules.stream().filter(module -> module.getClass() == clazz).findFirst().orElse(null);
    }

    public List<Module> getArraylistModules(dev.tenacity.module.impl.render.ArrayListMod arraylistMod, List<Module> into) {
        into.clear();
        for (Module m : modules) if (m.isEnabled()) into.add(m);
        into.sort(new SortModules());
        return into;
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T getModule(Class<T> clazz) {
        for (Module m : modules) if (clazz.isInstance(m)) return (T) m;
        return null;
    }

    public Module get(String name) {
        return modules.stream().filter(module -> module.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public List<Module> getModulesInCategory(Category c) {
        return modules.stream().filter(m -> m.getCategory() == c).collect(Collectors.toList());
    }

    /** Modules whose name contains the given text (case-insensitive); used by the Modern GUI search. */
    public List<Module> getModulesThatContainText(String text) {
        String needle = text.toLowerCase();
        return modules.stream().filter(m -> m.getName().toLowerCase().contains(needle)).collect(Collectors.toList());
    }

    public static class SortModules implements Comparator<Module>, Utils {
        public int compare(Module m1, Module m2) {
            if (tenacityBoldFont22().getStringWidthFloat(m1.getName()) > tenacityBoldFont22().getStringWidthFloat(m2.getName()))
                return -1;
            if (tenacityBoldFont22().getStringWidthFloat(m1.getName()) < tenacityBoldFont22().getStringWidthFloat(m2.getName()))
                return 1;
            return 0;
        }
    }
}
