package dev.tenacity.module.impl.render;

import dev.tenacity.utils.tuples.Pair;
import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.render.Render3DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.combat.KillAura;
import dev.tenacity.module.impl.movement.Scaffold;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ColorSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.ESPUtil;
import dev.tenacity.utils.render.WorldRenderUtil;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import java.awt.*;

public class ChinaHat extends Module {

    private final BooleanSetting firstPerson = new BooleanSetting("Show in first person", false);
    private final BooleanSetting allPlayers = new BooleanSetting("All players", false);
    private final ModeSetting colorMode = new ModeSetting("Color Mode", "Sync", "Sync", "Custom");
    private final ColorSetting color = new ColorSetting("Color", Color.WHITE);

    public ChinaHat() {
        super("ChinaHat", Category.RENDER, "epic hat");
        color.addParent(colorMode, modeSetting -> modeSetting.is("Custom"));
        this.addSettings(firstPerson, allPlayers, colorMode, color);
    }

    @Override
    public void onRender3DEvent(Render3DEvent event) {
        if (mc.player == null || mc.world == null) return;


        float partialTicks = event.getTicks();

        Vec3d cam = WorldRenderUtil.cameraPos();

        WorldRenderUtil.start3D();
        for (PlayerEntity player : mc.world.getPlayers()) {
            boolean self = player == mc.player;
            if ((!allPlayers.isEnabled() && !self) || (self && !firstPerson.isEnabled() && mc.options.getPerspective().isFirstPerson())
                    || !player.isAlive() || player.isInvisible() || (!self && (!ESPUtil.isInView(player) || !mc.player.canSee(player))))
                continue;

            WorldRenderUtil.matrices().push();

            Vec3d lerped = player.getLerpedPos(partialTicks);
            double posX = lerped.x - cam.x,
                    posY = lerped.y - cam.y,
                    posZ = lerped.z - cam.z;

            Box bb = player.getBoundingBox();

            boolean lowerHeight = CustomModel.enabled && !mc.options.getPerspective().isFirstPerson();
            double height = (lowerHeight ? -CustomModel.getYOffset() : 0) + bb.maxY - bb.minY + 0.02, radius = bb.maxX - bb.minX;

            float yaw = MathHelper.lerp(partialTicks, player.lastHeadYaw, player.headYaw);
            if (Tenacity.INSTANCE.isEnabled(KillAura.class) || Tenacity.INSTANCE.isEnabled(Scaffold.class)) {
                yaw = MathHelper.lerp(partialTicks,
                        MathHelper.wrapDegrees(player.lastHeadYaw), MathHelper.wrapDegrees(player.headYaw));
            }


            float pitch = MathHelper.lerp(partialTicks, player.lastPitch, player.getPitch());

            WorldRenderUtil.matrices().translate(0, posY + height, 0);

            if (self) WorldRenderUtil.matrices().multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
            WorldRenderUtil.matrices().multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch / 3f));
            WorldRenderUtil.matrices().translate(0, 0, pitch / 270.0);

            // outline/border or whatever you call it
            WorldRenderUtil.begin(RenderLayers.LINES);
            for (int i = 0; i <= 180; i++) {
                int color1 = getColor(i * 4, .5f).getRGB();
                WorldRenderUtil.color(color1);
                WorldRenderUtil.vertex(
                        posX - Math.sin(i * Math.PI * 2 / 90) * radius,
                        -(player.isSneaking() ? 0.2 : 0) - 0.002,
                        posZ + Math.cos(i * Math.PI * 2 / 90) * radius
                );
            }

            // draw hat
            WorldRenderUtil.begin(RenderLayers.debugTriangleFan());
            int color12 = getColor(4, .7f).getRGB();
            WorldRenderUtil.color(color12);
            WorldRenderUtil.vertex(posX, 0.3 - (player.isSneaking() ? 0.23 : 0), posZ);

            for (int i = 0; i <= 180; i++) {
                int color1 = getColor(i * 4, .2f).getRGB();
                WorldRenderUtil.color(color1);
                WorldRenderUtil.vertex(posX - Math.sin(i * Math.PI * 2 / 90) * radius,
                        -(player.isSneaking() ? 0.23F : 0),
                        posZ + Math.cos(i * Math.PI * 2 / 90) * radius
                );

            }
            WorldRenderUtil.color(color12);
            WorldRenderUtil.vertex(posX, 0.3 - (player.isSneaking() ? 0.23 : 0), posZ);
            WorldRenderUtil.matrices().pop();
        }

        WorldRenderUtil.end3D();
    }

    private Color getColor(int index, float alpha) {
        Color returnColor;
        if (colorMode.is("Custom")) {
            returnColor = color.isRainbow() ? color.getRainbow().getColor(index) : color.getColor();
        } else {
            final Pair<Color, Color> colors = HUDMod.getClientColors();
            if (isRainbowTheme()) {
                returnColor = HUDMod.color1.getRainbow().getColor(index);
            } else {
                returnColor = interpolateColorsBackAndForth(7, index, colors.getFirst(), colors.getSecond(), false);
            }
        }
        return ColorUtil.applyOpacity(returnColor, alpha);
    }

    private static boolean isRainbowTheme() {
        return HUDMod.theme.is("Custom Theme") && HUDMod.color1.isRainbow();
    }

    private static Color interpolateColorsBackAndForth(int speed, int index, Color start, Color end, boolean trueColor) {
        int angle = (int) (((System.currentTimeMillis()) / speed + index) % 360);
        angle = (angle >= 180 ? 360 - angle : angle) * 2;
        return ColorUtil.interpolateColorC(start, end, angle / 360f);
    }

}
