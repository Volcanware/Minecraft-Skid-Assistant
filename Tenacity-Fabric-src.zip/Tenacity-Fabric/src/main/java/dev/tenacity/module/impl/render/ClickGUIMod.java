package dev.tenacity.module.impl.render;

import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.ui.clickguis.compact.CompactClickgui;
import dev.tenacity.ui.clickguis.modern.ModernClickGui;
import dev.tenacity.ui.clickguis.dropdown.DropdownClickGUI;
import dev.tenacity.utils.render.Theme;
import org.lwjgl.glfw.GLFW;

public class ClickGUIMod extends Module {

    public static final ModeSetting clickguiMode = new ModeSetting("ClickGui", "Dropdown", "Dropdown", "Modern", "Compact");
    public static final ModeSetting scrollMode = new ModeSetting("Scroll Mode", "Screen Height", "Screen Height", "Value");
    public static final BooleanSetting gradient = new BooleanSetting("Gradient", false);
    public static final BooleanSetting outlineAccent = new BooleanSetting("Outline Accent", true);
    public static final BooleanSetting transparent = new BooleanSetting("Transparent", false);
    public static final BooleanSetting walk = new BooleanSetting("Allow Movement", true);
    public static final NumberSetting clickHeight = new NumberSetting("Tab Height", 250, 500, 100, 1);
    public static final BooleanSetting rescale = new BooleanSetting("Rescale GUI", true);

    public static final DropdownClickGUI dropdownClickGui = new DropdownClickGUI();
    public static final CompactClickgui compactClickgui = new CompactClickgui();
    public static final ModernClickGui modernClickGui = new ModernClickGui();

    private int activeCategory = 0;
    private Category activeCategory2 = Category.COMBAT;

    public ClickGUIMod() {
        super("ClickGUI", Category.RENDER, "Displays modules");
        clickHeight.addParent(scrollMode, selection -> selection.is("Value"));
        gradient.addParent(clickguiMode, selection -> selection.is("Dropdown") && !Theme.getCurrentTheme().isGradient());
        transparent.addParent(clickguiMode, selection -> selection.is("Dropdown"));
        outlineAccent.addParent(clickguiMode, selection -> selection.is("Dropdown"));
        scrollMode.addParent(clickguiMode, selection -> selection.is("Dropdown"));

        this.addSettings(clickguiMode, scrollMode, outlineAccent, gradient, transparent, walk, clickHeight, rescale);
        this.getKeybind().setCode(GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    @Override
    public void toggle() {
        this.onEnable();
    }

    @Override
    public void onEnable() {
        Module.allowedClickGuiHeight = scrollMode.is("Value") ? (float) clickHeight.getValue()
                : mc.getWindow().getScaledHeight() - 40;
        switch (clickguiMode.getMode()) {
            case "Modern": mc.setScreen(modernClickGui); break;
            case "Compact": mc.setScreen(compactClickgui); break;
            case "Dropdown":
            default: mc.setScreen(dropdownClickGui); break;
        }
    }

    public int getActiveCategoryy() { return activeCategory; }
    public Category getActiveCategory() { return activeCategory2; }
    public void setActiveCategory(int activeCategory) { this.activeCategory = activeCategory; }
    public void setActiveCategory(Category activeCategory) { this.activeCategory2 = activeCategory; }
}
