package dev.tenacity.module.impl.render;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.ModuleCollection;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.render.Theme;
import dev.tenacity.utils.tuples.Pair;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ArrayListMod extends Module {

    public dev.tenacity.utils.font.CustomFont font = dev.tenacity.utils.font.FontUtil.FontType.TENACITY.size(18);
    public java.util.List<Module> modules = new java.util.ArrayList<>();
    public String longest = "";
    public final dev.tenacity.module.settings.impl.NumberSetting height = new dev.tenacity.module.settings.impl.NumberSetting("Height", 11, 20, 8, 1);

    private final ModeSetting rectangleMode = new ModeSetting("Rectangle", "None", "None", "Top", "Side", "Outline", "Background");
    private final ModeSetting textColor = new ModeSetting("Text Color", "Tenacity", "Tenacity", "Theme", "Rainbow", "Category", "White");
    private final BooleanSetting background = new BooleanSetting("Background", true);
    private final ModeSetting animation = new ModeSetting("Animation", "Move in", "Move in", "Scale in");
    private final BooleanSetting important = new BooleanSetting("Show Keybinds", true);

    public ArrayListMod() {
        super("ArrayList", Category.RENDER, "Shows enabled modules");
        this.addSettings(rectangleMode, textColor, background, animation, important);
    }

    @Override
    public void onRender2DEvent(Render2DEvent e) {
        Pair<Color, Color> clientColors = HUDMod.getClientColors();
        Theme theme = Theme.getCurrentTheme();

        List<Module> modules = Tenacity.INSTANCE.getModuleCollection().getModules().stream()
                .filter(Module::isEnabled)
                .sorted(Comparator.comparingDouble(m -> -tenacityBoldFont20().getStringWidthFloat(((Module) m).getDisplayName())))
                .collect(Collectors.toList());

        float yOffset = 4;
        for (Module module : modules) {
            String name = module.getDisplayName();
            if (HUDMod.isLowercase()) name = name.toLowerCase();
            float width = tenacityBoldFont20().getStringWidthFloat(name) + 6;
            float x = ctx().getScaledWindowWidth() - width - 4;

            if (background.isEnabled()) {
                RoundedUtil.drawRound(x, yOffset, width, 12, 2,
                        ColorUtil.applyOpacity(new Color(10, 10, 10), .6f));
            }

            Color textC = switch (textColor.getMode()) {
                case "Theme" -> theme.getColors().getFirst();
                case "Rainbow" -> ColorUtil.rainbow(15, (int) yOffset * 2, 1f, 1f, 1f);
                case "Category" -> theme.getColors().getFirst();
                case "White" -> Color.WHITE;
                default -> clientColors.getFirst();
            };
            tenacityBoldFont20().drawString(name, x + 3, yOffset + 3, textC.getRGB());

            switch (rectangleMode.getMode()) {
                case "Side" -> RenderUtil.drawRect(x - 2, yOffset, 2, 12, clientColors.getFirst().getRGB());
                case "Top" -> RenderUtil.drawRect(x, yOffset - 1, width, 1, clientColors.getFirst().getRGB());
                case "Outline" -> RenderUtil.drawBorderedRect(x, yOffset, width, 12, .5f,
                        ColorUtil.applyOpacity(Color.BLACK, .6f).getRGB(), clientColors.getFirst().getRGB());
            }

            yOffset += 13;
        }
    }
}
