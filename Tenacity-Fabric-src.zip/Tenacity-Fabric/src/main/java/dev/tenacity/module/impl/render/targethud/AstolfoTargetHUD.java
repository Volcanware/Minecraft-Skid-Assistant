package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.utils.animations.ContinualAnimation;
import dev.tenacity.utils.render.ColorUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

import java.awt.*;
import java.text.DecimalFormat;

public class AstolfoTargetHUD extends TargetHUD {

    private final ContinualAnimation animation = new ContinualAnimation();
    private final DecimalFormat DF_1O = new DecimalFormat("0.#");

    public AstolfoTargetHUD() {
        super("Astolfo");
    }

    @Override
    public void render(float x, float y, float alpha, LivingEntity target) {
        float width = Math.max(110, fr.getWidth(target.getName().getString()) + 70);
        double healthPercentage = MathHelper.clamp((target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0, 1);
        setWidth(width);
        setHeight(45);

        Color c1 = ColorUtil.applyOpacity(HUDMod.getClientColors().getFirst(), alpha);
        Color c2 = ColorUtil.applyOpacity(HUDMod.getClientColors().getSecond(), alpha);
        int textColor = ColorUtil.applyOpacity(-1, alpha);

        // Draw background
        fillRect(x, y, width, 45, new Color(0, 0, 0, (0.6F * alpha)).getRGB());

        // Draw health bar (high quality code)
        gradientRectLR(x + 34, y + 33, x + width - 4, y + 40, c1.darker().darker().darker().darker().getRGB(), c2.darker().darker().darker().darker().getRGB());

        // damage anim
        float endWidth = (float) Math.max(0, (width - 34) * healthPercentage);
        animation.animate(endWidth, 18);
        float healthWidth = animation.getOutput();

        gradientRectLR(x + 34, y + 33, x + 30 + healthWidth, y + 40, c1.darker().darker().getRGB(), c2.darker().darker().getRGB());
        gradientRectLR(x + 34, y + 33, x + 30 + Math.min(endWidth, healthWidth), y + 40, c1.getRGB(), c2.getRGB());

        // Draw player
        renderEntityOnScreen(x + 17, y + 40, 18, target.getYaw(), target.getPitch(), target);

        // Draw name
        drawStringWithShadow(target.getName().getString(), x + 34, y + 4, ColorUtil.applyOpacity(-1, (float) Math.max(.1, alpha)));

        // Draw health
        float scale = 1.75F;
        org.joml.Matrix3x2fStack matrices = ctx().getMatrices();
        matrices.pushMatrix();
        matrices.scale(scale, scale);
        drawStringWithShadow(DF_1O.format(target.getHealth()) + " ❤", (x + 34) / scale, (y + 16) / scale,
                ColorUtil.applyOpacity(HUDMod.getClientColors().getFirst(), (float) Math.max(.1, alpha)).getRGB());
        matrices.popMatrix();
    }


    @Override
    public void renderEffects(float x, float y, float alpha, boolean glow) {
        fillRect(x, y, getWidth(), 45, ColorUtil.applyOpacity(Color.BLACK.getRGB(), alpha));
    }

}
