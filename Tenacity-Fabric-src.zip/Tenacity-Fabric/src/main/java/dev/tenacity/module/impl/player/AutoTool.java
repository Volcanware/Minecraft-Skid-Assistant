package dev.tenacity.module.impl.player;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.combat.KillAura;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.utils.player.InventoryUtils;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public class AutoTool extends Module {

    private final BooleanSetting autoSword = new BooleanSetting("AutoSword", true);

    public AutoTool() {
        super("AutoTool", Category.PLAYER, "switches to the best tool");
        this.addSettings(autoSword);
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        if (e.isPre()) {
            if (mc.crosshairTarget != null && mc.options.attackKey.isPressed()) {
                HitResult objectMouseOver = mc.crosshairTarget;
                if (objectMouseOver.getType() == HitResult.Type.ENTITY) {
                    switchSword();
                } else if (objectMouseOver.getType() == HitResult.Type.BLOCK) {
                    BlockState state = mc.world.getBlockState(((BlockHitResult) objectMouseOver).getBlockPos());
                    updateItem(state);
                }
            } else if (KillAura.target != null) {
                switchSword();
            }
        }
    }

    private void updateItem(BlockState state) {
        float strength = 1.0F;
        int bestItem = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack itemStack = mc.player.getInventory().getStack(i);
            if (itemStack.isEmpty()) {
                continue;
            }
            float strVsBlock = itemStack.getMiningSpeedMultiplier(state);
            if (strVsBlock > strength) {
                strength = strVsBlock;
                bestItem = i;
            }
        }
        if (bestItem != -1) {
            mc.player.getInventory().setSelectedSlot(bestItem);
        }
    }

    private void switchSword() {
        if (!autoSword.isEnabled()) return;
        float damage = 1;
        int bestItem = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack is = mc.player.getInventory().getStack(i);
            if (!is.isEmpty() && is.isIn(ItemTags.SWORDS) && InventoryUtils.getSwordStrength(is) > damage) {
                damage = InventoryUtils.getSwordStrength(is);
                bestItem = i;
            }
        }
        if (bestItem != -1) {
            mc.player.getInventory().setSelectedSlot(bestItem);
        }
    }

}
