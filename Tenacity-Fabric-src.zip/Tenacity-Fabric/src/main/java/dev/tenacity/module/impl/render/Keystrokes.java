package dev.tenacity.module.impl.render;

import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;

import java.awt.*;

public class Keystrokes extends Module {

    private float x = 10, y = 200;

    public Keystrokes() {
        super("Keystrokes", Category.RENDER, "Shows WASD/mouse presses");
    }

    @Override
    public void onRender2DEvent(Render2DEvent e) {
        float size = 18, gap = 2;
        String[] keys = {"W", "A", "S", "D"};
        boolean[] pressed = {
                mc.options.forwardKey.isPressed(), mc.options.leftKey.isPressed(),
                mc.options.backKey.isPressed(), mc.options.rightKey.isPressed()};
        float[] xs = {x + size + gap, x, x + size + gap, x + 2 * (size + gap)};
        float[] ys = {y, y + size + gap, y + size + gap, y + size + gap};

        for (int i = 0; i < 4; i++) {
            RoundedUtil.drawRound(xs[i], ys[i], size, size, 3,
                    ColorUtil.applyOpacity(pressed[i] ? new Color(200, 200, 200) : new Color(30, 30, 30), .7f));
            tenacityFont18().drawCenteredString(keys[i], xs[i] + size / 2, ys[i] + 5,
                    pressed[i] ? Color.BLACK.getRGB() : Color.WHITE.getRGB());
        }
    }
}
