package dev.tenacity.module.impl.render.killeffects;

import dev.tenacity.event.impl.game.WorldEvent;
import dev.tenacity.event.impl.player.ChatReceivedEvent;
import dev.tenacity.event.impl.player.LivingDeathEvent;
import dev.tenacity.event.impl.render.RendererLivingEntityEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Formatting;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author senoe
 * @since 6/14/2022
 */
public class KillEffects extends Module {

    public static final ModeSetting killEffect = new ModeSetting("Kill Effect", "Blood Explosion", "Blood Explosion", "Lightning Bolt");
    private final Map<String, Location> players = new ConcurrentHashMap<>();
    private final EffectManager effectManager = new EffectManager();

    public KillEffects() {
        super("KillEffects", Category.RENDER, "Plays animation on killing another player");
        addSettings(killEffect);
    }

    @Override
    public void onLivingDeathEvent(LivingDeathEvent event) {
        if (event.getSource().getAttacker() != null && event.getSource().getAttacker().equals(mc.player) && event.getEntity() != mc.player) {
            String name = event.getEntity().getName().getString();
            Location location = players.remove(name);
            if (location != null) {
                effectManager.playKillEffect(location);
            } else {
                LivingEntity ent = event.getEntity();
                effectManager.playKillEffect(new Location(ent.getX(), ent.getY(), ent.getZ(), ent.getStandingEyeHeight()));
            }
        }
    }

    @Override
    public void onChatReceivedEvent(ChatReceivedEvent event) {
        String message = Formatting.strip(event.message.getString());
        if (mc.player != null && !message.contains(":") && message.contains("by " + mc.player.getName().getString())) {
            String killedPlayer = message.trim().split(" ")[0];
            Location location = players.remove(killedPlayer);
            if (location != null) {
                effectManager.playKillEffect(location);
            }
        }
    }

    @Override
    public void onRendererLivingEntityEvent(RendererLivingEntityEvent event) {
        if (event.isPost() && event.getEntity() instanceof PlayerEntity && event.getEntity() != mc.player) {
            LivingEntity ent = event.getEntity();
            players.put(ent.getName().getString(), new Location(ent.getX(), ent.getY(), ent.getZ(), ent.getStandingEyeHeight()));
        }
    }

    @Override
    public void onWorldEvent(WorldEvent event) {
        players.clear();
    }

    public static class Location {
        public double x, y, z, eyeHeight;

        public Location(double x, double y, double z, double eyeHeight) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.eyeHeight = eyeHeight;
        }
    }

}
