package dev.tenacity.module.impl.player;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.player.InventoryUtils;
import dev.tenacity.utils.player.ItemUtils;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;

public class AutoArmor extends Module {

    private final NumberSetting delay = new NumberSetting("Delay", 150, 300, 0, 10);
    private final BooleanSetting onlyWhileNotMoving = new BooleanSetting("Stop when moving", false);
    private final BooleanSetting invOnly = new BooleanSetting("Inventory only", false);
    private final TimerUtil timer = new TimerUtil();

    public AutoArmor() {
        super("AutoArmor", Category.PLAYER, "Automatically equips armor");
        this.addSettings(delay, onlyWhileNotMoving, invOnly);
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        if (e.isPost()) return;
        if ((invOnly.isEnabled() && !(mc.currentScreen instanceof InventoryScreen)) || (onlyWhileNotMoving.isEnabled() && MovementUtils.isMoving())) {
            return;
        }
        if (mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
            // so it doesn't put on armor immediately after closing a chest
            timer.reset();
        }
        if (timer.hasTimeElapsed((long) delay.getValue())) {
            for (int armorSlot = 5; armorSlot < 9; armorSlot++) {
                if (equipBest(armorSlot)) {
                    timer.reset();
                    break;
                }
            }
        }
    }

    private boolean equipBest(int armorSlot) {
        int equipSlot = -1, currProt = -1;
        ItemStack currItem = null;
        ItemStack slotStack = mc.player.playerScreenHandler.getSlot(armorSlot).getStack();
        if (!slotStack.isEmpty() && ItemUtils.isArmorFor(slotStack, ItemUtils.getArmorEquipmentSlot(armorSlot - 4))) {
            currItem = slotStack;
            currProt = (int) (ItemUtils.getAttributeValue(slotStack, EntityAttributes.ARMOR)
                    + ItemUtils.getEnchantLevel(slotStack, Enchantments.PROTECTION));
        }
        // find best piece
        for (int i = 9; i < 45; i++) {
            ItemStack is = mc.player.playerScreenHandler.getSlot(i).getStack();
            if (!is.isEmpty() && ItemUtils.isArmorFor(is, ItemUtils.getArmorEquipmentSlot(armorSlot - 4))) {
                int prot = (int) (ItemUtils.getAttributeValue(is, EntityAttributes.ARMOR) + ItemUtils.getEnchantLevel(is, Enchantments.PROTECTION));
                if ((currItem == null || currProt < prot)) {
                    currItem = is;
                    equipSlot = i;
                    currProt = prot;
                }
            }
        }
        // equip best piece (if there is a better one)
        if (equipSlot != -1) {
            if (!slotStack.isEmpty()) {
                InventoryUtils.drop(armorSlot);
            } else {
                InventoryUtils.click(equipSlot, 0, true);
            }
            return true;
        }
        return false;
    }

}
