package dev.tenacity.module.impl.player;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.mixin.MinecraftClientAccessor;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import net.minecraft.item.BlockItem;
import net.minecraft.item.EggItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SnowballItem;

public final class FastPlace extends Module {

    private final NumberSetting ticks = new NumberSetting("Ticks", 0, 4, 0, 1);
    private final BooleanSetting blocks = new BooleanSetting("Blocks", true);
    private final BooleanSetting projectiles = new BooleanSetting("Projectiles", true);

    @Override
    public void onMotionEvent(MotionEvent event) {
        if (canFastPlace()) {
            MinecraftClientAccessor accessor = (MinecraftClientAccessor) mc;
            accessor.tenacity$setItemUseCooldown(Math.min(accessor.tenacity$getItemUseCooldown(), ticks.getIntValue()));
        }
    }

    @Override
    public void onDisable() {
        ((MinecraftClientAccessor) mc).tenacity$setItemUseCooldown(4);
        super.onDisable();
    }

    private boolean canFastPlace() {
        if (mc.player == null) return false;
        ItemStack heldStack = mc.player.getMainHandStack();
        if (heldStack.isEmpty()) return false;
        Item heldItem = heldStack.getItem();
        return (blocks.isEnabled() && heldItem instanceof BlockItem) || (projectiles.isEnabled() && (heldItem instanceof SnowballItem || heldItem instanceof EggItem));
    }

    public FastPlace() {
        super("FastPlace", Category.PLAYER, "place blocks fast");
        this.addSettings(ticks, blocks, projectiles);
    }

}
