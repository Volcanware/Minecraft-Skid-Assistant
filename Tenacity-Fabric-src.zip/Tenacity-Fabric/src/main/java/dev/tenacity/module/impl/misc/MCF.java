package dev.tenacity.module.impl.misc;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.game.TickEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.ui.notifications.NotificationType;
import dev.tenacity.utils.misc.FriendUtils;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

public class MCF extends Module {

    private boolean wasDown;

    public MCF() {
        super("MCF", Category.MISC, "middle click friends");
    }

    @Override
    public void onTickEvent(TickEvent event) {
        if (mc.currentScreen == null) {
            boolean down = mc.options.pickItemKey.isPressed();
            if (down && !wasDown) {
                if (mc.crosshairTarget instanceof EntityHitResult
                        && ((EntityHitResult) mc.crosshairTarget).getEntity() instanceof PlayerEntity) {
                    PlayerEntity player = (PlayerEntity) ((EntityHitResult) mc.crosshairTarget).getEntity();
                    String name = player.getName().getString();
                    if (FriendUtils.isFriend(name)) {
                        FriendUtils.getFriends().removeIf(f -> f.equalsIgnoreCase(name));
                        Tenacity.INSTANCE.getNotificationManager().post(NotificationType.SUCCESS, "Friend Manager", "You are no longer friends with " + name + "!", 2);
                    } else {
                        FriendUtils.getFriends().add(name);
                        Tenacity.INSTANCE.getNotificationManager().post(NotificationType.SUCCESS, "Friend Manager", "You are now friends with " + name + "!", 2);
                    }
                    FriendUtils.save();
                    wasDown = true;
                }
            } else if (!down) {
                wasDown = false;
            }
        }
    }

}
