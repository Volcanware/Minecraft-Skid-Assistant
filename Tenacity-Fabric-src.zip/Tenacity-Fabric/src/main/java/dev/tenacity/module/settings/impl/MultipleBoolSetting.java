package dev.tenacity.module.settings.impl;

import dev.tenacity.module.settings.Setting;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.stream.Collectors;

public class MultipleBoolSetting extends Setting {

    private final HashMap<String, BooleanSetting> booleanSettings = new HashMap<>();

    public MultipleBoolSetting(String name, String... booleanSettingNames) {
        this(name, Arrays.stream(booleanSettingNames).map(s -> new BooleanSetting(s, false)).toArray(BooleanSetting[]::new));
    }

    public MultipleBoolSetting(String name, BooleanSetting... booleanSettings) {
        this.name = name;
        for (BooleanSetting setting : booleanSettings) {
            this.booleanSettings.put(setting.getName(), setting);
        }
    }

    public BooleanSetting getSetting(String settingName) {
        return booleanSettings.get(settingName);
    }

    public boolean isEnabled(String settingName) {
        BooleanSetting setting = booleanSettings.get(settingName);
        return setting != null && setting.isEnabled();
    }

    public Collection<BooleanSetting> getBoolSettings() {
        return booleanSettings.values();
    }

    @Override
    public HashMap<String, Boolean> getConfigValue() {
        return booleanSettings.values().stream().collect(Collectors.toMap(
                Setting::getName, BooleanSetting::isEnabled, (a, b) -> a, HashMap::new));
    }
}
