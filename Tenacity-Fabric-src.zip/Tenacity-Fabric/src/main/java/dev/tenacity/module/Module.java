package dev.tenacity.module;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import dev.tenacity.Tenacity;
import dev.tenacity.config.ConfigSetting;
import dev.tenacity.event.ListenerAdapter;
import dev.tenacity.module.impl.render.NotificationsMod;
import dev.tenacity.module.settings.Setting;
import dev.tenacity.module.settings.impl.*;
import dev.tenacity.ui.notifications.NotificationType;
import dev.tenacity.utils.Utils;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.misc.Multithreading;
import org.lwjgl.glfw.GLFW;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;

public class Module extends ListenerAdapter implements Utils {

    @Expose
    @SerializedName("name")
    private final String name;
    private final String description;
    private final Category category;
    private final CopyOnWriteArrayList<Setting> settingsList = new CopyOnWriteArrayList<>();
    private String suffix;
    private String author = "";

    @Expose
    @SerializedName("toggled")
    protected boolean enabled;
    @Expose
    @SerializedName("settings")
    public ConfigSetting[] cfgSettings;

    private boolean expanded;
    private final Animation animation = new DecelerateAnimation(250, 1).setDirection(Direction.BACKWARDS);

    public static int categoryCount;
    public static float allowedClickGuiHeight = 300;

    private final KeybindSetting keybind = new KeybindSetting(GLFW.GLFW_KEY_UNKNOWN);

    public Module(String name, Category category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
        addSettings(keybind);
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public List<Setting> getSettingsList() { return settingsList; }
    public String getSuffix() { return suffix; }
    public void setSuffix(String suffix) { this.suffix = suffix; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public boolean isEnabled() { return enabled; }
    public boolean isExpanded() { return expanded; }
    public void setExpanded(boolean expanded) { this.expanded = expanded; }
    public Animation getAnimation() { return animation; }
    public KeybindSetting getKeybind() { return keybind; }

    public boolean isInGame() {
        return mc.world != null && mc.player != null;
    }

    public void addSettings(Setting... settings) {
        settingsList.addAll(Arrays.asList(settings));
    }

    public void setToggled(boolean toggled) {
        this.enabled = toggled;
        if (toggled) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    public void toggleSilent() {
        this.enabled = !this.enabled;
        if (this.enabled) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    public void toggleSilent(boolean toggled) {
        this.enabled = toggled;
        if (this.enabled) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    public void toggle() {
        this.enabled = !this.enabled;
        if (this.enabled) {
            Tenacity.INSTANCE.getEventProtocol().register(this);
            onEnable();
            if (Tenacity.INSTANCE.getNotificationManager() != null && NotificationsMod.isToggled()
                    && !this.getClass().equals(NotificationsMod.class)) {
                Tenacity.INSTANCE.getNotificationManager().post(NotificationType.SUCCESS, "Module Toggle",
                        getName() + " was enabled", 2);
            }
        } else {
            Tenacity.INSTANCE.getEventProtocol().unregister(this);
            onDisable();
            if (Tenacity.INSTANCE.getNotificationManager() != null && NotificationsMod.isToggled()
                    && !this.getClass().equals(NotificationsMod.class)) {
                Tenacity.INSTANCE.getNotificationManager().post(NotificationType.DISABLE, "Module Toggle",
                        getName() + " was disabled", 2);
            }
        }
    }

    public String getDisplayName() {
        return author.isEmpty() ? name : name + " " + author;
    }

    public void initModule() {
        this.enabled = false;
    }

    public void setToggledSilently(boolean toggled) {
        this.enabled = toggled;
    }

    public void onEnable() {}

    public void onDisable() {}

    protected void onModuleDisabled(Runnable runnable) {
        Multithreading.schedule(runnable, 0, TimeUnit.MILLISECONDS);
    }
}
