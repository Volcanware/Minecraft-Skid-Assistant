package dev.tenacity.module.impl.render;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.game.WorldEvent;
import dev.tenacity.event.impl.render.Render3DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.ParentAttribute;
import dev.tenacity.module.settings.impl.*;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.ESPUtil;
import dev.tenacity.utils.tuples.Pair;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GlowESP extends Module {

    private final BooleanSetting kawaseGlow = new BooleanSetting("Kawase Glow", false);
    private final ModeSetting colorMode = new ModeSetting("Color Mode", "Sync", "Sync", "Random", "Custom");
    private final MultipleBoolSetting validEntities = new MultipleBoolSetting("Entities",
            new BooleanSetting("Players", true),
            new BooleanSetting("Animals", true),
            new BooleanSetting("Mobs", true),
            new BooleanSetting("Chests", true));
    private final ColorSetting playerColor = new ColorSetting("Player Color", Tenacity.INSTANCE.getClientColor());
    private final ColorSetting animalColor = new ColorSetting("Animal Color", Tenacity.INSTANCE.getAlternateClientColor());
    private final ColorSetting mobColor = new ColorSetting("Mob Color", Color.RED);
    private final ColorSetting chestColor = new ColorSetting("Chest Color", Color.GREEN);
    private final ColorSetting hurtTimeColor = new ColorSetting("Hurt Time Color", Color.RED);
    private final NumberSetting radius = new NumberSetting("Radius", 4, 20, 2, 2);
    private final NumberSetting iterationsSetting = new NumberSetting("Iterations", 4, 10, 2, 1);
    private final NumberSetting offsetSetting = new NumberSetting("Offset", 4, 10, 2, 1);
    private final NumberSetting exposure = new NumberSetting("Exposure", 2.2, 3.5, .5, .1);
    private final BooleanSetting seperate = new BooleanSetting("Seperate Texture", false);

    public GlowESP() {
        super("GlowESP", Category.RENDER, "ESP that glows on players");
        playerColor.addParent(colorMode, modeSetting -> modeSetting.is("Custom") && validEntities.getSetting("Players").isEnabled());
        animalColor.addParent(colorMode, modeSetting -> modeSetting.is("Custom") && validEntities.getSetting("Animals").isEnabled());
        mobColor.addParent(colorMode, modeSetting -> modeSetting.is("Custom") && validEntities.getSetting("Mobs").isEnabled());
        chestColor.addParent(colorMode, modeSetting -> modeSetting.is("Custom") && validEntities.getSetting("Chests").isEnabled());

        radius.addParent(kawaseGlow, ParentAttribute.BOOLEAN_CONDITION.negate());
        iterationsSetting.addParent(kawaseGlow, ParentAttribute.BOOLEAN_CONDITION);
        offsetSetting.addParent(kawaseGlow, ParentAttribute.BOOLEAN_CONDITION);
        addSettings(kawaseGlow, colorMode, validEntities, playerColor, animalColor, mobColor, chestColor, hurtTimeColor, iterationsSetting, offsetSetting, radius, exposure, seperate);
    }

    public static boolean renderNameTags = true;
    public static boolean renderGlint = true;

    public final List<Entity> entities = new ArrayList<>();
    private final Map<Object, Color> entityColorMap = new HashMap<>();
    private final java.util.Set<Entity> glowingEntities = new java.util.HashSet<>();

    public static Animation fadeIn;

    @Override
    public void onWorldEvent(WorldEvent event) {
        entityColorMap.clear();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        entityColorMap.clear();
        fadeIn = new DecelerateAnimation(250, 1, Direction.FORWARDS);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        for (Entity e : glowingEntities) {
            if (e != null) e.setGlowing(false);
        }
        glowingEntities.clear();
        entities.clear();
    }

    public Color getColorFor(Entity entity) {
        return getColor(entity);
    }

    @Override
    public void onRender3DEvent(Render3DEvent event) {
        collectEntities();
        // Vanilla outline glow: flag the entities glowing; EntityMixin supplies
        // the per-entity accent color via getTeamColorValue.
        for (Entity e : glowingEntities) {
            if (e != null && !entities.contains(e)) e.setGlowing(false);
        }
        glowingEntities.removeIf(e -> e == null || !entities.contains(e));
        for (Entity e : entities) {
            if (e == null || e.isRemoved()) continue;
            e.setGlowing(true);
            glowingEntities.add(e);
        }
    }

    private Color getColor(Object entity) {
        Color color = Color.WHITE;
        switch (colorMode.getMode()) {
            case "Custom":
                if (entity instanceof PlayerEntity) {
                    color = playerColor.getColor();
                }
                if (entity instanceof HostileEntity) {
                    color = mobColor.getColor();
                }
                if (entity instanceof AnimalEntity) {
                    color = animalColor.getColor();
                }
                if (entity instanceof ChestBlockEntity) {
                    color = chestColor.getColor();
                }
                break;
            case "Sync":
                Pair<Color, Color> colors = HUDMod.getClientColors();
                if (HUDMod.theme.is("Custom Theme") && HUDMod.color1.isRainbow()) {
                    color = colors.getFirst();
                } else {
                    color = ColorUtil.interpolateColorsBackAndForth(15, 0, colors.getFirst(), colors.getSecond(), false);
                }
                break;
            case "Random":
                if (entityColorMap.containsKey(entity)) {
                    color = entityColorMap.get(entity);
                } else {
                    color = ColorUtil.getRandomColor();
                    entityColorMap.put(entity, color);
                }
                break;
        }

        if (entity instanceof LivingEntity entityLivingBase) {
            if (entityLivingBase.hurtTime > 0) {
                color = ColorUtil.interpolateColorC(color, hurtTimeColor.getColor(), (float) Math.sin(entityLivingBase.hurtTime * (18 * Math.PI / 180)));
            }
        }

        return color;
    }

    public void collectEntities() {
        entities.clear();
        for (Entity entity : mc.world.getEntities()) {
            if (!ESPUtil.isInView(entity)) continue;
            if (entity == mc.player && mc.options.getPerspective().isFirstPerson()) continue;
            if (entity instanceof AnimalEntity && validEntities.getSetting("Animals").isEnabled()) {
                entities.add(entity);
            }
            if (entity instanceof PlayerEntity && validEntities.getSetting("Players").isEnabled()) {
                entities.add(entity);
            }
            if (entity instanceof HostileEntity && validEntities.getSetting("Mobs").isEnabled()) {
                entities.add(entity);
            }
        }
    }
}
