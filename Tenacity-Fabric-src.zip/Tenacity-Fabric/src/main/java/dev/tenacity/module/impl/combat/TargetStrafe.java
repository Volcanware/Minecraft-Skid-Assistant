package dev.tenacity.module.impl.combat;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.MoveEvent;
import dev.tenacity.event.impl.render.Render3DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.movement.Flight;
import dev.tenacity.module.impl.movement.Speed;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ColorSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.player.RotationUtils;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.server.ServerUtils;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class TargetStrafe extends Module {

    private static final MultipleBoolSetting adaptiveSettings = new MultipleBoolSetting("Adaptive",
            new BooleanSetting("Edges", false),
            new BooleanSetting("Behind", false),
            new BooleanSetting("Liquids", false),
            new BooleanSetting("Controllable", true)
    );
    public static final NumberSetting radius = new NumberSetting("Radius", 2, 8, 0.5, 0.5);
    private static final NumberSetting points = new NumberSetting("Points", 12, 16, 3, 1);
    public static final BooleanSetting space = new BooleanSetting("Require space key", true);
    public static final BooleanSetting auto3rdPerson = new BooleanSetting("Auto 3rd Person", false);
    private final BooleanSetting render = new BooleanSetting("Render", true);
    private final ColorSetting color = new ColorSetting("Color", new Color(-16711712));

    private static int strafe = 1;
    private static int position;

    private final DecelerateAnimation animation = new DecelerateAnimation(250, radius.getValue(), Direction.FORWARDS);
    private boolean returnState;

    public TargetStrafe() {
        super("TargetStrafe", Category.COMBAT, "strafe around targets");
        addSettings(adaptiveSettings, radius, points, space, auto3rdPerson, render, color);
        color.addParent(render, r -> render.isEnabled());
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        if (canStrafe()) {
            if (auto3rdPerson.isEnabled() && mc.options.getPerspective().isFirstPerson()) {
                mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
                returnState = true;
            }
            boolean updatePosition = false, positive = true;
            if (mc.player.horizontalCollision) {
                strafe = -strafe;
                updatePosition = true;
                positive = strafe == 1;
            } else {
                if (adaptiveSettings.getSetting("Controllable").isEnabled()) {
                    if (mc.options.leftKey.isPressed()) {
                        strafe = 1;
                        updatePosition = true;
                    }
                    if (mc.options.rightKey.isPressed()) {
                        strafe = -1;
                        updatePosition = true;
                        positive = false;
                    }
                }
                if (adaptiveSettings.getSetting("Edges").isEnabled() && isInVoid()) {
                    strafe = -strafe;
                    updatePosition = true;
                    positive = false;
                }
                if (adaptiveSettings.getSetting("Liquids").isEnabled() && isInLiquid()) {
                    strafe = -strafe;
                    updatePosition = true;
                    positive = false;
                }
            }
            if (updatePosition) {
                position = (position + (positive ? 1 : -1)) % (int) points.getValue();
            }
        } else if (auto3rdPerson.isEnabled() && !mc.options.getPerspective().isFirstPerson() && returnState) {
            mc.options.setPerspective(Perspective.FIRST_PERSON);
            returnState = false;
        }
    }

    @Override
    public void onRender3DEvent(Render3DEvent event) {
        if (render.isEnabled()) {
            if (animation.getEndPoint() != radius.getValue()) animation.setEndPoint(radius.getValue());
            boolean canStrafe = canStrafe();
            animation.setDirection(canStrafe ? Direction.FORWARDS : Direction.BACKWARDS);
            if (canStrafe || !animation.isDone()) {
                drawCircle(5, 0xFF000000, event.getTicks());
                drawCircle(3, color.getColor().getRGB(), event.getTicks());
            }
        }
    }

    public static boolean strafe(MoveEvent e) {
        return strafe(e, MovementUtils.getSpeed());
    }

    public static boolean strafe(MoveEvent e, double moveSpeed) {
        if (canStrafe()) {
            setSpeed(e, moveSpeed, RotationUtils.getYaw(KillAura.target.getEntityPos()), strafe,
                    mc.player.distanceTo(KillAura.target) <= radius.getValue() ? 0 : 1);
            return true;
        }
        return false;
    }

    public static boolean canStrafe() {
        KillAura killAura = Tenacity.INSTANCE.getModuleCollection().getModule(KillAura.class);
        if (!Tenacity.INSTANCE.isEnabled(TargetStrafe.class) || !killAura.isEnabled()
                || !MovementUtils.isMoving() || (space.isEnabled() && GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_SPACE) != GLFW.GLFW_PRESS)) {
            return false;
        }
        if (!(Tenacity.INSTANCE.isEnabled(Speed.class) || Tenacity.INSTANCE.isEnabled(Flight.class))) {
            return false;
        }
        return KillAura.target != null && killAura.isValid(KillAura.target);
    }

    public static void setSpeed(MoveEvent moveEvent, double speed, float yaw, double strafe, double forward) {
        LivingEntity target = KillAura.target;
        double rad = radius.getValue();
        int count = (int) points.getValue();

        double a = (Math.PI * 2.0) / (double) count;
        double posX = StrictMath.sin(a * position) * rad * strafe, posY = StrictMath.cos(a * position) * rad;

        if (forward == 0 && strafe == 0) {
            moveEvent.setX(0);
            moveEvent.setZ(0);
        } else {
            if (ServerUtils.isGeniuneHypixel()) speed = Math.min(speed, 0.3375);

            boolean skip = false;
            if (adaptiveSettings.getSetting("Edges").isEnabled()) {
                Vec3d pos = new Vec3d(mc.player.getX(), mc.player.getY() + mc.player.getStandingEyeHeight(), mc.player.getZ());
                Vec3d vec = RotationUtils.getVecRotations(0, 90);
                if (mc.world.raycast(new RaycastContext(pos, pos.add(vec.x * 5, vec.y * 5, vec.z * 5),
                        RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player)).getType() == HitResult.Type.MISS) {
                    moveEvent.setX(0);
                    moveEvent.setZ(0);
                    skip = true;
                }
            }

            if (!skip) {
                double d;
                if (adaptiveSettings.getSetting("Behind").isEnabled()) {
                    double x = target.getX() + -StrictMath.sin(StrictMath.toRadians(target.getYaw())) * -2,
                            z = target.getZ() + StrictMath.cos(StrictMath.toRadians(target.getYaw())) * -2;
                    d = StrictMath.toRadians(RotationUtils.getRotations(x, target.getY(), z)[0]);
                } else {
                    d = StrictMath.toRadians(RotationUtils.getRotations(target.getX() + posX, target.getY(), target.getZ() + posY)[0]);
                }
                moveEvent.setX(speed * -StrictMath.sin(d));
                moveEvent.setZ(speed * StrictMath.cos(d));
            }
        }

        double x = Math.abs(target.getX() + posX - mc.player.getX()), z = Math.abs(target.getZ() + posY - mc.player.getZ());
        double dist = StrictMath.sqrt(x * x + z * z);
        if (dist <= 0.7) {
            position = (position + TargetStrafe.strafe) % count;
        } else if (dist > 3) {
            position = getClosestPoint(target);
        }
    }

    private void drawCircle(float lineWidth, int color, float partialTicks) {
        LivingEntity entity = KillAura.target;
        if (entity == null) return;
        float alpha = (float) ((animation.getOutput().floatValue() / radius.getValue()) / 2F);
        // GL11 line-width circle rewritten via the ported RenderUtil circle; line width is
        // approximated by nudging the radius (GL lines are unavailable on the new pipeline).
        RenderUtil.drawCircle(entity, partialTicks, (float) radius.getValue() + (lineWidth - 3f) * 0.03f, color, alpha);
    }

    private boolean isInVoid() {
        double yaw = Math.toRadians(RotationUtils.getYaw(KillAura.target.getEntityPos()));
        double xValue = -Math.sin(yaw) * 2;
        double zValue = Math.cos(yaw) * 2;
        for (int i = 0; i <= 256; i++) {
            BlockPos b = BlockPos.ofFloored(mc.player.getX() + xValue, mc.player.getY() - i, mc.player.getZ() + zValue);
            if (mc.world.getBlockState(b).isAir()) {
                if (b.getY() == 0) {
                    return true;
                }
            } else {
                return false;
            }
        }
        return !mc.player.verticalCollision && !mc.player.isOnGround() && mc.player.fallDistance != 0 && mc.player.getVelocity().y != 0 && !mc.player.isOnGround() && !mc.player.getAbilities().flying && !mc.player.isTouchingWater() && !mc.player.isHoldingOntoLadder() && !mc.player.hasStatusEffect(StatusEffects.INVISIBILITY);
    }

    private boolean isInLiquid() {
        double yaw = Math.toRadians(RotationUtils.getYaw(KillAura.target.getEntityPos()));
        double xValue = -Math.sin(yaw) * 2;
        double zValue = Math.cos(yaw) * 2;
        BlockPos b = BlockPos.ofFloored(mc.player.getX() + xValue, mc.player.getY(), mc.player.getZ() + zValue);
        return !mc.world.getBlockState(b).getFluidState().isEmpty();
    }

    private static int getClosestPoint(Entity target) {
        double playerX = mc.player.getX(), playerZ = mc.player.getZ();
        return getPoints(target).stream().min(Comparator.comparingDouble(p -> p.getDistance(playerX, playerZ))).get().getIteration();
    }

    private static List<Point> getPoints(Entity target) {
        double radius = TargetStrafe.radius.getValue();
        List<Point> pointList = new ArrayList<>();
        int count = (int) points.getValue();
        double posX = target.getX(), posZ = target.getZ();
        double d = (Math.PI * 2.0) / count;
        for (int i = 0; i <= count; i++) {
            double x = radius * StrictMath.cos(i * d);
            double z = radius * StrictMath.sin(i * d);
            pointList.add(new Point(posX + x, posZ + z, i));
        }
        return pointList;
    }

    private static class Point {
        private final double x, z;
        private final int iteration;

        private Point(double x, double z, int iteration) {
            this.x = x;
            this.z = z;
            this.iteration = iteration;
        }

        public double getX() { return x; }
        public double getZ() { return z; }
        public int getIteration() { return iteration; }

        private double getDistance(double posX, double posZ) {
            double x2 = Math.abs(posX - x), z2 = Math.abs(posZ - z);
            return StrictMath.sqrt(x2 * x2 + z2 * z2);
        }
    }

}
