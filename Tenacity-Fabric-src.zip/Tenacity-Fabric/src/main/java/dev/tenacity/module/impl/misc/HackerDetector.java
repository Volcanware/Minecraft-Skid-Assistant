package dev.tenacity.module.impl.misc;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.game.TickEvent;
import dev.tenacity.hackerdetector.Detection;
import dev.tenacity.hackerdetector.DetectionManager;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.ui.notifications.NotificationType;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Formatting;

import java.util.Map;
import java.util.WeakHashMap;

public class HackerDetector extends Module {

    private final DetectionManager detectionManager = new DetectionManager();
    private final TimerUtil timer = new TimerUtil();
    private final Map<PlayerEntity, Integer> violationLevels = new WeakHashMap<>();
    private final MultipleBoolSetting detections = new MultipleBoolSetting("Detections",
            new BooleanSetting("Flight A", true),
            new BooleanSetting("Flight B", true),
            new BooleanSetting("Reach A", true));

    public HackerDetector() {
        super("HackerDetector", Category.MISC, "Detects people using cheats inside your game");
        this.addSettings(detections);
    }

    @Override
    public void onTickEvent(TickEvent event) {
        if (mc.world == null || mc.player == null) return;
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof PlayerEntity) {
                PlayerEntity entityPlayer = (PlayerEntity) entity;
                if (entityPlayer != mc.player) {
                    for (Detection d : detectionManager.getDetections()) {
                        if (detections.getSetting(d.getName()).isEnabled()) {
                            if (d.runCheck(entityPlayer) && System.currentTimeMillis() > d.getLastViolated() + 500) {
                                int vl = violationLevels.getOrDefault(entityPlayer, 0);
                                Tenacity.INSTANCE.getNotificationManager().post(NotificationType.WARNING, entityPlayer.getName().getString(), "has flagged " + d.getName() + " | " + Formatting.BOLD + vl);
                                violationLevels.put(entityPlayer, vl + 1);
                                d.setLastViolated(System.currentTimeMillis());
                            }
                        }
                    }
                }
            }
        }
    }

}
