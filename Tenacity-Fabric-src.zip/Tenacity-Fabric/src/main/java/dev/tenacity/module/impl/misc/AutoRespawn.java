package dev.tenacity.module.impl.misc;

import dev.tenacity.event.impl.game.TickEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.utils.server.PacketUtils;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;

public final class AutoRespawn extends Module {

    @Override
    public void onTickEvent(TickEvent event) {
        if (mc.player != null && mc.player.isDead()) {
            PacketUtils.sendPacketNoEvent(new ClientStatusC2SPacket(ClientStatusC2SPacket.Mode.PERFORM_RESPAWN));
        }
    }

    public AutoRespawn() {
        super("AutoRespawn", Category.MISC, "automatically respawn");
    }

}
