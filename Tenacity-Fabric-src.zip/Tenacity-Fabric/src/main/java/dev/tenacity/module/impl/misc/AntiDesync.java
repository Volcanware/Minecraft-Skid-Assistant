package dev.tenacity.module.impl.misc;

import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.utils.server.PacketUtils;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;

@SuppressWarnings("unused")
public final class AntiDesync extends Module {

    private int slot;

    public AntiDesync() {
        super("AntiDesync", Category.MISC, "pervents desync client side");
    }

    @Override
    public void onPacketSendEvent(PacketSendEvent event) {
        if (event.getPacket() instanceof UpdateSelectedSlotC2SPacket) {
            slot = ((UpdateSelectedSlotC2SPacket) event.getPacket()).getSelectedSlot();
        }
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        if (slot != mc.player.getInventory().getSelectedSlot() && slot != -1) {
            PacketUtils.sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().getSelectedSlot()));
        }
    }

}
