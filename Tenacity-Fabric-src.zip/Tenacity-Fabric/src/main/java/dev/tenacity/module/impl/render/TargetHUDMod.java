package dev.tenacity.module.impl.render;

import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;

public class TargetHUDMod extends Module {

    public static boolean renderLayers = true;

    public static final ModeSetting mode = new ModeSetting("Mode", "Tenacity",
            "Tenacity", "Novoline", "Rise", "Exhibition", "Astolfo", "Akrien", "Old Tenacity");
    public static final NumberSetting x = new NumberSetting("X", 50, 900, 0, 1);
    public static final NumberSetting y = new NumberSetting("Y", 100, 900, 0, 1);

    public TargetHUDMod() {
        super("TargetHUD", Category.RENDER, "Shows info about the current target");
        this.addSettings(mode, x, y);
    }
}
