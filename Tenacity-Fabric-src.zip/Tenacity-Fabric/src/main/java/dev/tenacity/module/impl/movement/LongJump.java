package dev.tenacity.module.impl.movement;

import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.MoveEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.misc.TimerUtils;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

public final class LongJump extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Watchdog", "NCP", "AGC");
    private final ModeSetting watchdogMode = new ModeSetting("Watchdog Mode", "Damage", "Damage", "Damageless");
    private final NumberSetting damageSpeed = new NumberSetting("Damage Speed", 1, 1, 20, 0.5);
    private final BooleanSetting spoofY = new BooleanSetting("Spoof Y", false);
    private int movementTicks = 0;
    private double speed;
    private float pitch;
    private int prevSlot, ticks = 0;
    private boolean damagedBow;
    private final TimerUtil jumpTimer = new TimerUtil();
    private boolean damaged;
    private double x;
    private double y;
    private double z;
    private final List<Packet> packets = new ArrayList<>();
    private int stage;

    @Override
    public void onMotionEvent(MotionEvent event) {
        setSuffix(mode.getMode());
        if (spoofY.isEnabled()) mc.player.setPosition(mc.player.getX(), y, mc.player.getZ());
        switch (mode.getMode()) {
            case "Vanilla":
                if (MovementUtils.isMoving() && mc.player.isOnGround()) {
                    MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * 2);
                    mc.player.jump();
                }
                break;
            case "Watchdog":
                if (event.isPre()) {
                    switch (watchdogMode.getMode()) {
                        case "Damage":
                            if (mc.player.isOnGround()) {
                                stage++;
                                if (stage <= 3)
                                    mc.player.jump();
                                if (stage > 5 && damaged)
                                    toggle();
                            }
                            if (stage <= 3) {
                                event.setOnGround(false);
                                mc.player.setPosition(mc.player.getX(), y, mc.player.getZ());
                                TimerUtils.setTimerSpeed(damageSpeed.getFloatValue());
                                speed = 1.2;
                            }
                            if (mc.player.hurtTime > 0) {
                                damaged = true;
                                ticks++;
                                if (ticks < 2)
                                    mc.player.setVelocity(mc.player.getVelocity().x, 0.41999998688698, mc.player.getVelocity().z);
                                MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * speed);
                                speed -= 0.01;
                                TimerUtils.setTimerSpeed(1);
                            }
                            if (damaged) {
                                mc.player.setVelocity(mc.player.getVelocity().x, mc.player.getVelocity().y + 0.0049, mc.player.getVelocity().z);
                            }
                            break;
                        case "Damageless":
                            stage++;

                            if (stage == 1 && mc.player.isOnGround()) {
                                mc.player.setVelocity(mc.player.getVelocity().x, 0.42, mc.player.getVelocity().z);
                                MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * 1.2);
                                speed = 1.45f;
                            }

                            if (stage > 1) {
                                MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * speed);
                                speed -= 0.015;
                            }

                            if (mc.player.isOnGround() && stage > 1)
                                toggle();
                            break;
                    }
                }
                break;
            case "NCP":
                if (MovementUtils.isMoving()) {
                    if (MovementUtils.isOnGround(0.00023)) {
                        mc.player.setVelocity(mc.player.getVelocity().x, 0.41, mc.player.getVelocity().z);
                    }

                    switch (movementTicks) {
                        case 1:
                            speed = MovementUtils.getBaseMoveSpeed();
                            break;
                        case 2:
                            speed = MovementUtils.getBaseMoveSpeed() + (0.132535 * Math.random());
                            break;
                        case 3:
                            speed = MovementUtils.getBaseMoveSpeed() / 2;
                            break;
                    }
                    MovementUtils.setSpeed(Math.max(speed, MovementUtils.getBaseMoveSpeed()));
                    movementTicks++;
                }
                break;
            case "AGC":
                int bow = getBowSlot();

                if (damagedBow) {
                    if (mc.player.isOnGround() && jumpTimer.hasTimeElapsed(1000)) {
                        toggle();
                    }
                    if (mc.player.isOnGround() && mc.player.getVelocity().y > 0.003) {
                        mc.player.setVelocity(mc.player.getVelocity().x, 0.575f, mc.player.getVelocity().z);
                    } else {
                        MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * 1.8);
                    }
                }

                if (!damagedBow) {
                    switch (ticks) {
                        case 0:
                            if (prevSlot != bow) {
                                PacketUtils.sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(bow));
                            }
                            PacketUtils.sendPacketNoEvent(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
                            break;
                        case 3:
                            event.setPitch(-89.93F);
                            PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.Full(event.getX(), event.getY(), event.getZ(), event.getYaw(), pitch, event.isOnGround(), false));
                            PacketUtils.sendPacketNoEvent(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.RELEASE_USE_ITEM, new BlockPos(-1, -1, -1), Direction.DOWN));
                            if (prevSlot != bow) {
                                PacketUtils.sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(prevSlot));
                            }
                            break;
                    }
                    if (mc.player.hurtTime != 0) {
                        damagedBow = true;
                    }
                }
        }
        if (!mode.is("Watchdog"))
            ticks++;
    }

    @Override
    public void onPacketSendEvent(PacketSendEvent event) {
    }

    @Override
    public void onMoveEvent(MoveEvent event) {
        if (!damagedBow && mode.is("AGC")) {
            event.setX(0);
            event.setZ(0);
        }
        if (!damaged && mode.is("Watchdog") && watchdogMode.is("Damage")) {
            MovementUtils.setSpeed(event, 0);
        }
    }

    public int getBowSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack is = mc.player.getInventory().getStack(i);
            if (!is.isEmpty() && is.getItem() == Items.BOW) {
                return i;
            }
        }
        return -1;
    }

    public int getItemCount(Item item) {
        int count = 0;
        for (int i = 9; i < 45; i++) {
            ItemStack stack = mc.player.playerScreenHandler.getSlot(i).getStack();
            if (!stack.isEmpty() && stack.getItem() == item) {
                count += stack.getCount();
            }
        }
        return count;
    }

    @Override
    public void onEnable() {
        if ((mode.is("AGC"))) {
            prevSlot = mc.player.getInventory().getSelectedSlot();
            pitch = MathUtils.getRandomFloat(-89.2F, -89.99F);
            if (getBowSlot() == -1) {
                this.toggleSilent();
                return;
            } else if (getItemCount(Items.ARROW) == 0) {
                this.toggleSilent();
                return;
            }
        }
        ticks = 0;
        damagedBow = false;
        damaged = false;
        jumpTimer.reset();
        x = mc.player.getX();
        y = mc.player.getY();
        z = mc.player.getZ();
        packets.clear();
        stage = 0;
        speed = 1.4f;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        TimerUtils.setTimerSpeed(1);
        packets.forEach(PacketUtils::sendPacketNoEvent);
        packets.clear();
        super.onDisable();
    }

    public LongJump() {
        super("LongJump", Category.MOVEMENT, "jump further");
        watchdogMode.addParent(mode, m -> m.is("Watchdog"));
        damageSpeed.addParent(mode, m -> m.is("Watchdog") && watchdogMode.is("Damage"));
        this.addSettings(mode, watchdogMode, damageSpeed, spoofY);
    }

}
