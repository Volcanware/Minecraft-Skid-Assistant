package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.utils.Utils;
import dev.tenacity.utils.objects.GradientColorWheel;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;

public abstract class TargetHUD implements Utils {

    protected GradientColorWheel colorWheel;
    private float width, height;
    private final String name;

    public TargetHUD(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setColorWheel(GradientColorWheel colorWheel) {
        this.colorWheel = colorWheel;
    }

    /**
     * Solid rectangle: 1.8.9 {@code Gui.drawRect2(x, y, w, h, argb)}.
     */
    protected void fillRect(float x, float y, float width, float height, int color) {
        ctx().fill(Math.round(x), Math.round(y), Math.round(x + width), Math.round(y + height), color);
    }

    /**
     * Horizontal gradient rect: 1.8.9 {@code RenderUtil.drawGradientRect}
     * / {@code GradientUtil.drawGradientLR} — startColor on the left, endColor on the right.
     * Implemented by rotating the DrawContext matrices -90 degrees so the
     * built-in vertical fillGradient appears horizontal.
     */
    protected void gradientRectLR(float left, float top, float right, float bottom, int leftColor, int rightColor) {
        org.joml.Matrix3x2fStack matrices = ctx().getMatrices();
        matrices.pushMatrix();
        matrices.translate((left + right) / 2f, (top + bottom) / 2f);
        matrices.rotate((float) Math.toRadians(-90));
        ctx().fillGradient(Math.round(-(bottom - top) / 2f), Math.round(-(right - left) / 2f),
                Math.round((bottom - top) / 2f), Math.round((right - left) / 2f), leftColor, rightColor);
        matrices.popMatrix();
    }

    /**
     * 1.8.9 {@code RenderUtil.drawGradientRectBordered}: gradient fill inset by
     * {@code width} plus four gradient border strips.
     */
    protected void gradientRectBordered(float left, float top, float right, float bottom, float width,
                                        int startColor, int endColor, int borderStartColor, int borderEndColor) {
        gradientRectLR(left + width, top + width, right - width, bottom - width, startColor, endColor);
        gradientRectLR(left + width, top, right - width, top + width, borderStartColor, borderEndColor);
        gradientRectLR(left, top, left + width, bottom, borderStartColor, borderEndColor);
        gradientRectLR(right - width, top, right, bottom, borderStartColor, borderEndColor);
        gradientRectLR(left + width, bottom - width, right - width, bottom, borderStartColor, borderEndColor);
    }

    protected void renderPlayer2D(float x, float y, float width, float height, AbstractClientPlayerEntity player) {
        renderPlayer2D(x, y, width, height, player, -1);
    }

    /**
     * Draws the face region of the player's skin. The 1.8.9 version masked the
     * texture through a GL stencil buffer for round heads; the DrawContext
     * pipeline has no stencil equivalent, so heads render unmasked (square).
     */
    protected void renderPlayer2D(float x, float y, float width, float height, AbstractClientPlayerEntity player, int tint) {
        Identifier skin = player.getSkin().body().texturePath();
        ctx().drawTexture(RenderPipelines.GUI_TEXTURED, skin, Math.round(x), Math.round(y), 8.0F, 8.0F,
                Math.round(width), Math.round(height), 64, 64, tint);
    }

    /**
     * 1.8.9 {@code GuiInventory.drawEntityOnScreen}: draws a living entity in the GUI,
     * feet anchored at ({@code x}, {@code y}), {@code size} in pixels-per-block.
     * The yaw/pitch look-at params map to the new API's rotation/camera quaternions.
     */
    protected void renderEntityOnScreen(float x, float y, float size, float yaw, float pitch, LivingEntity entity) {
        float w = size * 2.2f;
        float h = size * 2.6f;
        Quaternionf rotation = new Quaternionf().rotateZ((float) Math.PI).rotateY((float) Math.toRadians(yaw));
        Quaternionf cameraAngle = new Quaternionf().rotateX((float) Math.toRadians(-pitch));
        InventoryScreen.drawEntity(ctx(), Math.round(x - w / 2f), Math.round(y - h), Math.round(x + w / 2f), Math.round(y),
                Math.round(size), 0, yaw, pitch, entity);
    }

    /**
     * 1.8.9 {@code mc.getRenderItem().renderItemAndEffectIntoGUI(stack, x, y)}.
     */
    protected void renderItemStack(ItemStack stack, int x, int y) {
        ctx().drawItem(stack, x, y);
    }

    /**
     * Vanilla font text with shadow: 1.8.9 {@code FontRenderer.drawStringWithShadow}.
     */
    protected void drawStringWithShadow(String text, float x, float y, int color) {
        ctx().drawTextWithShadow(fr, text, Math.round(x), Math.round(y), color);
    }

    public abstract void render(float x, float y, float alpha, LivingEntity target);

    public abstract void renderEffects(float x, float y, float alpha, boolean glow);

    private static final HashMap<Class<? extends TargetHUD>, TargetHUD> targetHuds = new HashMap<>();

    public static TargetHUD get(String name) {
        return targetHuds.values().stream().filter(hud -> hud.getName().equals(name)).findFirst().orElse(null);
    }

    @SuppressWarnings("unchecked")
    public static <T extends TargetHUD> T get(Class<T> clazz) {
        return (T) targetHuds.get(clazz);
    }

    public static void init() {
        targetHuds.put(TenacityTargetHUD.class, new TenacityTargetHUD());
        targetHuds.put(OldTenacityTargetHUD.class, new OldTenacityTargetHUD());
        targetHuds.put(RiseTargetHUD.class, new RiseTargetHUD());
        targetHuds.put(ExhiTargetHUD.class, new ExhiTargetHUD());
        targetHuds.put(AutoDoxTargetHUD.class, new AutoDoxTargetHUD());
        targetHuds.put(AkrienTargetHUD.class, new AkrienTargetHUD());
        targetHuds.put(AstolfoTargetHUD.class, new AstolfoTargetHUD());
        targetHuds.put(NovolineTargetHUD.class, new NovolineTargetHUD());
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }
}
