package dev.tenacity.module;

import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.objects.Drag;
import dev.tenacity.utils.objects.Scroll;

public enum Category {

    COMBAT("Combat", FontUtil.BOMB),
    MOVEMENT("Movement", FontUtil.WHEELCHAIR),
    RENDER("Render", FontUtil.EYE),
    PLAYER("Player", FontUtil.PERSON),
    EXPLOIT("Exploit", FontUtil.BUG),
    MISC("Misc", FontUtil.LIST),
    SCRIPTS("Scripts", FontUtil.SCRIPT);

    public final String name;
    public final String icon;
    public final int posX;
    public final boolean expanded;

    private final Scroll scroll = new Scroll();
    private final Drag drag;
    public int posY = 20;

    public Scroll getScroll() { return scroll; }
    public Drag getDrag() { return drag; }

    Category(String name, String icon) {
        this.name = name;
        this.icon = icon;
        posX = 20 + (Module.categoryCount * 120);
        drag = new Drag(posX, posY);
        expanded = true;
        Module.categoryCount++;
    }
}
