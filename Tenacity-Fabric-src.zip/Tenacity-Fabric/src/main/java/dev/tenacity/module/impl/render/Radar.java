package dev.tenacity.module.impl.render;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.event.impl.render.ShaderEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ColorSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.objects.Dragging;
import dev.tenacity.utils.objects.GradientColorWheel;
import dev.tenacity.utils.render.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.WaterCreatureEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Radar extends Module {

    public final NumberSetting size = new NumberSetting("Size", 90, 125, 75, 1);
    private final ColorSetting playerColor = new ColorSetting("Player Color", Color.RED);
    private final ColorSetting mobColor = new ColorSetting("Mob Color", Color.ORANGE);
    private final ColorSetting animalColor = new ColorSetting("Animal Color", Color.BLUE);
    private final ColorSetting itemColor = new ColorSetting("Item Color", Color.YELLOW);

    public final MultipleBoolSetting targets = new MultipleBoolSetting("Entities",
            new BooleanSetting("Players", true),
            new BooleanSetting("Mobs", true),
            new BooleanSetting("Animals", true),
            new BooleanSetting("Items", true));


    public final Dragging drag = Tenacity.INSTANCE.createDrag(this, "radar", 5, 40);
    private final List<Entity> entities = new ArrayList<>();
    private final GradientColorWheel colorWheel = new GradientColorWheel();

    public Radar() {
        super("Radar", Category.RENDER, "Shows entites on a gui");
        playerColor.addParent(targets, targetsSetting -> targetsSetting.getSetting("Players").isEnabled());
        mobColor.addParent(targets, targetsSetting -> targetsSetting.getSetting("Mobs").isEnabled());
        animalColor.addParent(targets, targetsSetting -> targetsSetting.getSetting("Animals").isEnabled());

        itemColor.addParent(targets, targetsSetting -> targetsSetting.getSetting("Items").isEnabled());

        addSettings(targets, colorWheel.createModeSetting("Color Mode"), colorWheel.getColorSetting(),
                size, playerColor, mobColor, animalColor, itemColor);
    }

    @Override
    public void onShaderEvent(ShaderEvent e) {
        float x = drag.getX(), y = drag.getY(), size = (float) this.size.getValue();
        if (e.getBloomOptions().getSetting("Radar").isEnabled()) {
            RoundedUtil.drawGradientRound(x, y, size, size, 6, colorWheel.getColor1(), colorWheel.getColor4(), colorWheel.getColor2(), colorWheel.getColor3());
        } else {
            RoundedUtil.drawRound(x, y, size, size, 6, Color.BLACK);

        }
    }

    private void fill(float x, float y, float w, float h, int color) {
        ctx().fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), color);
    }

    @Override
    public void onRender2DEvent(Render2DEvent e) {
        getEntities();
        float x = drag.getX(), y = drag.getY(), size = (float) this.size.getValue(), middleX = x + size / 2f, middleY = y + size / 2f;

        drag.setWidth(size);
        drag.setHeight(size);

        Color lineColor = new Color(255, 255, 255, 180);

        colorWheel.setColors();
        float alpha = .85f;
        RoundedUtil.drawGradientRound(x, y, size, size, 6,
                ColorUtil.applyOpacity(colorWheel.getColor1(), alpha),
                ColorUtil.applyOpacity(colorWheel.getColor4(), alpha),
                ColorUtil.applyOpacity(colorWheel.getColor2(), alpha),
                ColorUtil.applyOpacity(colorWheel.getColor3(), alpha));


        fill(x - 1, y + (size / 2f - .5f), size + 2, 1, lineColor.getRGB());
        fill(x + (size / 2f - .5f), y - 1, 1, size + 2, lineColor.getRGB());


        // The original clipped the dots to the rounded rect via the stencil
        // buffer; the 1.21 GUI pipeline has no stencil in DrawContext, so a
        // square scissor is used instead.
        ctx().enableScissor((int) x, (int) y, (int) (x + size), (int) (y + size));
        // Equivalent to the old GLUtil.startRotate(middleX, middleY, yaw):
        // glRotatef(yaw, 0,0,-1) == rotate(-yaw) about +Z.
        ctx().getMatrices().pushMatrix();
        ctx().getMatrices().translate(middleX, middleY);
        ctx().getMatrices().rotate((float) Math.toRadians(-mc.player.getYaw()));
        ctx().getMatrices().translate(-middleX, -middleY);

        float partialTicks = mc.getRenderTickCounter().getTickProgress(false);
        for (Entity entity : entities) {
            double xDiff = MathHelper.lerp(partialTicks, entity.lastRenderX, entity.getX()) - MathHelper.lerp(partialTicks, mc.player.lastRenderX, mc.player.getX());
            double zDiff = MathHelper.lerp(partialTicks, entity.lastRenderZ, entity.getZ()) - MathHelper.lerp(partialTicks, mc.player.lastRenderZ, mc.player.getZ());
            if ((xDiff + zDiff) < (size / 2f)) {
                float translatedX = (float) (middleX - xDiff);
                float translatedY = (float) (middleY - zDiff);
                RoundedUtil.drawRound(translatedX, translatedY, 3, 3, 1f, getColor(entity));
            }
        }

        ctx().getMatrices().popMatrix();
        ctx().disableScissor();
    }


    public Color getColor(Entity entity) {
        Color color = Color.WHITE;

        if (entity instanceof PlayerEntity) {
            color = playerColor.getColor();
        }
        if (entity instanceof HostileEntity || entity instanceof WaterCreatureEntity) {
            color = mobColor.getColor();
        }

        if (entity instanceof AnimalEntity) {
            color = animalColor.getColor();
        }

        if (entity instanceof ItemEntity) {
            color = itemColor.getColor();
        }

        return color;

    }


    public void getEntities() {
        entities.clear();
        for (Entity entity : mc.world.getEntities()) {


            if (entity instanceof PlayerEntity && targets.getSetting("Players").isEnabled()) {
                if (entity != mc.player && !entity.isInvisible()) {
                    entities.add(entity);
                }
            }

            if ((entity instanceof HostileEntity || entity instanceof WaterCreatureEntity) && targets.getSetting("Mobs").isEnabled()) {
                entities.add(entity);
            }

            if (entity instanceof AnimalEntity && targets.getSetting("Animals").isEnabled()) {
                entities.add(entity);
            }

            if (entity instanceof ItemEntity && targets.getSetting("Items").isEnabled()) {
                entities.add(entity);
            }
        }
    }


}
