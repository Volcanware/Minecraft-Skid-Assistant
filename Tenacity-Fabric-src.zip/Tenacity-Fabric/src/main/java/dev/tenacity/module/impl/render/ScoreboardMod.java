package dev.tenacity.module.impl.render;

import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.NumberSetting;

public class ScoreboardMod extends Module {

    public static final BooleanSetting removeScoreboard = new BooleanSetting("Remove", false);
    public static final NumberSetting scoreboardHeight = new NumberSetting("Scoreboard Height", 250, 400, 150, 1);

    public ScoreboardMod() {
        super("Scoreboard", Category.RENDER, "Scoreboard adjustments");
        this.addSettings(removeScoreboard, scoreboardHeight);
    }
}
