package dev.tenacity.module.impl.combat;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.item.BowItem;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.lwjgl.glfw.GLFW;

public final class FastBow extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Ghostly");
    private final NumberSetting shotDelay = new NumberSetting("Shot Delay", 0, 2, 0, 0.1);

    private final TimerUtil delayTimer = new TimerUtil();

    @Override
    public void onMotionEvent(MotionEvent event) {
        if (mc.player.getMainHandStack().isEmpty()) return;
        if (delayTimer.hasTimeElapsed((long) (shotDelay.getValue() * 250L))) {
            switch (mode.getMode()) {
                case "Vanilla":
                    if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS
                            && mc.player.getMainHandStack().getItem() instanceof BowItem) {
                        for (int i = 0; i < 20; ++i) {
                            PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision));
                        }
                        // MinecraftClient.itemUseCooldown is private in yarn — needs an accessor (e.g. mixin accessor / duck interface)
                        ((dev.tenacity.mixin.MinecraftClientAccessor) mc).tenacity$setItemUseCooldown(0);
                        mc.interactionManager.stopUsingItem(mc.player);
                    }
                    break;
                case "Ghostly":
                    if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS
                            && mc.player.getMainHandStack().getItem() instanceof BowItem) {
                        for (int i = 0; i < 20; i++) {
                            PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(), mc.player.getY(), mc.player.getZ(), mc.player.isOnGround(), mc.player.horizontalCollision));

                        }
                        // MinecraftClient.itemUseCooldown is private in yarn — needs an accessor (e.g. mixin accessor / duck interface)
                        ((dev.tenacity.mixin.MinecraftClientAccessor) mc).tenacity$setItemUseCooldown(0);
                        mc.interactionManager.stopUsingItem(mc.player);
                    }
                    break;
            }
            delayTimer.reset();
        }
    }

    @Override
    public void onDisable() {
        // MinecraftClient.itemUseCooldown is private in yarn — needs an accessor (e.g. mixin accessor / duck interface)
        ((dev.tenacity.mixin.MinecraftClientAccessor) mc).tenacity$setItemUseCooldown(4);
        super.onDisable();
    }

    public FastBow() {
        super("FastBow", Category.COMBAT, "shoot bows faster");
        this.addSettings(mode, shotDelay);
    }

}
