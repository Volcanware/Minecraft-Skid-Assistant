package dev.tenacity.module.impl.render;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.StringSetting;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.objects.Dragging;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.tuples.Pair;

import java.awt.*;

public class SpotifyMod extends Module {

    private final StringSetting clientID = new StringSetting("Client ID");
    private final ModeSetting backgroundColor = new ModeSetting("Background", "Average", "Average", "Spotify Grey", "Sync");
    private final ModeSetting progressBarColor = new ModeSetting("Progress Bar", "Green", "Average", "Green", "White");

    private final Dragging drag = Tenacity.INSTANCE.createDrag(this, "spotify", 5, 150);
    private final DecelerateAnimation openAnimation = new DecelerateAnimation(300, 1);
    public final float height = 50;
    public final float albumCoverSize = height;
    private final float playerWidth = 135;
    private final float width = albumCoverSize + playerWidth;

    public SpotifyMod() {
        super("Spotify", Category.RENDER, "UI for spotify");
        addSettings(clientID, backgroundColor, progressBarColor);
    }

    @Override
    public void onEnable() {
        openAnimation.setDirection(Direction.FORWARDS);
        super.onEnable();
        dev.tenacity.utils.spotify.SpotifyAPI.build(clientID.getString());
        dev.tenacity.utils.spotify.SpotifyAPI.connect();
    }

    @Override
    public void onDisable() {
        openAnimation.setDirection(Direction.BACKWARDS);
        dev.tenacity.utils.spotify.SpotifyAPI.disconnect();
        super.onDisable();
    }

    @Override
    public void onRender2DEvent(Render2DEvent event) {
        dev.tenacity.utils.spotify.SpotifyAPI api = null;
        float x = drag.getX(), y = drag.getY();
        Color bg = new Color(18, 18, 18, 210);
        if (backgroundColor.is("Sync")) {
            bg = dev.tenacity.utils.render.ColorUtil.applyOpacity(HUDMod.getClientColors().getFirst(), 0.75f);
        }
        RoundedUtil.drawRound(x, y, width, height, 5, bg);
        RoundedUtil.drawRound(x, y, albumCoverSize, height, 5, new Color(30, 30, 30));
        tenacityFont20().drawString("Spotify", x + albumCoverSize + 8, y + 8, -1);

        String status;
        float progress = 0;
        if (dev.tenacity.utils.spotify.SpotifyAPI.hasTrack) {
            String artist = dev.tenacity.utils.spotify.SpotifyAPI.currentArtistName;
            String track = dev.tenacity.utils.spotify.SpotifyAPI.currentTrackName;
            status = (artist.isEmpty() ? "" : artist + " - ") + track + (dev.tenacity.utils.spotify.SpotifyAPI.isPlaying ? "" : " (paused)");
            progress = Math.min(1f, dev.tenacity.utils.spotify.SpotifyAPI.position / (float) Math.max(1, dev.tenacity.utils.spotify.SpotifyAPI.duration));
        } else if (dev.tenacity.utils.spotify.SpotifyAPI.authenticated) {
            status = "Connected - nothing playing";
        } else {
            status = clientID.getString().isEmpty() ? "No Client ID set" : "Awaiting auth (check browser)";
        }
        tenacityFont16().drawString(status, x + albumCoverSize + 8, y + 24, Color.GRAY.getRGB());

        Color barColor = progressBarColor.is("White") ? Color.WHITE
                : progressBarColor.is("Average") ? HUDMod.getClientColors().getFirst() : new Color(30, 215, 96);
        RoundedUtil.drawRound(x + albumCoverSize + 8, y + height - 12, playerWidth - 16, 4, 2, new Color(60, 60, 60));
        RoundedUtil.drawRound(x + albumCoverSize + 8, y + height - 12, (playerWidth - 16) * progress, 4, 2, barColor);
        drag.setWidth(width);
        drag.setHeight(height);
    }
}
