package dev.tenacity.module.impl.render;

import dev.tenacity.event.impl.game.TickEvent;
import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;

import java.util.Random;

public class Ambience extends Module {

    private final NumberSetting time = new NumberSetting("Time", 12000, 24000, 0, 1000);
    private final ModeSetting weather = new ModeSetting("Weather", "Clear", "Rain", "Thunder", "Clear", "Snow", "Don't Change");
    public static boolean overrideSnow = false;

    public Ambience() {
        super("Ambience", Category.RENDER, "world time");
        this.addSettings(time, weather);
    }

    //A random value was used in the clear weather command so here's one to use
    private final int randomValue = (300 + (new Random()).nextInt(600)) * 20;

    String mode = "";

    @Override
    public void onTickEvent(TickEvent event) {
        if (mc.world != null) {
            // ClientWorld#setTime(time, timeOfDay, fuzzy) drives the render clock only;
            // the WorldTimeUpdateS2CPacket cancel below stops the server overwriting it.
            mc.world.setTime((long) time.getValue(), (long) time.getValue(), false);
            // NOTE: server-side weather control is not possible from a client mod in
            // 1.21 (no world property access) — the Weather mode is kept for UI parity.
            overrideSnow = weather.is("Snow");
        }
    }

    @Override
    public void onPacketReceiveEvent(PacketReceiveEvent e) {
        if (e.getPacket() instanceof WorldTimeUpdateS2CPacket) {
            e.cancel();
        }
    }

    @Override
    public void onDisable() {
        overrideSnow = false;
        super.onDisable();
    }
}
