package dev.tenacity.module.impl.combat;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.movement.Scaffold;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.block.TransparentBlock;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;

import java.util.concurrent.ThreadLocalRandom;

public class AutoPot extends Module {

    private final NumberSetting delay = new NumberSetting("Delay", 750, 2000, 0, 50);
    private final NumberSetting minHealHP = new NumberSetting("Heal HP", 12, 20, 1, 0.5);
    private final BooleanSetting splashFrogPots = new BooleanSetting("Frog potions", false);
    private final TimerUtil timerUtil = new TimerUtil();
    public static boolean isPotting;
    private float lastPitch;

    public AutoPot() {
        super("AutoPot", Category.COMBAT, "auto splashes potions");
        this.addSettings(delay, minHealHP, splashFrogPots);
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        if (Tenacity.INSTANCE.isEnabled(Scaffold.class) || mc.currentScreen instanceof GenericContainerScreen)
            return;

        int prevSlot = mc.player.getInventory().getSelectedSlot();
        if (e.isPre()) {
            if (MovementUtils.isOnGround(1.0E-5)
                    && !(mc.world.getBlockState(BlockPos.ofFloored(e.getX(), e.getY() - 1, e.getZ())).getBlock() instanceof TransparentBlock)
                    && (!mc.player.hasStatusEffect(StatusEffects.SPEED)
                    || mc.player.getStatusEffect(StatusEffects.SPEED).getDuration() < 30)
                    && timerUtil.hasTimeElapsed((long) delay.getValue()) && !mc.player.isUsingItem()) {
                if (isSpeedPotsInHotbar()) {
                    for (int i = 36; i < 45; i++) {
                        if (isSpeedPot(mc.player.playerScreenHandler.getSlot(i).getStack())) {
                            isPotting = true;
                            lastPitch = mc.player.getPitch();
                            throwPot(prevSlot, i);
                            e.setPitch(-90 + ThreadLocalRandom.current().nextFloat());
                            break;
                        }
                    }
                    timerUtil.reset();
                    isPotting = false;
                } else {
                    moveSpeedPots();
                }
            }

            if (!mc.player.hasStatusEffect(StatusEffects.REGENERATION) && mc.player.getHealth() <= minHealHP.getValue()
                    && timerUtil.hasTimeElapsed((long) delay.getValue())) {
                if (isRegenPotsInHotbar()) {
                    for (int i = 36; i < 45; i++) {
                        if (isRegenPot(mc.player.playerScreenHandler.getSlot(i).getStack())) {
                            isPotting = true;
                            lastPitch = mc.player.getPitch();
                            throwPot(prevSlot, i);
                            e.setPitch(-90 + ThreadLocalRandom.current().nextFloat());
                            break;
                        }
                    }
                    timerUtil.reset();
                    isPotting = false;
                } else {
                    moveRegenPots();
                }
            }

            if (mc.player.getHealth() <= minHealHP.getValue() && timerUtil.hasTimeElapsed((long) delay.getValue())) {
                if (isHealthPotsInHotbar()) {
                    for (int i = 36; i < 45; i++) {
                        if (isHealthPot(mc.player.playerScreenHandler.getSlot(i).getStack())) {
                            isPotting = true;
                            lastPitch = mc.player.getPitch();
                            throwPot(prevSlot, i);
                            e.setPitch(-90 + ThreadLocalRandom.current().nextFloat());
                            break;
                        }
                    }
                    timerUtil.reset();
                    isPotting = false;
                } else {
                    moveHealthPots();
                }
            }
        } else if (e.isPost()) {
            isPotting = false;
        }
    }

    private void throwPot(int prevSlot, int index) {
        double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
        float yaw = mc.player.getYaw();
        PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.Full(
                x, y, z, yaw, 88.8F + ThreadLocalRandom.current().nextFloat(), mc.player.isOnGround(), mc.player.horizontalCollision));
        PacketUtils.sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(index - 36));
        PacketUtils.sendPacketNoEvent(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, yaw, 88.8F));
        PacketUtils.sendPacket(new UpdateSelectedSlotC2SPacket(prevSlot));
        PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.Full(
                x, y, z, yaw, lastPitch, mc.player.isOnGround(), mc.player.horizontalCollision));
    }

    private boolean isSpeedPotsInHotbar() {
        for (int index = 36; index < 45; index++) {
            if (isSpeedPot(mc.player.playerScreenHandler.getSlot(index).getStack())) return true;
        }
        return false;
    }

    private boolean isHealthPotsInHotbar() {
        for (int index = 36; index < 45; index++) {
            if (isHealthPot(mc.player.playerScreenHandler.getSlot(index).getStack())) return true;
        }
        return false;
    }

    private boolean isRegenPotsInHotbar() {
        for (int index = 36; index < 45; index++) {
            if (isRegenPot(mc.player.playerScreenHandler.getSlot(index).getStack())) return true;
        }
        return false;
    }

    private int getPotionCount() {
        int count = 0;
        for (int index = 0; index < 45; index++) {
            ItemStack stack = mc.player.playerScreenHandler.getSlot(index).getStack();
            if (isHealthPot(stack) || isHealthPot(stack) || isRegenPot(stack))
                count++;
        }
        return count;
    }

    private void moveSpeedPots() {
        if (mc.currentScreen instanceof GenericContainerScreen) return;
        for (int index = 9; index < 36; index++) {
            final ItemStack stack = mc.player.playerScreenHandler.getSlot(index).getStack();
            if (stack.isEmpty()) continue;
            if (!splashFrogPots.isEnabled() && stack.getName().getString().contains("Frog")) continue;
            if (isSpeedPot(stack)) {
                mc.interactionManager.clickSlot(0, index, 6, SlotActionType.SWAP, mc.player);
                break;
            }
        }
    }

    private void moveHealthPots() {
        if (mc.currentScreen instanceof GenericContainerScreen) return;
        for (int index = 9; index < 36; index++) {
            ItemStack stack = mc.player.playerScreenHandler.getSlot(index).getStack();
            if (isHealthPot(stack)) {
                mc.interactionManager.clickSlot(0, index, 6, SlotActionType.SWAP, mc.player);
                break;
            }
        }
    }

    private void moveRegenPots() {
        if (mc.currentScreen instanceof GenericContainerScreen) return;
        for (int index = 9; index < 36; index++) {
            ItemStack stack = mc.player.playerScreenHandler.getSlot(index).getStack();
            if (isRegenPot(stack)) {
                mc.interactionManager.clickSlot(0, index, 6, SlotActionType.SWAP, mc.player);
                break;
            }
        }
    }

    private boolean isSpeedPot(ItemStack stack) {
        if (!stack.isEmpty() && stack.isOf(Items.SPLASH_POTION)) {
            if (!splashFrogPots.isEnabled() && stack.getName().getString().contains("Frog")) return false;
            for (StatusEffectInstance e : stack.getOrDefault(DataComponentTypes.POTION_CONTENTS,
                    PotionContentsComponent.DEFAULT).getEffects()) {
                if (e.getEffectType() == StatusEffects.SPEED && e.getEffectType() != StatusEffects.JUMP_BOOST) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isHealthPot(ItemStack stack) {
        if (!stack.isEmpty() && stack.isOf(Items.SPLASH_POTION)) {
            for (StatusEffectInstance e : stack.getOrDefault(DataComponentTypes.POTION_CONTENTS,
                    PotionContentsComponent.DEFAULT).getEffects()) {
                if (e.getEffectType() == StatusEffects.INSTANT_HEALTH) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isRegenPot(ItemStack stack) {
        if (!stack.isEmpty() && stack.isOf(Items.SPLASH_POTION)) {
            for (StatusEffectInstance e : stack.getOrDefault(DataComponentTypes.POTION_CONTENTS,
                    PotionContentsComponent.DEFAULT).getEffects()) {
                if (e.getEffectType() == StatusEffects.REGENERATION) {
                    return true;
                }
            }
        }
        return false;
    }

}
