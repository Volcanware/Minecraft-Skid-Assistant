package dev.tenacity.module.impl.render;

import dev.tenacity.utils.tuples.Pair;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.render.Render3DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ColorSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.WorldRenderUtil;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.util.math.Vec3d;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright Alan Wood 2021
 * None of this code to be reused without my written permission
 * Intellectual Rights owned by Alan Wood
 */
public final class Breadcrumbs extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Rise", "Rise", "Line");
    private final NumberSetting particleAmount = new NumberSetting("Particle Amount", 15, 500, 1, 1);
    private final BooleanSetting seeThroughWalls = new BooleanSetting("Walls", true);
    private final ModeSetting colorMode = new ModeSetting("Color Mode", "Sync", "Sync", "Custom");
    private final ColorSetting color = new ColorSetting("Color", Color.WHITE);

    public Breadcrumbs() {
        super("Breadcrumbs", Category.RENDER, "shows where you've walked");
        color.addParent(colorMode, modeSetting -> modeSetting.is("Custom"));
        seeThroughWalls.addParent(mode, mode -> mode.getMode().equals("Rise"));
        addSettings(mode, particleAmount, seeThroughWalls, colorMode, color);
    }

    private final List<Vec3d> path = new ArrayList<>();

    @Override
    public void onMotionEvent(MotionEvent e) {
        if (e.isPre()) {
            if (mc.player.lastRenderX != mc.player.getX() || mc.player.lastRenderY != mc.player.getY() || mc.player.lastRenderZ != mc.player.getZ()) {
                path.add(new Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ()));
            }

            while (path.size() > particleAmount.getValue()) {
                path.remove(0);
            }
        }
    }

    @Override
    public void onRender3DEvent(Render3DEvent event) {
        int i = 0;

        Pair<Color, Color> colors = colorMode.is("Custom") ? Pair.of(color.getColor(), color.getAltColor()) : HUDMod.getClientColors();

        switch (mode.getMode()) {
            case "Rise": {
                WorldRenderUtil.start3D();
                // debug layers render through walls, matching the "Walls" option
                for (final Vec3d v : path) {


                    i++;

                    boolean draw = true;

                    final double distanceFromPlayer = mc.player.getEntityPos().distanceTo(new Vec3d(v.x, v.y - 1, v.z));
                    int quality = (int) (distanceFromPlayer * 4 + 10);

                    if (quality > 350)
                        quality = 350;

                    if (i % 10 != 0 && distanceFromPlayer > 25) {
                        draw = false;
                    }

                    if (i % 3 == 0 && distanceFromPlayer > 15) {
                        draw = false;
                    }

                    if (draw) {

                        WorldRenderUtil.matrices().push();
                        WorldRenderUtil.translate(v.x, v.y, v.z);

                        final float scale = 0.06f;
                        WorldRenderUtil.matrices().scale(-scale, -scale, -scale);

                        WorldRenderUtil.billboard();


                        Color c = interpolateColorsBackAndForth(7, 3 + (i * 20), colors.getFirst(), colors.getSecond(), false);

                        if (colorMode.is("Custom") && color.isRainbow()) {
                            c = color.getRainbow().getColor(3 + (i * 20));
                        }


                        drawFilledCircle(0, -2, 0.7, ColorUtil.applyOpacity(c, .6f).getRGB(), quality);

                        if (distanceFromPlayer < 4)
                            drawFilledCircle(0, -2, 1.4, ColorUtil.applyOpacity(c, .25f).getRGB(), quality);

                        if (distanceFromPlayer < 20)
                            drawFilledCircle(0, -2, 2.3, ColorUtil.applyOpacity(c, .15f).getRGB(), quality);


                        WorldRenderUtil.matrices().scale(0.8f, 0.8f, 0.8f);

                        WorldRenderUtil.matrices().pop();

                    }

                }
                WorldRenderUtil.end3D();
                break;
            }
            case "Line":
                renderLine(path, colors);
                break;
        }
    }

    @Override
    public void onEnable() {
        path.clear();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        path.clear();
        super.onDisable();
    }

    public void renderLine(final List<Vec3d> path) {
        renderLine(path, Pair.of(Color.WHITE, Color.WHITE));
    }

    public void renderLine(final List<Vec3d> path, Pair<Color, Color> colors) {
        Vec3d cam = WorldRenderUtil.cameraPos();
        WorldRenderUtil.start3D();
        WorldRenderUtil.begin(RenderLayers.LINES);

        boolean custom = colorMode.is("Custom") && this.color.isRainbow();
        int count = 0;
        int alpha = 200;
        int fadeOffset = 15;
        for (Vec3d v : path) {
            if (fadeOffset > count) {
                alpha = count * (200 / fadeOffset);
            }

            int argb;
            if (custom || isRainbowTheme()) {
                if (custom) {
                    argb = this.color.getRainbow().getColor(count * 2).getRGB();
                } else {
                    argb = HUDMod.color1.getRainbow().getColor(count * 2).getRGB();
                }
            } else {
                argb = interpolateColorsBackAndForth(15, count * 5, colors.getFirst(), colors.getSecond(), false).getRGB();
            }
            WorldRenderUtil.color(argb, alpha / 255f);
            WorldRenderUtil.vertex(v.x - cam.x, v.y - cam.y, v.z - cam.z);
            count++;
        }

        WorldRenderUtil.end3D();
    }

    /**
     * Port of RenderUtil.drawFilledCircleNoGL: a GL_TRIANGLE_FAN disc built from ring
     * vertices only (first vertex acts as the fan hub).
     */
    private static void drawFilledCircle(int x, int y, double r, int c, int quality) {
        WorldRenderUtil.begin(RenderLayers.debugTriangleFan());
        WorldRenderUtil.color(c);
        for (int i = 0; i <= 360 / quality; i++) {
            final double x2 = Math.sin(((i * quality * Math.PI) / 180)) * r;
            final double y2 = Math.cos(((i * quality * Math.PI) / 180)) * r;
            WorldRenderUtil.vertex(x + x2, y + y2, 0);
        }
    }

    private static boolean isRainbowTheme() {
        return HUDMod.theme.is("Custom Theme") && HUDMod.color1.isRainbow();
    }

    private static Color interpolateColorsBackAndForth(int speed, int index, Color start, Color end, boolean trueColor) {
        int angle = (int) (((System.currentTimeMillis()) / speed + index) % 360);
        angle = (angle >= 180 ? 360 - angle : angle) * 2;
        return ColorUtil.interpolateColorC(start, end, angle / 360f);
    }

}
