package dev.tenacity.module.impl.render.killeffects;

import dev.tenacity.utils.Utils;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;

/**
 * @author senoe
 * @since 6/14/2022
 */
public class EffectManager implements Utils {

    public void playKillEffect(KillEffects.Location location) {
        switch (KillEffects.killEffect.getMode()) {
            case "Blood Explosion":
                playBlockBreak(location.x, location.y, location.z, location.eyeHeight);
                break;
            case "Lightning Bolt":
                LightningEntity lightning = new LightningEntity(EntityType.LIGHTNING_BOLT, mc.world);
                lightning.refreshPositionAfterTeleport(location.x, location.y, location.z);
                mc.world.addEntity(lightning);
                mc.world.playSound(mc.player, location.x, location.y, location.z,
                        SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.WEATHER, 5.0F, 1.0F,
                        mc.world.getRandom().nextLong());
                break;
        }
    }

    private void playBlockBreak(double x, double y, double z, double eyeHeight) {
        BlockPos pos = BlockPos.ofFloored(x, y + eyeHeight, z);
        // Original called playAuxSFX(2001, pos, 152) which spawns block-break
        // particles of block 152 (redstone block) plus its break sound.
        mc.world.addBlockBreakParticles(pos, Blocks.REDSTONE_BLOCK.getDefaultState());
        mc.world.playSound(mc.player, x, y + eyeHeight, z,
                SoundEvents.BLOCK_METAL_BREAK, SoundCategory.BLOCKS, 1.0F, 1.0F,
                mc.world.getRandom().nextLong());
    }

}
