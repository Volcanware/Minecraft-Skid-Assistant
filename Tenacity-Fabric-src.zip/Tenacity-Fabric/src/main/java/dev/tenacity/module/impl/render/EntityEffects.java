package dev.tenacity.module.impl.render;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.event.impl.render.Render3DEvent;
import dev.tenacity.event.impl.render.RenderModelEvent;
import dev.tenacity.event.impl.render.ShaderEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.ui.notifications.NotificationType;
import dev.tenacity.utils.render.ESPUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class EntityEffects extends Module {

    private final MultipleBoolSetting validEntities = new MultipleBoolSetting("Valid Entities",
            new BooleanSetting("Players", true),
            new BooleanSetting("Animals", true),
            new BooleanSetting("Mobs", true));

    private final BooleanSetting blur = new BooleanSetting("Blur", true);
    private final BooleanSetting bloom = new BooleanSetting("Bloom", true);
    private final BooleanSetting blackBloom = new BooleanSetting("Black Bloom", true);

    public EntityEffects() {
        super("Entity Effects", Category.RENDER, "Very unnecessary blur of entities");
        blackBloom.addParent(bloom, s -> s.isEnabled());
        addSettings(validEntities, blur, bloom, blackBloom);
    }

    @Override
    public void onEnable() {
        if (Tenacity.INSTANCE.isEnabled(PostProcessing.class)) {
            super.onEnable();
        } else {
            Tenacity.INSTANCE.getNotificationManager().post(NotificationType.WARNING, "Error", "Post Processing is not enabled");
            toggleSilent();
        }
    }

    public final List<Entity> entities = new ArrayList<>();
    private final java.util.Set<Entity> glowingEntities = new java.util.HashSet<>();

    @Override
    public void onDisable() {
        super.onDisable();
        for (Entity e : glowingEntities) {
            if (e != null) e.setGlowing(false);
        }
        glowingEntities.clear();
        entities.clear();
    }

    public Color getColorFor(Entity e) {
        return blackBloom.isEnabled() ? new Color(0x22, 0x22, 0x22) : Tenacity.INSTANCE.getClientColor();
    }

    @Override
    public void onRender3DEvent(Render3DEvent event) {
        entities.clear();
        for (final Entity entity : mc.world.getEntities()) {
            if (shouldRender(entity) && ESPUtil.isInView(entity)) {
                entities.add(entity);
            }
        }
        for (Entity e : glowingEntities) {
            if (e != null && !entities.contains(e)) e.setGlowing(false);
        }
        glowingEntities.removeIf(e -> e == null || !entities.contains(e));
        for (Entity e : entities) {
            if (e == null || e.isRemoved()) continue;
            e.setGlowing(true);
            glowingEntities.add(e);
        }
    }

    @Override
    public void onRenderModelEvent(RenderModelEvent event) {
        // NOTE: 1.8.9 rendered entities into an offscreen framebuffer for blur/bloom.
        // The 1.21 GPU pipeline handles blurs inside PostProcessing — model hook is a no-op here.
        if (event.isPost() && entities.contains(event.getEntity())) {
            event.drawModel();
            event.drawLayers();
        }
    }

    @Override
    public void onShaderEvent(ShaderEvent e) {
        // Offscreen shader pass handled by the 1.21 post pipeline; nothing to draw manually.
    }

    @Override
    public void onRender2DEvent(Render2DEvent event) {
        // No framebuffer resize needed — post pipeline manages its own targets.
    }

    private boolean shouldRender(Entity entity) {
        if (!entity.isAlive() || entity.isInvisible()) {
            return false;
        }
        if (validEntities.getSetting("Players").isEnabled() && entity instanceof PlayerEntity) {
            if (entity == mc.player) {
                return !mc.options.getPerspective().isFirstPerson();
            }
            return !(entity.getDisplayName() != null && entity.getDisplayName().getString().contains("[NPC"));
        }
        if (validEntities.getSetting("Animals").isEnabled() && entity instanceof AnimalEntity) {
            return true;
        }
        return validEntities.getSetting("Mobs").isEnabled() && entity instanceof HostileEntity;
    }
}
