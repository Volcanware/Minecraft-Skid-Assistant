package dev.tenacity.module.impl.player;

import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.player.BlockUtils;
import dev.tenacity.utils.player.InventoryUtils;
import dev.tenacity.utils.player.ItemUtils;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.Slot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class InvManager extends Module {

    private BooleanSetting inventoryPackets, onlyWhileNotMoving, inventoryOnly, swapBlocks, dropArchery, moveArrows, dropFood, dropShears;
    private final MultipleBoolSetting options = new MultipleBoolSetting("Options",
            inventoryPackets = new BooleanSetting("Send inventory packets", true),
            onlyWhileNotMoving = new BooleanSetting("Only while not moving", false),
            inventoryOnly = new BooleanSetting("Inventory only", false),
            swapBlocks = new BooleanSetting("Swap blocks", false),
            dropArchery = new BooleanSetting("Drop archery", false),
            moveArrows = new BooleanSetting("Move arrows", true),
            dropFood = new BooleanSetting("Drop food", false),
            dropShears = new BooleanSetting("Drop shears", true)
    );

    private final NumberSetting delay = new NumberSetting("Delay", 120, 300, 0, 10);
    private static final NumberSetting slotWeapon = new NumberSetting("Weapon Slot", 1, 9, 1, 1);
    private static final NumberSetting slotPick = new NumberSetting("Pickaxe Slot", 2, 9, 1, 1);
    private static final NumberSetting slotAxe = new NumberSetting("Axe Slot", 3, 9, 1, 1);
    private static final NumberSetting slotShovel = new NumberSetting("Shovel Slot", 4, 9, 1, 1);
    private static final NumberSetting slotBow = new NumberSetting("Bow Slot", 5, 9, 1, 1);
    private static final NumberSetting slotBlock = new NumberSetting("Block Slot", 6, 9, 1, 1);
    private static final NumberSetting slotGapple = new NumberSetting("Gapple Slot", 7, 9, 1, 1);

    private final String[] blacklist = {"tnt", "stick", "egg", "string", "cake", "mushroom", "flint", "compass", "dyePowder", "feather", "bucket", "chest", "snow", "fish", "enchant", "exp", "anvil", "torch", "seeds", "leather", "reeds", "skull", "record", "snowball", "piston"};
    private final String[] serverItems = {"selector", "tracking compass", "(right click)", "tienda ", "perfil", "salir", "shop", "collectibles", "game", "profil", "lobby", "show all", "hub", "friends only", "cofre", "(click", "teleport", "play", "exit", "hide all", "jeux", "gadget", " (activ", "emote", "amis", "bountique", "choisir", "choose ", "recipe book", "click derecho", "todos", "teletransportador", "configuraci", "jugar de nuevo"};
    private final List<RegistryEntry<StatusEffect>> badPotionIDs = new ArrayList<>(Arrays.asList(StatusEffects.SLOWNESS, StatusEffects.WEAKNESS, StatusEffects.POISON, StatusEffects.INSTANT_DAMAGE));

    private final TimerUtil timer = new TimerUtil();
    private boolean isInvOpen;

    public InvManager() {
        super("InvManager", Category.PLAYER, "cleans up your inventory");
        inventoryPackets.addParent(inventoryOnly, s -> !s.isEnabled());
        moveArrows.addParent(dropArchery, s -> !s.isEnabled());
        slotGapple.addParent(dropFood, s -> !s.isEnabled());
        addSettings(options, delay, slotWeapon, slotPick, slotAxe, slotShovel, slotBow, slotBlock, slotGapple);
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        if (e.isPost() || canContinue()) return;
        if (!mc.player.isUsingItem() && (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen || mc.currentScreen instanceof InventoryScreen || mc.currentScreen instanceof GameMenuScreen)) {
            if (isReady()) {
                Slot slot = ItemType.WEAPON.getSlot();
                if (!slot.hasStack() || !isBestWeapon(slot.getStack())) {
                    getBestWeapon();
                }
            }
            getBestPickaxe();
            getBestAxe();
            getBestShovel();
            dropItems();
            swapBlocks();
            getBestBow();
            moveArrows();
            moveFood();
        }
    }

    @Override
    public void onPacketSendEvent(PacketSendEvent e) {
        if (isInvOpen) {
            Packet<?> packet = e.getPacket();
            if ((false /* OPEN_INVENTORY removed in 1.21 */)
                    || packet instanceof CloseHandledScreenC2SPacket) {
                e.cancel();
            } else if (packet instanceof PlayerInteractEntityC2SPacket) {
                fakeClose();
            }
        }
    }

    private boolean isReady() {
        return timer.hasTimeElapsed((long) delay.getValue());
    }

    public static float getDamageScore(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return 0;

        float damage = 0;
        Item item = stack.getItem();

        if (stack.isIn(ItemTags.SWORDS)) {
            damage += (float) ItemUtils.getAttributeValue(stack, EntityAttributes.ATTACK_DAMAGE);
        } else if (ItemUtils.isTool(stack)) {
            damage += item.getComponents().get(net.minecraft.component.DataComponentTypes.MAX_DAMAGE) != null ? item.getComponents().get(net.minecraft.component.DataComponentTypes.MAX_DAMAGE) : 0;
        }

        damage += ItemUtils.getEnchantLevel(stack, Enchantments.SHARPNESS) * 1.25F +
                ItemUtils.getEnchantLevel(stack, Enchantments.FIRE_ASPECT) * 0.1F;

        return damage;
    }

    public static float getProtScore(ItemStack stack) {
        float prot = 0;
        if (ItemUtils.isArmor(stack)) {
            float armor = (float) ItemUtils.getAttributeValue(stack, EntityAttributes.ARMOR);
            prot += armor + ((100 - armor) * ItemUtils.getEnchantLevel(stack, Enchantments.PROTECTION)) * 0.0075F;
            prot += ItemUtils.getEnchantLevel(stack, Enchantments.BLAST_PROTECTION) / 100F;
            prot += ItemUtils.getEnchantLevel(stack, Enchantments.FIRE_PROTECTION) / 100F;
            prot += ItemUtils.getEnchantLevel(stack, Enchantments.THORNS) / 100F;
            prot += ItemUtils.getEnchantLevel(stack, Enchantments.UNBREAKING) / 25.F;
            prot += ItemUtils.getEnchantLevel(stack, Enchantments.FEATHER_FALLING) / 100F;
        }
        return prot;
    }

    private void dropItems() {
        if (!isReady()) return;
        for (int i = 9; i < 45; i++) {
            if (canContinue()) return;
            Slot slot = mc.player.playerScreenHandler.getSlot(i);
            ItemStack is = slot.getStack();
            if (!is.isEmpty() && isBadItem(is, i, false)) {
                InventoryUtils.drop(i);
                timer.reset();
                break;
            }
        }
    }

    private boolean isBestWeapon(ItemStack is) {
        if (is == null || is.isEmpty()) return false;
        float damage = getDamageScore(is);
        for (int i = 9; i < 45; i++) {
            Slot slot = mc.player.playerScreenHandler.getSlot(i);
            if (slot.hasStack()) {
                ItemStack is2 = slot.getStack();
                if (getDamageScore(is2) > damage && is2.isIn(ItemTags.SWORDS)) {
                    return false;
                }
            }
        }
        return is.isIn(ItemTags.SWORDS);
    }

    private void getBestWeapon() {
        for (int i = 9; i < 45; i++) {
            ItemStack is = mc.player.playerScreenHandler.getSlot(i).getStack();
            if (!is.isEmpty() && is.isIn(ItemTags.SWORDS) && isBestWeapon(is) && getDamageScore(is) > 0) {
                swap(i, ItemType.WEAPON.getDesiredSlot() - 36);
                break;
            }
        }
    }

    // stealing is true when called from the ChestStealer module because returning true = ignore, but in invmanager returning true = drop
    public boolean isBadItem(ItemStack stack, int slot, boolean stealing) {
        Item item = stack.getItem();
        String stackName = stack.getName().getString().toLowerCase(), ulName = item.getTranslationKey();
        if (Arrays.stream(serverItems).anyMatch(stackName::contains)) return stealing;

        if (item instanceof BlockItem) {
            return !BlockUtils.isValidBlock(((BlockItem) item).getBlock(), true);
        }

        if (stealing) {
            if (isBestWeapon(stack) || isBestAxe(stack) || isBestPickaxe(stack) || isBestBow(stack) || isBestShovel(stack)) {
                return false;
            }
            if (ItemUtils.isArmor(stack)) {
                for (int type = 1; type < 5; type++) {
                    ItemStack is = mc.player.playerScreenHandler.getSlot(type + 4).getStack();
                    if (!is.isEmpty()) {
                        if (ItemUtils.isArmorFor(stack, ItemUtils.getArmorEquipmentSlot(type)) && getProtScore(is) > getProtScore(stack)) {
                            continue;
                        }
                    }
                    if (isBestArmor(stack, type)) {
                        return false;
                    }
                }
            }
        }

        int weaponSlot = ItemType.WEAPON.getDesiredSlot(), pickaxeSlot = ItemType.PICKAXE.getDesiredSlot(),
                axeSlot = ItemType.AXE.getDesiredSlot(), shovelSlot = ItemType.SHOVEL.getDesiredSlot();

        if (stealing || (slot != weaponSlot || !isBestWeapon(ItemType.WEAPON.getStackInSlot()))
                && (slot != pickaxeSlot || !isBestPickaxe(ItemType.PICKAXE.getStackInSlot()))
                && (slot != axeSlot || !isBestAxe(ItemType.AXE.getStackInSlot()))
                && (slot != shovelSlot || !isBestShovel(ItemType.SHOVEL.getStackInSlot()))) {
            if (!stealing && ItemUtils.isArmor(stack)) {
                for (int type = 1; type < 5; type++) {
                    ItemStack is = mc.player.playerScreenHandler.getSlot(type + 4).getStack();
                    if (!is.isEmpty() && isBestArmor(is, type)) {
                        continue;
                    }
                    if (isBestArmor(stack, type)) {
                        return false;
                    }
                }
            }

            if ((item == Items.WHEAT) || item instanceof SpawnEggItem
                    || (stack.contains(DataComponentTypes.FOOD) && dropFood.isEnabled() && item != Items.GOLDEN_APPLE && item != Items.ENCHANTED_GOLDEN_APPLE)
                    || (item instanceof PotionItem && isBadPotion(stack))) {
                return true;
            } else if (!stack.isIn(ItemTags.SWORDS) && !ItemUtils.isTool(stack) && !stack.isIn(ItemTags.HOES) && !ItemUtils.isArmor(stack)) {
                if (dropArchery.isEnabled() && (item instanceof BowItem || item == Items.ARROW)) {
                    return true;
                } else {
                    return (dropShears.isEnabled() && ulName.contains("shears")) || item == Items.GLASS_BOTTLE || Arrays.stream(blacklist).anyMatch(ulName::contains);
                }
            }
            return true;
        }

        return false;
    }

    private void getBestPickaxe() {
        if (!isReady()) return;
        for (int i = 9; i < 45; i++) {
            Slot slot = mc.player.playerScreenHandler.getSlot(i);
            if (slot.hasStack()) {
                ItemStack is = slot.getStack();
                if (isBestPickaxe(is) && !isBestWeapon(is)) {
                    int desiredSlot = ItemType.PICKAXE.getDesiredSlot();
                    if (i == desiredSlot) return;
                    Slot slot2 = mc.player.playerScreenHandler.getSlot(desiredSlot);
                    if (!slot2.hasStack() || !isBestPickaxe(slot2.getStack())) {
                        swap(i, desiredSlot - 36);
                    }
                }
            }
        }
    }

    private void getBestAxe() {
        if (!isReady()) return;
        for (int i = 9; i < 45; i++) {
            Slot slot = mc.player.playerScreenHandler.getSlot(i);
            if (slot.hasStack()) {
                ItemStack is = slot.getStack();
                if (isBestAxe(is) && !isBestWeapon(is)) {
                    int desiredSlot = ItemType.AXE.getDesiredSlot();
                    if (i == desiredSlot) return;
                    Slot slot2 = mc.player.playerScreenHandler.getSlot(desiredSlot);
                    if (!slot2.hasStack() || !isBestAxe(slot2.getStack())) {
                        swap(i, desiredSlot - 36);
                        timer.reset();
                    }
                }
            }
        }
    }

    private void getBestShovel() {
        if (!isReady()) return;
        for (int i = 9; i < 45; i++) {
            Slot slot = mc.player.playerScreenHandler.getSlot(i);
            if (slot.hasStack()) {
                ItemStack is = slot.getStack();
                if (isBestShovel(is) && !isBestWeapon(is)) {
                    int desiredSlot = ItemType.SHOVEL.getDesiredSlot();
                    if (i == desiredSlot) return;
                    Slot slot2 = mc.player.playerScreenHandler.getSlot(desiredSlot);
                    if (!slot2.hasStack() || !isBestShovel(slot2.getStack())) {
                        swap(i, desiredSlot - 36);
                        timer.reset();
                    }
                }
            }
        }
    }

    private void getBestBow() {
        if (!isReady()) return;
        for (int i = 9; i < 45; i++) {
            Slot slot = mc.player.playerScreenHandler.getSlot(i);
            if (slot.hasStack()) {
                ItemStack is = slot.getStack();
                String stackName = is.getName().getString().toLowerCase();
                if (Arrays.stream(serverItems).anyMatch(stackName::contains) || !(is.getItem() instanceof BowItem))
                    continue;
                if (isBestBow(is) && !isBestWeapon(is)) {
                    int desiredSlot = ItemType.BOW.getDesiredSlot();
                    if (i == desiredSlot) return;
                    Slot slot2 = mc.player.playerScreenHandler.getSlot(desiredSlot);
                    if (!slot2.hasStack() || !isBestBow(slot2.getStack())) {
                        swap(i, desiredSlot - 36);
                    }
                }
            }
        }
    }

    private void moveArrows() {
        if (dropArchery.isEnabled() || !moveArrows.isEnabled() || !isReady()) return;
        for (int i = 36; i < 45; i++) {
            ItemStack is = mc.player.playerScreenHandler.getSlot(i).getStack();
            if (!is.isEmpty() && is.getItem() == Items.ARROW) {
                for (int j = 0; j < 36; j++) {
                    if (mc.player.playerScreenHandler.getSlot(j).getStack().isEmpty()) {
                        fakeOpen();
                        InventoryUtils.click(i, 0, true);
                        fakeClose();
                        timer.reset();
                        break;
                    }
                }
            }
        }
    }

    private void moveFood() {
        if (dropFood.isEnabled() || !isReady()) return;
        for (int i = 9; i < 45; i++) {
            Slot slot = mc.player.playerScreenHandler.getSlot(i);
            if (slot.hasStack()) {
                ItemStack is = slot.getStack();
                if (hasMostGapples(is)) {
                    int desiredSlot = ItemType.GAPPLE.getDesiredSlot();
                    if (i == desiredSlot) return;
                    Slot slot2 = mc.player.playerScreenHandler.getSlot(desiredSlot);
                    if (!slot2.hasStack() || !hasMostGapples(slot2.getStack())) {
                        swap(i, desiredSlot - 36);
                    }
                }
            }
        }
    }

    private boolean hasMostGapples(ItemStack stack) {
        Item item = stack.getItem();
        if (!(item == Items.GOLDEN_APPLE || item == Items.ENCHANTED_GOLDEN_APPLE)) {
            return false;
        } else {
            int value = stack.getCount();
            for (int i = 9; i < 45; i++) {
                Slot slot = mc.player.playerScreenHandler.getSlot(i);
                if (slot.hasStack()) {
                    ItemStack is = slot.getStack();
                    if ((is.getItem() == Items.GOLDEN_APPLE || is.getItem() == Items.ENCHANTED_GOLDEN_APPLE) && is.getCount() > value) {
                        return false;
                    }
                }
            }
            return true;
        }

    }

    private int getMostBlocks() {
        int stack = 0;
        int biggestSlot = -1;
        for (int i = 9; i < 45; i++) {
            Slot slot = mc.player.playerScreenHandler.getSlot(i);
            ItemStack is = slot.getStack();
            if (!is.isEmpty() && is.getItem() instanceof BlockItem && is.getCount() > stack && Arrays.stream(serverItems).noneMatch(is.getName().getString().toLowerCase()::contains)) {
                stack = is.getCount();
                biggestSlot = i;
            }
        }
        return biggestSlot;
    }

    private void swapBlocks() {
        if (!swapBlocks.isEnabled() || !isReady()) return;
        int mostBlocksSlot = getMostBlocks();
        int desiredSlot = ItemType.BLOCK.getDesiredSlot();
        if (mostBlocksSlot != -1 && mostBlocksSlot != desiredSlot) {
            // only switch if the hotbar slot doesn't already have blocks of the same quantity to prevent an inf loop
            Slot dss = mc.player.playerScreenHandler.getSlot(desiredSlot);
            ItemStack dsis = dss.getStack();
            if (!(dsis != null && !dsis.isEmpty() && dsis.getItem() instanceof BlockItem && dsis.getCount() >= mc.player.playerScreenHandler.getSlot(mostBlocksSlot).getStack().getCount() && Arrays.stream(serverItems).noneMatch(dsis.getName().getString().toLowerCase()::contains))) {
                swap(mostBlocksSlot, desiredSlot - 36);
            }
        }
    }

    private boolean isBestPickaxe(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (!stack.isIn(ItemTags.PICKAXES)) {
            return false;
        } else {
            float value = getToolScore(stack);
            for (int i = 9; i < 45; i++) {
                Slot slot = mc.player.playerScreenHandler.getSlot(i);
                if (slot.hasStack()) {
                    ItemStack is = slot.getStack();
                    if (is.isIn(ItemTags.PICKAXES) && getToolScore(is) > value) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    private boolean isBestShovel(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (!stack.isIn(ItemTags.SHOVELS)) {
            return false;
        } else {
            float score = getToolScore(stack);
            for (int i = 9; i < 45; i++) {
                Slot slot = mc.player.playerScreenHandler.getSlot(i);
                if (slot.hasStack()) {
                    ItemStack is = slot.getStack();
                    if (is.isIn(ItemTags.SHOVELS) && getToolScore(is) > score) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    private boolean isBestAxe(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (!stack.isIn(ItemTags.AXES)) {
            return false;
        } else {
            float value = getToolScore(stack);
            for (int i = 9; i < 45; i++) {
                Slot slot = mc.player.playerScreenHandler.getSlot(i);
                if (slot.hasStack()) {
                    ItemStack is = slot.getStack();
                    if (getToolScore(is) > value && is.isIn(ItemTags.AXES) && !isBestWeapon(is)) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    private boolean isBestBow(ItemStack stack) {
        if (!(stack.getItem() instanceof BowItem)) {
            return false;
        } else {
            float value = getBowScore(stack);
            for (int i = 9; i < 45; i++) {
                Slot slot = mc.player.playerScreenHandler.getSlot(i);
                if (slot.hasStack()) {
                    ItemStack is = slot.getStack();
                    if (getBowScore(is) > value && is.getItem() instanceof BowItem && !isBestWeapon(stack)) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    private float getBowScore(ItemStack stack) {
        float score = 0;
        Item item = stack.getItem();
        if (item instanceof BowItem) {
            score += ItemUtils.getEnchantLevel(stack, Enchantments.POWER);
            score += ItemUtils.getEnchantLevel(stack, Enchantments.FLAME) * 0.5F;
            score += ItemUtils.getEnchantLevel(stack, Enchantments.UNBREAKING) * 0.1F;
        }
        return score;
    }

    private float getToolScore(ItemStack stack) {
        float score = 0;
        if (ItemUtils.isTool(stack)) {
            Item item = stack.getItem();
            String name = item.getTranslationKey().toLowerCase();
            if (stack.isIn(ItemTags.PICKAXES)) {
                score = stack.getMiningSpeedMultiplier(Blocks.STONE.getDefaultState()) - (name.contains("gold") ? 5 : 0);
            } else if (stack.isIn(ItemTags.SHOVELS)) {
                score = stack.getMiningSpeedMultiplier(Blocks.DIRT.getDefaultState()) - (name.contains("gold") ? 5 : 0);
            } else {
                if (!stack.isIn(ItemTags.AXES)) return 1;
                score = stack.getMiningSpeedMultiplier(Blocks.OAK_LOG.getDefaultState()) - (name.contains("gold") ? 5 : 0);
            }
            score += ItemUtils.getEnchantLevel(stack, Enchantments.EFFICIENCY) * 0.0075F;
            score += ItemUtils.getEnchantLevel(stack, Enchantments.UNBREAKING) / 100F;
        }
        return score;
    }

    private boolean isBadPotion(ItemStack stack) {
        if (stack != null && !stack.isEmpty() && stack.getItem() instanceof PotionItem) {
            PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
            Iterable<StatusEffectInstance> effects = contents != null ? contents.getEffects() : null;
            if (effects != null) {
                for (StatusEffectInstance effect : effects) {
                    if (badPotionIDs.contains(effect.getEffectType())) {
                        return true;
                    }
                }
            } else {
                return true;
            }
        }
        return false;
    }

    private boolean isBestArmor(ItemStack stack, int type) {
        EquipmentSlot equipmentSlot = ItemUtils.getArmorEquipmentSlot(type);
        if (ItemUtils.isArmorFor(stack, equipmentSlot)) {
            float prot = getProtScore(stack);
            for (int i = 5; i < 45; i++) {
                Slot slot = mc.player.playerScreenHandler.getSlot(i);
                if (slot.hasStack()) {
                    ItemStack is = slot.getStack();
                    if (ItemUtils.isArmorFor(is, equipmentSlot) && getProtScore(is) > prot) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }

    private void fakeOpen() {
        if (!isInvOpen) {
            timer.reset();
            if (!inventoryOnly.isEnabled() && inventoryPackets.isEnabled())
                // OPEN_INVENTORY removed in 1.21
            isInvOpen = true;
        }
    }

    private void fakeClose() {
        if (isInvOpen) {
            if (!inventoryOnly.isEnabled() && inventoryPackets.isEnabled())
                PacketUtils.sendPacketNoEvent(new CloseHandledScreenC2SPacket(mc.player.playerScreenHandler.syncId));
            isInvOpen = false;
        }
    }

    private void swap(int slot, int hSlot) {
        fakeOpen();
        InventoryUtils.swap(slot, hSlot);
        fakeClose();
        timer.reset();
    }

    private boolean canContinue() {
        return (inventoryOnly.isEnabled() && !(mc.currentScreen instanceof InventoryScreen)) || (onlyWhileNotMoving.isEnabled() && MovementUtils.isMoving());
    }

    private enum ItemType {
        WEAPON(slotWeapon),
        PICKAXE(slotPick),
        AXE(slotAxe),
        SHOVEL(slotShovel),
        BLOCK(slotBlock),
        BOW(slotBow),
        GAPPLE(slotGapple);

        private final NumberSetting setting;

        ItemType(NumberSetting setting) {
            this.setting = setting;
        }

        public NumberSetting getSetting() {
            return setting;
        }

        public int getDesiredSlot() {
            return (int) setting.getValue() + 35;
        }

        public Slot getSlot() {
            return mc.player.playerScreenHandler.getSlot(getDesiredSlot());
        }

        public ItemStack getStackInSlot() {
            return getSlot().getStack();
        }
    }

}
