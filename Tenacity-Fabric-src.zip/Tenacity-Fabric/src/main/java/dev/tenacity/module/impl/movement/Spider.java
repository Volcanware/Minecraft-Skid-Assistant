package dev.tenacity.module.impl.movement;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;

public final class Spider extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Verus");

    public Spider() {
        super("Spider", Category.MOVEMENT, "Climbs you up walls like a spider");
        addSettings(mode);
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        setSuffix(mode.getMode());
        if (mc.player.horizontalCollision) {
            if (!mc.player.isOnGround() && mc.player.verticalCollision) return;
            switch (mode.getMode()) {
                case "Vanilla":
                    mc.player.jump();
                    break;
                case "Verus":
                    if (mc.player.age % 3 == 0)
                        mc.player.setVelocity(mc.player.getVelocity().x, 0.42f, mc.player.getVelocity().z);
                    break;
            }
        }
    }
}
