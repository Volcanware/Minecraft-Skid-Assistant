package dev.tenacity.module.impl.movement;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.StepConfirmEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.misc.TimerUtils;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

@SuppressWarnings("unused")
public final class Step extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "NCP", "Full Jump Packets");

    private final NumberSetting height = new NumberSetting("Height", 1, 1, 10, 0.5);

    private final NumberSetting timer = new NumberSetting("Timer", 1, 0.1, 2, 0.1);

    private boolean hasStepped;

    private final TimerUtil timerUtil = new TimerUtil();

    public static boolean isStepping;

    public Step() {
        super("Step", Category.MOVEMENT, "step up blocks");
        this.addSettings(mode, height, timer);
    }

    // stepHeight was moved to the STEP_HEIGHT entity attribute in 1.20.5+
    private float getStepHeight() {
        return (float) mc.player.getAttributeValue(EntityAttributes.STEP_HEIGHT);
    }

    private void setStepHeight(float stepHeight) {
        EntityAttributeInstance attributeInstance = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (attributeInstance != null) {
            attributeInstance.setBaseValue(stepHeight);
        }
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        setSuffix(mode.getMode());
        if (mc.player.isOnGround()) {
            if (getStepHeight() != height.getFloatValue()) setStepHeight(height.getFloatValue());
        } else {
            if (getStepHeight() != 0.625f) setStepHeight(0.625f);
        }
        if (timerUtil.hasTimeElapsed(20) && hasStepped) {
            TimerUtils.setTimerSpeed(1);
            hasStepped = false;
            isStepping = false;
        }
    }

    @Override
    public void onStepConfirmEvent(StepConfirmEvent event) {
        double diffY = mc.player.getBoundingBox().minY - mc.player.getY();
        if (diffY > 0.625f && diffY <= 1.5f && mc.player.isOnGround()) {
            TimerUtils.setTimerSpeed(timer.getFloatValue());
            timerUtil.reset();
            hasStepped = true;
            isStepping = true;
            switch (mode.getMode()) {
                case "NCP":
                    for (double offset : new double[]{0.41999998688698, 0.7531999805212})
                        PacketUtils.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(), mc.player.getY() + offset, mc.player.getZ(), false, false));
                    break;
                case "Full Jump Packets":
                    for (double offset : new double[]{0.41999998688698, 0.7531999805212, 1.00133597911214, 1.16610926093821, 1.24918707874468, 1.24918707874468, 1.1707870772188, 1.0155550727022})
                        PacketUtils.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(), mc.player.getY() + offset, mc.player.getZ(), false, false));
                    break;
            }
        }
    }

    @Override
    public void onDisable() {
        setStepHeight(0.625f);
        super.onDisable();
    }

}
