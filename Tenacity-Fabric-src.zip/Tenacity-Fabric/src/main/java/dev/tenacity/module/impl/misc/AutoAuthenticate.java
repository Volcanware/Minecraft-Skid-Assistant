package dev.tenacity.module.impl.misc;

import dev.tenacity.event.impl.game.WorldEvent;
import dev.tenacity.event.impl.player.ChatReceivedEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.module.settings.impl.StringSetting;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.EaseInOutQuad;
import dev.tenacity.utils.misc.ChatUtil;
import dev.tenacity.utils.render.RenderUtil;

import java.awt.*;

public class AutoAuthenticate extends Module {

    private final NumberSetting delay = new NumberSetting("Delay", 2000, 5000, 0, 100);
    private final StringSetting password = new StringSetting("Password", "dog123");
    private final Animation animation = new EaseInOutQuad(500, 1);
    private final String[] PASSWORD_PLACEHOLDERS = {"password", "pass", "contrasena", "contraseña"};
    private long runAt, startAt;
    private String runCommand;

    public AutoAuthenticate() {
        super("AutoAuthenticate", Category.MISC, "Auto login/register on cracked servers");
        this.addSettings(delay, password);
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        if (this.runAt < System.currentTimeMillis() && this.runCommand != null) {
            animation.setDirection(Direction.BACKWARDS);
            ChatUtil.send(runCommand);
            reset();
        }
    }

    @Override
    public void onChatReceivedEvent(ChatReceivedEvent event) {
        String msg = event.message.getString();
        String password = this.password.getString();
        int passCount = count(msg);
        if (passCount > 0) {
            if (msg.contains("/register ")) {
                setRun("/register " + (password + " ").repeat(passCount));
            } else if (msg.contains("/login ")) {
                setRun("/login " + (password + " ").repeat(passCount));
            }
        }
    }

    @Override
    public void onRender2DEvent(Render2DEvent event) {
        if ((this.runAt > System.currentTimeMillis() && this.runCommand != null) || !animation.isDone()) {
            float scaledWidth = ctx().getScaledWindowWidth(), scaledHeight = ctx().getScaledWindowHeight();
            float width = 120, height = 5, width2 = width / 2.0F;
            float calc = runAt == 0 ? 1 : (float) (System.currentTimeMillis() - startAt) / (float) (runAt - startAt),
                    scale = (float) animation.getOutput().floatValue(),
                    left = (scaledWidth / 2.0F) / scale - width2,
                    top = (scaledHeight / 2.0F + 30) / scale;

            RenderUtil.scaleStart(0, 0, scale);
            Color color = HUDMod.getClientColors().getFirst();
            RenderUtil.drawRect(left, top, width, height, color.darker().darker().getRGB());
            RenderUtil.drawRect(left, top, width * calc, height, color.getRGB());
            RenderUtil.scaleEnd();
        }
    }

    @Override
    public void onWorldEvent(WorldEvent event) {
        reset();
    }

    @Override
    public void onEnable() {
        reset();
        super.onEnable();
    }

    private int count(String data) {
        int count = 0;
        data = data.toLowerCase();
        for (String pass : PASSWORD_PLACEHOLDERS) {
            count += countMatches(data, pass);
        }
        return count;
    }

    private int countMatches(String data, String sub) {
        int count = 0, index = 0;
        while ((index = data.indexOf(sub, index)) != -1) {
            count++;
            index += sub.length();
        }
        return count;
    }

    private void setRun(String runCommand) {
        long currentTimeMillis = System.currentTimeMillis();
        this.animation.setDirection(Direction.FORWARDS);
        this.startAt = currentTimeMillis;
        this.runAt = currentTimeMillis + (long) delay.getValue();
        this.runCommand = runCommand.trim();
    }

    private void reset() {
        this.animation.setDirection(Direction.BACKWARDS);
        this.startAt = this.runAt = 0;
        this.runCommand = null;
    }

}
