package dev.tenacity.module.impl.combat;

import dev.tenacity.Tenacity;
import dev.tenacity.utils.misc.FriendUtils;
import dev.tenacity.event.impl.player.AttackEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.player.AttackOrder;
import dev.tenacity.utils.player.RotationUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class IdleFighter extends Module {

    private LivingEntity target;
    private final List<LivingEntity> targets = new ArrayList<>();

    private final MultipleBoolSetting targetsSetting = new MultipleBoolSetting("Targets",
            new BooleanSetting("Players", true),
            new BooleanSetting("Animals", false),
            new BooleanSetting("Mobs", false),
            new BooleanSetting("Invisibles", false));

    private final NumberSetting minCPS = new NumberSetting("Min CPS", 10, 20, 1, 1);
    private final NumberSetting maxCPS = new NumberSetting("Max CPS", 10, 20, 1, 1);

    private final NumberSetting reach = new NumberSetting("Reach", 4, 6, 3, 0.1);

    private final TimerUtil attackTimer = new TimerUtil();

    public IdleFighter() {
        super("IdleFighter", Category.COMBAT, "Automatically finds the nearest player and attempts to kill them");
        this.addSettings(targetsSetting, minCPS, maxCPS, reach);
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        if (minCPS.getValue() > maxCPS.getValue()) {
            minCPS.setValue(minCPS.getValue() - 1);
        }

        mc.options.forwardKey.setPressed(target != null && !(mc.player.distanceTo(target) <= reach.getValue()));
        mc.options.jumpKey.setPressed(mc.player.horizontalCollision || mc.player.isTouchingWater());

        if (event.isPre()) {
            sortTargets();
            if (!targets.isEmpty()) {
                target = targets.get(0);
                final float[] rotations = RotationUtils.getRotations(target.getX(), target.getY(), target.getZ());
                mc.player.setYaw(rotations[0]);
                mc.player.setPitch(rotations[1]);

                if (mc.player.distanceTo(target) <= reach.getValue() && attackTimer.hasTimeElapsed((long) (1000 / MathUtils.getRandomInRange(minCPS.getValue(), maxCPS.getValue())))) {
                    AttackEvent attackEvent = new AttackEvent(target);
                    Tenacity.INSTANCE.getEventProtocol().handleEvent(attackEvent);

                    if (!attackEvent.isCancelled()) {
                        AttackOrder.sendFixedAttack(mc.player, target);
                    }
                    attackTimer.reset();
                }
            } else {
                target = null;
            }
        }
    }

    @Override
    public void onDisable() {
        target = null;
        mc.options.forwardKey.setPressed(false);
        targets.clear();
        super.onDisable();
    }

    private void sortTargets() {
        targets.clear();
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof LivingEntity) {
                LivingEntity livingEntity = (LivingEntity) entity;
                if (isValid(entity) && mc.player != livingEntity && !FriendUtils.isFriend(livingEntity.getName().getString())) {
                    targets.add(livingEntity);
                }
            }
        }
        targets.sort(Comparator.comparingDouble(mc.player::distanceTo));
    }

    private boolean isValid(Entity entity) {
        if (entity instanceof PlayerEntity && targetsSetting.getSetting("Players").isEnabled() && !entity.isInvisible())
            return true;

        if (entity instanceof PlayerEntity && targetsSetting.getSetting("Invisibles").isEnabled() && entity.isInvisible())
            return true;

        if (entity instanceof AnimalEntity && targetsSetting.getSetting("Animals").isEnabled())
            return true;

        if (entity instanceof HostileEntity && targetsSetting.getSetting("Mobs").isEnabled())
            return true;

        if (entity.isInvisible() && targetsSetting.getSetting("Invisibles").isEnabled())
            return true;

        return false;
    }

}
