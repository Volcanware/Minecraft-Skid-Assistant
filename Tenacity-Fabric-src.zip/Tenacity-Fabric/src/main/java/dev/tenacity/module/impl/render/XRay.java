package dev.tenacity.module.impl.render;

import dev.tenacity.event.impl.player.PlayerMoveUpdateEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.misc.Multithreading;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

import java.awt.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

/**
 * @author cedo
 * @since 03/24/2022
 */
public class XRay extends Module {
    public static final NumberSetting opacity = new NumberSetting("Opacity", 60, 100, 0, 1);
    public static final BooleanSetting bypass = new BooleanSetting("Anti-xray bypass", false);
    public static final HashSet<BlockPos> checkedOres = new HashSet<>(), queuedOres = new HashSet<>(), oresToRender = new HashSet<>();
    public static boolean enabled;
    private static BooleanSetting redstone, diamond, emerald, lapis, iron, coal, gold;
    private final MultipleBoolSetting ores = new MultipleBoolSetting("Ores",
            redstone = new BooleanSetting("Redstone", true),
            diamond = new BooleanSetting("Diamond", true),
            emerald = new BooleanSetting("Emerald", true),
            lapis = new BooleanSetting("Lapis", true),
            iron = new BooleanSetting("Iron", true),
            coal = new BooleanSetting("Coal", true),
            gold = new BooleanSetting("Gold", true)
    );
    private final HashSet<Block> blocks = new HashSet<>(Arrays.asList(Blocks.OBSIDIAN, Blocks.CLAY, Blocks.MOSSY_COBBLESTONE, Blocks.DIAMOND_ORE, Blocks.REDSTONE_ORE, Blocks.IRON_ORE, Blocks.COAL_ORE, Blocks.GOLD_ORE, Blocks.EMERALD_ORE, Blocks.LAPIS_ORE));
    // 1.21 has no ore base class (BlockOre/BlockRedstoneOre are gone), so ore-ness is a set membership test.
    private final HashSet<Block> oreBlocks = new HashSet<>(Arrays.asList(
            Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE,
            Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE,
            Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE,
            Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE,
            Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE,
            Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
            Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE,
            Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE,
            Blocks.NETHER_QUARTZ_ORE, Blocks.NETHER_GOLD_ORE, Blocks.ANCIENT_DEBRIS));
    private final TimerUtil updateTimer = new TimerUtil(), searchTimer = new TimerUtil();
    private World lastWorld;


    public XRay() {
        super("XRay", Category.RENDER, "Shows blocks through the world");
        addSettings(ores, opacity, bypass);
    }

    @Override
    public void onPlayerMoveUpdateEvent(PlayerMoveUpdateEvent e) {
        if (bypass.isEnabled() && !mc.isIntegratedServerRunning()) {
            if (updateTimer.hasTimeElapsed(2000)) {
                search();
                updateTimer.reset();
            }
            if (!queuedOres.isEmpty()) {
                Multithreading.runAsync(() -> {
                    for (int i = 0; i < 18; i++) {
                        if (queuedOres.size() < 1 || queuedOres.size() < i + 1) return;
                        BlockPos pos = queuedOres.iterator().next();
                        queuedOres.remove(pos);
                        PacketUtils.sendPacketNoEvent(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.ABORT_DESTROY_BLOCK, pos, Direction.DOWN));
                        checkedOres.add(pos);
                        Multithreading.schedule(() -> checkedOres.remove(pos), 30, TimeUnit.SECONDS);
                    }
                });
            }
        }
    }

    public static boolean isWhitelisted(Block block) {
        for (Ore o : Ore.values()) {
            if (o.ore == block) {
                return o.setting.isEnabled();
            }
        }
        return false;
    }

    public static boolean isExposed(BlockView worldIn, BlockPos pos, Direction side, double minY, double maxY, double minZ, double maxZ, double minX, double maxX) {
        return side == Direction.DOWN && minY > 0.0D || (side == Direction.UP && maxY < 1.0D || (side == Direction.NORTH && minZ > 0.0D || (side == Direction.SOUTH && maxZ < 1.0D || (side == Direction.WEST && minX > 0.0D || (side == Direction.EAST && maxX < 1.0D || !worldIn.getBlockState(pos).isOpaque())))));
    }

    @Override
    public void onEnable() {
        enabled = true;
        mc.worldRenderer.reload();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        enabled = false;
        super.onDisable();
        mc.worldRenderer.reload();
    }

    public void search() {
        if (mc.world != null && lastWorld != mc.world) {
            lastWorld = mc.world;
            oresToRender.clear();
            checkedOres.clear();
            queuedOres.clear();
        }

        int radius = 3;
        Multithreading.runAsync(() -> {
            for (int x = -radius; x <= radius; x++) {
                for (int y = -radius; y <= radius; y++) {
                    for (int z = -radius; z <= radius; z++) {
                        BlockPos pos = BlockPos.ofFloored(mc.player.getX() + x, mc.player.getY() + y, mc.player.getZ() + z);
                        Block block = mc.world.getBlockState(pos).getBlock();

                        if (oreBlocks.contains(block)) {
                            if (!checkedOres.contains(pos) && !queuedOres.contains(pos) && blocks.contains(block)) {
                                if (shouldAdd(pos)) {
                                    queuedOres.add(pos);
                                }
                            }
                        }
                    }
                }
            }
        });
    }

    public boolean shouldAdd(BlockPos pos) {
        Box bounds = mc.world.getBlockState(pos).getOutlineShape(mc.world, pos).getBoundingBox();
        for (Direction si : Direction.values()) {
            if (isExposed(mc.world, pos.offset(si), si, bounds.minY, bounds.maxY, bounds.minZ, bounds.maxZ, bounds.minX, bounds.maxX)) {
                return false;
            }
        }
        return true;
    }

    private enum Ore {
        DIAMOND(Blocks.DIAMOND_ORE, new Color(93, 235, 245), diamond),
        IRON(Blocks.IRON_ORE, Color.WHITE, iron),
        GOLD(Blocks.GOLD_ORE, new Color(239, 236, 79), gold),
        REDSTONE(Blocks.REDSTONE_ORE, Color.RED, redstone),
        // lit_redstone_ore is gone in 1.21 (lit is a blockstate property of REDSTONE_ORE)
        REDSTONE_LIT(Blocks.REDSTONE_ORE, Color.RED, redstone),
        COAL(Blocks.COAL_ORE, Color.BLACK, coal),
        LAPIS(Blocks.LAPIS_ORE, new Color(21, 69, 185), lapis),
        EMERALD(Blocks.EMERALD_ORE, new Color(23, 221, 98), emerald);

        private final Block ore;
        private final Color color;
        private final BooleanSetting setting;

        Ore(Block ore, Color color, BooleanSetting setting) {
            this.ore = ore;
            this.color = color;
            this.setting = setting;
        }
    }

}
