package dev.tenacity.module.impl.render;

import dev.tenacity.utils.tuples.Pair;
import dev.tenacity.event.impl.render.RenderChestEvent;
import dev.tenacity.event.impl.render.RenderModelEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ColorSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.awt.*;

public class Chams extends Module {


    private final MultipleBoolSetting entities = new MultipleBoolSetting("Entities", "Players", "Animals", "Mobs", "Chests");

    private final BooleanSetting lighting = new BooleanSetting("Lighting", true);
    private final BooleanSetting onlyBehindWalls = new BooleanSetting("Only behind walls", false);
    private final ModeSetting behindWalls = new ModeSetting("Not Visible", "Sync", "Sync", "Opposite", "Red", "Custom");
    private final ColorSetting wallColor = new ColorSetting("Not Visible Color", Color.red);
    private final ModeSetting visibleColorMode = new ModeSetting("Visible", "Sync", "Sync", "Custom");
    private final ColorSetting visibleColor = new ColorSetting("Visible Color", Color.BLUE);


    public Chams() {
        super("Chams", Category.RENDER, "See people through walls");
        wallColor.addParent(behindWalls, behindWalls -> behindWalls.is("Custom"));
        visibleColorMode.addParent(onlyBehindWalls, s -> !s.isEnabled());
        visibleColor.addParent(visibleColorMode, modeSetting -> modeSetting.is("Custom"));
        addSettings(entities, lighting, onlyBehindWalls, behindWalls, wallColor, visibleColorMode, visibleColor);
    }


    @Override
    public void onRenderChestEvent(RenderChestEvent event) {
        if (!entities.isEnabled("Chests")) return;
        Color behindWallsColor = Color.WHITE;
        Pair<Color, Color> colors = HUDMod.getClientColors();
        switch (behindWalls.getMode()) {
            case "Sync":
                behindWallsColor = colors.getSecond();
                break;
            case "Opposite":
                behindWallsColor = getOppositeColor(colors.getFirst());
                break;
            case "Red":
                behindWallsColor = new Color(0xffEF2626);
                break;
            case "Custom":
                behindWallsColor = wallColor.getColor();
                break;
        }

        Color visibleColor = Color.WHITE;
        switch (visibleColorMode.getMode()) {
            case "Sync":
                visibleColor = colors.getFirst();
                break;
            case "Custom":
                visibleColor = this.visibleColor.getColor();
                break;
        }


        setShaderColor(behindWallsColor.getRGB());

        // "Lighting" off and GL_TEXTURE_2D off had no direct equivalent in the shader
        // pipeline; the tint below approximates the flat-color look.

        event.drawChest();


        setShaderColor(-1);

        if (!onlyBehindWalls.isEnabled()) {
            setShaderColor(visibleColor.getRGB());
            event.drawChest();
            event.cancel();
        }

        setShaderColor(-1);
    }

    @Override
    public void onRenderModelEvent(RenderModelEvent event) {
        if (!isValidEntity(event.getEntity())) return;

        Pair<Color, Color> colors = HUDMod.getClientColors();
        if (event.isPre()) {
            Color behindWallsColor = Color.WHITE;

            switch (behindWalls.getMode()) {
                case "Sync":
                    behindWallsColor = colors.getSecond();
                    break;
                case "Opposite":
                    behindWallsColor = getOppositeColor(colors.getFirst());
                    break;
                case "Red":
                    behindWallsColor = new Color(0xffEF2626);
                    break;
                case "Custom":
                    behindWallsColor = wallColor.getColor();
                    break;
            }

            // GL_POLYGON_OFFSET_LINE and the lightmap override (fullbright) have no
            // direct per-call equivalent in the shader pipeline; tint via color modulate.
            setShaderColor(behindWallsColor.getRGB());

        } else {

            Color visibleColor = Color.WHITE;
            switch (visibleColorMode.getMode()) {
                case "Sync":
                    visibleColor = colors.getFirst();
                    break;
                case "Custom":
                    visibleColor = this.visibleColor.getColor();
                    break;
            }

            if (onlyBehindWalls.isEnabled()) {
                setShaderColor(-1);
            } else {
                setShaderColor(visibleColor.getRGB());
            }


            event.drawModel();


            setShaderColor(-1);
        }

    }

    private static void setShaderColor(int argb) {
        float a = ((argb >> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
    }

    public final java.util.List<Entity> chamsEntities = new java.util.ArrayList<>();
    private final java.util.Set<Entity> glowing = new java.util.HashSet<>();

    @Override
    public void onRender3DEvent(dev.tenacity.event.impl.render.Render3DEvent event) {
        // 1.21 equivalent of through-wall chams: vanilla outline glow colored
        // per entity via EntityMixin#getTeamColorValue.
        chamsEntities.clear();
        for (Entity entity : mc.world.getEntities()) {
            if (!isValidEntity(entity) || entity.isRemoved()) continue;
            if (entity == mc.player && mc.options.getPerspective().isFirstPerson()) continue;
            chamsEntities.add(entity);
        }
        for (Entity e : glowing) {
            if (e != null && !chamsEntities.contains(e)) e.setGlowing(false);
        }
        glowing.removeIf(e -> e == null || !chamsEntities.contains(e));
        for (Entity e : chamsEntities) {
            e.setGlowing(true);
            glowing.add(e);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        for (Entity e : glowing) {
            if (e != null) e.setGlowing(false);
        }
        glowing.clear();
        chamsEntities.clear();
    }

    public Color getColorFor(Entity entity) {
        Pair<Color, Color> colors = HUDMod.getClientColors();
        Color behindWallsColor;
        switch (behindWalls.getMode()) {
            case "Sync" -> behindWallsColor = colors.getSecond();
            case "Opposite" -> behindWallsColor = getOppositeColor(colors.getFirst());
            case "Red" -> behindWallsColor = new Color(0xffEF2626);
            default -> behindWallsColor = wallColor.getColor();
        }
        if (onlyBehindWalls.isEnabled()) return behindWallsColor;
        return switch (visibleColorMode.getMode()) {
            case "Sync" -> colors.getFirst();
            default -> this.visibleColor.getColor();
        };
    }

    public boolean hasEntity(Entity e) {
        return chamsEntities.contains(e);
    }

    private static Color getOppositeColor(Color color) {
        int rgb = color.getRGB();
        int r = 255 - ((rgb >> 16) & 0xFF);
        int g = 255 - ((rgb >> 8) & 0xFF);
        int b = 255 - (rgb & 0xFF);
        int a = (rgb >> 24) & 0xFF;
        return new Color(r, g, b, a);
    }

    private boolean isValidEntity(Entity entity) {
        return entities.isEnabled("Players") && entity instanceof PlayerEntity ||
                entities.isEnabled("Animals") && entity instanceof AnimalEntity ||
                entities.isEnabled("Mobs") && entity instanceof HostileEntity;
    }


}
