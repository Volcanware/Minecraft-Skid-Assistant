package dev.tenacity.module.impl.movement;

import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.packet.s2c.play.CloseScreenS2CPacket;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import org.lwjgl.glfw.GLFW;

import java.util.Arrays;
import java.util.List;

public final class InventoryMove extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Spoof", "Delay");
    private final TimerUtil delayTimer = new TimerUtil();
    private boolean wasInContainer;

    private static final List<KeyBinding> keys = Arrays.asList(
            mc.options.forwardKey,
            mc.options.backKey,
            mc.options.leftKey,
            mc.options.rightKey,
            mc.options.jumpKey
    );

    public InventoryMove() {
        super("InventoryMove", Category.MOVEMENT, "lets you move in your inventory");
        addSettings(mode);
    }

    private static boolean isKeyDown(KeyBinding keyBinding) {
        InputUtil.Key key = InputUtil.fromTranslationKey(keyBinding.getBoundKeyTranslationKey());
        long handle = mc.getWindow().getHandle();
        if (key.getCategory() == InputUtil.Type.KEYSYM) {
            return InputUtil.isKeyPressed(mc.getWindow(), key.getCode());
        }
        return GLFW.glfwGetMouseButton(handle, key.getCode()) == GLFW.GLFW_PRESS;
    }

    public static void updateStates() {
        if (mc.currentScreen != null) {
            keys.forEach(k -> k.setPressed(isKeyDown(k)));
        }
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        boolean inContainer = mc.currentScreen instanceof HandledScreen;
        if (wasInContainer && !inContainer) {
            wasInContainer = false;
            updateStates();
        }
        switch (mode.getMode()) {
            case "Spoof":
            case "Vanilla":
                if (inContainer) {
                    wasInContainer = true;
                    updateStates();
                }
                break;
            case "Delay":
                if (e.isPre() && inContainer) {
                    if (delayTimer.hasTimeElapsed(100)) {
                        wasInContainer = true;
                        updateStates();
                        delayTimer.reset();
                    }
                }
                break;
        }
    }

    @Override
    public void onPacketReceiveEvent(PacketReceiveEvent e) {
        if (mode.is("Spoof") && (e.getPacket() instanceof OpenScreenS2CPacket || e.getPacket() instanceof CloseScreenS2CPacket)) {
            e.cancel();
        }
    }

}
