package dev.tenacity.module.impl.movement;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.MoveEvent;
import dev.tenacity.event.impl.player.PlayerMoveUpdateEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.combat.TargetStrafe;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.ui.notifications.NotificationType;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.misc.TimerUtils;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.player.RotationUtils;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.math.BlockPos;

import java.util.concurrent.ThreadLocalRandom;

@SuppressWarnings("unused")
public final class Speed extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Watchdog",
            "Watchdog", "Strafe", "Matrix", "HurtTime", "Vanilla", "BHop", "Verus", "Viper", "Vulcan", "Zonecraft", "Heatseeker", "Mineland");
    private final ModeSetting watchdogMode = new ModeSetting("Watchdog Mode", "Hop", "Hop", "Dev", "Low Hop", "Ground");
    private final ModeSetting verusMode = new ModeSetting("Verus Mode", "Normal", "Low", "Normal");
    private final ModeSetting viperMode = new ModeSetting("Viper Mode", "Normal", "High", "Normal");
    private final BooleanSetting autoDisable = new BooleanSetting("Auto Disable", false);
    private final NumberSetting groundSpeed = new NumberSetting("Ground Speed", 2, 1, 5, 0.1);
    private final NumberSetting timer = new NumberSetting("Timer", 1, 1, 5, 0.1);
    private final NumberSetting vanillaSpeed = new NumberSetting("Speed", 1, 1, 10, 0.1);

    private final TimerUtil timerUtil = new TimerUtil();
    private final float r = ThreadLocalRandom.current().nextFloat();
    private double speed, lastDist;
    private float speedChangingDirection;
    private int stage;
    private boolean strafe, wasOnGround;
    private boolean setTimer = true;
    private double moveSpeed;
    private int inAirTicks;

    public Speed() {
        super("Speed", Category.MOVEMENT, "Makes you go faster");
        watchdogMode.addParent(mode, modeSetting -> modeSetting.is("Watchdog"));
        verusMode.addParent(mode, modeSetting -> modeSetting.is("Verus"));
        viperMode.addParent(mode, modeSetting -> modeSetting.is("Viper"));
        groundSpeed.addParent(watchdogMode, modeSetting -> modeSetting.is("Ground") && mode.is("Watchdog"));
        vanillaSpeed.addParent(mode, modeSetting -> modeSetting.is("Vanilla") || modeSetting.is("BHop"));
        this.addSettings(mode, vanillaSpeed, watchdogMode, verusMode, viperMode, autoDisable, groundSpeed, timer);
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        this.setSuffix(mode.getMode());
        if (setTimer) {
            TimerUtils.setTimerSpeed(timer.getFloatValue());
        }

        double distX = e.getX() - mc.player.lastRenderX, distZ = e.getZ() - mc.player.lastRenderZ;
        lastDist = Math.hypot(distX, distZ);

        switch (mode.getMode()) {
            case "Watchdog":
                switch (watchdogMode.getMode()) {
                    case "Hop":
                    case "Low Hop":
                    case "Dev":
                        if (e.isPre()) {
                            if (MovementUtils.isMoving() && mc.player.fallDistance < 1) {
                                if (mc.player.isOnGround()) {
                                    mc.player.jump();
                                }
                            }
                        }
                        break;
                }
                break;
            case "Heatseeker":
                if (e.isPre()) {
                    if (mc.player.isOnGround()) {
                        if (timerUtil.hasTimeElapsed(300, true)) {
                            strafe = !strafe;
                        }
                        if (strafe) {
                            MovementUtils.setSpeed(1.5);
                        }
                    }
                }
                break;
            case "Mineland":
                if (e.isPre()) {
                    stage++;
                    if (stage == 1)
                        mc.player.setVelocity(mc.player.getVelocity().x, 0.2, mc.player.getVelocity().z);

                    if (mc.player.isOnGround() && stage > 1)
                        MovementUtils.setSpeed(0.5);

                    if (stage % 14 == 0)
                        stage = 0;
                }
                break;
            case "Vulcan":
                if (e.isPre()) {
                    if (mc.player.isOnGround()) {
                        if (MovementUtils.isMoving()) {
                            mc.player.jump();
                            MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * 1.6);
                            inAirTicks = 0;
                        }
                    } else {
                        inAirTicks++;
                        if (inAirTicks == 1)
                            MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * 1.16);
                    }
                }
                break;
            case "Zonecraft":
                if (e.isPre()) {
                    if (mc.player.isOnGround()) {
                        mc.player.jump();
                        MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * 1.8);
                        stage = 0;
                    } else {
                        if (stage == 0 && !mc.player.horizontalCollision)
                            mc.player.setVelocity(mc.player.getVelocity().x, -0.4, mc.player.getVelocity().z);
                        stage++;
                    }
                }
                break;
            case "Matrix":
                if (MovementUtils.isMoving()) {
                    if (mc.player.isOnGround() && mc.player.getVelocity().y < 0.003) {
                        mc.player.jump();
                        TimerUtils.setTimerSpeed(1.0f);
                    }
                    if (mc.player.getVelocity().y > 0.003) {
                        mc.player.setVelocity(mc.player.getVelocity().x * speed, mc.player.getVelocity().y, mc.player.getVelocity().z * speed);
                        TimerUtils.setTimerSpeed(1.05f);
                    }
                    speed = 1.0012f;
                }
                break;
            case "HurtTime":
                if (MovementUtils.isMoving()) {
                    if (mc.player.hurtTime <= 0) {
                        mc.player.setVelocity(mc.player.getVelocity().x * 1.001f, mc.player.getVelocity().y, mc.player.getVelocity().z * 1.001f);
                    } else {
                        mc.player.setVelocity(mc.player.getVelocity().x * 1.0294f, mc.player.getVelocity().y, mc.player.getVelocity().z * 1.0294f);
                    }
                    if (mc.player.isOnGround() && mc.player.getVelocity().y < 0.003) {
                        mc.player.jump();
                    }
                }
                break;
            case "Vanilla":
                if (MovementUtils.isMoving()) {
                    MovementUtils.setSpeed(vanillaSpeed.getValue() / 4);
                }
                break;
            case "BHop":
                if (MovementUtils.isMoving()) {
                    MovementUtils.setSpeed(vanillaSpeed.getValue() / 4);
                    if (mc.player.isOnGround()) {
                        mc.player.jump();
                    }
                }
                break;
            case "Verus":
                switch (verusMode.getMode()) {
                    case "Low":
                        if (e.isPre()) {
                            if (MovementUtils.isMoving()) {
                                if (mc.player.isOnGround()) {
                                    mc.player.jump();
                                    wasOnGround = true;
                                } else if (wasOnGround) {
                                    if (!mc.player.horizontalCollision) {
                                        mc.player.setVelocity(mc.player.getVelocity().x, -0.0784000015258789, mc.player.getVelocity().z);
                                    }
                                    wasOnGround = false;
                                }
                                MovementUtils.setSpeed(0.33);
                            } else {
                                mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
                            }
                        }
                        break;
                    case "Normal":
                        if (e.isPre()) {
                            if (MovementUtils.isMoving()) {
                                if (mc.player.isOnGround()) {
                                    mc.player.jump();
                                    MovementUtils.setSpeed(0.48);
                                } else {
                                    MovementUtils.setSpeed(MovementUtils.getSpeed());
                                }
                            } else {
                                MovementUtils.setSpeed(0);
                            }
                        }
                        break;
                }
                break;
            case "Viper":
                switch (viperMode.getMode()) {
                    case "High":
                        if (mc.player.isOnGround()) {
                            mc.player.setVelocity(mc.player.getVelocity().x, 0.7, mc.player.getVelocity().z);
                        }
                        break;
                    case "Normal":
                        if (mc.player.isOnGround()) {
                            mc.player.setVelocity(mc.player.getVelocity().x, 0.42, mc.player.getVelocity().z);
                        }
                        break;
                }
                MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * 1.2);
                break;
            case "Strafe":
                if (e.isPre() && MovementUtils.isMoving()) {
                    if (mc.player.isOnGround()) {
                        mc.player.jump();
                    } else {
                        MovementUtils.setSpeed(MovementUtils.getSpeed());
                    }
                }
                break;
        }

    }

    @Override
    public void onMoveEvent(MoveEvent e) {
        if (mode.is("Watchdog")) {
            switch (watchdogMode.getMode()) {
                case "Ground":
                    strafe = !strafe;
                    if (mc.player.isOnGround() && MovementUtils.isMoving() && mc.world.getBlockState(BlockPos.ofFloored(mc.player.getX() + e.getX(), mc.player.getY(), mc.player.getZ() + e.getZ())).isAir() && !mc.player.horizontalCollision && !Step.isStepping) {
                        if (strafe || groundSpeed.getValue() >= 1.6)
                            PacketUtils.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX() + e.getX(), mc.player.getY(), mc.player.getZ() + e.getZ(), true, false));
                        MovementUtils.setSpeed(e, MovementUtils.getBaseMoveSpeed() * groundSpeed.getValue());
                        break;
                    }
                    break;
                case "Low Hop":
                    if (MovementUtils.isMoving()) {
                        if (mc.player.isOnGround())
                            inAirTicks = 0;
                        else
                            inAirTicks++;
                        if (inAirTicks == 5) {
                            mc.player.setVelocity(mc.player.getVelocity().x, -0.19, mc.player.getVelocity().z);
                            e.setY(-0.19);
                        }
                    }
                    break;
            }
        }
        TargetStrafe.strafe(e);
    }

    @Override
    public void onPlayerMoveUpdateEvent(PlayerMoveUpdateEvent e) {
        if (mode.is("Watchdog") && (watchdogMode.is("Hop") || watchdogMode.is("Dev") || watchdogMode.is("Low Hop")) && mc.player.fallDistance < 1 && !mc.player.hasStatusEffect(StatusEffects.JUMP_BOOST)) {
            if (MovementUtils.isMoving()) {
                switch (watchdogMode.getMode()) {
                    case "Low Hop":
                    case "Hop":
                        if (mc.player.isOnGround())
                            speed = 1.5f;
                        speed -= 0.025;
                        e.applyMotion(MovementUtils.getBaseMoveSpeed() * speed, 0.55f);
                        break;
                    case "Dev":
                        if (mc.player.isOnGround()) {
                            moveSpeed = MovementUtils.getBaseMoveSpeed() * 2.1475 * 0.76;
                            wasOnGround = true;
                        } else if (wasOnGround) {
                            moveSpeed = lastDist - 0.81999 * (lastDist - MovementUtils.getBaseMoveSpeed());
                            moveSpeed *= 1 / 0.91;
                            wasOnGround = false;
                        } else {
                            moveSpeed -= TargetStrafe.canStrafe() ? lastDist / 100.0 : lastDist / 150.0;
                        }
                        if (mc.player.isTouchingWater() || mc.player.isInLava()) {
                            speed = MovementUtils.getBaseMoveSpeed() * 0.25;
                        } else {
                            speed = Math.max(moveSpeed, MovementUtils.getBaseMoveSpeed());
                        }
                        e.applyMotion(speed, 0.6f);
                        break;
                }
            } else {
                e.applyMotion(0, 0);
            }
        }
    }

    @Override
    public void onPacketReceiveEvent(PacketReceiveEvent e) {
        if (e.getPacket() instanceof PlayerPositionLookS2CPacket && autoDisable.isEnabled()) {
            Tenacity.INSTANCE.getNotificationManager().post(NotificationType.WARNING, "Flag Detector",
                    "Speed disabled due to " +
                            (mc.player == null || mc.player.age < 5
                                    ? "world change"
                                    : "lagback"), 1.5F);
            this.toggleSilent();
        }
    }

    public boolean shouldPreventJumping() {
        return Tenacity.INSTANCE.isEnabled(Speed.class) && MovementUtils.isMoving() && !(mode.is("Watchdog") && watchdogMode.is("Ground"));
    }

    @Override
    public void onEnable() {
        speed = 1.5f;
        timerUtil.reset();
        if (mc.player != null) {
            wasOnGround = mc.player.isOnGround();
        }
        inAirTicks = 0;
        moveSpeed = 0;
        stage = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        TimerUtils.setTimerSpeed(1);
        mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
        super.onDisable();
    }

}
