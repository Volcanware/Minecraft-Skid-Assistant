package dev.tenacity.module.impl.render;

import dev.tenacity.event.impl.game.TickEvent;
import dev.tenacity.event.impl.player.PlayerSendMessageEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.utils.misc.IRCUtil;

public class IRC extends Module {

    public static final BooleanSetting shareUsername = new BooleanSetting("Share MC Username", true);

    public static boolean filter = false;

    /**
     * The original module used the client-wide IRC backend
     * (dev.tenacity.intent.irc.IntentIRC via Tenacity.INSTANCE.getIrcUtil()).
     * That backend is not ported; this local stub keeps the public API so the
     * module still compiles and behaves as if no IRC users were online.
     */
    private final IRCUtil ircUtil = new IRCUtil();

    public IRC() {
        super("IRC", Category.RENDER, "Internet Relay Chat for Tenacity and Intent client users");
        addSettings(shareUsername);
        this.setToggled(true);
    }


    @Override
    public void onTickEvent(TickEvent event) {
        ircUtil.onTick();
    }

    @Override
    public void onPlayerSendMessageEvent(PlayerSendMessageEvent event) {
        if (event.getMessage().startsWith("-")) {
            event.cancel();
            ircUtil.onMessage(event.getMessage().substring(1));
        }
    }

    public static String filter(String text) {
        if (filter) {
            for (String user : IRCUtil.usersMap.keySet()) {
                if (text.contains(user)) {
                    String ircName = " §7(§d" + IRCUtil.usersMap.get(user) + "§7)§r";
                    return text.replace(user, user + ircName);
                }
            }
        }
        return text;
    }


    @Override
    public void onDisable() {
        toggle();
    }

}
