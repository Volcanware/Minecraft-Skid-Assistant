package dev.tenacity.module.impl.player;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.movement.Speed;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.List;

public class AntiVoid extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Watchdog", "Watchdog");
    private final NumberSetting fallDist = new NumberSetting("Fall Distance", 3, 20, 1, 0.5);
    private final TimerUtil timer = new TimerUtil();
    private boolean reset;
    private double lastGroundY;

    private final List<Packet<?>> packets = new ArrayList<>();

    public AntiVoid() {
        super("AntiVoid", Category.PLAYER, "saves you from the void");
        this.addSettings(mode, fallDist);
    }

    @Override
    public void onPacketSendEvent(PacketSendEvent event) {
        if (mode.is("Watchdog") && !Tenacity.INSTANCE.getModuleCollection().getModule(Speed.class).isEnabled()) {
            if (event.getPacket() instanceof PlayerMoveC2SPacket) {
                if (!isBlockUnder()) {
                    if (mc.player.fallDistance < fallDist.getValue()) {
                        event.cancel();
                        packets.add(event.getPacket());
                    } else {
                        if (!packets.isEmpty()) {
                            for (Packet<?> packet : packets) {
                                final PlayerMoveC2SPacket move = (PlayerMoveC2SPacket) packet;
                                PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(
                                        move.getX(mc.player.getX()), lastGroundY, move.getZ(mc.player.getZ()), move.isOnGround(), move.horizontalCollision()));
                            }
                            packets.clear();
                        }
                    }
                } else {
                    lastGroundY = mc.player.getY();
                    if (!packets.isEmpty()) {
                        packets.forEach(PacketUtils::sendPacketNoEvent);
                        packets.clear();
                    }
                }
            }
        }
    }

    private boolean isBlockUnder() {
        if (mc.player.getY() < 0) return false;
        for (int offset = 0; offset < (int) mc.player.getY() + 2; offset += 2) {
            Box bb = mc.player.getBoundingBox().offset(0, -offset, 0);
            if (mc.world.getCollisions(mc.player, bb).iterator().hasNext()) {
                return true;
            }
        }
        return false;
    }

}
