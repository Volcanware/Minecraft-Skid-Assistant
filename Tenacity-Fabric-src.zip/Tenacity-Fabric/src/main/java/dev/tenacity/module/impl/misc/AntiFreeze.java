package dev.tenacity.module.impl.misc;

import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;

public final class AntiFreeze extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Normal", "Normal", "Teleport");

    @Override
    public void onPacketReceiveEvent(PacketReceiveEvent event) {
        if (event.getPacket() instanceof OpenScreenS2CPacket
                && ((OpenScreenS2CPacket) event.getPacket()).getName().getString().contains("frozen")) {
            event.cancel();
        } else if (event.getPacket() instanceof GameMessageS2CPacket
                && ((GameMessageS2CPacket) event.getPacket()).content().getString().contains("frozen")) {
            if (mode.is("Teleport")) {
                mc.player.setPos(mc.player.getX(), -999, mc.player.getZ());
            }
            event.cancel();
        }
    }

    public AntiFreeze() {
        super("AntiFreeze", Category.MISC, "prevents server plugins from freezing you");
    }

}
