package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.utils.animations.ContinualAnimation;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

import java.awt.*;

public class OldTenacityTargetHUD extends TargetHUD {

    private final ContinualAnimation animation = new ContinualAnimation();

    public OldTenacityTargetHUD() {
        super("Old Tenacity");
    }

    @Override
    public void render(float x, float y, float alpha, LivingEntity target) {
        setWidth(Math.max(145, tenacityBoldFont26().getStringWidthFloat(target.getName().getString()) + 40));
        setHeight(37);

        Color c1 = ColorUtil.applyOpacity(HUDMod.getClientColors().getFirst(), alpha);
        Color c2 = ColorUtil.applyOpacity(HUDMod.getClientColors().getSecond(), alpha);
        Color color = new Color(20, 18, 18, (int) (90 * alpha));

        int textColor = ColorUtil.applyOpacity(-1, alpha);

        RoundedUtil.drawRound(x, y, getWidth(), getHeight(), 4, color);

        if (target instanceof AbstractClientPlayerEntity) {
            renderPlayer2D(x + 3, y + 3, 31, 31, (AbstractClientPlayerEntity) target, textColor);
        } else {
            tenacityBoldFont32().drawCenteredStringWithShadow("?", x + 20, y + 17 - tenacityBoldFont32().getHeight() / 2f, textColor);
        }


        tenacityBoldFont26().drawStringWithShadow(target.getName().getString(), x + 39, y + 5, textColor);

        float healthPercent = MathHelper.clamp((target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0, 1);

        float realHealthWidth = getWidth() - 44;
        float realHealthHeight = 3;
        animation.animate(realHealthWidth * healthPercent, 18);
        Color backgroundHealthColor = new Color(0, 0, 0, ((int) alpha * 110));

        float healthWidth = animation.getOutput();

        RoundedUtil.drawRound(x + 39, (y + getHeight() - 12), 98, realHealthHeight, 1.5f, backgroundHealthColor);
        // drawGradientHorizontal(left->right) == drawGradientRound with matching left/right corner pairs
        RoundedUtil.drawGradientRound(x + 39, (y + getHeight() - 12), healthWidth, realHealthHeight, 1.5f, c1, c1, c2, c2);

        String healthText = (int) MathUtils.round(healthPercent * 100, .01) + "%";
        tenacityFont16().drawStringWithShadow(healthText, x + 34 + Math.min(Math.max(1, healthWidth), realHealthWidth - 11), y + getHeight() - (14 + tenacityFont16().getHeight()), textColor);
    }


    @Override
    public void renderEffects(float x, float y, float alpha, boolean glow) {
        RoundedUtil.drawRound(x, y, getWidth(), getHeight(), 4, ColorUtil.applyOpacity(Color.BLACK, alpha));
    }

}
