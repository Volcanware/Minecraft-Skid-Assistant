package dev.tenacity.module.impl.movement;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.player.NoSlow;
import dev.tenacity.module.settings.impl.BooleanSetting;

public class Sprint extends Module {

    private final BooleanSetting omniSprint = new BooleanSetting("Omni Sprint", false);

    public Sprint() {
        super("Sprint", Category.MOVEMENT, "Sprints automatically");
        this.addSettings(omniSprint);
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        if (Tenacity.INSTANCE.getModuleCollection().get(Scaffold.class).isEnabled() && (!Scaffold.sprint.isEnabled() || Scaffold.isDownwards())) {
            mc.options.sprintKey.setPressed(false);
            mc.player.setSprinting(false);
            return;
        }
        if (omniSprint.isEnabled()) {
            mc.player.setSprinting(true);
        } else {
            if (mc.player.isUsingItem()) {
                if (mc.player.forwardSpeed > 0 && (Tenacity.INSTANCE.isEnabled(NoSlow.class) || !mc.player.isUsingItem()) && !mc.player.isSneaking() && !mc.player.horizontalCollision && mc.player.getHungerManager().getFoodLevel() > 6) {
                    mc.player.setSprinting(true);
                }
            } else {
                mc.options.sprintKey.setPressed(true);
            }
        }
    }

    @Override
    public void onDisable() {
        mc.player.setSprinting(false);
        mc.options.sprintKey.setPressed(false);
        super.onDisable();
    }

}
