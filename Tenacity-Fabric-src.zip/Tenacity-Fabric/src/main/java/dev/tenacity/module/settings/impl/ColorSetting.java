package dev.tenacity.module.settings.impl;

import com.google.gson.JsonObject;
import dev.tenacity.module.settings.Setting;
import dev.tenacity.utils.render.ColorUtil;

import java.awt.*;

public class ColorSetting extends Setting {

    private float hue = 0;
    private float saturation = 1;
    private float brightness = 1;
    private Rainbow rainbow = null;

    public ColorSetting(String name, Color defaultColor) {
        this.name = name;
        this.setColor(defaultColor);
    }

    public Color getColor() {
        return isRainbow() ? getRainbow().getColor() : Color.getHSBColor(hue, saturation, brightness);
    }

    public Color getAltColor() {
        return isRainbow() ? getRainbow().getColor(40) : ColorUtil.darker(getColor(), .6f);
    }

    public void setColor(Color color) {
        float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
        hue = hsb[0];
        saturation = hsb[1];
        brightness = hsb[2];
    }

    public void setColor(float hue, float saturation, float brightness) {
        this.hue = hue;
        this.saturation = saturation;
        this.brightness = brightness;
    }

    public double getHue() {
        return hue;
    }

    public void setHue(float hue) {
        this.hue = hue;
    }

    public double getSaturation() {
        return saturation;
    }

    public void setSaturation(float saturation) {
        this.saturation = saturation;
    }

    public double getBrightness() {
        return brightness;
    }

    public void setBrightness(float brightness) {
        this.brightness = brightness;
    }

    public String getHexCode() {
        Color color = getColor();
        return String.format("%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
    }

    public boolean isRainbow() {
        return rainbow != null;
    }

    public Rainbow getRainbow() {
        return rainbow == null ? new Rainbow() : rainbow;
    }

    public void setRainbow(boolean isRainbow) {
        rainbow = isRainbow ? getRainbow() : null;
    }

    public void setRainbow(Rainbow rainbow) {
        this.rainbow = rainbow;
    }

    public JsonObject getConfigValueJSON() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("hue", getHue());
        jsonObject.addProperty("sat", getSaturation());
        jsonObject.addProperty("bri", getBrightness());
        jsonObject.addProperty("rainbow", isRainbow());
        if (isRainbow()) {
            jsonObject.addProperty("rainbowSpeed", getRainbow().getSpeed());
            jsonObject.addProperty("rainbowSat", getRainbow().getSaturation());
        }
        return jsonObject;
    }

    public void loadConfigValue(JsonObject jsonObject) {
        setHue(jsonObject.get("hue").getAsFloat());
        setSaturation(jsonObject.get("sat").getAsFloat());
        setBrightness(jsonObject.get("bri").getAsFloat());
        setRainbow(jsonObject.get("rainbow").getAsBoolean());
        if (isRainbow()) {
            getRainbow().setSpeed(jsonObject.get("rainbowSpeed").getAsInt());
            getRainbow().setSaturation(jsonObject.get("rainbowSat").getAsFloat());
        }
    }

    @Override
    public Object getConfigValue() {
        return getConfigValueJSON();
    }

    public static class Rainbow {
        private int speed = 25;
        private float saturation = 1;

        public Color getColor(int offset) {
            double rainbowState = Math.ceil((System.currentTimeMillis() / 3 + offset) / 20.0);
            rainbowState %= 360;
            return Color.getHSBColor((float) (rainbowState / 360.0f), saturation, 1);
        }

        public Color getColor() {
            return getColor(0);
        }

        public int getSpeed() { return speed; }
        public void setSpeed(int speed) { this.speed = speed; }
        public float getSaturation() { return saturation; }
        public void setSaturation(float saturation) { this.saturation = saturation; }
    }
}
