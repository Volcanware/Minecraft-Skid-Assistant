package dev.tenacity.module.impl.render;

import dev.tenacity.module.Category;
import dev.tenacity.module.Module;

public class NotificationsMod extends Module {

    private static NotificationsMod instance;
    private boolean enabled;

    public NotificationsMod() {
        super("Notifications", Category.RENDER, "Shows client notifications");
        instance = this;
        this.enabled = true;
        setToggledSilently(true);
    }

    public static boolean isToggled() {
        return instance == null || instance.enabled;
    }

    @Override
    public void onEnable() {
        enabled = true;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        enabled = false;
        super.onDisable();
    }
}
