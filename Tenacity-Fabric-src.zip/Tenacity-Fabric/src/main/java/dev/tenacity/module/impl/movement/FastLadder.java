package dev.tenacity.module.impl.movement;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.misc.TimerUtils;
import dev.tenacity.utils.server.PacketUtils;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class FastLadder extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Motion", "Motion", "Timer", "Position");
    private final NumberSetting speed = new NumberSetting("Speed", 1.5, 0.1, 5, 0.01);

    public FastLadder() {
        super("FastLadder", Category.MOVEMENT, "Climbs up ladders faster than normal");
        this.addSettings(mode, speed);
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        this.setSuffix(mode.getMode());
        if (mc.player.isClimbing()) {
            switch (mode.getMode()) {
                case "Timer":
                    TimerUtils.setTimerSpeed(speed.getFloatValue());
                    break;
                case "Motion":
                    mc.player.setVelocity(mc.player.getVelocity().x, speed.getValue(), mc.player.getVelocity().z);
                    break;
                case "Position":
                    PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.Full(
                            mc.player.getX(), mc.player.getY() + speed.getValue(), mc.player.getZ(),
                            mc.player.getYaw(), mc.player.getPitch(), false, false));
                    mc.player.setPosition(mc.player.getX(), mc.player.getY() + speed.getValue(), mc.player.getZ());
                    break;
            }
        } else {
            TimerUtils.setTimerSpeed(1);
        }
    }

    @Override
    public void onDisable() {
        TimerUtils.setTimerSpeed(1);
        super.onDisable();
    }

}
