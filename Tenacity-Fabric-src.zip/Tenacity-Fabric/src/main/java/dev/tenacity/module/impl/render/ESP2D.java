package dev.tenacity.module.impl.render;

import dev.tenacity.event.impl.render.NametagRenderEvent;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.event.impl.render.Render3DEvent;
import dev.tenacity.event.impl.render.ShaderEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.ParentAttribute;
import dev.tenacity.module.settings.impl.*;
import dev.tenacity.utils.misc.FriendUtils;
import dev.tenacity.utils.misc.IRCUtil;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.render.*;
import dev.tenacity.utils.tuples.Pair;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;

import java.awt.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class ESP2D extends Module {

    private final MultipleBoolSetting validEntities = new MultipleBoolSetting("Valid Entities",
            new BooleanSetting("Players", true),
            new BooleanSetting("Animals", true),
            new BooleanSetting("Mobs", true));


    private final BooleanSetting mcfont = new BooleanSetting("Minecraft Font", true);
    public final BooleanSetting boxEsp = new BooleanSetting("Box", true);
    private final ModeSetting boxColorMode = new ModeSetting("Box Mode", "Sync", "Sync", "Custom");
    private final ColorSetting boxColor = new ColorSetting("Box Color", Color.PINK);

    private final BooleanSetting itemHeld = new BooleanSetting("Item Held Text", true);
    private final BooleanSetting equipmentVisual = new BooleanSetting("Equipment", true);
    private final BooleanSetting healthBar = new BooleanSetting("Health Bar", true);
    private final ModeSetting healthBarMode = new ModeSetting("Health Bar Mode", "Color", "Health", "Color");
    private final BooleanSetting healthBarText = new BooleanSetting("Health Bar Text", true);


    private final BooleanSetting nametags = new BooleanSetting("Nametags", true);
    private final NumberSetting scale = new NumberSetting("Tag Scale", .75, 1, .35, .05);

    private final BooleanSetting redTags = new BooleanSetting("Red Tags", false);
    private final MultipleBoolSetting nametagSettings = new MultipleBoolSetting("Nametag Settings",
            redTags,
            new BooleanSetting("Formatted Tags", false),
            new BooleanSetting("Add PostProcessing", false),
            new BooleanSetting("Health Text", true),
            new BooleanSetting("Background", true),
            new BooleanSetting("Red Background", false),
            new BooleanSetting("Round", true));

    public ESP2D() {
        super("2D ESP", Category.RENDER, "Draws a box in 2D space around entitys");
        boxColorMode.addParent(boxEsp, ParentAttribute.BOOLEAN_CONDITION);
        boxColor.addParent(boxColorMode, modeSetting -> modeSetting.is("Custom"));

        scale.addParent(nametags, ParentAttribute.BOOLEAN_CONDITION);
        nametagSettings.addParent(nametags, ParentAttribute.BOOLEAN_CONDITION);
        healthBarMode.addParent(healthBar, ParentAttribute.BOOLEAN_CONDITION);
        healthBarText.addParent(healthBar, ParentAttribute.BOOLEAN_CONDITION);


        addSettings(validEntities, mcfont, boxEsp, boxColorMode, boxColor, itemHeld, healthBar, healthBarMode, healthBarText,
                equipmentVisual, nametags, scale, nametagSettings);
    }


    private final Map<Entity, Vector4f> entityPosition = new HashMap<>();

    @Override
    public void onNametagRenderEvent(NametagRenderEvent e) {
        if (nametags.isEnabled()) e.cancel();
    }

    @Override
    public void onRender3DEvent(Render3DEvent event) {
        entityPosition.clear();
        for (final Entity entity : mc.world.getEntities()) {
            if (shouldRender(entity) && ESPUtil.isInView(entity)) {
                entityPosition.put(entity, getEntityPositionsOn2D(entity, event.getTicks()));
            }
        }
    }

    /**
     * Projects the entity's interpolated bounding box into scaled screen space.
     * Replaces the old GLU-project-based ESPUtil.getEntityPositionsOn2D, which
     * relied on the fixed-function matrix stack.
     */
    private Vector4f getEntityPositionsOn2D(Entity entity, float partialTicks) {
        Camera camera = mc.gameRenderer.getCamera();
        Vec3d camPos = camera.getCameraPos();
        Box box = ESPUtil.getInterpolatedBoundingBox(entity);

        float fov = (float) mc.options.getFov().getValue().intValue();
        Matrix4f mvp = new Matrix4f(mc.gameRenderer.getBasicProjectionMatrix(fov))
                .mul(new Matrix4f().rotation(new Quaternionf(camera.getRotation()).conjugate()));

        float fbWidth = mc.getWindow().getFramebufferWidth();
        float fbHeight = mc.getWindow().getFramebufferHeight();
        float scaleFactor = (float) mc.getWindow().getScaleFactor();

        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            float cx = (float) ((i & 1) == 0 ? box.minX - camPos.x : box.maxX - camPos.x);
            float cy = (float) ((i & 2) == 0 ? box.minY - camPos.y : box.maxY - camPos.y);
            float cz = (float) ((i & 4) == 0 ? box.minZ - camPos.z : box.maxZ - camPos.z);
            Vector4f pos = new Vector4f(cx, cy, cz, 1f).mul(mvp);
            if (pos.w == 0) continue;
            float ndcX = pos.x / pos.w, ndcY = pos.y / pos.w;
            float sx = (ndcX + 1f) / 2f * fbWidth;
            float sy = (1f - ndcY) / 2f * fbHeight;
            minX = Math.min(minX, sx);
            minY = Math.min(minY, sy);
            maxX = Math.max(maxX, sx);
            maxY = Math.max(maxY, sy);
        }
        return new Vector4f(minX / scaleFactor, minY / scaleFactor, maxX / scaleFactor, maxY / scaleFactor);
    }

    private static final EquipmentSlot[] ARMOR_SLOTS = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};

    private String getName(LivingEntity entity) {
        Text displayName = entity.getDisplayName();
        if (displayName == null) return entity.getName().getString();
        if (nametagSettings.getSetting("Formatted Tags").isEnabled()) {
            // Recreate the old getFormattedText() output: literal text with section-code formatting.
            StringBuilder sb = new StringBuilder();
            displayName.visit((style, string) -> {
                TextColor color = style.getColor();
                if (color != null) {
                    Formatting formatting = Formatting.byName(color.getName());
                    if (formatting != null) sb.append('§').append(formatting.getCode());
                }
                if (style.isBold()) sb.append("§l");
                if (style.isItalic()) sb.append("§o");
                if (style.isUnderlined()) sb.append("§n");
                if (style.isStrikethrough()) sb.append("§m");
                if (style.isObfuscated()) sb.append("§k");
                sb.append(string);
                return Optional.empty();
            }, Style.EMPTY);
            return sb.toString();
        }
        return displayName.getString();
    }

    private float getTextWidth(String text) {
        return mcfont.isEnabled() ? fr.getWidth(text) : tenacityBoldFont20().getStringWidthFloat(text);
    }

    private float getFontHeight() {
        return mcfont.isEnabled() ? fr.fontHeight : tenacityBoldFont20().getHeight();
    }

    private void drawTagText(String text, float x, float y, int color) {
        if (mcfont.isEnabled()) {
            ctx().drawText(fr, text, (int) (x + .5f), (int) (y + .5f), Color.BLACK.getRGB(), false);
            ctx().drawText(fr, text, (int) x, (int) y, color, false);
        } else {
            tenacityBoldFont20().drawStringWithShadow(text, x, y, color);
        }
    }

    @Override
    public void onShaderEvent(ShaderEvent e) {

        if (nametagSettings.getSetting("Add PostProcessing").isEnabled() && nametags.isEnabled()) {
            for (Entity entity : entityPosition.keySet()) {
                Vector4f pos = entityPosition.get(entity);
                float x = pos.x, y = pos.y, right = pos.z, bottom = pos.w;

                if (entity instanceof LivingEntity) {
                    LivingEntity renderingEntity = (LivingEntity) entity;
                    String ircName = "";
                    if (IRCUtil.usersMap.containsKey(renderingEntity.getName().getString())) {
                        ircName = " \2477(\247d" + IRCUtil.usersMap.get(renderingEntity.getName().getString()) + "\2477)";
                    }
                    String name = getName(renderingEntity) + ircName;
                    StringBuilder text = new StringBuilder(
                            (FriendUtils.isFriend(renderingEntity.getName().getString()) ? "§d" : redTags.isEnabled() ? "§c" : "§f") + name);
                    if (nametagSettings.getSetting("Health Text").isEnabled()) {
                        text.append(String.format(" §7[§r%s HP§7]", df.format(renderingEntity.getHealth())));
                    }
                    double fontScale = scale.getValue();
                    float middle = x + ((right - x) / 2);
                    float textWidth = getTextWidth(text.toString());
                    middle -= (textWidth * fontScale) / 2f;
                    double fontHeight = getFontHeight() * fontScale;

                    ctx().getMatrices().pushMatrix();
                    ctx().getMatrices().translate((float) middle, (float) (y - (fontHeight + 2)));
                    ctx().getMatrices().scale((float) fontScale, (float) fontScale);
                    ctx().getMatrices().translate((float) -middle, (float) -(y - (fontHeight + 2)));

                    Color backgroundTagColor = nametagSettings.getSetting("Red Background").isEnabled() ? Color.RED : Color.BLACK;
                    if (nametagSettings.getSetting("Round").isEnabled()) {
                        RoundedUtil.drawRound(middle - 3, (float) (y - (fontHeight + 7)), textWidth + 6,
                                (float) ((fontHeight / fontScale) + 4), 4, backgroundTagColor);
                    } else {
                        fill(middle - 3, (float) (y - (fontHeight + 7)), textWidth + 6,
                                (fontHeight / fontScale) + 4, backgroundTagColor.getRGB());
                    }

                    ctx().getMatrices().popMatrix();

                }
            }
        }
    }


    private final NumberFormat df = new DecimalFormat("0.#");
    private final Color backgroundColor = new Color(10, 10, 10, 130);

    private Color firstColor = Color.BLACK, secondColor = Color.BLACK, thirdColor = Color.BLACK, fourthColor = Color.BLACK;

    private void fill(double x, double y, double w, double h, int color) {
        ctx().fill((int) Math.round(x), (int) Math.round(y), (int) Math.round(x + w), (int) Math.round(y + h), color);
    }

    private void fill(float x, float y, float w, float h, int color) {
        ctx().fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), color);
    }


    @Override
    public void onRender2DEvent(Render2DEvent e) {

        if (boxColorMode.is("Custom")) {
            if (boxColor.isRainbow()) {
                firstColor = boxColor.getRainbow().getColor(0);
                secondColor = boxColor.getRainbow().getColor(90);
                thirdColor = boxColor.getRainbow().getColor(180);
                fourthColor = boxColor.getRainbow().getColor(270);
            } else {
                gradientColorWheel(Pair.of(boxColor.getColor(), boxColor.getAltColor()));
            }
        } else {
            if (HUDMod.theme.is("Custom Theme") && HUDMod.color1.isRainbow()) {
                firstColor = HUDMod.color1.getRainbow().getColor(0);
                secondColor = HUDMod.color1.getRainbow().getColor(90);
                thirdColor = HUDMod.color1.getRainbow().getColor(180);
                fourthColor = HUDMod.color1.getRainbow().getColor(270);
            } else {
                gradientColorWheel(HUDMod.getClientColors());
            }
        }

        for (Entity entity : entityPosition.keySet()) {
            Vector4f pos = entityPosition.get(entity);
            float x = pos.x,
                    y = pos.y,
                    right = pos.z,
                    bottom = pos.w;

            if (entity instanceof LivingEntity) {
                LivingEntity renderingEntity = (LivingEntity) entity;
                if (nametags.isEnabled()) {
                    String ircName = "";
                    if (IRCUtil.usersMap.containsKey(renderingEntity.getName().getString())) {
                        ircName = " \2477(\247d" + IRCUtil.usersMap.get(renderingEntity.getName().getString()) + "\2477)";
                    }
                    float healthValue = renderingEntity.getHealth() / renderingEntity.getMaxHealth();
                    Color healthColor = healthValue > .75 ? new Color(66, 246, 123) : healthValue > .5 ? new Color(228, 255, 105) : healthValue > .35 ? new Color(236, 100, 64) : new Color(255, 65, 68);
                    String name = getName(renderingEntity) + ircName;
                    StringBuilder text = new StringBuilder(
                            (FriendUtils.isFriend(renderingEntity.getName().getString()) ? "§d" : redTags.isEnabled() ? "§c" : "§f") + name);
                    if (nametagSettings.getSetting("Health Text").isEnabled()) {
                        text.append(String.format(" §7[§r%s HP§7]", df.format(renderingEntity.getHealth())));
                    }
                    double fontScale = scale.getValue();
                    float middle = x + ((right - x) / 2);
                    float textWidth = getTextWidth(text.toString());
                    double fontHeight = getFontHeight() * fontScale;
                    middle -= (textWidth * fontScale) / 2f;

                    ctx().getMatrices().pushMatrix();
                    ctx().getMatrices().translate((float) middle, (float) (y - (fontHeight + 2)));
                    ctx().getMatrices().scale((float) fontScale, (float) fontScale);
                    ctx().getMatrices().translate((float) -middle, (float) -(y - (fontHeight + 2)));


                    if (nametagSettings.getSetting("Background").isEnabled()) {
                        Color backgroundTagColor = nametagSettings.getSetting("Red Background").isEnabled() ? ColorUtil.applyOpacity(Color.RED, .65f) : backgroundColor;
                        if (nametagSettings.getSetting("Round").isEnabled()) {
                            RoundedUtil.drawRound(middle - 3, (float) (y - (fontHeight + 7)), textWidth + 6,
                                    (float) ((fontHeight / fontScale) + 4), 4, backgroundTagColor);
                        } else {
                            fill(middle - 3, (float) (y - (fontHeight + 7)), textWidth + 6,
                                    (fontHeight / fontScale) + 4, backgroundTagColor.getRGB());
                        }
                    }


                    drawTagText(text.toString(), middle, (float) (y - (fontHeight + 4)), healthColor.getRGB());
                    ctx().getMatrices().popMatrix();
                }

                if (itemHeld.isEnabled()) {
                    ItemStack heldItem = renderingEntity.getMainHandStack();
                    if (!heldItem.isEmpty()) {

                        float fontScale = .5f;
                        float middle = x + ((right - x) / 2);
                        String text = heldItem.getName().getString();
                        float textWidth = getTextWidth(text);
                        middle -= (textWidth * fontScale) / 2f;

                        ctx().getMatrices().pushMatrix();
                        ctx().getMatrices().translate(middle, bottom + 4);
                        ctx().getMatrices().scale(fontScale, fontScale);
                        ctx().getMatrices().translate(-middle, -(bottom + 4));
                        fill(middle - 3, bottom + 1, textWidth + 6, getFontHeight() + 5, backgroundColor.getRGB());
                        if (mcfont.isEnabled()) {
                            ctx().drawTextWithShadow(fr, text, (int) middle, (int) (bottom + 4), -1);
                        } else {
                            tenacityBoldFont20().drawStringWithShadow(text, middle, bottom + 4, -1);
                        }
                        ctx().getMatrices().popMatrix();
                    }
                }

                if (equipmentVisual.isEnabled()) {
                    float scale = .4f;
                    float equipmentX = right + 5;
                    float equipmentY = y - 1;
                    ctx().getMatrices().pushMatrix();
                    ctx().getMatrices().translate(equipmentX, equipmentY);
                    ctx().getMatrices().scale(scale, scale);
                    ctx().getMatrices().translate(-equipmentX, -equipmentY);
                    float seperation = 0f;
                    float length = (bottom - y) - 2;
                    for (int i = 3; i >= 0; i--) {
                        ItemStack armor = renderingEntity.getEquippedStack(ARMOR_SLOTS[i]);
                        if (armor.isEmpty()) {
                            seperation += (length / 3) / scale;
                            continue;
                        }
                        ctx().drawItem(armor, (int) equipmentX, (int) (equipmentY + seperation));
                        seperation += (length / 3) / scale;
                    }

                    ctx().getMatrices().popMatrix();
                }


                if (healthBar.isEnabled()) {
                    float healthValue = renderingEntity.getHealth() / renderingEntity.getMaxHealth();
                    Color healthColor = healthValue > .75 ? new Color(66, 246, 123) : healthValue > .5 ? new Color(228, 255, 105) : healthValue > .35 ? new Color(236, 100, 64) : new Color(255, 65, 68);

                    float height = (bottom - y) + 1;
                    fill(x - 3.5f, y - .5f, 2, height + 1, new Color(0, 0, 0, 180).getRGB());
                    if (healthBarMode.is("Color")) {
                        drawGradientTB(x - 3, y, 1, height, .3f, firstColor, fourthColor);
                        drawGradientTB(x - 3, y + (height - (height * healthValue)), 1, height * healthValue, 1, firstColor, fourthColor);
                    } else {
                        fill(x - 3, y, 1, height, ColorUtil.applyOpacity(healthColor, .3f).getRGB());
                        fill(x - 3, y + (height - (height * healthValue)), 1, height * healthValue, healthColor.getRGB());
                    }

                    if (healthBarText.isEnabled()) {
                        healthValue *= 100;
                        String health = String.valueOf(MathUtils.round(healthValue, 1)).substring(0, healthValue == 100 ? 3 : 2);
                        String text = health + "%";
                        double fontScale = .5;
                        float textX = x - ((getTextWidth(text) / 2f) + 2);
                        float fontHeight = (float) (getFontHeight() * fontScale);
                        float newHeight = height - fontHeight;
                        float textY = y + (newHeight - (newHeight * (healthValue / 100)));

                        ctx().getMatrices().pushMatrix();
                        ctx().getMatrices().translate(textX - 5, textY);
                        ctx().getMatrices().scale((float) fontScale, (float) fontScale);
                        ctx().getMatrices().translate(-(textX - 5), -textY);
                        if (mcfont.isEnabled()) {
                            ctx().drawTextWithShadow(fr, text, (int) textX, (int) textY, -1);
                        } else {
                            tenacityBoldFont20().drawStringWithShadow(text, textX, textY, -1);
                        }
                        ctx().getMatrices().popMatrix();
                    }


                }


            }

            if (boxEsp.isEnabled()) {
                float outlineThickness = .5f;
                //top
                drawGradientLR(x, y, (right - x), 1, 1, firstColor, secondColor);
                //left
                drawGradientTB(x, y, 1, bottom - y, 1, firstColor, fourthColor);
                //bottom
                drawGradientLR(x, bottom, right - x, 1, 1, fourthColor, thirdColor);
                //right
                drawGradientTB(right, y, 1, (bottom - y) + 1, 1, secondColor, thirdColor);

                //Outline

                //top
                fill(x - .5f, y - outlineThickness, (right - x) + 2, outlineThickness, Color.BLACK.getRGB());
                //Left
                fill(x - outlineThickness, y, outlineThickness, (bottom - y) + 1, Color.BLACK.getRGB());
                //bottom
                fill(x - .5f, (bottom + 1), (right - x) + 2, outlineThickness, Color.BLACK.getRGB());
                //Right
                fill(right + 1, y, outlineThickness, (bottom - y) + 1, Color.BLACK.getRGB());


                //top
                fill(x + 1, y + 1, (right - x) - 1, outlineThickness, Color.BLACK.getRGB());
                //Left
                fill(x + 1, y + 1, outlineThickness, (bottom - y) - 1, Color.BLACK.getRGB());
                //bottom
                fill(x + 1, (bottom - outlineThickness), (right - x) - 1, outlineThickness, Color.BLACK.getRGB());
                //Right
                fill(right - outlineThickness, y + 1, outlineThickness, (bottom - y) - 1, Color.BLACK.getRGB());

            }

        }

    }

    /** Vertical (top->bottom) gradient; maps the old GradientUtil.drawGradientTB. */
    private void drawGradientTB(float x, float y, float w, float h, float opacity, Color top, Color bottom) {
        ctx().fillGradient(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h),
                ColorUtil.applyOpacity(top, opacity).getRGB(), ColorUtil.applyOpacity(bottom, opacity).getRGB());
    }

    /** Horizontal (left->right) gradient via a rotated vertical fillGradient. */
    private void drawGradientLR(float x, float y, float w, float h, float opacity, Color left, Color right) {
        ctx().getMatrices().pushMatrix();
        ctx().getMatrices().translate(x, y);
        ctx().getMatrices().rotate((float) (-Math.PI / 2f));
        ctx().fillGradient(Math.round(-h), 0, 0, Math.round(w),
                ColorUtil.applyOpacity(left, opacity).getRGB(), ColorUtil.applyOpacity(right, opacity).getRGB());
        ctx().getMatrices().popMatrix();
    }

    private void gradientColorWheel(Pair<Color, Color> colors) {
        firstColor = ColorUtil.interpolateColorsBackAndForth(15, 0, colors.getFirst(), colors.getSecond(), false);
        secondColor = ColorUtil.interpolateColorsBackAndForth(15, 90, colors.getFirst(), colors.getSecond(), false);
        thirdColor = ColorUtil.interpolateColorsBackAndForth(15, 180, colors.getFirst(), colors.getSecond(), false);
        fourthColor = ColorUtil.interpolateColorsBackAndForth(15, 270, colors.getFirst(), colors.getSecond(), false);
    }

    private boolean shouldRender(Entity entity) {
        if (!entity.isAlive() || entity.isInvisible()) {
            return false;
        }
        if (validEntities.getSetting("Players").isEnabled() && entity instanceof PlayerEntity) {
            if (entity == mc.player) {
                return !mc.options.getPerspective().isFirstPerson();
            }
            return entity.getDisplayName() == null || !entity.getDisplayName().getString().contains("[NPC");
        }
        if (validEntities.getSetting("Animals").isEnabled() && entity instanceof AnimalEntity) {
            return true;
        }

        return validEntities.getSetting("Mobs").isEnabled() && entity instanceof HostileEntity;
    }


}
