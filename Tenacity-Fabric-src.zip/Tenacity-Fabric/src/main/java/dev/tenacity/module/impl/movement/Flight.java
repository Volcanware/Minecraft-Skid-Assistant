package dev.tenacity.module.impl.movement;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.BoundingBoxEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.MoveEvent;
import dev.tenacity.event.impl.player.UpdateEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.combat.TargetStrafe;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.ui.notifications.NotificationType;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.misc.TimerUtils;
import dev.tenacity.utils.player.DamageUtils;
import dev.tenacity.utils.player.InventoryUtils;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.block.Blocks;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.BlockHitResult;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

@SuppressWarnings({"unused", "FieldCanBeLocal"})
public final class Flight extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Watchdog", "Zonecraft", "Watchdog", "Vanilla", "AirWalk", "Viper", "Verus", "Minemen", "Old NCP", "Slime", "Custom", "Packet", "Minemora", "Vulcan");
    private final NumberSetting teleportDelay = new NumberSetting("Teleport Delay", 5, 1, 20, 1);
    private final NumberSetting teleportLength = new NumberSetting("Teleport Length", 5, 1, 20, 1);
    private final NumberSetting timerAmount = new NumberSetting("Timer Amount", 1, 0.1, 3, 0.1);
    private final NumberSetting horizontalSpeed = new NumberSetting("Horizontal Speed", 2, 0, 5, 0.1);
    private final NumberSetting verticalSpeed = new NumberSetting("Vertical Speed", 1, 0, 5, 0.1);
    private final BooleanSetting viewBobbing = new BooleanSetting("View Bobbing", true);
    private final BooleanSetting antiKick = new BooleanSetting("Anti-kick", false);
    private int stage;
    private int ticks;
    private boolean doFly;
    private double x, y, z;
    private double lastX, lastY, lastZ;
    private final CopyOnWriteArrayList<Packet<?>> packets = new CopyOnWriteArrayList<>();
    private boolean hasClipped;
    private int slot = 0;
    private double speedStage;
    private float clip;
    private double moveSpeed;
    private int stage2;
    private final TimerUtil timer = new TimerUtil();
    public static final Set<BlockPos> hiddenBlocks = new HashSet<>();
    private boolean hasS08;
    private boolean hasDamaged;
    private boolean up;
    private int airTicks;

    private boolean adjustSpeed, canSpeed, hasBeenDamaged;
    public double moveSpeed2, lastDist;
    public int stage3;

    // Custom fly settings
    private final BooleanSetting damage = new BooleanSetting("Damage", false);
    private final ModeSetting damageMode = new ModeSetting("Damage Mode", "Vanilla", "Vanilla", "Suffocate", "NCP");

    private final NumberSetting motionY = new NumberSetting("Motion Y", 0, -0.3, 0.3, 0.01);

    private final BooleanSetting speed = new BooleanSetting("Speed", false);
    private final NumberSetting speedAmount = new NumberSetting("Speed Amount", 0.2, 0.05, 9, 0.01);

    public Flight() {
        super("Flight", Category.MOVEMENT, "Makes you hover in the air");
        horizontalSpeed.addParent(mode, m -> m.is("Vanilla"));
        verticalSpeed.addParent(mode, m -> m.is("Vanilla"));
        antiKick.addParent(mode, m -> m.is("Vanilla"));
        damage.addParent(mode, m -> m.is("Custom"));
        damageMode.addParent(damage, BooleanSetting::isEnabled);
        motionY.addParent(mode, m -> m.is("Custom"));
        speed.addParent(mode, m -> m.is("Custom"));
        speedAmount.addParent(speed, BooleanSetting::isEnabled);
        teleportDelay.addParent(mode, m -> m.is("Packet"));
        teleportLength.addParent(mode, m -> m.is("Packet"));
        this.addSettings(mode, teleportDelay, teleportLength, motionY, damage, damageMode, speed, speedAmount, timerAmount, horizontalSpeed, verticalSpeed, viewBobbing, antiKick);
    }

    @Override
    public void onMoveEvent(MoveEvent e) {
        switch (mode.getMode()) {
            case "Vanilla":
                MovementUtils.setSpeed(e, MovementUtils.isMoving() ? horizontalSpeed.getFloatValue() : 0);
                TargetStrafe.strafe(e, horizontalSpeed.getFloatValue());
                break;
            case "Watchdog":
                MovementUtils.setSpeed(e, 0);
                break;
            case "Slime":
                if (stage < 8) {
                    MovementUtils.setSpeed(e, 0);
                }
                break;
            case "Packet":
                MovementUtils.setSpeed(e, 0);
                break;
            case "Minemora":
                if (!hasDamaged)
                    MovementUtils.setSpeed(e, 0);
                break;
            default:
                TargetStrafe.strafe(e);
                break;
        }
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        this.setSuffix(mode.getMode());
        if (viewBobbing.isEnabled()) {
            mc.player.setYaw(mc.player.getYaw() + 0.08f);
        }
        TimerUtils.setTimerSpeed(timerAmount.getFloatValue());

        switch (mode.getMode()) {
            case "Watchdog":
                if (e.isPre()) {
                    mc.player.setVelocity(mc.player.getVelocity().x, 0, mc.player.getVelocity().z);
                    stage++;
                    if (stage == 1) {
                        final double x = e.getX() + -Math.sin(Math.toRadians(mc.player.getYaw())) * 7.99;
                        final double y = e.getY() - 1.75;
                        final double z = e.getZ() + Math.cos(Math.toRadians(mc.player.getYaw())) * 7.99;
                        if (mc.world.getBlockState(BlockPos.ofFloored(x, y, z)).isAir()) {
                            PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, false));
                            mc.player.setPosition(x, y, z);
                        }
                    }
                }
                break;
            case "Vulcan":
                if (e.isPre()) {
                    mc.player.setVelocity(mc.player.getVelocity().x, 0, mc.player.getVelocity().z);
                    e.setOnGround(true);
                    mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                            new BlockHitResult(new Vec3d(mc.player.getX(), mc.player.getY() - 2, mc.player.getZ()),
                                    Direction.UP, BlockPos.ofFloored(mc.player.getX(), mc.player.getY() - 2, mc.player.getZ()), false));
                }
                break;
            case "Minemora":
                if (e.isPre()) {
                    if (stage < 3) {
                        e.setOnGround(false);
                        if (mc.player.isOnGround()) {
                            mc.player.jump();
                            stage++;
                        }
                    } else {
                        if (mc.player.hurtTime > 0 && !hasDamaged) {
                            hasDamaged = true;
                        }
                        if (hasDamaged) {
                            mc.player.setVelocity(mc.player.getVelocity().x, -MathUtils.getRandomInRange(0.005, 0.0051), mc.player.getVelocity().z);
                            MovementUtils.setSpeed(MovementUtils.getBaseMoveSpeed() * 1.5);
                        }
                    }
                }
                break;
            case "Zonecraft":
                if (e.isPre()) {
                    stage++;
                    switch (stage) {
                        case 1:
                            e.setOnGround(true);
                            MovementUtils.setSpeed(0.55);
                            break;
                    }

                    mc.player.setVelocity(mc.player.getVelocity().x, 0, mc.player.getVelocity().z);
                    e.setY(mc.player.getY() + 0.1);
                }
                break;
            case "Verus":
                if (e.isPre()) {
                    if (!mc.options.jumpKey.isPressed()) {
                        if (mc.player.isOnGround()) {
                            mc.player.setVelocity(mc.player.getVelocity().x, 0.42f, mc.player.getVelocity().z);
                            up = true;
                        } else if (up) {
                            if (!mc.player.horizontalCollision) {
                                mc.player.setVelocity(mc.player.getVelocity().x, -0.0784000015258789, mc.player.getVelocity().z);
                            }
                            up = false;
                        }
                    } else if (mc.player.age % 3 == 0) {
                        mc.player.setVelocity(mc.player.getVelocity().x, 0.42f, mc.player.getVelocity().z);
                    }
                    MovementUtils.setSpeed(mc.options.jumpKey.isPressed() ? 0 : 0.33);
                }
                break;
            case "Vanilla":
                if (TargetStrafe.canStrafe()) {
                    mc.player.setVelocity(mc.player.getVelocity().x, antiKick.isEnabled() ? -0.0625 : 0, mc.player.getVelocity().z);
                } else {
                    mc.player.setVelocity(mc.player.getVelocity().x,
                            mc.options.jumpKey.isPressed() ? verticalSpeed.getValue() : mc.options.sneakKey.isPressed() ? -verticalSpeed.getValue() : antiKick.isEnabled() ? -0.0625 : 0,
                            mc.player.getVelocity().z);
                }
                break;
            case "AirWalk":
                break;
            case "Viper":
                mc.player.setVelocity(mc.player.getVelocity().x, mc.options.jumpKey.isPressed() ? 1 : mc.options.sneakKey.isPressed() ? -1 : 0, mc.player.getVelocity().z);
                e.setOnGround(true);
                MovementUtils.setSpeed(0.3);
                break;
            case "Old NCP":
                if (hasDamaged) {
                    e.setOnGround(true);
                    double baseSpeed = MovementUtils.getBaseMoveSpeed();
                    if (!MovementUtils.isMoving() || mc.player.horizontalCollision) moveSpeed = baseSpeed;
                    if (moveSpeed > baseSpeed)
                        moveSpeed -= moveSpeed / 159.0;

                    moveSpeed = Math.max(baseSpeed, moveSpeed);

                    if (e.isPre()) {
                        TimerUtils.setTimerSpeed(1);
                        if (MovementUtils.isMoving())
                            MovementUtils.setSpeed(moveSpeed);
                        mc.player.setVelocity(mc.player.getVelocity().x, 0, mc.player.getVelocity().z);
                        double y = 1.0E-10;
                        e.setY(e.getY() - y);
                    }
                } else if (mc.player.isOnGround()) {
                    DamageUtils.damage(DamageUtils.DamageType.WATCHDOGUP);
                    mc.player.jump();
                    hasDamaged = true;
                }
                break;
            case "Slime":
                if (e.isPre()) {
                    stage++;
                    switch (stage) {
                        case 1:
                            if (mc.player.isOnGround()) {
                                mc.player.jump();
                            }
                            break;
                        case 7:
                            BlockPos pos = BlockPos.ofFloored(e.getX(), e.getY() - 2, e.getZ());
                            e.setPitch(90);
                            mc.player.setPitch(90);
                            if (mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                                    new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false)).isAccepted()) {
                                mc.player.swingHand(Hand.MAIN_HAND);
                            }
                            break;
                    }
                    if (stage > 8) {
                        e.setOnGround(true);
                        MovementUtils.setSpeed(0.3);
                        mc.player.setVelocity(mc.player.getVelocity().x, 0, mc.player.getVelocity().z);
                    }
                }
                break;
            case "Custom":
                if (e.isPre()) {
                    stage++;
                    switch (stage) {
                        case 1:
                            if (damage.isEnabled())
                                DamageUtils.damage(DamageUtils.DamageType.valueOf(damageMode.getMode().toUpperCase()));
                            break;
                    }
                    mc.player.setVelocity(mc.player.getVelocity().x, motionY.getValue(), mc.player.getVelocity().z);
                    if (speed.isEnabled()) MovementUtils.setSpeed(speedAmount.getValue());
                }
                break;
            case "Packet":
                if (e.isPre()) {
                    mc.player.setVelocity(mc.player.getVelocity().x, 0, mc.player.getVelocity().z);
                    if (MovementUtils.isMoving() && mc.player.age % teleportDelay.getIntValue() == 0) {
                        final double x = e.getX() + -Math.sin(Math.toRadians(mc.player.getYaw())) * teleportLength.getIntValue();
                        final double z = e.getZ() + Math.cos(Math.toRadians(mc.player.getYaw())) * teleportLength.getIntValue();
                        PacketUtils.sendPacketNoEvent(new PlayerMoveC2SPacket.PositionAndOnGround(x, mc.player.getY(), z, false, false));
                        mc.player.setPosition(x, mc.player.getY(), z);
                    }
                }
                break;
        }
    }

    @Override
    public void onUpdateEvent(UpdateEvent event) {
    }

    @Override
    public void onPacketSendEvent(PacketSendEvent event) {
        if (mc.isInSingleplayer() || mc.player == null) return;
        if (mode.is("Slime") && stage > 7 && PacketUtils.isPacketValid(event.getPacket())) {
            event.cancel();
            packets.add(event.getPacket());
        }
        if (mode.is("Watchdog") && event.getPacket() instanceof PlayerMoveC2SPacket) {
            event.cancel();
        }
    }

    @Override
    public void onBoundingBoxEvent(BoundingBoxEvent event) {
        if (mode.is("AirWalk") || mode.is("Verus")) {
            final Box axisAlignedBB = new Box(-5, -1, -5, 5, 1, 5).offset(event.getBlockPos().getX(), event.getBlockPos().getY(), event.getBlockPos().getZ());
            event.setBoundingBox(axisAlignedBB);
        }
    }

    @Override
    public void onPacketReceiveEvent(PacketReceiveEvent e) {
        if (e.getPacket() instanceof PlayerPositionLookS2CPacket && !hasS08) {
            PlayerPositionLookS2CPacket s08 = (PlayerPositionLookS2CPacket) e.getPacket();
            hasS08 = true;
        }
    }

    @Override
    public void onEnable() {
        hasDamaged = false;
        doFly = false;
        ticks = 0;
        stage = 0;
        stage3 = 0;
        clip = 0;
        hasClipped = false;
        packets.clear();
        timer.reset();
        moveSpeed = 0;
        stage2 = 0;
        hasS08 = false;
        if (mc.player != null) {
            lastX = mc.player.getX();
            lastY = mc.player.getY();
            lastZ = mc.player.getZ();
            y = 0;
            slot = mc.player.getInventory().getSelectedSlot();
            if (mode.is("Old NCP")) {
                moveSpeed = 1.6;
            } else if (mode.is("Slime")) {
                int slimeBlockSlot = InventoryUtils.getBlockSlot(Blocks.SLIME_BLOCK);
                if (slimeBlockSlot != -1) {
                    mc.player.getInventory().setSelectedSlot(slimeBlockSlot);
                } else {
                    Tenacity.INSTANCE.getNotificationManager().post(NotificationType.DISABLE, "Flight", "No slime block found in hotbar!", 2);
                    toggleSilent();
                    return;
                }
            }
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (mode.is("Vanilla") || mode.is("Minemen") || mode.is("Old NCP") || mode.is("Watchdog")) {
            mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
        } else if (mode.is("Slime")) {
            mc.player.getInventory().setSelectedSlot(slot);
        }

        TimerUtils.setTimerSpeed(1);
        packets.forEach(PacketUtils::sendPacketNoEvent);
        packets.clear();
        super.onDisable();
    }

}
