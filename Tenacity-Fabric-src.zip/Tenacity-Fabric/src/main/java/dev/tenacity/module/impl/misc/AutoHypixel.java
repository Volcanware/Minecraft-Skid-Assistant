package dev.tenacity.module.impl.misc;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.player.ChatReceivedEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.module.settings.impl.StringSetting;
import dev.tenacity.ui.notifications.NotificationType;
import dev.tenacity.utils.misc.Multithreading;
import dev.tenacity.utils.misc.ChatUtil;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.concurrent.TimeUnit;

public class AutoHypixel extends Module {

    private final BooleanSetting autoGG = new BooleanSetting("AutoGG", true);
    private final StringSetting autoGGMessage = new StringSetting("AutoGG Message", "gg");
    private final BooleanSetting autoPlay = new BooleanSetting("AutoPlay", true);
    private final NumberSetting autoPlayDelay = new NumberSetting("AutoPlay Delay", 2.5, 8, 1, 0.5);
    private final BooleanSetting autoHubOnBan = new BooleanSetting("Auto /l on ban", false);

    public AutoHypixel() {
        super("AutoHypixel", Category.MISC, "stuff for hypixel");
        autoGGMessage.addParent(autoGG, setting -> setting.isEnabled());
        autoPlayDelay.addParent(autoPlay, setting -> setting.isEnabled());
        this.addSettings(autoGG, autoGGMessage, autoPlay, autoPlayDelay, autoHubOnBan);
    }

    @Override
    public void onChatReceivedEvent(ChatReceivedEvent event) {
        String message = event.message.getString(), strippedMessage = Formatting.strip(message);
        if (autoHubOnBan.isEnabled() && strippedMessage.equals("A player has been removed from your game.")) {
            ChatUtil.send("/lobby");
            Tenacity.INSTANCE.getNotificationManager().post(NotificationType.WARNING, "AutoHypixel", "A player in your lobby got banned.");
        }
        String playCommand = findPlayCommand(event.message);
        if (playCommand != null) {
            if (autoGG.isEnabled() && !strippedMessage.startsWith("You died!")) {
                ChatUtil.send("/ac " + autoGGMessage.getString());
            }
            if (autoPlay.isEnabled()) {
                sendToGame(playCommand);
            }
        }
    }

    private String findPlayCommand(Text text) {
        ClickEvent clickEvent = text.getStyle().getClickEvent();
        if (clickEvent instanceof ClickEvent.RunCommand) {
            String command = ((ClickEvent.RunCommand) clickEvent).command();
            if (command.startsWith("/play ")) {
                return command;
            }
        }
        for (Text sibling : text.getSiblings()) {
            String result = findPlayCommand(sibling);
            if (result != null) return result;
        }
        return null;
    }

    private void sendToGame(String mode) {
        float delay = autoPlayDelay.getFloatValue();
        Tenacity.INSTANCE.getNotificationManager().post(NotificationType.INFO, "AutoPlay",
                "Sending you to a new game" + (delay > 0 ? " in " + delay + "s" : "") + "!", delay);
        Multithreading.schedule(() -> ChatUtil.send(mode), (long) delay, TimeUnit.SECONDS);
    }

}
