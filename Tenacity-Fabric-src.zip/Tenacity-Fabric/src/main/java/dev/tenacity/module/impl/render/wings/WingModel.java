package dev.tenacity.module.impl.render.wings;

import dev.tenacity.module.impl.render.CustomModel;
import dev.tenacity.utils.Utils;
import net.minecraft.client.model.*;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import java.awt.*;

/**
 * Ported from canelex's Wings Mod (<a href="https://youtu.be/5_iZ4sxymu0">...</a>)
 *
 * @author senoe
 * @since 6/2/2022
 */
public class WingModel implements Utils {

    private static final Identifier WINGS_TEXTURE = Identifier.of("tenacity", "textures/models/wings.png");
    private final ModelPart wing, wingTip;

    public WingModel() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();
        ModelPartData wingData = root.addChild("wing", ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-10, -1, -1, 10, 2, 2)
                        .uv(-10, 8).cuboid(-10, 0, 0.5F, 10, 0, 10),
                ModelTransform.origin(-2, 0, 0));
        wingData.addChild("wingtip", ModelPartBuilder.create()
                        .uv(0, 5).cuboid(-10, -0.5F, -0.5F, 10, 1, 1)
                        .uv(-10, 18).cuboid(-10, 0, 0.5F, 10, 0, 10),
                ModelTransform.origin(-10, 0, 0));
        ModelPart rootPart = TexturedModelData.of(modelData, 30, 30).createModel();
        this.wing = rootPart.getChild("wing");
        this.wingTip = wing.getChild("wingtip");
    }

    public void renderWings(LivingEntity player, float partialTicks, double scale, Color color) {
        float angle = interpolate(MathHelper.wrapDegrees(player.lastBodyYaw),
                MathHelper.wrapDegrees(player.bodyYaw), partialTicks);

        VertexConsumer vertexConsumer = mc.getBufferBuilders().getEntityVertexConsumers()
                .getBuffer(RenderLayers.entityCutoutNoCull(WINGS_TEXTURE));

        Vec3d camPos = mc.gameRenderer.getCamera().getCameraPos();
        Vec3d pos = player.getLerpedPos(partialTicks);
        int light = WorldRenderer.getLightmapCoordinates(mc.world, player.getBlockPos());

        MatrixStack matrices = new MatrixStack();
        matrices.push();
        // Recreate the entity-model space the 1.8.9 hook rendered in:
        // translate to the entity, face its yaw, apply the y-flip + sunk offset
        // the vanilla model pipeline uses.
        matrices.translate((float) (pos.x - camPos.x), (float) (pos.y - camPos.y), (float) (pos.z - camPos.z));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F - angle));
        matrices.scale(-1.0F, -1.0F, 1.0F);
        matrices.translate(0, -1.5078125F, 0);

        matrices.scale((float) -scale, (float) -scale, (float) scale);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(angle + 180));
        matrices.translate(0, (float) (CustomModel.enabled ? -.65 : -1.25 / scale), 0);
        matrices.translate(0, 0, (float) (0.2 / scale));
        if (player.isSneaking()) {
            matrices.translate(0, (float) (0.125 / scale), 0);
        }

        for (int i = 0; i < 2; i++) {
            float f11 = (System.currentTimeMillis() % 1500L) / 1500.0F * MathHelper.PI * 2.0F;
            wing.pitch = -1.4F - (float) Math.cos(f11) * 0.2F;
            wing.yaw = 0.35F + (float) Math.sin(f11) * 0.4F;
            wing.roll = 0.35F;
            wingTip.roll = -(float) (Math.sin(f11 + 2.0F) + 0.5) * 0.75F;
            wing.render(matrices, vertexConsumer, light, OverlayTexture.DEFAULT_UV, color.getRGB());
            matrices.scale(-1, 1, 1);
        }

        matrices.pop();
    }

    private float interpolate(float current, float target, float percent) {
        float f = (current + (target - current) * percent) % 360;
        return f < 0 ? f + 360 : f;
    }

}
