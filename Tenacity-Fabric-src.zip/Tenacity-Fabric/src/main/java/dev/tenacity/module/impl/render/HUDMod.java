package dev.tenacity.module.impl.render;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.*;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.player.InventoryUtils;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.render.Theme;
import dev.tenacity.utils.server.ServerUtils;
import dev.tenacity.utils.tuples.Pair;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HUDMod extends Module {

    private final StringSetting clientName = new StringSetting("Client Name");
    private final ModeSetting watermarkMode = new ModeSetting("Watermark Mode", "Tenacity",
            "Tenacity", "Plain Text", "Logo", "None");
    public static final ColorSetting color1 = new ColorSetting("Color 1", new Color(0xffa028d4));
    public static final ColorSetting color2 = new ColorSetting("Color 2", new Color(0xff0008ff));
    public static final ModeSetting theme = Theme.getModeSetting("Theme Selection", "Tenacity");
    public static final BooleanSetting customFont = new BooleanSetting("Custom Font", true);
    private static final MultipleBoolSetting infoCustomization = new MultipleBoolSetting("Info Options",
            new BooleanSetting("Show Ping", false),
            new BooleanSetting("Semi-Bold Info", true),
            new BooleanSetting("White Info", false),
            new BooleanSetting("Info Shadow", true));
    public static final MultipleBoolSetting hudCustomization = new MultipleBoolSetting("HUD Options",
            new BooleanSetting("Radial Gradients", true),
            new BooleanSetting("Potion HUD", true),
            new BooleanSetting("Armor HUD", true),
            new BooleanSetting("Render Cape", true),
            new BooleanSetting("Lowercase", false));
    private static final MultipleBoolSetting disableButtons = new MultipleBoolSetting("Disable Buttons",
            new BooleanSetting("Disable KillAura", true),
            new BooleanSetting("Disable InvManager", true),
            new BooleanSetting("Disable ChestStealer", true));

    public HUDMod() {
        super("HUD", Category.RENDER, "customizes the client's appearance");
        color1.addParent(theme, modeSetting -> modeSetting.is("Custom Theme"));
        color2.addParent(theme, modeSetting -> modeSetting.is("Custom Theme") && !color1.isRainbow());
        this.addSettings(clientName, watermarkMode, theme, color1, color2, customFont,
                infoCustomization, hudCustomization, disableButtons);
        if (!enabled) this.setToggledSilently(true);
    }

    public static int offsetValue = 0;
    private final Animation fadeInText = new DecelerateAnimation(500, 1);

    public static float xOffset = 0;

    public static Pair<Color, Color> getClientColors() {
        return Theme.getThemeColors(theme.getMode());
    }

    public static boolean isLowercase() {
        return hudCustomization.isEnabled("Lowercase");
    }

    public static boolean isPotionHUD() {
        return hudCustomization.isEnabled("Potion HUD");
    }

    public static boolean isArmorHUD() {
        return hudCustomization.isEnabled("Armor HUD");
    }

    @Override
    public void onRender2DEvent(Render2DEvent e) {
        Pair<Color, Color> clientColors = getClientColors();
        String name = Tenacity.NAME;
        if (!clientName.getString().isEmpty()) {
            name = clientName.getString().replace("%time%", getCurrentTimeStamp());
        }

        if (watermarkMode.is("Tenacity")) {
            tenacityBoldFont30().drawString("T", 6, 6, clientColors.getFirst().getRGB());
            tenacityBoldFont22().drawString("enacity", 6 + tenacityBoldFont30().getStringWidthFloat("T"), 10,
                    Color.WHITE.getRGB());
        } else if (watermarkMode.is("Plain Text")) {
            tenacityBoldFont22().drawString(name, 6, 6, clientColors.getFirst().getRGB());
        } else if (watermarkMode.is("Logo")) {
            tenacityBoldFont30().drawString("T", 6, 6, clientColors.getFirst().getRGB());
        }

        drawInfo(clientColors);
        if (isPotionHUD()) drawPotionHUD();
    }

    private void drawInfo(Pair<Color, Color> clientColors) {
        if (mc.player == null) return;
        int ping = mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != null
                ? mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency() : 0;
        BlockPos pos = mc.player.getBlockPos();

        String info = String.format("X: %d Y: %d Z: %d", pos.getX(), pos.getY(), pos.getZ());
        if (infoCustomization.isEnabled("Show Ping")) {
            info += String.format(" | Ping: %d", ping);
        }
        info += String.format(" | FPS: %d", mc.getCurrentFps());
        info += " | " + ServerUtils.getRemoteIp();

        float width = tenacityFont18().getStringWidthFloat(info) + 10;
        float x = ctx().getScaledWindowWidth() / 2f - width / 2f;
        float y = ctx().getScaledWindowHeight() - 24;
        RoundedUtil.drawRound(x, y, width, 14, 5, ColorUtil.applyOpacity(new Color(15, 15, 15), .7f));
        tenacityFont18().drawCenteredString(info, x + width / 2, y + 4, Color.WHITE.getRGB());
    }

    private void drawPotionHUD() {
        float y = ctx().getScaledWindowHeight() - 60;
        for (StatusEffectInstance effect : mc.player.getStatusEffects()) {
            String name = effect.getEffectType().value().getName().getString() + " " + (effect.getAmplifier() + 1);
            int color = effect.getEffectType().value().getColor();
            tenacityFont18().drawString(name, 4, y, color);
            y -= 11;
        }
    }

    private static String getCurrentTimeStamp() {
        return new SimpleDateFormat("HH:mm").format(new Date());
    }
}
