package dev.tenacity.module.impl.combat;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.player.InventoryUtils;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;

public class AutoHead extends Module {

    private final NumberSetting delay = new NumberSetting("Delay", 750, 3000, 0, 50);
    private final NumberSetting healPercent = new NumberSetting("Health %", 50, 99, 1, 1);
    private final TimerUtil timer = new TimerUtil();

    public AutoHead() {
        super("AutoHead", Category.COMBAT, "auto consume heads");
        this.addSettings(delay, healPercent);
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        if (mc.player != null && mc.world != null && e.isPre()
                && !(mc.player.hasStatusEffect(StatusEffects.SPEED) && mc.player.hasStatusEffect(StatusEffects.REGENERATION))
                && (mc.player.getHealth() / mc.player.getMaxHealth()) * 100 <= healPercent.getValue()
                && timer.hasTimeElapsed((long) delay.getValue())) {
            for (int i = 0; i < 45; i++) {
                ItemStack is = mc.player.playerScreenHandler.getSlot(i).getStack();
                if (!is.isEmpty() && is.isIn(ItemTags.SKULLS) && is.getName().getString().contains("Head")) {
                    int prevSlot = mc.player.getInventory().getSelectedSlot();
                    if (i - 36 < 0) {
                        InventoryUtils.swap(i, 8);
                        PacketUtils.sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(8));
                    } else {
                        PacketUtils.sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(i - 36));
                    }

                    PacketUtils.sendPacketNoEvent(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
                    mc.player.getInventory().setSelectedSlot(prevSlot);
                    PacketUtils.sendPacketNoEvent(new UpdateSelectedSlotC2SPacket(prevSlot));

                    timer.reset();
                }
            }
        }
    }

}
