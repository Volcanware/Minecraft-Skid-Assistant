package dev.tenacity.module.impl.combat;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.game.WorldEvent;
import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.Setting;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.ui.notifications.NotificationType;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.player.MovementUtils;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.common.CommonPongC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.util.math.Vec3d;

public class Velocity extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Packet", "Packet", "Matrix", "Tick", "Stack", "C0F Cancel");
    private final NumberSetting horizontal = new NumberSetting("Horizontal", 0, 100, 0, 1);
    private final NumberSetting vertical = new NumberSetting("Vertical", 0, 100, 0, 1);
    private final NumberSetting chance = new NumberSetting("Chance", 100, 100, 0, 1);
    private final BooleanSetting onlyWhileMoving = new BooleanSetting("Only while moving", false);
    private final BooleanSetting staffCheck = new BooleanSetting("Staff check", false);

    private long lastDamageTimestamp, lastAlertTimestamp;
    private boolean cancel;
    private int stack;

    public Velocity() {
        super("Velocity", Category.COMBAT, "Reduces your knockback");
        Setting.addParent(mode, m -> m.is("Packet"), horizontal, vertical, staffCheck);
        this.addSettings(mode, horizontal, vertical, chance, onlyWhileMoving, staffCheck);
    }

    @Override
    public void onPacketSendEvent(PacketSendEvent event) {
        if (mode.is("C0F Cancel")) {
            if (event.getPacket() instanceof CommonPongC2SPacket && mc.player.hurtTime > 0) {
                event.cancel();
            }
        }
    }

    @Override
    public void onPacketReceiveEvent(PacketReceiveEvent e) {
        this.setSuffix(mode.getMode());
        if ((onlyWhileMoving.isEnabled() && !MovementUtils.isMoving()) || (chance.getValue() != 100 && MathUtils.getRandomInRange(0, 100) > chance.getValue()))
            return;
        Packet<?> packet = e.getPacket();
        switch (mode.getMode()) {
            case "Packet":
                if (packet instanceof EntityVelocityUpdateS2CPacket) {
                    EntityVelocityUpdateS2CPacket s12 = (EntityVelocityUpdateS2CPacket) e.getPacket();
                    if (mc.player != null && s12.getEntityId() == mc.player.getId()) {
                        if (cancel(e)) return;
                        Vec3d v = s12.getVelocity();
                        e.setPacket(new EntityVelocityUpdateS2CPacket(s12.getEntityId(),
                                new Vec3d(v.x * horizontal.getValue() / 100.0, v.y * vertical.getValue() / 100.0, v.z * horizontal.getValue() / 100.0)));
                    }
                } else if (packet instanceof ExplosionS2CPacket) {
                    if (cancel(e)) return;
                    ExplosionS2CPacket s27 = (ExplosionS2CPacket) e.getPacket();
                    e.setPacket(new ExplosionS2CPacket(s27.center(), s27.radius(), s27.blockCount(),
                            s27.playerKnockback().map(kb -> new Vec3d(kb.x * horizontal.getValue() / 100.0,
                                    kb.y * vertical.getValue() / 100.0, kb.z * horizontal.getValue() / 100.0)),
                            s27.explosionParticle(), s27.explosionSound(), s27.blockParticles()));
                } else if (e.getPacket() instanceof EntityStatusS2CPacket) {
                    EntityStatusS2CPacket s19 = (EntityStatusS2CPacket) e.getPacket();
                    if (mc.player != null && s19.getEntity(mc.world) == mc.player && s19.getStatus() == 2) {
                        lastDamageTimestamp = System.currentTimeMillis();
                    }
                }
                break;
            case "C0F Cancel":
                if (packet instanceof EntityVelocityUpdateS2CPacket) {
                    EntityVelocityUpdateS2CPacket s12 = (EntityVelocityUpdateS2CPacket) e.getPacket();
                    if (mc.player != null && s12.getEntityId() == mc.player.getId()) {
                        e.cancel();
                    }
                }
                if (packet instanceof ExplosionS2CPacket) {
                    e.cancel();
                }
                break;
            case "Stack":
                if (packet instanceof EntityVelocityUpdateS2CPacket) {
                    EntityVelocityUpdateS2CPacket s12 = (EntityVelocityUpdateS2CPacket) packet;
                    cancel = !cancel;
                    if (cancel) {
                        e.cancel();
                    }
                }
                if (packet instanceof ExplosionS2CPacket) {
                    e.cancel();
                }
                break;
            case "Matrix":
                if (packet instanceof EntityVelocityUpdateS2CPacket) {
                    EntityVelocityUpdateS2CPacket s12 = (EntityVelocityUpdateS2CPacket) e.getPacket();
                    if (mc.player != null && s12.getEntityId() == mc.player.getId()) {
                        Vec3d v = s12.getVelocity();
                        e.setPacket(new EntityVelocityUpdateS2CPacket(s12.getEntityId(),
                                new Vec3d(v.x * 5 / 100.0, v.y * 100 / 100.0, v.z * 5 / 100.0)));
                    }
                }
                break;
            case "Tick":
                if (packet instanceof EntityVelocityUpdateS2CPacket) {
                    EntityVelocityUpdateS2CPacket s12 = (EntityVelocityUpdateS2CPacket) e.getPacket();
                    if (mc.player != null && s12.getEntityId() == mc.player.getId() && mc.player.age % 3 == 0) {
                        Vec3d v = s12.getVelocity();
                        e.setPacket(new EntityVelocityUpdateS2CPacket(s12.getEntityId(),
                                new Vec3d(v.x * 5 / 100.0, v.y * 100 / 100.0, v.z * 5 / 100.0)));
                    }
                }
                break;
        }
    }

    @Override
    public void onWorldEvent(WorldEvent event) {
        stack = 0;
    }

    private boolean cancel(PacketReceiveEvent e) {
        if (staffCheck.isEnabled() && System.currentTimeMillis() - lastDamageTimestamp > 500) {
            if (System.currentTimeMillis() - lastAlertTimestamp > 250) {
                Tenacity.INSTANCE.getNotificationManager().post(NotificationType.WARNING, "Velocity", "Suspicious knockback detected!", 2);
                lastAlertTimestamp = System.currentTimeMillis();
            }
            return true;
        }
        if (horizontal.getValue() == 0 && vertical.getValue() == 0) {
            e.cancel();
            return true;
        }
        return false;
    }

}
