package dev.tenacity.module.impl.render;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.objects.Dragging;
import dev.tenacity.utils.render.RenderUtil;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class PlayerList extends Module {

    private final Dragging pos = Tenacity.INSTANCE.createDrag(this, "playerList", 4, 30);

    public PlayerList() {
        super("PlayerList", Category.RENDER, "Displays a list of players in your world");
    }

    @Override
    public void onRender2DEvent(Render2DEvent event) {
        if (mc.player == null || mc.world == null) return;
        List<AbstractClientPlayerEntity> players = mc.world.getPlayers().stream().filter(p -> p != null && p.isAlive()).collect(Collectors.toList());

        float height = 35 + (players.size() - 1) * (tenacityFont16().getHeight() + 8);
        float width = 175;
        float x = pos.getX(), y = pos.getY();
        pos.setWidth(width - 6);
        pos.setHeight(height);

        RenderUtil.drawRect(x, y, width - 6, height, new Color(0, 0, 0, 60).getRGB());
        RenderUtil.drawRect(x, y, width - 6, 1, HUDMod.getClientColors().getFirst().getRGB());
        RenderUtil.drawRect(x + 4, y + 17, width - 14, 0.5f, 0xFFAAAAAA);

        tenacityBoldFont22().drawString("Player List", x + 4, y + 5, -1);

        tenacityFont18().drawString(String.valueOf(players.size() + 1),
                x + width - tenacityFont18().getStringWidthFloat(String.valueOf(players.size() + 1)) - 10,
                y + 6, -1
        );

        y += 18;

        for (int i = 0; i < players.size(); i++) {
            PlayerEntity player = players.get(i);
            renderPlayer(player, i, x, y);
        }
    }

    private void renderPlayer(PlayerEntity player, int i, float x, float y) {
        float height = tenacityFont16().getHeight() + 8;
        float offset = i * (height);
        float healthPercent = MathHelper.clamp((player.getHealth() + player.getAbsorptionAmount()) / (player.getMaxHealth() + player.getAbsorptionAmount()), 0, 1);
        Color healthColor = healthPercent > .75 ? new Color(66, 246, 123) : healthPercent > .5 ? new Color(228, 255, 105) : healthPercent > .35 ? new Color(236, 100, 64) : new Color(255, 65, 68);
        String healthText = (int) MathUtils.round(healthPercent * 100, .01) + "%";
        tenacityFont16().drawString("§f§l" + player.getName().getString() + "§r " + healthText, x + 18, y + offset + tenacityFont16().getMiddleOfBox(height), healthColor.getRGB());

        float headX = x + 4;
        float headWH = 32;
        float headY = y + offset + height /2f - 6;
        float f = 0.35F;
        Identifier skin = ((AbstractClientPlayerEntity) player).getSkin().body().texturePath();
        RenderUtil.scaleStart(headX, headY, f);
        ctx().drawTexture(RenderPipelines.GUI_TEXTURED, skin, (int) headX, (int) headY, headWH, headWH, (int) headWH, (int) headWH, 64, 64);
        RenderUtil.scaleEnd();

        if (player == mc.player) {
            tenacityFont18().drawString("*", x + 139 - tenacityFont18().getStringWidthFloat("*"), y + offset + 6.75F, HUDMod.getClientColors().getFirst().getRGB());
        }




    }

}
