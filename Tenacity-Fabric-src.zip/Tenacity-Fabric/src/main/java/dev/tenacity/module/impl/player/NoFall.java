package dev.tenacity.module.impl.player;

import dev.tenacity.event.impl.player.BoundingBoxEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.utils.server.PacketUtils;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Box;

@SuppressWarnings("unused")
public final class NoFall extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Packet", "Verus");
    private double dist;
    private boolean doNofall;
    private double lastFallDistance;
    private boolean c04;

    public NoFall() {
        super("NoFall", Category.PLAYER, "prevents fall damage");
        this.addSettings(mode);
    }

    @Override
    public void onMotionEvent(MotionEvent event) {
        if (event.isPre()) {
            this.setSuffix(mode.getMode());
            if (mc.player.fallDistance > 3.0 && isBlockUnder()) {
                switch (mode.getMode()) {
                    case "Vanilla":
                        event.setOnGround(true);
                        break;
                    case "Packet":
                        PacketUtils.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, false));
                        break;
                }
                mc.player.fallDistance = 0;
            }
        }
    }

    @Override
    public void onBoundingBoxEvent(BoundingBoxEvent event) {
        if (mode.is("Verus") && mc.player.fallDistance > 2) {
            final Box axisAlignedBB = new Box(-5, -1, -5, 5, 1, 5).offset(event.getBlockPos().getX(), event.getBlockPos().getY(), event.getBlockPos().getZ());
            event.setBoundingBox(axisAlignedBB);
        }
    }

    private boolean isBlockUnder() {
        if (mc.player.getY() < 0) return false;
        for (int offset = 0; offset < (int) mc.player.getY() + 2; offset += 2) {
            Box bb = mc.player.getBoundingBox().offset(0, -offset, 0);
            if (mc.world.getCollisions(mc.player, bb).iterator().hasNext()) {
                return true;
            }
        }
        return false;
    }

}
