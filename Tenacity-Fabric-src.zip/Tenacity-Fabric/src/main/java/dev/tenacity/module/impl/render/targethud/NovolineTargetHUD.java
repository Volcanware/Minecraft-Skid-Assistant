package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.utils.animations.ContinualAnimation;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.render.ColorUtil;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

import java.awt.*;

public class NovolineTargetHUD extends TargetHUD {

    private final ContinualAnimation animation = new ContinualAnimation();

    public NovolineTargetHUD() {
        super("Novoline");
    }

    @Override
    public void render(float x, float y, float alpha, LivingEntity target) {
        double healthPercentage = MathHelper.clamp((target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0, 1);

        Color c1 = ColorUtil.applyOpacity(HUDMod.getClientColors().getFirst(), alpha);
        Color c2 = ColorUtil.applyOpacity(HUDMod.getClientColors().getSecond(), alpha);

        setWidth(Math.max(120, fr.getWidth(target.getName().getString()) + 50));
        setHeight(34);

        int alphaInt = (int) (alpha * 255);

        fillRect(x, y, getWidth(), getHeight(), new Color(29, 29, 29, alphaInt).getRGB());

        fillRect(x + 1, y + 1, getWidth() - 2, getHeight() - 2, new Color(40, 40, 40, alphaInt).getRGB());

        fillRect(x + 34, y + 15, 83, 10, ColorUtil.applyOpacity(0xFF271E1D, alpha));

        float f = (float) (83 * healthPercentage);
        animation.animate(f, 40);

        gradientRectLR(x + 34, y + 15, x + 34 + animation.getOutput(), y + 25, c1.darker().darker().getRGB(), c2.darker().darker().getRGB());
        gradientRectLR(x + 34, y + 15, x + 34 + f, y + 25, c1.getRGB(), c2.getRGB());

        int textColor = ColorUtil.applyOpacity(-1, alpha);
        int mcTextColor = ColorUtil.applyOpacity(-1, (float) Math.max(.1, alpha));
        if (target instanceof AbstractClientPlayerEntity) {
            renderPlayer2D(x + 3.5f, y + 3f, 28F, 28F, (AbstractClientPlayerEntity) target, textColor);
        } else {
            drawStringWithShadow("?", x + 17 - fr.getWidth("?") / 2f, y + 17 - fr.fontHeight / 2f, mcTextColor);
        }

        drawStringWithShadow(target.getName().getString(), x + 34, y + 5, mcTextColor);

        String healthText = MathUtils.round(healthPercentage * 100, .01) + "%";
        drawStringWithShadow(healthText, x + 17 + (getWidth() / 2) - fr.getWidth(healthText) / 2f, y + 16, mcTextColor);
    }


    @Override
    public void renderEffects(float x, float y, float alpha, boolean glow) {
        fillRect(x, y, getWidth(), getHeight(), ColorUtil.applyOpacity(Color.BLACK.getRGB(), alpha));
    }

}
