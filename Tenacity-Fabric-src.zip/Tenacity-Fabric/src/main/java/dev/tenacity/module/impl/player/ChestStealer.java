package dev.tenacity.module.impl.player;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.game.WorldEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.player.RotationUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ChestStealer extends Module {

    private final NumberSetting delay = new NumberSetting("Delay", 80, 300, 0, 10);
    private final BooleanSetting aura = new BooleanSetting("Aura", false);
    private final NumberSetting auraRange = new NumberSetting("Aura Range", 3, 6, 1, 1);
    public static BooleanSetting stealingIndicator = new BooleanSetting("Stealing Indicator", false);
    public static BooleanSetting titleCheck = new BooleanSetting("Title Check", true);
    public static BooleanSetting freeLook = new BooleanSetting("Free Look", true);
    private final BooleanSetting reverse = new BooleanSetting("Reverse", false);
    public static final BooleanSetting silent = new BooleanSetting("Silent", false);
    private final BooleanSetting smart = new BooleanSetting("Smart", false);

    private final List<BlockPos> openedChests = new ArrayList<>();
    private final List<Item> items = new ArrayList<>();
    private final TimerUtil timer = new TimerUtil();
    public static boolean stealing;
    private InvManager invManager;
    private boolean clear;

    public ChestStealer() {
        super("ChestStealer", Category.PLAYER, "auto loot chests");
        auraRange.addParent(aura, s -> s.isEnabled());
        stealingIndicator.addParent(silent, s -> s.isEnabled());
        this.addSettings(delay, aura, auraRange, stealingIndicator, titleCheck, freeLook, reverse, silent, smart);
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        if (e.isPre()) {
            setSuffix(smart.isEnabled() ? "Smart" : null);
            if (invManager == null) invManager = Tenacity.INSTANCE.getModuleCollection().getModule(InvManager.class);
            if (aura.isEnabled()) {
                final int radius = (int) auraRange.getValue();
                for (int x = -radius; x < radius; x++) {
                    for (int y = -radius; y < radius; y++) {
                        for (int z = -radius; z < radius; z++) {
                            final BlockPos pos = BlockPos.ofFloored(mc.player.getX() + x, mc.player.getY() + y, mc.player.getZ() + z);
                            if (mc.world.getBlockState(pos).isOf(Blocks.CHEST) && !openedChests.contains(pos)) {
                                final BlockHitResult hitResult = new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false);
                                if (mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult).isAccepted()) {
                                    mc.player.swingHand(Hand.MAIN_HAND);
                                    final float[] rotations = RotationUtils.getRotations(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
                                    e.setYaw(rotations[0]);
                                    e.setPitch(rotations[1]);
                                    RotationUtils.setVisualRotations(rotations[0], rotations[1]);
                                    openedChests.add(pos);
                                }
                            }
                        }
                    }
                }
            }
            if (mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
                GenericContainerScreenHandler chest = (GenericContainerScreenHandler) mc.player.currentScreenHandler;
                Inventory chestInv = chest.getInventory();
                if (titleCheck.isEnabled() && !isRealChest())
                    return;
                clear = true;
                stealing = true;

                List<Integer> slots = new ArrayList<>();
                for (int i = 0; i < chestInv.size(); i++) {
                    ItemStack is = chestInv.getStack(i);
                    if (!is.isEmpty() && (!smart.isEnabled() || !(invManager.isBadItem(is, -1, true) || items.contains(is.getItem())))) {
                        slots.add(i);
                    }
                }

                if (reverse.isEnabled()) {
                    Collections.reverse(slots);
                }

                slots.forEach(s -> {
                    ItemStack is = chestInv.getStack(s);
                    Item item = is.isEmpty() ? null : is.getItem();
                    if (item != null && !items.contains(item) && (delay.getValue() == 0 || timer.hasTimeElapsed((long) delay.getValue(), true))) {
                        if (smart.isEnabled() && !(item instanceof BlockItem)) {
                            items.add(is.getItem());
                        }
                        mc.interactionManager.clickSlot(chest.syncId, s, 0, SlotActionType.QUICK_MOVE, mc.player);
                    }
                });

                if (slots.isEmpty() || isInventoryFull()) {
                    items.clear();
                    clear = false;
                    stealing = false;
                    mc.player.closeHandledScreen();
                }
            } else if (clear) {
                items.clear();
                clear = false;
            }
        }
    }

    @Override
    public void onRender2DEvent(Render2DEvent event) {
        if (stealingIndicator.isEnabled() && stealing) {
            final String text = "§lStealing...";
            final float x = ctx().getScaledWindowWidth() / 2.0F;
            final float y = ctx().getScaledWindowHeight() / 2.0F + 10;
            if (HUDMod.customFont.isEnabled()) {
                tenacityFont20().drawStringWithShadow(text, x - tenacityFont20().getStringWidthFloat(text) / 2.0F, y,
                        HUDMod.getClientColors().getFirst().getRGB());
            } else {
                ctx().drawTextWithShadow(fr, text, (int) (x - fr.getWidth(text) / 2.0F), (int) y,
                        HUDMod.getClientColors().getFirst().getRGB());
            }
        }
    }

    @Override
    public void onEnable() {
        openedChests.clear();
        super.onEnable();
    }

    private boolean isInventoryFull() {
        for (int i = 9; i < 45; i++) {
            if (mc.player.playerScreenHandler.getSlot(i).getStack().isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public static boolean canSteal() {
        if (Tenacity.INSTANCE.isEnabled(ChestStealer.class) && mc.currentScreen instanceof GenericContainerScreen) {
            return !titleCheck.isEnabled() || isRealChest();
        }
        return false;
    }

    // 1.8.9 checked ContainerLocalMenu.realChest (title equals the chest's localized name).
    // Vanilla container titles are translatable ("container.chest", ...); custom menu GUIs use literal text.
    private static boolean isRealChest() {
        return mc.currentScreen instanceof GenericContainerScreen
                && mc.currentScreen.getTitle().getContent() instanceof TranslatableTextContent
                && ((TranslatableTextContent) mc.currentScreen.getTitle().getContent()).getKey().startsWith("container.");
    }

    @Override
    public void onWorldEvent(WorldEvent event) {
        if (event instanceof WorldEvent.Load) {
            openedChests.clear();
        }
    }

}
