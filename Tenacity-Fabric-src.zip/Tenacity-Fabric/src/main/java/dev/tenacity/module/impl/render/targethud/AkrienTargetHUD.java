package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.utils.animations.ContinualAnimation;
import dev.tenacity.utils.font.CustomFont;
import dev.tenacity.utils.render.ColorUtil;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

import java.awt.*;
import java.text.DecimalFormat;

public class AkrienTargetHUD extends TargetHUD {

    private final ContinualAnimation animation = new ContinualAnimation();
    private final DecimalFormat DF_1 = new DecimalFormat("0.0");

    public AkrienTargetHUD() {
        super("Akrien");
    }

    @Override
    public void render(float x, float y, float alpha, LivingEntity target) {
        CustomFont rubikBold = rubikFont.boldSize(18);
        CustomFont rubikSmall = rubikFont.size(13);
        setWidth(Math.max(100, rubikBold.getStringWidthFloat(target.getName().getString()) + 45));
        setHeight(39.5F);

        double healthPercentage = MathHelper.clamp((target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0, 1);
        int bg = new Color(0, 0, 0, 0.4F * alpha).getRGB();

        // Draw background
        fillRect(x, y, getWidth(), 39.5F, bg);

        // Draw health bar
        fillRect(x + 2.5f, y + 31, getWidth() - 4.5f, 2.5f, bg);
        fillRect(x + 2.5f, y + 34.5f, getWidth() - 4.5f, 2.5f, bg);

        // damage anim
        float endWidth = (float) Math.max(0, (getWidth() - 3.5) * healthPercentage);
        animation.animate(endWidth, 18);

        if (animation.getOutput() > 0) {
            gradientRectBordered(x + 2.5f, y + 31, x + 1.5f + animation.getOutput(), y + 33.5f, 0.74f,
                    ColorUtil.applyOpacity(0xFF009C41, alpha),
                    ColorUtil.applyOpacity(0xFF8EFFC1, alpha), bg, bg);
        }
        double armorValue = target.getArmor() / 20.0;
        if (armorValue > 0) {
            gradientRectBordered(x + 2.5f, y + 34.5f, x + 1.5f + ((float) (getWidth() - 3.5) * (float) armorValue), y + 37, 0.74f,
                    ColorUtil.applyOpacity(0xFF0067B0, alpha),
                    ColorUtil.applyOpacity(0xFF39D5FF, alpha), bg, bg);
        }

        // Draw head
        org.joml.Matrix3x2fStack matrices = ctx().getMatrices();
        matrices.pushMatrix();
        int textColor = ColorUtil.applyOpacity(-1, alpha);
        if (target instanceof AbstractClientPlayerEntity) {
            float f = 0.8125F;
            matrices.scale(f, f);
            renderPlayer2D(x / f + 3, y / f + 3, 32, 32, (AbstractClientPlayerEntity) target, textColor);
        } else {
            fillRect(x + 3, y + 3, 25, 25, bg);
            matrices.scale(2, 2);
            rubikBold.drawStringWithShadow("?", (x + 11) / 2.0F, (y + 11) / 2.0F, textColor);
        }
        matrices.popMatrix();

        // Draw name
        rubikBold.drawString(target.getName().getString(), x + 31, y + 5, textColor);
        rubikSmall.drawString("Health: " + DF_1.format(target.getHealth()), x + 31, y + 15, textColor);
        rubikSmall.drawString("Distance: " + DF_1.format(mc.player.distanceTo(target)) + "m", x + 31, y + 22, textColor);
    }


    @Override
    public void renderEffects(float x, float y, float alpha, boolean glow) {
        fillRect(x, y, getWidth(), 39.5F, ColorUtil.applyOpacity(Color.BLACK.getRGB(), alpha));
    }

}
