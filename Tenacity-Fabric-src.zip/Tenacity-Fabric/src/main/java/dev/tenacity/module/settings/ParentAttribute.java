package dev.tenacity.module.settings;

import dev.tenacity.module.settings.impl.BooleanSetting;

import java.util.function.Predicate;

public class ParentAttribute<T extends Setting> {

    public static final Predicate<BooleanSetting> BOOLEAN_CONDITION = BooleanSetting::isEnabled;

    private final T parent;
    private final Predicate<T> condition;

    public ParentAttribute(T parent, Predicate<T> condition) {
        this.parent = parent;
        this.condition = condition;
    }

    @SuppressWarnings("unchecked")
    public boolean isValid() {
        return condition.test((T) parent);
    }

    public T getParent() {
        return parent;
    }
}
