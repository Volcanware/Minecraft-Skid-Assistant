package dev.tenacity.module.impl.player;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.SlowDownEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.server.PacketUtils;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class NoSlow extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Watchdog", "Vanilla", "NCP", "Watchdog");
    private boolean synced;

    public NoSlow() {
        super("NoSlow", Category.PLAYER, "prevent item slowdown");
        this.addSettings(mode);
    }

    @Override
    public void onSlowDownEvent(SlowDownEvent event) {
        event.cancel();
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        this.setSuffix(mode.getMode());
        switch (mode.getMode()) {
            case "Watchdog":
                if (mc.player.isOnGround() && mc.player.isUsingItem() && MovementUtils.isMoving()) {
                    int slot = mc.player.getInventory().getSelectedSlot();
                    if (e.isPre()) {
                        PacketUtils.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
                        synced = true;
                    } else {
                        PacketUtils.sendPacket(new UpdateSelectedSlotC2SPacket(slot < 8 ? slot + 1 : slot - 1));
                        synced = false;
                    }
                }
                if (!synced) {
                    PacketUtils.sendPacket(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().getSelectedSlot()));
                    synced = true;
                }
                break;
            case "NCP":
                if (MovementUtils.isMoving() && mc.player.isUsingItem()) {
                    if (e.isPre()) {
                        PacketUtils.sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, Direction.DOWN));
                    } else {
                        PacketUtils.sendPacket(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
                    }

                }
                break;
        }
    }

}
