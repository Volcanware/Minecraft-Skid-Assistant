package dev.tenacity.event.impl.render;

import dev.tenacity.event.Event;

import java.util.function.BiConsumer;

public class CustomBlockRenderEvent extends Event {

    private final BiConsumer<Float, Float> transformFirstPersonItem;
    private final Runnable doBlockTransformations;
    private final float swingProgress, equipProgress;

    public CustomBlockRenderEvent(float swingProgress, float equipProgress,
                                  BiConsumer<Float, Float> transformFirstPersonItem,
                                  Runnable doBlockTransformations) {
        this.swingProgress = swingProgress;
        this.equipProgress = equipProgress;
        this.transformFirstPersonItem = transformFirstPersonItem;
        this.doBlockTransformations = doBlockTransformations;
    }

    public float getSwingProgress() { return swingProgress; }
    public float getEquipProgress() { return equipProgress; }

    public void transformFirstPersonItem(float equipProgress, float swingProgress) {
        this.transformFirstPersonItem.accept(equipProgress, swingProgress);
    }

    public void doBlockTransformations() {
        this.doBlockTransformations.run();
    }
}
