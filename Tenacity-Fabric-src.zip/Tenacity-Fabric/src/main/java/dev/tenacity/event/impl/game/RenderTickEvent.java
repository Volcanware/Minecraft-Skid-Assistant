package dev.tenacity.event.impl.game;

import dev.tenacity.event.Event;

public class RenderTickEvent extends Event.StateEvent {

    private final float ticks;

    public RenderTickEvent(float ticks) {
        this.ticks = ticks;
    }

    public float getTicks() {
        return ticks;
    }
}
