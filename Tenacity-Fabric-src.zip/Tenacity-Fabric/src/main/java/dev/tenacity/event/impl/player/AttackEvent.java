package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;
import net.minecraft.entity.LivingEntity;

public class AttackEvent extends Event {

    private final LivingEntity targetEntity;

    public AttackEvent(LivingEntity targetEntity) {
        this.targetEntity = targetEntity;
    }

    public LivingEntity getTargetEntity() {
        return targetEntity;
    }
}
