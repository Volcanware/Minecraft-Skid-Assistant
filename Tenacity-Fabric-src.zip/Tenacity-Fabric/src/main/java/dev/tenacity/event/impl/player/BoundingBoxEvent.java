package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

public class BoundingBoxEvent extends Event {

    private final Block block;
    private final BlockPos blockPos;
    private Box boundingBox;

    public BoundingBoxEvent(Block block, BlockPos pos, Box boundingBox) {
        this.block = block;
        this.blockPos = pos;
        this.boundingBox = boundingBox;
    }

    public Block getBlock() { return this.block; }
    public BlockPos getBlockPos() { return this.blockPos; }
    public Box getBoundingBox() { return this.boundingBox; }
    public void setBoundingBox(Box boundingBox) { this.boundingBox = boundingBox; }
}
