package dev.tenacity.event.impl.game;

import dev.tenacity.event.Event;
import net.minecraft.client.world.ClientWorld;

public class WorldEvent extends Event {

    public final ClientWorld world;

    public WorldEvent(ClientWorld world) {
        this.world = world;
    }

    public static class Load extends WorldEvent {
        public Load(ClientWorld world) {
            super(world);
        }
    }

    public static class Unload extends WorldEvent {
        public Unload(ClientWorld world) {
            super(world);
        }
    }
}
