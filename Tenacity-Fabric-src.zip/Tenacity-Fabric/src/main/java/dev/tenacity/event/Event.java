package dev.tenacity.event;

public class Event {

    private boolean cancelled;

    public boolean isCancelled() { return cancelled; }

    public void cancel() {
        this.cancelled = true;
    }

    public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }

    public void call() {
        if (dev.tenacity.Tenacity.INSTANCE != null) {
            dev.tenacity.Tenacity.INSTANCE.getEventProtocol().handleEvent(this);
        }
    }

    public static class StateEvent extends Event {
        private boolean pre = true;

        public boolean isPre() { return pre; }
        public boolean isPost() { return !pre; }
        public void setPost() { pre = false; }
    }
}
