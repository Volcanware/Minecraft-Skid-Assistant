package dev.tenacity.event.impl.render;

import dev.tenacity.event.Event;
import net.minecraft.client.gui.DrawContext;

public class Render2DEvent extends Event {

    private float width, height;
    private DrawContext context;

    public Render2DEvent(float width, float height) {
        this.width = width;
        this.height = height;
    }

    public Render2DEvent(DrawContext context) {
        this.context = context;
        this.width = context.getScaledWindowWidth();
        this.height = context.getScaledWindowHeight();
    }

    public float getHeight() { return height; }
    public void setHeight(float height) { this.height = height; }
    public float getWidth() { return width; }
    public void setWidth(float width) { this.width = width; }
    public DrawContext getContext() { return context; }
    public void setContext(DrawContext context) { this.context = context; }
}
