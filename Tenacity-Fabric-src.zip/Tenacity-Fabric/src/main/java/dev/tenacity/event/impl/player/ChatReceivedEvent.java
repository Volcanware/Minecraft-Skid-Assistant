package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;
import net.minecraft.text.Text;

public class ChatReceivedEvent extends Event {

    public final byte type;
    public Text message;
    private final String rawMessage;

    public ChatReceivedEvent(byte type, Text message) {
        this.type = type;
        this.message = message;
        this.rawMessage = message.getString();
    }

    public String getRawMessage() {
        return rawMessage;
    }
}
