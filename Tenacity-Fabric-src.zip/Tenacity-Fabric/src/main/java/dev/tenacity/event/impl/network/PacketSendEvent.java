package dev.tenacity.event.impl.network;

import net.minecraft.network.packet.Packet;

public class PacketSendEvent extends PacketEvent {

    public PacketSendEvent(Packet<?> packet) {
        super(packet);
    }
}
