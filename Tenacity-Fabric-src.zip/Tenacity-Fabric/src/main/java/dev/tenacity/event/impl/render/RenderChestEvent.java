package dev.tenacity.event.impl.render;

import dev.tenacity.event.Event;
import net.minecraft.block.entity.ChestBlockEntity;

public class RenderChestEvent extends Event {

    private final ChestBlockEntity entity;
    private final Runnable chestRenderer;

    public RenderChestEvent(ChestBlockEntity entity, Runnable chestRenderer) {
        this.entity = entity;
        this.chestRenderer = chestRenderer;
    }

    public ChestBlockEntity getEntity() {
        return entity;
    }

    public void drawChest() {
        this.chestRenderer.run();
    }
}
