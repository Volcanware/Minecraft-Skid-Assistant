package dev.tenacity.event;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventProtocol {

    private final List<EventListener> listeners = new CopyOnWriteArrayList<>();

    public void register(Object listener) {
        if (!(listener instanceof EventListener)) {
            throw new IllegalArgumentException("Listener must implement EventListener");
        }
        if (!listeners.contains(listener)) {
            listeners.add((EventListener) listener);
        }
    }

    public void unregister(Object listener) {
        if (!(listener instanceof EventListener)) {
            throw new IllegalArgumentException("Listener must implement EventListener");
        }
        listeners.remove((EventListener) listener);
    }

    public void handleEvent(Event event) {
        for (EventListener listener : listeners) {
            try {
                listener.onEvent(event);
            } catch (Throwable t) {
                String desc = listener.getClass().getSimpleName() + " | "
                        + event.getClass().getSimpleName() + " | " + t;
                if (dev.tenacity.commands.impl.ModuleTestCommand.testing) {
                    dev.tenacity.commands.impl.ModuleTestCommand.ERRORS.add(desc);
                }
                System.out.println("[EventProtocol] listener error: " + desc);
            }
        }
    }
}
