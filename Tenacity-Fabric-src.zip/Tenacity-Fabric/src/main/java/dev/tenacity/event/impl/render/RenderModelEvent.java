package dev.tenacity.event.impl.render;

import dev.tenacity.event.Event;
import net.minecraft.entity.LivingEntity;

public class RenderModelEvent extends Event.StateEvent {

    private final LivingEntity entity;
    private final Runnable modelRenderer;
    private final Runnable layerRenderer;

    public RenderModelEvent(LivingEntity entity, Runnable modelRenderer, Runnable layerRenderer) {
        this.entity = entity;
        this.modelRenderer = modelRenderer;
        this.layerRenderer = layerRenderer;
    }

    public LivingEntity getEntity() {
        return entity;
    }

    public void drawModel() {
        this.modelRenderer.run();
    }

    public void drawLayers() {
        this.layerRenderer.run();
    }
}
