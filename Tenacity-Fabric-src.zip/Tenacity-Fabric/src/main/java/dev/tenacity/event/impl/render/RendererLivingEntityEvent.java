package dev.tenacity.event.impl.render;

import dev.tenacity.event.Event;
import net.minecraft.entity.LivingEntity;

public class RendererLivingEntityEvent extends Event.StateEvent {

    private final LivingEntity entity;
    private final Object renderer;
    private final float partialTicks;
    private final double x, y, z;

    public RendererLivingEntityEvent(LivingEntity entity, Object renderer, float partialTicks, double x, double y, double z) {
        this.entity = entity;
        this.renderer = renderer;
        this.partialTicks = partialTicks;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public LivingEntity getEntity() { return entity; }
    public Object getRenderer() { return renderer; }
    public float getPartialTicks() { return partialTicks; }
    public double getX() { return x; }
    public double getY() { return y; }
    public double getZ() { return z; }
}
