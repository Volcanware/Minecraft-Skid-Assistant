package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;

public class LivingDeathEvent extends Event {

    private final LivingEntity entity;
    private final DamageSource source;

    public LivingDeathEvent(LivingEntity entity, DamageSource source) {
        this.entity = entity;
        this.source = source;
    }

    public LivingEntity getEntity() { return entity; }
    public DamageSource getSource() { return source; }
}
