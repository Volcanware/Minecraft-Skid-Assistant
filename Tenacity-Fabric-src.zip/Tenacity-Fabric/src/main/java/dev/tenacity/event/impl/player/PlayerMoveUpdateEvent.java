package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;
import dev.tenacity.utils.player.MovementUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public class PlayerMoveUpdateEvent extends Event {

    private float strafe, forward, friction, yaw, pitch;

    public void applyMotion(double speed, float strafeMotion) {
        float remainder = 1 - strafeMotion;
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        strafeMotion *= 0.91;
        if (player.isOnGround()) {
            MovementUtils.setSpeed(speed);
        } else {
            player.setVelocity(player.getVelocity().x * strafeMotion, player.getVelocity().y, player.getVelocity().z * strafeMotion);
            friction = (float) speed * remainder;
        }
    }

    public float getStrafe() { return strafe; }
    public void setStrafe(float strafe) { this.strafe = strafe; }
    public float getForward() { return forward; }
    public void setForward(float forward) { this.forward = forward; }
    public float getFriction() { return friction; }
    public void setFriction(float friction) { this.friction = friction; }
    public float getYaw() { return yaw; }
    public void setYaw(float yaw) { this.yaw = yaw; }
    public float getPitch() { return pitch; }
    public void setPitch(float pitch) { this.pitch = pitch; }
}
