package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;

public class JumpFixEvent extends Event {

    private float yaw;

    public float getYaw() { return yaw; }
    public void setYaw(float yaw) { this.yaw = yaw; }
}
