package dev.tenacity;

import net.fabricmc.api.ClientModInitializer;

public class TenacityMod implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // Tenacity.INSTANCE.init() runs in MinecraftClientMixin at end of MinecraftClient init
    }
}
