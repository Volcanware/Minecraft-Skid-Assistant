package dev.tenacity;

import dev.tenacity.commands.CommandHandler;
import dev.tenacity.config.ConfigManager;
import dev.tenacity.config.DragManager;
import dev.tenacity.utils.objects.Dragging;
import dev.tenacity.event.EventProtocol;
import dev.tenacity.module.Module;
import dev.tenacity.module.ModuleCollection;
import dev.tenacity.ui.notifications.NotificationManager;
import dev.tenacity.ui.searchbar.SearchBar;
import dev.tenacity.ui.sidegui.SideGUI;
import dev.tenacity.utils.Utils;
import net.minecraft.client.MinecraftClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.awt.*;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Tenacity implements Utils {

    public static final Tenacity INSTANCE = new Tenacity();

    public static final String NAME = "Tenacity";
    public static final String VERSION = "5.1";
    public static final Logger LOGGER = LogManager.getLogger(NAME);
    public static final File DIRECTORY = new File(MinecraftClient.getInstance().runDirectory, NAME);

    private final EventProtocol eventProtocol = new EventProtocol();
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private final SideGUI sideGui = new SideGUI();
    private final SearchBar searchBar = new SearchBar();
    private final NotificationManager notificationManager = new NotificationManager();
    private ModuleCollection moduleCollection;
    private ConfigManager configManager;
    private CommandHandler commandHandler;

    private boolean initialized = false;

    public void init() {
        if (initialized) return;
        initialized = true;
        DIRECTORY.mkdirs();
        dev.tenacity.utils.render.Theme.init();
        moduleCollection = new ModuleCollection();
        moduleCollection.registerModules();
        commandHandler = new CommandHandler();
        commandHandler.registerCommands();
        configManager = new ConfigManager();
        configManager.collectConfigs();
        configManager.loadConfig(configManager.getConfig("default.json"));
    }

    public EventProtocol getEventProtocol() { return eventProtocol; }
    public ExecutorService getExecutorService() { return executorService; }
    public SideGUI getSideGui() { return sideGui; }
    public SearchBar getSearchBar() { return searchBar; }
    public NotificationManager getNotificationManager() { return notificationManager; }
    public ModuleCollection getModuleCollection() { return moduleCollection; }
    public ConfigManager getConfigManager() { return configManager; }
    public CommandHandler getCommandHandler() { return commandHandler; }

    public static boolean updateGuiScale;
    public static int prevGuiScale;

    public String getVersion() {
        return VERSION;
    }

    public Color getClientColor() {
        return new Color(236, 133, 209);
    }

    public Color getAlternateClientColor() {
        return new Color(28, 167, 222);
    }

    public boolean isEnabled(Class<? extends Module> c) {
        Module m = INSTANCE.moduleCollection.get(c);
        return m != null && m.isEnabled();
    }

    public Dragging createDrag(Module module, String name, float x, float y) {
        DragManager.draggables.put(name, new Dragging(module, name, x, y));
        return DragManager.draggables.get(name);
    }
}
