package dev.tenacity.mixin;

import dev.tenacity.event.impl.render.HurtCamEvent;
import dev.tenacity.event.impl.render.Render3DEvent;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void hurtCameraEffect(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        HurtCamEvent event = new HurtCamEvent();
        event.call();
        if (event.isCancelled()) ci.cancel();
    }

    @Inject(method = "renderWorld", at = @At("TAIL"))
    private void renderWorld(RenderTickCounter tickCounter, CallbackInfo ci) {
        new Render3DEvent(tickCounter.getTickProgress(false)).call();
    }
}
