package dev.tenacity.mixin;

import dev.tenacity.event.impl.player.*;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onUpdate(CallbackInfo ci) {
        new UpdateEvent().call();
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        MotionEvent motion = new MotionEvent(player.getX(), player.getY(), player.getZ(),
                player.getYaw(), player.getPitch(), player.isOnGround());
        motion.call();
        motion.setPost();
        motion.call();
    }

    @Inject(method = "move", at = @At("HEAD"), cancellable = true)
    private void onMove(MovementType type, Vec3d movement, CallbackInfo ci) {
        MoveEvent event = new MoveEvent(movement.x, movement.y, movement.z);
        event.call();
        if (event.isCancelled()) {
            ci.cancel();
            ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
            player.setPosition(player.getEntityPos().add(event.getX(), event.getY(), event.getZ()));
        }
    }

    @Inject(method = "pushOutOfBlocks", at = @At("HEAD"), cancellable = true)
    private void pushOutOfBlocks(double x, double d, CallbackInfo ci) {
        PushOutOfBlockEvent event = new PushOutOfBlockEvent();
        event.call();
        if (event.isCancelled()) ci.cancel();
    }
}
