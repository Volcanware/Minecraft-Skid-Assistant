package dev.tenacity.mixin;

import dev.tenacity.event.impl.player.KeepSprintEvent;
import dev.tenacity.event.impl.player.SafeWalkEvent;
import dev.tenacity.event.impl.player.SlowDownEvent;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class EntityLivingMixin {

    @Inject(method = "canWalkOnFluid", at = @At("HEAD"), cancellable = true)
    private void canWalkOnFluid(CallbackInfoReturnable<Boolean> cir) {
        // Jesus/solid-liquids modules hook in here via event if needed; kept minimal.
    }
}
