package dev.tenacity.mixin;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.player.PlayerSendMessageEvent;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {

    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void sendChatMessage(String message, CallbackInfo ci) {
        if (Tenacity.INSTANCE != null && Tenacity.INSTANCE.getCommandHandler() != null
                && Tenacity.INSTANCE.getCommandHandler().execute(message)) {
            ci.cancel();
            return;
        }
        PlayerSendMessageEvent event = new PlayerSendMessageEvent(message);
        event.call();
        if (event.isCancelled()) ci.cancel();
    }

    @Inject(method = "sendChatCommand", at = @At("HEAD"), cancellable = true)
    private void sendChatCommand(String command, CallbackInfo ci) {
        if (Tenacity.INSTANCE != null && Tenacity.INSTANCE.getCommandHandler() != null
                && Tenacity.INSTANCE.getCommandHandler().execute("/" + command)) {
            ci.cancel();
        }
    }
}
