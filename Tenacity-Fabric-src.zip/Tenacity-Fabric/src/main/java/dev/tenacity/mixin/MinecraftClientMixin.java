package dev.tenacity.mixin;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.game.TickEvent;
import dev.tenacity.event.impl.game.WorldEvent;
import dev.tenacity.utils.server.ServerUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {

    private int tickCount = 0;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInitReturn(net.minecraft.client.RunArgs args, CallbackInfo ci) {
        Tenacity.INSTANCE.init();
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void tick(CallbackInfo ci) {
        new TickEvent(tickCount++).call();
    }

    private static boolean splashShown = false;

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void setScreen(net.minecraft.client.gui.screen.Screen screen, CallbackInfo ci) {
        if (screen instanceof net.minecraft.client.gui.screen.TitleScreen && !splashShown) {
            splashShown = true;
            ci.cancel();
            MinecraftClient.getInstance().setScreen(new dev.tenacity.ui.SplashScreen());
            return;
        }
        if (screen instanceof net.minecraft.client.gui.screen.TitleScreen) {
            ci.cancel();
            MinecraftClient.getInstance().setScreen(new dev.tenacity.ui.mainmenu.CustomMainMenu());
        }
    }

    @Inject(method = "setWorld", at = @At("HEAD"))
    private void setWorld(ClientWorld world, CallbackInfo ci) {
        if (world != null) {
            new WorldEvent.Load(world).call();
        }
        ServerUtils.updateServerStatus();
    }

    @Inject(method = "close", at = @At("HEAD"))
    private void close(CallbackInfo ci) {
        if (Tenacity.INSTANCE != null && Tenacity.INSTANCE.getConfigManager() != null) {
            Tenacity.INSTANCE.getConfigManager().saveDefaultConfig();
        }
    }
}
