package dev.tenacity.mixin;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.game.KeyPressEvent;
import dev.tenacity.module.Module;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class KeyboardMixin {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void onKey(long window, int action, net.minecraft.client.input.KeyInput input, CallbackInfo ci) {
        if (Tenacity.INSTANCE == null || MinecraftClient.getInstance().player == null) return;
        int key = input.key();
        if (action == 1) { // GLFW_PRESS
            new KeyPressEvent(key).call();
            for (Module module : Tenacity.INSTANCE.getModuleCollection().getModules()) {
                if (module.getKeybind().getCode() == key && key != 0) {
                    module.toggle();
                }
            }
        }
    }
}
