package dev.tenacity.mixin;

import dev.tenacity.event.impl.player.ClickEvent;
import dev.tenacity.event.impl.player.ClickEventRight;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void onMouseButton(long window, net.minecraft.client.input.MouseInput input, int action, CallbackInfo ci) {
        if (action == 1) {
            if (input.button() == 0) new ClickEvent(false).call();
            if (input.button() == 1) new ClickEventRight().call();
        }
    }
}
