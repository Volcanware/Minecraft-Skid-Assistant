package dev.tenacity.mixin;

import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.event.impl.network.PacketReceiveEvent;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientConnection.class)
public class ClientConnectionMixin {

    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V",
            at = @At("HEAD"), cancellable = true)
    private void sendPacket(Packet<?> packet, io.netty.channel.ChannelFutureListener callbacks, boolean flush, CallbackInfo ci) {
        if (PacketUtils.skipSendEvent) return;
        PacketSendEvent event = new PacketSendEvent(packet);
        event.call();
        if (event.isCancelled()) ci.cancel();
    }

    @Inject(method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD"))
    private void channelRead0(ChannelHandlerContext context, Packet<?> packet, CallbackInfo ci) {
        new PacketReceiveEvent(packet).call();
    }
}
