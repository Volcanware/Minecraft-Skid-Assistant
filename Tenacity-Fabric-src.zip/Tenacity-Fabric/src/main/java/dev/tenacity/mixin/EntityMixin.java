package dev.tenacity.mixin;

import dev.tenacity.Tenacity;
import dev.tenacity.module.impl.render.GlowESP;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {

    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true)
    private void tenacity$glowEspColor(CallbackInfoReturnable<Integer> cir) {
        if (Tenacity.INSTANCE == null || Tenacity.INSTANCE.getModuleCollection() == null) return;
        GlowESP glow = Tenacity.INSTANCE.getModuleCollection().getModule(GlowESP.class);
        if (glow != null && glow.isEnabled() && glow.entities.contains((Entity) (Object) this)) {
            cir.setReturnValue(glow.getColorFor((Entity) (Object) this).getRGB());
            return;
        }
        dev.tenacity.module.impl.render.Chams chams = Tenacity.INSTANCE.getModuleCollection().getModule(dev.tenacity.module.impl.render.Chams.class);
        if (chams != null && chams.isEnabled() && chams.hasEntity((Entity) (Object) this)) {
            cir.setReturnValue(chams.getColorFor((Entity) (Object) this).getRGB());
            return;
        }
        dev.tenacity.module.impl.render.EntityEffects fx = Tenacity.INSTANCE.getModuleCollection().getModule(dev.tenacity.module.impl.render.EntityEffects.class);
        if (fx != null && fx.isEnabled() && fx.entities.contains((Entity) (Object) this)) {
            cir.setReturnValue(fx.getColorFor((Entity) (Object) this).getRGB());
        }
    }
}
