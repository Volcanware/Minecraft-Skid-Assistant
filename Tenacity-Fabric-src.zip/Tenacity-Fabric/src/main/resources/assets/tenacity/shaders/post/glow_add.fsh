#version 330

uniform sampler2D InSampler;
uniform sampler2D ScreenSampler;

in vec2 texCoord;

out vec4 fragColor;

void main() {
    vec4 screen = texture(ScreenSampler, texCoord);
    vec4 glow = texture(InSampler, texCoord);
    fragColor = vec4(screen.rgb + glow.rgb * glow.a, screen.a);
}
