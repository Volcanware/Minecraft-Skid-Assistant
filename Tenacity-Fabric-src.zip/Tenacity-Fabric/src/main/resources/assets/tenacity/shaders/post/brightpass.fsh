#version 330

uniform sampler2D InSampler;

in vec2 texCoord;

out vec4 fragColor;

void main() {
    vec4 c = texture(InSampler, texCoord);
    float l = dot(c.rgb, vec3(0.2126, 0.7152, 0.0722));
    float a = smoothstep(0.45, 0.9, l) * c.a;
    fragColor = vec4(c.rgb, a);
}
