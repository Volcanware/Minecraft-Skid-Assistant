# Novoline 1.8.9-style sword-block animation (isolated)

Two files reproduce the fake sword-blocking animation Novoline used on 1.8.9,
ported to modern Fabric (Yarn, MC 1.21.x):

- `cc/novoline/mixin/HeldItemRendererMixin.java` — injects into
  `HeldItemRenderer.renderFirstPersonItem` (HEAD, cancellable). For the main
  hand it runs the block-swing transform sequence (1.8.9 `transformFirstPersonItem`
  math verbatim, incl. the Exhibition case), then calls the real `renderItem`.
  For the offhand it cancels shield rendering entirely. Also contains the
  downscale-factor hook on `renderItem`'s swap-animation scale.
- `cc/novoline/modules/visual/Animations.java` — the module holding the
  settings (anim type, block height, rotating, shield-only) and
  `Animations.shouldAnimateBlock()`, the shared trigger check:
  main-hand sword + use key held + no screen open; a real offhand shield-block
  always counts, any other offhand item use suppresses it, and the
  `shield-only` toggle requires a real shield-block.

## What you need to strip/wire to port it

1. Framework bits to replace in `Animations.java`:
   - `AbstractModule`/`ModuleManager`/`Novoline` — the module framework; keep
     only `shouldAnimateBlock()` + the fields you want (block_height, rotating,
     shieldOnly can become plain fields).
   - `@Property`, `PropertyFactory`, `Setting`/`Manager` — the settings system.
   - `@EventTarget`, `Render2DEvent`, `TickUpdateEvent` — event-bus glue;
     `onRender`/`shouldSlowSwing` are just the block-height easing and the HUD
     suffix, portable or droppable.
   - `isSwordBlocking()` — legacy name kept for callers; same as
     `shouldAnimateBlock()`.

2. Vanilla calls the logic needs (Yarn names):
   - `mc.options.useKey.isPressed()` — "use" key held.
   - `mc.player.getMainHandStack().isIn(ItemTags.SWORDS)` — sword check.
   - `mc.player.isUsingItem()`, `getActiveHand()`, `getOffHandStack().isOf(Items.SHIELD)`
     — real shield-block detection / offhand-use suppression.
   - `player.getMainArm()` — left-handed players still get their main hand.
   - `MatrixStack.multiply(new Quaternionf().rotationAxis(angle*RADIANS_PER_DEGREE, x,y,z))`
     — IMPORTANT: use the scalar-arg overload; `RotationAxis.of(Vector3f)` does
     NOT normalize and non-unit axes blow the item off-screen.

3. Mixin wiring:
   - Add `HeldItemRendererMixin` to your mixins.json and register a
     `novoline-refmap.json` (or your own refmap) in the jar for production.
   - The inject signature must match 1.21.x `renderFirstPersonItem`
     (player, tickProgress, pitch, hand, swingProgress, item, equipProgress,
     matrices, queue, light, ci) — re-check on other versions.
