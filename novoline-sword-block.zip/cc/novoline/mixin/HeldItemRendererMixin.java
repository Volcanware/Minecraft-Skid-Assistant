package cc.novoline.mixin;

import cc.novoline.Novoline;
import cc.novoline.modules.visual.Animations;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.state.Lancing;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.AxisAngle4f;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/* PORT: replaces the 1.8.9 ItemRenderer#renderItemInFirstPerson injection.
 * In 1.8.9 a held sword reported EnumAction.BLOCK while right-click was held,
 * which routed rendering through the Novoline block-animation switch. Sword
 * blocking no longer exists, so the mixin fakes the 1.8.9 BLOCK state purely
 * visually: Animations enabled + main-hand sword + use key held (and no real
 * item in use) -> run the original transform switch.
 *
 * Translation table for the 1.8.9 helpers:
 *   transformFirstPersonItem(equip, swing) -> applyEquipOffset + applySwingOffset
 *   func_178103_d(qq)                      -> novoline$blockPose
 *   func_178105_d(swing)                   -> the bob-translate inside swingArm
 *   GlStateManager.rotate(a, x, y, z)      -> Quaternionf/AxisAngle4f
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {

    @Shadow
    @Final
    private MinecraftClient client;

    @Unique
    private int novoline$frame;

    @Invoker("applyEquipOffset")
    abstract void novoline$applyEquipOffset(MatrixStack matrices, Arm arm, float equipProgress);

    @Invoker("applySwingOffset")
    abstract void novoline$applySwingOffset(MatrixStack matrices, Arm arm, float swingProgress);



    /** 1.8.9's `height` variable scaled the first arg of every transformFirstPersonItem call. */
    @ModifyArgs(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"))
    private void novoline$heightOffset(Args args) {
        Animations animations = novoline$animations();
        if (animations != null && animations.isEnabled()) {
            float height = 0.8F + animations.getHeight() / 100.0F;
            args.set(6, (float) args.get(6) + (height - 1.0F));
        }
    }

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), cancellable = true)
    private void novoline$animations(AbstractClientPlayerEntity player, float tickProgress, float pitch, Hand hand,
                                     float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                                     OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        Animations animations = novoline$animations();
        if (animations == null || !animations.isEnabled() || player.isUsingSpyglass()) {
            return;
        }

        /* 1.8.9 had no offhand — offhand items render vanilla, except the shield
         * which never renders in first person while Animations is on: the block
         * animation covers blocking instead of the shield pull-up. */
        if (hand == Hand.OFF_HAND) {
            if (item.isOf(Items.SHIELD)) {
                ci.cancel();
            }
            return;
        }

        Arm arm = player.getMainArm();
        ItemDisplayContext context = arm == Arm.RIGHT
                ? ItemDisplayContext.FIRST_PERSON_RIGHT_HAND
                : ItemDisplayContext.FIRST_PERSON_LEFT_HAND;

        if (novoline$isSwordBlocking(player, item)) {
            ci.cancel();
            this.novoline$frame++;
            matrices.push();

            float f = equipProgress;
            float f1 = swingProgress;
            float var9 = MathHelper.sin(MathHelper.sqrt(f1) * MathHelper.PI);

            if (animations.getRotating()) {
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(this.novoline$frame));
            }

            switch (animations.getAnim().get()) {
                case "Punch" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f, 0.0F);
                    novoline$blockPose(matrices, 0.2F);
                    matrices.translate(0.1F, 0.2F, 0.3F);
                    novoline$rotate(matrices, -var9 * 30.0F, -5.0F, 0.0F, 9.0F);
                    novoline$rotate(matrices, -var9 * 10.0F, 1.0F, -0.4F, -0.5F);
                }
                case "Stella" -> {
                    novoline$transformFirstPersonItem(matrices, arm, -0.1F, f1);
                    matrices.translate(-0.5F, 0.4F, -0.2F);
                    novoline$rotate(matrices, 30.0F, 0.0F, 1.0F, 0.0F);
                    novoline$rotate(matrices, -70.0F, 1.0F, 0.0F, 0.0F);
                    novoline$rotate(matrices, 40.0F, 0.0F, 1.0F, 0.0F);
                }
                case "1.7" -> {
                    novoline$transformFirstPersonItem(matrices, arm, -0.1F, f1);
                    novoline$blockPose(matrices, 0.2F);
                }
                case "Styles" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f, 0.0F);
                    novoline$blockPose(matrices, 0.2F);
                    float var11 = MathHelper.sin(MathHelper.sqrt(f1) * MathHelper.PI);
                    matrices.translate(-0.05F, 0.2F, 0.0F);
                    novoline$rotate(matrices, -var11 * 70.0F / 2.0F, -8.0F, 0.0F, 9.0F);
                    novoline$rotate(matrices, -var11 * 70.0F, 1.0F, -0.4F, 0.0F);
                }
                case "Swank" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f / 2.0F, f1);
                    float var151 = MathHelper.sin(MathHelper.sqrt(f1) * MathHelper.PI);
                    novoline$rotate(matrices, var151 * 30.0F, -var151, 0.0F, 9.0F);
                    novoline$rotate(matrices, var151 * 40.0F, 1.0F, -var151, 0.0F);
                    novoline$blockPose(matrices, 0.4F);
                }
                case "Swang" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f / 2.0F, f1);
                    float var152 = MathHelper.sin(MathHelper.sqrt(f1) * MathHelper.PI);
                    novoline$rotate(matrices, var152 * 30.0F / 2.0F, -var152, 0.0F, 9.0F);
                    novoline$rotate(matrices, var152 * 40.0F, 1.0F, -var152 / 2.0F, 0.0F);
                    novoline$blockPose(matrices, 0.4F);
                }
                case "Swong" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f / 2.0F, 0.0F);
                    float var153 = MathHelper.sin(f1 * f1 * MathHelper.PI);
                    novoline$rotate(matrices, -var153 * 40.0F / 2.0F, var153 / 2.0F, 0.0F, 9.0F);
                    novoline$rotate(matrices, -var153 * 30.0F, 1.0F, var153 / 2.0F, 0.0F);
                    novoline$blockPose(matrices, 0.4F);
                }
                case "Swaing" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f / 2.0F, -0.2F);
                    float var154 = MathHelper.sin(f1 * f1 * MathHelper.PI);
                    novoline$rotate(matrices, -var154 / 19.0F, var154 / 20.0F, 0.0F, 9.0F);
                    novoline$rotate(matrices, -var154 * 30.0F, 10.0F, var154 / 50.0F, 0.0F);
                    novoline$blockPose(matrices, 0.4F);
                }
                case "Swing" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f / 2.0F, f1);
                    novoline$blockPose(matrices, 0.4F);
                }
                case "Smooth" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f / 1.5F, 0.0F);
                    novoline$blockPose(matrices, 0.2F);
                    matrices.translate(-0.05F, 0.3F, 0.3F);
                    novoline$rotate(matrices, -var9 * 140.0F, 8.0F, 0.0F, 8.0F);
                    novoline$rotate(matrices, var9 * 90.0F, 8.0F, 0.0F, 8.0F);
                }
                case "Sigma" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f * 0.5F, 0.0F);
                    novoline$rotate(matrices, -var9 * 55.0F / 2.0F, -8.0F, 0.0F, 9.0F);
                    novoline$rotate(matrices, -var9 * 45.0F, 1.0F, var9 / 2.0F, 0.0F);
                    novoline$blockPose(matrices, 0.2F);
                    matrices.translate(1.2F, 0.3F, 0.5F);
                    matrices.translate(-1.0F, player.isSneaking() ? -0.1F : -0.2F, 0.2F);
                }
                case "Slide" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f, 0.0F);
                    novoline$blockPose(matrices, 0.2F);
                    matrices.translate(-0.4F, 0.3F, 0.0F);
                    novoline$rotate(matrices, -var9 * 35.0F, -8.0F, 0.0F, 9.0F);
                    novoline$rotate(matrices, -var9 * 70.0F, 1.0F, -0.4F, 0.0F);
                    matrices.translate(-0.05F, player.isSneaking() ? -0.2F : 0.0F, 0.1F);
                }
                case "Interia" -> {
                    novoline$transformFirstPersonItem(matrices, arm, 0.05F, f1);
                    matrices.translate(-0.5F, 0.5F, 0.0F);
                    novoline$rotate(matrices, 30.0F, 0.0F, 1.0F, 0.0F);
                    novoline$rotate(matrices, -80.0F, 1.0F, 0.0F, 0.0F);
                    novoline$rotate(matrices, 60.0F, 0.0F, 1.0F, 0.0F);
                }
                case "Ethereal" -> {
                    novoline$transformFirstPersonItem(matrices, arm, f, 0.0F);
                    novoline$blockPose(matrices, 0.2F);
                    matrices.translate(-0.05F, 0.2F, 0.2F);
                    novoline$rotate(matrices, -var9 * 70.0F / 2.0F, -8.0F, 0.0F, 9.0F);
                    novoline$rotate(matrices, -var9 * 70.0F, 1.0F, -0.4F, 0.0F);
                }
                case "Exhibition" -> {
                    matrices.translate(-0.04F, 0.13F, 0.0F);
                    novoline$transformFirstPersonItem(matrices, arm, f / 2.5F, 0.0F);
                    novoline$rotate(matrices, -var9 * 40.0F / 2.0F, var9 / 2.0F, 1.0F, 4.0F);
                    novoline$rotate(matrices, -var9 * 30.0F, 1.0F, var9 / 3.0F, 0.0F);
                    novoline$blockPose(matrices, 0.2F);
                }
                case "Spinning" -> {
                    matrices.translate(-0.04F, 0.1F, 0.0F);
                    novoline$transformFirstPersonItem(matrices, arm, f / 2.5F, 0.0F);
                    novoline$rotate(matrices, -90.0F, 1.0F, 0.0F, 0.2F);
                    novoline$rotate(matrices, this.novoline$frame, 0.0F, -1.0F, 0.0F);
                }
                default -> {
                    novoline$transformFirstPersonItem(matrices, arm, f, 0.0F);
                    novoline$blockPose(matrices, 0.2F);
                }
            }

            /* Item-transform compensation: the modern firstperson_righthand display
             * transform (rot -90Y / scale 0.68 / t .0706,.2,.0706) differs from 1.8.9's
             * firstperson (rot -135Y / scale 1.7 / t 0,.25,.125). Solving the two matrix
             * chains, this exact delta makes the modern transform produce the 1.8.9 pose
             * (the -45Y + 2.5 scale re-fold the baseline baked into modern item models). */
            matrices.translate(0.0F, -0.25F, -0.125F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((arm == Arm.RIGHT ? 1 : -1) * -45.0F));
            matrices.scale(2.5F, 2.5F, 2.5F);

            ((HeldItemRenderer) (Object) this).renderItem(player, item, context, matrices, queue, light);
            matrices.pop();
            return;
        }

        // HIT_ANIM_MODE "Smooth": the 1.8.9 code skipped func_178105_d (the swing
        // bob-translate) but still applied equip + swing rotation.
        boolean usingItem = player.isUsingItem() && player.getItemUseTimeLeft() > 0 && player.getActiveHand() == hand;
        if ("Smooth".equals(animations.getHit().get()) && !item.isEmpty()
                && !item.contains(DataComponentTypes.MAP_ID) && !item.isOf(Items.CROSSBOW)
                && !usingItem && !player.isUsingRiptide()) {
            ci.cancel();
            matrices.push();
            novoline$applyEquipOffset(matrices, arm, equipProgress - 0.05F);
            switch (item.getSwingAnimation().type()) {
                case WHACK -> novoline$applySwingOffset(matrices, arm, swingProgress);
                case STAB -> Lancing.method_75391(swingProgress, matrices, arm == Arm.RIGHT ? 1 : -1, arm);
                default -> {
                }
            }
            ((HeldItemRenderer) (Object) this).renderItem(player, item, context, matrices, queue, light);
            matrices.pop();
        }
    }

    /** 1.8.9 downscale-factor: shrinks flat (non-3D) held items in first person. */
    @Inject(method = "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/ItemRenderState;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;III)V"),
            locals = LocalCapture.CAPTURE_FAILHARD)
    private void novoline$downscale(LivingEntity entity, ItemStack stack, ItemDisplayContext renderMode,
                                    MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                                    CallbackInfo ci, ItemRenderState itemRenderState) {
        /* downscale-factor applies to the main hand's first-person context only. */
        ItemDisplayContext mainHandContext = this.client.player != null && this.client.player.getMainArm() == Arm.LEFT
                ? ItemDisplayContext.FIRST_PERSON_LEFT_HAND
                : ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
        if (renderMode == mainHandContext) {
            Animations animations = novoline$animations();
            if (animations != null && animations.isEnabled() && !itemRenderState.isSideLit()) {
                float scale = (float) (1.0 - animations.getDownscaleFactor().get());
                matrices.scale(scale, scale, scale);
            }
        }
    }

    @Unique
    private boolean novoline$isSwordBlocking(AbstractClientPlayerEntity player, ItemStack item) {
        /* Sword in hand + shared trigger logic (shield-only, offhand-use suppression
         * and real shield-block all handled inside Animations.shouldAnimateBlock). */
        return item.isIn(ItemTags.SWORDS) && Animations.shouldAnimateBlock();
    }

    /** 1.8.9 transformFirstPersonItem verbatim: BOTH translates (incl. the second
     *  -0.6*equip), unconditional 45Y + swing rotations, and the 0.4 scale that the
     *  modern applySwingOffset replaced with a -45Y unwind. The 0.4 scale matters:
     *  every anim-case translate was authored inside it, so without it all offsets
     *  apply 2.5x too large. */
    @Unique
    private void novoline$transformFirstPersonItem(MatrixStack matrices, Arm arm, float equipProgress, float swingProgress) {
        int i = arm == Arm.RIGHT ? 1 : -1;
        matrices.translate(i * 0.56F, -0.52F - equipProgress * 0.6F, -0.72F);
        matrices.translate(0.0F, equipProgress * -0.6F, 0.0F);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * 45.0F));
        float f = MathHelper.sin(swingProgress * swingProgress * (float) Math.PI);
        float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * f * -20.0F));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * g * -20.0F));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -80.0F));
        matrices.scale(0.4F, 0.4F, 0.4F);
    }

    /** 1.8.9 func_178103_d — the blocking pose. */
    @Unique
    private void novoline$blockPose(MatrixStack matrices, float height) {
        matrices.translate(-0.5F, height, 0.0F);
        novoline$rotate(matrices, 30.0F, 0.0F, 1.0F, 0.0F);
        novoline$rotate(matrices, -80.0F, 1.0F, 0.0F, 0.0F);
        novoline$rotate(matrices, 60.0F, 0.0F, 1.0F, 0.0F);
    }

    /** GlStateManager.rotate(angle, x, y, z) — arbitrary-axis degrees rotation. */
    @Unique
    private void novoline$rotate(MatrixStack matrices, float angle, float x, float y, float z) {
        if (angle != 0.0F) {
            /* glRotatef normalized the axis; JOML's rotationAxis(angle,x,y,z) does too
             * (the Vector3f overload requires a pre-normalized axis — non-unit axes
             * produce non-unit quaternions that scale the matrix and blow the item up). */
            matrices.multiply(new Quaternionf().rotationAxis(angle * MathHelper.RADIANS_PER_DEGREE, x, y, z));
        }
    }

    @Unique
    private Animations novoline$animations() {
        return Novoline.getInstance().getModuleManager() != null
                ? Novoline.getInstance().getModuleManager().getModule(Animations.class)
                : null;
    }
}
