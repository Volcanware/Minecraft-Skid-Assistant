/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.impactdevelopment.simpletweaker.SimpleTweaker
 *  net.minecraft.launchwrapper.Launch
 *  net.minecraft.launchwrapper.LaunchClassLoader
 *  org.spongepowered.asm.launch.MixinBootstrap
 *  org.spongepowered.asm.mixin.MixinEnvironment
 *  org.spongepowered.asm.mixin.MixinEnvironment$Side
 *  org.spongepowered.asm.mixin.Mixins
 */
package clientapi.load;

import io.github.impactdevelopment.simpletweaker.SimpleTweaker;
import java.util.List;
import net.impactclient.2w$6X;
import net.impactclient.3A;
import net.impactclient.3J;
import net.impactclient.4k;
import net.minecraft.launchwrapper.Launch;
import net.minecraft.launchwrapper.LaunchClassLoader;
import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.Mixins;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class ClientTweaker
extends SimpleTweaker {
    private static final String[] c;
    public static final boolean \u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005;
    private static final String[] b;
    private static String[] 2;

    /*
     * Enabled aggressive block sorting
     */
    private void setupMixin() {
        block4: {
            block2: {
                String string2;
                boolean bl;
                block3: {
                    bl = \u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005;
                    if (bl || bl) break block2;
                    MixinBootstrap.init();
                    if (bl || bl) break block2;
                    3A.8.info(ClientTweaker.a((int)((long)-699438225 ^ (long)-699434587), (int)((long)293023911 ^ (long)293033912)) /* "Initialized Mixin bootstrap" */);
                    if (bl || bl) break block2;
                    List list = (List)Launch.blackboard.get(ClientTweaker.a((int)((long)1445690119 ^ (long)1445685697), (int)((long)-190902054 ^ (long)190899586)) /* "TweakClasses" */);
                    if (bl) break block2;
                    string2 = ClientTweaker.a((int)((long)-198153321 ^ (long)-198149793), (int)((long)327005419 ^ (long)327009687)) /* "notch" */;
                    if (bl || bl) break block2;
                    if (!list.stream().anyMatch(string -> {
                        boolean bl = \u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005;
                        if (bl || bl) {
                            return true;
                        }
                        return string.contains(ClientTweaker.a((int)((long)-1902526897 ^ (long)-1902531456), (int)((long)799328628 ^ (long)799328793)) /* "net.minecraftforge.fml.common.launcher" */);
                    })) break block3;
                    if (bl || bl) break block2;
                    string2 = ClientTweaker.a((int)((long)560712043 ^ (long)560716718), (int)((long)1493387902 ^ (long)1493384050)) /* "searge" */;
                    if (bl || bl) break block2;
                    3A.8.info(ClientTweaker.a((int)((long)80400040 ^ (long)80403553), (int)((long)1678955410 ^ (long)1678938658)) /* "Discovered FML! Switching to SEARGE mappings." */);
                    if (bl) break block2;
                }
                if (bl) break block2;
                MixinEnvironment.getDefaultEnvironment().setSide(MixinEnvironment.Side.CLIENT);
                if (bl || bl) break block2;
                MixinEnvironment.getDefaultEnvironment().setObfuscationContext(string2);
                if (bl || bl) break block2;
                3A.8.info(ClientTweaker.a((int)((long)1735047805 ^ (long)1735043257), (int)((long)-1184607865 ^ (long)1184624592)) /* "Setup Mixin Environment" */);
                if (!bl && !bl) break block4;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void loadMixinConfig(String string) {
        boolean bl = \u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005;
        if (bl || bl) return;
        if (((Object)((Object)this)).getClass().getResourceAsStream(2w$6X.KAOZ("\uee99", -1036176717).concat(String.valueOf(string))) == null) {
            if (bl || bl) return;
            Object[] objectArray = new Object[(int)((long)-980342102 ^ (long)-980342101)];
            objectArray[(int)((long)1089221828 ^ (long)1089221828)] = string;
            throw new 4k(ClientTweaker.a((int)((long)-2071194815 ^ (long)-2071199347), (int)((long)-324025542 ^ (long)-324012913)) /* "Unable to locate mixin configuration %s" */, objectArray);
        }
        if (bl) return;
        Mixins.addConfiguration((String)string);
        if (!bl && !bl) return;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-1177624756 ^ (long)-1177624768)];
            if (var7) break block23;
            var3_2 = (int)((long)290904713 ^ (long)290904713);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u64f2\ub636\ua514\uad57\u644b\ub692\ua56c\uad60\u6448\ub64b\ua55d\uade9\u647c\ub616\ua512\uada2\u64ec\ub62c\ua524\uad1b\u6410\ub6d2\ua5e6\uad1d\u64e4\ub696\ua556\uadd1\u648f\ub660\ua586\uade7\u647c\ub6da\ua575\uadb1\u6492\ub6ea\ua532\uad7f\u6460\ub657\ua564\uad91\u6438\ub6d0\ua5fe\uadb5\u6427\ub616\ua564\uadde\u6460\ub6fa\ua5a5\uad34\u6463\ub6bb\ua560\uadf5\u64cf\ub6cc\ua594\uad9a\u64f2\ub636\ua557\uada9\u64d7\ub626\ua5ab\uad99\u6410\ub67a\ua564\uad2e\u64d1\ub699\ua54b\uadaa\u6460\ub603\ua594\uad24\u64db\ub68e\ua595\uadd5\u6495\ub690\ua570\uadc1\u64e1\ub612\ua5f0\uad4a\u6454\ub642\ua5b6\uad16\u6412\ub69d\ua5ce\uad78\u6428\ub67d\ua51b\uade6\u643d\ub6c3\ua595\uadef\u64fa\ub640\ua595\uadd6\u6486\ub625\ua5bf\uadbe\u645e\ub660\ua55c\uad0f\u6450\ub69a\ua59b\uadeb\u64ed\ub67d\ua530\uada2\u64b8\ub68f\ua592\uad38\u6455\ub601\ua50f\uadd7\u64a2\ub605\ua5f8\uad05\u646c\ub602\ua5c6\uad34\u64d6\ub6bc\ua5f2\uadeb\u6469\ub6d8\ua5e3\uad6e\u64b5\ub677\ua57e\uadcf\u646c\ub67b\ua59b\uadd8\u64a6\ub6fb\ua544\uad7b\u64c4\ub636\ua517\uadb0\u6413\ub62b\ua56a\uad2f\u6418\ub685\ua553\uad52\u6401\ub644\ua5c2\uad64\u6422\ub693\ua576\uadb6\u64eb\ub65e\ua578\uad8e\u64d5\ub6b3\ua5ca\uad0d\u6402\ub62d\ua524\uad67\u6423\ub6d8\ua56a\uad22\u64be\ub689\ua5b6\uadd6\u64aa\ub615\ua536\uad98\u6401\ub670\ua5e2\uad0b\u64d4\ub63e\ua5f7\uad7f\u648a\ub681\ua55b\uadf3\u647c\ub64b\ua541\uad51\u643e\ub6a3\ua577\uadfd\u64ef\ub607\ua5f0\uad00\u64a0\ub67a\ua56f\uad73\u6446\ub6e0\ua569\uad47\u64db\ub666\ua5a7\uad40\u64fd\ub6c3\ua518\uadb0\u6479\ub618\ua5a5\uad7f\u646b\ub6c5\ua5c8\uadb0\u6442", -268650300);
            var4_4 = var2_3.length();
            var1_5 = (int)((long)-852104866 ^ (long)-852104892);
            var0_6 = (int)((long)-526569135 ^ (long)526569134);
            ClientTweaker.4(null);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-173372135 ^ (long)-173372060);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)640197325 ^ (long)-640197326);
                    if (ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) {
                        throw null;
lbl23:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ua219\u70ec\u639c\u6ba0\ua240\u70a1\u63a1\u6ba1\ua213\u7083\u6332\u6be0\ua2df\u709d\u636b\u6bcd\ua284\u70bf\u6355\u6bbc\ua2d9\u70af\u6332\u6bda\ua2e8\u7091\u6357\u6b46\ua275\u70c5\u63ac", -1121943828);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1018326568 ^ (long)-1018326582);
                            var0_6 = (int)((long)1278900244 ^ (long)-1278900245);
                            while (true) {
                                v0 = (int)((long)-1931313487 ^ (long)-1931313465);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1151279774 ^ (long)-1151279774);
                                if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break block20;
                                throw null;
                            }
                            break;
                        }
lbl40:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) ** continue;
                                throw null;
                            }
                            ClientTweaker.b = var5_1;
                            ClientTweaker.c = new String[(int)((long)-208723643 ^ (long)-208723639)];
                            if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1851576229 ^ (long)-1851576229);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1035552297 ^ (long)1035552296)) ** GOTO lbl106
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1909009772 ^ (long)1909009771)) {
                                case 0: {
                                    v15 = (int)((long)-1757973689 ^ (long)-1757973640);
                                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1948928240 ^ (long)-1948928248);
                                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1551212986 ^ (long)1551212934);
                                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1196526322 ^ (long)-1196526304);
                                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1610405235 ^ (long)-1610405190);
                                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-196896721 ^ (long)-196896720);
                                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1678541384 ^ (long)-1678541402);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl117:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void injectIntoClassLoader(LaunchClassLoader launchClassLoader) {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005;
                    if (bl || bl) break block2;
                    super.injectIntoClassLoader(launchClassLoader);
                    if (bl) break block2;
                    String[] stringArray = ClientTweaker.9();
                    3A.8.info(ClientTweaker.a((int)((long)-2125379988 ^ (long)-2125376351), (int)((long)-417215389 ^ (long)417224162)) /* "Injecting into ClassLoader" */);
                    String[] stringArray2 = stringArray;
                    if (bl || bl) break block2;
                    this.setupMixin();
                    if (bl || bl) break block2;
                    this.loadMixinConfig(ClientTweaker.a((int)((long)1644206355 ^ (long)1644202973), (int)((long)1536496213 ^ (long)-1536493969)) /* "mixins.capi.json" */);
                    if (bl || bl) break block2;
                    this.loadMixinConfig(ClientTweaker.a((int)((long)179272844 ^ (long)179269195), (int)((long)1495697894 ^ (long)-1495705885)) /* "mixins.impact.json" */);
                    if (bl || bl) break block2;
                    3A.8.info(ClientTweaker.a((int)((long)85461877 ^ (long)85465534), (int)((long)1911844860 ^ (long)-1911837719)) /* "Loaded Mixin Configurations" */);
                    if (bl || bl) break block2;
                    if (stringArray2 == null) break block3;
                    if (bl) break block2;
                    3J.7(new 3J[(int)((long)179773395 ^ (long)179773399)]);
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void 4(String[] stringArray) {
        block3: {
            block2: {
                boolean bl = \u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005;
                if (bl) break block2;
                2 = stringArray;
                if (!bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1452846469 ^ (long)-1452851018)) & (int)((long)-288404784 ^ (long)-288377553);
            if (var9_2) ** GOTO lbl-1000
            if (ClientTweaker.c[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = ClientTweaker.b[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)233772284 ^ (long)233772284)] & (int)((long)886431048 ^ (long)886431159)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1920577507 ^ (long)-1920577408);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1601510654 ^ (long)1601510482);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-589079573 ^ (long)-589079695);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1101708365 ^ (long)1101708455);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)2012499583 ^ (long)2012499554);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1935752121 ^ (long)1935752145);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-399741477 ^ (long)-399741595);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)434948298 ^ (long)434948189);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1641712992 ^ (long)-1641713038);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1406426143 ^ (long)-1406426329);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)761565737 ^ (long)761565870);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)387895515 ^ (long)387895515);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1015721721 ^ (long)-1015721560);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-409638900 ^ (long)-409638825);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1000926588 ^ (long)-1000926540);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1345225325 ^ (long)1345225256);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1323997439 ^ (long)-1323997220);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1465717360 ^ (long)-1465717425);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1101176202 ^ (long)-1101176312);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1753116017 ^ (long)-1753116154);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1863954150 ^ (long)-1863954099);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1541100614 ^ (long)1541100702);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-28644920 ^ (long)-28645118);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1108414212 ^ (long)1108414210);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-639459865 ^ (long)-639459886);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1379614261 ^ (long)-1379614258);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1536312233 ^ (long)1536312076);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)722135154 ^ (long)722135184);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1306048043 ^ (long)1306048002);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1795109325 ^ (long)1795109216);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)2065439915 ^ (long)2065439916);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-560150868 ^ (long)-560151002);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)890918974 ^ (long)890919024);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)276490785 ^ (long)276490786);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1509079766 ^ (long)1509079804);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-2124709166 ^ (long)-2124709138);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-27095180 ^ (long)-27095193);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1836121995 ^ (long)-1836121940);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1751032478 ^ (long)1751032433);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-391045906 ^ (long)-391046003);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1971223479 ^ (long)1971223362);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-243402523 ^ (long)-243402662);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1696426162 ^ (long)-1696426033);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-734086372 ^ (long)-734086225);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)978318985 ^ (long)978318998);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-117538711 ^ (long)-117538603);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)591907387 ^ (long)591907527);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1943434386 ^ (long)-1943434477);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-2005458497 ^ (long)-2005458583);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-965091603 ^ (long)-965091735);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-2021225422 ^ (long)-2021225333);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1432634488 ^ (long)-1432634591);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)196224474 ^ (long)196224445);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)893489013 ^ (long)893488987);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-335338589 ^ (long)-335338684);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1479922171 ^ (long)1479921939);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)111427683 ^ (long)111427714);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-2061198782 ^ (long)-2061198774);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)336016747 ^ (long)336016872);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-203055648 ^ (long)-203055628);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1578058894 ^ (long)1578058936);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1841612100 ^ (long)-1841612180);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)753511621 ^ (long)753511496);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-105032955 ^ (long)-105032949);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)273497123 ^ (long)273497214);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)2013072311 ^ (long)2013072333);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)829233509 ^ (long)829233575);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1704901845 ^ (long)1704901869);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1433188916 ^ (long)1433188931);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1687797481 ^ (long)-1687797493);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1059743468 ^ (long)-1059743464);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1010734940 ^ (long)-1010734982);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1243679356 ^ (long)1243679448);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1209881219 ^ (long)-1209881101);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)84650050 ^ (long)84650175);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1694265833 ^ (long)-1694265807);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1548308215 ^ (long)1548308098);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1693031998 ^ (long)1693032068);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-667825846 ^ (long)-667825750);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)2004177865 ^ (long)2004177842);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)341354306 ^ (long)341354290);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1655054997 ^ (long)1655054947);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1111664749 ^ (long)1111664699);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)2057047873 ^ (long)2057047994);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)663029717 ^ (long)663029566);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-758917687 ^ (long)-758917728);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1635851671 ^ (long)-1635851581);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1137352634 ^ (long)1137352506);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)2108025443 ^ (long)2108025401);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)276804899 ^ (long)276805104);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1991378526 ^ (long)-1991378577);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1846870061 ^ (long)1846870016);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1737038192 ^ (long)1737038136);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)937018841 ^ (long)937018861);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-363457891 ^ (long)-363457994);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-99230331 ^ (long)-99230243);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1095181760 ^ (long)-1095181818);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)695203742 ^ (long)695203717);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1250727638 ^ (long)1250727502);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1084788078 ^ (long)1084788222);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1860869742 ^ (long)1860869790);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-898918143 ^ (long)-898917902);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)263411866 ^ (long)263411870);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1797783466 ^ (long)-1797783331);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-444166188 ^ (long)-444166363);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)297915095 ^ (long)297914991);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-516765786 ^ (long)-516765896);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1392054578 ^ (long)-1392054565);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)94776605 ^ (long)94776687);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-2126464196 ^ (long)-2126464100);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1460227937 ^ (long)-1460228040);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1985427141 ^ (long)-1985427109);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1169128464 ^ (long)-1169128541);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1779373496 ^ (long)1779373553);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)53238309 ^ (long)53238281);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-323587152 ^ (long)-323587124);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-243592957 ^ (long)-243592951);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1101643958 ^ (long)1101643968);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-12559758 ^ (long)-12559691);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1294600895 ^ (long)1294600840);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1661234789 ^ (long)-1661234790);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1655196450 ^ (long)-1655196622);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1784657967 ^ (long)-1784658074);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1870717732 ^ (long)-1870717838);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1417736069 ^ (long)1417736076);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1355858725 ^ (long)1355858769);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)779205745 ^ (long)779205706);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)2040204973 ^ (long)2040204983);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1404883941 ^ (long)-1404883740);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1431880300 ^ (long)-1431880272);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)2088701044 ^ (long)2088701051);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1187508833 ^ (long)-1187508967);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1668360737 ^ (long)-1668360854);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1414439391 ^ (long)1414439307);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1549076907 ^ (long)-1549076754);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1104083506 ^ (long)1104083686);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-951039689 ^ (long)-951039622);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-451951946 ^ (long)-451952094);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)319518869 ^ (long)319518775);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1656386489 ^ (long)1656386397);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1747739015 ^ (long)-1747739075);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)2020642409 ^ (long)2020642466);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1740597334 ^ (long)-1740597386);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1990092609 ^ (long)-1990092575);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)2004865877 ^ (long)2004865994);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1742403207 ^ (long)1742403139);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-501291207 ^ (long)-501291214);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)304906906 ^ (long)304906755);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1961796547 ^ (long)1961796525);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)968283164 ^ (long)968283222);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1910633721 ^ (long)1910633483);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)875824830 ^ (long)875824772);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1923159223 ^ (long)1923159057);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1270489723 ^ (long)-1270489644);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-880783275 ^ (long)-880783342);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1000827119 ^ (long)1000827088);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)2049518542 ^ (long)2049518427);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-782523509 ^ (long)-782523499);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-159420717 ^ (long)-159420745);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1849708920 ^ (long)-1849708947);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-906694223 ^ (long)-906694298);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)435243395 ^ (long)435243313);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-413868873 ^ (long)-413868905);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-639812984 ^ (long)-639813120);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-138704189 ^ (long)-138704327);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1776413210 ^ (long)1776413208);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1397323099 ^ (long)1397323256);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)670673319 ^ (long)670673397);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-133020200 ^ (long)-133020343);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1947480562 ^ (long)-1947480495);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1693804058 ^ (long)-1693804135);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)211905254 ^ (long)211905064);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-2070430270 ^ (long)-2070430256);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1626015967 ^ (long)-1626015923);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1568308238 ^ (long)1568308328);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-2084200621 ^ (long)-2084200558);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)971389753 ^ (long)971389819);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)60325874 ^ (long)60325860);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-824378624 ^ (long)-824378548);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1590308199 ^ (long)1590308208);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1991140982 ^ (long)1991141092);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)199615214 ^ (long)199615074);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-2026627378 ^ (long)-2026627564);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-271719956 ^ (long)-271719979);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-572834528 ^ (long)-572834541);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1579991991 ^ (long)-1579991944);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1076088095 ^ (long)-1076088158);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1980025936 ^ (long)-1980026029);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1512100589 ^ (long)-1512100549);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1919743420 ^ (long)-1919743451);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)150725923 ^ (long)150725960);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1383302815 ^ (long)1383302894);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1719760230 ^ (long)-1719760200);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)571001265 ^ (long)571001204);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1079369330 ^ (long)1079369385);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-215294051 ^ (long)-215294068);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-404436530 ^ (long)-404436581);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1098329322 ^ (long)-1098329206);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)171808614 ^ (long)171808521);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1657896341 ^ (long)1657896382);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1669936458 ^ (long)1669936604);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1212230067 ^ (long)-1212229937);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-131651754 ^ (long)-131651690);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-583225286 ^ (long)-583225204);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-2007800443 ^ (long)-2007800506);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1349911012 ^ (long)-1349911028);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)797223460 ^ (long)797223573);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)731631888 ^ (long)731631977);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1115279262 ^ (long)-1115279187);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)328109389 ^ (long)328109329);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1584311765 ^ (long)1584311802);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)999959746 ^ (long)999959689);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-2057530880 ^ (long)-2057530631);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-155935086 ^ (long)-155935073);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-713320975 ^ (long)-713321201);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-473817991 ^ (long)-473817936);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-918369199 ^ (long)-918369123);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1391942482 ^ (long)-1391942623);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)40806123 ^ (long)40805998);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1608288023 ^ (long)-1608288163);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)848112269 ^ (long)848112373);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1404052953 ^ (long)1404052744);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-274933108 ^ (long)-274933010);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1645748675 ^ (long)1645748706);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1902474332 ^ (long)-1902474308);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-2089971131 ^ (long)-2089971081);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1719024185 ^ (long)1719024265);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-356586782 ^ (long)-356586830);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)2012879844 ^ (long)2012879618);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-513206453 ^ (long)-513206517);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1193527224 ^ (long)1193527119);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1031378622 ^ (long)-1031378433);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1453108929 ^ (long)1453108789);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1646437556 ^ (long)-1646437629);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1141741925 ^ (long)-1141741862);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-2138389568 ^ (long)-2138389533);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1837185773 ^ (long)1837185605);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1295842194 ^ (long)-1295842301);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)310458501 ^ (long)310458472);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1324679119 ^ (long)1324679146);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)677487758 ^ (long)677487645);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-422573433 ^ (long)-422573458);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-542053993 ^ (long)-542053938);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)54221028 ^ (long)54221018);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)995084529 ^ (long)995084368);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1039998636 ^ (long)1039998687);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1387967353 ^ (long)-1387967302);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)715360724 ^ (long)715360591);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)511812124 ^ (long)511812338);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1376232109 ^ (long)-1376232021);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1432823826 ^ (long)-1432823817);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)866302905 ^ (long)866302931);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-465417326 ^ (long)-465417225);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1985362537 ^ (long)-1985362622);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)627607024 ^ (long)627606999);
                    if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1998579973 ^ (long)-1998580173);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1355653988 ^ (long)-1355654045)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)568882432 ^ (long)568888063)) >>> (int)((long)672187300 ^ (long)672187308)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1324309803 ^ (long)1324309803);
            if (!ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-41014866 ^ (long)-41014868);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1033457022 ^ (long)-1033457023) | var5_6 << (int)((long)1840813778 ^ (long)1840813783)) ^ var3_4[var7_8]) & (int)((long)-1433102449 ^ (long)-1433102480);
                    if (ClientTweaker.\u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-536572467 ^ (long)-536572466) | var6_7 << (int)((long)-78374816 ^ (long)-78374811)) ^ var3_4[var7_8]) & (int)((long)-394700217 ^ (long)-394700104);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            ClientTweaker.c[var2_3] = new String(var3_4).intern();
        }
        return ClientTweaker.c[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public ClientTweaker() {
        boolean bl = \u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005;
        if (bl) {
            return;
        }
    }

    public static String[] 9() {
        boolean bl = \u200b\u200a\u2008\u2007\u2004\u2001\u2005\u2005;
        if (bl) {
            return null;
        }
        return 2;
    }
}

