/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  baritone.api.BaritoneAPI
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import baritone.api.BaritoneAPI;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.2w$6X;
import net.impactclient.34R;
import net.impactclient.3X;
import net.impactclient.4f;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0_
extends 3X
implements 34R {
    private static final String[] e;
    @EventHandler
    private final Listener<4f> 0;
    public static final boolean \u200c\u2008;
    private static final String[] d;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0_.\u200c\u2008;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)882511463 ^ (long)882530609)) & (int)((long)-1757886037 ^ (long)-1757923756);
            if (var9_2) ** GOTO lbl-1000
            if (0_.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0_.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)201669312 ^ (long)201669312)] & (int)((long)363002745 ^ (long)363002758)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1495860816 ^ (long)1495860871);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1405875100 ^ (long)1405875037);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-996678406 ^ (long)-996678521);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1100888243 ^ (long)-1100888286);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1049019193 ^ (long)-1049019180);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)342378285 ^ (long)342378284);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)603941688 ^ (long)603941861);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)2002962311 ^ (long)2002962423);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1297346098 ^ (long)-1297346204);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)735986365 ^ (long)735986389);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1137283888 ^ (long)-1137284056);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1139825121 ^ (long)-1139824998);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-141854045 ^ (long)-141853969);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-708097273 ^ (long)-708097213);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)831358479 ^ (long)831358569);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-572871603 ^ (long)-572871620);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-755970579 ^ (long)-755970680);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1717623143 ^ (long)1717623145);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-704190003 ^ (long)-704190177);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1029836623 ^ (long)-1029836569);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-958393268 ^ (long)-958393154);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1485604721 ^ (long)1485604668);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1112753074 ^ (long)-1112753055);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1378699756 ^ (long)1378699635);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)770670712 ^ (long)770670756);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)843299698 ^ (long)843299765);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1067195841 ^ (long)-1067195664);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1337509106 ^ (long)1337508937);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1691647973 ^ (long)-1691647787);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1264464575 ^ (long)-1264464391);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1122892680 ^ (long)-1122892665);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-828042574 ^ (long)-828042597);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1241349752 ^ (long)-1241349731);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1582682967 ^ (long)-1582682951);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1391760267 ^ (long)1391760149);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1124728322 ^ (long)1124728527);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-765871343 ^ (long)-765871322);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-514773723 ^ (long)-514773507);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1839333 ^ (long)1839168);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1170900030 ^ (long)-1170900031);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-67758789 ^ (long)-67758763);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-799438596 ^ (long)-799438724);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-34560538 ^ (long)-34560663);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1604816896 ^ (long)1604816948);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-114702654 ^ (long)-114702797);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1692585451 ^ (long)-1692585230);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1952603093 ^ (long)-1952602979);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)5911009 ^ (long)5910994);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-909618354 ^ (long)-909618201);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1039670814 ^ (long)-1039670923);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1703480149 ^ (long)1703480284);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1625527794 ^ (long)1625527772);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1413175967 ^ (long)-1413175931);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1397678628 ^ (long)-1397678604);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-231543127 ^ (long)-231543220);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)259331522 ^ (long)259331357);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1107289961 ^ (long)-1107289875);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-288902868 ^ (long)-288902890);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1880480691 ^ (long)-1880480531);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1532312326 ^ (long)1532312541);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)360511108 ^ (long)360511069);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1358877497 ^ (long)-1358877634);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1254609290 ^ (long)1254609322);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1658467560 ^ (long)-1658467381);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-824682561 ^ (long)-824682628);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-687959906 ^ (long)-687959822);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1826028719 ^ (long)-1826028695);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)14278322 ^ (long)14278146);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-829511181 ^ (long)-829511323);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1361502420 ^ (long)1361502255);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)971813672 ^ (long)971813723);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1262172259 ^ (long)1262172303);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1807335058 ^ (long)-1807335088);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-556446801 ^ (long)-556446910);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-919950694 ^ (long)-919950811);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1986041170 ^ (long)1986041111);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-595999894 ^ (long)-595999789);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1356902183 ^ (long)1356902383);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)833622102 ^ (long)833622141);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1151271017 ^ (long)1151270984);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-404431378 ^ (long)-404431367);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-795714792 ^ (long)-795714744);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1183421215 ^ (long)-1183421376);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)832570823 ^ (long)832570759);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-391232749 ^ (long)-391232515);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1077789398 ^ (long)-1077789392);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)210282922 ^ (long)210282932);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1059784272 ^ (long)1059784265);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-370592924 ^ (long)-370592919);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-345264393 ^ (long)-345264515);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1580704223 ^ (long)1580704120);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)2103672759 ^ (long)2103672741);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1695088036 ^ (long)-1695087903);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1522845857 ^ (long)-1522845881);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)287157237 ^ (long)287157100);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)317955631 ^ (long)317955753);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1638918 ^ (long)1638949);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1720946588 ^ (long)1720946479);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1551676350 ^ (long)-1551676394);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1043009293 ^ (long)1043009332);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)824828791 ^ (long)824828900);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1564584947 ^ (long)-1564584917);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)154358676 ^ (long)154358644);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1297167256 ^ (long)-1297167218);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-442180874 ^ (long)-442181120);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)953731387 ^ (long)953731420);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1909028112 ^ (long)1909028218);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-323184596 ^ (long)-323184476);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1135954596 ^ (long)1135954569);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1063195816 ^ (long)-1063195899);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)936414077 ^ (long)936413986);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)311257827 ^ (long)311257711);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)226766416 ^ (long)226766555);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1653623589 ^ (long)-1653623751);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)757834009 ^ (long)757834064);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1737434521 ^ (long)-1737434469);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-911690190 ^ (long)-911690190);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1045910074 ^ (long)-1045910079);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-870417623 ^ (long)-870417621);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1677031745 ^ (long)-1677031682);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-47246284 ^ (long)-47246113);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1640665822 ^ (long)-1640665653);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1354397482 ^ (long)1354397661);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-74661333 ^ (long)-74661313);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)434197421 ^ (long)434197324);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)843343036 ^ (long)843342992);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1311224377 ^ (long)-1311224417);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)808690051 ^ (long)808690007);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-197444070 ^ (long)-197443938);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1665309782 ^ (long)1665309820);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-520650798 ^ (long)-520650826);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-624707891 ^ (long)-624707918);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)502875821 ^ (long)502875703);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)2030277794 ^ (long)2030277735);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1282899392 ^ (long)-1282899450);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)2126592817 ^ (long)2126592782);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1943825818 ^ (long)1943825700);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)2057298034 ^ (long)2057297968);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1735491073 ^ (long)-1735491237);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1810173007 ^ (long)-1810173179);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1314132056 ^ (long)1314132037);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-895934378 ^ (long)-895934308);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)183191770 ^ (long)183191774);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1757558907 ^ (long)1757559032);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-762655010 ^ (long)-762655119);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)20840780 ^ (long)20840938);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-28313402 ^ (long)-28313449);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-682903571 ^ (long)-682903638);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-821406031 ^ (long)-821406048);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-736436453 ^ (long)-736436384);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-622310436 ^ (long)-622310420);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)747538398 ^ (long)747538385);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)706791498 ^ (long)706791579);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-711470813 ^ (long)-711470806);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)185055654 ^ (long)185055496);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1768898100 ^ (long)-1768898201);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1443399694 ^ (long)1443399931);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)230267902 ^ (long)230267866);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1396142424 ^ (long)1396142382);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-2028556439 ^ (long)-2028556413);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1165845156 ^ (long)1165845199);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-939526339 ^ (long)-939526297);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-758229320 ^ (long)-758229372);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1229881673 ^ (long)1229881655);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-93201967 ^ (long)-93202175);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)465810046 ^ (long)465810036);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-127333102 ^ (long)-127332977);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-886337890 ^ (long)-886337942);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1465524334 ^ (long)-1465524480);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-966563109 ^ (long)-966563213);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)842799899 ^ (long)842799945);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)55340816 ^ (long)55340869);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-91789492 ^ (long)-91789449);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1831379997 ^ (long)-1831379995);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-585132062 ^ (long)-585132034);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1139590290 ^ (long)-1139590368);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1152805839 ^ (long)1152805716);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1597900262 ^ (long)-1597900115);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)123995905 ^ (long)123996097);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1929370474 ^ (long)-1929370496);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)2059322943 ^ (long)2059323129);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1881161235 ^ (long)1881161346);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)432613720 ^ (long)432613737);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1989674723 ^ (long)1989674650);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)631181017 ^ (long)631180984);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1335805964 ^ (long)-1335806180);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)827773188 ^ (long)827773415);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)248168288 ^ (long)248168277);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1500447105 ^ (long)-1500447062);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1883216700 ^ (long)-1883216689);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)204510842 ^ (long)204510958);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)306992893 ^ (long)306992797);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-2123562940 ^ (long)-2123562754);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1399975254 ^ (long)-1399975415);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1885265399 ^ (long)-1885265364);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-846659299 ^ (long)-846659270);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)427037921 ^ (long)427037773);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1222268980 ^ (long)-1222269019);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-268340967 ^ (long)-268340923);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1191900167 ^ (long)-1191900412);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-792368699 ^ (long)-792368728);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1133105166 ^ (long)1133105158);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1350989578 ^ (long)-1350989711);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-446131398 ^ (long)-446131232);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1577782542 ^ (long)1577782725);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1015820367 ^ (long)-1015820531);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1717246733 ^ (long)1717246842);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-2087013771 ^ (long)-2087013879);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1033637040 ^ (long)-1033637018);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)353665255 ^ (long)353665125);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1322343776 ^ (long)1322343807);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1967611132 ^ (long)-1967610959);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-24688446 ^ (long)-24688385);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)818295432 ^ (long)818295372);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)971951853 ^ (long)971951724);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)818190166 ^ (long)818190101);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)775523988 ^ (long)775524070);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)717400500 ^ (long)717400571);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1748016991 ^ (long)-1748017103);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1504711532 ^ (long)1504711589);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1158773014 ^ (long)1158773179);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-705213107 ^ (long)-705212989);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-203355814 ^ (long)-203355903);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)2043428021 ^ (long)2043428033);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1376629121 ^ (long)1376629017);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)28938202 ^ (long)28938025);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1190113159 ^ (long)-1190113156);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1384827637 ^ (long)-1384827522);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1964022207 ^ (long)1964022215);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-218431397 ^ (long)-218431327);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-212752128 ^ (long)-212752101);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1003972233 ^ (long)-1003972283);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1080991370 ^ (long)-1080991261);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-324848888 ^ (long)-324848648);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-372552040 ^ (long)-372552122);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)755799352 ^ (long)755799348);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)475190914 ^ (long)475191008);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1147637864 ^ (long)-1147637808);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1394710479 ^ (long)-1394710400);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1492243416 ^ (long)1492243329);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)342533030 ^ (long)342532884);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-659087110 ^ (long)-659087183);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1112525815 ^ (long)-1112525577);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)121417909 ^ (long)121417942);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-2078899425 ^ (long)-2078899325);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1694229433 ^ (long)1694229300);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1526986970 ^ (long)-1526986807);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)425448866 ^ (long)425448936);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)638130864 ^ (long)638130915);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)127136152 ^ (long)127136090);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1290475635 ^ (long)-1290475558);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1062948079 ^ (long)1062948017);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-241132925 ^ (long)-241132977);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1472967241 ^ (long)-1472967275);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-974703110 ^ (long)-974703272);
                    if (!0_.\u200c\u2008) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1498988873 ^ (long)-1498988959);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1732935997 ^ (long)-1732936132)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)418514701 ^ (long)418576626)) >>> (int)((long)-1280981709 ^ (long)-1280981701)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-140401913 ^ (long)-140401913);
            if (!0_.\u200c\u2008) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1202897743 ^ (long)1202897741);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)947703023 ^ (long)947703020) | var5_6 << (int)((long)2001601202 ^ (long)2001601207)) ^ var3_4[var7_8]) & (int)((long)-317026341 ^ (long)-317026524);
                    if (0_.\u200c\u2008) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)527141284 ^ (long)527141287) | var6_7 << (int)((long)-733087332 ^ (long)-733087335)) ^ var3_4[var7_8]) & (int)((long)160164177 ^ (long)160164270);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0_.e[var2_3] = new String(var3_4).intern();
        }
        return 0_.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        block3: {
            block2: {
                boolean bl = \u200c\u2008;
                if (bl || bl) break block2;
                BaritoneAPI.getProvider().getPrimaryBaritone().getFarmProcess().farm();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u200c\u2008;
                if (bl || bl) break block2;
                BaritoneAPI.getProvider().getPrimaryBaritone().getFarmProcess().onLostControl();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 0_.\u200c\u2008;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)1417352781 ^ (long)1417352783)];
            if (var7) break block16;
            var3_2 = (int)((long)-1278610007 ^ (long)-1278610007);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u3bfa\u13bc-\u087f\u3bc5\u1381\u00c9\u08d1\u3be1\u133f)\u0828\u3b4c\u134eR\u08da\u3b56\u1385\u00c0\u08f4\u3b4f\u139b\u00a5\u08fb\u3bcc\u1335\u001e\u085e\u3b24\u13af \u0814\u3b9d\u13d9K\u0836\u3b62\u13cf\u00b9\u088d\u3b87\u1377\u00ba\u08a9\u3b84\u1335\u0084\u0894\u3b18\u1364\u0011\u0885\u3b96\u134fZ\u0825\u3b4f\u139d;\u088e\u3b4a\u13b6\u00c9\u084a\u3b47\u133a\u00d6\u0858\u3bfd\u13bc\u00a9\u0884\u3b47\u134a\u00a2\u0883\u3b3d\u13210\u085c\u3ba8\u1341\u00b8\u087a\u3b70\u13e72\u0856\u3b1f\u139d\u00df\u0827\u3b8d\u136fl\u0814\u3b14\u1360\u00ee\u08b0\u3bc0\u13a7z\u0893\u3b17\u1351w\u082e\u3b58\u13efV\u0805\u3bff\u13f6\u00d5\u084d\u3b74\u1334\u0091\u08b9\u3b22\u1349\u0088\u083e\u3b8d\u1332\u001b\u085b\u3b17\u13dd\u00cf\u08b9\u3b4a\u13df\u0002\u08c4\u3b8c\u1361\u00b3\u089a\u3b37\u13de\u00f8\u08f7\u3bac\u13a2\u00c7", -144630335);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)-1990300747 ^ (long)-1990300868);
            if (var7) break block16;
            var0_6 = (int)((long)1105444434 ^ (long)-1105444435);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-1512574658 ^ (long)1512574657);
                if (0_.\u200c\u2008) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!0_.\u200c\u2008) continue block8;
                            throw null;
                        }
                        0_.d = var5_1;
                        0_.e = new String[(int)((long)89036950 ^ (long)89036948)];
                        if (!0_.\u200c\u2008) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)-873079982 ^ (long)-873079982);
                v5 = (int)((long)-351312372 ^ (long)-351312371);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)683712875 ^ (long)683712874)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1596860878 ^ (long)1596860873)) {
                                case 0: {
                                    v12 = (int)((long)-2047037655 ^ (long)-2047037695);
                                    if (!0_.\u200c\u2008) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)-215472753 ^ (long)-215472706);
                                    if (!0_.\u200c\u2008) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)452334240 ^ (long)452334284);
                                    if (!0_.\u200c\u2008) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)-1073157281 ^ (long)-1073157367);
                                    if (!0_.\u200c\u2008) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)-68887749 ^ (long)-68887692);
                                    if (!0_.\u200c\u2008) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)1983109163 ^ (long)1983109157);
                                    if (!0_.\u200c\u2008) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)824445344 ^ (long)824445322);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!0_.\u200c\u2008);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!0_.\u200c\u2008) ** continue;
                throw null;
            }
        }
    }

    public 0_() {
        boolean bl = \u200c\u2008;
        super(0_.b((int)((long)-683024135 ^ (long)-683034706), (int)((long)-148375834 ^ (long)0x8D86686)), 0_.b((int)((long)-1660528431 ^ (long)-1660547193), (int)((long)1241109915 ^ (long)1241099118)) /* "Automatically bonemeals, harvests, and replants crops\\nWheat, Carrots, Potatoes, Beetroot, Pumpkin, Melon, Nether Wart, Sugar Cane, Cactus" */);
        this.0 = new Listener(f -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u200c\u2008;
                        if (bl || bl) break block2;
                        if (BaritoneAPI.getProvider().getPrimaryBaritone().getFarmProcess().isActive()) break block3;
                        if (bl || bl) break block2;
                        this.1((boolean)((long)-811411752 ^ (long)-811411752));
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-1191797284 ^ (long)-1191797284)]);
    }
}

