/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dzm
 *  me.zero.alpine.event.EventState
 */
package net.impactclient;

import clientapi.load.mixin.7.2;
import me.zero.alpine.event.EventState;
import net.impactclient.2w$6X;
import net.impactclient.3sp;
import net.impactclient.4e;
import net.impactclient.8S;
import net.impactclient.9V;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 4X
extends 4e
implements 3sp {
    public boolean 1;
    private static final String[] b;
    public static final boolean \u2003\u2002;
    public 8S 2;
    public final EventState 7;
    public 9V 8;
    private static final String[] a;

    public final String toString() {
        boolean bl = \u2003\u2002;
        if (bl || bl) {
            return null;
        }
        return 4X.a((int)((long)2108766240 ^ (long)-2108776229), (int)((long)1288918452 ^ (long)1288926115)) /* "MotionUpdateEvent{pos=" */ + this.2 + 4X.a((int)((long)311163245 ^ (long)-311139948), (int)((long)-1009889156 ^ (long)1009885347)) /* ", rotations=" */ + this.8 + 4X.a((int)((long)-1011491506 ^ (long)1011500470), (int)((long)-1290613616 ^ (long)-1290607191)) /* ", onGround=" */ + this.1 + 4X.a((int)((long)310778588 ^ (long)-310803930), (int)((long)-496892503 ^ (long)-496873885)) /* ", type=" */ + this.7 + (char)((long)1187992629 ^ (long)1187992648);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final 4X 2(float f) {
        block3: {
            block2: {
                boolean bl = \u2003\u2002;
                if (bl || bl) break block2;
                this.8.3 = f;
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final 4X 9(double d2) {
        block3: {
            block2: {
                boolean bl = \u2003\u2002;
                if (bl || bl) break block2;
                this.2.1 = d2;
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return this;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 4X.\u2003\u2002;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1366562340 ^ (long)1366562336)];
            if (var7) break block23;
            var3_2 = (int)((long)593301649 ^ (long)593301649);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u7ae9\u52b2\u4144\u496f\u7a61\u5266\u41fa\u4937\u7a69\u522e\u4138\u4903\u7aee\u52e0\u4126\u49f5\u7a59\u52d1\u4114\u4985\u7a47\u5242\u41c1\u4935\u7abe\u52ac\u4103\u49f1\u7a05\u5242", 1526553715);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)786264106 ^ (long)786264124);
            if (var7) break block23;
            var0_6 = (int)((long)1617163407 ^ (long)-1617163408);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1391824290 ^ (long)-1391824383);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-796410430 ^ (long)796410429);
                    if (4X.\u2003\u2002) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!4X.\u2003\u2002) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u0cb7\u24c2\u3746\u3f43\u0c7e\u24a8\u37c2\u3f9b\u0ce2\u240c\u37a6\u3f73\u0c4f\u24af\u37de\u3f03\u0c53\u24ac\u37a6\u3f8d\u0ca5\u2485\u3760\u3f7e", 1804544660);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)176420530 ^ (long)176420542);
                            var0_6 = (int)((long)-1964824780 ^ (long)1964824779);
                            while (true) {
                                v0 = (int)((long)-1032679866 ^ (long)-1032679826);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)2081481875 ^ (long)2081481875);
                                if (!4X.\u2003\u2002) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!4X.\u2003\u2002) ** continue;
                                throw null;
                            }
                            4X.a = var5_1;
                            4X.b = new String[(int)((long)1461918424 ^ (long)1461918428)];
                            if (!4X.\u2003\u2002) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-535001639 ^ (long)-535001639);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)2082695915 ^ (long)2082695914)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1200111015 ^ (long)1200111008)) {
                                case 0: {
                                    v15 = (int)((long)2115250732 ^ (long)2115250803);
                                    if (!4X.\u2003\u2002) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1504298385 ^ (long)1504298463);
                                    if (!4X.\u2003\u2002) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)2077646378 ^ (long)2077646382);
                                    if (!4X.\u2003\u2002) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1947270215 ^ (long)1947270145);
                                    if (!4X.\u2003\u2002) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-803333327 ^ (long)-803333374);
                                    if (!4X.\u2003\u2002) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1452858701 ^ (long)1452858652);
                                    if (!4X.\u2003\u2002) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1871530836 ^ (long)-1871530803);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!4X.\u2003\u2002);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 4X.\u2003\u2002;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-915935407 ^ (long)915961770)) & (int)((long)-946170498 ^ (long)-946181503);
            if (var9_2) ** GOTO lbl-1000
            if (4X.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 4X.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1144795997 ^ (long)1144795997)] & (int)((long)-2057480827 ^ (long)-2057480838)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1994213255 ^ (long)-1994213142);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1448027947 ^ (long)1448028063);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-108477576 ^ (long)-108477468);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)632557323 ^ (long)632557529);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-2035013499 ^ (long)-2035013388);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1504842264 ^ (long)1504842371);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1414247985 ^ (long)1414248188);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-508581077 ^ (long)-508581036);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1151987575 ^ (long)-1151987571);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)2048480878 ^ (long)2048480929);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)952735597 ^ (long)952735599);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-238287804 ^ (long)-238287871);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)86781424 ^ (long)86781332);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)2066772625 ^ (long)2066772600);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-914706607 ^ (long)-914706560);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1449532811 ^ (long)-1449532710);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-825439453 ^ (long)-825439479);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)773779386 ^ (long)773779393);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-754018696 ^ (long)-754018695);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)532075152 ^ (long)532075069);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)932842176 ^ (long)932842116);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)351407843 ^ (long)351407706);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1553129937 ^ (long)-1553129766);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-522438594 ^ (long)-522438479);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-257067053 ^ (long)-257067023);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1869234632 ^ (long)1869234677);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)577107565 ^ (long)577107671);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-265167392 ^ (long)-265167594);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)751729249 ^ (long)751729347);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)378394538 ^ (long)378394454);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-2074976066 ^ (long)-2074976086);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1146802322 ^ (long)-1146802333);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)339774504 ^ (long)339774588);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1484262938 ^ (long)1484263107);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-52983 ^ (long)-52786);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1266528882 ^ (long)-1266528773);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1468823283 ^ (long)1468823079);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)36616036 ^ (long)36616039);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1996031107 ^ (long)-1996031163);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1249050365 ^ (long)-1249050326);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)2134625214 ^ (long)2134625081);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1502955648 ^ (long)1502955705);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1889258188 ^ (long)-1889257987);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-905520074 ^ (long)-905519898);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1603103902 ^ (long)-1603103899);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1105731944 ^ (long)1105732045);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)470991341 ^ (long)470991334);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-286423483 ^ (long)-286423386);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1878941170 ^ (long)1878941114);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-192169870 ^ (long)-192169947);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-313430260 ^ (long)-313430080);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)772823989 ^ (long)772823958);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-2036257269 ^ (long)-2036257127);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1553970119 ^ (long)-1553970055);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1902342685 ^ (long)1902342747);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-478052954 ^ (long)-478052936);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)999351579 ^ (long)999351798);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)2121597696 ^ (long)2121597857);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1725177001 ^ (long)1725177061);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)32258733 ^ (long)32258669);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-986895676 ^ (long)-986895628);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1192113120 ^ (long)1192112911);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1466008455 ^ (long)-1466008562);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1580437446 ^ (long)-1580437250);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1039959895 ^ (long)-1039959949);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1584384136 ^ (long)1584384159);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1953196220 ^ (long)-1953196109);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)28797163 ^ (long)28796989);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)365677710 ^ (long)365677719);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-741695564 ^ (long)-741695601);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)976179760 ^ (long)976179950);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-261682320 ^ (long)-261682215);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)2117648472 ^ (long)2117648582);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)364143675 ^ (long)364143661);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)306695688 ^ (long)306695704);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)700849947 ^ (long)700850097);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-240632753 ^ (long)-240632584);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)2136466164 ^ (long)2136466118);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1179371186 ^ (long)-1179371180);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1809682436 ^ (long)-1809682545);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)871190933 ^ (long)871190898);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1216777686 ^ (long)1216777642);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1271173315 ^ (long)-1271173348);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)27749780 ^ (long)27749849);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1381972024 ^ (long)1381972018);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1092850245 ^ (long)1092850356);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1702632797 ^ (long)1702632730);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-639904195 ^ (long)-639904127);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1814954938 ^ (long)1814954914);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)2005687726 ^ (long)2005687660);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)2139286892 ^ (long)2139286798);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)532201212 ^ (long)532201212);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-334641878 ^ (long)-334641816);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1916782633 ^ (long)1916782828);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)522331432 ^ (long)522331517);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1179241877 ^ (long)-1179241800);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)50013894 ^ (long)50013921);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1049618084 ^ (long)-1049618045);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)76472460 ^ (long)76472556);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)8048333 ^ (long)8048165);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1715810568 ^ (long)1715810621);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1302872902 ^ (long)1302873041);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1938835587 ^ (long)-1938835621);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)565545618 ^ (long)565545693);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-846770696 ^ (long)-846770711);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)69074785 ^ (long)69074842);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1952347934 ^ (long)-1952347991);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)576449620 ^ (long)576449733);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-234271368 ^ (long)-234271456);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-993128266 ^ (long)-993128394);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1174591816 ^ (long)1174591928);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1726347865 ^ (long)1726347880);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1670071514 ^ (long)1670071430);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)858116329 ^ (long)858116309);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-93788083 ^ (long)-93788140);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)677166146 ^ (long)677166143);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1557738671 ^ (long)-1557738689);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)583111883 ^ (long)583111847);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1820915732 ^ (long)1820915857);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1816271886 ^ (long)1816272116);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)213074897 ^ (long)213074874);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1253425686 ^ (long)1253425736);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1170527207 ^ (long)-1170527091);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)74516886 ^ (long)74516828);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)644572310 ^ (long)644572201);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1377562168 ^ (long)1377562133);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1924329355 ^ (long)1924329331);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-196852136 ^ (long)-196852044);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-99059886 ^ (long)-99059890);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-2129279421 ^ (long)-2129279296);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)82000646 ^ (long)82000802);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1425757208 ^ (long)1425757319);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-368103170 ^ (long)-368103223);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)736445987 ^ (long)736446176);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1690753086 ^ (long)1690753037);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)2104112771 ^ (long)2104112796);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-621009724 ^ (long)-621009753);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)2102811992 ^ (long)2102812045);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-460406567 ^ (long)-460406678);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)776502593 ^ (long)776502769);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1138265955 ^ (long)-1138265879);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)265376159 ^ (long)265376242);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-349427955 ^ (long)-349427913);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-734668851 ^ (long)-734668914);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-188441846 ^ (long)-188441775);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1383279433 ^ (long)-1383279505);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-273445415 ^ (long)-273445423);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-96261426 ^ (long)-96261466);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-489460463 ^ (long)-489460316);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)906232510 ^ (long)906232520);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1015115904 ^ (long)-1015115875);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1013642167 ^ (long)-1013642040);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1862806709 ^ (long)1862806760);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-810232249 ^ (long)-810232259);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-246738575 ^ (long)-246738484);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1114544745 ^ (long)-1114544735);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-650183386 ^ (long)-650183382);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-432116983 ^ (long)-432116808);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1358557575 ^ (long)1358557602);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)618145333 ^ (long)618145513);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1332842952 ^ (long)-1332842965);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1037905321 ^ (long)1037905384);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-364085016 ^ (long)-364085103);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-139473637 ^ (long)-139473650);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-116534464 ^ (long)-116534512);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)65404111 ^ (long)65404073);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-548516184 ^ (long)-548516262);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-920326666 ^ (long)-920326696);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1799257464 ^ (long)1799257509);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-539381999 ^ (long)-539381955);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1016395049 ^ (long)1016395047);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-54564764 ^ (long)-54564861);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1400781704 ^ (long)1400781676);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1833691687 ^ (long)1833691783);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1326943179 ^ (long)-1326943181);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)716107645 ^ (long)716107631);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)977908400 ^ (long)977908232);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1643291558 ^ (long)1643291443);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)454639816 ^ (long)454639715);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)315065122 ^ (long)315065272);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1015725898 ^ (long)1015726034);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1330618953 ^ (long)1330618912);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)633998398 ^ (long)633998512);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-657812624 ^ (long)-657812656);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-954503767 ^ (long)-954503839);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-375544283 ^ (long)-375544288);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1272883504 ^ (long)1272883595);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-70848372 ^ (long)-70848404);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)888023493 ^ (long)888023401);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1643151992 ^ (long)-1643152011);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1569420990 ^ (long)-1569421045);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1211577495 ^ (long)-1211577376);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1327662382 ^ (long)-1327662432);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)802390866 ^ (long)802390940);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1507514233 ^ (long)1507514367);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-864226684 ^ (long)-864226766);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)877195287 ^ (long)877195353);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1587229250 ^ (long)1587229213);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)37979907 ^ (long)37980130);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1082763313 ^ (long)-1082763484);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-138259123 ^ (long)-138259132);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-999828567 ^ (long)-999828649);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)905013865 ^ (long)905013959);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1038954850 ^ (long)1038954845);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-500874132 ^ (long)-500874222);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1665175969 ^ (long)-1665175945);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1465950293 ^ (long)1465950405);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1420839163 ^ (long)-1420838916);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)815750696 ^ (long)815750894);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-241482705 ^ (long)-241482567);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1640683052 ^ (long)-1640683087);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1945098482 ^ (long)1945098330);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-2069291538 ^ (long)-2069291684);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1679663045 ^ (long)1679662947);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-2042924411 ^ (long)-2042924305);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1991453180 ^ (long)1991452983);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1781526092 ^ (long)1781526209);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1730627733 ^ (long)1730627707);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1512410434 ^ (long)-1512410536);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1810919616 ^ (long)1810919466);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1555469900 ^ (long)-1555470017);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)677440757 ^ (long)677440666);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1242046727 ^ (long)1242046949);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1294167474 ^ (long)-1294167375);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)124736870 ^ (long)124736812);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)2002483631 ^ (long)2002483493);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-629720025 ^ (long)-629719824);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1154820656 ^ (long)1154820777);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1328798336 ^ (long)1328798388);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1648341242 ^ (long)-1648341130);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)759558872 ^ (long)759558798);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)684058111 ^ (long)684058049);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1121831847 ^ (long)1121831738);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1354612614 ^ (long)1354612517);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)2001779433 ^ (long)2001779442);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)967579671 ^ (long)967579817);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-402621936 ^ (long)-402621707);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)771425738 ^ (long)771425598);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)145211156 ^ (long)145211286);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1500822283 ^ (long)-1500822482);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1089067997 ^ (long)1089067857);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1804092490 ^ (long)1804092485);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1419093758 ^ (long)1419093677);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1376741021 ^ (long)1376741049);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-2098125290 ^ (long)-2098125255);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1823564099 ^ (long)1823564208);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-543284317 ^ (long)-543284437);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-466092986 ^ (long)-466092831);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1999403003 ^ (long)-1999402962);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)586436546 ^ (long)586436422);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1142982007 ^ (long)-1142981928);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1288746288 ^ (long)1288746346);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-487142095 ^ (long)-487142045);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)2013883809 ^ (long)2013883865);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)2000596989 ^ (long)2000596796);
                    if (!4X.\u2003\u2002) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)233488323 ^ (long)233488290);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1182942658 ^ (long)1182942525)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1460531416 ^ (long)1460473639)) >>> (int)((long)742927982 ^ (long)742927974)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)2064189979 ^ (long)2064189979);
            if (!4X.\u2003\u2002) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-392682220 ^ (long)-392682218);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1981309941 ^ (long)-1981309944) | var5_6 << (int)((long)-428251045 ^ (long)-428251042)) ^ var3_4[var7_8]) & (int)((long)-713989579 ^ (long)-713989430);
                    if (4X.\u2003\u2002) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-926280582 ^ (long)-926280583) | var6_7 << (int)((long)-145524308 ^ (long)-145524311)) ^ var3_4[var7_8]) & (int)((long)365231889 ^ (long)365232110);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            4X.b[var2_3] = new String(var3_4).intern();
        }
        return 4X.b[var2_3];
    }

    public 4X(dzm dzm2, EventState object) {
        boolean bl = \u2003\u2002;
        super(dzm2);
        this.2 = new 8S();
        this.8 = new 9V();
        this.7 = object;
        if (object == EventState.POST) {
            return;
        }
        object = (2)dzm2;
        Object object2 = object.getPos();
        Object object3 = this.2;
        this.2.9 = ((8S)object2).9;
        ((8S)object3).1 = ((8S)object2).1;
        ((8S)object3).2 = ((8S)object2).2;
        ((8S)object3).1 = dzm2.cc().b;
        object2 = object.getRotations();
        object3 = this.8;
        this.8.6 = ((9V)object2).6;
        ((9V)object3).3 = ((9V)object2).3;
        this.1 = dzm2.ao();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final 4X 6(float f) {
        block3: {
            block2: {
                boolean bl = \u2003\u2002;
                if (bl || bl) break block2;
                this.8.6 = f;
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return this;
    }
}

