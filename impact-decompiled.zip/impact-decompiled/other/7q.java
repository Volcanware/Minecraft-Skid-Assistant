/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  baritone.api.BaritoneAPI
 *  baritone.api.Settings$Setting
 *  baritone.api.event.events.PathEvent
 *  baritone.api.event.listener.AbstractGameEventListener
 *  baritone.api.event.listener.IGameEventListener
 *  baritone.api.pathing.goals.Goal
 *  baritone.api.pathing.goals.GoalBlock
 *  baritone.api.pathing.goals.GoalXZ
 *  k
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  nr
 */
package net.impactclient;

import baritone.api.BaritoneAPI;
import baritone.api.Settings;
import baritone.api.event.events.PathEvent;
import baritone.api.event.listener.AbstractGameEventListener;
import baritone.api.event.listener.IGameEventListener;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalBlock;
import baritone.api.pathing.goals.GoalXZ;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.06;
import net.impactclient.1P;
import net.impactclient.1m;
import net.impactclient.2w$6X;
import net.impactclient.34X;
import net.impactclient.34f;
import net.impactclient.3X;
import net.impactclient.3d;
import net.impactclient.3sC;
import net.impactclient.4C;
import net.impactclient.4f;
import net.impactclient.5i;
import net.impactclient.5p;
import net.impactclient.6s;
import net.impactclient.7m;
import net.impactclient.8j;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7q
extends 7m<06>
implements AbstractGameEventListener {
    private static final String[] b;
    private Float 4;
    private Goal 5;
    private 1P 2;
    @EventHandler
    private final Listener<4f> 7;
    private static final String[] a;
    private 1m<4C> 1;
    private 1P 6;
    public static final boolean \u2003\u200a\u2008;
    @EventHandler
    private final Listener<8j> 0;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2003\u200a\u2008;
                    if (bl || bl) break block2;
                    3d.2();
                    if (bl || bl) break block2;
                    if (7q.3.s == null) break block3;
                    if (bl || bl) break block2;
                    this.4 = Float.valueOf(7q.3.s.p);
                    if (bl || bl) break block2;
                    this.5();
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7q.\u2003\u200a\u2008;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)54019733 ^ (long)54019742)];
            if (var7) break block23;
            var3_2 = (int)((long)-205744838 ^ (long)-205744838);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ub340\u9a58\u8954\u81ce\ub328\u9af5\u8983\u814f\ub3b1\u9aeb\u897f\u8136\ub383\u9ac0\u8901\u81de\ub32e\u9a3c\u895b\u8139\ub327\u9a5d\u89e7\u81ee\ub3d8\u9a01\u89c1\u811d\ub323\u9a0f\u89a8\u81dc\ub398\u9a2f\u8993\u8166\ub3f7\u9ac6\u8912\u8148\ub3ed\u9a4b\u8989\u8113\ub3c5\u9ad6\u89c8\u811e\ub33a\u9ad1\u89d5\u8165\ub366\u9a92\u89d3\u8153\ub3b9\u9a8a\u891d\u8119\ub34d\u9aed\u89cd\u81a5\ub3ad\u9a44\u8981\u812b\ub3d7\u9a58\u89fa\u8164\ub354\u9a3e\u8955\u8139\ub3af\u9a7f\u896e\u81a0\ub3b3\u9a4c\u8929\u81e8\ub368\u9a07\u8972\u811c\ub3e7\u9a6e\u89eb\u811b\ub30b\u9aeb\u89f9\u81e6\ub3cf\u9ab7\u8900\u816b\ub3c1\u9a07\u8955\u81a8\ub354\u9a34\u89e8\u81fe\ub326\u9ab6\u89ff\u81a9\ub36d\u9a51\u89e3\u81af\ub3db\u9ad8\u8918\u81b5\ub372\u9a7a\u892b\u8126\ub38c\u9a4d\u89a7\u8157\ub3bf\u9ad3\u8971\u81ad\ub36c\u9a28\u8945\u81f8\ub3a4\u9aeb\u892f\u8141\ub37e\u9a34\u8940\u8194\ub301\u9ace\u89f5\u8127\ub3e3\u9ab4\u89d6\u81cb\ub3e5\u9a50\u8956\u81f2\ub308\u9a31\u890a\u813b\ub326\u9a01\u89b4\u8148\ub3f1\u9a94\u8971\u8198\ub3a8\u9a32\u895b", -1508338582);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1836938370 ^ (long)1836938374);
            if (var7) break block23;
            var0_6 = (int)((long)-582614788 ^ (long)582614787);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1506486094 ^ (long)1506486132);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)389481802 ^ (long)-389481803);
                    if (7q.\u2003\u200a\u2008) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7q.\u2003\u200a\u2008) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u3413\u1dae\u0e6d\u06ee\u34ea\u1da2\u0ebe\u0625\u3472\u1d7a\u0e39\u0660\u3478\u1dca\u0ee8\u063a\u347c\u1d05\u0e21\u0635\u3486\u1df5\u0ef6\u0693\u3482\u1d35\u0e98\u0669\u3469\u1db4\u0ea1\u06f8\u3405\u1dd2\u0ec2\u06cf\u344d\u1d44\u0e7b\u06e6\u344e\u1d6f\u0ec3\u0637\u3473\u1d4f\u0eb8\u06ab\u34c6\u1d7e\u0ea7\u068c\u34bb\u1d1e\u0ed4\u0615\u34be\u1d0e\u0ebc\u0611\u34a0\u1dc5\u0eaa\u06f8\u3458\u1dca\u0ebe\u06fa\u3425\u1dfb\u0e24\u0613\u346b\u1dd8\u0ecd\u060a\u34d7\u1d22\u0ef1\u0606\u34a3\u1d25\u0e28\u0643\u342e\u1dad\u0e0f\u0678\u346d\u1d6a\u0eb0\u0649\u34a0\u1d60\u0e1d\u064f\u3467\u1db2\u0eee\u0629\u3492\u1df4\u0e3a\u06c9\u348a\u1d98\u0eb1\u06ee\u3479\u1d52\u0e8c\u069c\u34b5\u1d3f\u0edd\u061f\u348d\u1d7d\u0e23\u0607\u34c7\u1dc2\u0e44\u0653\u3459\u1d20\u0e39\u06e4\u34db\u1dc0\u0e5a\u0643", -1711795319);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)1156042562 ^ (long)1156042556);
                            var0_6 = (int)((long)-1564329021 ^ (long)1564329020);
                            while (true) {
                                v0 = (int)((long)-1323274645 ^ (long)-1323274627);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1201499935 ^ (long)1201499935);
                                if (!7q.\u2003\u200a\u2008) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7q.\u2003\u200a\u2008) ** continue;
                                throw null;
                            }
                            7q.a = var5_1;
                            7q.b = new String[(int)((long)1945526023 ^ (long)1945526028)];
                            if (!7q.\u2003\u200a\u2008) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)514149765 ^ (long)514149765);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1137497265 ^ (long)-1137497266)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)2091700698 ^ (long)2091700701)) {
                                case 0: {
                                    v15 = (int)((long)-1508303138 ^ (long)-1508303125);
                                    if (!7q.\u2003\u200a\u2008) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-904670947 ^ (long)-904670904);
                                    if (!7q.\u2003\u200a\u2008) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1517448916 ^ (long)1517448843);
                                    if (!7q.\u2003\u200a\u2008) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-39877986 ^ (long)-39877962);
                                    if (!7q.\u2003\u200a\u2008) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-965796870 ^ (long)-965796885);
                                    if (!7q.\u2003\u200a\u2008) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1513865753 ^ (long)1513865755);
                                    if (!7q.\u2003\u200a\u2008) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1184991737 ^ (long)1184991680);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7q.\u2003\u200a\u2008);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    static /* synthetic */ 3X 6(7q q) {
        boolean bl = \u2003\u200a\u2008;
        if (bl || bl) {
            return null;
        }
        return q.8;
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 7q.\u2003\u200a\u2008;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1883414085 ^ (long)1883411421)) & (int)((long)-1073284652 ^ (long)-1073347029);
            if (var9_2) ** GOTO lbl-1000
            if (7q.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7q.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-976133839 ^ (long)-976133839)] & (int)((long)-924323955 ^ (long)-924323982)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1285706233 ^ (long)-1285706046);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1221635495 ^ (long)1221635437);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-316849328 ^ (long)-316849266);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1920093213 ^ (long)1920093310);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1593088281 ^ (long)-1593088418);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1344449378 ^ (long)1344449311);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)653809305 ^ (long)653809387);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-267506189 ^ (long)-267506423);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1620820392 ^ (long)1620820440);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1164885104 ^ (long)1164885027);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)596343917 ^ (long)596343985);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-724193854 ^ (long)-724193982);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1603947887 ^ (long)-1603947877);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1736748924 ^ (long)-1736748944);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)854731805 ^ (long)854731924);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)657578876 ^ (long)657578831);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-376398577 ^ (long)-376398446);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)857157923 ^ (long)857158059);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1016346375 ^ (long)-1016346574);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)985519092 ^ (long)985518995);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1757534950 ^ (long)1757534771);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1886780255 ^ (long)-1886780177);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1725430648 ^ (long)1725430681);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-2126862954 ^ (long)-2126862898);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1447535727 ^ (long)1447535790);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1660600890 ^ (long)-1660600860);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)28060512 ^ (long)28060661);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)29826177 ^ (long)29826063);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-932418229 ^ (long)-932418294);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1667283589 ^ (long)1667283591);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-905035732 ^ (long)-905035526);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)223192388 ^ (long)223192454);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1123594489 ^ (long)1123594337);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-675490218 ^ (long)-675490270);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)142018098 ^ (long)142018090);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1717757669 ^ (long)1717757653);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1230883841 ^ (long)-1230884005);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1145432098 ^ (long)1145432158);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1398308364 ^ (long)-1398308376);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1080546404 ^ (long)1080546436);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1078693683 ^ (long)1078693816);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)874091237 ^ (long)874091235);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1157025783 ^ (long)1157025689);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)2132185699 ^ (long)2132185826);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-2031915326 ^ (long)-2031915404);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-452773584 ^ (long)-452773425);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1766603714 ^ (long)1766603630);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1631413687 ^ (long)1631413552);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1208586082 ^ (long)1208586194);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-164347708 ^ (long)-164347725);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1686231876 ^ (long)-1686231934);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1806534931 ^ (long)-1806534926);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1619486299 ^ (long)-1619486394);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1891908429 ^ (long)1891908574);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1080983578 ^ (long)1080983611);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)218741343 ^ (long)218741294);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-246343898 ^ (long)-246343920);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-563161374 ^ (long)-563161374);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1565696507 ^ (long)1565696486);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-906827785 ^ (long)-906827923);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)50351556 ^ (long)50351500);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-51284542 ^ (long)-51284654);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1544357167 ^ (long)1544357238);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-490554884 ^ (long)-490555055);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)86715355 ^ (long)86715137);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1773448764 ^ (long)-1773448928);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)998643691 ^ (long)998643692);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)566044175 ^ (long)566044359);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1811146945 ^ (long)-1811146980);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1997350840 ^ (long)1997350786);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)235010520 ^ (long)235010509);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-888972564 ^ (long)-888972547);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1388187321 ^ (long)-1388187205);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1631478275 ^ (long)1631478364);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-706372526 ^ (long)-706372356);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1802017907 ^ (long)1802017867);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1773444860 ^ (long)-1773444852);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1082240842 ^ (long)-1082240800);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)715304995 ^ (long)715305108);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-502292497 ^ (long)-502292706);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-827590045 ^ (long)-827590120);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-303380212 ^ (long)-303379973);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1276599877 ^ (long)-1276599834);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-843864479 ^ (long)-843864377);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1502881082 ^ (long)1502881105);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1456844240 ^ (long)-1456844191);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)248126130 ^ (long)248126054);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1256688868 ^ (long)1256688857);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1239061706 ^ (long)1239061682);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-2000846287 ^ (long)-2000846222);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1911121151 ^ (long)1911121010);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)775196802 ^ (long)775196697);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1563350475 ^ (long)1563350310);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)181537950 ^ (long)181537810);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1879364685 ^ (long)-1879364789);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1249254800 ^ (long)1249254813);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-567370890 ^ (long)-567370990);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1635548683 ^ (long)1635548775);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1817871937 ^ (long)1817872008);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1345862363 ^ (long)1345862247);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1346897532 ^ (long)-1346897577);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1305748308 ^ (long)1305748246);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1464756546 ^ (long)1464756553);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1119694255 ^ (long)-1119694129);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-912046164 ^ (long)-912046126);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)844230003 ^ (long)844230019);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-314971551 ^ (long)-314971605);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1705634176 ^ (long)1705634125);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-489090414 ^ (long)-489090519);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)2025280741 ^ (long)2025280522);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-732921450 ^ (long)-732921537);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1751042576 ^ (long)-1751042644);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-457363986 ^ (long)-457364201);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-534060455 ^ (long)-534060478);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1028703314 ^ (long)-1028703468);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1742099116 ^ (long)-1742098975);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1212828506 ^ (long)1212828629);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-810019029 ^ (long)-810018822);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1431821925 ^ (long)1431821921);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1939628821 ^ (long)-1939628863);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1319139341 ^ (long)1319139386);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-736087179 ^ (long)-736087247);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1279686522 ^ (long)1279686559);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)321944781 ^ (long)321944723);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1168669419 ^ (long)-1168669229);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1706517466 ^ (long)-1706517283);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-321158631 ^ (long)-321158488);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)159400033 ^ (long)159400110);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-627113244 ^ (long)-627113340);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1206467483 ^ (long)-1206467509);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1823969190 ^ (long)-1823969161);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-963223243 ^ (long)-963223058);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1964455516 ^ (long)-1964455655);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)342863373 ^ (long)342863435);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1880605272 ^ (long)1880605277);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1037677482 ^ (long)-1037677499);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1578176470 ^ (long)1578176356);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-380223056 ^ (long)-380223063);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-233439890 ^ (long)-233439874);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1302282205 ^ (long)1302282233);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)836861676 ^ (long)836861677);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-2035005567 ^ (long)-2035005516);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)100178002 ^ (long)100177959);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-129421357 ^ (long)-129421516);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-228732807 ^ (long)-228732779);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1298493554 ^ (long)-1298493483);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1043738308 ^ (long)-1043738128);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1890118719 ^ (long)1890118676);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-2041375188 ^ (long)-2041375073);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-881570475 ^ (long)-881570392);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1188569721 ^ (long)1188569622);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-397273709 ^ (long)-397273688);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1943279633 ^ (long)-1943279863);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)229258913 ^ (long)229258920);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-941640375 ^ (long)-941640439);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)743051271 ^ (long)743051281);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)141449531 ^ (long)141449685);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)435387995 ^ (long)435388081);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)42563450 ^ (long)42563464);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1854287519 ^ (long)1854287465);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)384821263 ^ (long)384821451);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)667185142 ^ (long)667185145);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1479376839 ^ (long)-1479376804);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1841639590 ^ (long)1841639644);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-975251428 ^ (long)-975251260);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1717673591 ^ (long)1717673688);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-2138369680 ^ (long)-2138369716);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1606919974 ^ (long)-1606919954);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-156964705 ^ (long)-156964610);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1831479308 ^ (long)1831479527);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1570814569 ^ (long)1570814666);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-60689754 ^ (long)-60689772);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1123031538 ^ (long)1123031345);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1740843365 ^ (long)-1740843377);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)407048315 ^ (long)407048414);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1832459227 ^ (long)-1832459121);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1530284027 ^ (long)1530283896);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-505999374 ^ (long)-505999507);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1736542299 ^ (long)1736542257);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1419181709 ^ (long)-1419181663);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)379845895 ^ (long)379846106);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1143052884 ^ (long)1143052924);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1759172231 ^ (long)-1759172298);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1442352010 ^ (long)-1442352095);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1964014551 ^ (long)1964014477);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1923563204 ^ (long)1923563072);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-435023972 ^ (long)-435024106);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1761725877 ^ (long)-1761725925);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)666491135 ^ (long)666490985);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)758903709 ^ (long)758903583);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1955790294 ^ (long)1955790086);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-766456616 ^ (long)-766456710);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-2106851669 ^ (long)-2106851739);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1073146576 ^ (long)-1073146460);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)763137576 ^ (long)763137716);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)581400760 ^ (long)581400595);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)981032081 ^ (long)981031983);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)284374764 ^ (long)284374712);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)976409102 ^ (long)976409090);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1277331329 ^ (long)-1277331299);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)787347614 ^ (long)787347671);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-2116147873 ^ (long)-2116147841);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)684710825 ^ (long)684710806);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-56360862 ^ (long)-56360889);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)2118048216 ^ (long)2118048198);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1005288140 ^ (long)-1005288015);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1998263124 ^ (long)-1998263228);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1259739668 ^ (long)1259739737);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)311906421 ^ (long)311906354);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1831257946 ^ (long)-1831257932);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-87143893 ^ (long)-87143934);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-503189878 ^ (long)-503190004);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-741354178 ^ (long)-741354168);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1479776840 ^ (long)1479776801);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)2097660530 ^ (long)2097660455);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)411835844 ^ (long)411835771);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-917962182 ^ (long)-917961990);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-407527858 ^ (long)-407527852);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1400883349 ^ (long)-1400883436);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1530563324 ^ (long)-1530563203);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)331784521 ^ (long)331784560);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1821492058 ^ (long)1821492168);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1835889206 ^ (long)1835889313);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1079225314 ^ (long)-1079225287);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1922782510 ^ (long)1922782607);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)767103317 ^ (long)767103477);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)364398977 ^ (long)364399075);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1415628423 ^ (long)1415628382);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)48654767 ^ (long)48654729);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)385169452 ^ (long)385169556);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1631119613 ^ (long)-1631119603);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)188215709 ^ (long)188215564);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)2001121353 ^ (long)2001121354);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1836915089 ^ (long)-1836915191);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1719611250 ^ (long)-1719611165);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1261220818 ^ (long)-1261220740);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1539478329 ^ (long)1539478474);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1198144023 ^ (long)1198144208);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)945089542 ^ (long)945089779);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-147842485 ^ (long)-147842305);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)973904756 ^ (long)973904668);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1142650274 ^ (long)-1142650257);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1151110045 ^ (long)-1151109956);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)438800568 ^ (long)438800465);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1620254003 ^ (long)-1620253982);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1116009156 ^ (long)1116009089);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)2141188331 ^ (long)2141188172);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1892710939 ^ (long)1892711141);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)735770432 ^ (long)735770476);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1240763508 ^ (long)1240763448);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)743011894 ^ (long)743012015);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1110234942 ^ (long)1110235030);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)293786334 ^ (long)293786261);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)18469259 ^ (long)18469276);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1860620463 ^ (long)-1860620510);
                    if (!7q.\u2003\u200a\u2008) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1879666328 ^ (long)-1879666241);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-506280489 ^ (long)-506280664)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-267922009 ^ (long)-267965864)) >>> (int)((long)1086459746 ^ (long)1086459754)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1911868651 ^ (long)-1911868651);
            if (!7q.\u2003\u200a\u2008) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)163378514 ^ (long)163378512);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)607718411 ^ (long)607718408) | var5_6 << (int)((long)-1471427004 ^ (long)-1471427007)) ^ var3_4[var7_8]) & (int)((long)1992789835 ^ (long)1992789940);
                    if (7q.\u2003\u200a\u2008) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1848944297 ^ (long)-1848944300) | var6_7 << (int)((long)309039096 ^ (long)309039101)) ^ var3_4[var7_8]) & (int)((long)930600901 ^ (long)930600762);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7q.b[var2_3] = new String(var3_4).intern();
        }
        return 7q.b[var2_3];
    }

    static /* synthetic */ 1P 9(7q q) {
        boolean bl = \u2003\u200a\u2008;
        if (bl || bl) {
            return null;
        }
        return q.6;
    }

    public 7q(06 object) {
        boolean bl3 = \u2003\u200a\u2008;
        super(object, 7q.a((int)((long)-464591114 ^ (long)-464589980), (int)((long)-790995916 ^ (long)-790987273)) /* "Smart" */, null);
        Object object2 = 4C.a;
        object = (34f)((34f)((34f)this.2(4C.class).5(7q.a((int)((long)1657101612 ^ (long)1657098421), (int)((long)-393404497 ^ (long)-393395238)) /* "Lock" */)).7(7q.a((int)((long)1723033969 ^ (long)1723032809), (int)((long)-178441609 ^ (long)-178428484)) /* "lock" */)).1(7q.a((int)((long)-566663193 ^ (long)-566662535), (int)((long)380873904 ^ (long)-380888756)) /* "The pathing direction yaw lock" */);
        ((34f)((34f)((34f)this.2(4C.class).5(7q.a((int)((long)1657101612 ^ (long)1657098421), (int)((long)-393404497 ^ (long)-393395238)) /* "Lock" */)).7(7q.a((int)((long)1723033969 ^ (long)1723032809), (int)((long)-178441609 ^ (long)-178428484)) /* "lock" */)).1(7q.a((int)((long)-566663193 ^ (long)-566662535), (int)((long)380873904 ^ (long)-380888756)) /* "The pathing direction yaw lock" */)).7 = object2;
        this.1 = (1m)((34f)object).5();
        object2 = Boolean.FALSE;
        object = (34X)((34X)((34X)this.4().5(7q.a((int)((long)-1471682740 ^ (long)-1471681828), (int)((long)-476239767 ^ (long)476238667)) /* "Preserve Y" */)).7(7q.a((int)((long)-863907036 ^ (long)-863904069), (int)((long)-845552111 ^ (long)-845556118)) /* "preservey" */)).1(7q.a((int)((long)-663128162 ^ (long)-663127548), (int)((long)-620719989 ^ (long)-620709342)) /* "Preserves your Y coordinate when pathing" */);
        ((34X)((34X)((34X)this.4().5(7q.a((int)((long)-1471682740 ^ (long)-1471681828), (int)((long)-476239767 ^ (long)476238667)) /* "Preserve Y" */)).7(7q.a((int)((long)-863907036 ^ (long)-863904069), (int)((long)-845552111 ^ (long)-845556118)) /* "preservey" */)).1(7q.a((int)((long)-663128162 ^ (long)-663127548), (int)((long)-620719989 ^ (long)-620709342)) /* "Preserves your Y coordinate when pathing" */)).7 = object2;
        this.2 = (1P)((34X)object).5();
        object2 = Boolean.FALSE;
        object = (34X)((34X)((34X)this.4().5(7q.a((int)((long)1501489385 ^ (long)1501488500), (int)((long)-2008363410 ^ (long)-2008366751)) /* "Persistent" */)).7(7q.a((int)((long)169851545 ^ (long)169850626), (int)((long)2113215579 ^ (long)-2113222626)) /* "persistent" */)).1(7q.a((int)((long)-1937854128 ^ (long)-1937851188), (int)((long)-254550107 ^ (long)-254551555)) /* "Keep trying to calculate a path; never give up" */);
        ((34X)((34X)((34X)this.4().5(7q.a((int)((long)1501489385 ^ (long)1501488500), (int)((long)-2008363410 ^ (long)-2008366751)) /* "Persistent" */)).7(7q.a((int)((long)169851545 ^ (long)169850626), (int)((long)2113215579 ^ (long)-2113222626)) /* "persistent" */)).1(7q.a((int)((long)-1937854128 ^ (long)-1937851188), (int)((long)-254550107 ^ (long)-254551555)) /* "Keep trying to calculate a path; never give up" */)).7 = object2;
        this.6 = (1P)((34X)object).5();
        this.7 = new Listener(f -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2003\u200a\u2008;
                        if (bl || bl) break block2;
                        if (this.4 != null) break block3;
                        if (bl) break block2;
                        if (f.8 != EventState.PRE) break block3;
                        if (bl) break block2;
                        if (7q.3.s == null) break block3;
                        if (bl || bl) break block2;
                        this.4 = Float.valueOf(7q.3.s.p);
                        if (bl || bl) break block2;
                        this.5();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)496093356 ^ (long)496093356)]);
        this.0 = new Listener(j2 -> {
            block3: {
                block2: {
                    boolean bl = \u2003\u200a\u2008;
                    if (bl || bl) break block2;
                    this.4 = null;
                    if (bl || bl) break block2;
                    this.5 = null;
                    if (!bl && !bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)-810165508 ^ (long)-810165508)]);
        BaritoneAPI.getProvider().getPrimaryBaritone().getGameEventHandler().registerEventListener((IGameEventListener)this);
        this.2.3((z, bl, bl2) -> {
            block3: {
                block2: {
                    boolean bl3 = \u2003\u200a\u2008;
                    if (bl3 || bl3) break block2;
                    this.5 = null;
                    if (bl3 || bl3) break block2;
                    this.5();
                    if (!bl3 && !bl3) break block3;
                }
                return;
            }
        });
        new 6s(this, (byte)((long)1845004366 ^ (long)1845004366)).3();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void onPathEvent(PathEvent kArray) {
        boolean bl;
        block17: {
            block16: {
                bl = \u2003\u200a\u2008;
                if (bl || bl) return;
                if (!((06)this.8).3()) break block16;
                if (bl) return;
                if (this.3()) break block17;
                if (bl) return;
            }
            if (bl) return;
            return;
        }
        if (bl) return;
        switch (5i.1[kArray.ordinal()]) {
            case 1: {
                if (bl) return;
                k[] kArray2 = new k[(int)((long)-652698205 ^ (long)-652698206)];
                kArray2[(int)((long)1530638436 ^ (long)1530638436)] = k.m;
                kArray = kArray2;
                5p.9((nr)new 3sC().2((String)7q.a((int)((int)((long)-1471119643 ^ (long)-1471122572)), (int)((int)((long)1348809924 ^ (long)-1348815020))), null, (k[])kArray).7);
                if (bl || bl) return;
                if (this.6.2) break;
                if (bl || bl) return;
                ((06)this.8).1((boolean)((long)-1811108572 ^ (long)-1811108572));
                if (bl) return;
                return;
            }
            case 2: {
                if (bl) return;
                this.5();
                if (bl) return;
                break;
            }
        }
        if (!bl) return;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u2003\u200a\u2008;
                if (bl || bl) break block2;
                this.4 = null;
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 5() {
        GoalBlock goalBlock;
        int n;
        boolean bl;
        block16: {
            block15: {
                bl = \u2003\u200a\u2008;
                if (bl || bl) return;
                if (!((06)this.8).3()) break block15;
                if (bl) return;
                if (!this.3()) break block15;
                if (bl) return;
                if (7q.3.s == null) break block15;
                if (bl) return;
                if (this.4 != null) break block16;
                if (bl) return;
            }
            if (bl) return;
            return;
        }
        if (bl) {
            return;
        }
        Settings.Setting setting = BaritoneAPI.getSettings().simplifyUnloadedYCoord;
        if (!this.2.2) {
            n = (int)((long)761473219 ^ (long)761473218);
            if (\u2003\u200a\u2008) {
                throw null;
            }
        } else {
            n = (int)((long)-563831007 ^ (long)-563831007);
        }
        setting.value = n != 0;
        float f = this.4.floatValue() + 90.0f;
        float f2 = (float)Math.toRadians(((4C)((Object)this.1.0())).6.apply(Float.valueOf(f)).floatValue());
        double d = 4C.3((4C)((Object)this.1.0()));
        int n2 = afm.c((double)(7q.3.s.cD() + (double)afm.b((float)f2) * d));
        int n3 = afm.c((double)(7q.3.s.cH() + (double)afm.a((float)f2) * d));
        if (this.2.2) {
            goalBlock = new GoalBlock(n2, afm.c((double)7q.3.s.cE()), n3);
            if (\u2003\u200a\u2008) {
                throw null;
            }
        } else {
            goalBlock = new GoalXZ(n2, n3);
        }
        this.5 = goalBlock;
    }

    static /* synthetic */ 3X 0(7q q) {
        boolean bl = \u2003\u200a\u2008;
        if (bl || bl) {
            return null;
        }
        return q.8;
    }

    static /* synthetic */ 3X 2(7q q) {
        boolean bl = \u2003\u200a\u2008;
        if (bl || bl) {
            return null;
        }
        return q.8;
    }

    static /* synthetic */ Goal 0(7q q) {
        boolean bl = \u2003\u200a\u2008;
        if (bl || bl) {
            return null;
        }
        return q.5;
    }
}

