/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  dem$j
 *  dem$r
 *  dez
 *  dfm
 *  dnq
 *  dot
 *  nr
 */
package net.impactclient;

import com.mojang.blaze3d.systems.RenderSystem;
import net.impactclient.29;
import net.impactclient.2w$6X;
import net.impactclient.30;
import net.impactclient.3A;
import net.impactclient.3sC;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 4c
extends dnq {
    private static final String[] s;
    private final 30 5;
    public static final boolean \u2001\u2004;
    private static final String[] r;

    /*
     * Enabled aggressive block sorting
     */
    public final void b(String string, boolean bl) {
        boolean bl2 = \u2001\u2004;
        if (bl2 || bl2) return;
        if (this.i.s == null) {
            if (bl2 || bl2) return;
            this.i.j.c().a((nr)new 3sC().1((String)2w$6X.KAOZ((Object)"\udf7f", (int)-121308776)).1((String)this.i.J().c()).1((String)4c.a((int)((int)((long)91292585 ^ (long)91292683)), (int)((int)((long)-1986818800 ^ (long)-1986819630)))).1((String)string).7);
            if (bl2 || bl2) return;
            3A.6.post((Object)new 29(string));
            if (bl2 || bl2) return;
            return;
        }
        if (bl2) return;
        super.b(string, bl);
        if (!bl2 && !bl2) return;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void b() {
        block3: {
            block2: {
                boolean bl = \u2001\u2004;
                if (bl || bl) break block2;
                this.5.b();
                if (bl || bl) break block2;
                super.b();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(dfm dfm2, int n, int n2, float f) {
        block3: {
            block2: {
                boolean bl = \u2001\u2004;
                if (bl || bl) break block2;
                this.5.a(dfm2, (int)((long)-1024184544 ^ (long)1024184543), (int)((long)-2038671725 ^ (long)2038671724), f);
                if (bl || bl) break block2;
                dez dez2 = this.i.aD();
                dez2.o();
                if (bl || bl) break block2;
                int n3 = dez2.p();
                if (bl || bl) break block2;
                RenderSystem.enableBlend();
                if (bl || bl) break block2;
                RenderSystem.blendFuncSeparate((dem.r)dem.r.l, (dem.j)dem.j.j, (dem.r)dem.r.e, (dem.j)dem.j.n);
                if (bl || bl) break block2;
                RenderSystem.disableAlphaTest();
                if (bl || bl) break block2;
                RenderSystem.pushMatrix();
                if (bl || bl) break block2;
                RenderSystem.translatef((float)0.0f, (float)(n3 - (int)((long)-1651395091 ^ (long)-1651395107)), (float)0.0f);
                if (bl || bl) break block2;
                this.i.au().a(4c.a((int)((long)-855448943 ^ (long)-855448270), (int)((long)-1640517220 ^ (long)1640518713)) /* "chat" */);
                if (bl || bl) break block2;
                this.i.j.c().a(dfm2, this.i.j.d());
                if (bl || bl) break block2;
                this.i.au().c();
                if (bl || bl) break block2;
                RenderSystem.popMatrix();
                if (bl || bl) break block2;
                super.a(dfm2, n, n2, f);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    public 4c(30 var1_1, String string) {
        boolean bl = \u2001\u2004;
        super(string);
        this.5 = var1_1;
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 4c.\u2001\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1558310264 ^ (long)1558309594)) & (int)((long)1450824839 ^ (long)1450781560);
            if (var9_2) ** GOTO lbl-1000
            if (4c.s[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 4c.r[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1904838332 ^ (long)1904838332)] & (int)((long)839114115 ^ (long)839114108)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-264708795 ^ (long)-264708682);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)526450881 ^ (long)526450698);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-435466711 ^ (long)-435466740);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-882078215 ^ (long)-882078234);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1362580846 ^ (long)1362580907);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-450594363 ^ (long)-450594349);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-2044179783 ^ (long)-2044179859);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1604019559 ^ (long)1604019530);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)993120329 ^ (long)993120315);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)374805538 ^ (long)374805718);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1614490369 ^ (long)1614490454);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1109926297 ^ (long)-1109926307);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-606263567 ^ (long)-606263626);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1737856074 ^ (long)-1737856176);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-2095591462 ^ (long)-2095591586);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1801501923 ^ (long)-1801501840);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)582110259 ^ (long)582110269);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1911397009 ^ (long)-1911396891);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1315586055 ^ (long)-1315586119);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-828892866 ^ (long)-828892688);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)342987432 ^ (long)342987361);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1840912930 ^ (long)-1840912940);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1594294097 ^ (long)1594294113);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-74987174 ^ (long)-74987240);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1867085486 ^ (long)1867085362);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1516400142 ^ (long)-1516400205);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-823134750 ^ (long)-823134749);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)324003620 ^ (long)324003688);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)197962993 ^ (long)197962858);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-2133065722 ^ (long)-2133065474);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1721338363 ^ (long)-1721338167);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)2014102332 ^ (long)2014102458);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)558607658 ^ (long)558607624);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1176791311 ^ (long)1176791474);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1441715622 ^ (long)1441715553);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-373374280 ^ (long)-373374417);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-146520662 ^ (long)-146520752);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1821608849 ^ (long)1821608944);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1886036683 ^ (long)1886036501);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1314599266 ^ (long)-1314599240);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1020167264 ^ (long)-1020167213);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-159752796 ^ (long)-159752920);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-299988350 ^ (long)-299988355);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)56527715 ^ (long)56527842);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-152076635 ^ (long)-152076746);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-17609560 ^ (long)-17609572);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)183857942 ^ (long)183858040);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1817315698 ^ (long)1817315740);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1753999849 ^ (long)1753999861);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)488523661 ^ (long)488523740);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1563632144 ^ (long)1563632325);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1317768914 ^ (long)-1317768847);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-552305567 ^ (long)-552305651);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1604363561 ^ (long)-1604363560);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)725577866 ^ (long)725577893);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)839631874 ^ (long)839632064);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-518759745 ^ (long)-518759930);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1914922883 ^ (long)1914922980);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)991636922 ^ (long)991636963);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-137564884 ^ (long)-137564841);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1469299327 ^ (long)-1469299415);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-426285993 ^ (long)-426286011);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-568749935 ^ (long)-568749881);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)633838479 ^ (long)633838475);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)32521065 ^ (long)32521126);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)454445576 ^ (long)454445811);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)2076212411 ^ (long)2076212455);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)291768494 ^ (long)291768390);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-641882773 ^ (long)-641882823);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-40428963 ^ (long)-40428939);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-2007348318 ^ (long)-2007348452);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1016305069 ^ (long)1016305115);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)2122795114 ^ (long)2122795024);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1211218707 ^ (long)1211218888);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-183149552 ^ (long)-183149561);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1340665993 ^ (long)-1340665891);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1782082725 ^ (long)-1782082588);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1353413411 ^ (long)-1353413398);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1588622602 ^ (long)-1588622701);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1828751159 ^ (long)1828751175);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-492104325 ^ (long)-492104296);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1999354426 ^ (long)1999354516);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1106037941 ^ (long)-1106037997);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1022204471 ^ (long)1022204483);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)267268873 ^ (long)267268878);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)821408619 ^ (long)821408605);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)257190785 ^ (long)257190686);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1786530724 ^ (long)1786530766);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-2076051973 ^ (long)-2076052127);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1767552265 ^ (long)1767552352);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1056253927 ^ (long)-1056253714);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1286093057 ^ (long)-1286093161);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1357943973 ^ (long)1357944035);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1758954224 ^ (long)-1758954192);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-173824039 ^ (long)-173824052);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1291659570 ^ (long)1291659764);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)222543639 ^ (long)222543704);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1901830869 ^ (long)1901830719);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1273949408 ^ (long)1273949266);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-507629778 ^ (long)-507629587);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-404325612 ^ (long)-404325381);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1858013147 ^ (long)1858013002);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-747690331 ^ (long)-747690259);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1136156453 ^ (long)-1136156578);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-934007775 ^ (long)-934007599);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)37040168 ^ (long)37040179);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-2081817614 ^ (long)-2081817769);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)777940661 ^ (long)777940614);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-794165595 ^ (long)-794165700);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-898398826 ^ (long)-898398738);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1017355681 ^ (long)1017355754);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-667572476 ^ (long)-667572317);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-2025624672 ^ (long)-2025624611);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)138589538 ^ (long)138589657);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1215441159 ^ (long)1215441235);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1041778612 ^ (long)-1041778514);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1757386597 ^ (long)-1757386725);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)456876007 ^ (long)456875946);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-762826618 ^ (long)-762826737);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1678496071 ^ (long)-1678496076);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1896408072 ^ (long)-1896408280);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)846603013 ^ (long)846603109);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1418107058 ^ (long)1418107000);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1862585209 ^ (long)1862585114);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1416485480 ^ (long)-1416485588);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-627261352 ^ (long)-627261349);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-660187723 ^ (long)-660187740);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)687641745 ^ (long)687641619);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1998937553 ^ (long)-1998937379);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)71107717 ^ (long)71107680);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)679243682 ^ (long)679243578);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1645104352 ^ (long)1645104211);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-348012543 ^ (long)-348012523);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1385964417 ^ (long)-1385964378);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-359160737 ^ (long)-359160663);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)197720761 ^ (long)197720776);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-459572890 ^ (long)-459572840);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1036010775 ^ (long)-1036010838);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)166868799 ^ (long)166868960);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1463919309 ^ (long)-1463919307);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1902113067 ^ (long)1902113167);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1235437241 ^ (long)-1235437218);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-261010373 ^ (long)-261010422);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)2095823170 ^ (long)2095823163);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-585231004 ^ (long)-585230967);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)953415512 ^ (long)953415563);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)706113135 ^ (long)706113260);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1061149027 ^ (long)1061149001);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)313248429 ^ (long)313248383);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1474119809 ^ (long)-1474119774);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1866303246 ^ (long)-1866303430);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1460314486 ^ (long)1460314494);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)791787852 ^ (long)791788016);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1774383206 ^ (long)-1774383223);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1227189504 ^ (long)1227189557);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)217100824 ^ (long)217100979);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1444066904 ^ (long)-1444066924);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-513016443 ^ (long)-513016476);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-267573326 ^ (long)-267573488);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1086194878 ^ (long)-1086194701);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-433619232 ^ (long)-433619280);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)822647852 ^ (long)822648052);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-482255234 ^ (long)-482255334);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-155250304 ^ (long)-155250202);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1290503183 ^ (long)1290503288);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)761976112 ^ (long)761976186);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)783693652 ^ (long)783693717);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1388110252 ^ (long)1388110279);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-692660283 ^ (long)-692660264);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-2058141257 ^ (long)-2058141271);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-417864615 ^ (long)-417864613);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)604367173 ^ (long)604367223);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-722107202 ^ (long)-722107281);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-767037055 ^ (long)-767037091);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1893323341 ^ (long)-1893323458);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1001165784 ^ (long)1001165819);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-289888905 ^ (long)-289888825);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-411164453 ^ (long)-411164650);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1810816886 ^ (long)-1810816905);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1715185847 ^ (long)1715185804);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)2060479206 ^ (long)2060479178);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1510057926 ^ (long)1510057766);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1698464178 ^ (long)-1698464162);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)309186422 ^ (long)309186539);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-606196673 ^ (long)-606196639);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-644909119 ^ (long)-644909239);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1777077100 ^ (long)-1777077072);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)608063725 ^ (long)608063686);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)312218149 ^ (long)312218291);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)933484430 ^ (long)933484509);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)404705565 ^ (long)404705738);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1706806102 ^ (long)1706806186);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1988692640 ^ (long)-1988692497);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-775058386 ^ (long)-775058198);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1030620389 ^ (long)1030620389);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1114337051 ^ (long)-1114337213);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)577707802 ^ (long)577707912);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-619327612 ^ (long)-619327571);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-525456329 ^ (long)-525456337);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1507275039 ^ (long)-1507275251);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1097300194 ^ (long)1097300188);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1439610187 ^ (long)-1439610292);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-718622218 ^ (long)-718622373);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)179482525 ^ (long)179482556);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-26246998 ^ (long)-26246992);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-707652783 ^ (long)-707652668);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)2067223642 ^ (long)2067223791);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1833959400 ^ (long)1833959346);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1302953976 ^ (long)-1302953971);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)970655762 ^ (long)970655852);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1029575829 ^ (long)-1029575700);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1273696041 ^ (long)1273696206);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1520924986 ^ (long)-1520925027);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)2029113975 ^ (long)2029113918);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-970961152 ^ (long)-970960994);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1158122749 ^ (long)1158122508);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-531188658 ^ (long)-531188640);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)924927784 ^ (long)924927880);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1771618242 ^ (long)-1771618238);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1254797916 ^ (long)1254797865);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1768247355 ^ (long)-1768247533);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)2001483580 ^ (long)2001483617);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-2094079752 ^ (long)-2094079757);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1472828633 ^ (long)-1472828641);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1252075819 ^ (long)-1252075910);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1950316787 ^ (long)-1950316595);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1608179397 ^ (long)1608179327);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-91467076 ^ (long)-91467177);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1249712533 ^ (long)-1249712564);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1577258187 ^ (long)1577258109);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)85852474 ^ (long)85852501);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-2023940306 ^ (long)-2023940150);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1028251300 ^ (long)-1028251295);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1305580466 ^ (long)-1305580478);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-985116689 ^ (long)-985116698);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1660096393 ^ (long)-1660096339);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)413403559 ^ (long)413403470);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)766389044 ^ (long)766389078);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-119081563 ^ (long)-119081675);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1946084809 ^ (long)1946084749);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-768335960 ^ (long)-768336119);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-474239833 ^ (long)-474239989);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-996623557 ^ (long)-996623464);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1895959176 ^ (long)-1895959104);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-2123411909 ^ (long)-2123411793);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)834333303 ^ (long)834333436);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)27996335 ^ (long)27996394);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-675592017 ^ (long)-675592168);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1104653044 ^ (long)-1104652926);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1136438850 ^ (long)-1136439017);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-703941663 ^ (long)-703941713);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-470035067 ^ (long)-470035088);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1680579432 ^ (long)1680579415);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)669488569 ^ (long)669488512);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1995009636 ^ (long)1995009563);
                    if (!4c.\u2001\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1945000318 ^ (long)1945000235);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1660154737 ^ (long)1660154766)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1188996502 ^ (long)-1188977259)) >>> (int)((long)870578167 ^ (long)870578175)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1470076966 ^ (long)-1470076966);
            if (!4c.\u2001\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)538533279 ^ (long)538533277);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-217558702 ^ (long)-217558703) | var5_6 << (int)((long)-1768212654 ^ (long)-1768212649)) ^ var3_4[var7_8]) & (int)((long)-1769742924 ^ (long)-1769743029);
                    if (4c.\u2001\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-852488427 ^ (long)-852488426) | var6_7 << (int)((long)-1279140689 ^ (long)-1279140694)) ^ var3_4[var7_8]) & (int)((long)111789286 ^ (long)111789081);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            4c.s[var2_3] = new String(var3_4).intern();
        }
        return 4c.s[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean a(int n, int n2, int n3) {
        boolean bl;
        block14: {
            block13: {
                bl = \u2001\u2004;
                if (bl || bl) return true;
                if (n == (int)((long)-1347646233 ^ (long)-1347645977)) {
                    if (bl || bl) return true;
                    this.i.a((dot)this.5);
                    if (bl || bl) return true;
                    return (int)((long)-1803018562 ^ (long)-1803018561) != 0;
                }
                if (bl) return true;
                if (n == (int)((long)634064588 ^ (long)634064845)) break block13;
                if (bl) return true;
                if (n != (int)((long)1640045853 ^ (long)1640045650)) break block14;
                if (bl) return true;
            }
            if (bl) return true;
            String string = this.a.b().trim();
            if (!string.isEmpty()) {
                if (bl || bl) return true;
                this.b_(string);
                if (bl) return true;
            }
            if (bl) return true;
            this.i.a((dot)this.5);
            if (bl || bl) return true;
            return (int)((long)740631876 ^ (long)740631877) != 0;
        }
        if (!bl) return super.a(n, n2, n3);
        return true;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 4c.\u2001\u2004;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)1602541659 ^ (long)1602541657)];
            if (var7) break block16;
            var3_2 = (int)((long)5133240 ^ (long)5133240);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\uee94\uc6b9\ud5e0\udd41\uee1f\uc62d\ud54f", -1595291567);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)-346104679 ^ (long)-346104677);
            if (var7) break block16;
            var0_6 = (int)((long)1642008967 ^ (long)-1642008968);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-509508802 ^ (long)509508801);
                if (4c.\u2001\u2004) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!4c.\u2001\u2004) continue block8;
                            throw null;
                        }
                        4c.r = var5_1;
                        4c.s = new String[(int)((long)1094075767 ^ (long)1094075765)];
                        if (!4c.\u2001\u2004) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)1083840385 ^ (long)1083840385);
                v5 = (int)((long)-2108357836 ^ (long)-2108357776);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)527101940 ^ (long)527101941)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-551389387 ^ (long)-551389390)) {
                                case 0: {
                                    v12 = (int)((long)-1006815534 ^ (long)-1006815600);
                                    if (!4c.\u2001\u2004) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)-1071023301 ^ (long)-1071023242);
                                    if (!4c.\u2001\u2004) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)921610733 ^ (long)921610728);
                                    if (!4c.\u2001\u2004) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)547075566 ^ (long)547075459);
                                    if (!4c.\u2001\u2004) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)1938065555 ^ (long)1938065583);
                                    if (!4c.\u2001\u2004) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)566465082 ^ (long)566465120);
                                    if (!4c.\u2001\u2004) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-876845613 ^ (long)-876845616);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!4c.\u2001\u2004);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!4c.\u2001\u2004) ** continue;
                throw null;
            }
        }
    }
}

