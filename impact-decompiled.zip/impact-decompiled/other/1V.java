/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqa
 *  aqm
 *  com.google.common.collect.ImmutableList
 *  com.mojang.blaze3d.systems.RenderSystem
 *  dci
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  org.lwjgl.opengl.GL11
 *  pw.knx.feather.tessellate.Tessellator
 */
package net.impactclient;

import clientapi.load.mixin.7.2;
import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.2_;
import net.impactclient.2c;
import net.impactclient.2o;
import net.impactclient.2r;
import net.impactclient.2w$6X;
import net.impactclient.3e;
import net.impactclient.4L;
import net.impactclient.5C;
import net.impactclient.5K;
import net.impactclient.6L;
import net.impactclient.7m;
import net.impactclient.7t;
import net.impactclient.8S;
import net.impactclient.94;
import net.impactclient.9V;
import net.impactclient.9b;
import org.lwjgl.opengl.GL11;
import pw.knx.feather.tessellate.Tessellator;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 1V
extends 7m<7t> {
    private static final String[] a;
    private ImmutableList<8S> 6;
    @EventHandler
    private final Listener<2r> 7;
    @EventHandler
    private final Listener<2o> 9;
    private static final String[] b;
    private final List<5C> 1;
    public static final boolean \u2003\u2004\u2003;
    private List<9V> 4;

    /*
     * Enabled aggressive block sorting
     */
    private static 5C 5(float f, float f2, float f3, float f4) {
        5C c2;
        block3: {
            block2: {
                boolean bl = \u2003\u2004\u2003;
                if (bl || bl) break block2;
                c2 = new 5C();
                9V[] vArray = new 9V[(int)((long)1167994276 ^ (long)1167994272)];
                vArray[(int)((long)835901606 ^ (long)835901606)] = new 9V(f, f2);
                vArray[(int)((long)983849790 ^ (long)983849791)] = new 9V(f3, f2);
                vArray[(int)((long)-443194267 ^ (long)-443194265)] = new 9V(f3, f4);
                vArray[(int)((long)684170641 ^ (long)684170642)] = new 9V(f, f4);
                new 5C().9 = vArray;
                if (bl || bl) break block2;
                c2.6 = (int)((long)-964746513 ^ (long)-964746514);
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return c2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u2003\u2004\u2003;
                if (bl || bl) break block2;
                this.1.clear();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ void 4(Tessellator tessellator, 5C c2) {
        block11: {
            boolean bl = \u2003\u2004\u2003;
            if (!bl && !bl) {
                9V[] vArray = c2.9;
                if (!bl) {
                    int n = (int)((long)-2093668677 ^ (long)-2093668677);
                    String[] stringArray = 3e.5();
                    if (!bl) {
                        while (!bl) {
                            int n2;
                            if (n < vArray.length) {
                                if (bl || bl) break;
                                9V v = vArray[n];
                                if (bl || bl) break;
                                n2 = n;
                                if (stringArray == null) {
                                    if (n2 < vArray.length - (int)((long)-2011222254 ^ (long)-2011222253)) {
                                        if (bl || bl) break;
                                        tessellator.addVertex(v.6, v.3, 0.0f).addVertex(vArray[n + (int)((long)-1549598936 ^ (long)-1549598935)].6, vArray[n + (int)((long)2007241221 ^ (long)2007241220)].3, 0.0f);
                                        if (bl) break;
                                        if (stringArray != null) {
                                            if (bl) break;
                                        }
                                    } else {
                                        if (bl) break;
                                        if (c2.6) {
                                            if (bl || bl) break;
                                            tessellator.addVertex(v.6, v.3, 0.0f).addVertex(vArray[(int)((long)-1824099138 ^ (long)-1824099138)].6, vArray[(int)((long)830800210 ^ (long)830800210)].3, 0.0f);
                                            if (bl) break;
                                        }
                                    }
                                    if (bl) break;
                                    ++n;
                                    if (bl) break;
                                    if (stringArray == null) continue;
                                    if (bl) break;
                                }
                            } else {
                                if (bl) break;
                                n2 = c2.8;
                            }
                            5K.6(n2);
                            if (bl || bl) break;
                            tessellator.draw((int)((long)-861950932 ^ (long)-861950929));
                            if (!bl && !bl) break block11;
                        }
                    }
                }
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 1V.\u2003\u2004\u2003;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1092087701 ^ (long)-1092063283)) & (int)((long)1428912683 ^ (long)1428915668);
            if (var9_2) ** GOTO lbl-1000
            if (1V.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 1V.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1383050638 ^ (long)-1383050638)] & (int)((long)-1113140838 ^ (long)-1113140891)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1459600752 ^ (long)-1459600801);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-140897168 ^ (long)-140897129);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-732152298 ^ (long)-732152109);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)701487058 ^ (long)701486956);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1100730655 ^ (long)1100730668);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-81965021 ^ (long)-81965049);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1310460974 ^ (long)1310461121);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1038332895 ^ (long)-1038332697);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-864688056 ^ (long)-864688043);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-618437770 ^ (long)-618437638);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1002371608 ^ (long)-1002371816);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1634875442 ^ (long)1634875527);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1157514557 ^ (long)1157514594);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)35565343 ^ (long)35565429);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-56138001 ^ (long)-56138187);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)115496313 ^ (long)115496231);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-781760711 ^ (long)-781760765);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1885806778 ^ (long)1885806826);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1822713981 ^ (long)-1822713911);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)311015127 ^ (long)311015055);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)319584443 ^ (long)319584263);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)489466096 ^ (long)489465911);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1629280094 ^ (long)-1629280194);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)545411744 ^ (long)545411658);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-969275402 ^ (long)-969275396);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1409218702 ^ (long)-1409218807);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)577799908 ^ (long)577799927);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)661584583 ^ (long)661584417);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)373224107 ^ (long)373224165);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-356339618 ^ (long)-356339637);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1688465940 ^ (long)-1688465928);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-63474349 ^ (long)-63474185);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)779159436 ^ (long)779159545);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1381104948 ^ (long)-1381105046);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1505969949 ^ (long)1505970085);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-718604655 ^ (long)-718604624);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1923183453 ^ (long)-1923183555);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)594199424 ^ (long)594199353);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)681307957 ^ (long)681307927);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1772130715 ^ (long)-1772130618);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1358523610 ^ (long)1358523394);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-200247495 ^ (long)-200247420);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-800402191 ^ (long)-800402279);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1529492842 ^ (long)-1529492822);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1151858193 ^ (long)-1151858343);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)879360864 ^ (long)879360854);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)45262071 ^ (long)45261930);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1123533173 ^ (long)1123533154);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)283881002 ^ (long)283881013);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-838444379 ^ (long)-838444472);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)65541310 ^ (long)65541229);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-168347442 ^ (long)-168347517);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1859002659 ^ (long)-1859002786);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)979883497 ^ (long)979883326);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-650233288 ^ (long)-650233130);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1746090264 ^ (long)1746090416);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1493418567 ^ (long)1493418570);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1476312396 ^ (long)1476312363);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1740240115 ^ (long)1740240010);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-827471763 ^ (long)-827471726);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-144564188 ^ (long)-144564026);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-600044053 ^ (long)-600044047);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)533001844 ^ (long)533001981);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)941797169 ^ (long)941797327);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-2023919981 ^ (long)-2023920123);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1675889716 ^ (long)1675889816);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-2120255575 ^ (long)-2120255542);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1426401976 ^ (long)-1426401916);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-205011868 ^ (long)-205011721);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)919771944 ^ (long)919772107);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)2054112605 ^ (long)2054112716);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-329894932 ^ (long)-329895108);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1922019467 ^ (long)-1922019343);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-81452354 ^ (long)-81452450);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-6685116 ^ (long)-6684983);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-966379484 ^ (long)-966379459);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)872829637 ^ (long)872829543);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1742269579 ^ (long)1742269571);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1038228998 ^ (long)1038229055);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-440482727 ^ (long)-440482690);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1529394013 ^ (long)-1529394125);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-198774037 ^ (long)-198774052);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)631148502 ^ (long)631148371);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)593617417 ^ (long)593617531);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1121437361 ^ (long)1121437221);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)699156943 ^ (long)699156991);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1756524378 ^ (long)1756524420);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-707050198 ^ (long)-707050017);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1603897238 ^ (long)-1603897282);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-407867922 ^ (long)-407868118);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1303254304 ^ (long)-1303254421);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1896326628 ^ (long)-1896326656);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)471820765 ^ (long)471820741);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-795860699 ^ (long)-795860524);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1206569212 ^ (long)1206568983);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-912570511 ^ (long)-912570579);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-93460707 ^ (long)-93460644);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)393358909 ^ (long)393358877);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1976164629 ^ (long)1976164668);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1676096493 ^ (long)1676096399);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)819452846 ^ (long)819452832);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)427252500 ^ (long)427252511);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-77106229 ^ (long)-77106335);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)672214884 ^ (long)672214810);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1412157846 ^ (long)1412157767);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)611014020 ^ (long)611014079);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)244218459 ^ (long)244218468);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)517673578 ^ (long)517673556);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-899373857 ^ (long)-899373900);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-153421385 ^ (long)-153421328);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)256842361 ^ (long)256842343);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1077062767 ^ (long)1077062835);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1946785648 ^ (long)1946785775);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1240755817 ^ (long)1240755759);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-118694754 ^ (long)-118694698);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-352281172 ^ (long)-352281285);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-755081402 ^ (long)-755081441);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-793777810 ^ (long)-793777692);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1666038155 ^ (long)1666038073);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)2126985794 ^ (long)2126985753);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1753059303 ^ (long)1753059113);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1225523539 ^ (long)1225523600);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-941162410 ^ (long)-941162419);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-770710296 ^ (long)-770710436);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1735658648 ^ (long)1735658698);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1012769387 ^ (long)-1012769401);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-752848630 ^ (long)-752848566);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1145673605 ^ (long)-1145673697);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1879857159 ^ (long)1879857270);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)259163013 ^ (long)259162961);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)553711849 ^ (long)553711698);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-663686339 ^ (long)-663686383);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1106817427 ^ (long)-1106817314);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)412421399 ^ (long)412421561);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1196529614 ^ (long)-1196529429);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1959011709 ^ (long)-1959011723);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1157126132 ^ (long)1157126016);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1818390754 ^ (long)-1818390625);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1186601745 ^ (long)-1186601831);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1341787677 ^ (long)-1341787781);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-878003301 ^ (long)-878003281);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1141114968 ^ (long)-1141115063);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)140305932 ^ (long)140306085);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-2066115675 ^ (long)-2066115623);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1290473427 ^ (long)1290473468);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1353378447 ^ (long)-1353378509);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1517548889 ^ (long)1517548977);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1637613486 ^ (long)-1637613477);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1039242655 ^ (long)-1039242707);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-397056093 ^ (long)-397056199);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1937122358 ^ (long)1937122407);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-243422909 ^ (long)-243422772);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-570152482 ^ (long)-570152497);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)872884132 ^ (long)872884106);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)443329947 ^ (long)443329888);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1366311792 ^ (long)1366311799);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-343178158 ^ (long)-343178085);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-867762854 ^ (long)-867762859);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1573471871 ^ (long)1573471880);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)285666857 ^ (long)285666946);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1595453437 ^ (long)1595453301);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1958709018 ^ (long)-1958709218);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1750495686 ^ (long)1750495517);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1632317429 ^ (long)1632317192);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)200625247 ^ (long)200625290);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1848689491 ^ (long)-1848689608);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)995105780 ^ (long)995105577);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)183871301 ^ (long)183871272);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1395169853 ^ (long)-1395169861);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1558649943 ^ (long)1558649989);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1860383992 ^ (long)1860383794);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-397809343 ^ (long)-397809209);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)947284655 ^ (long)947284610);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)365895777 ^ (long)365895863);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)105325971 ^ (long)105325970);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)241731428 ^ (long)241731393);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1526979382 ^ (long)-1526979359);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)265382217 ^ (long)265382172);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)891335687 ^ (long)891335840);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)844456864 ^ (long)844456793);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1152044789 ^ (long)-1152044680);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1349523347 ^ (long)1349523229);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1497355197 ^ (long)-1497355021);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1447489933 ^ (long)1447490000);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1125961058 ^ (long)1125960971);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1806532297 ^ (long)-1806532218);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1589854999 ^ (long)1589855211);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)201307686 ^ (long)201307683);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-2056139414 ^ (long)-2056139318);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1641621006 ^ (long)-1641621226);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-199971069 ^ (long)-199971010);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-192527109 ^ (long)-192527139);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)78115986 ^ (long)78115920);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-225279589 ^ (long)-225279653);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-696059910 ^ (long)-696059926);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)547050758 ^ (long)547050900);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-2104486345 ^ (long)-2104486150);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1173210006 ^ (long)-1173209968);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)658486089 ^ (long)658486029);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1047223073 ^ (long)1047223150);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)253108745 ^ (long)253108838);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)2082595249 ^ (long)2082595276);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-564167928 ^ (long)-564167817);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1766426874 ^ (long)1766426638);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1530623160 ^ (long)1530622983);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1507212078 ^ (long)-1507212109);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1221718944 ^ (long)1221718816);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-2106977837 ^ (long)-2106977967);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1200600427 ^ (long)1200600540);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-515760773 ^ (long)-515760885);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)540821660 ^ (long)540821555);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1098499507 ^ (long)-1098499576);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1067862001 ^ (long)1067861808);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-901119051 ^ (long)-901119082);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1278084554 ^ (long)-1278084605);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)935672933 ^ (long)935673006);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1719403690 ^ (long)1719403688);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)66627227 ^ (long)66627235);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)184052633 ^ (long)184052688);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-974619925 ^ (long)-974620019);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1712436172 ^ (long)1712436043);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-856741873 ^ (long)-856741800);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1772446400 ^ (long)-1772446461);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1066988672 ^ (long)-1066988632);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1582779377 ^ (long)1582779240);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)610921052 ^ (long)610921091);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-2138341148 ^ (long)-2138341238);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1940182315 ^ (long)-1940182489);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1597583744 ^ (long)-1597583658);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)337600405 ^ (long)337600312);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-155916459 ^ (long)-155916459);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1016768706 ^ (long)-1016768712);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1549637027 ^ (long)1549637104);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1407376198 ^ (long)1407376202);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-879727396 ^ (long)-879727393);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)2030291964 ^ (long)2030291878);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1271936299 ^ (long)-1271936464);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1769468155 ^ (long)-1769468082);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)845521413 ^ (long)845521460);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)953042554 ^ (long)953042579);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1551084718 ^ (long)1551084676);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1317426715 ^ (long)-1317426922);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1542720888 ^ (long)1542720892);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)525709101 ^ (long)525709115);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1834047388 ^ (long)-1834047458);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-583472728 ^ (long)-583472673);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-898634579 ^ (long)-898634651);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)124245919 ^ (long)124246003);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)335167274 ^ (long)335167409);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-978616182 ^ (long)-978616136);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-987760752 ^ (long)-987760656);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1247125976 ^ (long)1247125885);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)548708959 ^ (long)548708922);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-365508986 ^ (long)-365509014);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-713312656 ^ (long)-713312566);
                    if (!1V.\u2003\u2004\u2003) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1078468119 ^ (long)1078468278);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)694138144 ^ (long)694138335)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)552688292 ^ (long)552707419)) >>> (int)((long)-1302868115 ^ (long)-1302868123)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)173820315 ^ (long)173820315);
            if (!1V.\u2003\u2004\u2003) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1866420400 ^ (long)-1866420398);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1417491725 ^ (long)-1417491728) | var5_6 << (int)((long)1748778713 ^ (long)1748778716)) ^ var3_4[var7_8]) & (int)((long)1282291888 ^ (long)1282291791);
                    if (1V.\u2003\u2004\u2003) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-941176675 ^ (long)-941176674) | var6_7 << (int)((long)-2021547388 ^ (long)-2021547391)) ^ var3_4[var7_8]) & (int)((long)599537504 ^ (long)599537567);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            1V.b[var2_3] = new String(var3_4).intern();
        }
        return 1V.b[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 1V.\u2003\u2004\u2003;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)-2034857644 ^ (long)-2034857642)];
            if (var7) break block16;
            var3_2 = (int)((long)-1035610037 ^ (long)-1035610037);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u7df9\u5553\u467c\u4e09\u7d67\u55c7\u4651\u4e99\u7d76\u55a6\u461e\u4ea9\u7d70\u5581\u4672\u4e6f\u7df3\u5514\u46a6\u4e14\u7da5\u551d\u4647\u4e97\u7d9d\u55a2\u46e2\u4ea4\u7d76\u55ad\u467e\u4e11\u7d0b\u55ef\u4674\u4eb2\u7d6b\u5576\u4610\u4ece\u7ddc\u55fb", -704423155);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)1306003173 ^ (long)1306003138);
            if (var7) break block16;
            var0_6 = (int)((long)391651336 ^ (long)-391651337);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-2001554191 ^ (long)2001554190);
                if (1V.\u2003\u2004\u2003) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!1V.\u2003\u2004\u2003) continue block8;
                            throw null;
                        }
                        1V.a = var5_1;
                        1V.b = new String[(int)((long)877315570 ^ (long)877315568)];
                        if (!1V.\u2003\u2004\u2003) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)-1308995126 ^ (long)-1308995126);
                v5 = (int)((long)-567633579 ^ (long)-567633564);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)151445406 ^ (long)151445407)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1857058706 ^ (long)-1857058711)) {
                                case 0: {
                                    v12 = (int)((long)2070475376 ^ (long)2070475274);
                                    if (!1V.\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)1264974576 ^ (long)1264974572);
                                    if (!1V.\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)1764161569 ^ (long)1764161604);
                                    if (!1V.\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)1966456491 ^ (long)1966456466);
                                    if (!1V.\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)-1285087536 ^ (long)-1285087575);
                                    if (!1V.\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)-1164033741 ^ (long)-1164033704);
                                    if (!1V.\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-150960010 ^ (long)-150960002);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!1V.\u2003\u2004\u2003);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!1V.\u2003\u2004\u2003) ** continue;
                throw null;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static 5C 6(float f, 9V ... vArray) {
        boolean bl = \u2003\u2004\u2003;
        if (bl || bl) return null;
        if (vArray.length <= 0) {
            if (bl || bl) return null;
            throw new RuntimeException(1V.a((int)((long)1780618998 ^ (long)-1780640082), (int)((long)25608803 ^ (long)25619564)) /* "At least one position must be supplied." */);
        }
        if (bl) return null;
        float f2 = Float.MAX_VALUE;
        if (bl) return null;
        float f3 = Float.MIN_VALUE;
        if (bl) return null;
        float f4 = Float.MAX_VALUE;
        if (bl) return null;
        float f5 = Float.MIN_VALUE;
        if (bl) return null;
        if (bl) return null;
        int n = vArray.length;
        if (bl) return null;
        int n2 = (int)((long)-1252094502 ^ (long)-1252094502);
        if (bl) return null;
        while (!bl) {
            if (n2 < n) {
                if (bl) return null;
                9V v = vArray[n2];
                f2 = Math.min(v.3, f2);
                if (bl || bl) return null;
                f3 = Math.max(v.3, f3);
                if (bl || bl) return null;
                f4 = Math.min(v.6, f4);
                if (bl || bl) return null;
                f5 = Math.max(v.6, f5);
                if (bl || bl) return null;
                ++n2;
                if (bl) return null;
                if (!\u2003\u2004\u2003) continue;
                throw null;
            }
            if (bl) return null;
            f2 -= f;
            if (bl || bl) return null;
            f3 += f;
            if (bl || bl) return null;
            f4 -= f;
            if (bl || bl) return null;
            f5 += f;
            if (!bl && !bl) return 1V.5(f4, f2, f5, f3);
        }
        return null;
    }

    public 1V(7t t) {
        boolean bl = \u2003\u2004\u2003;
        super(t, 1V.a((int)((long)1068148458 ^ (long)-1068161357), (int)((long)-824642695 ^ (long)824664906)) /* "2D" */, null);
        this.4 = new ArrayList<9V>();
        this.1 = new CopyOnWriteArrayList<5C>();
        this.7 = new Listener(r2 -> {
            block3: {
                block2: {
                    boolean bl = \u2003\u2004\u2003;
                    if (bl || bl) break block2;
                    RenderSystem.pushMatrix();
                    if (bl || bl) break block2;
                    RenderSystem.lineWidth((float)1.0f);
                    if (bl || bl) break block2;
                    r2 = 9b.5;
                    if (bl || bl) break block2;
                    9b.6((boolean)((long)-2001449209 ^ (long)-2001449210));
                    if (bl || bl) break block2;
                    GL11.glDisable((int)((int)((long)-710283950 ^ (long)-710285710)));
                    if (bl || bl) break block2;
                    4L[] lArray = new 4L[(int)((long)-1380210517 ^ (long)-1380210518)];
                    lArray[(int)((long)1874673238 ^ (long)1874673238)] = 4L.c;
                    9b.3(lArray);
                    if (bl || bl) break block2;
                    this.1.forEach(arg_0 -> 1V.4((Tessellator)r2, arg_0));
                    if (bl || bl) break block2;
                    9b.3();
                    if (bl || bl) break block2;
                    9b.6((boolean)((long)-690658056 ^ (long)-690658056));
                    if (bl || bl) break block2;
                    RenderSystem.popMatrix();
                    if (!bl && !bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)904751121 ^ (long)904751121)]);
        this.9 = new Listener(o -> {
            block3: {
                block2: {
                    boolean bl = \u2003\u2004\u2003;
                    if (bl || bl) break block2;
                    this.1.clear();
                    if (bl || bl) break block2;
                    6L.3(1V.3.r).sorted(Comparator.comparingDouble(arg_0 -> ((aqa)3.aa()).g(arg_0)).reversed()).filter(((7t)this.8)::1).forEach(object2 -> {
                        boolean bl = \u2003\u2004\u2003;
                        if (bl || bl) return;
                        2c c2 = (2c)3.ac();
                        if (bl || bl) return;
                        Object object3 = (2)object2;
                        o = object3.interpolate(((2_)o).3()).1(object3.getPos());
                        if (bl || bl) return;
                        o = object2.cc().d(((8S)object).9 - c2.getRenderPosX(), ((8S)object).1 - c2.getRenderPosY(), ((8S)object).2 - c2.getRenderPosZ());
                        if (bl || bl) return;
                        double d2 = ((dci)object).a;
                        8S s2 = (8S)this.6.get((int)((long)680560354 ^ (long)680560354));
                        ((8S)this.6.get((int)((long)680560354 ^ (long)680560354))).9 = d2;
                        if (bl || bl) return;
                        v0.1 = d2 = ((dci)object).b;
                        if (bl || bl) return;
                        s2.2 = ((dci)object).c;
                        if (bl || bl) return;
                        d2 = ((dci)object).d;
                        s2 = (8S)this.6.get((int)((long)-1525478659 ^ (long)-1525478660));
                        ((8S)this.6.get((int)((long)-1525478659 ^ (long)-1525478660))).9 = d2;
                        if (bl || bl) return;
                        v1.1 = d2 = ((dci)object).b;
                        if (bl || bl) return;
                        s2.2 = ((dci)object).c;
                        if (bl || bl) return;
                        d2 = ((dci)object).d;
                        s2 = (8S)this.6.get((int)((long)-9196418 ^ (long)-9196420));
                        ((8S)this.6.get((int)((long)-9196418 ^ (long)-9196420))).9 = d2;
                        if (bl || bl) return;
                        v2.1 = d2 = ((dci)object).b;
                        if (bl || bl) return;
                        s2.2 = ((dci)object).f;
                        if (bl || bl) return;
                        d2 = ((dci)object).a;
                        s2 = (8S)this.6.get((int)((long)-144756754 ^ (long)-144756755));
                        ((8S)this.6.get((int)((long)-144756754 ^ (long)-144756755))).9 = d2;
                        if (bl || bl) return;
                        v3.1 = d2 = ((dci)object).b;
                        if (bl || bl) return;
                        s2.2 = ((dci)object).f;
                        if (bl || bl) return;
                        d2 = ((dci)object).a;
                        s2 = (8S)this.6.get((int)((long)2042288338 ^ (long)2042288342));
                        ((8S)this.6.get((int)((long)2042288338 ^ (long)2042288342))).9 = d2;
                        if (bl || bl) return;
                        v4.1 = d2 = ((dci)object).e;
                        if (bl || bl) return;
                        s2.2 = ((dci)object).c;
                        if (bl || bl) return;
                        d2 = ((dci)object).d;
                        s2 = (8S)this.6.get((int)((long)969690399 ^ (long)969690394));
                        ((8S)this.6.get((int)((long)969690399 ^ (long)969690394))).9 = d2;
                        if (bl || bl) return;
                        v5.1 = d2 = ((dci)object).e;
                        if (bl || bl) return;
                        s2.2 = ((dci)object).c;
                        if (bl || bl) return;
                        d2 = ((dci)object).d;
                        s2 = (8S)this.6.get((int)((long)-1548370224 ^ (long)-1548370218));
                        ((8S)this.6.get((int)((long)-1548370224 ^ (long)-1548370218))).9 = d2;
                        if (bl || bl) return;
                        v6.1 = d2 = ((dci)object).e;
                        if (bl || bl) return;
                        s2.2 = ((dci)object).f;
                        if (bl || bl) return;
                        d2 = ((dci)object).a;
                        s2 = (8S)this.6.get((int)((long)-517194090 ^ (long)-517194095));
                        ((8S)this.6.get((int)((long)-517194090 ^ (long)-517194095))).9 = d2;
                        if (bl || bl) return;
                        v7.1 = d2 = ((dci)object).e;
                        if (bl || bl) return;
                        s2.2 = ((dci)object).f;
                        if (bl || bl) return;
                        this.4.clear();
                        if (bl || bl) return;
                        this.6.forEach(s -> {
                            boolean bl;
                            block8: {
                                block7: {
                                    bl = \u2003\u2004\u2003;
                                    if (bl || bl) return;
                                    if ((s = 5K.8(s)) == null) break block7;
                                    if (bl) return;
                                    if (s.2 < 0.0) break block7;
                                    if (bl) return;
                                    if (!(s.2 >= 1.0001)) break block8;
                                    if (bl) return;
                                }
                                if (bl) return;
                                return;
                            }
                            if (bl) return;
                            this.4.add(new 9V(s.9, s.1));
                            if (!bl && !bl) return;
                        });
                        if (bl || bl) return;
                        if (this.4.size() <= 0) {
                            if (bl || bl) return;
                            return;
                        }
                        if (bl) return;
                        9V[] vArray = this.4.toArray(new 9V[(int)((long)1088894049 ^ (long)1088894049)]);
                        if (bl || bl) return;
                        o = 1V.6(0.0f, vArray);
                        1V.6(0.0f, vArray).8 = ((7t)this.8).9((aqa)object2);
                        if (bl || bl) return;
                        5C c3 = 1V.6(-1.0f, ((5C)object).9);
                        1V.6(-1.0f, ((5C)object).9).8 = Color.black.getRGB();
                        if (bl || bl) return;
                        object3 = 1V.6(1.0f, ((5C)object).9);
                        1V.6(1.0f, ((5C)object).9).8 = Color.black.getRGB();
                        if (bl || bl) return;
                        5C[] cArray = new 5C[(int)((long)-860145027 ^ (long)-860145026)];
                        cArray[(int)((long)-1924464530 ^ (long)-1924464530)] = o;
                        cArray[(int)((long)558962603 ^ (long)558962602)] = c3;
                        cArray[(int)((long)1561844891 ^ (long)1561844889)] = object3;
                        this.1.addAll(Arrays.asList(cArray));
                        if (bl || bl) return;
                        if (object2 instanceof aqm) {
                            if (bl || bl) return;
                            aqm aqm2 = (aqm)object2;
                            if (bl || bl) return;
                            float f = ((5C)object).9[(int)((long)-1775675594 ^ (long)-1775675594)].3;
                            if (bl || bl) return;
                            float f2 = ((5C)object).9[(int)((long)-1628769193 ^ (long)-1628769195)].3;
                            if (bl || bl) return;
                            float f3 = ((5C)object).9[(int)((long)1569723392 ^ (long)1569723392)].6 - 4.0f;
                            if (bl || bl) return;
                            float f4 = Math.min(aqm2.dk(), aqm2.dx());
                            if (bl || bl) return;
                            float f5 = aqm2.dx();
                            if (bl || bl) return;
                            f4 /= f5;
                            if (bl || bl) return;
                            5C c4 = 1V.5(f3, f, f3, f2);
                            1V.5(f3, f, f3, f2).8 = 94.3(aqm2);
                            if (bl || bl) return;
                            5C c5 = 1V.6(1.0f, c4.9);
                            1V.6(1.0f, c4.9).8 = Color.black.getRGB();
                            if (bl || bl) return;
                            float f6 = f2;
                            5C c6 = 1V.5(f3, f, f3, f6 - (f6 - f) * f4);
                            1V.5(f3, f, f3, f6 - (f6 - f) * f4).8 = Color.black.getRGB();
                            if (bl || bl) return;
                            5C[] cArray2 = new 5C[(int)((long)714317604 ^ (long)714317607)];
                            cArray2[(int)((long)-1702857720 ^ (long)-1702857720)] = c4;
                            cArray2[(int)((long)1980245949 ^ (long)1980245948)] = c5;
                            cArray2[(int)((long)401976682 ^ (long)401976680)] = c6;
                            this.1.addAll(Arrays.asList(cArray2));
                            if (bl) return;
                        }
                        if (!bl) return;
                    });
                    if (!bl && !bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)1800921307 ^ (long)1800921307)]);
        this.6 = ImmutableList.copyOf((Collection)IntStream.range((int)((long)215011398 ^ (long)215011398), (int)((long)2120793264 ^ (long)2120793272)).mapToObj(n -> {
            boolean bl = \u2003\u2004\u2003;
            if (bl || bl) {
                return null;
            }
            return new 8S();
        }).collect(Collectors.toList()));
    }
}

