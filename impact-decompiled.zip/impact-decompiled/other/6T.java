/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  dfm
 *  dku
 *  k
 *  vk
 */
package net.impactclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Optional;
import me.zero.clarinet.hook.mixin.accessor.AccessorFontRenderer;
import net.impactclient.2a;
import net.impactclient.2n;
import net.impactclient.2w$6X;
import net.impactclient.3sH;
import net.impactclient.6C;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 6T
extends 6C {
    private static final String[] b;
    private static final String[] a;
    public static final boolean \u200c;

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 6T.\u200c;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)-741511562 ^ (long)-741511564)];
            if (var7) break block16;
            var3_2 = (int)((long)362602889 ^ (long)362602889);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u84f0\uadc7\ube92\ub683\u84fd\uad55\ubecf\ub6c7\u8483\uad8a\ube6f\ub684", -270490753);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)1041587260 ^ (long)1041587258);
            if (var7) break block16;
            var0_6 = (int)((long)-520701647 ^ (long)520701646);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-1852726341 ^ (long)1852726340);
                if (6T.\u200c) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!6T.\u200c) continue block8;
                            throw null;
                        }
                        6T.a = var5_1;
                        6T.b = new String[(int)((long)2038252421 ^ (long)2038252423)];
                        if (!6T.\u200c) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)-740162623 ^ (long)-740162623);
                v5 = (int)((long)1469941039 ^ (long)1469941112);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)1114425001 ^ (long)1114425000)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-389778613 ^ (long)-389778612)) {
                                case 0: {
                                    v12 = (int)((long)-577406948 ^ (long)-577406939);
                                    if (!6T.\u200c) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)713748230 ^ (long)713748268);
                                    if (!6T.\u200c) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)236605958 ^ (long)236606052);
                                    if (!6T.\u200c) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)869429353 ^ (long)869429295);
                                    if (!6T.\u200c) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)1671462773 ^ (long)1671462682);
                                    if (!6T.\u200c) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)-1470146902 ^ (long)-1470146878);
                                    if (!6T.\u200c) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-1056661254 ^ (long)-1056661264);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!6T.\u200c);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!6T.\u200c) ** continue;
                throw null;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 6T.\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)645455675 ^ (long)-645440200)) & (int)((long)-1420085854 ^ (long)-1420047779);
            if (var9_2) ** GOTO lbl-1000
            if (6T.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 6T.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-635543904 ^ (long)-635543904)] & (int)((long)-134534841 ^ (long)-134534728)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)97042476 ^ (long)97042577);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-916864908 ^ (long)-916864992);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1522397830 ^ (long)1522397897);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)880460973 ^ (long)880460864);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-237142716 ^ (long)-237142623);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)224747342 ^ (long)224747422);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1912852845 ^ (long)1912852790);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1896941647 ^ (long)1896941636);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-768898532 ^ (long)-768898504);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-883323176 ^ (long)-883323178);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1725663776 ^ (long)1725663909);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)801744935 ^ (long)801745071);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1426248449 ^ (long)-1426248544);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-2083389230 ^ (long)-2083389210);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1417563448 ^ (long)1417563571);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-2110658517 ^ (long)-2110658493);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1971369510 ^ (long)-1971369476);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1089589373 ^ (long)-1089589451);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)389632280 ^ (long)389632274);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-828971182 ^ (long)-828971239);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-938123634 ^ (long)-938123768);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-225708889 ^ (long)-225709045);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-405170240 ^ (long)-405170287);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1756160595 ^ (long)-1756160600);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)2078231369 ^ (long)2078231518);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1625049716 ^ (long)-1625049806);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1258997716 ^ (long)-1258997748);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1049779209 ^ (long)1049779323);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1297412895 ^ (long)-1297412868);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1698824909 ^ (long)1698824777);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1648257601 ^ (long)-1648257559);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)812946040 ^ (long)812946073);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1744919980 ^ (long)1744920027);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-323495588 ^ (long)-323495433);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-343799341 ^ (long)-343799515);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-335311978 ^ (long)-335312042);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)653552545 ^ (long)653552612);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1873263112 ^ (long)1873263163);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-763660204 ^ (long)-763660117);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-677347422 ^ (long)-677347388);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-519168385 ^ (long)-519168349);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1847883990 ^ (long)-1847883815);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1471564153 ^ (long)1471564163);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1499341990 ^ (long)1499342043);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1490543045 ^ (long)1490542935);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-599686228 ^ (long)-599686280);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1819317862 ^ (long)-1819318004);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-2147405073 ^ (long)-2147405189);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-754949722 ^ (long)-754949667);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1726564766 ^ (long)1726564788);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)23164313 ^ (long)23164192);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)320789695 ^ (long)320789668);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1854247392 ^ (long)-1854247402);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-213013999 ^ (long)-213013906);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)798602144 ^ (long)798602150);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-790304504 ^ (long)-790304268);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-497059374 ^ (long)-497059535);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1705901366 ^ (long)-1705901326);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1317732883 ^ (long)1317733111);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1225140059 ^ (long)-1225140150);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1487880461 ^ (long)1487880477);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)272268908 ^ (long)272268960);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1211393412 ^ (long)-1211393333);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1644259194 ^ (long)1644259301);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)452098735 ^ (long)452098598);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)903781366 ^ (long)903781345);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)314805274 ^ (long)314805307);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)183724495 ^ (long)183724513);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1733566424 ^ (long)1733566413);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)199775929 ^ (long)199775752);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1506384395 ^ (long)1506384538);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1708559182 ^ (long)1708559178);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-523360822 ^ (long)-523360924);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1512920808 ^ (long)-1512920684);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1481826104 ^ (long)1481826301);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1848674051 ^ (long)-1848674304);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1978180770 ^ (long)1978180773);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1674445547 ^ (long)-1674445539);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)345149848 ^ (long)345149699);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-785148547 ^ (long)-785148548);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)737183315 ^ (long)737183330);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1050613516 ^ (long)1050613650);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1414774862 ^ (long)-1414774950);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-282601265 ^ (long)-282601333);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1515089458 ^ (long)-1515089469);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)348917369 ^ (long)348917498);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)2013500758 ^ (long)2013500829);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1682111951 ^ (long)1682111997);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)207248721 ^ (long)207248799);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-636705593 ^ (long)-636705554);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)524939096 ^ (long)524939124);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1965620839 ^ (long)1965620828);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1041612083 ^ (long)-1041612121);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1827357871 ^ (long)1827357898);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)778992383 ^ (long)778992148);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-45413265 ^ (long)-45413250);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)229342042 ^ (long)229342195);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1574789960 ^ (long)-1574790023);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-2087174633 ^ (long)-2087174472);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1450280749 ^ (long)1450280881);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1536571773 ^ (long)1536571652);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)59482295 ^ (long)59482281);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-397076979 ^ (long)-397076961);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-694989584 ^ (long)-694989645);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1960429256 ^ (long)1960429075);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1857319319 ^ (long)1857319221);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1253939687 ^ (long)1253939479);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)673696166 ^ (long)673696021);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1170284958 ^ (long)1170284911);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1229951637 ^ (long)-1229951641);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1846072760 ^ (long)-1846072776);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)553439806 ^ (long)553439948);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-2131707807 ^ (long)-2131707738);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1451875677 ^ (long)-1451875799);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)773705814 ^ (long)773705926);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)741855034 ^ (long)741855184);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1993167222 ^ (long)1993167162);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-2077520866 ^ (long)-2077520772);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1686749035 ^ (long)1686748928);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-677087953 ^ (long)-677087933);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1485093770 ^ (long)-1485093857);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)534623281 ^ (long)534623483);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1153327657 ^ (long)1153327771);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1677550813 ^ (long)1677550757);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1794278637 ^ (long)1794278498);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1650410818 ^ (long)1650410768);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)911661515 ^ (long)911661334);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1381914185 ^ (long)-1381914229);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1967279964 ^ (long)-1967280047);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)999985571 ^ (long)999985578);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)2041309066 ^ (long)2041308969);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)322735257 ^ (long)322735168);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)2025771159 ^ (long)2025771236);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1589612805 ^ (long)-1589612871);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-2127039964 ^ (long)-2127039776);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-109284025 ^ (long)-109284028);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1759245227 ^ (long)-1759245124);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1116367900 ^ (long)-1116368009);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)459134236 ^ (long)459134354);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1351258687 ^ (long)-1351258873);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-262350032 ^ (long)-262349977);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1070956807 ^ (long)1070956865);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)700156446 ^ (long)700156575);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)735603054 ^ (long)735603188);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1528633475 ^ (long)1528633552);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1127332128 ^ (long)-1127332280);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)376269580 ^ (long)376269737);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-185515749 ^ (long)-185515646);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-783994804 ^ (long)-783994693);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1994392792 ^ (long)1994392806);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1417702154 ^ (long)1417702239);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)382974536 ^ (long)382974581);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-34226188 ^ (long)-34226259);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1241052650 ^ (long)-1241052662);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1501950378 ^ (long)1501950290);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1416646704 ^ (long)-1416646808);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-494379412 ^ (long)-494379496);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)833512203 ^ (long)833512372);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1255825899 ^ (long)-1255825870);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)932905406 ^ (long)932905273);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1800597792 ^ (long)-1800597871);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-130293068 ^ (long)-130293228);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)2113060336 ^ (long)2113060182);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1117438314 ^ (long)1117438416);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1535669610 ^ (long)-1535669693);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-2139507767 ^ (long)-2139507913);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1192905395 ^ (long)1192905460);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-93129128 ^ (long)-93129030);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1706051995 ^ (long)1706051889);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-758651492 ^ (long)-758651483);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1495079787 ^ (long)-1495079913);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-240637476 ^ (long)-240637453);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-2026633768 ^ (long)-2026633852);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)102998938 ^ (long)102998861);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1898377548 ^ (long)1898377562);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)234891725 ^ (long)234891661);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1952309831 ^ (long)-1952309909);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-359303389 ^ (long)-359303389);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)3200654 ^ (long)3200752);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1057099259 ^ (long)1057099171);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)711706691 ^ (long)711706677);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-782665979 ^ (long)-782665955);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-986732693 ^ (long)-986732741);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)972333533 ^ (long)972333447);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-381061998 ^ (long)-381061925);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1983231117 ^ (long)1983231214);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1546834347 ^ (long)-1546834401);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)75053979 ^ (long)75053871);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1932432198 ^ (long)1932432277);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)2027180957 ^ (long)2027181042);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-529678962 ^ (long)-529679054);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1413526719 ^ (long)-1413526678);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)2051718157 ^ (long)2051718243);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1884095404 ^ (long)-1884095424);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1909187122 ^ (long)-1909187200);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1102433470 ^ (long)-1102433489);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-964443596 ^ (long)-964443516);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)772937402 ^ (long)772937255);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1528996487 ^ (long)1528996570);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-542523068 ^ (long)-542523042);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1579021225 ^ (long)-1579021138);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1111722022 ^ (long)-1111722074);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1863854023 ^ (long)1863853829);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1163668066 ^ (long)-1163668152);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1741296322 ^ (long)-1741296269);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1081492544 ^ (long)-1081492572);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1994329038 ^ (long)-1994328875);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1283153809 ^ (long)1283153852);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)775103152 ^ (long)775103145);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1494408366 ^ (long)-1494408336);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-566169568 ^ (long)-566169595);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1719611451 ^ (long)-1719611576);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)758072693 ^ (long)758072698);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1476306645 ^ (long)-1476306607);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1553098989 ^ (long)-1553098996);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1270416702 ^ (long)-1270416777);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)868055028 ^ (long)868054972);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-184959606 ^ (long)-184959575);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1380717192 ^ (long)1380717160);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1441915198 ^ (long)-1441915305);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)2054725875 ^ (long)2054725714);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)580296677 ^ (long)580296592);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1358831732 ^ (long)-1358831684);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-2071170982 ^ (long)-2071171068);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1721911224 ^ (long)1721911143);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)10520244 ^ (long)10520276);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)2028359617 ^ (long)2028359526);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-771087877 ^ (long)-771088091);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1977088280 ^ (long)1977088464);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1719271147 ^ (long)1719271124);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-65183362 ^ (long)-65183234);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-2098410493 ^ (long)-2098410290);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-81083633 ^ (long)-81083497);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)714647319 ^ (long)714647300);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)187022344 ^ (long)187022566);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1888253817 ^ (long)1888253878);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-404142292 ^ (long)-404142121);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-2078725578 ^ (long)-2078725620);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1930865120 ^ (long)-1930865129);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)942381365 ^ (long)942381454);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1639502940 ^ (long)1639503034);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-959330575 ^ (long)-959330672);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1058308325 ^ (long)1058308168);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1784169774 ^ (long)-1784169776);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)501256145 ^ (long)501255973);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)763972964 ^ (long)763972867);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)358160329 ^ (long)358160165);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1659876306 ^ (long)1659876104);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)979738951 ^ (long)979739030);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1299626968 ^ (long)-1299627008);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1976352080 ^ (long)1976352136);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-746665688 ^ (long)-746665588);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1124050497 ^ (long)-1124050434);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1039609728 ^ (long)1039609781);
                    if (!6T.\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1481113724 ^ (long)1481113791);
                    if (!6T.\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)39654712 ^ (long)39654897);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1758954942 ^ (long)-1758954819)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-2019057922 ^ (long)-2019073791)) >>> (int)((long)1278888068 ^ (long)1278888076)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1078676230 ^ (long)1078676230);
            if (!6T.\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1542469261 ^ (long)-1542469263);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1111658793 ^ (long)1111658794) | var5_6 << (int)((long)-1909952666 ^ (long)-1909952669)) ^ var3_4[var7_8]) & (int)((long)-916815744 ^ (long)-916815745);
                    if (6T.\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-355630417 ^ (long)-355630420) | var6_7 << (int)((long)-145733580 ^ (long)-145733583)) ^ var3_4[var7_8]) & (int)((long)296366612 ^ (long)296366827);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            6T.b[var2_3] = new String(var3_4).intern();
        }
        return 6T.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 4(dfm dfm2, dku dku2) {
        block5: {
            block2: {
                int n;
                String string;
                boolean bl;
                block4: {
                    String string2;
                    String string3;
                    3sH sH;
                    block3: {
                        bl = \u200c;
                        if (bl || bl) break block2;
                        sH = 2a.7();
                        Optional<vk> optional = sH.6.7();
                        string3 = 6T.a((int)((long)-225698506 ^ (long)225681205), (int)((long)2013312441 ^ (long)-2013305400)) /* "Impact" */;
                        if (bl || bl) break block2;
                        string = k.h + 6T.a((int)((long)80692847 ^ (long)-80690067), (int)((long)1565668592 ^ (long)-1565679912)) /* "4.9.1" */;
                        if (bl || bl) break block2;
                        string2 = sH.6.1();
                        if (bl || bl) break block2;
                        n = (int)((long)654389698 ^ (long)654389698);
                        if (bl) return;
                        if (bl) break block2;
                        RenderSystem.enableTexture();
                        if (bl || bl) break block2;
                        if (!optional.isPresent()) break block3;
                        if (bl || bl) break block2;
                        n = (((AccessorFontRenderer)dku2).getFontHeight() - (int)((long)1953691648 ^ (long)1953691656)) / (int)((long)-1050124720 ^ (long)-1050124718);
                        if (bl || bl) break block2;
                        2n.7(optional.get(), (int)((long)-1579404565 ^ (long)-1579404565), n, (int)((long)-1945409011 ^ (long)-1945409019));
                        if (bl || bl) break block2;
                        n = (int)((long)-1445222702 ^ (long)-1445222696);
                        if (bl) return;
                    }
                    if (bl) break block2;
                    dku2.a(dfm2, string3, (float)n, 0.0f, (int)((long)373094714 ^ (long)-379692034));
                    if (bl || bl) break block2;
                    n += dku2.b(string3);
                    if (bl || bl) break block2;
                    n += 2;
                    if (bl || bl) break block2;
                    if (string2.isEmpty()) break block4;
                    if (bl || bl) break block2;
                    int n2 = sH.6.3().orElse((int)((long)1045358799 ^ (long)-1045358800));
                    if (bl || bl) break block2;
                    string2 = 2w$6X.KAOZ("\u180d", -2136916185).concat(String.valueOf(string2));
                    if (bl || bl) break block2;
                    this.2(dfm2, dku2, string2, n, 0.0f, n2);
                    if (bl || bl) break block2;
                    n += dku2.b(string2);
                    if (bl || bl) break block2;
                    n += 4;
                    if (bl) break block2;
                }
                if (bl) break block2;
                dku2.a(dfm2, string, (float)n, 0.0f, (int)((long)-1304119145 ^ (long)1304119144));
                if (bl || bl) break block2;
                n += dku2.b(string);
                if (bl || bl) break block2;
                this.0 = n;
                if (bl || bl) break block2;
                this.2 = ((AccessorFontRenderer)dku2).getFontHeight();
                if (!bl && !bl) break block5;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 6T() {
        boolean bl = \u200c;
        if (bl) {
            return;
        }
    }
}

