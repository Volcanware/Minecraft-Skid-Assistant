/*
 * Decompiled with CFR 0.152.
 */
package net.impactclient;

import java.util.List;
import net.impactclient.2w$6X;
import net.impactclient.3p;
import net.impactclient.5X;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class 5B {
    private Class<?> 7;
    public static final boolean \u2003\u2007\u200e\u200d\u200e\u2001\u2001;
    private static final String[] b;
    private static final 5B 0;
    private Object 8;
    private static final String[] a;

    /*
     * Unable to fully structure code
     */
    static {
        block18: {
            block17: {
                var7 = 5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001;
                if (!var7) break block17;
                break block18;
            }
            var5_1 = new String[(int)((long)308679370 ^ (long)308679369)];
            if (var7) break block18;
            var3_2 = (int)((long)1896806401 ^ (long)1896806401);
            if (var7) break block18;
            var2_3 = 2w$6X.KAOZ("\u9803\ub01c\ua316\uaba8\u98af\ub032\ua302\uab68\u98dc\ub008\ua343\uab3a\u980a\ub0cd\ua3a1\uaba6\u9891\ub024\ua38c\uabeb\u98af\ub0d1\ua3a6\uab63\u9807\ub00a\ua3b5\uabcd\u988c\ub0b7\ua3d5\uab9c\u9882\ub091\ua3a3\uab7b\u98c7\ub07e\ua3e0\uab64\u9885\ub0e5\ua3ec\uabb4\u9850\ub0ac\ua3d8\uab18\u9830\ub08a\ua367\uab4c\u9823\ub0e1\ua3d7\uaba8\u983d\ub0fe\ua3f9\uab98\u984d\ub0dd\ua3a2\uab9d\u98c2\ub08b\ua3cd\uabc0", -422003099);
            var4_4 = var2_3.length();
            if (var7) break block18;
            var1_5 = (int)((long)2062298045 ^ (long)2062298003);
            if (var7) break block18;
            var0_6 = (int)((long)-119013787 ^ (long)119013786);
            if (var7) break block18;
            block8: while (!var7) {
                block15: {
                    v0 = ++var0_6;
                    v1 = (int)((long)-11022531 ^ (long)11022530);
                    if (5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) {
                        throw null;
                        while (true) {
                            var5_1[var3_2++] = new String(v2).intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) continue block8;
                                throw null;
                            }
                            5B.a = var5_1;
                            5B.b = new String[(int)((long)1215350567 ^ (long)1215350564)];
                            if (5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) {
                                throw null;
                            }
                            break block15;
                            break;
                        }
                    }
                    v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                    v4 = v3.length;
                    var6_7 = (int)((long)571664926 ^ (long)571664926);
                    v5 = (int)((long)-29383192 ^ (long)-29383176);
                    v6 = v3;
                    v7 = v4;
                    if (v4 > (int)((long)-871757805 ^ (long)-871757806)) ** GOTO lbl88
                    do {
                        block16: {
                            v8 = v5;
                            v6 = v6;
                            v9 = v6;
                            v10 = v5;
                            v11 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-399163714 ^ (long)-399163719)) {
                                    case 0: {
                                        v12 = (int)((long)-510692530 ^ (long)-510692566);
                                        if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v12 = (int)((long)-1071294584 ^ (long)-1071294492);
                                        if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v12 = (int)((long)-1319635857 ^ (long)-1319635945);
                                        if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v12 = (int)((long)-475256767 ^ (long)-475256785);
                                        if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v12 = (int)((long)496595317 ^ (long)496595252);
                                        if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v12 = (int)((long)-1441904713 ^ (long)-1441904747);
                                        if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                                        throw null;
                                    }
                                    default: {
                                        v12 = (int)((long)1093985151 ^ (long)1093985115);
                                    }
                                }
                                v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                                ++var6_7;
                                v5 = v8;
                                if (v8 != 0) break block16;
                                v8 = v5;
                                v6 = v6;
                                v11 = v5;
                                v9 = v6;
                                v10 = v5;
                            } while (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001);
                            throw null;
                        }
                        v2 = v6;
                        v7 = v7;
                    } while (v7 > var6_7);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) ** continue;
                    throw null;
                }
                5B.0 = new 5B();
                break;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1922361262 ^ (long)1922362495)) & (int)((long)2028377203 ^ (long)2028366732);
            if (var9_2) ** GOTO lbl-1000
            if (5B.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 5B.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1555105491 ^ (long)-1555105491)] & (int)((long)21671526 ^ (long)21671577)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1142127672 ^ (long)-1142127684);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)2120948999 ^ (long)2120949129);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1724658831 ^ (long)-1724658780);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1449852896 ^ (long)1449852878);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)65443546 ^ (long)65443414);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1422843017 ^ (long)-1422843087);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1561935093 ^ (long)1561935035);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1077223718 ^ (long)1077223930);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-622075310 ^ (long)-622075235);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)32161630 ^ (long)32161690);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-370330521 ^ (long)-370330379);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1245486651 ^ (long)-1245486782);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)2111935313 ^ (long)2111935268);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1676199948 ^ (long)-1676199941);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-177509955 ^ (long)-177510006);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)541965711 ^ (long)541965722);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1565682266 ^ (long)1565682227);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1128098234 ^ (long)1128098147);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1302152324 ^ (long)1302152225);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-2043294348 ^ (long)-2043294247);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1403803723 ^ (long)1403803681);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1873924678 ^ (long)-1873924822);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1007486037 ^ (long)-1007486033);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1751641015 ^ (long)1751640905);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)277292383 ^ (long)277292455);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1596524908 ^ (long)1596524958);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-840778851 ^ (long)-840778998);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1078270547 ^ (long)-1078270495);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1991978890 ^ (long)1991978837);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1490063091 ^ (long)1490062993);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1251043284 ^ (long)-1251043235);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1262521915 ^ (long)1262522106);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1437091725 ^ (long)1437091732);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1724449172 ^ (long)1724449158);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-118331771 ^ (long)-118331716);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)36727407 ^ (long)36727412);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1008199797 ^ (long)1008199900);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)660014361 ^ (long)660014486);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1350355875 ^ (long)-1350355852);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-733393961 ^ (long)-733394140);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1106999952 ^ (long)1107000032);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)886816747 ^ (long)886816577);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-123866234 ^ (long)-123866349);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)261524332 ^ (long)261524262);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1246515441 ^ (long)1246515402);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1550552378 ^ (long)-1550552331);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)297823431 ^ (long)297823374);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)705695869 ^ (long)705695944);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)48549834 ^ (long)48549803);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-2108184563 ^ (long)-2108184442);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1923490409 ^ (long)1923490527);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)588913621 ^ (long)588913628);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1666708529 ^ (long)-1666708548);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1135206487 ^ (long)1135206516);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1273760854 ^ (long)-1273761011);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)914501878 ^ (long)914501846);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1818947731 ^ (long)1818947798);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1553173689 ^ (long)-1553173578);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)940565393 ^ (long)940565336);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1911962421 ^ (long)1911962472);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-137490819 ^ (long)-137490852);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)880283684 ^ (long)880283858);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-516212159 ^ (long)-516212034);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-2010559779 ^ (long)-2010559985);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1635439376 ^ (long)1635439520);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1655061510 ^ (long)-1655061551);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1647512521 ^ (long)-1647512493);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1709224526 ^ (long)-1709224495);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1309127527 ^ (long)1309127641);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1548092516 ^ (long)-1548092547);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-836338098 ^ (long)-836338081);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-606345901 ^ (long)-606345973);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)228456432 ^ (long)228456223);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-694496324 ^ (long)-694496269);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1180233702 ^ (long)-1180233615);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-2129170667 ^ (long)-2129170452);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)498846412 ^ (long)498846389);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-2009422724 ^ (long)-2009422665);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1150469002 ^ (long)-1150468913);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-260330945 ^ (long)-260330844);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1199449233 ^ (long)1199449097);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1706465729 ^ (long)1706465769);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1127702532 ^ (long)-1127702629);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1415134610 ^ (long)-1415134467);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1712442846 ^ (long)-1712442733);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)614990562 ^ (long)614990493);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1000501366 ^ (long)-1000501382);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)2001260629 ^ (long)2001260769);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1654808112 ^ (long)1654808087);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-908622057 ^ (long)-908622000);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)160268587 ^ (long)160268619);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1600902997 ^ (long)-1600902944);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1130327729 ^ (long)-1130327769);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-2059612137 ^ (long)-2059612133);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)2140350124 ^ (long)2140350143);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)719634443 ^ (long)719634507);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1018404982 ^ (long)-1018405049);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-587995484 ^ (long)-587995560);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1538324673 ^ (long)1538324611);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1772024710 ^ (long)-1772024796);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)61877264 ^ (long)61877312);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1026929251 ^ (long)1026929375);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)94360501 ^ (long)94360335);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-416936692 ^ (long)-416936570);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-719827142 ^ (long)-719827188);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1139389960 ^ (long)-1139390088);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1967610864 ^ (long)1967610821);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)732978569 ^ (long)732978452);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1303813971 ^ (long)-1303813930);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)852274399 ^ (long)852274213);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)2055738718 ^ (long)2055738632);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)522463482 ^ (long)522463331);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-914283521 ^ (long)-914283570);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)336296582 ^ (long)336296683);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)2070136593 ^ (long)2070136727);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)978408485 ^ (long)978408522);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-844686744 ^ (long)-844686613);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)713376348 ^ (long)713376433);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1691998200 ^ (long)1691998042);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1856168169 ^ (long)-1856168122);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-2110192630 ^ (long)-2110192413);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-134192177 ^ (long)-134192361);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1020395506 ^ (long)-1020395303);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)601141120 ^ (long)601141131);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)498858203 ^ (long)498858202);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)541148601 ^ (long)541148603);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1442531142 ^ (long)-1442531139);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1611233560 ^ (long)-1611233671);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1601718852 ^ (long)-1601718876);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1703040087 ^ (long)1703040081);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1456645203 ^ (long)-1456645232);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1252596096 ^ (long)1252596035);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)140625833 ^ (long)140625868);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1975800863 ^ (long)1975800896);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-719901611 ^ (long)-719901549);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-403720480 ^ (long)-403720670);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)904623129 ^ (long)904623305);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-103092065 ^ (long)-103092075);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-360127715 ^ (long)-360127535);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1699309772 ^ (long)-1699309648);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-556576322 ^ (long)-556576322);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1349577629 ^ (long)1349577609);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)702960862 ^ (long)702960890);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-2129224709 ^ (long)-2129224931);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)451178494 ^ (long)451178449);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1354977974 ^ (long)1354977958);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1317302954 ^ (long)1317302994);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1550906977 ^ (long)-1550907016);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1792484744 ^ (long)-1792484858);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1650648352 ^ (long)1650648472);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)758424004 ^ (long)758424010);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)826754911 ^ (long)826754843);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1014611619 ^ (long)1014611528);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)434634127 ^ (long)434634211);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-2011110596 ^ (long)-2011110630);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-605050837 ^ (long)-605050827);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-897125305 ^ (long)-897125317);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1667740872 ^ (long)1667740912);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1502652571 ^ (long)-1502652612);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1791909230 ^ (long)-1791909183);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)187309713 ^ (long)187309634);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1435879112 ^ (long)-1435878949);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)579756487 ^ (long)579756339);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)773809994 ^ (long)773809975);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-2120172275 ^ (long)-2120172227);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1813922138 ^ (long)-1813922284);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1598031272 ^ (long)1598031172);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-859070543 ^ (long)-859070573);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)901133233 ^ (long)901133285);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1334858702 ^ (long)-1334858525);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-51929903 ^ (long)-51929921);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1458742769 ^ (long)-1458742612);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1546908619 ^ (long)-1546908511);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-2046468136 ^ (long)-2046468208);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-643082095 ^ (long)-643082101);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)405742980 ^ (long)405742995);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-625745193 ^ (long)-625745157);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-250162035 ^ (long)-250162043);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-266934519 ^ (long)-266934437);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1190835832 ^ (long)-1190835771);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1847465005 ^ (long)1847465093);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-127872208 ^ (long)-127872203);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)677372188 ^ (long)677372294);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)701808706 ^ (long)701808693);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-89859706 ^ (long)-89859748);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)153615281 ^ (long)153615134);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-879021202 ^ (long)-879021106);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1077847110 ^ (long)1077847072);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-180734378 ^ (long)-180734356);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1061772627 ^ (long)-1061772653);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1385245612 ^ (long)-1385245482);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1432060670 ^ (long)-1432060516);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)320164589 ^ (long)320164460);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1301842595 ^ (long)-1301842509);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1239675546 ^ (long)-1239675448);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1069758380 ^ (long)-1069758243);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-617123248 ^ (long)-617123189);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1545346965 ^ (long)1545346901);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1814364677 ^ (long)1814364752);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1310275576 ^ (long)-1310275547);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)2068906228 ^ (long)2068906187);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-451905545 ^ (long)-451905560);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)302741670 ^ (long)302741550);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1343176629 ^ (long)-1343176522);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1920745310 ^ (long)1920745299);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-606994637 ^ (long)-606994488);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1563559628 ^ (long)1563559433);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-93742273 ^ (long)-93742111);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1043032542 ^ (long)-1043032513);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1868363148 ^ (long)-1868363133);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1981221630 ^ (long)1981221433);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-399932611 ^ (long)-399932511);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-855026345 ^ (long)-855026275);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)946548247 ^ (long)946548450);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-386782803 ^ (long)-386782831);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1091035273 ^ (long)-1091035245);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1746287549 ^ (long)-1746287418);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)62624378 ^ (long)62624475);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)924397413 ^ (long)924397522);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1100774163 ^ (long)1100774245);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1569721861 ^ (long)-1569721945);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-249479879 ^ (long)-249479787);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1575367516 ^ (long)-1575367551);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1389010485 ^ (long)-1389010655);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)671147109 ^ (long)671147179);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1934683509 ^ (long)1934683541);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)32832567 ^ (long)32832746);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-516619791 ^ (long)-516619908);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1254402574 ^ (long)1254402739);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-693169002 ^ (long)-693168916);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)300957645 ^ (long)300957582);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-314775861 ^ (long)-314775815);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)943369679 ^ (long)943369577);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1680297756 ^ (long)-1680297834);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)790347578 ^ (long)790347756);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)603206430 ^ (long)603206646);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)499326616 ^ (long)499326671);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1114854360 ^ (long)1114854243);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1370130969 ^ (long)1370130970);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1670147471 ^ (long)-1670147515);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1428536606 ^ (long)1428536628);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-836089434 ^ (long)-836089587);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-942784491 ^ (long)-942784272);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1749832561 ^ (long)1749832661);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1084879810 ^ (long)-1084879652);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1944166543 ^ (long)-1944166547);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)419124588 ^ (long)419124525);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-169426943 ^ (long)-169426854);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-2073175836 ^ (long)-2073175874);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)426826393 ^ (long)426826278);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1340071110 ^ (long)1340071120);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-610332732 ^ (long)-610332916);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1461455696 ^ (long)1461455814);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)712040262 ^ (long)712040409);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-312607358 ^ (long)-312607439);
                    if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1105277848 ^ (long)1105277772);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)786491165 ^ (long)786491362)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1747952843 ^ (long)-1747934006)) >>> (int)((long)-423259092 ^ (long)-423259100)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1390779670 ^ (long)1390779670);
            if (!5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-488868842 ^ (long)-488868844);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)2018249150 ^ (long)2018249149) | var5_6 << (int)((long)-1404590679 ^ (long)-1404590676)) ^ var3_4[var7_8]) & (int)((long)1286327619 ^ (long)1286327740);
                    if (5B.\u2003\u2007\u200e\u200d\u200e\u2001\u2001) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-2086701884 ^ (long)-2086701881) | var6_7 << (int)((long)2067429879 ^ (long)2067429874)) ^ var3_4[var7_8]) & (int)((long)465300290 ^ (long)465300413);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            5B.b[var2_3] = new String(var3_4).intern();
        }
        return 5B.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void 6() {
        boolean bl = \u2003\u2007\u200e\u200d\u200e\u2001\u2001;
        if (bl || bl) return;
        if (5X.9()) {
            if (bl) return;
            if (this.8 == null) {
                if (bl) return;
                try {
                    if (bl) return;
                    this.7 = Class.forName(5B.a((int)((long)1724129437 ^ (long)-1724132176), (int)((long)1290728546 ^ (long)-1290718528)) /* "net.minecraftforge.fml.common.FMLCommonHandler" */);
                    if (bl || bl) return;
                    this.8 = 3p.6(this.7, 5B.a((int)((long)-1791797448 ^ (long)1791795988), (int)((long)515803595 ^ (long)-515812309)) /* "instance" */, new Class[(int)((long)368471806 ^ (long)368471806)]).invoke(null, new Object[(int)((long)-629955559 ^ (long)-629955559)]);
                    if (bl || bl) return;
                    return;
                }
                catch (Exception exception) {
                    if (bl) return;
                }
            }
        }
        if (!bl) return;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean 8() {
        boolean bl = \u2003\u2007\u200e\u200d\u200e\u2001\u2001;
        if (bl || bl) return true;
        this.6();
        if (bl || bl) return true;
        if (5X.9()) {
            if (bl) return true;
            if (this.7 != null) {
                if (bl) return true;
                if (this.8 != null) {
                    if (bl) return true;
                    return (int)((long)-1961873530 ^ (long)-1961873529) != 0;
                }
            }
        }
        if (!bl) return (int)((long)2056186867 ^ (long)2056186867) != 0;
        return true;
    }

    public static 5B 6() {
        boolean bl = \u2003\u2007\u200e\u200d\u200e\u2001\u2001;
        if (bl || bl) {
            return null;
        }
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final List<String> 3() {
        boolean bl = \u2003\u2007\u200e\u200d\u200e\u2001\u2001;
        if (bl || bl) return null;
        if (this.8()) {
            if (bl) return null;
            try {
                if (bl) return null;
                Class[] classArray = new Class[(int)((long)-2000422542 ^ (long)-2000422541)];
                classArray[(int)((long)239310273 ^ (long)239310273)] = Boolean.TYPE;
                Object[] objectArray = new Object[(int)((long)-2050085764 ^ (long)-2050085763)];
                objectArray[(int)((long)2136036671 ^ (long)2136036671)] = Boolean.FALSE;
                return (List)3p.6(this.7, 5B.a((int)((long)-1655523225 ^ (long)1655524424), (int)((long)390998140 ^ (long)391016402)) /* "getBrandings" */, classArray).invoke(this.8, objectArray);
            }
            catch (Exception exception) {
                if (bl) return null;
            }
        }
        if (!bl) return null;
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private 5B() {
        boolean bl = \u2003\u2007\u200e\u200d\u200e\u2001\u2001;
        if (bl) {
            return;
        }
    }
}

