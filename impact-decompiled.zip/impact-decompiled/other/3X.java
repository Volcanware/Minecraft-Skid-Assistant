/*
 * Decompiled with CFR 0.152.
 */
package net.impactclient;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.impactclient.2v;
import net.impactclient.2w$6X;
import net.impactclient.3A;
import net.impactclient.3U;
import net.impactclient.3e;
import net.impactclient.3sk;
import net.impactclient.4d;
import net.impactclient.57;
import net.impactclient.7m;
import net.impactclient.8U;
import net.impactclient.8m;
import net.impactclient.9Z;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class 3X
extends 3e
implements 8U,
57 {
    private List<7m> 8;
    private static int 7;
    public static final boolean \u2001\u200e\u200b;
    private static final String[] c;
    private 7m 5;
    private final List<2v> 1;
    private static final String[] b;

    /*
     * Enabled aggressive block sorting
     */
    public final 7m 8() {
        int n;
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2001\u200e\u200b;
                    if (bl || bl) break block2;
                    this.2();
                    if (bl || bl) break block2;
                    n = this.8.indexOf(this.2());
                    if (bl || bl) break block2;
                    --n;
                    if (bl) break block2;
                    if (n >= 0) break block3;
                    if (bl || bl) break block2;
                    n = this.8.size() - (int)((long)-1831985478 ^ (long)-1831985477);
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return null;
        }
        return this.9(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final 7m 9(int n) {
        block3: {
            block2: {
                boolean bl = \u2001\u200e\u200b;
                if (bl || bl) break block2;
                this.2();
                if (!bl && !bl) break block3;
            }
            return null;
        }
        3X x2 = this;
        return x2.3(x2.8.get(n));
    }

    /*
     * Enabled aggressive block sorting
     */
    public final List<7m> 0() {
        block3: {
            block2: {
                boolean bl = \u2001\u200e\u200b;
                if (bl || bl) break block2;
                this.2();
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return new ArrayList<7m>(this.8);
    }

    public 3X(String string, String string2) {
        boolean bl = \u2001\u200e\u200b;
        this(string, string2, (int)((long)1822415418 ^ (long)-1822415419));
    }

    /*
     * Enabled aggressive block sorting
     */
    public final 7m 7(String string) {
        block3: {
            block2: {
                boolean bl = \u2001\u200e\u200b;
                if (bl || bl) break block2;
                this.2();
                if (!bl && !bl) break block3;
            }
            return null;
        }
        3X x2 = this;
        return x2.3(x2.9(string));
    }

    /*
     * Enabled aggressive block sorting
     */
    public final 7m 7() {
        int n;
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2001\u200e\u200b;
                    if (bl || bl) break block2;
                    this.2();
                    if (bl || bl) break block2;
                    n = this.8.indexOf(this.2());
                    if (bl || bl) break block2;
                    ++n;
                    if (bl) break block2;
                    if (n <= this.8.size() - (int)((long)378645037 ^ (long)378645036)) break block3;
                    if (bl || bl) break block2;
                    n = (int)((long)-1613873688 ^ (long)-1613873688);
                    if (bl) return null;
                }
                if (!bl) break block4;
            }
            return null;
        }
        return this.9(n);
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 3X.\u2001\u200e\u200b;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-862680332 ^ (long)-862678464)) & (int)((long)150524643 ^ (long)150482204);
            if (var9_2) ** GOTO lbl-1000
            if (3X.c[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3X.b[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)403894183 ^ (long)403894183)] & (int)((long)-487240222 ^ (long)-487240419)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)355021071 ^ (long)355021273);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-708358206 ^ (long)-708358372);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1396680227 ^ (long)-1396680214);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-447233351 ^ (long)-447233450);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)194465997 ^ (long)194465929);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1403966824 ^ (long)1403966805);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)673130266 ^ (long)673130491);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1933475490 ^ (long)1933475496);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-751689259 ^ (long)-751689286);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1246963707 ^ (long)1246963661);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1025577503 ^ (long)-1025577666);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-874985500 ^ (long)-874985720);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1213626324 ^ (long)1213626161);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1705820065 ^ (long)-1705820017);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)2086877328 ^ (long)2086877292);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1039764235 ^ (long)1039764243);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-2026415795 ^ (long)-2026415720);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1561579127 ^ (long)-1561579125);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-182474891 ^ (long)-182474772);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-294220537 ^ (long)-294220520);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)992334367 ^ (long)992334518);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1299882114 ^ (long)-1299882179);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1456433004 ^ (long)-1456433006);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1897018153 ^ (long)1897018272);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1655494106 ^ (long)-1655493966);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)913648306 ^ (long)913648290);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1939859855 ^ (long)1939859949);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1251910523 ^ (long)1251910460);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1636116448 ^ (long)1636116426);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)954801451 ^ (long)954801596);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1613079435 ^ (long)1613079331);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1585677116 ^ (long)-1585677222);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1819656753 ^ (long)-1819656895);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-2035296310 ^ (long)-2035296289);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)722064541 ^ (long)722064500);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)541373779 ^ (long)541373921);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1792998779 ^ (long)-1792998799);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-2067976165 ^ (long)-2067976151);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)9159233 ^ (long)9159311);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)505197206 ^ (long)505197140);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1505488577 ^ (long)1505488487);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-524451395 ^ (long)-524451451);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1030771300 ^ (long)-1030771419);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-375870965 ^ (long)-375870793);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1936932030 ^ (long)1936931968);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)2120786536 ^ (long)2120786528);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)609356382 ^ (long)609356403);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)2053572552 ^ (long)2053572394);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-633470110 ^ (long)-633470029);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)312494299 ^ (long)312494153);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1450320764 ^ (long)-1450320837);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1621438637 ^ (long)1621438625);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)421953603 ^ (long)421953785);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1852834300 ^ (long)1852834081);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1047811392 ^ (long)-1047811448);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-931927534 ^ (long)-931927329);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-381516273 ^ (long)-381516170);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-83561190 ^ (long)-83560995);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)237322977 ^ (long)237322817);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1551219952 ^ (long)1551219853);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)262999443 ^ (long)262999454);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-856385643 ^ (long)-856385667);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-698066778 ^ (long)-698066767);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-126878139 ^ (long)-126878122);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1126053397 ^ (long)1126053607);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)273151497 ^ (long)273151613);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)444018783 ^ (long)444018742);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1237904049 ^ (long)-1237904022);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1908142827 ^ (long)-1908142745);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)2083151430 ^ (long)2083151429);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)356338984 ^ (long)356338969);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)719637660 ^ (long)719637722);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-661353157 ^ (long)-661353080);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-174233766 ^ (long)-174233609);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-176605912 ^ (long)-176605769);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-756373374 ^ (long)-756373467);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)914067104 ^ (long)914067049);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1591288287 ^ (long)1591288155);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-246615445 ^ (long)-246615497);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-383026219 ^ (long)-383026345);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1125443635 ^ (long)-1125443784);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1744435242 ^ (long)1744435280);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1203539874 ^ (long)-1203539842);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-350174881 ^ (long)-350174799);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)662862738 ^ (long)662862830);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1836651806 ^ (long)1836651908);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1476378321 ^ (long)1476378309);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-818149055 ^ (long)-818148924);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)602449113 ^ (long)602449021);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-773799843 ^ (long)-773799786);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-793194010 ^ (long)-793194047);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-745963763 ^ (long)-745963680);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1637136850 ^ (long)1637136768);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1413873896 ^ (long)1413873894);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1899278251 ^ (long)1899278240);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-935552039 ^ (long)-935552104);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)682931283 ^ (long)682931344);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-415738517 ^ (long)-415738563);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-812235044 ^ (long)-812235072);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)717622506 ^ (long)717622344);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)241444365 ^ (long)241444556);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-152623394 ^ (long)-152623489);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1076338145 ^ (long)1076338167);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-215939875 ^ (long)-215940054);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)992536940 ^ (long)992536895);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1692795904 ^ (long)-1692795707);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)368940833 ^ (long)368941053);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1466482394 ^ (long)1466482211);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1904687400 ^ (long)1904687372);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-407674785 ^ (long)-407674815);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)693604839 ^ (long)693604724);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-2038121269 ^ (long)-2038121425);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-90297621 ^ (long)-90297714);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1223353535 ^ (long)-1223353397);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)2049425676 ^ (long)2049425877);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1553481285 ^ (long)1553481343);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-770913890 ^ (long)-770914042);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)10818622 ^ (long)10818691);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1130930407 ^ (long)-1130930182);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-272907357 ^ (long)-272907520);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-531492879 ^ (long)-531493103);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)73538713 ^ (long)73538638);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1512761913 ^ (long)-1512761879);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-2132696385 ^ (long)-2132696461);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1160283056 ^ (long)-1160282891);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1713615564 ^ (long)-1713615386);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)99025469 ^ (long)99025539);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)550934655 ^ (long)550934551);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)263163071 ^ (long)263163108);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)146893999 ^ (long)146894049);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-29400926 ^ (long)-29400870);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-217543624 ^ (long)-217543458);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)797136316 ^ (long)797136333);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)381707980 ^ (long)381707878);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-578583739 ^ (long)-578583720);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1728827455 ^ (long)-1728827458);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1508254325 ^ (long)-1508254310);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1875680462 ^ (long)-1875680354);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-270600599 ^ (long)-270600678);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1490612176 ^ (long)1490612177);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-546290533 ^ (long)-546290616);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1116644263 ^ (long)-1116644174);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1532556573 ^ (long)1532556712);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1175006408 ^ (long)1175006286);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1071157360 ^ (long)-1071157430);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1300592360 ^ (long)-1300592305);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1916896458 ^ (long)1916896316);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-259762956 ^ (long)-259763170);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1287062422 ^ (long)-1287062461);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-841977808 ^ (long)-841977650);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1271825842 ^ (long)1271825906);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-455318088 ^ (long)-455318231);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-829035855 ^ (long)-829035919);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1585443361 ^ (long)1585443563);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1601799051 ^ (long)-1601799057);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1496650933 ^ (long)-1496650753);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1746846720 ^ (long)1746846793);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1575978763 ^ (long)1575978791);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-460954554 ^ (long)-460954503);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1816683971 ^ (long)1816683870);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-910212209 ^ (long)-910212116);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-403206677 ^ (long)-403206793);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-2128045139 ^ (long)-2128045286);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1958819866 ^ (long)-1958820064);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1244503413 ^ (long)-1244503327);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1417090265 ^ (long)-1417090222);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1293392705 ^ (long)1293392694);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1025868101 ^ (long)-1025868110);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1172658866 ^ (long)1172658762);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1000343147 ^ (long)1000343236);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)650282848 ^ (long)650282809);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)574000684 ^ (long)574000823);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1455327330 ^ (long)-1455327304);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1673261740 ^ (long)-1673261607);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)416871868 ^ (long)416871732);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1848156776 ^ (long)-1848156742);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1499931192 ^ (long)1499931363);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)704944707 ^ (long)704944655);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1158750552 ^ (long)-1158750680);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)628514854 ^ (long)628514973);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-88400376 ^ (long)-88400291);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1001503340 ^ (long)-1001503313);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1001195485 ^ (long)1001195416);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)410735010 ^ (long)410734979);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1806582829 ^ (long)1806582789);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1185768736 ^ (long)1185768936);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1965087909 ^ (long)-1965087766);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)277745424 ^ (long)277745499);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1077618741 ^ (long)-1077618777);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)980701875 ^ (long)980701937);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-211546003 ^ (long)-211545864);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)380460313 ^ (long)380460515);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-651669176 ^ (long)-651669201);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-2146823048 ^ (long)-2146822924);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1437284312 ^ (long)1437284168);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)405250323 ^ (long)405250558);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-800791891 ^ (long)-800791906);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1220198977 ^ (long)1220199045);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-101614438 ^ (long)-101614543);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-584625115 ^ (long)-584625118);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)113452666 ^ (long)113452641);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1308803938 ^ (long)-1308803999);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)505305498 ^ (long)505305572);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)173732414 ^ (long)173732582);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1591328981 ^ (long)-1591328993);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-471161340 ^ (long)-471161305);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1457816683 ^ (long)1457816686);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1899965780 ^ (long)1899965749);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1242616136 ^ (long)-1242616245);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-526857193 ^ (long)-526857095);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1900735623 ^ (long)1900735711);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)32362362 ^ (long)32362266);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1635796828 ^ (long)1635796947);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1765287785 ^ (long)1765287715);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)562875851 ^ (long)562875763);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)546762515 ^ (long)546762685);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1916983973 ^ (long)1916984042);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-39168125 ^ (long)-39168084);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1721976602 ^ (long)-1721976649);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-703206017 ^ (long)-703206017);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)453624753 ^ (long)453624708);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-744452244 ^ (long)-744452272);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-344546925 ^ (long)-344546867);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)302293730 ^ (long)302293529);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1619890744 ^ (long)-1619890818);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1424489486 ^ (long)1424489539);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1263914658 ^ (long)1263914548);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1900272920 ^ (long)1900272936);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-749834669 ^ (long)-749834544);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1421617323 ^ (long)1421617243);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1188778755 ^ (long)1188779006);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)2044190243 ^ (long)2044190280);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1759273486 ^ (long)1759273509);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1078608449 ^ (long)-1078608533);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1010722675 ^ (long)1010722563);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1335857330 ^ (long)-1335857334);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1545334414 ^ (long)-1545334488);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-468270538 ^ (long)-468270490);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1142839223 ^ (long)-1142839047);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-61754664 ^ (long)-61754706);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-128239908 ^ (long)-128239999);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1982337514 ^ (long)1982337387);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-435289727 ^ (long)-435289625);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1444914463 ^ (long)1444914555);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)297190100 ^ (long)297189971);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1245922221 ^ (long)-1245922124);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1536652149 ^ (long)1536652218);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-492363465 ^ (long)-492363421);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1830948085 ^ (long)-1830948046);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1037928156 ^ (long)-1037928097);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-549881846 ^ (long)-549881605);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-835416298 ^ (long)-835416247);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-58027155 ^ (long)-58027148);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1144785655 ^ (long)1144785532);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)2092651226 ^ (long)2092651208);
                    if (!3X.\u2001\u200e\u200b) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)844893284 ^ (long)844893291);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1243124585 ^ (long)-1243124632)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1865427911 ^ (long)-1865471034)) >>> (int)((long)-1309963041 ^ (long)-1309963049)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1093672632 ^ (long)1093672632);
            if (!3X.\u2001\u200e\u200b) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1263038328 ^ (long)-1263038326);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-674158355 ^ (long)-674158354) | var5_6 << (int)((long)1901187241 ^ (long)1901187244)) ^ var3_4[var7_8]) & (int)((long)1780868873 ^ (long)1780869110);
                    if (3X.\u2001\u200e\u200b) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)970469286 ^ (long)970469285) | var6_7 << (int)((long)549359562 ^ (long)549359567)) ^ var3_4[var7_8]) & (int)((long)-413516229 ^ (long)-413516092);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3X.c[var2_3] = new String(var3_4).intern();
        }
        return 3X.c[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 1(boolean bl) {
        boolean bl2;
        block12: {
            block11: {
                bl2 = \u2001\u200e\u200b;
                if (bl2) return;
                String[] stringArray = 3e.5();
                if (bl2 || bl2) return;
                if (bl == this.6) {
                    if (bl2 || bl2) return;
                    return;
                }
                if (bl2) return;
                3U u = new 3U(this, bl);
                if (bl2 || bl2) return;
                3A.6.post((Object)u);
                if (bl2 || bl2) return;
                if (u.isCancelled()) {
                    if (bl2 || bl2) return;
                    return;
                }
                if (bl2) return;
                this.6 = bl;
                if (!this.6) break block11;
                if (bl2 || bl2) return;
                this.8();
                if (bl2 || bl2) return;
                if (!this.6) break block12;
                if (bl2 || bl2) return;
                3A.6.subscribe(this);
                if (bl2) return;
                if (stringArray == null) break block12;
                if (bl2) return;
            }
            if (bl2) return;
            3A.6.unsubscribe(this);
            if (bl2 || bl2) return;
            this.9();
            if (bl2) return;
        }
        if (bl2) return;
        if (this.4()) {
            if (bl2) return;
            if (this.5 != null) {
                if (bl2 || bl2) return;
                this.5.1(bl);
                if (bl2) return;
            }
        }
        if (!bl2) return;
    }

    public final boolean 9(String string) {
        boolean bl = \u2001\u200e\u200b;
        if (bl || bl) {
            return true;
        }
        return this.2(string).isPresent();
    }

    @Override
    public final Optional<2v> 2(String string) {
        boolean bl = \u2001\u200e\u200b;
        if (bl || bl) {
            return null;
        }
        return this.1.stream().filter(v -> {
            boolean bl = \u2001\u200e\u200b;
            if (bl || bl) {
                return true;
            }
            return v.6.equals(string);
        }).findFirst();
    }

    /*
     * Enabled aggressive block sorting
     */
    public final 7m 2() {
        block3: {
            block2: {
                boolean bl = \u2001\u200e\u200b;
                if (bl || bl) break block2;
                this.2();
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return this.5;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 1(String string) {
        block3: {
            block2: {
                boolean bl = \u2001\u200e\u200b;
                if (bl || bl) break block2;
                this.2(string).ifPresent(this.1::remove);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 2() {
        boolean bl = \u2001\u200e\u200b;
        if (bl || bl) return;
        if (!this.4()) {
            if (bl || bl) return;
            throw new UnsupportedOperationException(3X.a((int)((long)-635841780 ^ (long)-635843656), (int)((long)-1891085133 ^ (long)-1891099769)) /* "Cannot use mode required actions when modes aren't supported" */);
        }
        if (!bl) return;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 3X.\u2001\u200e\u200b;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)-309957766 ^ (long)-309957768)];
            if (var7) break block16;
            var3_2 = (int)((long)1512156203 ^ (long)1512156203);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\uddca\uf5a5\ue6bc\ueed7\uddd3\uf579\ue609\uee49\udd9d\uf525\ue6b9\uee7b\uddbe\uf508\ue6ae\ueed1\udd4a\uf55e\ue608\uee46\udd62\uf5ed\ue602\uee32\udd1a\uf5d1\ue642\ueea5\udd34\uf55c\ue60c\uee3a\udd8a\uf579\ue6cc\uee3a\udd79\uf51c\ue6d6\ueeb3\uddbc\uf552\ue692\ueebb\udd0a\uf504\ue665\ueee3\udd17\uf527\ue66e\ueeba\udd2f\uf524\ue608\uee33\udd17\uf5ed\ue61b\uee63\udd9d\uf5c5\ue61a\ueeac\udd73\uf52d\ue67e\ueea1\udd84\uf502\ue682\ueee7\uddc4\uf52c\ue602\ueeec\udd09\uf5aa\ue657\uee83\udd83\uf516\ue6b2\uee60\udd6e\uf543\ue680\ueeb2\udde9\uf5c6\ue6f5\uee5e\uddc2\uf562\ue6de", 532413198);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)-499413133 ^ (long)-499413169);
            3X.0((int)((long)-242366527 ^ (long)-242366527));
            if (var7) break block16;
            var0_6 = (int)((long)1042442322 ^ (long)-1042442323);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-776755653 ^ (long)776755652);
                if (3X.\u2001\u200e\u200b) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!3X.\u2001\u200e\u200b) continue block8;
                            throw null;
                        }
                        3X.b = var5_1;
                        3X.c = new String[(int)((long)1768569376 ^ (long)1768569378)];
                        if (!3X.\u2001\u200e\u200b) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)1170675820 ^ (long)1170675820);
                v5 = (int)((long)1651491018 ^ (long)1651491060);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)1365585708 ^ (long)1365585709)) ** GOTO lbl88
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1239834259 ^ (long)-1239834262)) {
                                case 0: {
                                    v12 = (int)((long)-1825000009 ^ (long)-1824999945);
                                    if (!3X.\u2001\u200e\u200b) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)1540812432 ^ (long)1540812462);
                                    if (!3X.\u2001\u200e\u200b) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-1845340792 ^ (long)-1845340779);
                                    if (!3X.\u2001\u200e\u200b) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)16067348 ^ (long)16067409);
                                    if (!3X.\u2001\u200e\u200b) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)934686193 ^ (long)934686187);
                                    if (!3X.\u2001\u200e\u200b) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)-1121024156 ^ (long)-1121024193);
                                    if (!3X.\u2001\u200e\u200b) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-916633663 ^ (long)-916633626);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!3X.\u2001\u200e\u200b);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!3X.\u2001\u200e\u200b) ** continue;
                throw null;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final 7m 9(String string) {
        block3: {
            block2: {
                boolean bl = \u2001\u200e\u200b;
                if (bl || bl) break block2;
                this.2();
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return this.8.stream().filter(m -> {
            boolean bl = \u2001\u200e\u200b;
            if (bl || bl) {
                return true;
            }
            return m.2().equalsIgnoreCase(string);
        }).findFirst().orElse(null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 0(List<7m> list) {
        boolean bl = \u2001\u200e\u200b;
        if (bl || bl) return;
        if (list.size() == 0) {
            if (bl) return;
            return;
        }
        if (bl) return;
        this.8 = new ArrayList<7m>(list);
        if (bl || bl) return;
        this.8.removeIf(Objects::isNull);
        if (bl || bl) return;
        3X x2 = this;
        x2.3(x2.8.get((int)((long)1653479832 ^ (long)1653479832)));
        if (!bl && !bl) return;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean 4() {
        boolean bl = \u2001\u200e\u200b;
        if (bl || bl) return true;
        if (this.8 != null) {
            if (bl) return true;
            return (int)((long)1677718336 ^ (long)1677718337) != 0;
        }
        if (!bl) return (int)((long)549296441 ^ (long)549296441) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 5(7m ... mArray) {
        block3: {
            block2: {
                boolean bl = \u2001\u200e\u200b;
                if (bl || bl) break block2;
                this.0(Arrays.asList(mArray));
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void 0(int n) {
        block3: {
            block2: {
                boolean bl = \u2001\u200e\u200b;
                if (bl) break block2;
                7 = n;
                if (!bl) break block3;
            }
            return;
        }
    }

    public final List<2v> 5() {
        boolean bl = \u2001\u200e\u200b;
        if (bl || bl) {
            return null;
        }
        return this.1;
    }

    public static int 1() {
        boolean bl = \u2001\u200e\u200b;
        if (bl) {
            return -2138268123;
        }
        return 7;
    }

    /*
     * Enabled aggressive block sorting
     */
    public 3X(String string, String string2, int n) {
        boolean bl = \u2001\u200e\u200b;
        if (bl || bl) return;
        this.1 = new ArrayList<2v>();
        if (bl || bl) return;
        this.4 = string;
        if (bl || bl) return;
        this.2 = string2;
        if (bl || bl) return;
        this.0 = new 8m(9Z.a, n, d2 -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2001\u200e\u200b;
                        if (bl || bl) break block2;
                        if (d2 != 4d.a) break block3;
                        if (bl) break block2;
                        this.1();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        });
        if (bl || bl) return;
        String[] stringArray = new String[(int)((long)285182962 ^ (long)285182960)];
        stringArray[(int)((long)-1892204703 ^ (long)-1892204703)] = string;
        stringArray[(int)((long)1002140939 ^ (long)1002140938)] = string2;
        if (3sk.7(stringArray)) {
            if (bl || bl) return;
            throw new NullPointerException(3X.a((int)((long)1106195559 ^ (long)1106193618), (int)((long)-309187957 ^ (long)309187574)) /* "One or more Mod members were null!" */);
        }
        if (!bl) return;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 2(2v v) {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2001\u200e\u200b;
                    if (bl || bl) break block2;
                    if (this.9(v).isPresent()) break block3;
                    if (bl || bl) break block2;
                    this.1.add(v);
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final 7m 3(7m m) {
        boolean bl;
        block12: {
            block11: {
                bl = \u2001\u200e\u200b;
                if (bl || bl) return null;
                this.2();
                if (bl || bl) return null;
                if (m == null) break block11;
                if (bl) return null;
                if (m.6() == this) break block12;
                if (bl) return null;
            }
            if (bl) return null;
            return null;
        }
        if (bl) return null;
        if (m == this.5) {
            if (bl || bl) return null;
            return m;
        }
        if (bl) return null;
        if (this.5 != null) {
            if (bl || bl) return null;
            this.5.1((boolean)((long)847671083 ^ (long)847671083));
            if (bl) return null;
        }
        if (bl) return null;
        this.5 = m;
        this.5.1((boolean)((long)382642954 ^ (long)382642955));
        if (!bl && !bl) return this.5;
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static int 8() {
        boolean bl = \u2001\u200e\u200b;
        if (bl) return -1522881458;
        int n = 3X.1();
        if (bl) return -1522881458;
        if (n == 0) {
            if (bl) return -1522881458;
            return (int)((long)2135487446 ^ (long)2135487458);
        }
        if (!bl) return (int)((long)-1755438002 ^ (long)-1755438002);
        return -1522881458;
    }
}

