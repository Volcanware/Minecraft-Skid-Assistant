/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  org.apache.logging.log4j.Level
 */
package net.impactclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import net.impactclient.2C;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.3K;
import net.impactclient.3sU;
import net.impactclient.3si;
import net.impactclient.5z;
import net.impactclient.6e;
import net.impactclient.7m;
import net.impactclient.93;
import org.apache.logging.log4j.Level;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 90
implements 3sU {
    private final Path 7;
    private static final String[] a;
    public final 2C 1;
    private static final String[] b;
    public static final boolean \u2008\u2005\u200b\u2000\u2001;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 90.\u2008\u2005\u200b\u2000\u2001;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)621918946 ^ (long)621904897)) & (int)((long)-2126565316 ^ (long)-2126524477);
            if (var9_2) ** GOTO lbl-1000
            if (90.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 90.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1299536157 ^ (long)-1299536157)] & (int)((long)828557383 ^ (long)828557496)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)403966078 ^ (long)403966141);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)449212004 ^ (long)449212066);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1500369373 ^ (long)1500369393);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1419056487 ^ (long)1419056509);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1866278352 ^ (long)-1866278296);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-2066367516 ^ (long)-2066367652);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)621782021 ^ (long)621782255);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1980453643 ^ (long)-1980453733);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-79939468 ^ (long)-79939352);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1822170178 ^ (long)-1822170345);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1802561630 ^ (long)1802561558);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1931121907 ^ (long)1931121792);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1198576873 ^ (long)1198576851);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1240397935 ^ (long)1240398031);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-703684595 ^ (long)-703684559);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-427994335 ^ (long)-427994312);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1048333430 ^ (long)-1048333523);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-11842460 ^ (long)-11842560);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1685828822 ^ (long)-1685828851);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)481260668 ^ (long)481260667);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1383453534 ^ (long)-1383453647);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)2125229436 ^ (long)2125229491);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)309982151 ^ (long)309982088);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-503834711 ^ (long)-503834666);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1619061455 ^ (long)-1619061384);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-493146024 ^ (long)-493145883);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1565637773 ^ (long)1565637870);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1822610885 ^ (long)-1822610880);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1637194383 ^ (long)1637194269);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)2085051676 ^ (long)2085051688);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-521828493 ^ (long)-521828417);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-626172567 ^ (long)-626172448);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1737177084 ^ (long)-1737177034);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)2064752352 ^ (long)2064752334);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1233330122 ^ (long)-1233329981);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)443808349 ^ (long)443808454);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1636100910 ^ (long)-1636101077);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-132890253 ^ (long)-132890269);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-801635228 ^ (long)-801635113);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1876668771 ^ (long)-1876668683);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1689289101 ^ (long)1689289140);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1537347198 ^ (long)-1537347254);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1937328566 ^ (long)-1937328533);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1398030633 ^ (long)1398030690);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1296382282 ^ (long)-1296382409);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-618836852 ^ (long)-618836958);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)934833536 ^ (long)934833630);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-977576203 ^ (long)-977576208);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1694963518 ^ (long)1694963700);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)454648619 ^ (long)454648791);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1482038740 ^ (long)-1482038702);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)652415303 ^ (long)652415315);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1974195396 ^ (long)1974195382);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)809446713 ^ (long)809446758);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1632184625 ^ (long)-1632184724);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1782015651 ^ (long)1782015580);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)407233264 ^ (long)407233243);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)658870645 ^ (long)658870750);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-333204016 ^ (long)-333204122);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1731369099 ^ (long)-1731369182);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-2069685892 ^ (long)-2069685953);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-288276122 ^ (long)-288275984);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)962637955 ^ (long)962637928);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)50100058 ^ (long)50100120);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1783496365 ^ (long)1783496256);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)977360592 ^ (long)977360584);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-911325531 ^ (long)-911325670);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1688898984 ^ (long)1688898858);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-482495959 ^ (long)-482495803);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1766114773 ^ (long)1766114808);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1128878727 ^ (long)1128878630);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1398339675 ^ (long)-1398339693);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1962458618 ^ (long)-1962458383);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)198204098 ^ (long)198203972);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1197373460 ^ (long)1197373464);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)415649461 ^ (long)415649390);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1052876713 ^ (long)-1052876606);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)226409828 ^ (long)226409972);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1123812322 ^ (long)1123812185);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1424341268 ^ (long)1424341489);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)131845160 ^ (long)131845375);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1961227252 ^ (long)-1961227207);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)923780947 ^ (long)923781063);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1460339505 ^ (long)1460339553);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1085203178 ^ (long)1085202983);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1589747796 ^ (long)-1589747794);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1468039180 ^ (long)1468039288);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)2061900175 ^ (long)2061900100);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-358343226 ^ (long)-358343197);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)757990662 ^ (long)757990882);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-990526451 ^ (long)-990526289);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)486413549 ^ (long)486413558);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1584976079 ^ (long)1584976040);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)928556270 ^ (long)928556147);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1329223795 ^ (long)1329223802);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-931034440 ^ (long)-931034480);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1770183344 ^ (long)1770183284);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-2137925478 ^ (long)-2137925402);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-904402654 ^ (long)-904402613);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-837080968 ^ (long)-837081015);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1110252101 ^ (long)1110252073);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-443533852 ^ (long)-443533980);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1410598024 ^ (long)-1410598050);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)210206887 ^ (long)210206752);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1009726706 ^ (long)1009726668);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)902907292 ^ (long)902907353);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-84844762 ^ (long)-84844694);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1497392993 ^ (long)-1497393014);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1338142174 ^ (long)1338141966);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)125528348 ^ (long)125528363);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-128322534 ^ (long)-128322530);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-638305951 ^ (long)-638305873);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1856924429 ^ (long)-1856924433);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)748111001 ^ (long)748110937);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-21402635 ^ (long)-21402650);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1668437419 ^ (long)-1668437326);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1354050589 ^ (long)-1354050647);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1270436273 ^ (long)1270436139);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)458446588 ^ (long)458446579);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-539338910 ^ (long)-539338795);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)940161689 ^ (long)940161682);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1416289402 ^ (long)1416289374);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1678714212 ^ (long)1678714289);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1385485535 ^ (long)-1385485487);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1101875061 ^ (long)-1101875071);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1175247595 ^ (long)1175247550);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)289816393 ^ (long)289816534);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1736900715 ^ (long)-1736900828);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1841552108 ^ (long)1841552055);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)239576371 ^ (long)239576484);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-2061787751 ^ (long)-2061787656);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1746600234 ^ (long)1746600366);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1914510600 ^ (long)1914510643);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1837817335 ^ (long)1837817262);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)75910454 ^ (long)75910540);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-694155593 ^ (long)-694155616);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)2147333701 ^ (long)2147333812);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-733972242 ^ (long)-733972242);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-213293732 ^ (long)-213293798);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)520692394 ^ (long)520692343);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1757868045 ^ (long)-1757868287);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)720567013 ^ (long)720566808);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)866217703 ^ (long)866217510);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-494465846 ^ (long)-494465946);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1520608619 ^ (long)1520608621);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1601158053 ^ (long)-1601158023);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1042115885 ^ (long)1042115872);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1047730283 ^ (long)-1047730187);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-822051964 ^ (long)-822051947);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1475300631 ^ (long)1475300742);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1356373417 ^ (long)-1356373361);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)502588336 ^ (long)502588301);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1243802342 ^ (long)1243802279);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)794959257 ^ (long)794959332);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1748495597 ^ (long)1748495611);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1283457146 ^ (long)-1283457065);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1214816849 ^ (long)1214816828);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1434794016 ^ (long)1434794133);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)186003283 ^ (long)186003329);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)11060998 ^ (long)11061151);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1036109032 ^ (long)1036108994);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1637545354 ^ (long)-1637545305);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1913161573 ^ (long)-1913161509);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-2057454637 ^ (long)-2057454753);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-683055477 ^ (long)-683055432);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1891175713 ^ (long)1891175705);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1734887165 ^ (long)1734886939);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)989678868 ^ (long)989678909);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-121049089 ^ (long)-121049255);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)285246908 ^ (long)285246916);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-759288661 ^ (long)-759288752);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1428920206 ^ (long)1428920259);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)782768739 ^ (long)782768778);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-268405941 ^ (long)-268405864);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-432700650 ^ (long)-432700514);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)2001002536 ^ (long)2001002507);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)896709834 ^ (long)896709728);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)34351842 ^ (long)34351869);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1953053102 ^ (long)1953053035);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1911661736 ^ (long)1911661643);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)0xA141A11 ^ (long)169089694);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-335743835 ^ (long)-335743808);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1784880496 ^ (long)1784880418);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)912649296 ^ (long)912649343);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1309357298 ^ (long)1309357064);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1447299738 ^ (long)-1447299656);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1638935052 ^ (long)1638935139);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-462762220 ^ (long)-462762204);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-634641436 ^ (long)-634641522);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1586581582 ^ (long)1586581556);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-886704695 ^ (long)-886704663);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-84151724 ^ (long)-84151669);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1866069698 ^ (long)1866069613);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)797821086 ^ (long)797820999);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1245405081 ^ (long)1245404980);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-262983291 ^ (long)-262983231);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)614093450 ^ (long)614093493);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)472133929 ^ (long)472133954);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)202288949 ^ (long)202289091);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)57969373 ^ (long)57969197);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-739270340 ^ (long)-739270348);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-563927720 ^ (long)-563927746);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)613520769 ^ (long)613520850);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-267257355 ^ (long)-267257432);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1889612153 ^ (long)-1889612226);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1212013993 ^ (long)1212013863);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)866243235 ^ (long)866243147);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1305029696 ^ (long)-1305029726);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1935303462 ^ (long)-1935303507);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1514761698 ^ (long)-1514761656);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1052066556 ^ (long)1052066336);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)527558029 ^ (long)527557888);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)842036197 ^ (long)842036159);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-99688475 ^ (long)-99688641);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-312475302 ^ (long)-312475138);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1988596022 ^ (long)1988596223);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1484191673 ^ (long)-1484191739);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-2108979473 ^ (long)-2108979629);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1239571440 ^ (long)1239571437);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)463539728 ^ (long)463539731);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1647743239 ^ (long)1647743475);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-778732206 ^ (long)-778732118);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)458532938 ^ (long)458533020);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1311529835 ^ (long)1311529791);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-288696791 ^ (long)-288696662);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)206652793 ^ (long)206652779);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)486311129 ^ (long)486311080);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1484663322 ^ (long)-1484663366);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1836139517 ^ (long)1836139443);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-271585189 ^ (long)-271585058);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-317313156 ^ (long)-317313124);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)759963869 ^ (long)759963765);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-201619849 ^ (long)-201619729);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)865242649 ^ (long)865242771);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1825042801 ^ (long)1825042847);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1578750938 ^ (long)1578750847);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-671891061 ^ (long)-671891095);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1161554952 ^ (long)-1161554970);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1906299996 ^ (long)-1906299939);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-31841308 ^ (long)-31841425);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1489121784 ^ (long)1489121559);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)988772088 ^ (long)988771865);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1876142363 ^ (long)-1876142543);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1694679323 ^ (long)-1694679467);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-444860880 ^ (long)-444860786);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)314834752 ^ (long)314834823);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)973165648 ^ (long)973165605);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)394408529 ^ (long)394408543);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1289678435 ^ (long)1289678480);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1355537402 ^ (long)1355537341);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)310556337 ^ (long)310556165);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1222927726 ^ (long)1222927640);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-454923469 ^ (long)-454923347);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-907225400 ^ (long)-907225399);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-904338569 ^ (long)-904338551);
                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1127296989 ^ (long)-1127296879);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-90894539 ^ (long)-90894390)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-24429943 ^ (long)-24394378)) >>> (int)((long)2025863607 ^ (long)2025863615)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)766529581 ^ (long)766529581);
            if (!90.\u2008\u2005\u200b\u2000\u2001) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1667468222 ^ (long)-1667468224);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1599700309 ^ (long)-1599700312) | var5_6 << (int)((long)-2000426972 ^ (long)-2000426975)) ^ var3_4[var7_8]) & (int)((long)382291483 ^ (long)382291684);
                    if (90.\u2008\u2005\u200b\u2000\u2001) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-512449312 ^ (long)-512449309) | var6_7 << (int)((long)1703102126 ^ (long)1703102123)) ^ var3_4[var7_8]) & (int)((long)-1237959633 ^ (long)-1237959472);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            90.b[var2_3] = new String(var3_4).intern();
        }
        return 90.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public 90(String string, 2C c2) {
        block3: {
            block2: {
                boolean bl = \u2008\u2005\u200b\u2000\u2001;
                if (bl || bl) break block2;
                this.1 = c2;
                if (bl || bl) break block2;
                5z.4();
                this.7 = 5z.1(string);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 6() {
        block3: {
            block2: {
                boolean bl = \u2008\u2005\u200b\u2000\u2001;
                if (bl || bl) break block2;
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty(90.a((int)((long)1462310968 ^ (long)1462314716), (int)((long)1760141838 ^ (long)-1760165137)) /* "version" */, 90.a((int)((long)320357115 ^ (long)320371720), (int)((long)822184041 ^ (long)822202277)) /* "1.1" */);
                if (bl || bl) break block2;
                JsonArray jsonArray = new JsonArray();
                if (bl || bl) break block2;
                this.1.forEach(x2 -> {
                    block7: {
                        block2: {
                            JsonObject jsonObject;
                            boolean bl;
                            block6: {
                                String string;
                                block5: {
                                    block4: {
                                        block3: {
                                            bl = \u2008\u2005\u200b\u2000\u2001;
                                            if (bl || bl) break block2;
                                            jsonObject = new JsonObject();
                                            if (bl || bl) break block2;
                                            string = 3si.6(x2.9().3).toUpperCase();
                                            if (!string.startsWith(90.a((int)((long)-1226347566 ^ (long)-1226353359), (int)((long)-197770221 ^ (long)-197756003)))) break block3;
                                            if (bl || bl) break block2;
                                            string = string.replaceFirst(90.a((int)((long)-571914596 ^ (long)-571901827), (int)((long)1094089427 ^ (long)1094076532)) /* "LEFT_" */, 2w$6X.KAOZ("\u1082", -2045102195));
                                            if (bl) break block2;
                                        }
                                        if (bl) break block2;
                                        if (!string.startsWith(90.a((int)((long)-1879011670 ^ (long)-1879003059), (int)((long)-1477285883 ^ (long)-1477304938)) /* "RIGHT_" */)) break block4;
                                        if (bl || bl) break block2;
                                        string = string.replaceFirst(90.a((int)((long)-930324302 ^ (long)-930324924), (int)((long)307145402 ^ (long)-307156138)), 2w$6X.KAOZ("\udd76", -1150879129));
                                        if (bl) break block2;
                                    }
                                    if (bl) break block2;
                                    jsonObject.addProperty(90.a((int)((long)-210789206 ^ (long)-210787764), (int)((long)2092177286 ^ (long)2092183823)), 2C.5(x2.2()));
                                    if (bl || bl) break block2;
                                    jsonObject.addProperty(90.a((int)((long)-721896491 ^ (long)-721910470), (int)((long)1565378892 ^ (long)-1565364964)) /* "state" */, Boolean.valueOf(x2.3()));
                                    if (bl || bl) break block2;
                                    jsonObject.addProperty(90.a((int)((long)-1493465153 ^ (long)-1493452469), (int)((long)2045249197 ^ (long)-2045255715)) /* "bind" */, string);
                                    if (bl || bl) break block2;
                                    jsonObject.addProperty(90.a((int)((long)-1026160817 ^ (long)-1026147935), (int)((long)1072179722 ^ (long)-1072190318)), (Boolean)2R.0(x2, 90.a((int)((long)2125212489 ^ (long)2125206956), (int)((long)2035785286 ^ (long)-2035779460)) /* "display" */));
                                    if (bl || bl) break block2;
                                    string = 3K.7(x2);
                                    if (string == null) break block5;
                                    if (bl || bl) break block2;
                                    jsonObject.add(90.a((int)((long)-706003878 ^ (long)-706018640), (int)((long)1523289682 ^ (long)1523306693)) /* "values" */, (JsonElement)string);
                                    if (bl) break block2;
                                }
                                if (bl) break block2;
                                if (!x2.4()) break block6;
                                if (bl || bl) break block2;
                                jsonObject.addProperty(90.a((int)((long)-2001461954 ^ (long)-2001460276), (int)((long)2128666718 ^ (long)-2128672273)) /* "mode" */, x2.2().2());
                                if (bl || bl) break block2;
                                string = new JsonArray();
                                if (bl || bl) break block2;
                                x2.0().forEach(arg_0 -> 90.3((JsonArray)string, arg_0));
                                if (bl || bl) break block2;
                                if (string.size() <= 0) break block6;
                                if (bl || bl) break block2;
                                jsonObject.add(90.a((int)((long)-455672538 ^ (long)-455687209), (int)((long)-1302650090 ^ (long)1302631429)) /* "modes" */, (JsonElement)string);
                                if (bl) break block2;
                            }
                            if (bl) break block2;
                            jsonArray.add((JsonElement)jsonObject);
                            if (!bl && !bl) break block7;
                        }
                        return;
                    }
                });
                if (bl || bl) break block2;
                jsonObject.add(90.a((int)((long)1709357850 ^ (long)1709344241), (int)((long)-2000460099 ^ (long)2000477986)) /* "modules" */, (JsonElement)jsonArray);
                if (bl || bl) break block2;
                93.5((JsonElement)jsonObject, this.7);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ void 3(JsonArray jsonArray, 7m m) {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2008\u2005\u200b\u2000\u2001;
                    if (bl || bl) break block2;
                    JsonArray jsonArray2 = 3K.7(m);
                    if (jsonArray2 == null) break block3;
                    if (bl || bl) break block2;
                    JsonObject jsonObject = new JsonObject();
                    jsonObject.addProperty(90.a((int)((long)-1825238083 ^ (long)-1825231523), (int)((long)292541727 ^ (long)-292525895)) /* "name" */, m.2());
                    if (bl || bl) break block2;
                    jsonObject.add(90.a((int)((long)609325346 ^ (long)609333202), (int)((long)1393841582 ^ (long)-1393824616)), (JsonElement)jsonArray2);
                    if (bl || bl) break block2;
                    jsonArray.add((JsonElement)jsonObject);
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 90.\u2008\u2005\u200b\u2000\u2001;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1323819372 ^ (long)1323819380)];
            if (var7) break block23;
            var3_2 = (int)((long)538306305 ^ (long)538306305);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u3c49\u1538\u0632\u0e73\u3cd0\u159a\u06b7\u0eb6\u3cd8\u15bf\u0655\u0e93\u3cc9\u1550\u060e\u0e61\u3ce9\u1542\u06ff\u0ecb\u3c87\u15cd\u0623\u0ef4\u3cc5\u15fc\u06a8\u0e8c\u3c1b\u150e\u065f\u0e25\u3c9a\u1529\u06e1\u0e94\u3c46\u15f7\u06c3\u0e2c\u3c9b\u15d0\u06b5\u0efe\u3c08\u15d6\u06a5\u0ef8\u3c4e\u153a\u06f2\u0eda\u3cbb\u15f0\u066c\u0e6a\u3c1b\u15b3\u0669\u0e4a\u3c53\u15c9\u06ad\u0ed9\u3c05\u15b0\u066c\u0eab\u3cbd\u15b3\u064d\u0eb0\u3cd7\u1596\u06ac\u0ed8\u3c20\u1554\u06d4\u0ebd\u3cab\u15e9\u06ac\u0ebb\u3cce\u1569\u0687\u0e3e\u3cac\u152b\u06ac\u0ecf\u3c72\u1589\u065d\u0ef3\u3c3b\u152a\u06ad\u0ee9\u3c24\u153d\u0658\u0e65\u3c8d\u159e\u0602\u0ef2\u3cb5\u1512\u0613\u0ea0\u3ca4\u1566\u06a5\u0ebb\u3c59\u1595\u0680\u0e5a\u3c66\u158a\u06f3\u0ea6\u3cee\u157d\u06c9\u0e14\u3ce3\u15f6\u065c\u0eb9\u3c26\u155e\u065c\u0e46\u3cd4\u153d\u0641\u0ee5\u3c06\u1562\u0676\u0e47\u3c57\u15b9\u06c6\u0eff\u3c7e\u1515\u0612\u0e8b\u3ccf\u15f6\u0617\u0ec9\u3cfb\u152b\u06ba\u0ee2\u3cd9\u15cd\u068c\u0e98\u3c6b\u15df\u06c8\u0e9e\u3c89\u158e\u0699\u0e44\u3c7a\u15cf\u06c7\u0e11\u3cdb\u15fd\u06be\u0ec6\u3c58\u158d\u0649\u0e7c\u3c6b\u1584\u06ac\u0e07\u3c99\u15af\u06e3\u0ec2\u3c4d\u1506\u06ac\u0e39\u3cf0\u1557\u060d\u0e28\u3c31\u1551\u06b2\u0e3b\u3cd4\u152d\u06bf\u0ec2\u3c92\u155f\u063c\u0ef5\u3ced\u15f8\u0699\u0eb0\u3c77\u15e4\u0619\u0e66\u3c8e\u150b\u061d\u0e0f\u3c26\u157a\u065a\u0edb\u3c5e\u150c\u06b7\u0e16\u3c59\u150f\u06fa\u0ef4\u3c74\u15b2\u061e\u0ee7\u3cd7\u15b3\u060e\u0ed9\u3c25\u1578\u06e8\u0efa\u3cde\u15bd\u068b\u0efa\u3cd5\u15ce\u06ba\u0e55\u3cb4\u1508\u06a8\u0e19\u3c63\u15aa\u06c2\u0eda\u3cad\u15a0\u06bd\u0eef\u3c1f\u1514\u06af\u0e13\u3ccc\u1586\u0625\u0e98\u3c87\u15d7\u0631\u0ed8\u3c9d\u1592\u06e3\u0ed9\u3cc4\u15a9\u065f\u0ed0\u3c57\u154e", -1343415522);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1891699373 ^ (long)1891699368);
            if (var7) break block23;
            var0_6 = (int)((long)-1877392538 ^ (long)1877392537);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)226702416 ^ (long)226702352);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-147633541 ^ (long)147633540);
                    if (90.\u2008\u2005\u200b\u2000\u2001) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!90.\u2008\u2005\u200b\u2000\u2001) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u58dd\u71e3\u625b\u6ab9\u58cb\u71bd\u626b\u6ab4\u58df\u71e4\u6291\u6ac3", 2020376433);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1275225166 ^ (long)-1275225163);
                            var0_6 = (int)((long)355225410 ^ (long)-355225411);
                            while (true) {
                                v0 = (int)((long)144321182 ^ (long)144321157);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-240268101 ^ (long)-240268101);
                                if (!90.\u2008\u2005\u200b\u2000\u2001) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!90.\u2008\u2005\u200b\u2000\u2001) ** continue;
                                throw null;
                            }
                            90.a = var5_1;
                            90.b = new String[(int)((long)186446902 ^ (long)186446894)];
                            if (!90.\u2008\u2005\u200b\u2000\u2001) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1373515087 ^ (long)1373515087);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)682970223 ^ (long)682970222)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1954001667 ^ (long)-1954001670)) {
                                case 0: {
                                    v15 = (int)((long)2110026138 ^ (long)2110026180);
                                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)762147115 ^ (long)762147158);
                                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-786150041 ^ (long)-786150020);
                                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)979071885 ^ (long)979071886);
                                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1706207306 ^ (long)-1706207246);
                                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1130499919 ^ (long)-1130499937);
                                    if (!90.\u2008\u2005\u200b\u2000\u2001) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-156097874 ^ (long)-156097820);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!90.\u2008\u2005\u200b\u2000\u2001);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    public final void 1() {
        block14: {
            block13: {
                block16: {
                    block12: {
                        block15: {
                            block11: {
                                block10: {
                                    var4_1 = 90.\u2008\u2005\u200b\u2000\u2001;
                                    if (var4_1) lbl-1000:
                                    // 22 sources

                                    {
                                        return;
                                    }
                                    if (var4_1) ** GOTO lbl-1000
                                    if (Files.exists(this.7, new LinkOption[(int)((long)1183989321 ^ (long)1183989321)])) break block10;
                                    if (var4_1 || var4_1) ** GOTO lbl-1000
                                    this.6();
                                    if (var4_1 || var4_1) ** GOTO lbl-1000
                                    return;
                                }
                                if (var4_1) ** GOTO lbl-1000
                                var1_2 = 93.0(Files.newBufferedReader(this.7));
                                if (var1_2.isJsonObject()) break block11;
                                if (var4_1 || var4_1) ** GOTO lbl-1000
                                throw new Exception(90.a((int)((long)-28169903 ^ (long)-28174426), (int)((long)623134254 ^ (long)623146977)));
                            }
                            if (var4_1) ** GOTO lbl-1000
                            if (!(var1_2 = var1_2.getAsJsonObject()).has(90.a((int)((long)1027150929 ^ (long)1027156644), (int)((long)1150617200 ^ (long)1150629287)))) break block15;
                            if (var4_1) ** GOTO lbl-1000
                            if (var1_2.get(90.a((int)((long)1435764028 ^ (long)1435777993), (int)((long)-1281192018 ^ (long)-1281180551))).isJsonPrimitive()) break block12;
                            if (var4_1) ** GOTO lbl-1000
                        }
                        if (var4_1) ** GOTO lbl-1000
                        throw new Exception(90.a((int)((long)1845776218 ^ (long)1845785011), (int)((long)232284208 ^ (long)-232272365)) /* "Config file doesn't define format version" */);
                    }
                    if (var4_1) ** GOTO lbl-1000
                    if (!var1_2.has(90.a((int)((long)-605506854 ^ (long)-605516745), (int)((long)1748696566 ^ (long)-1748693122)))) break block16;
                    if (var4_1) ** GOTO lbl-1000
                    if (var1_2.get(90.a((int)((long)-921235173 ^ (long)-921227274), (int)((long)191079165 ^ (long)-191082379))).isJsonArray()) break block13;
                    if (var4_1) ** GOTO lbl-1000
                }
                if (var4_1) ** GOTO lbl-1000
                throw new Exception(90.a((int)((long)703948268 ^ (long)703945476), (int)((long)109587644 ^ (long)-109598040)) /* "Config file is in invalid format" */);
            }
            if (var4_1) ** GOTO lbl-1000
            var2_4 = var1_2.get(90.a((int)((long)-1641998759 ^ (long)-1641994068), (int)((long)-523356418 ^ (long)-523369175))).getAsString();
            var3_5 = 6e.0(var2_4);
            if (var3_5 != null) break block14;
            if (var4_1 || var4_1) ** GOTO lbl-1000
            v0 = new Object[(int)((long)-1426737497 ^ (long)-1426737498)];
            v0[(int)((long)2035643260 ^ (long)2035643260)] = var2_4;
            throw new Exception(String.format(90.a((int)((long)1352968701 ^ (long)1352963871), (int)((long)-28057911 ^ (long)-28067766)) /* "Unable to find loader for config version \"%s\"" */, v0));
        }
        try {
            if (var4_1) ** GOTO lbl-1000
            var3_5.1(this, var1_2.getAsJsonArray(90.a((int)((long)-1252734055 ^ (long)-1252723340), (int)((long)925855215 ^ (long)-925851801))));
            if (var4_1 || var4_1) ** GOTO lbl-1000
            ** if (!90.\u2008\u2005\u200b\u2000\u2001) goto lbl-1000
        }
        catch (Exception var1_3) {
            if (var4_1 || var4_1) ** GOTO lbl-1000
            5z.9.log(Level.FATAL, 90.a((int)((long)-1923392271 ^ (long)-1923390947), (int)((long)1334698340 ^ (long)-1334677753)) /* "Unable to load config: {}" */, (Object)var1_3.getMessage());
            if (var4_1) ** GOTO lbl-1000
        }
lbl-1000:
        // 1 sources

        {
            throw null;
        }
lbl-1000:
        // 1 sources

        {
        }
        if (var4_1) ** GOTO lbl-1000
        this.6();
        if (!var4_1 && !var4_1) ** break;
        ** while (true)
    }
}

