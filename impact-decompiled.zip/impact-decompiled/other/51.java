/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dfm
 */
package net.impactclient;

import java.util.AbstractMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.impactclient.2f;
import net.impactclient.2w$6X;
import net.impactclient.5e;
import net.impactclient.6c;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
final class 51
extends LinkedList<Map.Entry<String, String>> {
    public static final boolean \u2002\u200b\u2001\u2006;
    private /* synthetic */ 6c 3;
    private static final String[] b;
    private static final String[] a;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 51.\u2002\u200b\u2001\u2006;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1000345606 ^ (long)-1000353673)) & (int)((long)-762402656 ^ (long)-762423457);
            if (var9_2) ** GOTO lbl-1000
            if (51.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 51.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1903347806 ^ (long)1903347806)] & (int)((long)-2075455360 ^ (long)-2075455361)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1688608408 ^ (long)-1688608476);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1443608052 ^ (long)-1443607928);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1230406843 ^ (long)-1230406853);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1217784614 ^ (long)1217784637);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)661858749 ^ (long)661858778);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1382387726 ^ (long)-1382387920);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1774740736 ^ (long)-1774740640);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1658204762 ^ (long)1658204750);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1486079221 ^ (long)1486079012);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1941701782 ^ (long)1941701683);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)697978930 ^ (long)697979046);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1658084085 ^ (long)1658083849);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1671704201 ^ (long)1671704239);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1327512160 ^ (long)-1327512259);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1001790686 ^ (long)1001790648);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)2020267524 ^ (long)2020267577);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)73325222 ^ (long)73325065);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-611398700 ^ (long)-611398830);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1401000620 ^ (long)-1401000555);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)754725962 ^ (long)754726083);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1838904145 ^ (long)-1838904263);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1638865296 ^ (long)-1638865338);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1820617501 ^ (long)1820617570);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)592290378 ^ (long)592290404);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1406637852 ^ (long)1406637884);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1198683441 ^ (long)-1198683535);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-890311485 ^ (long)-890311566);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-857670973 ^ (long)-857670973);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)813449562 ^ (long)813449688);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)207495551 ^ (long)207495473);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1887058007 ^ (long)-1887058156);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-958082662 ^ (long)-958082768);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)2088985353 ^ (long)2088985370);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-417210454 ^ (long)-417210548);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1803179748 ^ (long)1803179728);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1747666577 ^ (long)1747666540);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-198303818 ^ (long)-198303842);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1739608197 ^ (long)1739608188);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-288054083 ^ (long)-288054193);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-617769379 ^ (long)-617769408);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-573161882 ^ (long)-573161917);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-76411434 ^ (long)-76411646);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-349009442 ^ (long)-349009610);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1615412055 ^ (long)1615412046);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1997308538 ^ (long)1997308425);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1082817899 ^ (long)-1082817817);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-788619287 ^ (long)-788619335);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)504118477 ^ (long)504118273);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1250990733 ^ (long)1250990602);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-466416662 ^ (long)-466416654);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1951075192 ^ (long)-1951075296);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)585733280 ^ (long)585733259);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-617805089 ^ (long)-617805191);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1148285478 ^ (long)1148285451);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)2110151349 ^ (long)2110151216);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)2109667779 ^ (long)2109667656);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1191607317 ^ (long)-1191607416);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1592886802 ^ (long)-1592886861);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)57696318 ^ (long)57696363);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1984152979 ^ (long)-1984153072);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)824978031 ^ (long)824977990);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-13729591 ^ (long)-13729569);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)112142347 ^ (long)112142561);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-269457904 ^ (long)-269457707);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1226913883 ^ (long)1226913809);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-579189221 ^ (long)-579189048);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1773014346 ^ (long)-1773014471);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-2119111624 ^ (long)-2119111602);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1227262690 ^ (long)-1227262693);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1191160822 ^ (long)1191160818);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)258789653 ^ (long)258789827);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1112418292 ^ (long)1112418262);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)494420214 ^ (long)494420221);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1229493532 ^ (long)-1229493645);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1285953686 ^ (long)-1285953608);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-901389250 ^ (long)-901389059);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-753219061 ^ (long)-753218982);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1513282460 ^ (long)1513282458);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)658692990 ^ (long)658693029);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1876413945 ^ (long)-1876413763);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1057919035 ^ (long)-1057919182);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1391972470 ^ (long)1391972493);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-333366142 ^ (long)-333366080);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1603838758 ^ (long)1603838760);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1449684767 ^ (long)1449684931);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-675153201 ^ (long)-675153238);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1322687340 ^ (long)-1322687293);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1224384493 ^ (long)1224384441);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1487883394 ^ (long)-1487883393);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-994292832 ^ (long)-994292873);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)956798370 ^ (long)956798344);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)485977421 ^ (long)485977371);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1167278614 ^ (long)-1167278845);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1500525141 ^ (long)-1500525262);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)523399668 ^ (long)523399531);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-725048447 ^ (long)-725048419);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)129463178 ^ (long)129463278);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-939420039 ^ (long)-939420072);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1801131439 ^ (long)1801131382);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)337526202 ^ (long)337526154);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)438511731 ^ (long)438511772);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)2085580685 ^ (long)2085580749);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-969302480 ^ (long)-969302509);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)819667815 ^ (long)819667901);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)754833828 ^ (long)754833668);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)2074534401 ^ (long)2074534582);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)951330650 ^ (long)951330579);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)604718938 ^ (long)604718948);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-689250520 ^ (long)-689250334);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-2137636029 ^ (long)-2137635949);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-2088169580 ^ (long)-2088169476);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1560758955 ^ (long)1560759014);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1230554144 ^ (long)1230554273);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1488271981 ^ (long)1488272089);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1169204596 ^ (long)-1169204665);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)794056539 ^ (long)794056683);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-748705161 ^ (long)-748705197);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)340006219 ^ (long)340006355);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1363919272 ^ (long)-1363919200);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)2139043854 ^ (long)2139044013);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1376460907 ^ (long)1376460890);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1685476847 ^ (long)-1685476834);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)870483961 ^ (long)870483786);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-613457612 ^ (long)-613457534);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1676292305 ^ (long)1676292280);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1230996598 ^ (long)1230996588);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-597297524 ^ (long)-597297508);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1615158920 ^ (long)1615159014);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1695343105 ^ (long)-1695343326);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1666992586 ^ (long)1666992514);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1255362821 ^ (long)-1255362934);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1871534368 ^ (long)1871534425);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1198222916 ^ (long)-1198223034);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1492706343 ^ (long)-1492706314);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-330300790 ^ (long)-330300861);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-791818557 ^ (long)-791818712);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-542153030 ^ (long)-542153038);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-135001150 ^ (long)-135001266);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1674278563 ^ (long)1674278632);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-2051743797 ^ (long)-2051743979);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)575536495 ^ (long)575536469);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1285123361 ^ (long)-1285123466);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-40548610 ^ (long)-40548810);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1606573295 ^ (long)-1606573157);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)944545201 ^ (long)944545027);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)89022383 ^ (long)89022442);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-844418883 ^ (long)-844419000);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)708117328 ^ (long)708117268);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)114713763 ^ (long)114713836);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1104652158 ^ (long)1104652148);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1268838720 ^ (long)1268838892);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)94844095 ^ (long)94843967);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)787652325 ^ (long)787652198);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)413393182 ^ (long)413393318);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)2034967002 ^ (long)2034966789);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)606780822 ^ (long)606780874);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1405762674 ^ (long)-1405762795);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)59990000 ^ (long)59989914);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-388385559 ^ (long)-388385662);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1415885369 ^ (long)1415885358);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1588764216 ^ (long)-1588764325);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)2028273870 ^ (long)2028273814);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-742665014 ^ (long)-742664986);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1504840025 ^ (long)-1504839947);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1937776292 ^ (long)1937776283);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)2054419528 ^ (long)2054419492);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)529143632 ^ (long)529143571);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-180690345 ^ (long)-180690206);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1878697893 ^ (long)1878697814);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1862604409 ^ (long)1862604468);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-591774022 ^ (long)-591774202);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1235879652 ^ (long)1235879639);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-272555312 ^ (long)-272555415);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-445639780 ^ (long)-445639781);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-429119484 ^ (long)-429119237);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1337627995 ^ (long)1337628079);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1176579790 ^ (long)1176579720);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)67016828 ^ (long)67016739);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)393688209 ^ (long)393688189);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-870288371 ^ (long)-870288335);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1801692244 ^ (long)-1801692415);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)236085108 ^ (long)236085172);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1813105811 ^ (long)1813105739);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-6063505 ^ (long)-6063567);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-2018767616 ^ (long)-2018767586);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-43108990 ^ (long)-43109024);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1913159206 ^ (long)-1913159267);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1793406384 ^ (long)1793406359);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-722824974 ^ (long)-722824992);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1031687033 ^ (long)1031686976);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-754980607 ^ (long)-754980485);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-655621489 ^ (long)-655621448);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1770950552 ^ (long)-1770950576);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-399392361 ^ (long)-399392267);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)315602794 ^ (long)315602769);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)243720401 ^ (long)243720269);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1173482077 ^ (long)1173482024);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)2080003331 ^ (long)2080003478);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)120184234 ^ (long)120184165);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)682562660 ^ (long)682562793);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1233695115 ^ (long)-1233695030);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)890121235 ^ (long)890121280);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-494125725 ^ (long)-494125800);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1202584976 ^ (long)1202584934);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1054358930 ^ (long)-1054358810);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)999111899 ^ (long)999111895);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-947838183 ^ (long)-947838057);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1603242805 ^ (long)1603242808);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-292558503 ^ (long)-292558366);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1465388216 ^ (long)1465388249);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1790405164 ^ (long)-1790405357);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1616354828 ^ (long)-1616354826);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1040656038 ^ (long)-1040655938);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1025689796 ^ (long)-1025689614);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)589387622 ^ (long)589387772);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-732531889 ^ (long)-732531954);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)402320146 ^ (long)402320155);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1328648818 ^ (long)1328648924);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1420341943 ^ (long)-1420341942);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1751729579 ^ (long)-1751729650);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1241191531 ^ (long)1241191616);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1140401060 ^ (long)1140401041);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1113011239 ^ (long)-1113011394);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-86864060 ^ (long)-86864010);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1793625874 ^ (long)-1793626081);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1568944972 ^ (long)1568945058);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-915298204 ^ (long)-915298172);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1346151054 ^ (long)1346150959);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)2061988568 ^ (long)2061988425);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)679387982 ^ (long)679387939);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-675569533 ^ (long)-675569595);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1938243421 ^ (long)-1938243334);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1131533157 ^ (long)-1131533249);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1343716020 ^ (long)1343716078);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1741436266 ^ (long)1741436365);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1651047040 ^ (long)-1651046916);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1504714222 ^ (long)-1504714014);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1951024135 ^ (long)-1951024279);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)254663325 ^ (long)254663240);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1108271439 ^ (long)1108271569);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-183550985 ^ (long)-183551080);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-323201551 ^ (long)-323201568);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)766788105 ^ (long)766788209);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1290671660 ^ (long)-1290671712);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-2145259347 ^ (long)-2145259444);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1189506604 ^ (long)1189506652);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1082058868 ^ (long)1082058890);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)406586893 ^ (long)406587118);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-532548519 ^ (long)-532548428);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-328068945 ^ (long)-328068944);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1775257969 ^ (long)-1775257864);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1786901272 ^ (long)-1786901491);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1244474261 ^ (long)1244474119);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)900419781 ^ (long)900419585);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-110453678 ^ (long)-110453520);
                    if (!51.\u2002\u200b\u2001\u2006) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)675962127 ^ (long)675962138);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1835513483 ^ (long)1835513460)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-395035276 ^ (long)-395001205)) >>> (int)((long)1349941613 ^ (long)1349941605)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-541494891 ^ (long)-541494891);
            if (!51.\u2002\u200b\u2001\u2006) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1574399271 ^ (long)-1574399269);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-2028876644 ^ (long)-2028876641) | var5_6 << (int)((long)264169643 ^ (long)264169646)) ^ var3_4[var7_8]) & (int)((long)1241637981 ^ (long)1241638050);
                    if (51.\u2002\u200b\u2001\u2006) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1795251262 ^ (long)-1795251263) | var6_7 << (int)((long)-297479278 ^ (long)-297479273)) ^ var3_4[var7_8]) & (int)((long)-218793366 ^ (long)-218793323);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            51.b[var2_3] = new String(var3_4).intern();
        }
        return 51.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 8(dfm dfm2, int n) {
        block3: {
            block2: {
                boolean bl = \u2002\u200b\u2001\u2006;
                if (bl || bl) break block2;
                float[] fArray = new float[(int)((long)-2124615609 ^ (long)-2124615610)];
                fArray[(int)((long)581219557 ^ (long)581219557)] = this.0();
                float[] fArray2 = fArray;
                if (bl || bl) break block2;
                51 v1 = this;
                v1.forEach(object -> {
                    block5: {
                        block2: {
                            String string;
                            boolean bl;
                            block4: {
                                block3: {
                                    bl = \u2002\u200b\u2001\u2006;
                                    if (bl || bl) break block2;
                                    string = (String)object.getKey();
                                    if (bl || bl) break block2;
                                    if ((object = (String)object.getValue()) == null) break block3;
                                    if (bl) break block2;
                                    if (!((String)object).isEmpty()) break block4;
                                    if (bl) break block2;
                                }
                                if (bl) break block2;
                                this.3.0.a(dfm2, string, fArray2[(int)((long)901081366 ^ (long)901081366)], (float)n, 6c.2());
                                if (bl) break block2;
                            }
                            if (bl) break block2;
                            int n2 = this.3.0.b(string);
                            if (bl || bl) break block2;
                            int n3 = (int)((long)185767801 ^ (long)185767801);
                            fArray[n3] = fArray2[n3] + (float)n2;
                            if (!bl && !bl) break block5;
                        }
                        return;
                    }
                });
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private int 0() {
        int n;
        block3: {
            block2: {
                boolean bl = \u2002\u200b\u2001\u2006;
                if (bl || bl) break block2;
                n = this.3.0.b(this.toString());
                if (!bl && !bl) break block3;
            }
            return -2101357267;
        }
        return this.3.l + Math.round(6c.7((6c)this.3).d * (float)n);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 51.\u2002\u200b\u2001\u2006;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1855290052 ^ (long)1855290061)];
            if (var7) break block23;
            var3_2 = (int)((long)-1889444009 ^ (long)-1889444009);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ubb28\u9367\u805e\u881a\ubbf2\u93c4\u804e\u88ed\ubb26\u931f\u8039\u88a3\ubb22\u93b5\u8062\u88e6\ubb94\u93cf\u809f\u8822\ubbbc\u935d\u80a2\u88e0\ubb7d\u939f\u80d9\u885c\ubb62\u93e0\u809d\u8815\ubbb6\u93d1\u806a\u889c\ubb22\u93e3\u808f\u8841\ubb66\u935b\u804d\u8850\ubbce\u93c6\u807c\u885e\ubbe8\u93b1\u8091\u885e\ubb03\u93b1\u8041\u886e\ubbc2\u93d9\u8063\u8846\ubb34\u93d1\u8093\u882a\ubb9b\u93d1\u80dc\u8803\ubb98\u93c8\u8067\u88ed\ubbbf\u9320\u80d6\u8856\ubb92\u934a\u807e\u882e\ubb49\u9356\u8031\u88ea\ubbb7\u939d\u80ad\u88f1\ubb98\u93a4\u8029\u88a5\ubbf4\u934c\u806a\u8870\ubb5d\u93f4\u801b\u88ca\ubbb4\u9308\u808d\u886f\ubbbf\u9301\u80f0\u889d\ubb1c\u932b\u802c\u8888\ubb2c\u93bb\u80b1\u88cd\ubbb7\u93f4\u8039\u8847\ubb7d\u937f\u8086\u88bc\ubb88\u9356\u8048\u886f\ubbfe\u936f\u80df\u8814\ubbf2\u9366\u8028\u88e9\ubb9e\u93a1\u802d\u88fd\ubb34\u930e\u8092\u887a\ubbb1\u935d\u8095\u8846\ubb33\u939b\u807d\u8846\ubbaf\u93c1\u801c\u8805\ubb0c\u93a6\u8099\u88bb\ubbac\u9311\u803b\u8891\ubb0f\u931f\u80bf\u882a\ubbd7\u9365\u802c\u8878\ubbdd\u9334\u80f2\u8834\ubb00\u93ef\u80a7\u8884\ubba5\u937b\u8026\u88ef\ubb25\u93ca\u8030\u8819\ubb76\u9374\u80a6\u886e\ubbac\u93d0\u8075\u88f8\ubba7\u932e\u80b2\u88ac\ubbeb\u932d\u8034\u8800\ubb4c\u93a3\u8060\u886a\ubbb8", -48128725);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1724442452 ^ (long)1724442451);
            if (var7) break block23;
            var0_6 = (int)((long)1544539085 ^ (long)-1544539086);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1156046662 ^ (long)1156046653);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1834447516 ^ (long)-1834447517);
                    if (51.\u2002\u200b\u2001\u2006) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!51.\u2002\u200b\u2001\u2006) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u94af\ubcbf\uaf41\ua77f\u94ba\ubc95\uaf3e\ua744\u9400", -754929034);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-546907576 ^ (long)-546907572);
                            var0_6 = (int)((long)1239614464 ^ (long)-1239614465);
                            while (true) {
                                v0 = (int)((long)1199319053 ^ (long)1199319094);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1247426912 ^ (long)1247426912);
                                if (!51.\u2002\u200b\u2001\u2006) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!51.\u2002\u200b\u2001\u2006) ** continue;
                                throw null;
                            }
                            51.a = var5_1;
                            51.b = new String[(int)((long)-970944956 ^ (long)-970944947)];
                            if (!51.\u2002\u200b\u2001\u2006) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-2112663294 ^ (long)-2112663294);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-707220461 ^ (long)-707220462)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)532403585 ^ (long)532403590)) {
                                case 0: {
                                    v15 = (int)((long)261555407 ^ (long)261555438);
                                    if (!51.\u2002\u200b\u2001\u2006) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1320004173 ^ (long)-1320004223);
                                    if (!51.\u2002\u200b\u2001\u2006) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1178683913 ^ (long)-1178683959);
                                    if (!51.\u2002\u200b\u2001\u2006) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1293625189 ^ (long)1293625159);
                                    if (!51.\u2002\u200b\u2001\u2006) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1585893238 ^ (long)1585893200);
                                    if (!51.\u2002\u200b\u2001\u2006) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-203438296 ^ (long)-203438281);
                                    if (!51.\u2002\u200b\u2001\u2006) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-242775695 ^ (long)-242775753);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!51.\u2002\u200b\u2001\u2006);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    public 51(6c c2, 51 var2_2) {
        boolean bl = \u2002\u200b\u2001\u2006;
        this(c2);
        this.addAll(var2_2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final List<2f> 6(int n) {
        LinkedList<2f> linkedList;
        block3: {
            block2: {
                boolean bl = \u2002\u200b\u2001\u2006;
                if (bl || bl) break block2;
                linkedList = new LinkedList<2f>();
                if (bl || bl) break block2;
                int[] nArray = new int[(int)((long)-8626717 ^ (long)-8626718)];
                nArray[(int)((long)-1586819465 ^ (long)-1586819465)] = this.0();
                int[] nArray2 = nArray;
                if (bl || bl) break block2;
                51 v1 = this;
                v1.forEach(object -> {
                    int n2;
                    String string;
                    block6: {
                        int n3;
                        block9: {
                            block7: {
                                Matcher matcher;
                                block8: {
                                    block5: {
                                        boolean bl = \u2002\u200b\u2001\u2006;
                                        if (bl || bl) break block5;
                                        string = (String)object.getKey();
                                        if (bl || bl) break block5;
                                        if ((object = (String)object.getValue()) == null) break block6;
                                        if (bl) break block5;
                                        if (((String)object).isEmpty()) break block6;
                                        if (bl || bl) break block5;
                                        matcher = Pattern.compile(51.a((int)((long)-1060403162 ^ (long)-1060390996), (int)((long)-801203032 ^ (long)-801198599)) /* "^\\s+" */).matcher(string);
                                        if (!matcher.find()) break block7;
                                        if (!bl) break block8;
                                    }
                                    return;
                                }
                                n3 = this.3.0.b(matcher.group());
                                if (\u2002\u200b\u2001\u2006) {
                                    throw null;
                                }
                                break block9;
                            }
                            n3 = (int)((long)-1080112341 ^ (long)-1080112341);
                        }
                        n2 = n3;
                        2f f = new 2f(n2 + nArray2[(int)((long)-1113718262 ^ (long)-1113718262)], n, 5e.a, string.trim(), (String)object, (boolean)((long)-1429121604 ^ (long)-1429121604));
                        f.2(this.3.0);
                        linkedList.add(f);
                    }
                    n2 = this.3.0.b(string);
                    int n4 = (int)((long)1700019847 ^ (long)1700019847);
                    nArray[n4] = nArray2[n4] + n2;
                });
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return linkedList;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean isEmpty() {
        boolean bl = \u2002\u200b\u2001\u2006;
        if (bl || bl) return true;
        if (super.isEmpty()) {
            if (bl) return true;
            return (int)((long)248846580 ^ (long)248846581) != 0;
        }
        if (bl) return true;
        if (!this.toString().matches(51.a((int)((long)1443310670 ^ (long)1443304387), (int)((long)-1077909767 ^ (long)1077915133)))) {
            if (bl) return true;
            return (int)((long)1288716354 ^ (long)1288716355) != 0;
        }
        if (!bl) return (int)((long)126125340 ^ (long)126125340) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static String 7(String string) {
        boolean bl = \u2002\u200b\u2001\u2006;
        if (bl || bl) return null;
        if ((string = string.trim()).matches(51.a((int)((long)-2003290498 ^ (long)-2003301904), (int)((long)-1297175528 ^ (long)1297181137)) /* "^((https?://)?[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?[.][a-zA-Z]{2,})[-A-Za-z0-9+&@#/%?=~_()|!:,.;]*[-A-Za-z0-9+&@#/%=~_()|]$" */)) {
            if (bl || bl) return null;
            if (string.matches(51.a((int)((long)-598223896 ^ (long)-598217632), (int)((long)-2074262953 ^ (long)-2074249484)) /* "^(discord\\.gg|impactclient.net).*" */)) {
                if (bl || bl) return null;
                string = 51.a((int)((long)1221222569 ^ (long)1221222178), (int)((long)-1593987923 ^ (long)-1593988192)) /* "https://" */.concat(String.valueOf(string));
                if (bl) return null;
            }
            if (bl) return null;
            if (!string.matches(51.a((int)((long)-779022910 ^ (long)-779013555), (int)((long)-948647215 ^ (long)948638772)) /* "^https?://.*" */)) {
                if (bl || bl) return null;
                string = 51.a((int)((long)328234151 ^ (long)328223531), (int)((long)48774436 ^ (long)-48788950)) /* "http://" */.concat(String.valueOf(string));
                if (bl) return null;
            }
            if (bl) return null;
            return string;
        }
        if (!bl) return null;
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 4() {
        block4: {
            boolean bl = \u2002\u200b\u2001\u2006;
            if (!bl) {
                while (!bl) {
                    Object object = (Map.Entry)this.pollLast();
                    if (object != null) {
                        if (bl || bl) break;
                        if (((String)(object = (String)object.getKey())).matches(51.a((int)((long)-967331099 ^ (long)-967340692), (int)((long)1264039716 ^ (long)1264033541)) /* ".*\\S+.*" */)) {
                            if (bl || bl) break;
                            this.4(((String)object).replaceAll(51.a((int)((long)-1460936258 ^ (long)-1460937157), (int)((long)1933276330 ^ (long)1933249193)) /* "\\s+$" */, 2w$6X.KAOZ("", 188204420)));
                            if (bl || bl) break;
                            return;
                        }
                        if (bl) break;
                        if (!\u2002\u200b\u2001\u2006) continue;
                        throw null;
                    }
                    if (!bl) break block4;
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 51(6c c2) {
        boolean bl = \u2002\u200b\u2001\u2006;
        this.3 = c2;
        if (bl || bl) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 4(String string) {
        block3: {
            block2: {
                boolean bl = \u2002\u200b\u2001\u2006;
                if (bl || bl) break block2;
                String string2 = string;
                this.add(new AbstractMap.SimpleEntry<String, String>(string2, 51.7(string2)));
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    @Override
    public final String toString() {
        boolean bl = \u2002\u200b\u2001\u2006;
        if (bl || bl) {
            return null;
        }
        return String.join((CharSequence)2w$6X.KAOZ("", 855893356), this.stream().map(Map.Entry::getKey).collect(Collectors.toList()));
    }
}

