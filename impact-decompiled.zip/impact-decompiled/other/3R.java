/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  javax.annotation.Nullable
 *  vk
 */
package net.impactclient;

import com.google.gson.annotations.SerializedName;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.UUID;
import javax.annotation.Nullable;
import net.impactclient.25;
import net.impactclient.2w$6X;
import net.impactclient.52;
import net.impactclient.5z;
import net.impactclient.6J;
import net.impactclient.6L;
import net.impactclient.93;
import net.impactclient.9T;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3R {
    private final Map<String, OptionalInt> 2;
    @SerializedName(value="cape")
    private String 6;
    public static final boolean \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
    private static final String[] b;
    private static final String[] a;
    @SerializedName(value="bg_color")
    private String 3;
    private static final Map<String, 3R> 0;
    @SerializedName(value="border_color")
    private String 4;
    @SerializedName(value="icon")
    public String 7;
    @SerializedName(value="text_shadow")
    public boolean 8;
    @SerializedName(value="text_color")
    private String 9;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1557535175 ^ (long)-1557546784)) & (int)((long)38943548 ^ (long)38978755);
            if (var9_2) ** GOTO lbl-1000
            if (3R.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3R.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)2102183054 ^ (long)2102183054)] & (int)((long)-576047046 ^ (long)-576046907)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1197213773 ^ (long)-1197213744);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-638826749 ^ (long)-638826575);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)447900052 ^ (long)447899995);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-333653800 ^ (long)-333653902);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)560209747 ^ (long)560209897);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1543817645 ^ (long)-1543817639);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1818124612 ^ (long)1818124650);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1483924184 ^ (long)1483923988);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)870419651 ^ (long)870419530);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-613488610 ^ (long)-613488425);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1472375845 ^ (long)1472376007);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1354569225 ^ (long)-1354569385);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1512748250 ^ (long)1512748109);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1869743949 ^ (long)-1869743898);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1947726470 ^ (long)-1947726570);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1131602460 ^ (long)1131602682);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)138293924 ^ (long)138294003);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1273947674 ^ (long)-1273947775);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-835098496 ^ (long)-835098596);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)2011031097 ^ (long)2011031184);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1262709411 ^ (long)-1262709448);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-466843660 ^ (long)-466843806);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-884220887 ^ (long)-884220834);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)721968071 ^ (long)721968028);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1072448923 ^ (long)-1072448970);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1411485356 ^ (long)1411485292);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1860824856 ^ (long)1860824900);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1059242939 ^ (long)-1059242756);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1815276412 ^ (long)1815276402);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)949301644 ^ (long)949301706);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1136789494 ^ (long)-1136789429);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1982173985 ^ (long)-1982174013);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)254212357 ^ (long)254212516);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1538081685 ^ (long)1538081653);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1546612510 ^ (long)1546612714);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-948569989 ^ (long)-948569858);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1212987625 ^ (long)1212987506);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1471804180 ^ (long)-1471804385);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1136531324 ^ (long)1136531325);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1508118386 ^ (long)-1508118308);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)487140516 ^ (long)487140585);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)655824647 ^ (long)655824712);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1999205748 ^ (long)1999205794);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1099912812 ^ (long)1099912717);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-114502500 ^ (long)-114502526);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)566886275 ^ (long)566886242);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-2141745623 ^ (long)-2141745583);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-708761557 ^ (long)-708761534);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-2000663385 ^ (long)-2000663533);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)93822811 ^ (long)93822941);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-908662701 ^ (long)-908662595);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1224330402 ^ (long)1224330241);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1020258064 ^ (long)1020258236);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)369393092 ^ (long)369393003);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)34253518 ^ (long)0x20AAA0A);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)108696608 ^ (long)108696616);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1983811071 ^ (long)-1983811069);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1164110848 ^ (long)-1164110675);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-385679059 ^ (long)-385678995);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-243425827 ^ (long)-243426003);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-908441038 ^ (long)-908441041);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-695476603 ^ (long)-695476552);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)2141057781 ^ (long)2141057786);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1803050429 ^ (long)1803050441);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)365221936 ^ (long)365221896);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1056593465 ^ (long)-1056593522);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-819310665 ^ (long)-819310701);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-61279965 ^ (long)-61279962);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1202158235 ^ (long)-1202158295);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1054392099 ^ (long)-1054392316);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1202849701 ^ (long)1202849592);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)200428011 ^ (long)200427796);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)839072379 ^ (long)839072277);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1576912379 ^ (long)-1576912234);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1718767009 ^ (long)1718766975);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)828230773 ^ (long)828230780);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1503907992 ^ (long)-1503907933);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1248509435 ^ (long)-1248509410);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1926826600 ^ (long)-1926826667);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-687871709 ^ (long)-687871709);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1991083037 ^ (long)1991083238);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)269142589 ^ (long)269142603);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1845110802 ^ (long)-1845110880);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)923696097 ^ (long)923695910);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1004683073 ^ (long)1004683202);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1293459073 ^ (long)1293459169);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1839963398 ^ (long)1839963596);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1101768172 ^ (long)1101768142);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-927177174 ^ (long)-927177037);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1144964124 ^ (long)1144964343);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1923130115 ^ (long)1923130257);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)487125992 ^ (long)487125938);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)167227185 ^ (long)167227336);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1818332615 ^ (long)-1818332655);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1371716448 ^ (long)1371716506);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)2056642266 ^ (long)2056642223);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-127143326 ^ (long)-127143261);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1055544124 ^ (long)-1055544110);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1258928793 ^ (long)-1258928758);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-528919646 ^ (long)-528919565);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1485135080 ^ (long)-1485134925);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1412327997 ^ (long)-1412328130);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-793061974 ^ (long)-793062121);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)363642343 ^ (long)363642165);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-764399642 ^ (long)-764399772);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)2107563386 ^ (long)2107563287);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1327195161 ^ (long)1327195147);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)678820712 ^ (long)678820673);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)575937253 ^ (long)575937086);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1116240960 ^ (long)-1116240993);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1004355375 ^ (long)1004355576);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1758236111 ^ (long)1758236127);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1860952433 ^ (long)1860952565);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1454938885 ^ (long)-1454939043);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1486009042 ^ (long)-1486008871);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-933392889 ^ (long)-933392686);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-365183293 ^ (long)-365183239);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-302091444 ^ (long)-302091399);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1440372346 ^ (long)1440372450);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-17971968 ^ (long)-17971935);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-564241628 ^ (long)-564241586);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1121464906 ^ (long)1121464957);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)2127952572 ^ (long)2127952540);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)497119992 ^ (long)497119937);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-673505575 ^ (long)-673505549);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)136613352 ^ (long)136613265);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1020156149 ^ (long)-1020155906);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-322968649 ^ (long)-322968776);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-573761808 ^ (long)-573761966);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1820463994 ^ (long)-1820464115);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1608356915 ^ (long)-1608356888);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1689956359 ^ (long)1689956406);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-552379816 ^ (long)-552379899);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1713653921 ^ (long)-1713653784);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-432557528 ^ (long)-432557472);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-671274067 ^ (long)-671274184);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1535459353 ^ (long)1535459493);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1999683457 ^ (long)-1999683366);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-94789914 ^ (long)-94789920);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1142775589 ^ (long)1142775648);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)814936186 ^ (long)814936106);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-773939757 ^ (long)-773939776);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)919614997 ^ (long)919615178);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1655873196 ^ (long)1655873056);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)665793700 ^ (long)665793696);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1189443915 ^ (long)1189443995);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1664269364 ^ (long)1664269452);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1896583367 ^ (long)-1896583255);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)667269079 ^ (long)667269045);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1048815517 ^ (long)-1048815493);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1569994034 ^ (long)1569994172);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1848351694 ^ (long)-1848351671);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1016376338 ^ (long)-1016376512);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)819850745 ^ (long)819850674);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1270738689 ^ (long)1270738907);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1432824499 ^ (long)1432824382);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-2142066549 ^ (long)-2142066626);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)0x6F661111 ^ (long)1868960096);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-25108935 ^ (long)-25108781);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-34020577 ^ (long)-34020387);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1898248726 ^ (long)-1898248945);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1826105395 ^ (long)-1826105409);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1305086412 ^ (long)1305086301);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)345678614 ^ (long)345678846);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-471100910 ^ (long)-471100915);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1930772257 ^ (long)-1930772308);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)393160976 ^ (long)393161015);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1508496302 ^ (long)-1508496194);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1359749866 ^ (long)-1359749848);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1538260895 ^ (long)-1538260880);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)408352456 ^ (long)408352419);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-2010964079 ^ (long)-2010964085);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1882578065 ^ (long)1882578134);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1881991945 ^ (long)-1881991983);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)482144495 ^ (long)482144327);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1682633537 ^ (long)1682633634);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)26290277 ^ (long)26290265);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-2070576563 ^ (long)-2070576430);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1583411341 ^ (long)-1583411447);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)64699826 ^ (long)64699789);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)235468467 ^ (long)235468354);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-805133642 ^ (long)-805133824);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)63681894 ^ (long)63681979);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1722295605 ^ (long)1722295608);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1440696088 ^ (long)1440696278);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1708091341 ^ (long)1708091195);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1133128030 ^ (long)-1133128163);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-2089883934 ^ (long)-2089884062);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1844446044 ^ (long)-1844446111);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1356731804 ^ (long)-1356731716);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-272806565 ^ (long)-272806549);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-786704035 ^ (long)-786704094);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-816995807 ^ (long)-816995681);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)834662956 ^ (long)834663109);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1609259363 ^ (long)-1609259474);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)613393781 ^ (long)613393825);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1420540978 ^ (long)1420541114);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1801332416 ^ (long)-1801332393);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1910062103 ^ (long)-1910062207);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1327035698 ^ (long)1327035652);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-17987802 ^ (long)-17987611);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1833341654 ^ (long)-1833341592);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-341965026 ^ (long)-341964984);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-223945300 ^ (long)-223945378);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-709323803 ^ (long)-709323792);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-665856015 ^ (long)-665856014);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)898939618 ^ (long)898939493);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1137666056 ^ (long)-1137666231);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1433546763 ^ (long)1433546995);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1231051619 ^ (long)-1231051602);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1252231289 ^ (long)1252231345);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-338392825 ^ (long)-338392669);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1825393735 ^ (long)-1825393770);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)908563225 ^ (long)908563369);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-2133274345 ^ (long)-2133274284);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1564128970 ^ (long)1564128954);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)53445229 ^ (long)53445334);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-2038679274 ^ (long)-2038679238);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1236884537 ^ (long)1236884577);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)2077929976 ^ (long)2077929953);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1986425440 ^ (long)1986425502);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1635737071 ^ (long)-1635736834);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)741788691 ^ (long)741788746);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1122216082 ^ (long)1122216174);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1326249927 ^ (long)1326249932);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1843093571 ^ (long)-1843093695);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-633733560 ^ (long)-633733479);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-980979907 ^ (long)-980979751);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)2049939673 ^ (long)2049939613);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1889907176 ^ (long)-1889907060);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)753768821 ^ (long)753768723);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)2117326094 ^ (long)2117326106);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1004359983 ^ (long)1004360101);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)365027380 ^ (long)365027419);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)991652716 ^ (long)991652687);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)568023313 ^ (long)568023478);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1338971320 ^ (long)-1338971313);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-2135519365 ^ (long)-2135519415);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1976003891 ^ (long)1976004079);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1343371494 ^ (long)-1343371471);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-365656440 ^ (long)-365656397);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)860898680 ^ (long)860898676);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)815696181 ^ (long)815696203);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-9544771 ^ (long)-9544823);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1591172635 ^ (long)-1591172810);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)265098928 ^ (long)265098870);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-203976461 ^ (long)-203976595);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1995606781 ^ (long)-1995606711);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-514127855 ^ (long)-514127803);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1741022501 ^ (long)1741022655);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1430737955 ^ (long)-1430738118);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1456316242 ^ (long)1456316287);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1444440824 ^ (long)-1444440724);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1650235363 ^ (long)-1650235236);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-695329574 ^ (long)-695329660);
                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)262743710 ^ (long)262743779);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1816843411 ^ (long)-1816843374)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1415299621 ^ (long)1415265754)) >>> (int)((long)-1863737308 ^ (long)-1863737300)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-855828596 ^ (long)-855828596);
            if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1939636732 ^ (long)1939636734);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1099582866 ^ (long)-1099582867) | var5_6 << (int)((long)-798255229 ^ (long)-798255226)) ^ var3_4[var7_8]) & (int)((long)611568999 ^ (long)611569048);
                    if (3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1194845670 ^ (long)1194845669) | var6_7 << (int)((long)509536215 ^ (long)509536210)) ^ var3_4[var7_8]) & (int)((long)-1656651738 ^ (long)-1656651559);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3R.b[var2_3] = new String(var3_4).intern();
        }
        return 3R.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public 3R() {
        block3: {
            block2: {
                boolean bl = \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
                if (bl || bl) break block2;
                this.2 = new HashMap<String, OptionalInt>();
                if (bl || bl) break block2;
                this.8 = (int)((long)865716486 ^ (long)865716487);
                if (!bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)1954258016 ^ (long)1954258023)];
            if (var7) break block25;
            var3_2 = (int)((long)1272870611 ^ (long)1272870611);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\uc042\ue882\ufb5f\uf314\uc02c\ue844\ufb73\uf3de\uc0a3\ue84c\ufb0a\uf32b\uc054\ue85a\ufb0c\uf3df\uc00f\ue87f\ufbd9\uf3ca\uc0e1\ue83a\ufbfa\uf32a\uc0f0\ue831\ufb33\uf3ae\uc069\ue8f2\ufbff\uf3b8\uc0b3\ue893\ufbd2\uf325\uc093\ue881\ufbe6\uf38f\uc03a\ue829\ufb5d\uf3c2\uc04e\ue8dd\ufbbb\uf394\uc0b9\ue8f2\ufb4a\uf32b\uc045\ue847\ufb0f\uf3a3\uc02c\ue8f5\ufbb1\uf3dc\uc03f\ue82e\ufb6f\uf3cc\uc050\ue867\ufb57\uf3b6\uc084\ue832\ufb7e\uf376\uc034\ue815\ufb2d\uf353\uc0ac\ue866\ufb9b\uf36b\uc068\ue8de\ufb04\uf346\uc07c\ue866\ufbe9\uf3bc\uc01b\ue81f\ufbcd\uf36e\uc06e\ue836\ufb9f\uf324\uc050\ue899\ufb95\uf3b8\uc012\ue84c\ufbdf\uf3ac\uc01c\ue892\ufbe0\uf380\uc0f1\ue88f\ufb7a\uf32b\uc0b0\ue80e\ufb3f\uf3ab\uc06a\ue89f\ufb59\uf317\uc083\ue8d2\ufba9\uf3cf\uc0dc", -34216404);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)1862362914 ^ (long)1862362917);
            if (var7) break block25;
            var0_6 = (int)((long)111832087 ^ (long)-111832088);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)-265693500 ^ (long)-265693497);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)2044212443 ^ (long)-2044212444);
                        if (3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\u1d26\u3580\u262f\u2e70\u1d2c\u35cc\u267a\u2e0f\u1df1\u3522\u261d\u2eac\u1d6c\u35e8\u269a\u2e9d\u1d44\u358a\u263b\u2e01\u1d5f\u35ba\u26c4\u2e9d\u1da6\u35ee\u2620\u2e17\u1d92\u35d9\u266f\u2e18\u1dcb\u357e\u26ef\u2e3d\u1d78\u35f6\u2628\u2e6d\u1d5f\u3577\u26c3\u2e3b\u1da6\u359d", -75875414);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)1640156904 ^ (long)1640156879);
                                var0_6 = (int)((long)-253731836 ^ (long)253731835);
                                while (true) {
                                    v0 = (int)((long)-1317675007 ^ (long)-1317674909);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)-1149719570 ^ (long)-1149719570);
                                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) ** continue;
                                    throw null;
                                }
                                3R.a = var5_1;
                                3R.b = new String[(int)((long)232141679 ^ (long)232141672)];
                                if (3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)660513290 ^ (long)660513290);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)-1632505843 ^ (long)-1632505844)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-701195537 ^ (long)-701195544)) {
                                    case 0: {
                                        v15 = (int)((long)297096444 ^ (long)297096388);
                                        if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)-1840056288 ^ (long)-1840056295);
                                        if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)2108963059 ^ (long)2108962961);
                                        if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)-1485271205 ^ (long)-1485271190);
                                        if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)-1238673180 ^ (long)-1238673181);
                                        if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)-424601778 ^ (long)-424601784);
                                        if (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)-751356812 ^ (long)-751356886);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!3R.\u2008\u2002\u200b\u2007\u2005\u200a\u200f);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                3R.0 = new HashMap<String, 3R>();
                break;
            }
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void 5() {
        Map map;
        boolean bl = \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
        if (bl || bl) return;
        0.clear();
        if (bl) return;
        try {
            if (bl) return;
            map = (Map)93.0(new URL(3R.a((int)((long)1382620053 ^ (long)1382630733), (int)((long)-1295018402 ^ (long)1295005133)) /* "https://api.impactclient.net/v1/minecraft/user/info" */), new 25().getType());
            if (map == null) {
                if (bl || bl) return;
                throw new IOException(3R.a((int)((long)1714220618 ^ (long)1714204817), (int)((long)-1070075149 ^ (long)-1070083323)) /* "Failed to parse response while loading user info." */);
            }
        }
        catch (IOException iOException) {
            if (bl || bl) return;
            5z.9.error(3R.a((int)((long)1950689081 ^ (long)1950710245), (int)((long)-907738864 ^ (long)-907730271)) /* "Error loading user info from Impact API" */, (Throwable)iOException);
            if (bl || bl) return;
            return;
        }
        {
            if (bl) return;
            0.putAll(map);
            if (bl || bl) return;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final Optional<vk> 0() {
        boolean bl;
        block8: {
            block7: {
                bl = \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
                if (bl || bl) return null;
                if (this.6 == null) break block7;
                if (bl) return null;
                if (!this.6.isEmpty()) break block8;
                if (bl) return null;
            }
            if (bl) return null;
            return Optional.empty();
        }
        if (!bl) return Optional.ofNullable(6J.0(this.6, (boolean)((long)-800049104 ^ (long)-800049103)));
        return null;
    }

    public final OptionalInt 6() {
        boolean bl = \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
        if (bl || bl) {
            return null;
        }
        return this.2.computeIfAbsent(3R.a((int)((long)-1932567463 ^ (long)-1932590461), (int)((long)723807035 ^ (long)723792718)) /* "background" */, string -> {
            boolean bl = \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
            if (bl || bl) {
                return null;
            }
            return 6L.8(this.3);
        });
    }

    public final OptionalInt 3() {
        boolean bl = \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
        if (bl || bl) {
            return null;
        }
        return this.2.computeIfAbsent(3R.a((int)((long)1048442835 ^ (long)1048422668), (int)((long)-2019880850 ^ (long)2019879502)) /* "border" */, string -> {
            boolean bl = \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
            if (bl || bl) {
                return null;
            }
            return 6L.8(this.4);
        });
    }

    public final OptionalInt 9() {
        boolean bl = \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
        if (bl || bl) {
            return null;
        }
        return this.2.computeIfAbsent(3R.a((int)((long)-975257964 ^ (long)-975249335), (int)((long)-1247323990 ^ (long)-1247338889)) /* "name" */, string -> {
            boolean bl = \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
            if (bl || bl) {
                return null;
            }
            return 6L.8(this.9);
        });
    }

    /*
     * Enabled aggressive block sorting
     */
    @Nullable
    @Deprecated
    public static 3R 5(UUID object) {
        boolean bl = \u2008\u2002\u200b\u2007\u2005\u200a\u200f;
        if (bl || bl) return null;
        if (object == null) {
            if (bl || bl) return null;
            return null;
        }
        if (bl) return null;
        object = 9T.3(3R.a((int)((long)1482069322 ^ (long)1482083219), (int)((long)-34939714 ^ (long)34934709)) /* "SHA-256" */).7(((UUID)object).toString(), 52.1);
        if (!bl && !bl) return 0.getOrDefault(object, null);
        return null;
    }
}

