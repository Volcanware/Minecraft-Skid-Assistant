/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.ImpactDevelopment.installer.Installer
 *  io.github.ImpactDevelopment.installer.impact.ImpactVersionReleased
 *  io.github.ImpactDevelopment.installer.impact.ImpactVersions
 *  io.github.ImpactDevelopment.installer.setting.InstallationConfig
 *  io.github.ImpactDevelopment.installer.setting.Setting
 *  io.github.ImpactDevelopment.installer.setting.settings.ImpactVersionSetting
 *  io.github.ImpactDevelopment.installer.setting.settings.InstallationModeSetting
 *  io.github.ImpactDevelopment.installer.setting.settings.MinecraftDirectorySetting
 *  io.github.ImpactDevelopment.installer.setting.settings.MinecraftVersionSetting
 *  io.github.ImpactDevelopment.installer.setting.settings.OptiFineSetting
 *  io.github.ImpactDevelopment.installer.target.InstallationModeOptions
 *  io.github.ImpactDevelopment.installer.target.targets.Vanilla
 *  io.github.ImpactDevelopment.installer.utils.GPG
 *  org.apache.commons.io.IOUtils
 *  org.apache.logging.log4j.Level
 *  x
 */
package net.impactclient;

import io.github.ImpactDevelopment.installer.Installer;
import io.github.ImpactDevelopment.installer.impact.ImpactVersionReleased;
import io.github.ImpactDevelopment.installer.impact.ImpactVersions;
import io.github.ImpactDevelopment.installer.setting.InstallationConfig;
import io.github.ImpactDevelopment.installer.setting.Setting;
import io.github.ImpactDevelopment.installer.setting.settings.ImpactVersionSetting;
import io.github.ImpactDevelopment.installer.setting.settings.InstallationModeSetting;
import io.github.ImpactDevelopment.installer.setting.settings.MinecraftDirectorySetting;
import io.github.ImpactDevelopment.installer.setting.settings.MinecraftVersionSetting;
import io.github.ImpactDevelopment.installer.setting.settings.OptiFineSetting;
import io.github.ImpactDevelopment.installer.target.InstallationModeOptions;
import io.github.ImpactDevelopment.installer.target.targets.Vanilla;
import io.github.ImpactDevelopment.installer.utils.GPG;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import net.impactclient.1Q;
import net.impactclient.2w$6X;
import net.impactclient.341;
import net.impactclient.3sp;
import net.impactclient.4P;
import net.impactclient.5B;
import net.impactclient.5z;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.Level;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3sb
implements 3sp {
    private static final String[] b;
    private static final String[] a;
    public final 341 2;
    public static final boolean \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static InstallationConfig 7(ImpactVersionReleased object) {
        Object object2;
        InstallationConfig installationConfig;
        boolean bl;
        block19: {
            bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
            if (bl || bl) return null;
            if (5B.6().8()) {
                if (bl || bl) return null;
                throw new IllegalStateException(3sb.a((int)((long)1719914043 ^ (long)1719907592), (int)((long)1185056889 ^ (long)-1185058090)));
            }
            if (bl) return null;
            installationConfig = new InstallationConfig();
            object2 = (Path)installationConfig.getSettingValue((Setting)MinecraftDirectorySetting.INSTANCE);
            if (!object2.toFile().getAbsoluteFile().equals(3sb.3.n.getAbsoluteFile())) {
                if (bl || bl) return null;
                throw new IllegalArgumentException(3sb.a((int)((long)-1896971032 ^ (long)-1896939561), (int)((long)1512939599 ^ (long)-1512935261)) /* "Wrong mc path " */ + object2.toFile().getAbsoluteFile() + 2w$6X.KAOZ("\uf68b", 596657597) + 3sb.3.n.getAbsoluteFile());
            }
            if (bl) return null;
            if (!3sb.2().contains(new File(3sb.3.n, 3sb.a((int)((long)1001813033 ^ (long)1001787194), (int)((long)1425946581 ^ (long)-1425949209)) /* "libraries" */).toString())) {
                if (bl || bl) return null;
                throw new IllegalArgumentException(3sb.2() + 2w$6X.KAOZ("\ud606", 1983079728) + new File(3sb.3.n, 3sb.a((int)((long)-252470259 ^ (long)-252451036), (int)((long)50194193 ^ (long)50169672))));
            }
            try {
                if (bl) return null;
                if (IOUtils.toString((URI)3sb.3.n.toPath().resolve(3sb.a((int)((long)-1149184335 ^ (long)-1149194847), (int)((long)97888419 ^ (long)97906327)) /* "versions" */).resolve(3.g()).resolve(3.g() + 3sb.a((int)((long)-404253491 ^ (long)-404230145), (int)((long)1283656087 ^ (long)1283678288)) /* ".json" */).toUri(), (Charset)StandardCharsets.UTF_8).contains(3sb.a((int)((long)1110362442 ^ (long)1110356591), (int)((long)1185864873 ^ (long)-1185841981)) /* "LiteLoaderTweaker" */)) {
                    if (bl || bl) return null;
                    throw new IllegalStateException(3sb.a((int)((long)1374554513 ^ (long)1374581435), (int)((long)422558715 ^ (long)422558886)) /* "Liteloader" */);
                }
                if (bl) return null;
                if (!\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break block19;
                throw null;
            }
            catch (IOException iOException) {
                if (bl || bl) return null;
                throw new RuntimeException(iOException);
            }
        }
        if (bl) return null;
        3sb.0(installationConfig, InstallationModeSetting.INSTANCE, InstallationModeOptions.VANILLA);
        if (bl || bl) return null;
        3sb.0(installationConfig, MinecraftVersionSetting.INSTANCE, ((ImpactVersionReleased)object).mcVersion);
        if (bl || bl) return null;
        3sb.0(installationConfig, ImpactVersionSetting.INSTANCE, object);
        if (bl || bl) return null;
        object2 = 4P.5 + 3sb.a((int)((long)-1015942248 ^ (long)-1015969629), (int)((long)96518461 ^ (long)96502474)) /* "-Impact_4.9.1" */;
        if (bl || bl) return null;
        object = 3.g();
        if (!((String)object).equals(object2)) {
            if (bl || bl) return null;
            if (!((String)object).startsWith((String)object2)) {
                if (bl || bl) return null;
                throw new IllegalArgumentException(3sb.a((int)((long)-226309221 ^ (long)-226316122), (int)((long)-138395724 ^ (long)-138404996)) /* "Wrong version " */ + (String)object + 2w$6X.KAOZ("\u4c44", 309264242) + (String)object2);
            }
            if (bl) return null;
            if (!((String)(object2 = ((String)object).substring(((String)object2).length()))).startsWith(3sb.a((int)((long)-308772840 ^ (long)-308741363), (int)((long)-512870817 ^ (long)-512875728)) /* "-OptiFine_" */)) {
                if (bl || bl) return null;
                throw new IllegalArgumentException((String)object);
            }
            if (bl) return null;
            object = 4P.5 + 2w$6X.KAOZ("\u8d08", 264322625) + ((String)object2).substring((int)((long)1047594102 ^ (long)1047594108));
            if (bl || bl) return null;
            3sb.0(installationConfig, OptiFineSetting.INSTANCE, object);
            if (bl) return null;
        }
        if (bl) return null;
        new Vanilla(installationConfig).sanityCheck((boolean)((long)-1470795448 ^ (long)-1470795447));
        if (!bl && !bl) return installationConfig;
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void 9() {
        boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
        if (bl) return;
        try {
            String string;
            if (bl) return;
            Object object = 3sb.2();
            if (bl || bl) return;
            String string2 = 3sb.4();
            if (bl || bl) return;
            String[] stringArray = new String[(int)((long)1170962998 ^ (long)1170963006)];
            stringArray[(int)((long)638671514 ^ (long)638671514)] = string2;
            stringArray[(int)((long)-1205508784 ^ (long)-1205508783)] = 3sb.a((int)((long)1120600362 ^ (long)1120631301), (int)((long)-1250990677 ^ (long)1251014277)) /* "-cp" */;
            stringArray[(int)((long)-1049636770 ^ (long)-1049636772)] = object;
            stringArray[(int)((long)-1524013642 ^ (long)-1524013643)] = 3sb.a((int)((long)1922115143 ^ (long)1922129260), (int)((long)437957107 ^ (long)437964000)) /* "io.github.ImpactDevelopment.installer.Installer" */;
            stringArray[(int)((long)-1429077914 ^ (long)-1429077918)] = 3sb.a((int)((long)655402881 ^ (long)655416489), (int)((long)-1650318912 ^ (long)1650301571)) /* "--mode" */;
            int n = (int)((long)-230174648 ^ (long)-230174643);
            if (5B.6().8()) {
                string = 3sb.a((int)((long)1416878425 ^ (long)1416864378), (int)((long)1942069972 ^ (long)1942079491)) /* "Forge" */;
                if (\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) {
                    throw null;
                }
            } else {
                string = 3sb.a((int)((long)2066511198 ^ (long)2066484857), (int)((long)-1431122600 ^ (long)1431110266)) /* "Vanilla" */;
            }
            stringArray[n] = string;
            stringArray[(int)((long)-1545240392 ^ (long)-1545240386)] = 3sb.a((int)((long)950543407 ^ (long)950558478), (int)((long)2037569899 ^ (long)-2037555867)) /* "-i" */;
            stringArray[(int)((long)168659312 ^ (long)168659319)] = this.2.9.getCombinedVersion();
            object = new ArrayList<String>(Arrays.asList(stringArray));
            if (Installer.args.prereleases) {
                object.add(3sb.a((int)((long)-1900632190 ^ (long)-1900618574), (int)((long)1211308204 ^ (long)-1211326847)) /* "--prereleases" */);
            }
            System.out.println(3sb.a((int)((long)1123948381 ^ (long)1123970173), (int)((long)1571209364 ^ (long)1571208482)) /* "Installer command: " */.concat(String.valueOf(object)));
            object = new ProcessBuilder((List<String>)object).start();
            Thread.sleep(0x3BEEA50E1B9DE4DFL ^ 0x3BEEA50E1B9DED1BL);
            if (!((Process)object).isAlive()) {
                System.out.println(IOUtils.toString((InputStream)((Process)object).getInputStream(), (Charset)StandardCharsets.UTF_8));
                System.err.println(IOUtils.toString((InputStream)((Process)object).getErrorStream(), (Charset)StandardCharsets.UTF_8));
                throw new IllegalStateException(3sb.a((int)((long)833549761 ^ (long)833523445), (int)((long)908732695 ^ (long)-908746939)) /* "Failed to open installer" */);
            }
            3.n();
            return;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            if (bl || bl) return;
            System.out.println(3sb.a((int)((long)-504705637 ^ (long)-504711508), (int)((long)-831931372 ^ (long)-831928474)) /* "Falling back to opening the website!" */);
            if (bl || bl) return;
            x.i().a(3sb.a((int)((long)-821390360 ^ (long)-821368582), (int)((long)1402481241 ^ (long)-1402496831)) /* "https://impactclient.net/?updating=true" */);
            if (bl || bl) return;
            3.n();
            if (bl || bl) return;
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-475779016 ^ (long)-475779043)];
            if (var7) break block23;
            var3_2 = (int)((long)-897739283 ^ (long)-897739283);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u53e8\ueef6\ufda0\uf518\u538b\ueef8\ufd81\uf56e\u53d5\ueea8\ufd64\uf5b9\u53f9\ueeef\ufdc6\uf546\u539b\ueecd\ufda8\uf55d\u5380\ueedd\ufdfb\uf5ed\u53ab\ueebc\ufdf5\uf552\u5344\uee3c\ufd0d\uf574\u53fd\uee9b\ufdb1\uf571\u53fc\uee35\ufdaf\uf59d\u53f1\uee32\ufd0e\uf566\u5397\uee45\ufd3b\uf55a\u53ad\uee9a\ufd50\uf512\u533e\uee34\ufd45\uf50f\u5306\uee2f\ufd52\uf5c3\u5307\uee35\ufd51\uf51d\u53b6\uee08\ufd2c\uf525\u5335\uee86\ufdfc\uf5e1\u5370\ueea1\ufd39\uf50a\u53b7\uee66\ufdc2\uf5bf\u53ba\ueeff\ufd0f\uf564\u53f3\ueef5\ufdd5\uf525\u535f\ueec3\ufdb9\uf5a3\u53d8\uee55\ufdad\uf5bb\u53b2\uee0b\ufd3d\uf572\u53ae\ueedf\ufd78\uf57a\u53c4\uee3b\ufd66\uf591\u53c7\ueef6\ufd1f\uf532\u53c4\uee26\ufda8\uf590\u5316\uee77\ufdc8\uf55b\u5338\ueeec\ufd2b\uf5b8\u538c\uee4f\ufd53\uf584\u539b\uee38\ufd8f\uf5b7\u5353\ueedf\ufde9\uf5ed\u53d0\uee2d\ufde0\uf5d8\u53aa\uee2d\ufdc9\uf50d\u53d6\uee3a\ufd68\uf542\u5342\uee34\ufd79\uf5a5\u5363\ueed3\ufd13\uf51e\u53b4\uee70\ufd04\uf55a\u531f\uee3b\ufd15\uf5ab\u53ca\uee39\ufd2e\uf57d\u53bd\uee91\ufdc2\uf58f\u53d0\uee87\ufd61\uf5b4\u5324\uee92\ufd13\uf5d1\u538b\uee59\ufde6\uf5d1\u5386\uee27\ufd8c\uf5c8\u539e\uee8a\ufded\uf596\u53fc\uee65\ufd9d\uf5e0\u53fe\uee62\ufda7\uf551\u534c\uee5b\ufd7e\uf537\u53e4\ueeae\ufd50\uf528\u5313\uee24\ufd90\uf5eb\u53e0\uee17\ufd29\uf503\u5374\uee24\ufd9d\uf56f\u530a\uee56\ufdad\uf562\u53e1\ueeff\ufd1e\uf5e8\u53c1\uee20\ufde7\uf5ca\u535b\ueea0\ufd3f\uf584\u5368\uee32\ufde2\uf542\u530a\ueec1\ufd88\uf55a\u53a1\uee85\ufd96\uf5b3\u53d9\uee26\ufda7\uf5d2\u53ef\uee17\ufddb\uf57a\u53aa\uee9e\ufdcc\uf5b7\u5359\ueecb\ufd2d\uf5a0\u5301\uee6b\ufd29\uf570\u53b4\ueee6\ufdc5\uf5fb\u536d\uee0b\ufd1d\uf576\u532f\uee38\ufd1c\uf55f\u533e\uee0d\ufd8d\uf5d5\u533a\uee9d\ufd16\uf530\u53fc\ueeeb\ufdce\uf5c2\u538a\uee86\ufdbd\uf5c8\u5305\uee94\ufd36\uf5d1\u53b6\ueeb6\ufd08\uf512\u5346\uee5d\ufdc7\uf551\u5318\uee2f\ufd9f\uf57f\u5323\ueebd\ufd4a\uf558\u5301\uee32\ufdaf\uf56b\u537d\uee1e\ufd8d\uf55a\u53ca\uee87\ufde2\uf5d8\u53c0\uee3e\ufd96\uf5b2\u53fb\uee0c\ufda0\uf5f1\u5345\uee50\ufd2e\uf559\u5388\ueee1\ufd89\uf5d2\u53d2\ueee6\ufd04\uf55d\u5348\uee5a\ufd66\uf5da\u5359\uee33\ufd75\uf553\u53f1\uee61\ufd28\uf502\u53d1\uee6a\ufdb2\uf5f8\u5394\ueed3\ufd83\uf58f\u53d0\uee37\ufd88\uf5f4\u53f8\uee78\ufd30\uf5ce\u53e5\uee75\ufde1\uf5c1\u53c0\uee5d\ufd4d\uf50a\u53e4\uee58\ufd89\uf526\u5393\uee8f\ufd55\uf52e\u5373\uee20\ufd21\uf58a\u53b8\uee7b\ufdbc\uf5ea\u535b\uee99\ufd5c\uf529\u53bb\uee23\ufd0b\uf5d3\u5385\uee10\ufd82\uf55a\u534d\uee5f\ufd9b\uf5f8\u5365\ueeb1\ufdb3\uf57e\u5324\uee03\ufde6\uf5f5\u53b3\uee6c\ufd28\uf5e7\u5349\uee27\ufd28\uf58d\u53d7\ueed2\ufd22\uf507\u5344\uee2a\ufd2e\uf5c0\u538a\ueed8\ufd88\uf5ce\u5381\uee62\ufd8d\uf51d\u5393\uee6f\ufdb7\uf5b0\u5368\uee6f\ufd23\uf5d2\u530a\uee0b\ufd71\uf527\u5336\uee8a\ufde6\uf556\u5327\uee9b\ufd1a\uf54c\u534b\uee9c\ufdef\uf598\u53ac", 540532894);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)798983714 ^ (long)798983737);
            if (var7) break block23;
            var0_6 = (int)((long)1702759481 ^ (long)-1702759482);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)2075177994 ^ (long)2075178043);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1687239031 ^ (long)1687239030);
                    if (3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u439f\ufe78\ued6a\ue579\u4376\ufec5\uedab\ue54d\u4345\ufe60\uede3\ue54b\u43fe\ufee1\ued97\ue56d\u43cb\ufeb0\ued36\ue560\u43cb\ufe5a\uedb3\ue597\u4338\ufeb4\uedf0\ue5ea\u4352\ufee0\ued5e\ue5c4\u43ed\ufe15\ued74\ue5fa\u43f5\ufebe\ued98\ue5f4\u437d\ufe94\ueddf\ue5bc\u435e\ufe85\uedb1\ue5f7\u4384\ufe6c", 1082257471);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)399704608 ^ (long)399704583);
                            var0_6 = (int)((long)-608832276 ^ (long)608832275);
                            while (true) {
                                v0 = (int)((long)1427420526 ^ (long)1427420438);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1629699510 ^ (long)-1629699510);
                                if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) ** continue;
                                throw null;
                            }
                            3sb.a = var5_1;
                            3sb.b = new String[(int)((long)-1290110862 ^ (long)-1290110889)];
                            if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-263925164 ^ (long)-263925164);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)2125601374 ^ (long)2125601375)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1875602933 ^ (long)-1875602932)) {
                                case 0: {
                                    v15 = (int)((long)1157424303 ^ (long)1157424341);
                                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-855745052 ^ (long)-855745040);
                                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-370247595 ^ (long)-370247606);
                                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-2020715707 ^ (long)-2020715680);
                                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1192500241 ^ (long)1192500303);
                                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-597789904 ^ (long)-597789948);
                                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)2107952335 ^ (long)2107952267);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static String 2() {
        String string;
        boolean bl;
        block8: {
            block7: {
                bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
                if (bl || bl) return null;
                string = GPG.class.getResource(3sb.a((int)((long)-2116497423 ^ (long)-2116504352), (int)((long)-1304117616 ^ (long)-1304113366)) /* "/keys.asc" */).getFile();
                if (!string.startsWith(3sb.a((int)((long)-1358032291 ^ (long)-1358009989), (int)((long)647210299 ^ (long)-647233236)) /* "file:" */)) break block7;
                if (bl) return null;
                if (string.endsWith(3sb.a((int)((long)1721528793 ^ (long)1721502439), (int)((long)2073643504 ^ (long)-2073644407)) /* ".jar!/keys.asc" */)) break block8;
                if (bl) return null;
            }
            if (bl) return null;
            throw new IllegalStateException(3sb.a((int)((long)-1859520957 ^ (long)-1859547781), (int)((long)-1642200905 ^ (long)1642172925)) /* "I have no idea " */.concat(String.valueOf(string)));
        }
        try {
            if (bl) return null;
            return Paths.get(new URL(string.substring((int)((long)511002866 ^ (long)511002866), string.length() - (int)((long)735384302 ^ (long)735384292))).toURI()).toFile().getAbsolutePath();
        }
        catch (Exception exception) {
            if (bl || bl) return null;
            throw new RuntimeException(exception);
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)161502890 ^ (long)161492379)) & (int)((long)-1363297607 ^ (long)-1363327674);
            if (var9_2) ** GOTO lbl-1000
            if (3sb.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3sb.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)215231377 ^ (long)215231377)] & (int)((long)545705388 ^ (long)545705299)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-905099675 ^ (long)-905099739);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-206676059 ^ (long)-206676130);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1964834498 ^ (long)-1964834441);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1475225473 ^ (long)1475225376);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1463799595 ^ (long)1463799793);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1724815286 ^ (long)1724815283);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1832431844 ^ (long)-1832431697);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1215826069 ^ (long)1215826114);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-657499976 ^ (long)-657500054);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)302555930 ^ (long)302556082);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1556765107 ^ (long)-1556765076);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1520148807 ^ (long)1520148878);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1370536795 ^ (long)1370536956);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-611131110 ^ (long)-611130894);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1121332587 ^ (long)-1121332646);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)922853737 ^ (long)922853719);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1214173334 ^ (long)-1214173252);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)944326669 ^ (long)944326661);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-734036791 ^ (long)-734036797);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-862362502 ^ (long)-862362473);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)100325972 ^ (long)100326137);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)909556220 ^ (long)909555970);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-721311762 ^ (long)-721311784);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1717436892 ^ (long)1717436680);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)2052058066 ^ (long)2052058012);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)909156420 ^ (long)909156400);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)609982750 ^ (long)609982940);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)535608346 ^ (long)535608424);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)801215758 ^ (long)801215767);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1656290508 ^ (long)-1656290366);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1432098987 ^ (long)1432098850);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1593686644 ^ (long)-1593686546);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1349403873 ^ (long)-1349403889);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1020006948 ^ (long)1020007146);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1534177967 ^ (long)1534177969);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1662669573 ^ (long)1662669817);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-2085933274 ^ (long)-2085933304);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)2047096233 ^ (long)2047096256);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-258862126 ^ (long)-258862186);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1723439404 ^ (long)-1723439375);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)75654968 ^ (long)75654923);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-758082674 ^ (long)-758082603);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-277336434 ^ (long)-277336498);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)653944736 ^ (long)653944760);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1311183996 ^ (long)-1311183886);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)2038690549 ^ (long)2038690354);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1515964250 ^ (long)-1515964245);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)2024564527 ^ (long)2024564549);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-828474914 ^ (long)-828475084);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)12926170 ^ (long)12926022);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1194712014 ^ (long)-1194711828);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1477017397 ^ (long)-1477017506);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-813053094 ^ (long)-813053105);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1362165223 ^ (long)1362165191);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1556235198 ^ (long)-1556235104);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-2026235315 ^ (long)-2026235322);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1043554761 ^ (long)-1043554667);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)616430569 ^ (long)616430488);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)889984747 ^ (long)889984744);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1729355544 ^ (long)-1729355775);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)531584750 ^ (long)531584557);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-358285565 ^ (long)-358285470);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)125498119 ^ (long)125498181);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-551797836 ^ (long)-551797912);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1120339409 ^ (long)-1120339404);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1727398893 ^ (long)-1727398884);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)550058748 ^ (long)550058595);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1090135207 ^ (long)-1090135174);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)2130288381 ^ (long)2130288230);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)527211893 ^ (long)527211784);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)653458041 ^ (long)653458077);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1357435676 ^ (long)-1357435902);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1537614962 ^ (long)1537615005);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-842807852 ^ (long)-842808025);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1469407847 ^ (long)-1469407808);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1044818836 ^ (long)1044818761);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1471749832 ^ (long)1471749819);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1758194098 ^ (long)-1758193973);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-331809464 ^ (long)-331809305);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1123848446 ^ (long)-1123848229);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-481734601 ^ (long)-481734413);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)997776848 ^ (long)997776780);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1775476617 ^ (long)-1775476527);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)2052298369 ^ (long)2052298421);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1248711742 ^ (long)1248711890);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)149427603 ^ (long)149427709);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-463103352 ^ (long)-463103364);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1831574313 ^ (long)-1831574311);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1418112265 ^ (long)1418112504);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)740299654 ^ (long)740299569);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1365838235 ^ (long)-1365838271);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-521547003 ^ (long)-521546779);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1818263662 ^ (long)-1818263677);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-867469265 ^ (long)-867469312);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)634010193 ^ (long)634010152);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)42327557 ^ (long)42327711);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1292397937 ^ (long)-1292397890);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1490861870 ^ (long)1490861998);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-2028374037 ^ (long)-2028374123);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-88259152 ^ (long)-88259270);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)17872844 ^ (long)17872693);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-447312502 ^ (long)-447312417);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1930531839 ^ (long)1930531735);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1468655782 ^ (long)1468655769);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-465473746 ^ (long)-465473715);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)52333099 ^ (long)52333293);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)354064594 ^ (long)354064497);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)611830901 ^ (long)611830836);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1972250313 ^ (long)-1972250184);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1268512065 ^ (long)-1268512222);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1332731 ^ (long)1332604);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-2029421809 ^ (long)-2029421689);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-109912247 ^ (long)-109912203);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1732445194 ^ (long)1732445345);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1892144340 ^ (long)1892144171);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1570955235 ^ (long)-1570955178);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1653673453 ^ (long)1653673344);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)162303423 ^ (long)162303424);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1195681473 ^ (long)1195681465);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1372101327 ^ (long)-1372101323);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)570534355 ^ (long)570534246);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1842801754 ^ (long)1842801722);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-236961935 ^ (long)-236961972);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1671529664 ^ (long)1671529607);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1783371709 ^ (long)-1783371522);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)2038077194 ^ (long)2038077426);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1546547138 ^ (long)1546547028);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)834501895 ^ (long)834502059);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-2139483246 ^ (long)-2139483250);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1347962842 ^ (long)-1347962790);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1508183853 ^ (long)-1508183872);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1773790288 ^ (long)-1773790424);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-195166990 ^ (long)-195167043);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1688226551 ^ (long)-1688226329);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1266516635 ^ (long)1266516673);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)329168551 ^ (long)329168420);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)300102930 ^ (long)300102977);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1129026749 ^ (long)-1129026626);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1395565687 ^ (long)1395565769);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)21550809 ^ (long)21550670);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)758322958 ^ (long)758323124);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1410614556 ^ (long)1410614631);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)980445391 ^ (long)980445204);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-648353868 ^ (long)-648353940);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1836042142 ^ (long)1836042196);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-172640746 ^ (long)-172640733);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1588421976 ^ (long)-1588421921);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1911992204 ^ (long)1911992275);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-2088494288 ^ (long)-2088494218);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1581779924 ^ (long)1581779906);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1850475815 ^ (long)1850476010);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1367160492 ^ (long)1367160490);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)53431499 ^ (long)53431453);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1505039015 ^ (long)-1505039069);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1963075010 ^ (long)-1963074817);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1558920653 ^ (long)1558920663);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1595333238 ^ (long)-1595333317);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1703312734 ^ (long)-1703312809);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1993310104 ^ (long)-1993309981);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1818128750 ^ (long)1818128732);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1128152810 ^ (long)1128152824);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-2123649969 ^ (long)-2123649825);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-934913382 ^ (long)-934913313);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1363150379 ^ (long)1363150353);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-760261117 ^ (long)-760261073);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)521172510 ^ (long)521172601);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)188628830 ^ (long)188628748);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-459388403 ^ (long)-459388398);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)249412964 ^ (long)249412931);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-622769532 ^ (long)-622769659);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-783851886 ^ (long)-783851934);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)455887249 ^ (long)455887107);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1146057500 ^ (long)1146057687);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)829177545 ^ (long)829177471);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-528584952 ^ (long)-528584815);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1947643421 ^ (long)-1947643565);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1741146157 ^ (long)-1741146150);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1603451407 ^ (long)1603451620);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)306001845 ^ (long)306001746);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-2108826995 ^ (long)-2108827026);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-921236966 ^ (long)-921236826);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-418838481 ^ (long)-418838497);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)225917142 ^ (long)225916983);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1987522174 ^ (long)-1987522057);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-473062292 ^ (long)-473062332);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1430051092 ^ (long)1430051186);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1244626806 ^ (long)1244626902);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)17931407 ^ (long)17931437);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-2113354461 ^ (long)-2113354462);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)2031259739 ^ (long)2031259766);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)117802644 ^ (long)117802736);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1544270564 ^ (long)-1544270462);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1794315693 ^ (long)1794315607);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-177007154 ^ (long)-177007284);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1611878273 ^ (long)-1611878159);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)345146824 ^ (long)345146716);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1346478553 ^ (long)1346478472);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-3089796 ^ (long)-3089745);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-694441902 ^ (long)-694441770);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1092435943 ^ (long)-1092435770);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)492703661 ^ (long)492703688);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-216493248 ^ (long)-216493134);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1425093553 ^ (long)-1425093601);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1914462429 ^ (long)1914462319);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)2018186584 ^ (long)2018186737);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-750206881 ^ (long)-750206948);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)2055598505 ^ (long)2055598530);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)6271502 ^ (long)6271542);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-644040080 ^ (long)-644040161);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1111124776 ^ (long)1111124755);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-531651792 ^ (long)-531651780);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-383248325 ^ (long)-383248141);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)105708034 ^ (long)105708263);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1180898552 ^ (long)1180898421);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-879720844 ^ (long)-879720903);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-132650637 ^ (long)-132650567);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1962760471 ^ (long)1962760593);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1581122880 ^ (long)1581123027);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-573922438 ^ (long)-573922479);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)227214562 ^ (long)227214422);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1053588696 ^ (long)1053588553);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1783105013 ^ (long)1783104805);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1001566729 ^ (long)1001566841);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)265278117 ^ (long)265278153);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)738206648 ^ (long)738206486);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-480877517 ^ (long)-480877543);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1107419343 ^ (long)1107419336);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)645254063 ^ (long)645253908);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1197406393 ^ (long)1197406227);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1371711940 ^ (long)-1371711979);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-399438446 ^ (long)-399438449);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1092440911 ^ (long)1092440859);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1571654403 ^ (long)1571654491);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1761735539 ^ (long)1761735498);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-18940435 ^ (long)-18940612);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)646001169 ^ (long)646001309);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1757097494 ^ (long)1757097474);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-876222793 ^ (long)-876222880);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)431420293 ^ (long)431420240);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-594565266 ^ (long)-594565174);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1277002900 ^ (long)1277002953);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)45625862 ^ (long)45626019);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)862813783 ^ (long)862813842);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1425360413 ^ (long)-1425360620);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1813416936 ^ (long)1813416910);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-286009633 ^ (long)-286009624);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-843958512 ^ (long)-843958353);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1938504904 ^ (long)-1938504716);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1679862306 ^ (long)-1679862378);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)2112590837 ^ (long)2112590668);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)755186964 ^ (long)755187116);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-808985935 ^ (long)-808985873);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)285912027 ^ (long)285912027);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1008225595 ^ (long)-1008225593);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-234685272 ^ (long)-234685249);
                    if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-418653471 ^ (long)-418653523);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1656419201 ^ (long)1656419198)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1695861852 ^ (long)1695822755)) >>> (int)((long)-2021329921 ^ (long)-2021329929)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-364376840 ^ (long)-364376840);
            if (!3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)50042804 ^ (long)50042806);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-2137159146 ^ (long)-2137159147) | var5_6 << (int)((long)1406029558 ^ (long)1406029555)) ^ var3_4[var7_8]) & (int)((long)388134509 ^ (long)388134546);
                    if (3sb.\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1738477457 ^ (long)-1738477460) | var6_7 << (int)((long)-1914602219 ^ (long)-1914602224)) ^ var3_4[var7_8]) & (int)((long)-1046595131 ^ (long)-1046595270);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3sb.b[var2_3] = new String(var3_4).intern();
        }
        return 3sb.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String 8(String string) {
        boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
        if (bl || bl) return null;
        if ((string = string.split(2w$6X.KAOZ("\u83d8", 1661415651))[(int)((long)1223777449 ^ (long)1223777449)]).indexOf((int)((long)967312429 ^ (long)967312387)) == string.lastIndexOf((int)((long)-819058656 ^ (long)-819058674))) {
            if (bl || bl) return null;
            return string;
        }
        if (!bl) return string.substring((int)((long)43422065 ^ (long)43422065), string.lastIndexOf((int)((long)-192061049 ^ (long)-192061015)));
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static 341 9(boolean bl) {
        341 var3_6;
        boolean bl2;
        block17: {
            int n;
            bl2 = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
            if (bl2 || bl2) return null;
            5z.9.log(Level.INFO, 3sb.a((int)((long)736881750 ^ (long)736860027), (int)((long)2125806562 ^ (long)2125805963)) /* "Checking for Updates" */);
            if (bl2) return null;
            String string = 4P.5.toString();
            String string2 = 3sb.a((int)((long)202474844 ^ (long)202505830), (int)((long)847117986 ^ (long)-847092005)) /* "4.9.1" */;
            if (bl2 || bl2) return null;
            System.out.println(3sb.a((int)((long)-254600341 ^ (long)-254582694), (int)((long)526180146 ^ (long)-526170802)) /* "Offering updates to betas: " */.concat(String.valueOf(bl)));
            if (bl2 || bl2) return null;
            if (bl) {
                if (bl2 || bl2) return null;
                Installer.args.prereleases = (int)((long)171593891 ^ (long)171593890);
                if (bl2) return null;
            }
            if (bl2) return null;
            Installer.args.noGPG = (int)((long)483315414 ^ (long)483315414);
            if (bl2 || bl2) return null;
            Installer.args.noGUI = (int)((long)1718443189 ^ (long)1718443188);
            if (bl2 || bl2) return null;
            Optional<ImpactVersionReleased> optional = ImpactVersions.getAllVersions().stream().filter(impactVersionReleased -> {
                boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
                if (bl || bl) {
                    return true;
                }
                return impactVersionReleased.mcVersion.equals(string);
            }).filter(impactVersionReleased -> {
                boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
                if (bl || bl) return true;
                if (impactVersionReleased.impactVersion.compareTo(string2) > 0) {
                    if (bl) return true;
                    return (int)((long)-1719045295 ^ (long)-1719045296) != 0;
                }
                if (!bl) return (int)((long)1575751960 ^ (long)1575751960) != 0;
                return true;
            }).max(Comparator.comparing(impactVersionReleased -> {
                boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
                if (bl || bl) {
                    return null;
                }
                return impactVersionReleased.impactVersion;
            }));
            if (!optional.isPresent()) {
                if (bl2 || bl2) return null;
                optional = ImpactVersions.getAllVersions().stream().max(Comparator.comparing(impactVersionReleased -> {
                    boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
                    if (bl || bl) {
                        return null;
                    }
                    return 3sb.8(impactVersionReleased.impactVersion) + 3sb.a((int)((long)-1386274922 ^ (long)-1386257238), (int)((long)-1600465899 ^ (long)-1600457605)) + impactVersionReleased.mcVersion + 3sb.a((int)((long)-1984763670 ^ (long)-1984785441), (int)((long)2037896110 ^ (long)-2037890880)) /* " _ " */ + impactVersionReleased.impactVersion;
                })).filter(impactVersionReleased -> {
                    boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
                    if (bl || bl) return true;
                    if (3sb.8(impactVersionReleased.impactVersion).compareTo(3sb.8(string2)) > 0) {
                        if (bl) return true;
                        return (int)((long)-605172538 ^ (long)-605172537) != 0;
                    }
                    if (!bl) return (int)((long)-989853755 ^ (long)-989853755) != 0;
                    return true;
                });
                if (bl2) return null;
            }
            if (bl2) return null;
            var3_6 = new 341();
            if (bl2 || bl2) return null;
            if (!optional.isPresent()) {
                if (bl2 || bl2) return null;
                return var3_6;
            }
            if (bl2) return null;
            var3_6.5 = (int)((long)1550736420 ^ (long)1550736421);
            if (bl2 || bl2) return null;
            var3_6.9 = optional.get();
            if (bl2 || bl2) return null;
            var3_6.9.fetchContents();
            if (bl2 || bl2) return null;
            if (3sb.8(string2).equals(3sb.8(var3_6.9.impactVersion)) && string.equals(var3_6.9.mcVersion)) {
                n = (int)((long)-2087924797 ^ (long)-2087924798);
                if (\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) {
                    throw null;
                }
            } else {
                var3_6.8 = (int)((long)-1888817822 ^ (long)-1888817822);
                n = var3_6.8 ? 1 : 0;
            }
            if (var3_6.8) {
                try {
                    var3_6.6 = 3sb.7(var3_6.9);
                    var3_6.2 = (int)((long)1192295284 ^ (long)1192295285);
                    if (!\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) break block17;
                    throw null;
                }
                catch (Throwable throwable) {
                    if (bl2 || bl2) return null;
                    System.out.println(3sb.a((int)((long)-1073854470 ^ (long)-1073857314), (int)((long)-295651030 ^ (long)295641089)) /* "Patch was not able to be auto installed because" */);
                    if (bl2 || bl2) return null;
                    throwable.printStackTrace();
                    if (bl2) return null;
                }
            }
        }
        if (bl2) return null;
        var3_6.7 = ImpactVersions.getAllVersions().stream().filter(impactVersionReleased -> {
            boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
            if (bl || bl) {
                return true;
            }
            return 3sb.8(impactVersionReleased.impactVersion).equals(3sb.8(var0.9.impactVersion));
        }).map(impactVersionReleased -> {
            boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
            if (bl || bl) {
                return null;
            }
            return impactVersionReleased.mcVersion;
        }).distinct().sorted().collect(Collectors.toList());
        if (bl2 || bl2) return null;
        if (var3_6.2) {
            if (bl2) return null;
            if (!var3_6.8) {
                if (bl2 || bl2) return null;
                throw new IllegalStateException();
            }
        }
        if (!bl2) return var3_6;
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static <T> void 0(InstallationConfig installationConfig, Setting<T> setting, T t) {
        boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
        if (bl || bl) return;
        if (!installationConfig.setSettingValue(setting, t)) {
            if (bl || bl) return;
            throw new IllegalArgumentException(installationConfig + 2w$6X.KAOZ("\uc62d", -1313442533) + setting + 2w$6X.KAOZ("\u81bd", 684470923) + t);
        }
        if (!bl) return;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void 7() {
        boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
        if (bl) return;
        try {
            if (bl) return;
            new Vanilla(this.2.6).install((boolean)((long)-1325993775 ^ (long)-1325993776));
            if (bl || bl) return;
            return;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            if (bl || bl) return;
            System.out.println(3sb.a((int)((long)138592123 ^ (long)138593369), (int)((long)-1127474848 ^ (long)-1127455531)) /* "Uh oh" */);
            if (bl || bl) return;
            return;
        }
    }

    private static String 4() {
        String string;
        boolean bl = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
        if (bl || bl) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder().append(System.getProperties().getProperty(3sb.a((int)((long)187286162 ^ (long)187283900), (int)((long)639677511 ^ (long)639680801)) /* "java.home" */)).append(File.separator).append(3sb.a((int)((long)725926605 ^ (long)725924321), (int)((long)397586864 ^ (long)-397593288)) /* "bin" */).append(File.separator).append(3sb.a((int)((long)-981618216 ^ (long)-981611794), (int)((long)1931979022 ^ (long)-1931979551)) /* "java" */);
        if (1Q.8() == 1Q.a) {
            string = 3sb.a((int)((long)-2034696337 ^ (long)-2034727850), (int)((long)1457619501 ^ (long)-1457631329)) /* ".exe" */;
            if (\u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000) {
                throw null;
            }
        } else {
            string = 2w$6X.KAOZ("", 633112891);
        }
        return stringBuilder.append(string).toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    public 3sb(boolean bl) {
        block3: {
            block2: {
                boolean bl2 = \u200a\u2004\u200c\u200e\u2007\u2008\u2006\u2000;
                if (bl2 || bl2) break block2;
                this.2 = 3sb.9(bl);
                if (!bl2 && !bl2) break block3;
            }
            return;
        }
    }
}

