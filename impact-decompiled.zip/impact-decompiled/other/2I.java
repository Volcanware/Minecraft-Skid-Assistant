/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  org.apache.logging.log4j.Level
 */
package net.impactclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.Map;
import net.impactclient.21;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.3K;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3si;
import net.impactclient.3ss;
import net.impactclient.5z;
import net.impactclient.90;
import org.apache.logging.log4j.Level;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 2I
implements 3ss {
    private static final String[] a;
    public static final boolean \u200a\u200b\u2007\u2004;
    private static final String[] b;

    /*
     * Enabled aggressive block sorting
     */
    public 2I() {
        boolean bl = \u200a\u200b\u2007\u2004;
        if (bl) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static /* synthetic */ void 2(3X x2, Map.Entry entry) {
        boolean bl = \u200a\u200b\u2007\u2004;
        if (bl) return;
        String string = (String)entry.getKey();
        String[] stringArray = 3e.5();
        if (bl || bl) return;
        entry = (JsonElement)entry.getValue();
        if (bl) return;
        try {
            if (bl) return;
            if (string.equals(2I.a((int)((long)-581288704 ^ (long)-581291081), (int)((long)476066225 ^ (long)476059553)) /* "values" */)) {
                if (bl) return;
                if (entry.isJsonArray()) {
                    if (bl || bl) return;
                    3K.4(x2, entry.getAsJsonArray());
                    if (bl) return;
                }
            }
            if (bl) return;
            if (string.equals(2I.a((int)((long)1196230124 ^ (long)1196231519), (int)((long)-1090820323 ^ (long)-1090844884)) /* "modes" */)) {
                if (bl) return;
                if (entry.isJsonArray()) {
                    if (bl) return;
                    if (x2.4()) {
                        if (bl || bl) return;
                        entry.getAsJsonArray().forEach(jsonElement -> {
                            block4: {
                                block2: {
                                    boolean bl;
                                    block3: {
                                        bl = \u200a\u200b\u2007\u2004;
                                        if (bl || bl) break block2;
                                        if (!jsonElement.isJsonObject()) break block3;
                                        if (bl || bl) break block2;
                                        21.1(x2, jsonElement.getAsJsonObject());
                                        if (bl) break block2;
                                    }
                                    if (!bl) break block4;
                                }
                                return;
                            }
                        });
                        if (bl) return;
                    }
                }
            }
            if (bl) return;
            String string2 = string;
            if (bl) return;
            int n = (int)((long)-1527489767 ^ (long)1527489766);
            if (bl) return;
            switch (string2.hashCode()) {
                case 109757585: {
                    if (bl) return;
                    if (!string2.equals(2I.a((int)((long)1391843249 ^ (long)1391843588), (int)((long)1210435711 ^ (long)-1210429475)) /* "state" */)) break;
                    if (bl) return;
                    n = (int)((long)833272564 ^ (long)833272564);
                    if (bl) return;
                    if (stringArray == null) break;
                    if (bl) return;
                }
                case 3023933: {
                    if (bl) return;
                    if (!string2.equals(2I.a((int)((long)110450534 ^ (long)110451161), (int)((long)-354650243 ^ (long)-354675158)) /* "bind" */)) break;
                    if (bl) return;
                    n = (int)((long)-482319319 ^ (long)-482319320);
                    if (bl) return;
                    if (stringArray == null) break;
                    if (bl) return;
                }
                case 1671764162: {
                    if (bl) return;
                    if (!string2.equals(2I.a((int)((long)1527296186 ^ (long)1527299588), (int)((long)-338201319 ^ (long)338198601)))) break;
                    if (bl) return;
                    n = (int)((long)1057128431 ^ (long)1057128429);
                    if (bl) return;
                    if (stringArray == null) break;
                    if (bl) return;
                }
                case 0x3339A3: {
                    if (bl) return;
                    if (!string2.equals(2I.a((int)((long)-1900462980 ^ (long)-1900465458), (int)((long)479506322 ^ (long)-479494883)) /* "mode" */)) break;
                    if (bl) return;
                    n = (int)((long)1649994517 ^ (long)1649994518);
                    if (bl) return;
                    break;
                }
            }
            if (bl) return;
            switch (n) {
                case 0: {
                    if (bl) return;
                    x2.1(entry.getAsBoolean());
                    if (bl || bl) return;
                    return;
                }
            }
        }
        catch (Exception exception) {
            if (bl || bl) return;
            5z.9.log(Level.WARN, 2I.a((int)((long)-1140254222 ^ (long)-1140254910), (int)((long)-1641064582 ^ (long)1641072334)) /* "Unable to load setting for {}.{}" */, (Object)x2.2(), (Object)string);
            if (!bl && !bl) return;
            return;
        }
        {
            case 1: {
                if (bl) return;
                x2.9().3 = 3si.9(entry.getAsString());
                if (bl || bl) return;
                return;
            }
            case 2: {
                if (bl) return;
                2R.1(x2, 2I.a((int)((long)365211260 ^ (long)365207752), (int)((long)862916329 ^ (long)-862919816)) /* "display" */, entry.getAsBoolean());
                if (bl || bl) return;
                return;
            }
            case 3: {
                if (bl) return;
                if (!x2.4()) break;
                if (bl || bl) return;
                x2.7(entry.getAsString());
                if (bl) return;
                break;
            }
        }
        if (bl) return;
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 2I.\u200a\u200b\u2007\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)426640740 ^ (long)426642387)) & (int)((long)-122278963 ^ (long)-122235854);
            if (var9_2) ** GOTO lbl-1000
            if (2I.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 2I.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1434297635 ^ (long)1434297635)] & (int)((long)2139738310 ^ (long)2139738169)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-133093414 ^ (long)-133093487);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-63440060 ^ (long)-63439938);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1336327391 ^ (long)-1336327182);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1661974579 ^ (long)1661974676);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-613390407 ^ (long)-613390524);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1678742155 ^ (long)1678742124);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-327914366 ^ (long)-327914453);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1657551688 ^ (long)1657551727);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1373399049 ^ (long)-1373399076);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-719119100 ^ (long)-719118981);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-2073047190 ^ (long)-2073047123);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1723928801 ^ (long)-1723928779);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1661769476 ^ (long)-1661769542);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-667845103 ^ (long)-667845045);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1431729171 ^ (long)1431729343);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)617674286 ^ (long)617674386);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)917491664 ^ (long)917491655);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-144088771 ^ (long)-144088618);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1654695824 ^ (long)1654695704);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1974462486 ^ (long)-1974462499);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1756095647 ^ (long)-1756095489);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)513341180 ^ (long)513340941);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)796168932 ^ (long)796168924);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1769758281 ^ (long)1769758301);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)885732324 ^ (long)885732231);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1137719515 ^ (long)-1137719401);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-728397298 ^ (long)-728397304);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)177275993 ^ (long)177275936);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1713653275 ^ (long)1713653379);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)365031148 ^ (long)365031034);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1695915631 ^ (long)1695915560);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)2093618873 ^ (long)2093618812);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)765481855 ^ (long)765481976);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-2039770919 ^ (long)-2039771040);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1715123484 ^ (long)-1715123460);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-2120944289 ^ (long)-2120944242);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-2069846022 ^ (long)-2069846074);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1856374260 ^ (long)1856374022);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-540320087 ^ (long)-540320063);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)44393574 ^ (long)44393552);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1151434186 ^ (long)1151434136);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-2080374845 ^ (long)-2080374905);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1838331653 ^ (long)-1838331853);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)670270701 ^ (long)670270562);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1588829380 ^ (long)-1588829288);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-475918305 ^ (long)-475918227);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-448866429 ^ (long)-448866375);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1187067963 ^ (long)-1187068044);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)569152207 ^ (long)569152239);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1507389015 ^ (long)-1507388955);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)343923813 ^ (long)343923848);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1945993528 ^ (long)1945993629);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-2009278574 ^ (long)-2009278475);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1022933082 ^ (long)1022933177);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1553280353 ^ (long)-1553280502);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1453634120 ^ (long)-1453634058);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1547698537 ^ (long)1547698473);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-94789011 ^ (long)-94788885);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1354425767 ^ (long)1354425651);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1047390443 ^ (long)1047390396);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1679418249 ^ (long)-1679418210);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1329133692 ^ (long)1329133650);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1819417440 ^ (long)1819417544);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-914080451 ^ (long)-914080412);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1320525700 ^ (long)1320525688);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1516375043 ^ (long)-1516375088);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)517608206 ^ (long)517608403);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1502649055 ^ (long)1502648861);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1791413429 ^ (long)-1791413260);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-89676218 ^ (long)-89676047);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-762209568 ^ (long)-762209582);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-280699118 ^ (long)-280698994);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-193372370 ^ (long)-193372348);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-74470322 ^ (long)-74470350);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1172016164 ^ (long)1172016263);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1121605126 ^ (long)1121605319);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)412305369 ^ (long)412305168);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-933529253 ^ (long)-933529114);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1529509509 ^ (long)1529509510);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)58904060 ^ (long)58904042);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1212890124 ^ (long)-1212890125);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)634133635 ^ (long)634133679);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-938113856 ^ (long)-938113970);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1447375092 ^ (long)1447374922);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1178894922 ^ (long)-1178894974);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)586453751 ^ (long)586453713);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)413154380 ^ (long)413154451);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1863445486 ^ (long)1863445374);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1518042249 ^ (long)1518042142);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1357552022 ^ (long)-1357552124);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-755040667 ^ (long)-755040672);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)2129186463 ^ (long)2129186383);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1213739700 ^ (long)-1213739696);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1644336572 ^ (long)-1644336626);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-2025203284 ^ (long)-2025203274);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1288789322 ^ (long)-1288789319);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1740114249 ^ (long)-1740114265);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-915759393 ^ (long)-915759434);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)666624783 ^ (long)666624984);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1547918895 ^ (long)-1547918985);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)366814605 ^ (long)366814548);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1783762868 ^ (long)-1783762733);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1505860974 ^ (long)-1505860970);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1018119389 ^ (long)-1018119262);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-55863788 ^ (long)-55863722);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-710939729 ^ (long)-710939673);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1573430276 ^ (long)-1573430512);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1697078436 ^ (long)1697078311);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-322102960 ^ (long)-322102839);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-831861533 ^ (long)-831861613);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)610560333 ^ (long)610560452);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1742324207 ^ (long)-1742323992);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1841895193 ^ (long)1841895365);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1393815956 ^ (long)-1393815945);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1994113109 ^ (long)-1994113144);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-168712008 ^ (long)-168712048);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-843211400 ^ (long)-843211430);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1665533659 ^ (long)1665533553);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1696379498 ^ (long)1696379583);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1361596472 ^ (long)1361596662);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)900814032 ^ (long)900813898);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)340060427 ^ (long)340060653);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-152718076 ^ (long)-152717884);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1874066721 ^ (long)-1874066828);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)960874515 ^ (long)960874576);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1459534937 ^ (long)1459534872);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)402086108 ^ (long)402085949);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-832683719 ^ (long)-832683685);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-880074868 ^ (long)-880074759);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)12159165 ^ (long)12159050);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)20344909 ^ (long)20344944);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-306055888 ^ (long)-306055763);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1135554213 ^ (long)1135554139);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)338327614 ^ (long)338327665);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1809181034 ^ (long)1809181112);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-629474349 ^ (long)-629474424);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1015060002 ^ (long)-1015060013);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-463248844 ^ (long)-463248693);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)194744338 ^ (long)194744388);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)690656401 ^ (long)690656500);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1086386921 ^ (long)-1086386882);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1680919378 ^ (long)1680919390);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)908979137 ^ (long)908979188);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1460318272 ^ (long)-1460318320);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1527418769 ^ (long)-1527418715);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)249905248 ^ (long)249905336);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1001957398 ^ (long)-1001957400);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-217235591 ^ (long)-217235507);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-30096639 ^ (long)-30096421);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1918973961 ^ (long)1918974052);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1041145381 ^ (long)1041145543);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-416958699 ^ (long)-416958710);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)357388550 ^ (long)357388598);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-868930463 ^ (long)-868930390);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)60743296 ^ (long)60743278);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1321807844 ^ (long)1321807659);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)622168792 ^ (long)622168759);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1446504037 ^ (long)1446504000);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1947443354 ^ (long)-1947443409);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1806111461 ^ (long)1806111300);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1669899724 ^ (long)1669899585);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1833051569 ^ (long)1833051628);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1908451764 ^ (long)-1908451619);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-49845597 ^ (long)-49845693);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1706250098 ^ (long)1706250164);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)630260398 ^ (long)630260224);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1013121102 ^ (long)1013121070);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1820365050 ^ (long)-1820364848);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)819643673 ^ (long)819643754);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1604700207 ^ (long)1604700209);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)2076216730 ^ (long)2076216740);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1686743423 ^ (long)-1686743378);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1307871578 ^ (long)-1307871715);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1573719611 ^ (long)1573719752);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-97174911 ^ (long)-97174844);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-538055409 ^ (long)-538055215);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-269233312 ^ (long)-269233235);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-486742636 ^ (long)-486742551);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)473250176 ^ (long)473250093);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1970427347 ^ (long)1970427195);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-373381537 ^ (long)-373381573);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-646397565 ^ (long)-646397538);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-2076400957 ^ (long)-2076400967);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)352265562 ^ (long)352265556);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)2076317342 ^ (long)2076317246);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-194296210 ^ (long)-194296261);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)821258351 ^ (long)821258351);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1552062542 ^ (long)-1552062647);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-881656018 ^ (long)-881655842);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1991539169 ^ (long)-1991539079);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)693419340 ^ (long)693419486);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)220261349 ^ (long)220261200);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-240139386 ^ (long)-240139454);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)2003779696 ^ (long)2003779601);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1940374799 ^ (long)-1940374878);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1063535089 ^ (long)1063534973);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1763559201 ^ (long)1763559332);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1522963900 ^ (long)1522963798);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-544149625 ^ (long)-544149505);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-729355555 ^ (long)-729355636);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)574971737 ^ (long)574971746);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1560342835 ^ (long)1560342961);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)812060047 ^ (long)812060046);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)940543186 ^ (long)940543065);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-29259869 ^ (long)-29259912);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1783682509 ^ (long)-1783682449);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-717904357 ^ (long)-717904376);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-272989083 ^ (long)-272989167);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-273707616 ^ (long)-273707608);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1200501455 ^ (long)-1200501334);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)408207930 ^ (long)408208085);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1537389243 ^ (long)-1537389059);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)698736031 ^ (long)698736006);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)942353455 ^ (long)942353497);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1876519786 ^ (long)1876519846);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)792730 ^ (long)792629);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1167265626 ^ (long)1167265758);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-857877487 ^ (long)-857877470);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1027195607 ^ (long)1027195523);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1594033666 ^ (long)-1594033721);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-68574103 ^ (long)-68574131);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1638612148 ^ (long)1638612191);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1254365190 ^ (long)-1254365328);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)2067603683 ^ (long)2067603643);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1686418687 ^ (long)-1686418576);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1657498628 ^ (long)-1657498870);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-59001274 ^ (long)-59001211);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-2107702488 ^ (long)-2107702495);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1516546022 ^ (long)1516545872);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-517309314 ^ (long)-517309324);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1150554920 ^ (long)-1150555076);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)955955964 ^ (long)955955720);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1472299875 ^ (long)1472299931);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1493577759 ^ (long)1493577931);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)789560082 ^ (long)789560165);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1774116062 ^ (long)1774116005);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-554494621 ^ (long)-554494691);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-450816579 ^ (long)-450816593);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-905429021 ^ (long)-905429038);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1828085569 ^ (long)-1828085731);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-359373155 ^ (long)-359373283);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-307751404 ^ (long)-307751371);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-804365877 ^ (long)-804365858);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)930620755 ^ (long)930620685);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-948346984 ^ (long)-948346923);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1761555034 ^ (long)1761555177);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)290422684 ^ (long)290422572);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1863106879 ^ (long)1863107034);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1755917842 ^ (long)1755917901);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-24158275 ^ (long)-24158392);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-186236255 ^ (long)-186236366);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)2123278889 ^ (long)2123278995);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)933326093 ^ (long)933326108);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1492661011 ^ (long)-1492661018);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)833676022 ^ (long)833675930);
                    if (!2I.\u200a\u200b\u2007\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)794790409 ^ (long)794790454);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-755444381 ^ (long)-755444324)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-278436842 ^ (long)-278422551)) >>> (int)((long)1806178499 ^ (long)1806178507)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)2125233615 ^ (long)2125233615);
            if (!2I.\u200a\u200b\u2007\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)2106201921 ^ (long)2106201923);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)690644804 ^ (long)690644807) | var5_6 << (int)((long)1711851776 ^ (long)1711851781)) ^ var3_4[var7_8]) & (int)((long)1884489442 ^ (long)1884489245);
                    if (2I.\u200a\u200b\u2007\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)509642172 ^ (long)509642175) | var6_7 << (int)((long)891093144 ^ (long)891093149)) ^ var3_4[var7_8]) & (int)((long)1023772213 ^ (long)1023772362);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            2I.b[var2_3] = new String(var3_4).intern();
        }
        return 2I.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 1(90 var1_1, JsonArray jsonArray) {
        block3: {
            block2: {
                boolean bl = \u200a\u200b\u2007\u2004;
                if (bl || bl) break block2;
                jsonArray.forEach(jsonElement -> {
                    boolean bl;
                    block11: {
                        block10: {
                            bl = \u200a\u200b\u2007\u2004;
                            if (bl || bl) return;
                            if (!jsonElement.isJsonObject()) {
                                if (bl || bl) return;
                                return;
                            }
                            if (bl) return;
                            if (!(jsonElement = jsonElement.getAsJsonObject()).has(2I.a((int)((long)-1581175026 ^ (long)-1581178440), (int)((long)-235016440 ^ (long)235026744)))) break block10;
                            if (bl) return;
                            if (!jsonElement.get(2I.a((int)((long)999034204 ^ (long)999031789), (int)((long)-208502879 ^ (long)208516567)) /* "name" */).isJsonPrimitive()) break block10;
                            if (bl) return;
                            var1_1 = ((90)object).1.6(jsonElement.get(2I.a((int)((long)-1352889688 ^ (long)-1352891367), (int)((long)-1802688159 ^ (long)1802691351)) /* "name" */).getAsString());
                            if (var1_1 != null) break block11;
                            if (bl) return;
                        }
                        if (bl) return;
                        return;
                    }
                    if (bl) return;
                    jsonElement.entrySet().forEach(arg_0 -> 2I.2((3X)((Object)var1_1), arg_0));
                    if (!bl && !bl) return;
                });
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 2I.\u200a\u200b\u2007\u2004;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1754549570 ^ (long)1754549576)];
            if (var7) break block23;
            var3_2 = (int)((long)1634964777 ^ (long)1634964777);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u4c6f\u6479\u77d3\u7f94\u4cbd\u64d3\u7723\u7fc7\u4c75\u6488\u7734\u7f56\u4c45\u645c\u773e\u7f86\u4cac\u643c\u7751\u7fdd\u4cab\u6469\u77b7\u7fbe\u4c23\u643e\u77b3\u7fa7\u4cc8\u64f5\u7731\u7f57\u4cea\u6416\u7713\u7fa6\u4c15\u64dc\u7722\u7f8e\u4c2e\u641b\u77d4\u7fa5\u4c1e\u6493\u7751\u7fb5\u4ca6\u64eb\u771b\u7f7c\u4ccf\u6423\u77c4\u7f0e\u4cb1\u648a\u779d\u7fbb\u4c4d\u640d\u7780\u7f07\u4ce7\u64b3\u7705\u7f2c\u4c4f\u642b\u7704\u7fea\u4c33\u642d", -1106810222);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-92097030 ^ (long)-92097028);
            if (var7) break block23;
            var0_6 = (int)((long)561318102 ^ (long)-561318103);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-133933230 ^ (long)-133933306);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1614874600 ^ (long)-1614874601);
                    if (2I.\u200a\u200b\u2007\u2004) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!2I.\u200a\u200b\u2007\u2004) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u05b9\u2d87\u3e04\u36ca\u0537\u2dc2\u3e2d\u3681\u054a\u2d3f\u3e72\u366a", -785964109);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)1805209837 ^ (long)1805209833);
                            var0_6 = (int)((long)-63770751 ^ (long)63770750);
                            while (true) {
                                v0 = (int)((long)1256163890 ^ (long)1256163888);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-807449181 ^ (long)-807449181);
                                if (!2I.\u200a\u200b\u2007\u2004) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!2I.\u200a\u200b\u2007\u2004) ** continue;
                                throw null;
                            }
                            2I.a = var5_1;
                            2I.b = new String[(int)((long)276871411 ^ (long)276871417)];
                            if (!2I.\u200a\u200b\u2007\u2004) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1470082374 ^ (long)1470082374);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-482413908 ^ (long)-482413907)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)20111663 ^ (long)20111656)) {
                                case 0: {
                                    v15 = (int)((long)1625223874 ^ (long)1625223881);
                                    if (!2I.\u200a\u200b\u2007\u2004) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)720196615 ^ (long)720196637);
                                    if (!2I.\u200a\u200b\u2007\u2004) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1093167387 ^ (long)-1093167435);
                                    if (!2I.\u200a\u200b\u2007\u2004) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-127633386 ^ (long)-127633348);
                                    if (!2I.\u200a\u200b\u2007\u2004) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)320102356 ^ (long)320102326);
                                    if (!2I.\u200a\u200b\u2007\u2004) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)749782120 ^ (long)749782091);
                                    if (!2I.\u200a\u200b\u2007\u2004) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)347021306 ^ (long)347021264);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!2I.\u200a\u200b\u2007\u2004);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

