/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  aqa
 *  bfw
 *  dci
 *  ddh
 *  deo
 *  djz
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  oj
 *  st$a
 */
package net.impactclient;

import clientapi.load.mixin.7.9;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.0R;
import net.impactclient.1A;
import net.impactclient.2w$6X;
import net.impactclient.34e;
import net.impactclient.3e;
import net.impactclient.3sh;
import net.impactclient.4m;
import net.impactclient.7m;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 1u
extends 7m<0R> {
    private static final String[] b;
    public static final boolean \u2009\u200e\u200d\u2003\u200b\u2003\u2007;
    private static final String[] a;
    private int 0;
    private 1A 7;
    @EventHandler
    private final Listener<3sh> 6;
    private int 4;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2009\u200e\u200d\u2003\u200b\u2003\u2007;
                    if (bl || bl) break block2;
                    if (1u.3.s == null) break block3;
                    if (bl || bl) break block2;
                    ((9)9.getTimer()).setSpeed(1.0f);
                    if (bl || bl) break block2;
                    1u.3.s.c((boolean)((long)1280633310 ^ (long)1280633310));
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static double 2(bfw bfw2) {
        double d;
        double d2;
        double d3;
        block6: {
            boolean bl = \u2009\u200e\u200d\u2003\u200b\u2003\u2007;
            if (bl) return 0.0;
            String[] stringArray = 3e.5();
            if (bl || bl) return 0.0;
            List list = bfw2.l.b((aqa)1u.3.s, bfw2.cc().b(0.0, -69.0, 0.0)).filter(ddh::b).map(ddh::a).collect(Collectors.toList());
            if (list.isEmpty()) {
                if (bl || bl) return 0.0;
                return 0.0;
            }
            if (bl) return 0.0;
            d3 = 0.0;
            if (bl) return 0.0;
            if (bl) return 0.0;
            list = list.iterator();
            if (bl) return 0.0;
            while (!bl) {
                if (list.hasNext()) {
                    if (bl) return 0.0;
                    dci dci2 = (dci)list.next();
                    d2 = dci2.e;
                    d = d3;
                    if (stringArray != null) return d2 - d;
                    if (d2 > d) {
                        if (bl || bl) return 0.0;
                        d3 = dci2.e;
                        if (bl) return 0.0;
                    }
                    if (bl) return 0.0;
                    if (stringArray == null) continue;
                    if (bl) return 0.0;
                }
                if (!bl) break block6;
            }
            return 0.0;
        }
        d2 = bfw2.cE();
        d = d3;
        return d2 - d;
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)799318970 ^ (long)-799328851)) & (int)((long)1890071490 ^ (long)1890110525);
            if (var9_2) ** GOTO lbl-1000
            if (1u.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 1u.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)2075980165 ^ (long)2075980165)] & (int)((long)-945898876 ^ (long)-945898885)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1828258402 ^ (long)-1828258353);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)224210271 ^ (long)224210364);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)942751724 ^ (long)942751538);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1656892285 ^ (long)-1656892174);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)2090480834 ^ (long)2090480807);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)47784485 ^ (long)47784543);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1449841956 ^ (long)1449842159);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1506737598 ^ (long)-1506737426);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1555733447 ^ (long)-1555733503);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-858761977 ^ (long)-858761790);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)651477761 ^ (long)651477911);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-350547443 ^ (long)-350547242);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1388976230 ^ (long)-1388976291);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-2089195512 ^ (long)-2089195275);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-839174809 ^ (long)-839174773);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-899832402 ^ (long)-899832555);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)981337766 ^ (long)981337650);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)2041853836 ^ (long)2041853810);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)20191185 ^ (long)20191123);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1117470267 ^ (long)1117470240);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1680303206 ^ (long)1680303219);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1067476250 ^ (long)-1067476262);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1448531260 ^ (long)-1448531414);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1416914882 ^ (long)1416914801);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)735355223 ^ (long)735355277);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)73044811 ^ (long)73044882);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1419962602 ^ (long)1419962549);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1374557486 ^ (long)-1374557632);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)883856226 ^ (long)883856254);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1268800386 ^ (long)1268800390);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-436856647 ^ (long)-436856728);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-279145613 ^ (long)-279145568);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1888956751 ^ (long)-1888956872);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1476842702 ^ (long)1476842712);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1729011413 ^ (long)-1729011202);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1146378757 ^ (long)1146378852);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1294373877 ^ (long)1294373807);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1296421200 ^ (long)-1296421160);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-496641006 ^ (long)-496640845);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-986348237 ^ (long)-986348117);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1054972178 ^ (long)-1054972232);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1266890616 ^ (long)-1266890598);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)179356173 ^ (long)179356227);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)845750465 ^ (long)845750499);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)793229068 ^ (long)793229166);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-367502357 ^ (long)-367502378);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-942323492 ^ (long)-942323617);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-74995603 ^ (long)-74995615);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1405616509 ^ (long)1405616441);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1199969391 ^ (long)1199969321);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1319516704 ^ (long)1319516673);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1680227678 ^ (long)1680227724);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)561499392 ^ (long)561499554);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-437505685 ^ (long)-437505758);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)822500670 ^ (long)822500819);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)551491666 ^ (long)551491593);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)2074365269 ^ (long)2074365192);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1091964327 ^ (long)1091964210);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-589571996 ^ (long)-589571862);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)223737875 ^ (long)223738051);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-2144675716 ^ (long)-2144675748);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1563284027 ^ (long)-1563284126);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1636549713 ^ (long)1636549844);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1747696836 ^ (long)1747696879);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-674860319 ^ (long)-674860419);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)116661089 ^ (long)116661041);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1866155266 ^ (long)1866155430);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)224538324 ^ (long)224538213);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)751226251 ^ (long)751226284);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1816875052 ^ (long)-1816875047);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1483329118 ^ (long)1483329127);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1136234203 ^ (long)1136234034);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-697861641 ^ (long)-697861857);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1734149849 ^ (long)1734149802);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)679854273 ^ (long)679854205);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1944997988 ^ (long)-1944998052);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1795056594 ^ (long)-1795056597);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-935269862 ^ (long)-935269826);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1232829939 ^ (long)1232829759);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1768280815 ^ (long)1768280672);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1765895078 ^ (long)-1765894982);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-872837356 ^ (long)-872837148);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1155933845 ^ (long)-1155933934);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)550359756 ^ (long)550359732);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)60395912 ^ (long)60395856);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-419151449 ^ (long)-419151544);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-250261089 ^ (long)-250261089);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)470298612 ^ (long)470298563);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-899095419 ^ (long)-899095356);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1408501437 ^ (long)1408501318);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1924830752 ^ (long)-1924830778);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1898410668 ^ (long)1898410676);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)864325392 ^ (long)864325452);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)821568899 ^ (long)821568971);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-2046459660 ^ (long)-2046459897);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1109888315 ^ (long)1109888299);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1611392425 ^ (long)1611392272);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-572892344 ^ (long)-572892246);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1806355931 ^ (long)-1806355834);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1884310173 ^ (long)-1884310268);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1506330162 ^ (long)-1506330296);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1321202283 ^ (long)-1321202316);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)240732694 ^ (long)240732784);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)691695625 ^ (long)691695717);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)524865431 ^ (long)524865378);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1388917354 ^ (long)1388917412);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-830895212 ^ (long)-830895252);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-236434828 ^ (long)-236434756);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-608645099 ^ (long)-608644971);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1110738987 ^ (long)1110739176);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1137913115 ^ (long)1137913300);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1281441441 ^ (long)-1281441400);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1554955722 ^ (long)1554955649);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1582936745 ^ (long)-1582936818);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1616781253 ^ (long)1616781262);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-154159021 ^ (long)-154158853);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1697800144 ^ (long)1697800020);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1332644489 ^ (long)-1332644411);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1772564363 ^ (long)1772564319);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1087946596 ^ (long)-1087946586);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-899987254 ^ (long)-899987405);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)426435512 ^ (long)426435357);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1738083187 ^ (long)-1738083321);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1820139762 ^ (long)-1820139524);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-431459231 ^ (long)-431459241);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1813920668 ^ (long)-1813920656);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)376520186 ^ (long)376520109);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-2003421264 ^ (long)-2003421381);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-609948654 ^ (long)-609948502);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1687965370 ^ (long)-1687965287);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)365034470 ^ (long)365034321);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-284286809 ^ (long)-284286771);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)49219194 ^ (long)49219085);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-207749749 ^ (long)-207749845);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-794891466 ^ (long)-794891380);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)337436593 ^ (long)337436559);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1229978278 ^ (long)1229978171);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1965485779 ^ (long)1965485659);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1969682864 ^ (long)-1969682827);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-137744821 ^ (long)-137744827);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1891588120 ^ (long)1891588119);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-760684901 ^ (long)-760684904);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)381126467 ^ (long)381126416);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)486178138 ^ (long)486178087);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1239833739 ^ (long)-1239833786);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1155905207 ^ (long)1155905190);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)850112297 ^ (long)850112484);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1661927989 ^ (long)1661928098);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-99308697 ^ (long)-99308591);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1850300887 ^ (long)-1850300862);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1389480035 ^ (long)1389480037);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1115638462 ^ (long)1115638414);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)614641427 ^ (long)614641655);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-314835572 ^ (long)-314835458);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)618735655 ^ (long)618735707);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)246646811 ^ (long)246646962);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)914019741 ^ (long)914019794);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1127232711 ^ (long)1127232605);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1153169862 ^ (long)-1153169750);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-272058206 ^ (long)-272058300);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1579507599 ^ (long)-1579507645);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1873953847 ^ (long)-1873953814);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1697029062 ^ (long)1697029039);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)728854455 ^ (long)728854476);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1254983028 ^ (long)1254982981);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1107108117 ^ (long)-1107108275);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-2007685951 ^ (long)-2007685963);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)518822069 ^ (long)518821914);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-932055552 ^ (long)-932055407);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1757485191 ^ (long)1757485284);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-641363205 ^ (long)-641363268);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-114006102 ^ (long)-114006076);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1177126384 ^ (long)1177126145);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-755888781 ^ (long)-755888820);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-512398995 ^ (long)-512398909);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)282047813 ^ (long)282047830);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-713873140 ^ (long)-713873082);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)576798303 ^ (long)576798388);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)713808949 ^ (long)713809062);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-2086168101 ^ (long)-2086168074);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1209079427 ^ (long)1209079370);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1344341724 ^ (long)1344341504);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)358808797 ^ (long)358808778);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-2078573781 ^ (long)-2078573666);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)2051736217 ^ (long)2051736208);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1731230191 ^ (long)1731230020);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)366041658 ^ (long)366041808);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-833419278 ^ (long)-833419390);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1806591631 ^ (long)-1806591629);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)490146851 ^ (long)490146963);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)567961675 ^ (long)567961802);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1123341865 ^ (long)1123341824);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-846063081 ^ (long)-846062891);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-2083728820 ^ (long)-2083728693);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-884311024 ^ (long)-884310984);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)724594278 ^ (long)724594238);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-908670458 ^ (long)-908670376);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)602911542 ^ (long)602911661);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1010649723 ^ (long)1010649722);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1760512079 ^ (long)-1760512004);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)859792556 ^ (long)859792464);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1808291896 ^ (long)-1808291939);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1542076878 ^ (long)1542076870);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-748965019 ^ (long)-748964961);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-942326465 ^ (long)-942326367);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-915847333 ^ (long)-915847332);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)2016587633 ^ (long)2016587703);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1385738133 ^ (long)-1385738051);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1460053283 ^ (long)1460053460);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)549294827 ^ (long)549294750);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)2003802140 ^ (long)2003802346);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1301455355 ^ (long)-1301455134);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-2124290874 ^ (long)-2124290983);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-302569393 ^ (long)-302569221);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-606148480 ^ (long)-606148380);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)2096423771 ^ (long)2096423710);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-2140649978 ^ (long)-2140649940);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)675152162 ^ (long)675152285);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1833719574 ^ (long)1833719580);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1979347510 ^ (long)1979347481);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)766715977 ^ (long)766716007);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)901032403 ^ (long)901032351);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-18015512 ^ (long)-18015593);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1818252073 ^ (long)-1818252210);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1658105948 ^ (long)-1658105902);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)714706431 ^ (long)714706372);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1661214312 ^ (long)1661214402);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1884104415 ^ (long)-1884104428);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)320140818 ^ (long)320140908);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1675579697 ^ (long)1675579788);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)906714112 ^ (long)906714285);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1743004146 ^ (long)-1743003964);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)418736439 ^ (long)418736474);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)37358404 ^ (long)37358429);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)806365657 ^ (long)806365593);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-293450365 ^ (long)-293450430);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1195389927 ^ (long)1195389715);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-250219509 ^ (long)-250219282);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-2056858352 ^ (long)-2056858302);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)461309091 ^ (long)461309132);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-760045058 ^ (long)-760045085);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1085274492 ^ (long)-1085274466);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1083150196 ^ (long)-1083150286);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1397487273 ^ (long)1397487261);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1821488111 ^ (long)-1821488015);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)768658097 ^ (long)768658037);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1669473400 ^ (long)1669473525);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1033431040 ^ (long)1033431070);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)2144923561 ^ (long)2144923574);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-809395147 ^ (long)-809395103);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-991448149 ^ (long)-991448185);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)897854593 ^ (long)897854556);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1909266718 ^ (long)-1909266915);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1359838139 ^ (long)-1359838007);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1443806324 ^ (long)1443806454);
                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-871597024 ^ (long)-871596957);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1016576824 ^ (long)1016576967)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1232678962 ^ (long)-1232719823)) >>> (int)((long)-527414985 ^ (long)-527414977)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1392795082 ^ (long)1392795082);
            if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)412615301 ^ (long)412615303);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1388287646 ^ (long)1388287645) | var5_6 << (int)((long)355139613 ^ (long)355139608)) ^ var3_4[var7_8]) & (int)((long)1935919382 ^ (long)1935919593);
                    if (1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1173744973 ^ (long)1173744974) | var6_7 << (int)((long)-1972049637 ^ (long)-1972049634)) ^ var3_4[var7_8]) & (int)((long)79426058 ^ (long)79426293);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            1u.b[var2_3] = new String(var3_4).intern();
        }
        return 1u.b[var2_3];
    }

    public 1u(0R object) {
        boolean bl = \u2009\u200e\u200d\u2003\u200b\u2003\u2007;
        super(object, 1u.a((int)((long)-607428530 ^ (long)607450715), (int)((long)-160807235 ^ (long)160814991)) /* "NoDamage" */, null);
        Float f = Float.valueOf(3.0f);
        object = ((34e)((34e)((34e)this.9().5(1u.a((int)((long)1657333737 ^ (long)-1657310721), (int)((long)653631311 ^ (long)-653650164)) /* "Boost" */)).7(1u.a((int)((long)-1758968929 ^ (long)1758975368), (int)((long)-1769491413 ^ (long)1769499439)) /* "boost" */)).1(1u.a((int)((long)548783641 ^ (long)-548777971), (int)((long)-2069911021 ^ (long)2069897411)) /* "LongJump boost amount (3 = Bypass)" */)).3(Float.valueOf(3.0f)).2(Float.valueOf(15.0f));
        ((34e)((34e)((34e)this.9().5(1u.a((int)((long)1657333737 ^ (long)-1657310721), (int)((long)653631311 ^ (long)-653650164)) /* "Boost" */)).7(1u.a((int)((long)-1758968929 ^ (long)1758975368), (int)((long)-1769491413 ^ (long)1769499439)) /* "boost" */)).1(1u.a((int)((long)548783641 ^ (long)-548777971), (int)((long)-2069911021 ^ (long)2069897411)) /* "LongJump boost amount (3 = Bypass)" */)).3(Float.valueOf(3.0f)).2(Float.valueOf(15.0f)).7 = f;
        this.7 = (1A)((34e)object).5();
        this.6 = new Listener(sh -> {
            float f;
            float f2;
            block70: {
                block71: {
                    block72: {
                        float f3;
                        float f4;
                        int n;
                        String[] stringArray;
                        boolean bl;
                        block69: {
                            block68: {
                                bl = \u2009\u200e\u200d\u2003\u200b\u2003\u2007;
                                if (bl) return;
                                stringArray = 3e.5();
                                if (bl || bl) return;
                                if (1u.3.s == null) break block68;
                                if (bl) return;
                                if (sh.5 != EventState.PRE) break block68;
                                if (bl) return;
                                if (0R.8()) break block69;
                                if (bl) return;
                            }
                            if (bl) return;
                            return;
                        }
                        if (bl) return;
                        if (deo.a((long)djz.C().aD().i(), (int)((int)((long)-461209027 ^ (long)-461208725)))) {
                            if (bl || bl) return;
                            1u.4(0.0, 2.147483647E9, 0.0);
                            if (bl) return;
                        }
                        if (bl) {
                            return;
                        }
                        float f5 = 1u.3.s.p;
                        if (1u.3.s.aT < 0.0f) {
                            n = (int)((long)1257463026 ^ (long)1257462854);
                            if (\u2009\u200e\u200d\u2003\u200b\u2003\u2007) {
                                throw null;
                            }
                        } else {
                            n = (int)((long)412449413 ^ (long)412449413);
                        }
                        float f6 = f5 + (float)n;
                        if (1u.3.s.aR > 0.0f) {
                            float f7;
                            if (1u.3.s.aT > 0.0f) {
                                f7 = 0.5f;
                                if (\u2009\u200e\u200d\u2003\u200b\u2003\u2007) {
                                    throw null;
                                }
                            } else if (1u.3.s.aT < 0.0f) {
                                f7 = -0.5f;
                                if (\u2009\u200e\u200d\u2003\u200b\u2003\u2007) {
                                    throw null;
                                }
                            } else {
                                f7 = 1.0f;
                            }
                            f4 = -90.0f * f7;
                            if (\u2009\u200e\u200d\u2003\u200b\u2003\u2007) {
                                throw null;
                            }
                        } else {
                            f4 = 0.0f;
                        }
                        float f8 = f6 + f4;
                        if (1u.3.s.aR < 0.0f) {
                            float f9;
                            if (1u.3.s.aT > 0.0f) {
                                f9 = 0.5f;
                                if (\u2009\u200e\u200d\u2003\u200b\u2003\u2007) {
                                    throw null;
                                }
                            } else if (1u.3.s.aT < 0.0f) {
                                f9 = -0.5f;
                                if (\u2009\u200e\u200d\u2003\u200b\u2003\u2007) {
                                    throw null;
                                }
                            } else {
                                f9 = 1.0f;
                            }
                            f3 = -90.0f * f9;
                            if (\u2009\u200e\u200d\u2003\u200b\u2003\u2007) {
                                throw null;
                            }
                        } else {
                            f3 = 0.0f;
                        }
                        f2 = f8 - f3;
                        f = afm.b((float)((float)((double)(f2 + 90.0f) * Math.PI / 180.0)));
                        f2 = afm.a((float)((float)((double)(f2 + 90.0f) * Math.PI / 180.0)));
                        if (1u.3.s.v) break block70;
                        this.4 += (int)((long)-112924261 ^ (long)-112924262);
                        if (1u.3.s.f.h) {
                            1u.3.s.e.a((oj)new st.a(0.0, 2.147483647E9, 0.0, (boolean)((long)-1121102814 ^ (long)-1121102814)));
                        }
                        this.0 = (int)((long)-985491021 ^ (long)-985491021);
                        if (1u.3.s.v) break block71;
                        if (1u.3.s.cC().c == -0.07190068807140403) {
                            4m.1(1u.3.s.cC().c * (double)0.35f);
                        }
                        if (1u.3.s.cC().c == -0.10306193759436909) {
                            4m.1(1u.3.s.cC().c * (double)0.55f);
                        }
                        if (1u.3.s.cC().c == -0.13395038817442878) {
                            4m.1(1u.3.s.cC().c * (double)0.67f);
                        }
                        if (1u.3.s.cC().c == -0.16635183030382) {
                            4m.1(1u.3.s.cC().c * (double)0.69f);
                        }
                        if (1u.3.s.cC().c == -0.19088711097794803) {
                            4m.1(1u.3.s.cC().c * (double)0.71f);
                        }
                        if (1u.3.s.cC().c == -0.21121925191528862) {
                            4m.1(1u.3.s.cC().c * (double)0.2f);
                        }
                        if (1u.3.s.cC().c == -0.11979897632390576) {
                            4m.1(1u.3.s.cC().c * (double)0.93f);
                        }
                        if (1u.3.s.cC().c == -0.18758479151225355) {
                            4m.1(1u.3.s.cC().c * (double)0.72f);
                        }
                        if (1u.3.s.cC().c == -0.21075983825251726) {
                            4m.1(1u.3.s.cC().c * (double)0.76f);
                        }
                        if (!(1u.2((bfw)1u.3.s) < 0.5)) break block72;
                        if (1u.3.s.cC().c == -0.23537393014173347) {
                            4m.1(1u.3.s.cC().c * (double)0.03f);
                        }
                        if (1u.3.s.cC().c == -0.08531999505205401) {
                            4m.1(1u.3.s.cC().c * -0.5);
                        }
                        if (1u.3.s.cC().c == -0.03659320313669756) {
                            4m.1(1u.3.s.cC().c * (double)-0.1f);
                        }
                        if (1u.3.s.cC().c == -0.07481386749524899) {
                            4m.1(1u.3.s.cC().c * (double)-0.07f);
                        }
                        if (1u.3.s.cC().c == -0.0732677700939672) {
                            4m.1(1u.3.s.cC().c * (double)-0.05f);
                        }
                        if (1u.3.s.cC().c == -0.07480988066790395) {
                            4m.1(1u.3.s.cC().c * (double)-0.04f);
                        }
                        if (1u.3.s.cC().c == -0.0784000015258789) {
                            4m.1(1u.3.s.cC().c * (double)0.1f);
                        }
                        if (1u.3.s.cC().c == -0.08608320193943977) {
                            4m.1(1u.3.s.cC().c * (double)0.1f);
                        }
                        if (1u.3.s.cC().c == -0.08683615560584318) {
                            4m.1(1u.3.s.cC().c * (double)0.05f);
                        }
                        if (1u.3.s.cC().c == -0.08265497329678266) {
                            4m.1(1u.3.s.cC().c * (double)0.05f);
                        }
                        if (1u.3.s.cC().c == -0.08245009535659828) {
                            4m.1(1u.3.s.cC().c * (double)0.05f);
                        }
                        if (1u.3.s.cC().c == -0.08244005633718426) {
                            4m.1(-0.08243956442521608);
                        }
                        if (1u.3.s.cC().c == -0.08243956442521608) {
                            4m.1(-0.08244005590677261);
                        }
                        if (!(1u.3.s.cC().c > -0.1) || !(1u.3.s.cC().c < -0.08) || 1u.3.s.ao() || !1u.3.k.af.d()) break block71;
                        4m.1(-1.0E-4f);
                        if (stringArray == null) break block71;
                    }
                    if (1u.3.s.cC().c < -0.2 && 1u.3.s.cC().c > -0.24) {
                        4m.1(1u.3.s.cC().c * 0.7);
                    }
                    if (1u.3.s.cC().c < -0.25 && 1u.3.s.cC().c > -0.32) {
                        4m.1(1u.3.s.cC().c * 0.8);
                    }
                    if (1u.3.s.cC().c < -0.35 && 1u.3.s.cC().c > -0.8) {
                        4m.1(1u.3.s.cC().c * 0.98);
                    }
                    if (1u.3.s.cC().c < -0.8 && 1u.3.s.cC().c > -1.6) {
                        4m.1(1u.3.s.cC().c * 0.99);
                    }
                }
                ((9)9.getTimer()).setSpeed(0.85f);
                double[] dArray = new double[(int)((long)-992129100 ^ (long)-992129031)];
                dArray[(int)((long)465593740 ^ (long)465593740)] = 0.420606;
                dArray[(int)((long)212468962 ^ (long)212468963)] = 0.417924;
                dArray[(int)((long)2092993281 ^ (long)2092993283)] = 0.415258;
                dArray[(int)((long)-497674480 ^ (long)-497674477)] = 0.412609;
                dArray[(int)((long)-317293595 ^ (long)-317293599)] = 0.409977;
                dArray[(int)((long)-182105651 ^ (long)-182105656)] = 0.407361;
                dArray[(int)((long)316097711 ^ (long)316097705)] = 0.404761;
                dArray[(int)((long)-1820152411 ^ (long)-1820152414)] = 0.402178;
                dArray[(int)((long)-603911834 ^ (long)-603911826)] = 0.399611;
                dArray[(int)((long)-606707591 ^ (long)-606707600)] = 0.39706;
                dArray[(int)((long)-146238254 ^ (long)-146238248)] = 0.394525;
                dArray[(int)((long)-717532795 ^ (long)-717532786)] = 0.392;
                dArray[(int)((long)-1322209751 ^ (long)-1322209755)] = 0.3894;
                dArray[(int)((long)-175051718 ^ (long)-175051721)] = 0.38644;
                dArray[(int)((long)-1856661982 ^ (long)-1856661972)] = 0.383655;
                dArray[(int)((long)-97548810 ^ (long)-97548807)] = 0.381105;
                dArray[(int)((long)-890677273 ^ (long)-890677257)] = 0.37867;
                dArray[(int)((long)-738400981 ^ (long)-738400966)] = 0.37625;
                dArray[(int)((long)-1204440917 ^ (long)-1204440903)] = 0.37384;
                dArray[(int)((long)-938658753 ^ (long)-938658772)] = 0.37145;
                dArray[(int)((long)731288307 ^ (long)731288295)] = 0.369;
                dArray[(int)((long)-202675942 ^ (long)-202675953)] = 0.3666;
                dArray[(int)((long)768225350 ^ (long)768225360)] = 0.3642;
                dArray[(int)((long)1401960599 ^ (long)1401960576)] = 0.3618;
                dArray[(int)((long)-252509868 ^ (long)-252509876)] = 0.35945;
                dArray[(int)((long)1984431288 ^ (long)1984431265)] = 0.357;
                dArray[(int)((long)-559664864 ^ (long)-559664838)] = 0.354;
                dArray[(int)((long)344859947 ^ (long)344859952)] = 0.351;
                dArray[(int)((long)-123125577 ^ (long)-123125589)] = 0.348;
                dArray[(int)((long)-426260559 ^ (long)-426260564)] = 0.345;
                dArray[(int)((long)-1151458082 ^ (long)-1151458112)] = 0.342;
                dArray[(int)((long)-1570834051 ^ (long)-1570834078)] = 0.339;
                dArray[(int)((long)611410893 ^ (long)611410925)] = 0.336;
                dArray[(int)((long)-1400013413 ^ (long)-1400013382)] = 0.333;
                dArray[(int)((long)-44567058 ^ (long)-44567092)] = 0.33;
                dArray[(int)((long)42875867 ^ (long)42875896)] = 0.327;
                dArray[(int)((long)450919001 ^ (long)450919037)] = 0.324;
                dArray[(int)((long)-1735036922 ^ (long)-1735036893)] = 0.321;
                dArray[(int)((long)-217456993 ^ (long)-217456967)] = 0.318;
                dArray[(int)((long)1663427762 ^ (long)1663427733)] = 0.315;
                dArray[(int)((long)2089793075 ^ (long)2089793051)] = 0.312;
                dArray[(int)((long)-1658084116 ^ (long)-1658084155)] = 0.309;
                dArray[(int)((long)1010583771 ^ (long)1010583793)] = 0.307;
                dArray[(int)((long)804635717 ^ (long)804635758)] = 0.305;
                dArray[(int)((long)-1716388650 ^ (long)-1716388614)] = 0.303;
                dArray[(int)((long)-548247973 ^ (long)-548247946)] = 0.3;
                dArray[(int)((long)-332971780 ^ (long)-332971822)] = 0.297;
                dArray[(int)((long)1688226348 ^ (long)1688226307)] = 0.295;
                dArray[(int)((long)-1261454591 ^ (long)-1261454543)] = 0.293;
                dArray[(int)((long)-1910000202 ^ (long)-1910000249)] = 0.291;
                dArray[(int)((long)-879130980 ^ (long)-879130962)] = 0.289;
                dArray[(int)((long)-758557297 ^ (long)-758557252)] = 0.287;
                dArray[(int)((long)-1355982550 ^ (long)-1355982562)] = 0.285;
                dArray[(int)((long)-1350393697 ^ (long)-1350393686)] = 0.283;
                dArray[(int)((long)1941287398 ^ (long)1941287376)] = 0.281;
                dArray[(int)((long)-1473334131 ^ (long)-1473334086)] = 0.279;
                dArray[(int)((long)947649901 ^ (long)947649877)] = 0.277;
                dArray[(int)((long)-2120353260 ^ (long)-2120353235)] = 0.275;
                dArray[(int)((long)1474690718 ^ (long)1474690724)] = 0.273;
                dArray[(int)((long)-1647534104 ^ (long)-1647534125)] = 0.271;
                dArray[(int)((long)280711756 ^ (long)280711792)] = 0.269;
                dArray[(int)((long)2040352429 ^ (long)2040352400)] = 0.267;
                dArray[(int)((long)-1048360285 ^ (long)-1048360291)] = 0.265;
                dArray[(int)((long)-636496793 ^ (long)-636496808)] = 0.263;
                dArray[(int)((long)-1952034623 ^ (long)-1952034687)] = 0.261;
                dArray[(int)((long)-1362221812 ^ (long)-1362221747)] = 0.259;
                dArray[(int)((long)-1743868617 ^ (long)-1743868555)] = 0.257;
                dArray[(int)((long)1319605229 ^ (long)1319605166)] = 0.255;
                dArray[(int)((long)478619146 ^ (long)478619214)] = 0.253;
                dArray[(int)((long)1342807933 ^ (long)1342807864)] = 0.251;
                dArray[(int)((long)-1705130300 ^ (long)-1705130366)] = 0.249;
                dArray[(int)((long)-494116099 ^ (long)-494116166)] = 0.247;
                dArray[(int)((long)-1737261117 ^ (long)-1737261173)] = 0.245;
                dArray[(int)((long)-696839560 ^ (long)-696839631)] = 0.243;
                dArray[(int)((long)666656039 ^ (long)666656109)] = 0.241;
                dArray[(int)((long)-1985828300 ^ (long)-1985828225)] = 0.239;
                dArray[(int)((long)1209733102 ^ (long)1209733026)] = 0.237;
                double[] dArray2 = dArray;
                if (!1u.3.k.af.d()) {
                    4m.4(0.0);
                    4m.2(0.0);
                    return;
                }
                if (this.4 > (int)((long)-1188821000 ^ (long)-1188821067)) {
                    this.4 = (int)((long)1116631441 ^ (long)1116631516);
                }
                4m.4((double)f * dArray2[this.4 - (int)((long)-999338506 ^ (long)-999338505)] * (double)this.7.9);
                4m.2((double)f2 * dArray2[this.4 - (int)((long)-992713432 ^ (long)-992713431)] * (double)this.7.9);
                return;
            }
            if (1u.3.s.aT == 0.0f && 1u.3.s.aR == 0.0f) return;
            ((9)9.getTimer()).setSpeed(1.0f);
            this.4 = (int)((long)1814701085 ^ (long)1814701085);
            this.0 += (int)((long)499766335 ^ (long)499766334);
            4m.4(1u.3.s.cC().b / 13.0);
            4m.2(1u.3.s.cC().d / 13.0);
            if (this.0 == (int)((long)2104861359 ^ (long)2104861358)) {
                1u.4(1u.3.s.cD(), 1u.3.s.cE(), 1u.3.s.cH());
                1u.4(1u.3.s.cD() + 0.0624, 1u.3.s.cE(), 1u.3.s.cH());
                1u.4(1u.3.s.cD(), 1u.3.s.cE() + 0.419, 1u.3.s.cH());
                1u.4(1u.3.s.cD() + 0.0624, 1u.3.s.cE(), 1u.3.s.cH());
                1u.4(1u.3.s.cD(), 1u.3.s.cE() + 0.419, 1u.3.s.cH());
            }
            if (this.0 <= (int)((long)-1197847085 ^ (long)-1197847087)) return;
            this.0 = (int)((long)652835651 ^ (long)652835651);
            4m.4((double)f * 0.3);
            4m.2((double)f2 * 0.3);
            4m.1(0.424f);
        }, new Predicate[(int)((long)-1493105647 ^ (long)-1493105647)]);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void 4(double d, double d2, double d3) {
        block3: {
            block2: {
                boolean bl = \u2009\u200e\u200d\u2003\u200b\u2003\u2007;
                if (bl || bl) break block2;
                1u.3.s.e.a((oj)new st.a(d, d2, d3, 1u.3.s.ao()));
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        boolean bl = \u2009\u200e\u200d\u2003\u200b\u2003\u2007;
        if (bl || bl) return;
        if (1u.3.s != null) {
            if (bl || bl) return;
            ((9)9.getTimer()).setSpeed(1.0f);
            if (bl || bl) return;
            1u.3.s.c((boolean)((long)397981062 ^ (long)397981063));
            if (bl) return;
            return;
        }
        if (bl) return;
        ((0R)this.8).1();
        if (!bl && !bl) return;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-1651533372 ^ (long)-1651533376)];
            if (var7) break block23;
            var3_2 = (int)((long)-991840426 ^ (long)-991840426);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ue3a4\ucb9b\ud871\ud0ea\ue3f5\ucb7a\ud823\ud08b\ue324\ucb8d\ud8de", -1619474986);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1895344025 ^ (long)1895344028);
            if (var7) break block23;
            var0_6 = (int)((long)178846546 ^ (long)-178846547);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-690519668 ^ (long)-690519573);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1346978418 ^ (long)1346978417);
                    if (1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u8ad0\ua241\ub105\ub9db\u8a54\ua2f9\ub1c6\ub96d\u8a7f\ua234\ub17b\ub9a2\u8a48\ua25f\ub16f\ub93d\u8aee\ua24c\ub11d\ub9d2\u8ab7\ua205\ub1eb\ub9e7\u8a5a\ua25f\ub12a\ub9d9\u8ab0\ua249\ub1bc\ub995\u8add\ua2ca\ub107\ub996\u8a52\ua290\ub10d\ub9aa\u8a6e\ua289\ub161", -1425822515);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1003479790 ^ (long)-1003479782);
                            var0_6 = (int)((long)-1389950796 ^ (long)1389950795);
                            while (true) {
                                v0 = (int)((long)-690716301 ^ (long)-690716396);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1034842269 ^ (long)-1034842269);
                                if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) ** continue;
                                throw null;
                            }
                            1u.a = var5_1;
                            1u.b = new String[(int)((long)1700864623 ^ (long)1700864619)];
                            if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1255357867 ^ (long)1255357867);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-814654709 ^ (long)-814654710)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)14616716 ^ (long)14616715)) {
                                case 0: {
                                    v15 = (int)((long)-1044770326 ^ (long)-1044770306);
                                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)140391076 ^ (long)140391046);
                                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)2144031523 ^ (long)2144031525);
                                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1746679171 ^ (long)-1746679262);
                                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)643312082 ^ (long)643312030);
                                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)55900054 ^ (long)55900093);
                                    if (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)381458043 ^ (long)381457985);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!1u.\u2009\u200e\u200d\u2003\u200b\u2003\u2007);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

