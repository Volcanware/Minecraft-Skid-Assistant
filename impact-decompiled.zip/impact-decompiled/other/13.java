/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import clientapi.load.mixin.7.9;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.0H;
import net.impactclient.1A;
import net.impactclient.1P;
import net.impactclient.2w$6X;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3e;
import net.impactclient.3sh;
import net.impactclient.4E;
import net.impactclient.4X;
import net.impactclient.4m;
import net.impactclient.5Q;
import net.impactclient.5p;
import net.impactclient.7m;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 13
extends 7m<0H> {
    private static final String[] b;
    public static final boolean \u2002\u2008\u2009;
    private 1A 2U;
    private 1A 7;
    private 1P 4;
    @EventHandler
    private final Listener<4X> 1;
    private double 0;
    private static final String[] a;
    @EventHandler
    private final Listener<3sh> 5;
    private double 8;
    @EventHandler
    private final Listener<4E> 6;
    private int 2;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 13.\u2002\u2008\u2009;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)701235028 ^ (long)701226180)) & (int)((long)503721031 ^ (long)503763896);
            if (var9_2) ** GOTO lbl-1000
            if (13.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 13.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1772833922 ^ (long)1772833922)] & (int)((long)1793356638 ^ (long)1793356705)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-843564599 ^ (long)-843564581);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1569223649 ^ (long)-1569223671);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-958096461 ^ (long)-958096604);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1677956012 ^ (long)1677956004);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1373786529 ^ (long)1373786472);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1087002431 ^ (long)-1087002384);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)838480410 ^ (long)838480581);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-196787078 ^ (long)-196787134);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1435019511 ^ (long)1435019380);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)295744629 ^ (long)295744661);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1815075684 ^ (long)1815075631);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-777168428 ^ (long)-777168451);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)405281602 ^ (long)405281717);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1220463083 ^ (long)1220463092);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)2144620929 ^ (long)2144620944);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1830721615 ^ (long)-1830721544);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-2135642623 ^ (long)-2135642519);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1496261607 ^ (long)1496261428);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1062970884 ^ (long)1062970951);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-922176154 ^ (long)-922176182);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-922065476 ^ (long)-922065637);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-188728915 ^ (long)-188728973);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)483597759 ^ (long)483597582);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1334300997 ^ (long)1334301038);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-109135298 ^ (long)-109135188);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1661603067 ^ (long)-1661602914);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)248764522 ^ (long)248764602);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)235899734 ^ (long)235899806);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1547693405 ^ (long)1547693504);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-498907089 ^ (long)-498906948);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1392015333 ^ (long)-1392015268);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)2092723478 ^ (long)2092723677);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)636700904 ^ (long)636700746);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-2093090564 ^ (long)-2093090643);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1517282912 ^ (long)1517282993);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-203969919 ^ (long)-203969853);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-220233291 ^ (long)-220233378);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-2104018263 ^ (long)-2104018228);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-2139099724 ^ (long)-2139099864);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-230859585 ^ (long)-230859575);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1659385794 ^ (long)1659385744);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1175328186 ^ (long)-1175328245);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-2056540532 ^ (long)-2056540441);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1126190292 ^ (long)-1126190232);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1011700073 ^ (long)1011700211);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-631451805 ^ (long)-631451685);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)856643006 ^ (long)856643015);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)377824596 ^ (long)377824649);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1245179458 ^ (long)1245179599);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)783603971 ^ (long)783604092);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)961315538 ^ (long)961315387);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-570463945 ^ (long)-570463841);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1452094447 ^ (long)1452094263);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1624741079 ^ (long)-1624740893);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1650271068 ^ (long)1650271012);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-402552422 ^ (long)-402552479);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-221763444 ^ (long)-221763566);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1854495971 ^ (long)1854495832);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1047933128 ^ (long)-1047933134);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1757143991 ^ (long)-1757143875);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)480858238 ^ (long)480858232);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1479438324 ^ (long)1479438081);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1246662769 ^ (long)-1246662855);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1123707631 ^ (long)-1123707446);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1241776215 ^ (long)-1241776276);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1539020096 ^ (long)1539020226);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-931262077 ^ (long)-931262130);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1979088627 ^ (long)1979088402);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-507322881 ^ (long)-507323041);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)682840259 ^ (long)682840064);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)559446081 ^ (long)559446070);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-601984995 ^ (long)-601984774);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1976668168 ^ (long)-1976668219);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-537007667 ^ (long)-537007845);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1335323100 ^ (long)1335323054);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1519064122 ^ (long)-1519064225);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)2107884511 ^ (long)2107884296);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1551821129 ^ (long)1551821257);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1041243930 ^ (long)-1041244156);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1770759788 ^ (long)1770759903);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1870802304 ^ (long)1870802278);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1031824458 ^ (long)1031824546);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-811811915 ^ (long)-811811950);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1990197518 ^ (long)-1990197580);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)852727212 ^ (long)852727058);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1504974391 ^ (long)1504974526);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-554194837 ^ (long)-554194888);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-2016301851 ^ (long)-2016302046);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1759413368 ^ (long)1759413386);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1932754781 ^ (long)1932754793);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-18391563 ^ (long)-18391607);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)579073459 ^ (long)579073399);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)84502569 ^ (long)84502551);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1116715194 ^ (long)1116715075);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-828400633 ^ (long)-828400470);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1890712792 ^ (long)1890712599);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1013083176 ^ (long)-1013083352);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1007005495 ^ (long)1007005624);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)276801851 ^ (long)276801955);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1989094327 ^ (long)1989094228);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1863212276 ^ (long)-1863212263);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)44343641 ^ (long)44343558);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-521306398 ^ (long)-521306568);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)890189368 ^ (long)890189326);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)2105191570 ^ (long)2105191660);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1803503423 ^ (long)1803503390);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1242469282 ^ (long)1242469157);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1304655691 ^ (long)-1304655665);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1792845187 ^ (long)-1792845123);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)640930002 ^ (long)640929880);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1882090573 ^ (long)1882090716);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1485618594 ^ (long)-1485618526);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-237086591 ^ (long)-237086619);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)839101045 ^ (long)839101026);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1550493077 ^ (long)-1550493006);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1626211085 ^ (long)1626211161);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)852999044 ^ (long)852999146);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)845579238 ^ (long)845579171);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-42736580 ^ (long)-42736447);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1395956721 ^ (long)-1395956650);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1347551691 ^ (long)1347551525);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-957345188 ^ (long)-957345070);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)762235244 ^ (long)762235184);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)658164002 ^ (long)658164180);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1371584405 ^ (long)1371584488);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)2021687782 ^ (long)2021687642);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)589582789 ^ (long)589582738);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1515111001 ^ (long)1515111121);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-880397853 ^ (long)-880397898);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1532260157 ^ (long)1532260231);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-2081255302 ^ (long)-2081255207);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)659383878 ^ (long)659383962);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1556448832 ^ (long)1556448890);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1024347921 ^ (long)1024348085);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-750514407 ^ (long)-750514306);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1354105875 ^ (long)1354105904);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1987086486 ^ (long)1987086523);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1929885402 ^ (long)-1929885431);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1451856249 ^ (long)1451856220);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-797735884 ^ (long)-797735929);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)408145519 ^ (long)408145481);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-30897131 ^ (long)-30896984);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-63221066 ^ (long)-63221046);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1110547946 ^ (long)-1110547904);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-318466576 ^ (long)-318466580);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-474964381 ^ (long)-474964456);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1313646408 ^ (long)1313646468);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1360537001 ^ (long)1360537081);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1564347197 ^ (long)-1564347261);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)795794451 ^ (long)795794583);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-541926468 ^ (long)-541926480);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1969832423 ^ (long)1969832242);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1782343553 ^ (long)1782343566);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-503767127 ^ (long)-503767064);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1985127506 ^ (long)1985127568);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1553769230 ^ (long)-1553769286);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-59046621 ^ (long)-59046531);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1221422547 ^ (long)1221422564);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)412466184 ^ (long)412466204);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1844971100 ^ (long)-1844971075);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1694099751 ^ (long)1694099740);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)223777517 ^ (long)223777477);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-561195138 ^ (long)-561195162);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1667531665 ^ (long)1667531525);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-183206362 ^ (long)-183206183);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-333037375 ^ (long)-333037491);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1412328387 ^ (long)-1412328359);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)428074015 ^ (long)428073996);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1599230823 ^ (long)1599230761);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-791114957 ^ (long)-791114898);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-2095706257 ^ (long)-2095706134);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-988711203 ^ (long)-988711311);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1019547012 ^ (long)1019547021);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1582667398 ^ (long)-1582667332);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)2075552053 ^ (long)2075552203);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)659544949 ^ (long)659544951);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1399596783 ^ (long)1399596709);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1773485747 ^ (long)1773485746);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)395670209 ^ (long)395670270);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1479083120 ^ (long)1479083088);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1167150203 ^ (long)1167150175);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1324098735 ^ (long)1324098737);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-245233571 ^ (long)-245233492);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)474418953 ^ (long)474418957);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)227235758 ^ (long)227235829);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)567398489 ^ (long)567398551);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1579477356 ^ (long)-1579477493);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-75644344 ^ (long)-75644375);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)307950672 ^ (long)307950841);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)448932735 ^ (long)448932724);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1171419501 ^ (long)-1171419604);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1990314101 ^ (long)1990314164);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)989628588 ^ (long)989628489);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1325183275 ^ (long)1325183234);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1214557073 ^ (long)-1214557119);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)967191803 ^ (long)967191574);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-811913150 ^ (long)-811913127);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)769558017 ^ (long)769558164);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-898474353 ^ (long)-898474487);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1450348215 ^ (long)1450348131);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)880304153 ^ (long)880304195);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1736522181 ^ (long)1736522062);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1523846207 ^ (long)-1523846304);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1568092205 ^ (long)-1568092415);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1546308937 ^ (long)1546308869);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1291256442 ^ (long)1291256528);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-2007101930 ^ (long)-2007101788);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)10549641 ^ (long)10549702);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1219099956 ^ (long)1219099905);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1174446314 ^ (long)-1174446175);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1198690506 ^ (long)1198690379);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1020047602 ^ (long)1020047361);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-874159452 ^ (long)-874159601);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1359648181 ^ (long)1359648001);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1111131420 ^ (long)-1111131497);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-718398825 ^ (long)-718398729);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1235499199 ^ (long)-1235499212);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1917244416 ^ (long)-1917244240);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-119006204 ^ (long)-119006105);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)370250569 ^ (long)370250532);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1043363974 ^ (long)-1043363876);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)141974237 ^ (long)141974255);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1064504404 ^ (long)-1064504512);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1886425867 ^ (long)-1886426048);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1461337031 ^ (long)1461336877);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-657727894 ^ (long)-657727793);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1211591894 ^ (long)-1211591897);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1689897873 ^ (long)-1689897729);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-647255551 ^ (long)-647255551);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1348948913 ^ (long)1348948809);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1868044858 ^ (long)1868044886);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-451302340 ^ (long)-451302378);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1428363523 ^ (long)1428363520);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-444741587 ^ (long)-444741515);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)2139888109 ^ (long)2139887938);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1053873856 ^ (long)1053873841);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)601498221 ^ (long)601498237);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1617513695 ^ (long)-1617513657);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1986942826 ^ (long)1986942916);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1256777284 ^ (long)-1256777402);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)462940227 ^ (long)462940211);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-836596907 ^ (long)-836596934);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)427013016 ^ (long)427013023);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1962817353 ^ (long)1962817323);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1808442278 ^ (long)1808442271);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1699341237 ^ (long)1699341231);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-635649853 ^ (long)-635649879);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1259519730 ^ (long)1259519622);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-8916528 ^ (long)-8916666);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1019970669 ^ (long)-1019970692);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1619451720 ^ (long)1619451754);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)33658771 ^ (long)33658781);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1191312251 ^ (long)-1191312256);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1861451146 ^ (long)-1861451157);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-2088775415 ^ (long)-2088775367);
                    if (!13.\u2002\u2008\u2009) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1517904868 ^ (long)1517904733);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)2019592195 ^ (long)2019592444)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1699573297 ^ (long)-1699582416)) >>> (int)((long)-1271734558 ^ (long)-1271734550)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1813423257 ^ (long)-1813423257);
            if (!13.\u2002\u2008\u2009) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-611724463 ^ (long)-611724461);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-274431499 ^ (long)-274431498) | var5_6 << (int)((long)-749854817 ^ (long)-749854822)) ^ var3_4[var7_8]) & (int)((long)1126249433 ^ (long)1126249254);
                    if (13.\u2002\u2008\u2009) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1835869063 ^ (long)-1835869062) | var6_7 << (int)((long)-1530636366 ^ (long)-1530636361)) ^ var3_4[var7_8]) & (int)((long)1130826721 ^ (long)1130826526);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            13.b[var2_3] = new String(var3_4).intern();
        }
        return 13.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u2002\u2008\u2009;
                if (bl || bl) break block2;
                ((9)9.getTimer()).setSpeed(1.0f);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    public 13(0H e3) {
        boolean bl = \u2002\u2008\u2009;
        super(e3, 13.a((int)((long)-1332497003 ^ (long)-1332505086), (int)((long)1533157780 ^ (long)1533154968)) /* "Vanilla" */, null);
        this.4 = (1P)((34X)((34X)((34X)this.4().5(13.a((int)((long)1073156394 ^ (long)1073164979), (int)((long)1477218941 ^ (long)-1477219996)) /* "Antishake" */)).7(13.a((int)((long)1112661976 ^ (long)1112669258), (int)((long)-1389494037 ^ (long)1389472524)) /* "antishake" */)).1(13.a((int)((long)-199323583 ^ (long)-199314473), (int)((long)1522255502 ^ (long)-1522240518)) /* "Removes hand shaking" */)).5();
        Float f = Float.valueOf(5.0f);
        e3 = ((34e)((34e)((34e)this.9().5(13.a((int)((long)1351249684 ^ (long)1351240839), (int)((long)-239258078 ^ (long)-239260300)) /* "Speed" */)).7(13.a((int)((long)-1460835852 ^ (long)-1460843935), (int)((long)1704950020 ^ (long)-1704947764)) /* "speed" */)).1(13.a((int)((long)-148043699 ^ (long)-148034595), (int)((long)507049820 ^ (long)-507022618)) /* "Speed multiplier" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(5.0f));
        ((34e)((34e)((34e)this.9().5(13.a((int)((long)1351249684 ^ (long)1351240839), (int)((long)-239258078 ^ (long)-239260300)) /* "Speed" */)).7(13.a((int)((long)-1460835852 ^ (long)-1460843935), (int)((long)1704950020 ^ (long)-1704947764)) /* "speed" */)).1(13.a((int)((long)-148043699 ^ (long)-148034595), (int)((long)507049820 ^ (long)-507022618)) /* "Speed multiplier" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(5.0f)).7 = f;
        this.2U = (1A)((34e)e3).5();
        f = Float.valueOf(1.0f);
        e3 = ((34e)((34e)((34e)this.9().5(13.a((int)((long)-535437497 ^ (long)-535429930), (int)((long)1006006307 ^ (long)-1005985300)) /* "Boost" */)).7(13.a((int)((long)-1599201447 ^ (long)-1599193907), (int)((long)1180608504 ^ (long)1180605769)) /* "boost" */)).1(13.a((int)((long)190730802 ^ (long)190738858), (int)((long)1395820866 ^ (long)-1395838008)) /* "Timer boost added onto the base speed" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(3.0f));
        ((34e)((34e)((34e)this.9().5(13.a((int)((long)-535437497 ^ (long)-535429930), (int)((long)1006006307 ^ (long)-1005985300)) /* "Boost" */)).7(13.a((int)((long)-1599201447 ^ (long)-1599193907), (int)((long)1180608504 ^ (long)1180605769)) /* "boost" */)).1(13.a((int)((long)190730802 ^ (long)190738858), (int)((long)1395820866 ^ (long)-1395838008)) /* "Timer boost added onto the base speed" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(3.0f)).7 = f;
        this.7 = (1A)e3.5();
        this.5 = new Listener(sh2 -> {
            boolean bl;
            block8: {
                block7: {
                    bl = \u2002\u2008\u2009;
                    if (bl || bl) return;
                    if (13.3.s == null) break block7;
                    if (bl) return;
                    if (sh2.5 == EventState.PRE) break block8;
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            this.0 = 4m.0();
            if (!bl && !bl) return;
        }, new Predicate[(int)((long)210977969 ^ (long)210977969)]);
        this.1 = new Listener(x2 -> {
            double d2;
            block17: {
                float f;
                boolean bl;
                block16: {
                    bl = \u2002\u2008\u2009;
                    if (bl || bl) return;
                    if (x2.7 != EventState.PRE) {
                        if (bl || bl) return;
                        return;
                    }
                    if (bl) return;
                    if (13.3.s.aT != 0.0f) break block16;
                    if (bl) return;
                    if (13.3.s.aR == 0.0f) break block17;
                    if (bl) return;
                }
                if (bl) {
                    return;
                }
                9 v0 = (9)9.getTimer();
                if (this.2 == (int)((long)845453558 ^ (long)845453556)) {
                    f = 1.0f;
                    if (\u2002\u2008\u2009) {
                        throw null;
                    }
                } else {
                    f = this.7.9;
                }
                v0.setSpeed(f);
            }
            if (this.4.2) {
                13.3.s.A = 0.0f;
            }
            if (this.2 != (int)((long)-1744372242 ^ (long)-1744372244)) return;
            4X x3 = x2;
            double d3 = x3.2.1;
            if (5p.9()) {
                d2 = 0.4;
                if (\u2002\u2008\u2009) {
                    throw null;
                }
            } else {
                d2 = 0.2;
            }
            x3.9(d3 + d2);
        }, new Predicate[(int)((long)-1997444737 ^ (long)-1997444737)]);
        this.6 = new Listener(e2 -> {
            boolean bl;
            block11: {
                block10: {
                    String[] stringArray;
                    block9: {
                        bl = \u2002\u2008\u2009;
                        if (bl) return;
                        stringArray = 3e.5();
                        if (bl || bl) return;
                        if (!13.3.s.ao()) {
                            if (bl || bl) return;
                            return;
                        }
                        if (bl) return;
                        if (13.3.s.aT != 0.0f) break block9;
                        if (bl) return;
                        if (13.3.s.aR == 0.0f) break block10;
                        if (bl) return;
                    }
                    if (bl) return;
                    switch (this.2) {
                        case 1: {
                            if (bl) return;
                            double d2 = (double)(this.2U.9 / 5.0f) + 1.149;
                            if (bl || bl) return;
                            this.8 *= d2;
                            if (bl || bl) return;
                            this.2 = (int)((long)-1655619566 ^ (long)-1655619568);
                            if (bl || bl) return;
                            if (stringArray == null) break block11;
                            if (bl) return;
                        }
                        case 2: {
                            if (bl) return;
                            this.2 = (int)((long)-901951696 ^ (long)-901951695);
                            if (bl || bl) return;
                            double d3 = 0.66 * (this.0 - 4m.1(5Q.b));
                            if (bl || bl) return;
                            this.8 = this.0 - d3;
                            if (bl) return;
                        }
                        default: {
                            if (bl) return;
                            if (stringArray == null) break block11;
                            if (bl) return;
                        }
                    }
                }
                if (bl) return;
                ((9)9.getTimer()).setSpeed(1.0f);
                if (bl) return;
            }
            if (bl) return;
            this.8 = Math.max(this.8, 4m.1(5Q.b));
            4m.7(e2, this.8);
            if (!bl && !bl) return;
        }, new Predicate[(int)((long)1659957379 ^ (long)1659957379)]);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        block3: {
            block2: {
                boolean bl = \u2002\u2008\u2009;
                if (bl || bl) break block2;
                this.2 = (int)((long)-1400239863 ^ (long)-1400239861);
                if (bl || bl) break block2;
                this.8 = 4m.7(5Q.b);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 13.\u2002\u2008\u2009;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-936547075 ^ (long)-936547081)];
            if (var7) break block23;
            var3_2 = (int)((long)-341784072 ^ (long)-341784072);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u0349\u2b6e\u387c\u30f4\u030e\u2b9a\u38f9\u30cc\u0340\u2bd2\u382a\u30f0\u03e9\u2b59\u38ff\u30c2\u032b\u2b17\u38d2\u3006\u0385\u2b73\u38dc\u3025\u03ef\u2b79\u389d\u3086\u031b\u2bfc\u382b\u3068\u032b\u2bfc\u388e\u3042\u03e4\u2ba0\u38d0\u306d\u036e\u2b08\u3896\u30d7\u032b\u2b47\u3858\u3011\u033e\u2bca\u38c1\u30a4\u03eb\u2b05\u3871\u3036\u034d\u2b5d\u3806\u3001\u0308\u2b6c\u3880\u3086\u03b2\u2b37\u387d\u3069\u03a5\u2b00\u3897\u30a6\u032f\u2b3e\u381e\u30c1\u0320\u2bfd\u3839", -109894304);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1484019098 ^ (long)-1484019082);
            if (var7) break block23;
            var0_6 = (int)((long)-1179455567 ^ (long)1179455566);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1851303279 ^ (long)1851303179);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1741302319 ^ (long)1741302318);
                    if (13.\u2002\u2008\u2009) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!13.\u2002\u2008\u2009) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u756f\u5db3\u4edf\u46fd\u75ed\u5d33\u4ed6\u466b\u75c0\u5df0\u4ecc\u468b\u750e\u5de9\u4e26\u46e7\u754d\u5dda\u4e0e\u4611\u7586\u5dcd\u4ed5\u4646\u7550\u5d9a\u4ec7\u4645\u75f7\u5dc7\u4e57\u466f\u75f4\u5ddc\u4ed3\u46c6\u758c\u5de4\u4e58\u4657\u7513\u5def\u4ecb\u46d1\u75b4\u5d17\u4e61", 1784697668);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-774433933 ^ (long)-774433962);
                            var0_6 = (int)((long)2097847076 ^ (long)-2097847077);
                            while (true) {
                                v0 = (int)((long)767603514 ^ (long)767603543);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1828239964 ^ (long)-1828239964);
                                if (!13.\u2002\u2008\u2009) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!13.\u2002\u2008\u2009) ** continue;
                                throw null;
                            }
                            13.a = var5_1;
                            13.b = new String[(int)((long)-1066849062 ^ (long)-1066849072)];
                            if (!13.\u2002\u2008\u2009) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-373346102 ^ (long)-373346102);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)488681029 ^ (long)488681028)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)755299098 ^ (long)755299101)) {
                                case 0: {
                                    v15 = (int)((long)1342647404 ^ (long)1342647345);
                                    if (!13.\u2002\u2008\u2009) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)961322538 ^ (long)961322561);
                                    if (!13.\u2002\u2008\u2009) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1478191633 ^ (long)1478191691);
                                    if (!13.\u2002\u2008\u2009) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1617661346 ^ (long)-1617661343);
                                    if (!13.\u2002\u2008\u2009) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-517294414 ^ (long)-517294423);
                                    if (!13.\u2002\u2008\u2009) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1508905103 ^ (long)-1508905106);
                                    if (!13.\u2002\u2008\u2009) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1107841240 ^ (long)-1107841266);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!13.\u2002\u2008\u2009);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

