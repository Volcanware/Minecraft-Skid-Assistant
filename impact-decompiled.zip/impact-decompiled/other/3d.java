/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  baritone.api.BaritoneAPI
 *  k
 *  np
 *  np$a
 *  nr
 */
package net.impactclient;

import baritone.api.BaritoneAPI;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Optional;
import net.impactclient.2w$6X;
import net.impactclient.349;
import net.impactclient.3X;
import net.impactclient.3sC;
import net.impactclient.5p;
import net.impactclient.5w;
import net.impactclient.5z;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3d
implements 349<Optional<?>> {
    public static final boolean \u200a\u2006\u2009;
    private static final String[] a;
    private static final String[] b;

    /*
     * Enabled aggressive block sorting
     */
    public 3d() {
        boolean bl = \u200a\u2006\u2009;
        if (bl) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final /* synthetic */ Object 9(5w w, Type type, String string) {
        boolean bl = \u200a\u2006\u2009;
        if (bl || bl) return null;
        if (string.isEmpty()) {
            if (bl || bl) return null;
            return Optional.empty();
        }
        if (bl) return null;
        if (!(type instanceof ParameterizedType)) {
            if (bl || bl) return null;
            return null;
        }
        if (bl) return null;
        if ((type = (ParameterizedType)type).getActualTypeArguments().length != (int)((long)853583603 ^ (long)853583602)) {
            if (bl || bl) return null;
            return null;
        }
        if (bl) return null;
        type = type.getActualTypeArguments()[(int)((long)2138897199 ^ (long)2138897199)];
        if (bl || bl) return null;
        349 var4_5 = w.2().2(type);
        if (var4_5 == null) {
            if (bl || bl) return null;
            return null;
        }
        if (!bl) return Optional.ofNullable(var4_5.9(w, type, string));
        return null;
    }

    public static boolean 8() {
        boolean bl = \u200a\u2006\u2009;
        if (bl || bl) {
            return true;
        }
        return BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().isPathing();
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void 2() {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u200a\u2006\u2009;
                    if (bl || bl) break block2;
                    k[] kArray = 5z.4().1G;
                    if (bl || bl) break block2;
                    String string = 5z.4().2.5.8;
                    if (bl || bl) break block2;
                    if (kArray.0(3d.a((int)((long)-1964081141 ^ (long)1964067495), (int)((long)220343135 ^ (long)-220333946)) /* "baritone_first_time" */, (boolean)((long)1215319492 ^ (long)1215319492))) break block3;
                    if (bl || bl) break block2;
                    kArray.7(3d.a((int)((long)988857463 ^ (long)-988868928), (int)((long)1503383205 ^ (long)1503392365)), (boolean)((long)1728240283 ^ (long)1728240282));
                    if (bl || bl) break block2;
                    k[] kArray2 = new k[(int)((long)384255050 ^ (long)384255051)];
                    kArray2[(int)((long)-804700931 ^ (long)-804700931)] = k.h;
                    kArray = kArray2;
                    3sC sC = new 3sC().2(3d.a((int)((long)-1935125215 ^ (long)1935122323), (int)((long)1709145705 ^ (long)1709128281)) /* "We've detected that it is your first time using " */, null, kArray);
                    k[] kArray3 = new k[(int)((long)1745049089 ^ (long)1745049088)];
                    kArray3[(int)((long)-794167976 ^ (long)-794167976)] = k.n;
                    kArray = kArray3;
                    3sC sC2 = sC.2(3d.a((int)((long)-1606388995 ^ (long)1606400075), (int)((long)-473678375 ^ (long)473673268)) /* "Baritone" */, null, kArray);
                    k[] kArray4 = new k[(int)((long)1069537320 ^ (long)1069537321)];
                    kArray4[(int)((long)-128395864 ^ (long)-128395864)] = k.h;
                    kArray = kArray4;
                    3sC sC3 = sC2.2(3d.a((int)((long)1800327899 ^ (long)-1800333196), (int)((long)102996283 ^ (long)-103019657)) /* "! " */, null, kArray);
                    k[] kArray5 = new k[(int)((long)486706825 ^ (long)486706824)];
                    kArray5[(int)((long)-1413437809 ^ (long)-1413437809)] = k.n;
                    kArray = kArray5;
                    3sC sC4 = sC3.2(3d.a((int)((long)-383638084 ^ (long)383643399), (int)((long)1036133784 ^ (long)-1036143211)), null, kArray);
                    k[] kArray6 = new k[(int)((long)-916553708 ^ (long)-916553707)];
                    kArray6[(int)((long)-1910618220 ^ (long)-1910618220)] = k.h;
                    kArray = kArray6;
                    3sC sC5 = sC4.2(3d.a((int)((long)926575555 ^ (long)-926572161), (int)((long)-1610348568 ^ (long)1610324034)) /* " is an advanced Minecraft A* Path Finding bot that is integrated with " */, null, kArray);
                    k[] kArray7 = new k[(int)((long)-466048669 ^ (long)-466048670)];
                    kArray7[(int)((long)-2061076624 ^ (long)-2061076624)] = k.j;
                    kArray = kArray7;
                    3sC sC6 = sC5.2(3d.a((int)((long)-581121812 ^ (long)581108289), (int)((long)-2010343650 ^ (long)2010316948)) /* "Impact " */, null, kArray);
                    k[] kArray8 = new k[(int)((long)700437972 ^ (long)700437973)];
                    kArray8[(int)((long)1675415315 ^ (long)1675415315)] = k.j;
                    kArray = kArray8;
                    3sC sC7 = sC6.2(3d.a((int)((long)1157432776 ^ (long)-1157443719), (int)((long)-443258248 ^ (long)443257462)) /* "4.9.1-1.16.5" */, null, kArray);
                    k[] kArray9 = new k[(int)((long)244393181 ^ (long)244393180)];
                    kArray9[(int)((long)-1963095122 ^ (long)-1963095122)] = k.h;
                    kArray = kArray9;
                    3sC sC8 = sC7.2(3d.a((int)((long)2105048266 ^ (long)-2105035138), (int)((long)1889135447 ^ (long)1889121135)) /* ". To get started, navigate to the " */, null, kArray);
                    k[] kArray10 = new k[(int)((long)1154542978 ^ (long)1154542979)];
                    kArray10[(int)((long)814328677 ^ (long)814328677)] = k.j;
                    kArray = kArray10;
                    3sC sC9 = sC8.2(3d.a((int)((long)1474374772 ^ (long)-1474369852), (int)((long)1565129721 ^ (long)-1565127170)) /* "Movement" */, null, kArray);
                    k[] kArray11 = new k[(int)((long)415945168 ^ (long)415945169)];
                    kArray11[(int)((long)-2038624668 ^ (long)-2038624668)] = k.h;
                    kArray = kArray11;
                    3sC sC10 = sC9.2(3d.a((int)((long)1789006005 ^ (long)-1789011448), (int)((long)-1422344230 ^ (long)-1422342659)) /* " panel in the Click GUI and find " */, null, kArray);
                    k[] kArray12 = new k[(int)((long)850272145 ^ (long)850272144)];
                    kArray12[(int)((long)-140308176 ^ (long)-140308176)] = k.n;
                    kArray = kArray12;
                    3sC sC11 = sC10.2(3d.a((int)((long)-2038267858 ^ (long)2038254229), (int)((long)-1536659631 ^ (long)1536687964)), null, kArray).1(3d.a((int)((long)718412662 ^ (long)-718417463), (int)((long)-1391754339 ^ (long)1391748411)) /* ". Try typing " */);
                    k[] kArray13 = new k[(int)((long)-329234986 ^ (long)-329234985)];
                    kArray13[(int)((long)-1424163257 ^ (long)-1424163257)] = k.j;
                    kArray = kArray13;
                    3sC sC12 = sC11.2(string + 3d.a((int)((long)-1250574060 ^ (long)1250560935), (int)((long)1584326502 ^ (long)1584325670)) /* "goto portal" */, null, kArray);
                    k[] kArray14 = new k[(int)((long)-386217128 ^ (long)-386217127)];
                    kArray14[(int)((long)1018682776 ^ (long)1018682776)] = k.h;
                    kArray = kArray14;
                    k[] kArray15 = new k[(int)((long)-286794629 ^ (long)-286794631)];
                    kArray15[(int)((long)1726046285 ^ (long)1726046285)] = k.t;
                    kArray15[(int)((long)-602919072 ^ (long)-602919071)] = k.j;
                    3sC sC13 = sC12.2(3d.a((int)((long)2090506166 ^ (long)-2090509041), (int)((long)1391180513 ^ (long)-1391180845)) /* " (or another block) to path to a block. You may also want to check out the " */, null, kArray).2(3d.a((int)((long)-889298686 ^ (long)889301948), (int)((long)1864247325 ^ (long)-1864254545)) /* "GitHub Repo" */, new np(np.a.a, 3d.a((int)((long)-2111032688 ^ (long)2111043621), (int)((long)888155177 ^ (long)-888176384)) /* "https://github.com/cabaletta/baritone/blob/master/USAGE.md" */), kArray15);
                    k[] kArray16 = new k[(int)((long)-1092143895 ^ (long)-1092143896)];
                    kArray16[(int)((long)-1519357383 ^ (long)-1519357383)] = k.h;
                    kArray = kArray16;
                    5p.9((nr)sC13.2((String)3d.a((int)((int)((long)722700064 ^ (long)-722711142)), (int)((int)((long)1497912144 ^ (long)1497921172))), null, (k[])kArray).7);
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 3d.\u200a\u2006\u2009;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-138376342 ^ (long)-138376327)];
            if (var7) break block23;
            var3_2 = (int)((long)539755952 ^ (long)539755952);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\uac04\u84a3\u97b8\u9f0a\uacfd\u84ce\u972f\u9f15\uac01\u8428\u976f\u9f74\uaca8\u8421\u972d\u9f3d\uac93\u842e\u9796\u9fcf\uace3\u84a9\u973d\u9f61\uac37\u843e\u971c\u9fcb\uacb6\u8400\u976f\u9f4e\uacac\u84c2\u977d\u9f7f\uac8c\u8480\u9726\u9f7f\uacd9\u840c\u97dc\u9f31\uac83\u84a8\u978d\u9f5c\uac61\u8456\u97f4\u9fe9\uacd6\u845c\u9763\u9f74\uacac\u843a\u9734\u9ff0\uace7\u84fa\u9707\u9f31\uacd1\u8403\u97d4\u9f9f\uacc9\u849f\u977e\u9f58\uac94\u84d5\u9762\u9fb6\uac1e\u84a9\u97e4\u9ff9\uacd0\u8433\u97f8\u9f33\uacdc\u841b\u9754\u9f3a\uac24\u84e7\u9706\u9f6b\uac29\u84dd\u9704\u9fd6\uacd8\u8465\u9755\u9fb8\uac76\u84a2\u9731\u9f01\uac9d\u84e2\u9784\u9f68\uac57\u84f2\u9725\u9ff3\uac42\u84c0\u970a\u9f66\uaca0\u840f\u9793\u9f6a\uac13\u8478\u97f6\u9fbd\uac27\u84a6\u972a\u9fc4\uac59\u8435\u97d3\u9f81\uac08\u8495\u97c6\u9f2d\uac5f\u8405\u977b\u9f26\uacf1\u8450\u97e2\u9fc6\uac72\u84b1\u97a8\u9f3f\uac6d\u8499\u9758\u9fc4\uacfb\u8476\u97f0\u9fe5\uacd6\u84d9\u9779\u9f6e\uacca\u84f9\u9722\u9f06\uacb1\u8462\u97c5\u9f9f\uac25\u84d9\u9749\u9fac\uac12\u84b3\u9747\u9f4b\uac3c\u8488\u9739\u9fa9\uacd4\u843f\u9769\u9fb4\uac1a\u8493\u97cd\u9f0f\uac94\u8481\u9741\u9fd7\uac13\u845c\u97ba\u9fdc\uac81\u84bf\u9792\u9f83\uacd4\u84aa\u97b3\u9f92\uac78\u844f\u97a0\u9f57\uac2f\u8441\u976b\u9f78\uacc8\u84a4\u97e0\u9f62\uac81\u8480\u97b6\u9fae\uac83\u848b\u97f6\u9fb1\uacca\u8487\u9700\u9f3e\uacf6\u845b\u97d9\u9f3b\uac47\u841a\u971a\u9f42\uac95\u8482\u9762\u9f46\uac02\u84c5\u9771\u9f49\uac0d\u8446\u9714\u9fbc\uac8f\u841f\u970f\u9f3a\uaccd\u84d0\u97e9\u9f54\uaca0\u84fb\u9763\u9f34\uac3d\u84cd\u97fd\u9fe4\uaccd\u844b\u97bc\u9f23\uac1d\u840f\u974e\u9f42\uacb2\u84a5\u9746\u9f74\uac83\u8427\u97e2\u9f13\uac0e\u84ec\u97e8\u9f8b\uacc2\u8491\u9748\u9f5b\uac6e\u84e1\u973e\u9f40\uac81\u844a\u9711\u9f39\uac61\u84ed\u9795\u9fd2\uac60\u84ad\u97fc\u9f84\uac74\u84e0\u97f8\u9fd6\uaccb\u846b\u9715\u9f89\uace9\u8435\u9776\u9fb0\uaccd\u845b\u97de\u9f7a\uac8e\u84a2\u9796\u9f48\uac22\u8460\u9722\u9f8a\uac9f\u841d\u9778\u9f6a\uacb6\u8480\u97b8\u9f04\uac79\u849b\u97f9\u9f41\uacd9\u8420\u9769\u9fd4\uac64\u84f8\u97bf\u9f84\uac6c\u84f9\u9792\u9f2d\uac8d\u841d\u9743\u9ffe\uac90\u8418\u97dc\u9f11\uacb4\u8404\u9769\u9f8e\uac16\u846a\u97ba\u9f0f\uac29\u84b0\u97f6\u9fd5\uace1\u8411\u9771\u9f9a\uacd3\u8408\u97cd\u9fac\uacf0\u84ed\u9727\u9fd3\uacbd\u84e5\u9721\u9fe6\uacbb\u8437\u972f\u9f77\uac0f\u8474\u9725\u9f81\uacd0\u8428\u97ce\u9fa7\uac46\u8497\u97c6\u9f71\uacf0\u8401\u979d\u9f2e\uac57\u8403\u97b1\u9f44\uac7a\u8408\u97ab\u9fc6\uac8c\u8462\u9731\u9fb5\uacc5\u848c\u97a7\u9f6e\uacf8\u84e2\u979c\u9f52\uac77\u848c\u9794\u9f95\uace9\u84d7\u9760\u9fe8\uac10\u84d1\u9716\u9f4d\uac6b\u849b\u9763\u9fe4\uac2c\u84df\u976a\u9f72\uac5a\u84a2\u979c\u9fad\uac9b\u84b1\u9752\u9f42\uac36\u84ca\u97e7\u9f9d\uac4b\u8471\u9749\u9fd6\uaca0\u84b9\u979f\u9f26\uacdd\u843a\u97f0\u9f65\uace4\u8404\u974d\u9f77\uacd6\u84c4\u973d\u9f35\uac95\u8404\u97b1\u9fac\uac81\u84ec\u97d2\u9fa8\uacbd\u8449\u9718\u9f68\uac38\u840f\u9750\u9f91\uacc1\u8427\u9733\u9f5c\uac95\u8482\u9741\u9f73\uac7d\u840f\u9736\u9f19\uac3f\u847f\u970c\u9ff1\uacd8\u8483\u9705\u9f7c\uacc4\u8425\u974e\u9fb8\uac96", 1155500589);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1506165112 ^ (long)-1506165079);
            if (var7) break block23;
            var0_6 = (int)((long)-1557806186 ^ (long)1557806185);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1123959563 ^ (long)1123959643);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1829575560 ^ (long)-1829575561);
                    if (3d.\u200a\u2006\u2009) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3d.\u200a\u2006\u2009) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ue6fb\uced2\udd86\ud5c8\ue682\uceaa\udd65\ud52e\ue626\uce5c\udd59\ud5b6\ue61e\uceac\uddeb\ud592\ue60c\uce16\uddb3\ud5c9\ue679\uce1e", -954875894);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-905341467 ^ (long)-905341450);
                            var0_6 = (int)((long)-170106412 ^ (long)170106411);
                            while (true) {
                                v0 = (int)((long)1834501355 ^ (long)1834501283);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-129253693 ^ (long)-129253693);
                                if (!3d.\u200a\u2006\u2009) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3d.\u200a\u2006\u2009) ** continue;
                                throw null;
                            }
                            3d.a = var5_1;
                            3d.b = new String[(int)((long)-1298111674 ^ (long)-1298111659)];
                            if (!3d.\u200a\u2006\u2009) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1132101259 ^ (long)1132101259);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)961647629 ^ (long)961647628)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-691971368 ^ (long)-691971361)) {
                                case 0: {
                                    v15 = (int)((long)1627077447 ^ (long)1627077481);
                                    if (!3d.\u200a\u2006\u2009) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1680308053 ^ (long)-1680308047);
                                    if (!3d.\u200a\u2006\u2009) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)574965140 ^ (long)574965244);
                                    if (!3d.\u200a\u2006\u2009) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)952176957 ^ (long)952176950);
                                    if (!3d.\u200a\u2006\u2009) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1080640291 ^ (long)-1080640309);
                                    if (!3d.\u200a\u2006\u2009) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1500793051 ^ (long)-1500793017);
                                    if (!3d.\u200a\u2006\u2009) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1142762615 ^ (long)-1142762526);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!3d.\u200a\u2006\u2009);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 3d.\u200a\u2006\u2009;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1600653171 ^ (long)1600664112)) & (int)((long)-890846635 ^ (long)-890880598);
            if (var9_2) ** GOTO lbl-1000
            if (3d.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3d.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1698385233 ^ (long)1698385233)] & (int)((long)-702902158 ^ (long)-702902131)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1245079872 ^ (long)1245080039);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1712396318 ^ (long)1712396469);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1455053395 ^ (long)-1455053389);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1834794001 ^ (long)1834794072);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1103595062 ^ (long)1103595064);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)572193190 ^ (long)572193273);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-438369949 ^ (long)-438369968);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1121187537 ^ (long)1121187338);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1752347348 ^ (long)1752347267);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1508700353 ^ (long)1508700256);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)2012509983 ^ (long)2012510181);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-2146375082 ^ (long)-2146374928);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1707107611 ^ (long)1707107681);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1068520135 ^ (long)1068520021);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)574466554 ^ (long)574466341);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)388335368 ^ (long)388335475);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1410247515 ^ (long)-1410247540);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-542404974 ^ (long)-542404889);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1596130417 ^ (long)1596130425);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1642583778 ^ (long)1642583581);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)906715666 ^ (long)906715742);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1597024529 ^ (long)-1597024678);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-2022481905 ^ (long)-2022481785);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1543684491 ^ (long)1543684513);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1168242640 ^ (long)-1168242624);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)834014856 ^ (long)834014847);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1733165752 ^ (long)-1733165756);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)359617480 ^ (long)359617529);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)949476071 ^ (long)949476021);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)332985554 ^ (long)332985490);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)93453336 ^ (long)93453493);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)693910049 ^ (long)693910036);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1770498229 ^ (long)1770498099);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)2020643778 ^ (long)2020643647);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)299158905 ^ (long)299158870);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-554510988 ^ (long)-554510888);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1431510858 ^ (long)1431510877);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-157492174 ^ (long)-157491986);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)346502313 ^ (long)346502157);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)30627799 ^ (long)30627745);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1965315763 ^ (long)-1965315769);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1677586138 ^ (long)1677585996);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)985842913 ^ (long)985842800);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)182857857 ^ (long)182857754);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-2013299789 ^ (long)-2013299852);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1058185096 ^ (long)-1058185095);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)764876519 ^ (long)764876316);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)964645120 ^ (long)964645302);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1560194424 ^ (long)-1560194334);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1589022810 ^ (long)-1589022973);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1080294298 ^ (long)-1080294334);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-534074700 ^ (long)-534074689);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-699746087 ^ (long)-699746192);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1265952111 ^ (long)1265952073);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1836749059 ^ (long)-1836749120);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1074066899 ^ (long)-1074066860);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1303206695 ^ (long)-1303206739);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)901602346 ^ (long)901602323);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1367721125 ^ (long)1367721123);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)884785260 ^ (long)884785339);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)955320256 ^ (long)955320293);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)2100458340 ^ (long)2100458275);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-625907241 ^ (long)-625907382);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)2027688315 ^ (long)2027688421);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)2042000600 ^ (long)2042000402);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1212263759 ^ (long)-1212263845);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1667048893 ^ (long)1667048803);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-50712448 ^ (long)-50712420);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1065126371 ^ (long)1065126292);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1720343125 ^ (long)1720343207);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-767947376 ^ (long)-767947269);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-349996750 ^ (long)-349996572);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-444598453 ^ (long)-444598306);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-757547418 ^ (long)-757547426);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1355925068 ^ (long)-1355925153);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-730533340 ^ (long)-730533328);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1638602671 ^ (long)1638602544);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1172740207 ^ (long)1172740263);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1475903020 ^ (long)1475903184);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-366262772 ^ (long)-366262718);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1143975749 ^ (long)1143975931);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1653797858 ^ (long)-1653797711);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-403803294 ^ (long)-403803337);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-198625365 ^ (long)-198625288);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1877254952 ^ (long)-1877255084);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1718445715 ^ (long)1718445822);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-509729187 ^ (long)-509729233);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)476541366 ^ (long)476541386);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1478780213 ^ (long)1478780389);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1619454424 ^ (long)1619454267);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-596900040 ^ (long)-596900064);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)332254333 ^ (long)332254415);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-2017347184 ^ (long)-2017347158);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-629824132 ^ (long)-629824028);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1291632850 ^ (long)1291632836);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1482776811 ^ (long)-1482776752);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-75290899 ^ (long)-75291059);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)546597986 ^ (long)546597991);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)821859731 ^ (long)821859764);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1825212974 ^ (long)-1825213140);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-870045019 ^ (long)-870045121);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1400041025 ^ (long)1400041153);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-210860569 ^ (long)-210860597);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)98491480 ^ (long)98491569);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)297676114 ^ (long)297676196);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1921636065 ^ (long)1921635853);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)595692834 ^ (long)595693004);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1796511752 ^ (long)-1796511944);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1598463979 ^ (long)-1598463801);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1096943301 ^ (long)-1096943349);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)751973670 ^ (long)751973756);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1410972278 ^ (long)1410972232);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-832399961 ^ (long)-832400029);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-413006584 ^ (long)-413006354);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1632634594 ^ (long)-1632634476);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1545425801 ^ (long)-1545425677);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1545821788 ^ (long)1545821761);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1316286557 ^ (long)-1316286564);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1448428171 ^ (long)1448428056);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-747908823 ^ (long)-747908833);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1456070625 ^ (long)-1456070621);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1079038103 ^ (long)1079037996);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1995203289 ^ (long)1995203131);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1642874660 ^ (long)1642874686);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1009599367 ^ (long)1009599481);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-674764686 ^ (long)-674764749);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)808960673 ^ (long)808960608);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)116803322 ^ (long)116803230);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-761699420 ^ (long)-761699563);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-517678083 ^ (long)-517678206);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1533740291 ^ (long)1533740314);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)899303400 ^ (long)899303370);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-86194489 ^ (long)-86194666);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)960519504 ^ (long)960519565);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1359995788 ^ (long)-1359995732);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1069354911 ^ (long)-1069354999);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1462677309 ^ (long)1462677305);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-246074979 ^ (long)-246074961);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-153158724 ^ (long)-153158892);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1091182079 ^ (long)1091181966);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1566464984 ^ (long)1566464904);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1787214248 ^ (long)-1787214100);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-68394516 ^ (long)-68394728);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)264680178 ^ (long)264680087);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-601803894 ^ (long)-601804025);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1752298375 ^ (long)1752298318);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1395649368 ^ (long)1395649371);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1326516962 ^ (long)1326516746);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-995878392 ^ (long)-995878324);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1923653593 ^ (long)-1923653506);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1783917760 ^ (long)1783917729);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-2117825149 ^ (long)-2117825044);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-2025218939 ^ (long)-2025219054);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)696961589 ^ (long)696961641);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)367943098 ^ (long)367943063);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1709976455 ^ (long)1709976424);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-443860897 ^ (long)-443860794);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1326543176 ^ (long)-1326543299);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1755111012 ^ (long)-1755111063);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1299147809 ^ (long)-1299147946);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)526812675 ^ (long)526812858);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1823797753 ^ (long)1823797609);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)57071639 ^ (long)57071769);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1365619900 ^ (long)1365619905);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1419809193 ^ (long)1419809258);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)530917182 ^ (long)530917129);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1860742960 ^ (long)1860743009);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-859444506 ^ (long)-859444511);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)95776639 ^ (long)95776700);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-721848375 ^ (long)-721848483);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-2043844921 ^ (long)-2043845110);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1147874260 ^ (long)1147874061);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-2146178187 ^ (long)-2146178060);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1680390775 ^ (long)1680390829);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-171432957 ^ (long)-171432920);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)42418520 ^ (long)42418617);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-13778489 ^ (long)-13778455);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1837380027 ^ (long)1837379987);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-817068713 ^ (long)-817068634);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-129657157 ^ (long)-129657343);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1133309797 ^ (long)-1133309740);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1689542067 ^ (long)1689541984);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-195717665 ^ (long)-195717680);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)2136169761 ^ (long)2136169884);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)483281507 ^ (long)483281445);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)363179033 ^ (long)363179213);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-432351512 ^ (long)-432351602);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1885074016 ^ (long)1885074061);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1040064299 ^ (long)-1040064467);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-657660777 ^ (long)-657660705);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1294124886 ^ (long)1294124898);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)51389603 ^ (long)51389678);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1140762794 ^ (long)1140762732);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-659088384 ^ (long)-659088300);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1584267544 ^ (long)1584267616);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1073406408 ^ (long)-1073406374);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1026818622 ^ (long)1026818653);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1484985785 ^ (long)1484985839);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)403736107 ^ (long)403736123);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)673525541 ^ (long)673525739);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1993391857 ^ (long)1993391698);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)767327430 ^ (long)767327345);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1387008109 ^ (long)-1387008111);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1000741089 ^ (long)1000741049);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1948307244 ^ (long)-1948307411);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1204085661 ^ (long)1204085567);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-983254937 ^ (long)-983254821);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1374698569 ^ (long)1374698578);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-383841852 ^ (long)-383841929);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-682329049 ^ (long)-682329042);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)677293502 ^ (long)677293435);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1967068249 ^ (long)1967068350);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1334604275 ^ (long)-1334604055);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-609567576 ^ (long)-609567501);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1581152348 ^ (long)-1581152310);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1804657649 ^ (long)1804657649);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-970401424 ^ (long)-970401486);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1991054262 ^ (long)-1991054241);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1193681925 ^ (long)-1193681948);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1513759712 ^ (long)-1513759536);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-384104034 ^ (long)-384103945);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1337764408 ^ (long)1337764480);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1681224499 ^ (long)-1681224634);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-167754966 ^ (long)-167754969);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1488709739 ^ (long)-1488709801);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-2132918550 ^ (long)-2132918683);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)64435139 ^ (long)64434982);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-79638861 ^ (long)-79638957);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1065889464 ^ (long)-1065889445);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)586058483 ^ (long)586058296);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-833889292 ^ (long)-833889477);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1848939753 ^ (long)1848939626);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-388288429 ^ (long)-388288276);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1160252901 ^ (long)-1160252859);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1128745477 ^ (long)1128745560);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)28821061 ^ (long)28821094);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1881938046 ^ (long)-1881938032);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1498553574 ^ (long)-1498553495);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1165472074 ^ (long)1165472001);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1297683215 ^ (long)-1297683347);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-882232134 ^ (long)-882232300);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1092812774 ^ (long)1092812742);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)264780013 ^ (long)264779943);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)793312069 ^ (long)793312199);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1718622838 ^ (long)1718622737);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1170676557 ^ (long)1170676572);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)179141597 ^ (long)179141553);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)573984573 ^ (long)573984744);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1147867050 ^ (long)-1147866971);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)579363093 ^ (long)579363118);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-551303137 ^ (long)-551302957);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1273772044 ^ (long)-1273772075);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1903620702 ^ (long)1903620846);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1595352035 ^ (long)-1595351939);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-3948938 ^ (long)-3948815);
                    if (!3d.\u200a\u2006\u2009) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-358421395 ^ (long)-358421305);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1068174460 ^ (long)-1068174469)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1526818285 ^ (long)-1526831636)) >>> (int)((long)1548807471 ^ (long)1548807463)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)252305224 ^ (long)252305224);
            if (!3d.\u200a\u2006\u2009) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-422815708 ^ (long)-422815706);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1225270315 ^ (long)-1225270314) | var5_6 << (int)((long)-39317392 ^ (long)-39317387)) ^ var3_4[var7_8]) & (int)((long)-880166325 ^ (long)-880166220);
                    if (3d.\u200a\u2006\u2009) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-653641273 ^ (long)-653641276) | var6_7 << (int)((long)1179931140 ^ (long)1179931137)) ^ var3_4[var7_8]) & (int)((long)486070410 ^ (long)486070389);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3d.b[var2_3] = new String(var3_4).intern();
        }
        return 3d.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean 9(Type type) {
        boolean bl = \u200a\u2006\u2009;
        if (bl || bl) return true;
        if (type instanceof Class) {
            if (bl) return true;
            return Optional.class.isAssignableFrom((Class)type);
        }
        if (bl) return true;
        if (type instanceof ParameterizedType) {
            if (bl) return true;
            if (Optional.class.isAssignableFrom((Class)((ParameterizedType)type).getRawType())) {
                if (bl) return true;
                return (int)((long)1623089424 ^ (long)1623089425) != 0;
            }
        }
        if (!bl) return (int)((long)880084023 ^ (long)880084023) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean 3(3X x2) {
        boolean bl = \u200a\u2006\u2009;
        if (bl || bl) return true;
        if (3d.8()) {
            if (bl || bl) return true;
            k[] kArray = new k[(int)((long)-600022456 ^ (long)-600022455)];
            kArray[(int)((long)1639377145 ^ (long)1639377145)] = k.h;
            k[] kArray2 = kArray;
            5p.9((nr)new 3sC().2((String)new StringBuilder().append((String)x2.2()).append((String)3d.a((int)((int)((long)-272657159 ^ (long)272653889)), (int)((int)((long)1460152966 ^ (long)-1460151875)))).toString(), null, (k[])kArray2).7);
            if (bl || bl) return true;
            x2.1((boolean)((long)695362033 ^ (long)695362033));
            if (bl || bl) return true;
            return (int)((long)936084 ^ (long)936085) != 0;
        }
        if (!bl) return (int)((long)-1322312609 ^ (long)-1322312609) != 0;
        return true;
    }
}

