/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  org.apache.logging.log4j.Level
 */
package net.impactclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.impactclient.2w$6X;
import net.impactclient.3e;
import net.impactclient.3si;
import net.impactclient.3sp;
import net.impactclient.4d;
import net.impactclient.5z;
import net.impactclient.8m;
import net.impactclient.9Z;
import org.apache.logging.log4j.Level;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 5A
implements 3sp {
    private static final String[] a;
    public final 8m 2;
    private static final String[] b;
    public static final boolean \u2009\u2007\u2005;
    public final List<String> 1;
    public boolean 9;

    /*
     * Enabled aggressive block sorting
     */
    public final JsonObject 7() {
        JsonObject jsonObject;
        block7: {
            block6: {
                boolean bl = \u2009\u2007\u2005;
                if (bl) break block6;
                String[] stringArray = 3e.5();
                jsonObject = new JsonObject();
                jsonObject.addProperty(5A.a((int)((long)-1917805484 ^ (long)1917792942), (int)((long)848054595 ^ (long)848048191)) /* "key" */, 3si.6(this.2.3));
                String[] stringArray2 = stringArray;
                if (bl || bl) break block6;
                switch (this.1.size()) {
                    case 0: {
                        if (bl) break block6;
                        if (stringArray2 == null) break;
                        if (bl) break block6;
                    }
                    case 1: {
                        if (bl) break block6;
                        jsonObject.addProperty(5A.a((int)((long)433214573 ^ (long)-433194348), (int)((long)1602909359 ^ (long)1602891337)), this.1.get((int)((long)-1365107539 ^ (long)-1365107539)));
                        if (bl || bl) break block6;
                        if (stringArray2 == null) break;
                        if (bl) break block6;
                    }
                    default: {
                        if (bl) break block6;
                        JsonArray jsonArray = new JsonArray();
                        if (bl || bl) break block6;
                        this.1.forEach(arg_0 -> ((JsonArray)jsonArray).add(arg_0));
                        if (bl || bl) break block6;
                        jsonObject.add(5A.a((int)((long)398505563 ^ (long)-398518110), (int)((long)221581709 ^ (long)221596523)), (JsonElement)jsonArray);
                        if (bl) break block6;
                    }
                }
                if (!bl) break block7;
            }
            return null;
        }
        return jsonObject;
    }

    /*
     * Enabled aggressive block sorting
     */
    public 5A(int n, List<String> list) {
        block3: {
            block2: {
                boolean bl = \u2009\u2007\u2005;
                if (bl || bl) break block2;
                this.2 = new 8m(9Z.a, n, object -> {
                    block4: {
                        block2: {
                            boolean bl;
                            block3: {
                                bl = \u2009\u2007\u2005;
                                if (bl || bl) break block2;
                                if (object != 4d.a) break block3;
                                if (bl) break block2;
                                5A a2 = this;
                                if (a2.9) break block3;
                                if (bl || bl) break block2;
                                if (5A.3.s == null) break block3;
                                if (bl || bl) break block2;
                                a2.1.forEach(string -> {
                                    block3: {
                                        block2: {
                                            boolean bl = \u2009\u2007\u2005;
                                            if (bl || bl) break block2;
                                            5A.3.s.f(string);
                                            if (!bl) break block3;
                                        }
                                        return;
                                    }
                                });
                                if (bl) break block2;
                            }
                            if (!bl) break block4;
                        }
                        return;
                    }
                });
                if (bl || bl) break block2;
                this.1 = list;
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 5A.\u2009\u2007\u2005;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-1054749100 ^ (long)-1054749103)];
            if (var7) break block23;
            var3_2 = (int)((long)970308223 ^ (long)970308223);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u1f2d\u37d6\u2442\u2cfe\u1f42\u3778\u240e\u2c65\u1fe6\u37ed\u2416\u2c3b\u1ffc\u378d\u2444\u2cf9\u1fac\u37e4\u2428\u2cfc\u1fff\u3748\u24d1\u2c59\u1fe1\u37d9\u2463\u2c5b\u1fc5\u374e\u2431\u2c56\u1fc5\u37cb\u249e\u2c58\u1f32\u3782\u24ed\u2ca9\u1fee\u37e0\u24dd\u2cba\u1ffe\u37b2\u246c\u2cb2\u1fbd\u378f\u245c\u2c56\u1f45\u3763\u246b\u2c14\u1fef\u37a5", 1612069332);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)252650319 ^ (long)252650314);
            if (var7) break block23;
            var0_6 = (int)((long)2129285384 ^ (long)-2129285385);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1827031843 ^ (long)1827031862);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)797048608 ^ (long)-797048609);
                    if (5A.\u2009\u2007\u2005) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!5A.\u2009\u2007\u2005) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u54c9\u7cab\u6fe5\u67ea\u5417\u7cdf\u6f3e", -525700568);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)973088403 ^ (long)973088400);
                            var0_6 = (int)((long)247376056 ^ (long)-247376057);
                            while (true) {
                                v0 = (int)((long)-1997684139 ^ (long)-1997684156);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-2062587170 ^ (long)-2062587170);
                                if (!5A.\u2009\u2007\u2005) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!5A.\u2009\u2007\u2005) ** continue;
                                throw null;
                            }
                            5A.a = var5_1;
                            5A.b = new String[(int)((long)-327068925 ^ (long)-327068922)];
                            if (!5A.\u2009\u2007\u2005) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1841234221 ^ (long)-1841234221);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)254570081 ^ (long)254570080)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1528197353 ^ (long)-1528197360)) {
                                case 0: {
                                    v15 = (int)((long)1149100925 ^ (long)1149100823);
                                    if (!5A.\u2009\u2007\u2005) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-265791429 ^ (long)-265791421);
                                    if (!5A.\u2009\u2007\u2005) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1946838504 ^ (long)-1946838458);
                                    if (!5A.\u2009\u2007\u2005) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1763385920 ^ (long)-1763385895);
                                    if (!5A.\u2009\u2007\u2005) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)630591228 ^ (long)630591178);
                                    if (!5A.\u2009\u2007\u2005) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1904436991 ^ (long)-1904436941);
                                    if (!5A.\u2009\u2007\u2005) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1591298427 ^ (long)-1591298319);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!5A.\u2009\u2007\u2005);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Optional<5A> 0(JsonObject jsonObject) {
        boolean bl = \u2009\u2007\u2005;
        if (bl) return null;
        String[] stringArray = 3e.5();
        if (bl) return null;
        try {
            ArrayList<String> arrayList;
            int n;
            block6: {
                block5: {
                    if (bl) return null;
                    n = 3si.9(jsonObject.get(5A.a((int)((long)731515747 ^ (long)-731535970), (int)((long)1820182924 ^ (long)-1820164137))).getAsString());
                    if (bl || bl) return null;
                    arrayList = new ArrayList<String>();
                    if (bl || bl) return null;
                    if (!(jsonObject = jsonObject.get(5A.a((int)((long)725863339 ^ (long)-725850797), (int)((long)-1212206778 ^ (long)1212198363)) /* "macro" */)).isJsonArray()) break block5;
                    if (bl) return null;
                    jsonObject.getAsJsonArray().forEach(jsonElement -> {
                        block3: {
                            block2: {
                                boolean bl = \u2009\u2007\u2005;
                                if (bl || bl) break block2;
                                arrayList.add(jsonElement.getAsString());
                                if (!bl) break block3;
                            }
                            return;
                        }
                    });
                    if (bl) return null;
                    if (stringArray == null) break block6;
                    if (bl) return null;
                }
                if (bl) return null;
                arrayList.add(jsonObject.getAsString());
                if (bl) return null;
            }
            if (bl) return null;
            return Optional.of(new 5A(n, arrayList));
        }
        catch (Exception exception) {
            if (bl || bl) return null;
            5z.9.log(Level.ERROR, 5A.a((int)((long)415212796 ^ (long)-415233529), (int)((long)-894895759 ^ (long)-894904709)) /* "Error deserializing Macro object from json: {}" */, (Object)exception.getLocalizedMessage());
            if (bl || bl) return null;
            return Optional.empty();
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 5A.\u2009\u2007\u2005;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1912361548 ^ (long)1912341325)) & (int)((long)319680791 ^ (long)319622888);
            if (var9_2) ** GOTO lbl-1000
            if (5A.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 5A.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1277815777 ^ (long)-1277815777)] & (int)((long)-392710116 ^ (long)-392709917)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)966174228 ^ (long)966174286);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-318591727 ^ (long)-318591632);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1379252413 ^ (long)1379252349);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1650132010 ^ (long)-1650131996);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1252556372 ^ (long)1252556529);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)63576095 ^ (long)63576278);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1240511231 ^ (long)-1240511146);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1487774139 ^ (long)-1487774160);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1640630320 ^ (long)-1640630321);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)825606723 ^ (long)825606682);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1355120 ^ (long)1355194);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-925719103 ^ (long)-925719263);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-534746939 ^ (long)-534747133);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1439025254 ^ (long)1439025221);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)2017767291 ^ (long)2017767219);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)2033968748 ^ (long)2033968867);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)302953090 ^ (long)302953122);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)997634801 ^ (long)997634658);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-979288940 ^ (long)-979288958);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)995613884 ^ (long)995613878);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-764205308 ^ (long)-764205121);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)337127367 ^ (long)337127271);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-2019837215 ^ (long)-2019837213);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)110623943 ^ (long)110623767);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1526116871 ^ (long)1526117064);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1388257509 ^ (long)1388257490);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1178246976 ^ (long)-1178247091);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1697323471 ^ (long)1697323398);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1302820362 ^ (long)1302820492);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-252780782 ^ (long)-252780678);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-2127470521 ^ (long)-2127470458);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1501063460 ^ (long)1501063666);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1386562536 ^ (long)1386562308);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1528701365 ^ (long)-1528701216);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)12368872 ^ (long)12368682);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)640505922 ^ (long)640505915);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)65386139 ^ (long)65386095);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)370434295 ^ (long)370434137);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1868030152 ^ (long)1868030057);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-2008041420 ^ (long)-2008041447);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1263193886 ^ (long)1263193916);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1127085469 ^ (long)-1127085340);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1268295337 ^ (long)-1268295348);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1490450943 ^ (long)-1490450907);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1369300768 ^ (long)-1369300822);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)736860619 ^ (long)736860554);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)671693686 ^ (long)671693618);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1576300775 ^ (long)-1576300644);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-151325795 ^ (long)-151325721);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)584818771 ^ (long)584818754);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1009312314 ^ (long)-1009312467);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-28167538 ^ (long)-28167490);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1541970583 ^ (long)-1541970507);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1773590148 ^ (long)-1773590270);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1900330787 ^ (long)1900330804);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)231304987 ^ (long)231305052);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)758655821 ^ (long)758655991);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)939256677 ^ (long)939256665);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1120807671 ^ (long)-1120807432);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-120877709 ^ (long)-120877663);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-508667799 ^ (long)-508667793);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-553973978 ^ (long)-553973925);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)200123934 ^ (long)200124050);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1271456083 ^ (long)-1271456192);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1584349483 ^ (long)1584349461);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)918073578 ^ (long)918073490);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)363618193 ^ (long)363618242);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1037707425 ^ (long)1037707362);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1756871237 ^ (long)-1756871258);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1808844822 ^ (long)1808844918);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)61544963 ^ (long)61545204);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-700166614 ^ (long)-700166655);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-571663421 ^ (long)-571663364);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1177243655 ^ (long)1177243859);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1939141766 ^ (long)-1939141648);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-39782031 ^ (long)-39782111);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-747680588 ^ (long)-747680547);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)2132511623 ^ (long)2132511639);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)9032831 ^ (long)9032939);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1075893047 ^ (long)1075893224);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1966122020 ^ (long)-1966122223);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1290502739 ^ (long)-1290502688);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1919150061 ^ (long)-1919149943);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1894511361 ^ (long)1894511459);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)627817609 ^ (long)627817585);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)511444239 ^ (long)511444479);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1462789285 ^ (long)-1462789259);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)916553798 ^ (long)916553824);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)499519039 ^ (long)499519132);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-47043200 ^ (long)-47043206);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)786787461 ^ (long)786787385);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1106687873 ^ (long)-1106687781);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-815701503 ^ (long)-815701299);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1634028857 ^ (long)1634028890);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-773317803 ^ (long)-773317658);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-337021226 ^ (long)-337021365);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1542267737 ^ (long)-1542267783);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1270093128 ^ (long)-1270093258);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)815918775 ^ (long)815918778);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)843843267 ^ (long)843843195);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-768221501 ^ (long)-768221528);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1777137976 ^ (long)1777138071);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-537273276 ^ (long)-537273328);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)796069244 ^ (long)796069203);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)888340900 ^ (long)888340895);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-2111606706 ^ (long)-2111606603);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)928157843 ^ (long)928157893);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)601441243 ^ (long)601441085);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-239357995 ^ (long)-239358042);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-313412829 ^ (long)-313412614);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)758377039 ^ (long)758376969);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-267493252 ^ (long)-267493128);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-267194316 ^ (long)-267194349);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1881471971 ^ (long)1881471848);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-256549317 ^ (long)-256549175);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-468809979 ^ (long)-468809800);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-727198876 ^ (long)-727198858);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)634760613 ^ (long)634760593);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)587404174 ^ (long)587404087);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)322219720 ^ (long)322219695);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1451587921 ^ (long)1451587972);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1782555888 ^ (long)-1782555846);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1697169030 ^ (long)-1697169004);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)777976452 ^ (long)777976332);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1935626308 ^ (long)-1935626412);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)117799953 ^ (long)117800173);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)649883850 ^ (long)649883859);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-847529206 ^ (long)-847529099);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-2138241061 ^ (long)-2138241132);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1807489430 ^ (long)1807489314);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1231399805 ^ (long)-1231399785);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-2127997607 ^ (long)-2127997636);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-2068891791 ^ (long)-2068891712);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1139701145 ^ (long)1139701007);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1249071715 ^ (long)1249071701);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)605222627 ^ (long)605222473);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-134860028 ^ (long)-134859782);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-314527679 ^ (long)-314527612);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1895344205 ^ (long)1895344197);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1331402517 ^ (long)-1331402583);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)245562215 ^ (long)245562258);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)2018948644 ^ (long)2018948680);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1276252534 ^ (long)-1276252535);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)546814791 ^ (long)546814727);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)621639641 ^ (long)621639652);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1118569561 ^ (long)-1118569713);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)2093061695 ^ (long)2093061731);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-946652450 ^ (long)-946652478);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-2131090222 ^ (long)-2131090205);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)503320782 ^ (long)503320656);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)134337706 ^ (long)134337600);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-217672201 ^ (long)-217672243);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-488560916 ^ (long)-488561042);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1936178630 ^ (long)-1936178518);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)579217217 ^ (long)579217220);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)616738020 ^ (long)616737883);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-825170895 ^ (long)-825170859);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1806391375 ^ (long)-1806391313);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-532640660 ^ (long)-532640667);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)587209356 ^ (long)587209291);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)2106820408 ^ (long)2106820604);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-542289996 ^ (long)-542290073);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1115292022 ^ (long)-1115292041);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-234105709 ^ (long)-234105625);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)759745683 ^ (long)759745637);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1701951481 ^ (long)-1701951318);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)389575137 ^ (long)389574954);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1414504080 ^ (long)1414503952);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-137249017 ^ (long)-137248892);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)650361267 ^ (long)650361285);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)856918028 ^ (long)856918069);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)458557736 ^ (long)458557757);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1306432276 ^ (long)-1306432361);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)751637944 ^ (long)751637948);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1282427310 ^ (long)1282427353);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1325843158 ^ (long)1325843083);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1149947415 ^ (long)1149947632);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1031371646 ^ (long)-1031371728);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)203927981 ^ (long)203927892);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-63965114 ^ (long)-63965155);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-2022269976 ^ (long)-2022270086);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1312827631 ^ (long)-1312827570);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)409288348 ^ (long)409288398);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1339244011 ^ (long)1339243902);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)785795720 ^ (long)785795687);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)31255998 ^ (long)31255842);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-388046205 ^ (long)-388046289);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1550605575 ^ (long)1550605789);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-980155811 ^ (long)-980155885);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)830033187 ^ (long)830033344);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-321597167 ^ (long)-321597169);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-177223720 ^ (long)-177223725);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-324746998 ^ (long)-324746869);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-961455351 ^ (long)-961455352);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1068999738 ^ (long)-1068999750);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1067101344 ^ (long)1067101191);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1160708903 ^ (long)-1160708895);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1981845521 ^ (long)1981845640);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1306181341 ^ (long)1306181186);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-321037765 ^ (long)-321037738);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)925494647 ^ (long)925494782);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1472733858 ^ (long)1472733760);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)202237864 ^ (long)202237787);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-691273953 ^ (long)-691273906);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1642934314 ^ (long)1642934513);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)741448333 ^ (long)741448218);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1296526418 ^ (long)-1296526585);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)765517013 ^ (long)765517019);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-554868437 ^ (long)-554868278);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1506297281 ^ (long)-1506297296);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1294445584 ^ (long)-1294445804);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1528716152 ^ (long)1528716139);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1288029202 ^ (long)1288029360);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1029816256 ^ (long)1029816181);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1981046395 ^ (long)-1981046475);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-127911544 ^ (long)-127911661);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)2053264236 ^ (long)2053264169);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-346139452 ^ (long)-346139467);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-2110219962 ^ (long)-2110219917);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)290379854 ^ (long)290379929);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1361608019 ^ (long)-1361608059);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)827540388 ^ (long)827540365);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)373591502 ^ (long)373591417);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1983015890 ^ (long)-1983015844);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)543010578 ^ (long)543010807);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1734491107 ^ (long)1734491087);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1525914008 ^ (long)-1525914105);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1424421632 ^ (long)1424421665);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1794243807 ^ (long)1794243759);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-492665703 ^ (long)-492665744);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1473103049 ^ (long)-1473102938);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1840484891 ^ (long)-1840485059);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)863956848 ^ (long)863956762);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1694111282 ^ (long)1694111358);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-818008253 ^ (long)-818008132);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)452004887 ^ (long)452004930);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)886190175 ^ (long)886190231);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1434316196 ^ (long)-1434316054);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1618477738 ^ (long)1618477810);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1862975435 ^ (long)-1862975349);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1904739977 ^ (long)-1904739887);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1408650309 ^ (long)-1408650390);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1279446600 ^ (long)-1279446666);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1922871098 ^ (long)1922871161);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1858744308 ^ (long)-1858744279);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-728789707 ^ (long)-728789528);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-941926070 ^ (long)-941926064);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-823179548 ^ (long)-823179549);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-627198501 ^ (long)-627198505);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1185040079 ^ (long)1185040033);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1110104618 ^ (long)1110104601);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1443622542 ^ (long)-1443622422);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-819726568 ^ (long)-819726568);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)395758943 ^ (long)395758868);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)2024616517 ^ (long)2024616541);
                    if (!5A.\u2009\u2007\u2005) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-325270725 ^ (long)-325270691);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1914987355 ^ (long)-1914987430)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1555074629 ^ (long)1555067322)) >>> (int)((long)-1588109543 ^ (long)-1588109551)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1322224898 ^ (long)-1322224898);
            if (!5A.\u2009\u2007\u2005) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-126088828 ^ (long)-126088826);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1440461763 ^ (long)-1440461762) | var5_6 << (int)((long)-1802357087 ^ (long)-1802357084)) ^ var3_4[var7_8]) & (int)((long)-2092170821 ^ (long)-2092170940);
                    if (5A.\u2009\u2007\u2005) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-961495153 ^ (long)-961495156) | var6_7 << (int)((long)868002249 ^ (long)868002252)) ^ var3_4[var7_8]) & (int)((long)-1608323924 ^ (long)-1608324013);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            5A.b[var2_3] = new String(var3_4).intern();
        }
        return 5A.b[var2_3];
    }
}

