/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  me.zero.alpine.listener.Listenable
 *  org.apache.logging.log4j.Level
 */
package net.impactclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Objects;
import me.zero.alpine.listener.Listenable;
import net.impactclient.2u;
import net.impactclient.2w$6X;
import net.impactclient.3A;
import net.impactclient.5A;
import net.impactclient.5z;
import net.impactclient.93;
import org.apache.logging.log4j.Level;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 2Z
extends 2u<5A>
implements Listenable {
    private static final String[] b;
    private static final String[] a;
    private final Path 6;
    public static final boolean \u2009;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 2Z.\u2009;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)2102862121 ^ (long)2102870116)) & (int)((long)552891262 ^ (long)552897665);
            if (var9_2) ** GOTO lbl-1000
            if (2Z.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 2Z.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-837536875 ^ (long)-837536875)] & (int)((long)-1383492570 ^ (long)-1383492391)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1541832014 ^ (long)1541832126);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-2062769364 ^ (long)-2062769225);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1246474221 ^ (long)1246474022);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-536867056 ^ (long)-536866890);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)236041735 ^ (long)236041852);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1528917334 ^ (long)1528917331);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)100588064 ^ (long)100588070);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)931446981 ^ (long)931446989);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1288158398 ^ (long)-1288158215);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1279556201 ^ (long)1279556117);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)664538663 ^ (long)664538853);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)2037988351 ^ (long)2037988310);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-863163260 ^ (long)-863163141);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1637869243 ^ (long)1637869292);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1119081642 ^ (long)-1119081651);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)511808987 ^ (long)511808849);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1473997255 ^ (long)1473997212);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)280565347 ^ (long)280565327);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1873230029 ^ (long)-1873229858);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)995523304 ^ (long)995523301);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1673143098 ^ (long)-1673143078);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)255091721 ^ (long)255091934);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)904980667 ^ (long)904980664);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)978599389 ^ (long)978599252);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)2120799124 ^ (long)2120799110);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)132223599 ^ (long)132223742);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-28055442 ^ (long)-28055470);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1949230980 ^ (long)-1949230960);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1543247799 ^ (long)-1543247784);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-745430875 ^ (long)-745431022);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1210224787 ^ (long)-1210224723);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1162365263 ^ (long)1162365405);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-158439026 ^ (long)-158439065);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)590663127 ^ (long)590662914);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)222016836 ^ (long)222016776);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)2048025451 ^ (long)2048025449);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)369900212 ^ (long)369900245);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-14254000 ^ (long)-14253844);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1016589219 ^ (long)-1016589057);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1687225195 ^ (long)1687225301);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-755859277 ^ (long)-755859418);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)73887820 ^ (long)73887946);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)210037875 ^ (long)210037814);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-489344080 ^ (long)-489344204);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-767848872 ^ (long)-767848865);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-22369184 ^ (long)-22369194);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1842270517 ^ (long)-1842270645);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1328387646 ^ (long)-1328387589);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1561302581 ^ (long)1561302779);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)398140173 ^ (long)398140199);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)57352316 ^ (long)57352344);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)2136151858 ^ (long)2136151815);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1963715447 ^ (long)-1963715365);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1209972475 ^ (long)1209972353);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-6336716 ^ (long)-6336613);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1891407021 ^ (long)1891407035);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)222635390 ^ (long)222635287);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)419856028 ^ (long)419856044);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-28737694 ^ (long)-28737553);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-448524420 ^ (long)-448524465);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1260283588 ^ (long)-1260283424);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1878355016 ^ (long)1878355091);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1700855961 ^ (long)1700855812);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1383982628 ^ (long)1383982762);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)2131805076 ^ (long)2131804930);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1284765446 ^ (long)1284765611);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1321332870 ^ (long)-1321332807);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)57021487 ^ (long)57021503);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1221790867 ^ (long)-1221790774);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1278428928 ^ (long)-1278428717);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1486990125 ^ (long)-1486990104);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1080292735 ^ (long)-1080292753);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-934224877 ^ (long)-934224756);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1636977503 ^ (long)1636977473);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-146709643 ^ (long)-146709699);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1612240549 ^ (long)1612240415);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1344370184 ^ (long)-1344370241);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1212379493 ^ (long)1212379620);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1066755364 ^ (long)1066755543);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1253701321 ^ (long)1253701140);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1753561283 ^ (long)1753561308);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-259745266 ^ (long)-259745200);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-2086109558 ^ (long)-2086109539);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1934178245 ^ (long)-1934178061);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)265734045 ^ (long)265734096);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-885806639 ^ (long)-885806791);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1993846739 ^ (long)-1993846691);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1144717305 ^ (long)1144717131);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1532108437 ^ (long)1532108486);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)2118282463 ^ (long)2118282300);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1603624785 ^ (long)1603624717);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1310133368 ^ (long)-1310133436);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-658413440 ^ (long)-658413563);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)614111669 ^ (long)614111692);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1850255472 ^ (long)-1850255560);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-974500250 ^ (long)-974500225);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1838824523 ^ (long)1838824449);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-2061129062 ^ (long)-2061129091);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-509192756 ^ (long)-509192862);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-769414652 ^ (long)-769414628);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1995868462 ^ (long)-1995868630);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-644497609 ^ (long)-644497643);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1063096352 ^ (long)-1063096481);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)2037363917 ^ (long)2037363775);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1868247252 ^ (long)1868247167);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)2118939864 ^ (long)2118939694);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)590774184 ^ (long)590774216);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)230664389 ^ (long)230664370);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1151216504 ^ (long)-1151216465);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1695825391 ^ (long)1695825280);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1362900717 ^ (long)-1362900488);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-156660854 ^ (long)-156660933);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)696638831 ^ (long)696638827);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-176136755 ^ (long)-176136764);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1358406341 ^ (long)1358406237);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1197365239 ^ (long)1197365180);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1753625481 ^ (long)1753625420);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1306401093 ^ (long)-1306401075);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1861882427 ^ (long)1861882456);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-997015581 ^ (long)-997015610);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)2057174398 ^ (long)2057174474);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)755411489 ^ (long)755411575);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1866267441 ^ (long)-1866267521);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-799574934 ^ (long)-799574998);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1546545236 ^ (long)1546545334);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)939056547 ^ (long)939056410);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)896142343 ^ (long)896142418);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-360233269 ^ (long)-360233352);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-911889506 ^ (long)-911889603);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-170437848 ^ (long)-170437838);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)478919753 ^ (long)478919695);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-680882668 ^ (long)-680882557);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)141572653 ^ (long)141572748);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-634131707 ^ (long)-634131674);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1240618102 ^ (long)-1240618015);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)479907659 ^ (long)479907603);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1903990344 ^ (long)-1903990305);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)389050202 ^ (long)389050325);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1462416487 ^ (long)-1462416536);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1224204043 ^ (long)1224204105);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-603129128 ^ (long)-603129193);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1516772253 ^ (long)1516772345);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1626237467 ^ (long)1626237482);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-462953328 ^ (long)-462953282);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)97601919 ^ (long)97601857);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1730705022 ^ (long)1730704931);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-2076855347 ^ (long)-2076855497);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1041062983 ^ (long)1041063091);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1008773286 ^ (long)-1008773232);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1849105121 ^ (long)-1849105132);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-171116210 ^ (long)-171116229);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)367985989 ^ (long)367986067);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1391111348 ^ (long)1391111396);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1632093559 ^ (long)-1632093452);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1252037945 ^ (long)1252037960);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-852999830 ^ (long)-852999834);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1166561029 ^ (long)-1166561260);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1580632257 ^ (long)-1580632107);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1279858160 ^ (long)-1279858059);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)839442644 ^ (long)839442592);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-528792188 ^ (long)-528792290);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-678611529 ^ (long)-678611603);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-583403814 ^ (long)-583403825);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-70513853 ^ (long)-70513702);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)673121711 ^ (long)673121539);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)970365911 ^ (long)970365923);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1481168834 ^ (long)-1481168677);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-419137315 ^ (long)-419137416);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)395768822 ^ (long)395768615);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)146775311 ^ (long)146775310);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1234740091 ^ (long)-1234740086);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)956542872 ^ (long)956542962);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-755116170 ^ (long)-755116137);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-631675255 ^ (long)-631675142);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-2087549393 ^ (long)-2087549261);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-2111550978 ^ (long)-2111551221);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1262859169 ^ (long)-1262859038);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-950080262 ^ (long)-950080505);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1942100846 ^ (long)-1942100917);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1362003404 ^ (long)-1362003442);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1543154484 ^ (long)-1543154461);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-473682410 ^ (long)-473682215);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1384519365 ^ (long)-1384519395);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)846942068 ^ (long)846942146);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)238468065 ^ (long)238467893);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)2135156932 ^ (long)2135156951);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1239872950 ^ (long)1239872968);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-351558176 ^ (long)-351558223);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1738126061 ^ (long)1738125887);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1863302441 ^ (long)-1863302634);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-648971902 ^ (long)-648971841);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)392827908 ^ (long)392827941);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-874238997 ^ (long)-874239128);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1555439033 ^ (long)-1555439062);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1210986615 ^ (long)1210986586);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1755537626 ^ (long)1755537637);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-747471629 ^ (long)-747471623);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)905958624 ^ (long)905958515);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1657890072 ^ (long)1657890236);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-435845942 ^ (long)-435846054);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)311110247 ^ (long)311110180);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1780105679 ^ (long)1780105553);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1467044133 ^ (long)-1467044323);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-554484074 ^ (long)-554483974);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1348734368 ^ (long)-1348734407);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-500638732 ^ (long)-500638849);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1122152414 ^ (long)1122152422);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1808570972 ^ (long)1808570901);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)642305261 ^ (long)642305261);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-344886218 ^ (long)-344886229);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)228814847 ^ (long)228814797);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1909452378 ^ (long)1909452531);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)2108249324 ^ (long)2108249288);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)841648887 ^ (long)841648819);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1797724354 ^ (long)1797724282);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1646742963 ^ (long)1646743015);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1408294577 ^ (long)-1408294601);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1947940262 ^ (long)-1947940112);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1485721871 ^ (long)1485722056);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1507610440 ^ (long)1507610410);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1969728390 ^ (long)1969728422);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1816782473 ^ (long)-1816782337);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-875963916 ^ (long)-875963986);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1004584503 ^ (long)1004584651);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-2114395172 ^ (long)-2114395301);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)214284372 ^ (long)214284348);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-384440809 ^ (long)-384440807);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)612394110 ^ (long)612394070);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)44246309 ^ (long)44246517);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)445258727 ^ (long)445258526);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)667227451 ^ (long)667227439);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1473287666 ^ (long)1473287552);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-503131213 ^ (long)-503131284);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1016775558 ^ (long)-1016775603);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-121968175 ^ (long)-121968329);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1264199061 ^ (long)1264199131);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1019723802 ^ (long)-1019723918);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-333363658 ^ (long)-333363461);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)264555448 ^ (long)264555486);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-539830585 ^ (long)-539830736);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1608532011 ^ (long)1608532137);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)630027187 ^ (long)630027084);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1764241641 ^ (long)-1764241457);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1810289661 ^ (long)1810289480);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1166954433 ^ (long)-1166954400);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1785568092 ^ (long)-1785568166);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1498005181 ^ (long)-1498005021);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1975193897 ^ (long)1975194093);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1153841377 ^ (long)-1153841261);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-113912721 ^ (long)-113912689);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)240507413 ^ (long)240507515);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)791026713 ^ (long)791026738);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)149199205 ^ (long)149199140);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)780026068 ^ (long)780025903);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)586777288 ^ (long)586777089);
                    if (!2Z.\u2009) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1797242016 ^ (long)-1797241922);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)203977804 ^ (long)203977907)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)240418956 ^ (long)240418675)) >>> (int)((long)-1422158471 ^ (long)-1422158479)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1238773590 ^ (long)1238773590);
            if (!2Z.\u2009) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)2137429255 ^ (long)2137429253);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)839733481 ^ (long)839733482) | var5_6 << (int)((long)581441968 ^ (long)581441973)) ^ var3_4[var7_8]) & (int)((long)-844319538 ^ (long)-844319695);
                    if (2Z.\u2009) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1264056906 ^ (long)1264056905) | var6_7 << (int)((long)-485015025 ^ (long)-485015030)) ^ var3_4[var7_8]) & (int)((long)-578740716 ^ (long)-578740501);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            2Z.b[var2_3] = new String(var3_4).intern();
        }
        return 2Z.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 6() {
        block3: {
            block2: {
                boolean bl = \u2009;
                if (bl || bl) break block2;
                JsonArray jsonArray = new JsonArray();
                if (bl || bl) break block2;
                this.stream().map(5A::7).filter(Objects::nonNull).forEach(arg_0 -> ((JsonArray)jsonArray).add(arg_0));
                if (bl || bl) break block2;
                93.5((JsonElement)jsonArray, this.6);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    public 2Z() {
        boolean bl = \u2009;
        super(2Z.a((int)((long)466996414 ^ (long)466988530), (int)((long)248242725 ^ (long)248241053)) /* "Macro" */);
        5z.4();
        this.6 = 5z.1(2Z.a((int)((long)-1225515080 ^ (long)-1225490699), (int)((long)-1847759366 ^ (long)1847784384)) /* "macros.json" */);
        3A.6.subscribe(this);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 2Z.\u2009;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1393912177 ^ (long)1393912181)];
            if (var7) break block23;
            var3_2 = (int)((long)2003264219 ^ (long)2003264219);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u2665\u0ecc\u1d8d\u1571\u2674\u0e19\u1d5d\u1509\u263e\u0e5d\u1db0\u1551\u26ed\u0e57\u1db8\u1502\u26d2", -1247805291);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)790152949 ^ (long)790152958);
            if (var7) break block23;
            var0_6 = (int)((long)1705759560 ^ (long)-1705759561);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1982075191 ^ (long)-1982075168);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-433790365 ^ (long)433790364);
                    if (2Z.\u2009) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!2Z.\u2009) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\uc50e\uede9\ufebd\uf64b\uc553\ued3a\ufeb4\uf6c7\uc5b0\ued76\ufe9c\uf696\uc5b8\ued9d\ufe94\uf68d\uc530\uedc0\ufef9\uf605\uc56a\ued40\ufe18\uf63f\uc53b\ued8a\ufe6c\uf690\uc5ed\uedff\ufe1d\uf6cd\uc51b\ued9a\ufe46\uf6a4\uc588\ued23\ufe1f\uf6ff\uc56c\ued55\ufe25\uf679\uc5ab\ued7d\ufe58\uf650\uc5b2\ued7a\ufeb7\uf638\uc5d3\uede5\ufe4c\uf6e8\uc533\ued7b", -538123517);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)2068579173 ^ (long)2068579196);
                            var0_6 = (int)((long)-2015023028 ^ (long)2015023027);
                            while (true) {
                                v0 = (int)((long)1129155258 ^ (long)1129155251);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1098096604 ^ (long)1098096604);
                                if (!2Z.\u2009) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!2Z.\u2009) ** continue;
                                throw null;
                            }
                            2Z.a = var5_1;
                            2Z.b = new String[(int)((long)-1828140219 ^ (long)-1828140223)];
                            if (!2Z.\u2009) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1473783573 ^ (long)1473783573);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1935535769 ^ (long)1935535768)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1153372887 ^ (long)1153372880)) {
                                case 0: {
                                    v15 = (int)((long)-1622372401 ^ (long)-1622372480);
                                    if (!2Z.\u2009) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1819412602 ^ (long)-1819412499);
                                    if (!2Z.\u2009) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-675142249 ^ (long)-675142160);
                                    if (!2Z.\u2009) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)567187499 ^ (long)567187534);
                                    if (!2Z.\u2009) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1576711827 ^ (long)-1576711891);
                                    if (!2Z.\u2009) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1395327396 ^ (long)-1395327438);
                                    if (!2Z.\u2009) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1183607221 ^ (long)1183607246);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!2Z.\u2009);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void 0() {
        JsonElement jsonElement2;
        boolean bl = \u2009;
        if (bl) return;
        try {
            if (bl) return;
            jsonElement2 = 93.0(Files.newBufferedReader(this.6));
            if (!jsonElement2.isJsonArray()) {
                if (bl || bl) return;
                throw new Exception(2Z.a((int)((long)1288139578 ^ (long)1288114804), (int)((long)1935380118 ^ (long)1935396438)) /* "Macros file is in invalid format" */);
            }
        }
        catch (FileNotFoundException fileNotFoundException) {
            if (bl || bl) return;
            return;
        }
        catch (Throwable throwable) {
            if (bl || bl) return;
            5z.9.log(Level.FATAL, 2Z.a((int)((long)-1268994859 ^ (long)-1268986470), (int)((long)2088123355 ^ (long)2088136797)) /* "Unable to load macros: {}" */, (Object)throwable.getMessage());
            if (bl || bl) return;
            return;
        }
        {
            if (bl) return;
            this.clear();
            if (bl || bl) return;
            jsonElement2.getAsJsonArray().forEach(jsonElement -> {
                block4: {
                    block2: {
                        boolean bl;
                        block3: {
                            bl = \u2009;
                            if (bl || bl) break block2;
                            if (!jsonElement.isJsonObject()) break block3;
                            if (bl || bl) break block2;
                            5A.0(jsonElement.getAsJsonObject()).ifPresent(this::add);
                            if (bl) break block2;
                        }
                        if (!bl) break block4;
                    }
                    return;
                }
            });
            if (bl || bl) return;
            return;
        }
    }
}

