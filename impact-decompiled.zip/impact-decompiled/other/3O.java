/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aft
 *  ddl
 *  ddm
 *  ddn
 *  ddp
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listenable
 *  me.zero.alpine.listener.Listener
 *  nr
 *  oe
 */
package net.impactclient;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listenable;
import me.zero.alpine.listener.Listener;
import net.impactclient.2d;
import net.impactclient.2t;
import net.impactclient.2w$6X;
import net.impactclient.3e;
import net.impactclient.3sg;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3O
implements Listenable {
    private static final Pattern 1;
    private static final String[] a;
    private static final String[] b;
    private final Map<3sg, Integer> 5;
    @EventHandler
    private final Listener<2t> 3;
    public static final boolean \u2003\u200c;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 3O.\u2003\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1437625392 ^ (long)-1437604992)) & (int)((long)-1684268557 ^ (long)-1684216308);
            if (var9_2) ** GOTO lbl-1000
            if (3O.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3O.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)917563268 ^ (long)917563268)] & (int)((long)528457279 ^ (long)528457408)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-25114467 ^ (long)-25114375);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1645622851 ^ (long)-1645622985);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-655581927 ^ (long)-655581757);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)980260239 ^ (long)980260147);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)2035102092 ^ (long)2035102032);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1133826740 ^ (long)-1133826665);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-219821405 ^ (long)-219821350);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1387619073 ^ (long)-1387619282);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)748040801 ^ (long)748040912);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)2106490765 ^ (long)2106490755);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-614198176 ^ (long)-614198243);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)204575292 ^ (long)204575382);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-193885202 ^ (long)-193885329);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1707091597 ^ (long)1707091473);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1051233400 ^ (long)1051233503);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1260089072 ^ (long)1260088941);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)242592098 ^ (long)242592039);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)461827273 ^ (long)461827307);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-855393916 ^ (long)-855394035);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1032982533 ^ (long)1032982603);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)135658982 ^ (long)135658823);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)736251619 ^ (long)736251589);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1927604019 ^ (long)1927604069);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)2089997746 ^ (long)2089997780);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1588718992 ^ (long)1588718942);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1941544885 ^ (long)1941544872);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-2008554027 ^ (long)-2008554004);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1457545170 ^ (long)1457545159);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1847535931 ^ (long)-1847535930);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1172028106 ^ (long)1172028048);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1262609573 ^ (long)1262609576);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)128051453 ^ (long)128051247);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)2132866281 ^ (long)2132866125);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1696719076 ^ (long)1696719015);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)54158434 ^ (long)54158370);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1868147536 ^ (long)1868147532);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1192869401 ^ (long)1192869376);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)453296359 ^ (long)453296183);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1227270299 ^ (long)-1227270199);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-416405052 ^ (long)-416405137);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1304680216 ^ (long)1304680329);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1863009224 ^ (long)-1863009198);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1062108625 ^ (long)-1062108528);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1812199244 ^ (long)1812199175);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-371101754 ^ (long)-371101940);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1710579321 ^ (long)1710579206);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1626160625 ^ (long)1626160590);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-134423741 ^ (long)-134423589);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)350422798 ^ (long)350422984);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)723190623 ^ (long)723190764);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)443679494 ^ (long)443679678);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)120125974 ^ (long)120126085);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1368576760 ^ (long)-1368576716);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1120981539 ^ (long)1120981564);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1297969140 ^ (long)-1297969146);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1717011980 ^ (long)-1717012086);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1589600050 ^ (long)-1589600249);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1057984118 ^ (long)1057984133);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-839069321 ^ (long)-839069440);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)244209115 ^ (long)244209057);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1575382663 ^ (long)-1575382764);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1762028203 ^ (long)1762028194);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1773342691 ^ (long)1773342491);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-976436650 ^ (long)-976436670);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1716468608 ^ (long)-1716468513);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-782786617 ^ (long)-782786642);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)191944708 ^ (long)191944919);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-614519380 ^ (long)-614519467);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-606583930 ^ (long)-606583896);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)888672750 ^ (long)888672589);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-2124955162 ^ (long)-2124955182);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1207947058 ^ (long)1207947219);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)559804959 ^ (long)559805099);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-433108899 ^ (long)-433108986);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)2121433245 ^ (long)2121433090);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)593973335 ^ (long)593973417);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-639698270 ^ (long)-639698217);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-200009003 ^ (long)-200009081);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)766520396 ^ (long)766520516);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)2132361850 ^ (long)2132361814);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-312453423 ^ (long)-312453503);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1825570180 ^ (long)-1825570107);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1873892722 ^ (long)-1873892612);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-710864783 ^ (long)-710864666);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-163592507 ^ (long)-163592559);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)350872356 ^ (long)350872375);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)221273836 ^ (long)221273641);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-76656695 ^ (long)-76656653);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)705611717 ^ (long)705611661);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)68318682 ^ (long)68318476);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-455325835 ^ (long)-455325705);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-737458332 ^ (long)-737458305);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1646050678 ^ (long)1646050756);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1415711215 ^ (long)-1415711082);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-560626754 ^ (long)-560626724);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1901775538 ^ (long)1901775514);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)48369816 ^ (long)48369729);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1881085190 ^ (long)-1881085355);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-844197401 ^ (long)-844197589);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-433067969 ^ (long)-433067909);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1218271777 ^ (long)1218271789);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)262391719 ^ (long)262391702);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)18572881 ^ (long)18572890);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)213883750 ^ (long)213883851);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1112197465 ^ (long)-1112197591);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-391952299 ^ (long)-391952137);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1126728322 ^ (long)1126728417);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)492052823 ^ (long)492052851);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)2048973086 ^ (long)2048973269);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-668973749 ^ (long)-668973780);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1878991865 ^ (long)-1878991632);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)884853541 ^ (long)884853745);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-2026346387 ^ (long)-2026346345);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1813756915 ^ (long)-1813756926);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1123122135 ^ (long)1123121960);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-24023432 ^ (long)-24023408);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1309563466 ^ (long)1309563414);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)438696620 ^ (long)438696474);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1846273929 ^ (long)1846273982);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1414722845 ^ (long)1414722821);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1224670095 ^ (long)-1224670182);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-2060832046 ^ (long)-2060832140);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1958667515 ^ (long)-1958667279);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-177243205 ^ (long)-177243223);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1069973322 ^ (long)1069973266);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1984975293 ^ (long)-1984975146);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1442082143 ^ (long)1442082232);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1715325565 ^ (long)1715325484);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-511718264 ^ (long)-511718207);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-395952988 ^ (long)-395953077);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)900553405 ^ (long)900553401);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)969382612 ^ (long)969382488);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1534843882 ^ (long)1534843803);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1998537859 ^ (long)-1998537967);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)728508357 ^ (long)728508213);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1406722295 ^ (long)1406722260);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)591649427 ^ (long)591649460);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1253864711 ^ (long)-1253864779);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1111493567 ^ (long)-1111493502);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-76560607 ^ (long)-76560558);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1279875242 ^ (long)1279875244);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-433567442 ^ (long)-433567263);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)188468717 ^ (long)188468587);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1849850515 ^ (long)1849850377);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)153677972 ^ (long)153678004);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1910273706 ^ (long)1910273754);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1843550035 ^ (long)-1843550064);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1939410306 ^ (long)-1939410336);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)2031779181 ^ (long)2031779178);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1970913037 ^ (long)1970913118);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1151664656 ^ (long)-1151664698);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1635558421 ^ (long)-1635558571);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-340309787 ^ (long)-340309779);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1549296543 ^ (long)1549296494);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1048663964 ^ (long)-1048663978);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1778025881 ^ (long)1778025910);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)822662128 ^ (long)822662027);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-2029083770 ^ (long)-2029083873);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1963723932 ^ (long)-1963724031);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1965673313 ^ (long)1965673237);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1099399067 ^ (long)1099398962);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1144340019 ^ (long)1144340191);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-170795 ^ (long)-170862);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1264409910 ^ (long)1264410107);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)277162442 ^ (long)277162280);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-74892707 ^ (long)-74892632);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)2002887263 ^ (long)2002887354);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1062525284 ^ (long)1062525284);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1024016387 ^ (long)1024016402);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1906455570 ^ (long)1906455759);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1845379687 ^ (long)1845379751);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1687716450 ^ (long)1687716489);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1837150319 ^ (long)-1837150386);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1422446082 ^ (long)1422446319);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)2087992137 ^ (long)2087992193);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-864159454 ^ (long)-864159364);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-460668139 ^ (long)-460668051);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1348593266 ^ (long)1348593317);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)707803301 ^ (long)707803141);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)816036097 ^ (long)816036271);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1306255937 ^ (long)1306256069);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-2084585700 ^ (long)-2084585684);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1447144848 ^ (long)1447144735);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1301623980 ^ (long)1301623994);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1288297282 ^ (long)-1288297432);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1683522368 ^ (long)-1683522312);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1637062502 ^ (long)-1637062606);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1062410501 ^ (long)-1062410611);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1180096470 ^ (long)1180096468);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)443253703 ^ (long)443253679);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)186498722 ^ (long)186498754);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1590059930 ^ (long)-1590059795);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1252543955 ^ (long)1252543889);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)534108086 ^ (long)534107942);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1887532383 ^ (long)1887532446);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1931513966 ^ (long)-1931513921);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-144461471 ^ (long)-144461377);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)2054943126 ^ (long)2054943155);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-935297107 ^ (long)-935297234);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1260780646 ^ (long)1260780753);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)739120757 ^ (long)739120735);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)918196497 ^ (long)918196636);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1766989383 ^ (long)-1766989399);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-2129037228 ^ (long)-2129037195);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1336154023 ^ (long)-1336154092);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)718435422 ^ (long)718435391);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1176130093 ^ (long)1176130233);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1654187097 ^ (long)-1654187034);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1183742820 ^ (long)1183742970);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)511113207 ^ (long)511113061);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)155928901 ^ (long)155928942);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1363522297 ^ (long)1363522124);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)667781052 ^ (long)667780889);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1649302247 ^ (long)1649302242);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)61251740 ^ (long)61251617);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-385657354 ^ (long)-385657425);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-293376205 ^ (long)-293376139);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)700291117 ^ (long)700291222);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-2000290954 ^ (long)-2000290898);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1789524533 ^ (long)-1789524553);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)267744032 ^ (long)267744078);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1674639918 ^ (long)1674639929);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1952614624 ^ (long)1952614400);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)308458239 ^ (long)308458154);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1328965723 ^ (long)-1328965826);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)107558180 ^ (long)107558254);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)871387032 ^ (long)871387127);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-184128663 ^ (long)-184128551);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-2086376211 ^ (long)-2086376234);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1928901716 ^ (long)1928901800);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1089025130 ^ (long)1089025169);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)812911383 ^ (long)812911434);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)140522494 ^ (long)140522468);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1533069887 ^ (long)1533070037);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-869912993 ^ (long)-869912970);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1257808221 ^ (long)1257808138);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1084747929 ^ (long)-1084747811);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1677691355 ^ (long)1677691192);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)542369954 ^ (long)542369887);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-395468369 ^ (long)-395468479);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-989530101 ^ (long)-989529890);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1732319292 ^ (long)1732319480);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1717091920 ^ (long)1717091921);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1116945830 ^ (long)-1116945815);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-341171418 ^ (long)-341171293);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)374513764 ^ (long)374513814);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-159219820 ^ (long)-159219885);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)2146053979 ^ (long)2146053998);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1938080162 ^ (long)-1938080160);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1278793410 ^ (long)-1278793257);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1849350559 ^ (long)1849350521);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1217221552 ^ (long)1217221460);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-377310629 ^ (long)-377310567);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1854619641 ^ (long)1854619574);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)604125074 ^ (long)604124946);
                    if (!3O.\u2003\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1884160431 ^ (long)1884160345);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-498361684 ^ (long)-498361773)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)936982276 ^ (long)937019643)) >>> (int)((long)-467041975 ^ (long)-467041983)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1068666236 ^ (long)-1068666236);
            if (!3O.\u2003\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-730756069 ^ (long)-730756071);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)994938190 ^ (long)994938189) | var5_6 << (int)((long)1510783376 ^ (long)1510783381)) ^ var3_4[var7_8]) & (int)((long)-2105545691 ^ (long)-2105545510);
                    if (3O.\u2003\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1880527697 ^ (long)-1880527700) | var6_7 << (int)((long)-1389351922 ^ (long)-1389351925)) ^ var3_4[var7_8]) & (int)((long)1419868062 ^ (long)1419868001);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3O.b[var2_3] = new String(var3_4).intern();
        }
        return 3O.b[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block18: {
            block17: {
                var7 = 3O.\u2003\u200c;
                if (!var7) break block17;
                break block18;
            }
            var5_1 = new String[(int)((long)-1464951984 ^ (long)-1464951982)];
            if (var7) break block18;
            var3_2 = (int)((long)-321434082 ^ (long)-321434082);
            if (var7) break block18;
            var2_3 = 2w$6X.KAOZ("\u4fcb\u67ca\u74ef\u7ccb\u4f03\u6747\u74e0\u7c0e\u4fa7\u6741\u742e\u7cbd\u4f06\u677e\u7447\u7c19\u4f0a\u67d8\u74e4\u7c64\u4f26\u67e5\u7453\u7c8e\u4f2d\u6730\u74bd\u7cc3\u4f27\u67f8\u747f\u7ca3\u4fb6\u670d\u749d\u7c3e\u4f7e\u6713\u74e0\u7ca1\u4ff8\u67dc\u7423\u7c71\u4f03\u6757\u74de\u7cc9\u4f05\u67bc\u744a\u7cc3\u4f05\u67a3\u74d5\u7cf1\u4f38\u67e4\u74a3\u7c4e\u4fca\u6768\u7407\u7cbc", -1134532249);
            var4_4 = var2_3.length();
            if (var7) break block18;
            var1_5 = (int)((long)-2074006813 ^ (long)-2074006815);
            if (var7) break block18;
            var0_6 = (int)((long)-1803710824 ^ (long)1803710823);
            if (var7) break block18;
            block8: while (!var7) {
                block15: {
                    v0 = ++var0_6;
                    v1 = (int)((long)1947378210 ^ (long)-1947378211);
                    if (3O.\u2003\u200c) {
                        throw null;
                        while (true) {
                            var5_1[var3_2++] = new String(v2).intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3O.\u2003\u200c) continue block8;
                                throw null;
                            }
                            3O.a = var5_1;
                            3O.b = new String[(int)((long)-357579148 ^ (long)-357579146)];
                            if (3O.\u2003\u200c) {
                                throw null;
                            }
                            break block15;
                            break;
                        }
                    }
                    v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                    v4 = v3.length;
                    var6_7 = (int)((long)76265212 ^ (long)76265212);
                    v5 = (int)((long)316638365 ^ (long)316638435);
                    v6 = v3;
                    v7 = v4;
                    if (v4 > (int)((long)-679683855 ^ (long)-679683856)) ** GOTO lbl88
                    do {
                        block16: {
                            v8 = v5;
                            v6 = v6;
                            v9 = v6;
                            v10 = v5;
                            v11 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-1057544212 ^ (long)-1057544213)) {
                                    case 0: {
                                        v12 = (int)((long)1040959143 ^ (long)1040959137);
                                        if (!3O.\u2003\u200c) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v12 = (int)((long)2062895453 ^ (long)2062895360);
                                        if (!3O.\u2003\u200c) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v12 = (int)((long)602324287 ^ (long)602324272);
                                        if (!3O.\u2003\u200c) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v12 = (int)((long)1014101424 ^ (long)1014101501);
                                        if (!3O.\u2003\u200c) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v12 = (int)((long)-2137463820 ^ (long)-2137463923);
                                        if (!3O.\u2003\u200c) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v12 = (int)((long)1679570635 ^ (long)1679570579);
                                        if (!3O.\u2003\u200c) break;
                                        throw null;
                                    }
                                    default: {
                                        v12 = (int)((long)1843613622 ^ (long)1843613653);
                                    }
                                }
                                v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                                ++var6_7;
                                v5 = v8;
                                if (v8 != 0) break block16;
                                v8 = v5;
                                v6 = v6;
                                v11 = v5;
                                v9 = v6;
                                v10 = v5;
                            } while (!3O.\u2003\u200c);
                            throw null;
                        }
                        v2 = v6;
                        v7 = v7;
                    } while (v7 > var6_7);
                    if (!3O.\u2003\u200c) ** continue;
                    throw null;
                }
                3O.1 = Pattern.compile(3O.a((int)((long)475176509 ^ (long)-475197044), (int)((long)1090161401 ^ (long)-1090169958)) /* "(\\w+) killed by (\\w+) with ([a-zA-Z0-9- ]+)[.,]( Headshot)?.?" */);
                break;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 3O() {
        block3: {
            block2: {
                boolean bl = \u2003\u200c;
                if (bl || bl) break block2;
                this.5 = new HashMap<3sg, Integer>();
                if (bl || bl) break block2;
                this.3 = new Listener(object -> {
                    block4: {
                        block2: {
                            boolean bl;
                            block3: {
                                bl = \u2003\u200c;
                                if (bl || bl) break block2;
                                if (!((Matcher)(object = 1.matcher(((2d)((Object)((Object)object))).8()))).find()) break block3;
                                if (bl || bl) break block2;
                                System.out.println(((Matcher)object).group((int)((long)-113136559 ^ (long)-113136557)) + 3O.a((int)((long)1550032542 ^ (long)-1550053074), (int)((long)-2108068189 ^ (long)-2108088566)) /* "->" */ + ((Matcher)object).group((int)((long)1090079638 ^ (long)1090079639)));
                                if (bl) break block2;
                            }
                            if (!bl) break block4;
                        }
                        return;
                    }
                }, new Predicate[(int)((long)-1165048152 ^ (long)-1165048152)]);
                if (!bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    final void 3(ddn ddn2, Collection<ddm> collection) {
        block3: {
            block2: {
                boolean bl = \u2003\u200c;
                if (bl || bl) break block2;
                collection.forEach(sgArray -> {
                    boolean bl = \u2003\u200c;
                    if (bl || bl) return;
                    ddn2 = aft.a((String)ddl.a((ddp)ddn2.i(sgArray.e()), (nr)new oe(sgArray.e())).getString()).trim();
                    if (bl) return;
                    sgArray = 3sg.values();
                    int n = ((3sg[])sgArray).length;
                    int n2 = (int)((long)1251156157 ^ (long)1251156157);
                    String[] stringArray = 3e.5();
                    if (bl) return;
                    while (!bl) {
                        if (n2 < n) {
                            block5: {
                                if (bl) return;
                                3sg sg = sgArray[n2];
                                if (bl || bl) return;
                                if (((String)ddn2).endsWith(sg.3)) {
                                    if (bl) return;
                                    try {
                                        if (bl) return;
                                        Integer n3 = Integer.valueOf(((String)ddn2).split(2w$6X.KAOZ("\u984c", -1853309244))[(int)((long)-1635887246 ^ (long)-1635887246)]);
                                        if (bl || bl) return;
                                        this.5.put(sg, n3);
                                        if (bl || bl) return;
                                        if (!\u2003\u200c) break block5;
                                        throw null;
                                    }
                                    catch (Exception exception) {
                                        if (bl) return;
                                    }
                                }
                            }
                            if (bl) return;
                            ++n2;
                            if (bl) return;
                            if (stringArray == null) continue;
                            if (bl) return;
                        }
                        if (!bl) return;
                    }
                });
                if (!bl && !bl) break block3;
            }
            return;
        }
    }
}

