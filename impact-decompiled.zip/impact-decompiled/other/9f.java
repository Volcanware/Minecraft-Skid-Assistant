/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  k
 *  nr
 */
package net.impactclient;

import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import net.impactclient.2w$6X;
import net.impactclient.342;
import net.impactclient.3sC;
import net.impactclient.5p;
import net.impactclient.5w;
import net.impactclient.5z;
import net.impactclient.6r;
import net.impactclient.70;
import net.impactclient.9e;
import net.impactclient.9s;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@342(a={"breadcrumbs"}, b="Manage Breadcrumbs Saves")
public final class 9f
extends 9e {
    public static final boolean \u2000\u2006\u2000\u200e\u2002;
    private static final String[] d;
    private static final String[] b;

    /*
     * Enabled aggressive block sorting
     */
    @6r(a={"clear"})
    private void 4(5w kArray) {
        block3: {
            block2: {
                boolean bl = \u2000\u2006\u2000\u200e\u2002;
                if (bl || bl) break block2;
                5z.4().1z.7(70.class).0();
                if (bl || bl) break block2;
                k[] kArray2 = new k[(int)((long)68584234 ^ (long)68584235)];
                kArray2[(int)((long)-2133169034 ^ (long)-2133169034)] = k.h;
                kArray = kArray2;
                5p.9((nr)new 3sC().2((String)9f.b((int)((int)((long)-1369241912 ^ (long)1369211765)), (int)((int)((long)-1184871678 ^ (long)-1184866892))), null, (k[])kArray).7);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    private static Path 1(String string) {
        boolean bl = \u2000\u2006\u2000\u200e\u2002;
        if (bl || bl) {
            return null;
        }
        int n = (int)((long)11334973 ^ (long)-11308926);
        5z.4();
        return 5z.1(9f.b(n, (int)((long)-1821937489 ^ (long)1821934246))).resolve(string + 9f.b((int)((long)-1258776834 ^ (long)1258754884), (int)((long)329686874 ^ (long)329685543)) /* ".json" */);
    }

    /*
     * Enabled aggressive block sorting
     */
    public 9f() {
        boolean bl = \u2000\u2006\u2000\u200e\u2002;
        if (bl) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 9f.\u2000\u2006\u2000\u200e\u2002;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)831615930 ^ (long)831615932)];
            if (var7) break block23;
            var3_2 = (int)((long)1959357667 ^ (long)1959357667);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ua7de\u8e12\u9ddb\u95ed\ua7d5\u8e07\u9d00\u95cb\ua743\u8e9d\u9d12\u95a3\ua704\u8eb6\u9d35\u95a9\ua7ee\u8eaa\u9d00\u957d\ua750\u8eae\u9d1b\u95bd\ua723\u8e8d\u9dbe\u9530\ua7f8\u8e73\u9d0c\u95c9\ua761\u8e23\u9d31\u959e\ua73d\u8ed5\u9d14\u953f\ua7d8\u8ee3\u9dcf\u95cb\ua735\u8e79\u9d5f\u95cb\ua743\u8ed5\u9d41\u954a\ua784\u8e55\u9db9\u957e\ua714\u8e4d\u9dc2\u95a2\ua7ec\u8e94\u9de7\u9582\ua7ba\u8e92\u9de2\u952d\ua714\u8e3a\u9d5f\u956a\ua7a5\u8ee3\u9d74\u950d\ua7d4\u8e21\u9d4e\u9597\ua718\u8e61\u9d05\u9538\ua76e\u8e10\u9d5f\u9526\ua7b3\u8eee\u9d70\u95ce\ua7dc\u8e4b\u9d26\u956d\ua7c4", 644317265);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1103804142 ^ (long)-1103804150);
            if (var7) break block23;
            var0_6 = (int)((long)1184294496 ^ (long)-1184294497);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-501776994 ^ (long)-501776905);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1156985585 ^ (long)1156985584);
                    if (9f.\u2000\u2006\u2000\u200e\u2002) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!9f.\u2000\u2006\u2000\u200e\u2002) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u2b0b\u0231\u1143\u1939\u2b83\u024e\u1145\u1991\u2bd9\u02c1\u11d7\u193e\u2b23\u02a0\u1171\u191a\u2ba6\u02c8\u1133\u191a\u2b61\u0298\u11db\u1982\u2bc2\u02b9", -2121986829);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-576385392 ^ (long)-576385387);
                            var0_6 = (int)((long)522672346 ^ (long)-522672347);
                            while (true) {
                                v0 = (int)((long)476164286 ^ (long)476164275);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1220667196 ^ (long)-1220667196);
                                if (!9f.\u2000\u2006\u2000\u200e\u2002) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!9f.\u2000\u2006\u2000\u200e\u2002) ** continue;
                                throw null;
                            }
                            9f.b = var5_1;
                            9f.d = new String[(int)((long)-1427234796 ^ (long)-1427234798)];
                            if (!9f.\u2000\u2006\u2000\u200e\u2002) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)439660081 ^ (long)439660081);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-2095444137 ^ (long)-2095444138)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1372227685 ^ (long)1372227682)) {
                                case 0: {
                                    v15 = (int)((long)-1988563957 ^ (long)-1988563893);
                                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-46643860 ^ (long)-46643958);
                                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)28446445 ^ (long)28446436);
                                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)2132555867 ^ (long)2132555797);
                                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)461525908 ^ (long)461525955);
                                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-592363321 ^ (long)-592363370);
                                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1992012250 ^ (long)1992012230);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!9f.\u2000\u2006\u2000\u200e\u2002);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @6r(a={"load"}, b={"name"})
    private void 2(5w object, String kArray) {
        boolean bl = \u2000\u2006\u2000\u200e\u2002;
        if (bl || bl) return;
        object = 9f.1((String)kArray);
        if (!Files.exists((Path)object, new LinkOption[(int)((long)1325197458 ^ (long)1325197458)])) {
            if (bl || bl) return;
            k[] kArray2 = new k[(int)((long)385816633 ^ (long)385816632)];
            kArray2[(int)((long)-1416801902 ^ (long)-1416801902)] = k.m;
            kArray = kArray2;
            3sC sC = new 3sC().2(9f.b((int)((long)992494119 ^ (long)-992491620), (int)((long)-2061711354 ^ (long)2061728289)) /* "Unable to find file " */, null, kArray);
            k[] kArray3 = new k[(int)((long)-389839654 ^ (long)-389839653)];
            kArray3[(int)((long)660936734 ^ (long)660936734)] = k.m;
            kArray = kArray3;
            5p.9((nr)sC.2((String)object.getFileName().toString(), null, (k[])kArray).7);
            if (bl || bl) return;
            return;
        }
        if (bl) return;
        new 9s((Path)object).0();
        if (bl || bl) return;
        k[] kArray4 = new k[(int)((long)-78600861 ^ (long)-78600862)];
        kArray4[(int)((long)650339865 ^ (long)650339865)] = k.h;
        kArray = kArray4;
        3sC sC = new 3sC().2(9f.b((int)((long)-1268927819 ^ (long)1268922123), (int)((long)-1565634773 ^ (long)-1565651359)) /* "Loaded breadcrumbs from " */, null, kArray);
        k[] kArray5 = new k[(int)((long)790213547 ^ (long)790213546)];
        kArray5[(int)((long)-1371748960 ^ (long)-1371748960)] = k.j;
        kArray = kArray5;
        5p.9((nr)sC.2((String)object.getFileName().toString(), null, (k[])kArray).7);
        if (!bl && !bl) return;
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 9f.\u2000\u2006\u2000\u200e\u2002;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-616871634 ^ (long)616877200)) & (int)((long)1258775858 ^ (long)1258789581);
            if (var9_2) ** GOTO lbl-1000
            if (9f.d[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 9f.b[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-807505246 ^ (long)-807505246)] & (int)((long)-968085251 ^ (long)-968085502)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)770822033 ^ (long)770821990);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1371521433 ^ (long)-1371521408);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)957219743 ^ (long)957219825);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-286416472 ^ (long)-286416509);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)472570866 ^ (long)472570749);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1506175852 ^ (long)1506175846);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1951307827 ^ (long)1951307917);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1713596164 ^ (long)-1713596213);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-598210770 ^ (long)-598210770);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-875266327 ^ (long)-875266341);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-119700774 ^ (long)-119700930);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1984079846 ^ (long)-1984079861);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1191060245 ^ (long)1191060385);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-16583433 ^ (long)-16583645);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)921341906 ^ (long)921341873);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1723014801 ^ (long)-1723014740);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-459959277 ^ (long)-459959244);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1752962573 ^ (long)-1752962711);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1827184580 ^ (long)1827184553);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-301771070 ^ (long)-301771157);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1131544339 ^ (long)-1131544426);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)376754085 ^ (long)376754005);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)113189215 ^ (long)113189179);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)430401706 ^ (long)430401762);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1416556001 ^ (long)-1416555788);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1983372423 ^ (long)1983372535);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1241375032 ^ (long)-1241375143);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)627527699 ^ (long)627527758);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)2136154028 ^ (long)2136153868);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1088276600 ^ (long)-1088276710);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1814044483 ^ (long)-1814044418);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-316329856 ^ (long)-316329902);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1784615819 ^ (long)-1784615731);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-2113461715 ^ (long)-2113461547);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)611292234 ^ (long)611292240);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)929012761 ^ (long)929012840);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)142457570 ^ (long)142457347);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)237874932 ^ (long)237874816);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1806398301 ^ (long)-1806398325);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1254283741 ^ (long)1254283589);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-424405501 ^ (long)-424405402);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1537837989 ^ (long)1537837833);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)458852664 ^ (long)458852633);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-61349874 ^ (long)-61349859);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-293226898 ^ (long)-293227002);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1372495546 ^ (long)-1372495615);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1406390042 ^ (long)1406390069);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-2003431867 ^ (long)-2003431725);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-516626776 ^ (long)-516626876);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1262867626 ^ (long)1262867614);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-241487754 ^ (long)-241487746);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-201455102 ^ (long)-201454968);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1771370572 ^ (long)-1771370709);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)2004986843 ^ (long)2004986850);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)859468910 ^ (long)859468924);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1957041553 ^ (long)-1957041461);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)719023348 ^ (long)719023200);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1838817148 ^ (long)1838817078);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1024136956 ^ (long)1024136801);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-892148158 ^ (long)-892147977);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1970931944 ^ (long)1970931830);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1344800274 ^ (long)1344800479);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1223255013 ^ (long)1223255016);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1513866926 ^ (long)-1513866935);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-333282111 ^ (long)-333282075);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1763021324 ^ (long)-1763021434);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-682515135 ^ (long)-682514976);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1427733985 ^ (long)1427733854);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-789021203 ^ (long)-789021366);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)2072653777 ^ (long)2072653801);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1779669835 ^ (long)-1779669954);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1730041333 ^ (long)1730041128);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1809229758 ^ (long)-1809229645);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-351910667 ^ (long)-351910897);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-488954523 ^ (long)-488954621);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1138420508 ^ (long)1138420729);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1064834728 ^ (long)1064834681);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-106140154 ^ (long)-106139915);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1505890233 ^ (long)1505890229);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-552954530 ^ (long)-552954613);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-549142892 ^ (long)-549142959);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1281399733 ^ (long)-1281399626);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1202322953 ^ (long)1202323070);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)950749005 ^ (long)950749160);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)2140258968 ^ (long)2140258925);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)897877606 ^ (long)897877722);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1339483079 ^ (long)1339482907);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)756632871 ^ (long)756632916);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)904444347 ^ (long)904444228);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)310262675 ^ (long)310262727);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-599256954 ^ (long)-599257083);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1937081658 ^ (long)-1937081810);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1493603097 ^ (long)-1493603284);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1122815148 ^ (long)1122815151);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-441843574 ^ (long)-441843487);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)922609926 ^ (long)922610008);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1382860355 ^ (long)-1382860493);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)143777573 ^ (long)143777560);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1148824006 ^ (long)-1148823851);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1610036322 ^ (long)1610036408);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-38466108 ^ (long)-38466087);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-234248196 ^ (long)-234248275);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-2061636918 ^ (long)-2061637025);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)249891193 ^ (long)249891159);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1833824904 ^ (long)1833824924);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1214808537 ^ (long)-1214808527);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-549288392 ^ (long)-549288298);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-926430687 ^ (long)-926430611);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-489924009 ^ (long)-489923946);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1568335283 ^ (long)-1568335208);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-214335557 ^ (long)-214335516);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)740038145 ^ (long)740038177);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)2144547441 ^ (long)2144547337);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-813216500 ^ (long)-813216276);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)2093728027 ^ (long)2093728098);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1789929647 ^ (long)1789929503);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1309238667 ^ (long)-1309238645);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1674825662 ^ (long)1674825659);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)309485187 ^ (long)309485152);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1464716222 ^ (long)-1464716219);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)580748169 ^ (long)580748041);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1121290734 ^ (long)-1121290738);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)92980312 ^ (long)92980427);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)858235068 ^ (long)858234995);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1394332203 ^ (long)1394332168);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1409554311 ^ (long)1409554257);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)753160428 ^ (long)753160423);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1966924861 ^ (long)-1966924998);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)871268235 ^ (long)871268132);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1863722743 ^ (long)1863722653);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)945989112 ^ (long)945988894);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-2063049682 ^ (long)-2063049698);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1597743250 ^ (long)1597743180);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)176004051 ^ (long)176004036);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-2067014851 ^ (long)-2067014881);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-144135116 ^ (long)-144135120);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)578464464 ^ (long)578464439);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1551993818 ^ (long)1551993682);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1751802753 ^ (long)1751802631);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1726005087 ^ (long)-1726005225);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-133220777 ^ (long)-133220719);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1942476151 ^ (long)-1942476275);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-657629060 ^ (long)-657629152);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-109736562 ^ (long)-109736615);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-473595264 ^ (long)-473595385);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1659444682 ^ (long)-1659444566);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1475785221 ^ (long)1475785470);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1370676994 ^ (long)-1370677058);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)573710572 ^ (long)573710585);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-2078880370 ^ (long)-2078880336);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)775522600 ^ (long)775522669);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1084696609 ^ (long)-1084696589);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1495937534 ^ (long)-1495937456);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1380472286 ^ (long)1380472199);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1269356517 ^ (long)1269356391);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-277637877 ^ (long)-277637822);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1350126327 ^ (long)1350126302);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1705241752 ^ (long)-1705241726);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1984365292 ^ (long)1984365249);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)713097914 ^ (long)713097829);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1137094184 ^ (long)1137094226);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)943013234 ^ (long)943013156);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1173759980 ^ (long)1173759926);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)2082984767 ^ (long)2082984925);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)585308661 ^ (long)585308540);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1347624445 ^ (long)-1347624395);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)185788051 ^ (long)185788124);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1255690452 ^ (long)-1255690299);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1839864480 ^ (long)1839864331);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)863308694 ^ (long)863308771);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)2026340180 ^ (long)2026340152);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1460370253 ^ (long)-1460370353);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1452401279 ^ (long)-1452401395);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1874397217 ^ (long)-1874397315);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-2070091626 ^ (long)-2070091729);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1878021176 ^ (long)-1878021134);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1741185026 ^ (long)-1741185268);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)2010863780 ^ (long)2010863786);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-499450738 ^ (long)-499450781);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1688483910 ^ (long)1688483928);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1432467093 ^ (long)-1432466992);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-795834507 ^ (long)-795834598);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1631443143 ^ (long)-1631443132);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1800093672 ^ (long)-1800093482);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-2026808870 ^ (long)-2026808985);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1425220959 ^ (long)1425220970);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-435791952 ^ (long)-435791921);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1444353920 ^ (long)-1444354023);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)333630567 ^ (long)333630499);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-610750151 ^ (long)-610750206);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-535461696 ^ (long)-535461726);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1284628571 ^ (long)-1284628611);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-965029132 ^ (long)-965029190);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1607532759 ^ (long)-1607532757);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)834485307 ^ (long)834485480);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1573150989 ^ (long)1573150988);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1929956777 ^ (long)1929956618);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1384637556 ^ (long)-1384637547);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1976586761 ^ (long)1976586947);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1604356200 ^ (long)-1604356217);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-960460592 ^ (long)-960460665);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1134295180 ^ (long)1134295245);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)2030366423 ^ (long)2030366243);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1689807527 ^ (long)1689807433);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)687823464 ^ (long)687823603);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)295366568 ^ (long)295366542);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1536399630 ^ (long)1536399779);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1038840121 ^ (long)-1038840233);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1260368167 ^ (long)1260368290);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1505057898 ^ (long)1505057900);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1652574227 ^ (long)-1652574255);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-709338079 ^ (long)-709337999);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)963932865 ^ (long)963932736);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)708018733 ^ (long)708018696);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1284515555 ^ (long)-1284515401);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)236042183 ^ (long)236042169);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)833870142 ^ (long)833870327);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)680330446 ^ (long)680330371);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-2070855916 ^ (long)-2070855728);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1904637866 ^ (long)1904637809);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-625855954 ^ (long)-625855875);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1041965948 ^ (long)-1041965893);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1200298171 ^ (long)1200298129);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1535499011 ^ (long)1535499188);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-636196891 ^ (long)-636196884);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1747501418 ^ (long)-1747501472);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-535292711 ^ (long)-535292752);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1403189874 ^ (long)-1403189955);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1584758423 ^ (long)0x5E757E55);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-264168867 ^ (long)-264168900);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1172869429 ^ (long)-1172869523);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1634336340 ^ (long)1634336271);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)740991527 ^ (long)740991645);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1699030024 ^ (long)1699030096);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)74792977 ^ (long)74793116);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1930955477 ^ (long)-1930955285);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1827193337 ^ (long)-1827193163);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1707241093 ^ (long)1707241142);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-527398266 ^ (long)-527398208);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-419234127 ^ (long)-419234186);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-832049621 ^ (long)-832049476);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)741225447 ^ (long)741225271);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1190657880 ^ (long)1190657921);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-897149127 ^ (long)-897148939);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1497735457 ^ (long)1497735561);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1857458039 ^ (long)-1857458031);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1151424413 ^ (long)1151424481);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1645325636 ^ (long)-1645325811);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1833738674 ^ (long)1833738658);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1365690420 ^ (long)-1365690371);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)648597055 ^ (long)648597040);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1491168108 ^ (long)-1491168030);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-460863430 ^ (long)-460863368);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1341029599 ^ (long)1341029524);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1181436303 ^ (long)1181436399);
                    if (!9f.\u2000\u2006\u2000\u200e\u2002) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1118153774 ^ (long)-1118153958);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1764759565 ^ (long)-1764759796)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-450953666 ^ (long)-451018303)) >>> (int)((long)147876931 ^ (long)147876939)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1051508651 ^ (long)1051508651);
            if (!9f.\u2000\u2006\u2000\u200e\u2002) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1604194915 ^ (long)-1604194913);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-129300504 ^ (long)-129300501) | var5_6 << (int)((long)-494954708 ^ (long)-494954711)) ^ var3_4[var7_8]) & (int)((long)-1780942657 ^ (long)-1780942784);
                    if (9f.\u2000\u2006\u2000\u200e\u2002) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)992862959 ^ (long)992862956) | var6_7 << (int)((long)402350102 ^ (long)402350099)) ^ var3_4[var7_8]) & (int)((long)-330705519 ^ (long)-330705554);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            9f.d[var2_3] = new String(var3_4).intern();
        }
        return 9f.d[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @6r(a={"save"}, b={"name"})
    private void 0(5w object, String kArray) {
        block3: {
            block2: {
                boolean bl = \u2000\u2006\u2000\u200e\u2002;
                if (bl || bl) break block2;
                object = 9f.1((String)kArray);
                if (bl || bl) break block2;
                new 9s((Path)object).6();
                if (bl || bl) break block2;
                k[] kArray2 = new k[(int)((long)882870752 ^ (long)882870753)];
                kArray2[(int)((long)-361350527 ^ (long)-361350527)] = k.h;
                kArray = kArray2;
                3sC sC = new 3sC().2(9f.b((int)((long)-2138266887 ^ (long)2138253125), (int)((long)1011302309 ^ (long)1011290691)) /* "Saved breadcrumbs to " */, null, kArray);
                k[] kArray3 = new k[(int)((long)-822687851 ^ (long)-822687852)];
                kArray3[(int)((long)-1251245607 ^ (long)-1251245607)] = k.j;
                kArray = kArray3;
                5p.9((nr)sC.2((String)object.getFileName().toString(), null, (k[])kArray).7);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }
}

