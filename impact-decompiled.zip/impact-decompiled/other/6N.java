/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aps
 *  apu
 *  dfm
 *  dku
 *  it.unimi.dsi.fastutil.objects.Object2FloatArrayMap
 *  it.unimi.dsi.fastutil.objects.Object2FloatMap
 */
package net.impactclient;

import it.unimi.dsi.fastutil.objects.Object2FloatArrayMap;
import it.unimi.dsi.fastutil.objects.Object2FloatMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import me.zero.clarinet.hook.mixin.accessor.AccessorFontRenderer;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.34L;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3sN;
import net.impactclient.5z;
import net.impactclient.6C;
import net.impactclient.6Z;
import net.impactclient.7N;
import net.impactclient.8U;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 6N
extends 6C {
    private float 2;
    public static final boolean \u2004\u2001;
    private static final String[] a;
    private static 7N 1;
    private static final String[] b;
    private int 5;
    private final Object2FloatMap<3X> 0;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 4(dfm dfm2, dku dku2) {
        float f;
        int n;
        block15: {
            block13: {
                boolean bl;
                block14: {
                    bl = \u2004\u2001;
                    if (bl || bl) break block13;
                    if (1 != null) break block14;
                    if (bl || bl) break block13;
                    1 = 5z.4().1z.7(7N.class);
                    if (bl) break block13;
                }
                if (bl) break block13;
                this.5 = (int)((long)-868610244 ^ (long)-868610244);
                if (!bl && !bl) break block15;
            }
            return;
        }
        List<3X> list = 6N.3.s.dh().stream().filter(apu::f).map(apu::a).collect(Collectors.toList());
        boolean bl = list.stream().anyMatch(aps::h);
        if (!list.stream().allMatch(aps::h)) {
            n = (int)((long)-1055050306 ^ (long)-1055050305);
            if (\u2004\u2001) {
                throw null;
            }
        } else {
            n = (int)((long)1658347728 ^ (long)1658347728);
        }
        if (n != 0) {
            f = 48.0f;
            if (\u2004\u2001) {
                throw null;
            }
        } else if (bl) {
            f = 24.0f;
            if (\u2004\u2001) {
                throw null;
            }
        } else {
            f = 0.0f;
        }
        this.2 = f;
        list = new ArrayList<3X>(5z.4().1z);
        list.removeIf(arg_0 -> this.8(-1.0f, arg_0));
        list.sort(Comparator.comparingDouble(x2 -> {
            boolean bl = \u2004\u2001;
            if (bl || bl) {
                return 0.0;
            }
            return -dku2.b(6N.1(x2));
        }));
        list.forEach(arg_0 -> this.5(dku2, -1.0f, list, dfm2, arg_0));
        ((6Z)this).0 = this.5;
        ((6Z)this).2 = this.2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static String 1(3X object) {
        String string;
        String string2;
        boolean bl = \u2004\u2001;
        if (bl) return null;
        if (bl) return null;
        String string3 = ((3e)object).2();
        if (bl) return null;
        if (bl) return null;
        if (!6N.1.77.2) return string3;
        if (bl) return null;
        if (bl) return null;
        if ((object = (String)2R.0((8U)object, 6N.a((int)((long)2044782324 ^ (long)2044756860), (int)((long)1132214137 ^ (long)-1132217928)) /* "suffix" */)) == null) return string3;
        if (bl) return null;
        if (((String)object).isEmpty()) return string3;
        if (bl) return null;
        if (bl) return null;
        StringBuilder stringBuilder = new StringBuilder().append(string3).append(2w$6X.KAOZ("\u26aa", 47251854));
        if (6N.1.7b.2) {
            string2 = ((3sN)((Object)6N.1.7h.0())).2() + 2w$6X.KAOZ("\u7785", 1492472026);
            if (\u2004\u2001) {
                throw null;
            }
        } else {
            string2 = 2w$6X.KAOZ("", 882331963);
        }
        StringBuilder stringBuilder2 = stringBuilder.append(string2).append(((3sN)((Object)6N.1.7F.0())).2()).append((String)object);
        if (6N.1.7b.2) {
            string = ((3sN)((Object)6N.1.7h.0())).2() + 2w$6X.KAOZ("\u44f4", 744842157);
            if (!\u2004\u2001) return stringBuilder2.append(string).toString();
            throw null;
        }
        string = 2w$6X.KAOZ("", 955645130);
        return stringBuilder2.append(string).toString();
    }

    /*
     * Enabled aggressive block sorting
     */
    public 6N() {
        block3: {
            block2: {
                boolean bl = \u2004\u2001;
                if (bl || bl) break block2;
                this.0 = new Object2FloatArrayMap();
                if (!bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ boolean 8(float f, 3X x2) {
        boolean bl;
        block14: {
            block13: {
                bl = \u2004\u2001;
                if (bl || bl) return true;
                this.0.putIfAbsent((Object)x2, f);
                if (bl || bl) return true;
                if (((String)6N.1.7J.0()).equals(6N.a((int)((long)-1850052180 ^ (long)-1850076125), (int)((long)-930854543 ^ (long)930863815)))) {
                    if (bl) return true;
                    if (!x2.3()) {
                        if (bl || bl) return true;
                        return (int)((long)-225377133 ^ (long)-225377134) != 0;
                    }
                }
                if (bl) return true;
                if (!((Boolean)2R.0(x2, 6N.a((int)((long)-883583518 ^ (long)-883560341), (int)((long)1982745581 ^ (long)-1982736072)) /* "display" */)).booleanValue()) break block13;
                if (bl) return true;
                if (x2.3()) break block14;
                if (bl) return true;
                if (this.0.getFloat((Object)x2) > f) break block14;
                if (bl) return true;
            }
            if (bl) return true;
            return (int)((long)-1389826329 ^ (long)-1389826330) != 0;
        }
        if (!bl) return (int)((long)-1747084543 ^ (long)-1747084543) != 0;
        return true;
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 6N.\u2004\u2001;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-2039723144 ^ (long)-2039730444)) & (int)((long)391085791 ^ (long)391086368);
            if (var9_2) ** GOTO lbl-1000
            if (6N.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 6N.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)636770806 ^ (long)636770806)] & (int)((long)-1022604369 ^ (long)-1022604464)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)513144529 ^ (long)513144455);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-70969761 ^ (long)-70969850);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1227332646 ^ (long)-1227332633);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-732292966 ^ (long)-732293010);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1835261585 ^ (long)1835261483);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)539749661 ^ (long)539749709);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1645106553 ^ (long)1645106496);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1129692610 ^ (long)1129692599);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)633064029 ^ (long)633063946);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-166846644 ^ (long)-166846522);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)192485346 ^ (long)192485249);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1661011479 ^ (long)1661011540);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1526730467 ^ (long)1526730481);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1876020212 ^ (long)-1876020167);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-784305986 ^ (long)-784305963);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1606252772 ^ (long)-1606252771);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1670983050 ^ (long)-1670982945);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1749379587 ^ (long)-1749379718);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1699944320 ^ (long)-1699944333);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1984057657 ^ (long)1984057648);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1078159063 ^ (long)-1078159069);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)2101621531 ^ (long)2101621652);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1086663302 ^ (long)-1086663404);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1610077346 ^ (long)-1610077224);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1434619940 ^ (long)1434619916);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1420412545 ^ (long)1420412446);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1631195288 ^ (long)1631195334);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-789554812 ^ (long)-789554932);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-697488604 ^ (long)-697488452);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1915416146 ^ (long)-1915416295);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-689539669 ^ (long)-689539737);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1790284261 ^ (long)-1790284041);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-552493087 ^ (long)-552493271);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1475421433 ^ (long)-1475421314);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1358553944 ^ (long)-1358553989);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-11305775 ^ (long)-11305961);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-142387520 ^ (long)-142387596);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)2007585661 ^ (long)2007585576);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)211058553 ^ (long)211058565);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-566773896 ^ (long)-566773901);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1424523835 ^ (long)-1424524008);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)483685314 ^ (long)483685338);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-513356903 ^ (long)-513357005);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)329797125 ^ (long)329797271);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1954906509 ^ (long)1954906585);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-968474339 ^ (long)-968474245);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)726874930 ^ (long)726874950);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)2073720359 ^ (long)2073720431);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-935083049 ^ (long)-935083170);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1277469555 ^ (long)1277469616);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-270638915 ^ (long)-270639079);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-646903816 ^ (long)-646904018);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-743018330 ^ (long)-743018283);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1405093784 ^ (long)1405093660);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1347747645 ^ (long)-1347747820);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1545916829 ^ (long)1545916883);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-579503882 ^ (long)-579504065);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1841229726 ^ (long)-1841229628);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)954096239 ^ (long)954096288);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1223923500 ^ (long)1223923651);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1310676415 ^ (long)1310676288);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)444378393 ^ (long)444378389);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)586841985 ^ (long)586841888);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1240979288 ^ (long)1240979220);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-724012842 ^ (long)-724013001);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1751124681 ^ (long)-1751124549);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1523312204 ^ (long)-1523312254);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1134783586 ^ (long)1134783549);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)2033282824 ^ (long)2033283036);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)354053887 ^ (long)354053700);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-2012006072 ^ (long)-2012005993);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1497851005 ^ (long)-1497850975);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)669345619 ^ (long)669345747);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)2141106470 ^ (long)2141106469);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-2136815752 ^ (long)-2136815819);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1622856827 ^ (long)-1622856871);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)2001813554 ^ (long)2001813700);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1274562039 ^ (long)-1274561904);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1533040452 ^ (long)1533040406);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1766490507 ^ (long)-1766490400);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1900301488 ^ (long)-1900301328);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1354652867 ^ (long)1354652707);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-854020406 ^ (long)-854020464);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)157850618 ^ (long)157850598);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1455034785 ^ (long)-1455034660);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)2727581 ^ (long)2727519);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1660001470 ^ (long)-1660001483);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)613403125 ^ (long)613402903);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-2112085925 ^ (long)-2112085962);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1833003649 ^ (long)-1833003622);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1074266156 ^ (long)-1074266128);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)980846132 ^ (long)980846132);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1572878082 ^ (long)-1572878126);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)376412856 ^ (long)376412770);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-584839321 ^ (long)-584839224);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)450717781 ^ (long)450717904);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)199669118 ^ (long)199668998);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-364170160 ^ (long)-364170118);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1873484098 ^ (long)-1873484120);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)2088797987 ^ (long)2088797968);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1705807612 ^ (long)-1705807600);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1872365072 ^ (long)-1872365239);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1129802555 ^ (long)1129802573);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)933454209 ^ (long)933454182);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1352264341 ^ (long)1352264433);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1345215060 ^ (long)1345215172);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1392611034 ^ (long)-1392611043);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-141491332 ^ (long)-141491251);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)281056859 ^ (long)281056957);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1958851860 ^ (long)1958851966);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)0xB5757B ^ (long)11892169);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-480606634 ^ (long)-480606697);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1229238748 ^ (long)-1229238650);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1286826558 ^ (long)-1286826630);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1066180115 ^ (long)-1066180332);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)589569355 ^ (long)589569455);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1615517534 ^ (long)1615517568);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)210193928 ^ (long)210193937);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)795204435 ^ (long)795204402);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-2009326823 ^ (long)-2009326631);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1428514962 ^ (long)-1428515056);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1749831855 ^ (long)1749831806);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)371037175 ^ (long)371036956);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-819475145 ^ (long)-819475128);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)741383683 ^ (long)741383896);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-233071391 ^ (long)-233071376);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-852885567 ^ (long)-852885528);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1311203325 ^ (long)-1311203277);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1187418604 ^ (long)1187418593);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1358761891 ^ (long)1358761862);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-532449756 ^ (long)-532449783);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1830045783 ^ (long)1830045739);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1258051132 ^ (long)1258051080);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1904671814 ^ (long)-1904671887);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)401304437 ^ (long)401304338);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)253066812 ^ (long)253066881);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1869287844 ^ (long)-1869287700);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1308105002 ^ (long)1308105041);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)309756901 ^ (long)309756799);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)146345456 ^ (long)146345451);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1785202436 ^ (long)1785202520);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1660843143 ^ (long)1660843055);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1935866078 ^ (long)-1935866100);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-2140240492 ^ (long)-2140240600);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1937966617 ^ (long)1937966635);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1460707113 ^ (long)-1460707172);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1145473960 ^ (long)1145473893);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)789212723 ^ (long)789212862);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-2110312534 ^ (long)-2110312582);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1259720394 ^ (long)-1259720293);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)711038090 ^ (long)711037972);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1034841812 ^ (long)-1034841749);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1631465137 ^ (long)1631465164);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1952631746 ^ (long)1952631636);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1152279421 ^ (long)-1152279466);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-2038517673 ^ (long)-2038517603);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-474398385 ^ (long)-474398458);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1811736272 ^ (long)-1811736256);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1599758980 ^ (long)1599759085);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)469244262 ^ (long)469244180);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1586481222 ^ (long)1586481243);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1900185866 ^ (long)1900186022);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1878313063 ^ (long)-1878313060);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-928960908 ^ (long)-928960797);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-2034624068 ^ (long)-2034624146);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1363183270 ^ (long)-1363183177);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1453516352 ^ (long)1453516430);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1370885968 ^ (long)-1370885989);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-301876482 ^ (long)-301876643);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1299517354 ^ (long)1299517220);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-221523241 ^ (long)-221523313);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1261210598 ^ (long)-1261210502);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1836239878 ^ (long)-1836240055);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1578796365 ^ (long)-1578796531);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1888958354 ^ (long)-1888958362);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1104996359 ^ (long)-1104996600);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)393260572 ^ (long)393260634);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1493747510 ^ (long)-1493747701);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1088393832 ^ (long)1088393943);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-956942227 ^ (long)-956942331);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1305734380 ^ (long)1305734217);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-499437328 ^ (long)-499437455);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-298553003 ^ (long)-298552974);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)100299530 ^ (long)100299656);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-2049781352 ^ (long)-2049781314);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-133321704 ^ (long)-133321489);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-605481364 ^ (long)-605481434);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-264321529 ^ (long)-264321389);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-919615252 ^ (long)-919615447);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-77865121 ^ (long)-77865052);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1606500183 ^ (long)-1606500116);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1079706250 ^ (long)-1079706254);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-2114524699 ^ (long)-2114524732);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1805707345 ^ (long)-1805707402);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1412153971 ^ (long)1412154036);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1698551672 ^ (long)1698551766);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1122798645 ^ (long)-1122798799);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)387822512 ^ (long)387822580);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1717387267 ^ (long)-1717387325);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1932037440 ^ (long)1932037585);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)966356560 ^ (long)966356522);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)269559300 ^ (long)269559542);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-85597888 ^ (long)-85597789);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-712652805 ^ (long)-712653050);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)944972978 ^ (long)944972972);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1552531710 ^ (long)1552531545);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)819927632 ^ (long)819927602);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1835052492 ^ (long)-1835052463);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-354149754 ^ (long)-354149778);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-204952331 ^ (long)-204952334);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)835506201 ^ (long)835506244);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-377972080 ^ (long)-377972045);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1120475953 ^ (long)-1120475955);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1297354497 ^ (long)1297354503);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-935998922 ^ (long)-935998738);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1750696654 ^ (long)-1750696579);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-946618671 ^ (long)-946618859);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)137725876 ^ (long)137725915);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1875940663 ^ (long)-1875940642);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-730716014 ^ (long)-730716151);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1873900021 ^ (long)1873900000);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1329918131 ^ (long)1329918175);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-686019864 ^ (long)-686019997);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1469569239 ^ (long)1469569224);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1886353611 ^ (long)1886353594);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)295350190 ^ (long)295350066);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-367737935 ^ (long)-367737922);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1582064341 ^ (long)-1582064227);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1700651148 ^ (long)-1700651154);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-112319362 ^ (long)-112319354);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)2141194856 ^ (long)2141194872);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-412676589 ^ (long)-412676355);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)2135601985 ^ (long)2135602091);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-527048173 ^ (long)-527048145);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1673763100 ^ (long)1673763317);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)197698189 ^ (long)197698270);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)976040741 ^ (long)976040709);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1366882978 ^ (long)1366883065);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-812373770 ^ (long)-812373823);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1355029782 ^ (long)-1355029848);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)853060526 ^ (long)853060403);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1883278974 ^ (long)-1883278980);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)722805669 ^ (long)722805558);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1090511610 ^ (long)1090511546);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1297834376 ^ (long)-1297834430);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-42991327 ^ (long)-42991313);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1698984004 ^ (long)1698984175);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1491717706 ^ (long)1491717746);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1731557311 ^ (long)1731557358);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1373808990 ^ (long)1373809131);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1451218050 ^ (long)1451218109);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1655238044 ^ (long)1655237993);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)757602339 ^ (long)757602515);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1357995738 ^ (long)1357995755);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1677495841 ^ (long)-1677495824);
                    if (!6N.\u2004\u2001) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1665681330 ^ (long)-1665681315);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1718638291 ^ (long)1718638124)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1757727378 ^ (long)-1757689199)) >>> (int)((long)1288673283 ^ (long)1288673291)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1120439507 ^ (long)-1120439507);
            if (!6N.\u2004\u2001) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1651343165 ^ (long)-1651343167);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)199758004 ^ (long)199758007) | var5_6 << (int)((long)-732713809 ^ (long)-732713814)) ^ var3_4[var7_8]) & (int)((long)1355847729 ^ (long)1355847886);
                    if (6N.\u2004\u2001) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-245438341 ^ (long)-245438344) | var6_7 << (int)((long)-2070363402 ^ (long)-2070363405)) ^ var3_4[var7_8]) & (int)((long)-1053316489 ^ (long)-1053316472);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            6N.b[var2_3] = new String(var3_4).intern();
        }
        return 6N.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 5(dku dku2, float f, List list, dfm dfm2, 3X object) {
        float f2;
        float f3;
        int n;
        float f4;
        int n2;
        float f5;
        float f6;
        String[] stringArray;
        String string;
        block32: {
            block30: {
                block31: {
                    block29: {
                        boolean bl = \u2004\u2001;
                        if (bl) break block29;
                        string = 6N.1((3X)object);
                        stringArray = 3e.5();
                        if (bl || bl) break block29;
                        f6 = dku2.b(string);
                        if (bl || bl) break block29;
                        if (!((3e)object).3()) break block30;
                        if (!bl) break block31;
                    }
                    return;
                }
                f5 = f6;
                if (\u2004\u2001) {
                    throw null;
                }
                break block32;
            }
            f5 = f;
        }
        f = f5;
        float f7 = this.0.getFloat(object);
        float f8 = 6N.9.getTimer().b * 8.25f;
        if (((3e)object).3()) {
            n2 = (int)((long)-872025567 ^ (long)-872025568);
            if (\u2004\u2001) {
                throw null;
            }
        } else {
            n2 = (int)((long)-2021060424 ^ (long)2021060423);
        }
        float f9 = f7 + f8 * (float)n2;
        if (((3e)object).3()) {
            f4 = Math.min(f, f9);
            if (\u2004\u2001) {
                throw null;
            }
        } else {
            f4 = Math.max(f, f9);
        }
        f9 = f4;
        this.0.put(object, f9);
        Object object2 = object;
        object = ((String)6N.1.7D.0()).toLowerCase();
        int n3 = (int)((long)350722839 ^ (long)-350722840);
        switch (((String)object).hashCode()) {
            case -938285885: {
                if (!((String)object).equals(6N.a((int)((long)-308043994 ^ (long)-308020574), (int)((long)1652846184 ^ (long)-1652833953)) /* "random" */)) break;
                n3 = (int)((long)682637876 ^ (long)682637876);
                if (stringArray == null) break;
            }
            case 50511102: {
                if (!((String)object).equals(6N.a((int)((long)-420227628 ^ (long)-420237222), (int)((long)257932896 ^ (long)257932284)) /* "category" */)) break;
                n3 = (int)((long)1061729542 ^ (long)1061729543);
                if (stringArray == null) break;
            }
            case 3135100: {
                if (!((String)object).equals(6N.a((int)((long)1803747104 ^ (long)1803721387), (int)((long)-599176810 ^ (long)599194795)) /* "fade" */)) break;
                n3 = (int)((long)2104001250 ^ (long)2104001248);
                if (stringArray == null) break;
            }
            case 973576630: {
                if (!((String)object).equals(6N.a((int)((long)-1064303204 ^ (long)-1064280039), (int)((long)-770125936 ^ (long)-770137484)) /* "rainbow" */)) break;
                n3 = (int)((long)1618125961 ^ (long)1618125962);
                break;
            }
        }
        switch (n3) {
            case 0: {
                int n4 = (Integer)2R.0((8U)object2, 6N.a((int)((long)1350011502 ^ (long)1350037476), (int)((long)-1195379953 ^ (long)-1195378029)) /* "color" */);
                if (!\u2004\u2001) break;
                throw null;
            }
            case 1: {
                int n4 = object2.3();
                if (!\u2004\u2001) break;
                throw null;
            }
            case 2: {
                int n4 = 34L.7((int)((long)-117343521 ^ (long)110673412), (int)((long)-1139017220 ^ (long)1132026680), (float)list.indexOf(object2) / (float)list.size());
                if (!\u2004\u2001) break;
                throw null;
            }
            case 3: {
                int n4 = 34L.9((float)6N.1.7H.4 / 100.0f, (float)6N.1.7M.4 / 100.0f, list.indexOf(object2) * (int)((long)-1149240111 ^ (long)-1149240093));
                if (!\u2004\u2001) break;
                throw null;
            }
            default: {
                int n4 = n = (int)((long)-1814884779 ^ (long)1814884778);
            }
        }
        if (((String)6N.1.7J.0()).equals(6N.a((int)((long)1278665530 ^ (long)1278641847), (int)((long)1549901898 ^ (long)-1549921676)) /* "None" */)) {
            f3 = f6;
            if (\u2004\u2001) {
                throw null;
            }
        } else {
            f3 = f9;
        }
        this.5 = Math.max(this.5, this.2(dfm2, dku2, string, -f3 + f6, this.2, n));
        float f10 = ((AccessorFontRenderer)dku2).getFontHeight() + (int)((long)-201957599 ^ (long)-201957600);
        if (((String)6N.1.7J.0()).equals(6N.a((int)((long)1290552446 ^ (long)1290543602), (int)((long)1588384433 ^ (long)-1588375450)) /* "Flare" */)) {
            f2 = f9 / f6;
            if (\u2004\u2001) {
                throw null;
            }
        } else {
            f2 = 1.0f;
        }
        this.2 += f10 * f2;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 6N.\u2004\u2001;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)2973187 ^ (long)2973193)];
            if (var7) break block23;
            var3_2 = (int)((long)808314585 ^ (long)808314585);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u8407\uad5d\ube8e\ub66b\u84da\uadc5\ubefd\ub64c\u8450\uad58\ubed5\ub61c\u8412\uaddd\ubef8\ub643\u8420\uadc7\ube17\ub6ad\u843c\uad9d\ubeef\ub607\u846a\uad38\ube67\ub63c\u8444\uad44\ube44\ub6ae\u841e\uad83\ubed9\ub617\u8469\uad47\ube47\ub6ac\u84d9\uadb5\ubed9\ub608\u848b\uadc5\ube12\ub689\u848a\uad2f", -1556503704);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-810736676 ^ (long)-810736679);
            if (var7) break block23;
            var0_6 = (int)((long)-1138987713 ^ (long)1138987712);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-564343976 ^ (long)-564344014);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1075741961 ^ (long)-1075741962);
                    if (6N.\u2004\u2001) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!6N.\u2004\u2001) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u5f00\u7646\u65c4\u6da5\u5f60\u769c\u651d\u6d29\u5f06\u7642\u6566\u6d1c\u5f8e\u769b", -1284343633);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)878897739 ^ (long)878897741);
                            var0_6 = (int)((long)1696291123 ^ (long)-1696291124);
                            while (true) {
                                v0 = (int)((long)122425536 ^ (long)122425507);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-490346845 ^ (long)-490346845);
                                if (!6N.\u2004\u2001) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!6N.\u2004\u2001) ** continue;
                                throw null;
                            }
                            6N.a = var5_1;
                            6N.b = new String[(int)((long)1646541077 ^ (long)1646541087)];
                            if (!6N.\u2004\u2001) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1441396012 ^ (long)-1441396012);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1662682103 ^ (long)1662682102)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)863485535 ^ (long)863485528)) {
                                case 0: {
                                    v15 = (int)((long)-417043702 ^ (long)-417043684);
                                    if (!6N.\u2004\u2001) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-626139709 ^ (long)-626139739);
                                    if (!6N.\u2004\u2001) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)834215082 ^ (long)834215070);
                                    if (!6N.\u2004\u2001) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1461149591 ^ (long)-1461149632);
                                    if (!6N.\u2004\u2001) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-2037045977 ^ (long)-2037045902);
                                    if (!6N.\u2004\u2001) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)2019953977 ^ (long)2019954037);
                                    if (!6N.\u2004\u2001) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)640072348 ^ (long)640072371);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!6N.\u2004\u2001);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

