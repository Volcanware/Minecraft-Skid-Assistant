/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  djz
 *  org.apache.commons.lang3.ArrayUtils
 */
package net.impactclient;

import com.google.gson.JsonArray;
import java.io.IOException;
import java.lang.invoke.LambdaMetafactory;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import net.impactclient.2B;
import net.impactclient.2w$6X;
import net.impactclient.3M;
import net.impactclient.3e;
import net.impactclient.81;
import org.apache.commons.lang3.ArrayUtils;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 34n {
    private static final 3M<UUID, String> 7;
    private static final String[] a;
    private static final int[] 5;
    private static final String[] b;
    public static final boolean \u2004\u2007\u2000\u2004;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 34n.\u2004\u2007\u2000\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1042035322 ^ (long)-1042034710)) & (int)((long)376953477 ^ (long)376907130);
            if (var9_2) ** GOTO lbl-1000
            if (34n.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 34n.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-993840068 ^ (long)-993840068)] & (int)((long)-646223690 ^ (long)-646223799)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1032016666 ^ (long)1032016838);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1840238370 ^ (long)1840238441);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1029345917 ^ (long)1029345899);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-273562744 ^ (long)-273562854);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)691317443 ^ (long)691317362);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1424055335 ^ (long)-1424055392);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-2037588159 ^ (long)-2037588213);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)425864535 ^ (long)425864632);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1778712009 ^ (long)-1778711860);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1955954419 ^ (long)1955954419);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-722658081 ^ (long)-722658244);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)634703503 ^ (long)634703444);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-217265963 ^ (long)-217266135);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)289341216 ^ (long)289341419);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-404674073 ^ (long)-404674160);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1500722860 ^ (long)-1500722888);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)377775761 ^ (long)377775806);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-154258453 ^ (long)-154258486);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-235032592 ^ (long)-235032652);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1453899388 ^ (long)-1453899302);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)876297052 ^ (long)876297130);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-328335460 ^ (long)-328335440);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1511806733 ^ (long)-1511806726);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-2015186272 ^ (long)-2015186287);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-453425990 ^ (long)-453425982);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)430827686 ^ (long)430827627);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-450159920 ^ (long)-450159927);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-445612182 ^ (long)-445612191);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1251915566 ^ (long)1251915707);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)233845404 ^ (long)233845443);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-842583873 ^ (long)-842583978);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)891020060 ^ (long)891020075);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-409403943 ^ (long)-409403939);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)640165232 ^ (long)640165189);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1324534936 ^ (long)1324534920);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1177956787 ^ (long)1177956748);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-841980950 ^ (long)-841980995);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-38859059 ^ (long)-38859213);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1432337481 ^ (long)-1432337578);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1302188311 ^ (long)-1302188449);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1016146331 ^ (long)-1016146391);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1216370497 ^ (long)1216370492);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)929913611 ^ (long)929913651);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1083005789 ^ (long)1083005724);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1312025803 ^ (long)1312025789);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1536356592 ^ (long)1536356550);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1788086828 ^ (long)-1788086967);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)229446414 ^ (long)229446464);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1383140239 ^ (long)1383140274);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)81084205 ^ (long)81084224);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1951151100 ^ (long)-1951151074);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1652109739 ^ (long)1652109662);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)719088145 ^ (long)719088328);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)123527561 ^ (long)123527605);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1106865745 ^ (long)-1106865770);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)120736805 ^ (long)120736955);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1580627389 ^ (long)-1580627310);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1507148248 ^ (long)1507148176);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1183047195 ^ (long)1183047265);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)996235452 ^ (long)996235378);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1217625227 ^ (long)-1217625242);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)95524715 ^ (long)95524844);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1736714743 ^ (long)1736714513);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1495649501 ^ (long)1495649454);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1155345930 ^ (long)1155346085);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1054054955 ^ (long)-1054054956);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1840809192 ^ (long)1840809016);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)724001877 ^ (long)724002003);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-373741396 ^ (long)-373741504);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1026831827 ^ (long)-1026831839);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)899207638 ^ (long)899207493);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)604723273 ^ (long)604723276);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1796693065 ^ (long)1796693155);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)277503945 ^ (long)277503775);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-914108144 ^ (long)-914107935);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)337994337 ^ (long)337994366);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)569482053 ^ (long)569482180);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1133861572 ^ (long)1133861473);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)73928463 ^ (long)73928497);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-671483447 ^ (long)-671483412);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-572027442 ^ (long)-572027425);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-108304719 ^ (long)-108304663);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1359249531 ^ (long)-1359249600);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)967729835 ^ (long)967729699);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1924928628 ^ (long)-1924928766);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-532458231 ^ (long)-532458158);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-24731267 ^ (long)-24731322);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)319934653 ^ (long)319934717);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1353395268 ^ (long)-1353395429);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1308234800 ^ (long)1308234930);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)962207270 ^ (long)962207234);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1532492740 ^ (long)-1532492628);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-466292222 ^ (long)-466292180);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1560107835 ^ (long)-1560107884);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)517684528 ^ (long)517684648);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1369156373 ^ (long)1369156584);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)547418380 ^ (long)547418587);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)676418289 ^ (long)676418226);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-4464595 ^ (long)-4464479);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1357607902 ^ (long)-1357607824);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1408299979 ^ (long)1408299987);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)933198599 ^ (long)933198661);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)429112089 ^ (long)429112140);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1881293489 ^ (long)-1881293457);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1069609261 ^ (long)1069609251);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-453377735 ^ (long)-453377653);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1592328321 ^ (long)1592328286);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1899133737 ^ (long)1899133722);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)645049915 ^ (long)645049951);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-530786005 ^ (long)-530785807);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1713670518 ^ (long)-1713670536);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)142660019 ^ (long)142659852);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1319431776 ^ (long)-1319431920);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)721811808 ^ (long)721811826);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)196169623 ^ (long)196169705);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)504831622 ^ (long)504831689);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1009723365 ^ (long)-1009723277);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1992256351 ^ (long)-1992256512);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-164139148 ^ (long)-164139215);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)369021085 ^ (long)369020957);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-2037963718 ^ (long)-2037963575);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-2026881127 ^ (long)-2026881159);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-2077071959 ^ (long)-2077071950);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)2059193045 ^ (long)2059193015);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1088437012 ^ (long)1088437099);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-2098072141 ^ (long)-2098072233);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)703344389 ^ (long)703344402);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)737053108 ^ (long)737053034);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-489438971 ^ (long)-489438781);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)394799386 ^ (long)394799406);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)228441576 ^ (long)228441457);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1571954869 ^ (long)-1571954732);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1877191573 ^ (long)-1877191549);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1879299945 ^ (long)1879299886);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-123693898 ^ (long)-123693961);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-470830238 ^ (long)-470830248);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1456102877 ^ (long)-1456102907);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-682328657 ^ (long)-682328696);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1377816347 ^ (long)-1377816443);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)902386891 ^ (long)902386734);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1476215197 ^ (long)1476215195);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-243885386 ^ (long)-243885360);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-375467226 ^ (long)-375467123);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1059054121 ^ (long)1059054333);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)59767059 ^ (long)59767111);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-2128149197 ^ (long)-2128148999);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1622522563 ^ (long)-1622522536);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1123780792 ^ (long)-1123780676);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1243176582 ^ (long)-1243176621);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-2134698332 ^ (long)-2134698463);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)328768709 ^ (long)328768619);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1721401027 ^ (long)-1721400930);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1347056627 ^ (long)1347056636);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1876525785 ^ (long)-1876525595);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1216235725 ^ (long)-1216235631);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1599420447 ^ (long)1599420564);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)555125734 ^ (long)555125534);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1718907260 ^ (long)1718907370);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)542980130 ^ (long)542980228);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)147602921 ^ (long)147602819);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-333972672 ^ (long)-333972638);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1962229815 ^ (long)1962229802);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)783088963 ^ (long)783089112);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1637582693 ^ (long)-1637582705);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-478884537 ^ (long)-478884579);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1594370627 ^ (long)1594370692);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-506297894 ^ (long)-506298057);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-636721153 ^ (long)-636721323);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)409572808 ^ (long)409572650);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1542925138 ^ (long)1542925083);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1587737211 ^ (long)1587737088);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1151159173 ^ (long)1151159270);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)694634540 ^ (long)694634544);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)903420796 ^ (long)903420880);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1842773954 ^ (long)-1842773841);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)692553008 ^ (long)692553151);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)2061097102 ^ (long)2061097193);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1786204622 ^ (long)-1786204606);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1560705128 ^ (long)-1560705087);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)668738038 ^ (long)668738043);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-710150458 ^ (long)-710150536);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-763008811 ^ (long)-763008864);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)808516284 ^ (long)808516346);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-221108987 ^ (long)-221108803);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)67405551 ^ (long)67405553);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-799541740 ^ (long)-799541664);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)603086117 ^ (long)603086164);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-282772871 ^ (long)-282772987);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1805392537 ^ (long)1805392570);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1828975573 ^ (long)-1828975498);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)969109826 ^ (long)969109911);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1624445982 ^ (long)-1624446031);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-483891815 ^ (long)-483891823);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)187034431 ^ (long)187034611);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1685854407 ^ (long)-1685854413);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)314359833 ^ (long)314359941);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-366956907 ^ (long)-366957055);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1337500156 ^ (long)1337500137);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-899829739 ^ (long)-899829506);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)7331706 ^ (long)7331791);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1657604268 ^ (long)-1657604201);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-414812841 ^ (long)-414812681);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-542056244 ^ (long)-542056194);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)2101700748 ^ (long)2101700826);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1402835018 ^ (long)1402835017);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1754065837 ^ (long)1754065799);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1411912836 ^ (long)-1411912837);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1343927655 ^ (long)-1343927568);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-2091193947 ^ (long)-2091193945);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1669224689 ^ (long)-1669224484);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1738205133 ^ (long)1738205119);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)978358918 ^ (long)978359002);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)391662276 ^ (long)391662131);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1461061084 ^ (long)1461060934);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)12268909 ^ (long)12268948);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1712103272 ^ (long)1712103205);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)143079645 ^ (long)143079482);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1430451956 ^ (long)1430451753);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1147118733 ^ (long)1147118629);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-926761502 ^ (long)-926761680);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)332902952 ^ (long)332903084);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-888473198 ^ (long)-888473253);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1506571011 ^ (long)-1506571138);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)333631206 ^ (long)333631069);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)2133373834 ^ (long)2133373751);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)951747882 ^ (long)951747908);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1478081160 ^ (long)1478081096);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1469070514 ^ (long)1469070363);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1307704170 ^ (long)-1307704200);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1075686562 ^ (long)1075686595);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1589444756 ^ (long)1589444611);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1114561585 ^ (long)1114561781);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1307305476 ^ (long)-1307305649);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1147627544 ^ (long)-1147627752);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)107849355 ^ (long)107849332);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1754743942 ^ (long)1754743820);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)533973050 ^ (long)533973015);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1364322808 ^ (long)1364322707);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)95203001 ^ (long)95202953);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1213007495 ^ (long)1213007485);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1913666570 ^ (long)-1913666740);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1652869152 ^ (long)1652869359);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-2112543685 ^ (long)-2112543601);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)468287414 ^ (long)468287449);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)991274889 ^ (long)991274788);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-438970971 ^ (long)-438971096);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)837956563 ^ (long)837956463);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1463058886 ^ (long)-1463058765);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-616787609 ^ (long)-616787521);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-2096078428 ^ (long)-2096078449);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-324685858 ^ (long)-324685977);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1764620315 ^ (long)1764620499);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-770644118 ^ (long)-770644166);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-196118028 ^ (long)-196118192);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-704999790 ^ (long)-704999899);
                    if (!34n.\u2004\u2007\u2000\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-893215855 ^ (long)-893215815);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1877166238 ^ (long)1877166177)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)223065776 ^ (long)223037775)) >>> (int)((long)171277270 ^ (long)171277278)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1249248899 ^ (long)-1249248899);
            if (!34n.\u2004\u2007\u2000\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)304544726 ^ (long)304544724);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1521095663 ^ (long)1521095660) | var5_6 << (int)((long)-1714205389 ^ (long)-1714205386)) ^ var3_4[var7_8]) & (int)((long)-977516752 ^ (long)-977516593);
                    if (34n.\u2004\u2007\u2000\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)639080471 ^ (long)639080468) | var6_7 << (int)((long)-340237052 ^ (long)-340237055)) ^ var3_4[var7_8]) & (int)((long)1752194280 ^ (long)1752194071);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            34n.b[var2_3] = new String(var3_4).intern();
        }
        return 34n.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static UUID 1(String string) {
        boolean bl;
        block6: {
            bl = \u2004\u2007\u2000\u2004;
            if (bl) return null;
            String[] stringArray = 3e.5();
            if (bl) return null;
            if (bl) return null;
            if ((string = string.split(2w$6X.KAOZ("\uc120", -1940166015))[(int)((long)1555661117 ^ (long)1555661117)].trim()).length() != (int)((long)-792487810 ^ (long)-792487842)) {
                if (bl) return null;
                if (string.length() != (int)((long)-1544403975 ^ (long)-1544404003)) {
                    if (bl) return null;
                    if (bl) return null;
                    throw new IllegalArgumentException(34n.a((int)((long)1815155766 ^ (long)-1815156315), (int)((long)-1491198631 ^ (long)-1491180970)) /* "Invalid length for UUID" */);
                }
            }
            if (bl) return null;
            if (string.split(2w$6X.KAOZ("\uf740", -2080744212)).length != (int)((long)491984298 ^ (long)491984303)) {
                StringBuilder stringBuilder;
                block5: {
                    if (bl) return null;
                    if (bl) return null;
                    stringBuilder = new StringBuilder();
                    if (bl) return null;
                    if (bl) return null;
                    int n = (int)((long)1676038463 ^ (long)1676038463);
                    if (bl) return null;
                    do {
                        if (bl) return null;
                        if (n >= (int)((long)-2094945441 ^ (long)-2094945409)) break block5;
                        if (bl) return null;
                        if (bl) return null;
                        stringBuilder.append(string.charAt(n));
                        if (bl) return null;
                        if (bl) return null;
                        if (stringArray != null) break block6;
                        if (bl) return null;
                        if (ArrayUtils.contains((int[])5, (int)n)) {
                            if (bl) return null;
                            if (bl) return null;
                            stringBuilder.append(2w$6X.KAOZ("\ub1c4", -420406680));
                            if (bl) return null;
                        }
                        if (bl) return null;
                        ++n;
                        if (bl) return null;
                    } while (stringArray == null);
                    if (bl) return null;
                }
                if (bl) return null;
                string = stringBuilder.toString();
                if (bl) return null;
            }
        }
        if (bl) return null;
        return UUID.fromString(string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String 2(UUID object) {
        boolean bl;
        block7: {
            bl = \u2004\u2007\u2000\u2004;
            if (bl) return null;
            try {
                if (bl) return null;
                object = 81.6(34n.a((int)((long)-2147285838 ^ (long)2147285283), (int)((long)-1943457274 ^ (long)1943449122)) /* "https://api.mojang.com/user/profiles/" */ + ((UUID)object).toString().replace(2w$6X.KAOZ("\u826f", -1554175549), 2w$6X.KAOZ("", -1280548821)) + 34n.a((int)((long)-2106924267 ^ (long)2106924679), (int)((long)602559634 ^ (long)602567067)) /* "/names" */, null);
                if (bl || bl) return null;
                if (!\u2004\u2007\u2000\u2004) break block7;
                throw null;
            }
            catch (IOException iOException) {
                if (bl || bl) return null;
                throw new IllegalStateException(iOException);
            }
        }
        if (bl) {
            return null;
        }
        JsonArray jsonArray = ((2B)object).2().getAsJsonArray();
        return jsonArray.get(jsonArray.size() - (int)((long)-600780543 ^ (long)-600780544)).getAsJsonObject().get(34n.a((int)((long)-24781529 ^ (long)24780983), (int)((long)1906926700 ^ (long)-1906933583)) /* "name" */).getAsString();
    }

    public static Optional<String> 8(UUID uUID) {
        boolean bl = \u2004\u2007\u2000\u2004;
        if (bl || bl) {
            return null;
        }
        return 7.5(uUID);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 34n.\u2004\u2007\u2000\u2004;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)206280380 ^ (long)206280376)];
            if (var7) break block25;
            var3_2 = (int)((long)-741738219 ^ (long)-741738219);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\u9747\u321e\u216e\u2927\u977b\u32b4\u214b\u29be\u97ec\u3222\u21ce\u296b\u97cb\u325d\u218b\u2943\u97fb\u3242\u2197\u2961\u972c\u3239\u2112\u29b3\u970f\u328a\u2171\u2902\u9761\u3250\u21fa\u2903\u9767\u32ca\u21db\u2971\u972e\u32b9\u2114\u290b\u9750\u321c", -184861473);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)-411092561 ^ (long)-411092565);
            if (var7) break block25;
            var0_6 = (int)((long)1946404812 ^ (long)-1946404813);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)200241516 ^ (long)200241489);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)628762784 ^ (long)-628762785);
                        if (34n.\u2004\u2007\u2000\u2004) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!34n.\u2004\u2007\u2000\u2004) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\ua805\u0df7\u1e57\u16e8\ua80c\u0db9\u1e61\u161c\ua8fc\u0ddd\u1ef4\u1662\ua80b\u0da5\u1ee3\u16da\ua8d3\u0d69\u1ea8\u1688\ua83c\u0d39\u1e1f\u1641\ua820\u0de2\u1e6e\u1624\ua82f\u0db0", 734266307);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)-1464712993 ^ (long)-1464712999);
                                var0_6 = (int)((long)283128555 ^ (long)-283128556);
                                while (true) {
                                    v0 = (int)((long)1020408646 ^ (long)1020408604);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)-760859319 ^ (long)-760859319);
                                    if (!34n.\u2004\u2007\u2000\u2004) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!34n.\u2004\u2007\u2000\u2004) ** continue;
                                    throw null;
                                }
                                34n.a = var5_1;
                                34n.b = new String[(int)((long)-1069551552 ^ (long)-1069551548)];
                                if (34n.\u2004\u2007\u2000\u2004) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)-1544920903 ^ (long)-1544920903);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)-845823252 ^ (long)-845823251)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-759534645 ^ (long)-759534644)) {
                                    case 0: {
                                        v15 = (int)((long)1510254652 ^ (long)1510254709);
                                        if (!34n.\u2004\u2007\u2000\u2004) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)-1631141170 ^ (long)-1631141136);
                                        if (!34n.\u2004\u2007\u2000\u2004) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)-26857015 ^ (long)-26857069);
                                        if (!34n.\u2004\u2007\u2000\u2004) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)-587476922 ^ (long)-587476985);
                                        if (!34n.\u2004\u2007\u2000\u2004) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)1026613434 ^ (long)1026613410);
                                        if (!34n.\u2004\u2007\u2000\u2004) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)183848833 ^ (long)183848837);
                                        if (!34n.\u2004\u2007\u2000\u2004) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)71654066 ^ (long)71654118);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!34n.\u2004\u2007\u2000\u2004);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                v17 = new int[(int)((long)-260961815 ^ (long)-260961811)];
                v17[(int)((long)510593763 ^ (long)510593763)] = (int)((long)-524310779 ^ (long)-524310782);
                v17[(int)((long)1250398636 ^ (long)1250398637)] = (int)((long)-1540309702 ^ (long)-1540309711);
                v17[(int)((long)523786813 ^ (long)523786815)] = (int)((long)-1193698179 ^ (long)-1193698190);
                v17[(int)((long)-474696553 ^ (long)-474696556)] = (int)((long)-2045794688 ^ (long)-2045794669);
                34n.5 = v17;
                v18 = new Function[(int)((long)-737107223 ^ (long)-737107221)];
                v18[(int)((long)-1647437028 ^ (long)-1647437028)] = (Function<UUID, String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, 1(java.util.UUID ), (Ljava/util/UUID;)Ljava/lang/String;)();
                v18[(int)((long)-2131366190 ^ (long)-2131366189)] = (Function<UUID, String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, 2(java.util.UUID ), (Ljava/util/UUID;)Ljava/lang/String;)();
                34n.7 = new 3M<K, V>(v18);
                break;
            }
        }
    }

    private static /* synthetic */ String 1(UUID uUID) {
        boolean bl = \u2004\u2007\u2000\u2004;
        if (bl || bl) {
            return null;
        }
        return djz.C().w().a(uUID).l().a();
    }
}

