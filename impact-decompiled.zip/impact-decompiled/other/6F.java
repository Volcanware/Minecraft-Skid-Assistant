/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.suggestion.Suggestion
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listenable
 *  me.zero.alpine.listener.Listener
 *  pc
 *  sh
 */
package net.impactclient;

import com.google.common.collect.Sets;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestion;
import java.util.LinkedHashSet;
import java.util.function.Consumer;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listenable;
import me.zero.alpine.listener.Listener;
import net.impactclient.2w$6X;
import net.impactclient.34s;
import net.impactclient.3A;
import net.impactclient.3C;
import net.impactclient.3i;
import net.impactclient.3sh;
import net.impactclient.3sp;
import net.impactclient.6w;
import net.impactclient.8H;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 6F
implements Listenable,
3sp {
    private long 9;
    @EventHandler
    private final Listener<3C> 7;
    private int 4;
    private Consumer<6w> 6;
    private 8H 2;
    @EventHandler
    private final Listener<3i> 8;
    @EventHandler
    private final Listener<3sh> 1;
    private static final String[] a;
    public static final boolean \u2009;
    private static final String[] b;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 6F.\u2009;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1464871410 ^ (long)1464862003)) & (int)((long)460152824 ^ (long)460169223);
            if (var9_2) ** GOTO lbl-1000
            if (6F.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 6F.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-721158035 ^ (long)-721158035)] & (int)((long)-1322486703 ^ (long)-1322486610)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1176284144 ^ (long)1176283978);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1956779046 ^ (long)-1956779136);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1509742087 ^ (long)1509742113);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1297027206 ^ (long)-1297027103);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-215280061 ^ (long)-215280115);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1887187774 ^ (long)1887187808);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-990204904 ^ (long)-990204722);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1819501642 ^ (long)-1819501739);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)899526079 ^ (long)899526127);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-725811013 ^ (long)-725811104);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)131460929 ^ (long)131460982);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1706852336 ^ (long)-1706852199);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-669775247 ^ (long)-669775288);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-36330732 ^ (long)-36330669);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1277517642 ^ (long)-1277517617);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)434895754 ^ (long)434895669);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)989081250 ^ (long)989081292);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-725325205 ^ (long)-725325129);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1579324763 ^ (long)-1579324817);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-233537273 ^ (long)-233537078);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1907481889 ^ (long)-1907481961);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-693092123 ^ (long)-693092187);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)911066083 ^ (long)911065875);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)623549447 ^ (long)623549690);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1928962534 ^ (long)1928962502);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1136140867 ^ (long)-1136141034);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1420445344 ^ (long)1420445252);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1980195835 ^ (long)-1980195707);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-2044942825 ^ (long)-2044942666);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1860606316 ^ (long)-1860606346);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1046494922 ^ (long)1046494825);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)954230076 ^ (long)954230080);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-435748573 ^ (long)-435748568);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1274704186 ^ (long)-1274704151);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1013223739 ^ (long)-1013223732);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)937571633 ^ (long)937571710);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-983325406 ^ (long)-983325382);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1058963038 ^ (long)1058963071);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1360459504 ^ (long)1360459313);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1620895658 ^ (long)-1620895685);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1149411719 ^ (long)-1149411666);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1222906148 ^ (long)-1222906280);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-314714727 ^ (long)-314714664);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1302329743 ^ (long)1302329787);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1818081303 ^ (long)1818081463);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1697020797 ^ (long)-1697020697);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)2092633732 ^ (long)2092633643);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1870407618 ^ (long)-1870407578);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-353586796 ^ (long)-353586701);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1792149521 ^ (long)1792149627);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-2094625520 ^ (long)-2094625355);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1766540491 ^ (long)-1766540302);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1180767239 ^ (long)1180767436);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)353228583 ^ (long)353228610);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1571260393 ^ (long)1571260176);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)466572205 ^ (long)466572273);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1153321074 ^ (long)1153320968);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1972327158 ^ (long)1972327074);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-129383465 ^ (long)-129383486);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)441424058 ^ (long)441424042);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)388581490 ^ (long)388581607);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1437152076 ^ (long)1437152122);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-750005190 ^ (long)-750005174);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)701098153 ^ (long)701098174);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1257975569 ^ (long)1257975619);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)100475159 ^ (long)100475244);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)826588639 ^ (long)826588486);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1345667535 ^ (long)-1345667501);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1291553606 ^ (long)-1291553543);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1048052712 ^ (long)-1048052534);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-2078152578 ^ (long)-2078152526);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1905449042 ^ (long)1905449143);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)644599237 ^ (long)644599066);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)516727962 ^ (long)516727984);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-486342465 ^ (long)-486342588);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)868447926 ^ (long)868447952);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)558532891 ^ (long)558533075);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-870205209 ^ (long)-870205422);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1421683158 ^ (long)1421682966);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1962506225 ^ (long)-1962506154);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1297918033 ^ (long)-1297917990);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1698777330 ^ (long)1698777217);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1540288318 ^ (long)-1540288282);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1157894359 ^ (long)1157894342);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1367816847 ^ (long)1367816764);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)677503063 ^ (long)677503175);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)461058245 ^ (long)461058301);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)159080803 ^ (long)159080844);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1998233888 ^ (long)1998234024);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1145904918 ^ (long)-1145905085);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1232150279 ^ (long)1232150289);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1541343953 ^ (long)1541343972);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)864533141 ^ (long)864532996);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-53454714 ^ (long)-53454815);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1906632746 ^ (long)1906632831);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1953985842 ^ (long)1953985940);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1497031352 ^ (long)-1497031195);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1810842502 ^ (long)1810842389);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-793111666 ^ (long)-793111799);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1549253131 ^ (long)1549253155);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)709236491 ^ (long)709236560);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-389347400 ^ (long)-389347496);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)353326757 ^ (long)353326681);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)840179390 ^ (long)840179384);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)790757990 ^ (long)790758039);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1065210477 ^ (long)-1065210499);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1158410706 ^ (long)1158410604);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)900179315 ^ (long)900179440);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)345439483 ^ (long)345439458);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1864907654 ^ (long)1864907750);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-2059600919 ^ (long)-2059601048);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-155727262 ^ (long)-155727112);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)127191737 ^ (long)127191591);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-304937005 ^ (long)-304936978);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1537951812 ^ (long)-1537951943);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1547187841 ^ (long)-1547187815);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1146193271 ^ (long)1146193316);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1235924916 ^ (long)1235924955);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)2046749975 ^ (long)2046750014);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1411631641 ^ (long)-1411631707);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)370779772 ^ (long)370779691);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1987150130 ^ (long)1987150130);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)764593961 ^ (long)764593979);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)2031428089 ^ (long)2031427955);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)738958380 ^ (long)738958451);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-2097878313 ^ (long)-2097878432);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)239174129 ^ (long)239174030);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-166893127 ^ (long)-166893176);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)2068767636 ^ (long)2068767659);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1416586331 ^ (long)-1416586480);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-719405144 ^ (long)-719405249);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1003687610 ^ (long)-1003687530);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)2129257629 ^ (long)2129257579);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)551344934 ^ (long)551344922);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-896257181 ^ (long)-896257175);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-553507950 ^ (long)-553508004);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)2081826202 ^ (long)2081826209);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1598032934 ^ (long)1598033042);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1361680107 ^ (long)1361680007);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1878424099 ^ (long)1878424265);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1166852163 ^ (long)-1166852286);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-323445878 ^ (long)-323445840);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1578508232 ^ (long)1578508119);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1797028601 ^ (long)1797028493);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-669552642 ^ (long)-669552641);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-165072733 ^ (long)-165072722);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-510543519 ^ (long)-510543506);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)803483016 ^ (long)803483107);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-961908898 ^ (long)-961908801);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-182765400 ^ (long)-182765478);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)814132224 ^ (long)814132227);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1844097614 ^ (long)1844097760);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-81747910 ^ (long)-81747902);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-281486555 ^ (long)-281486472);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-550368936 ^ (long)-550368849);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1494254838 ^ (long)1494254619);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1307121740 ^ (long)-1307121811);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1661783534 ^ (long)-1661783320);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)744244621 ^ (long)744244568);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1810794012 ^ (long)-1810794122);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1733464984 ^ (long)1733465033);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1425790247 ^ (long)1425790353);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)3870245 ^ (long)3870435);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1980471950 ^ (long)1980471913);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-791121974 ^ (long)-791121996);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-34356774 ^ (long)-34356973);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1391676252 ^ (long)1391676274);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1121232411 ^ (long)-1121232602);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-300678743 ^ (long)-300678726);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1304929036 ^ (long)-1304929143);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1234272419 ^ (long)1234272379);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-124752370 ^ (long)-124752382);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1492984911 ^ (long)-1492984872);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1022724763 ^ (long)-1022724817);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-995691809 ^ (long)-995691859);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)359484730 ^ (long)359484787);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1770762337 ^ (long)1770762471);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)194851216 ^ (long)194851214);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-794126555 ^ (long)-794126559);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-315808483 ^ (long)-315808283);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)371427696 ^ (long)371427644);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-856297091 ^ (long)-856297007);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1070575852 ^ (long)-1070575850);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)2071437020 ^ (long)2071436951);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1084625784 ^ (long)-1084625869);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)2147293819 ^ (long)2147293813);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1483555017 ^ (long)1483554939);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)834219413 ^ (long)834219401);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-876967541 ^ (long)-876967495);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)973521470 ^ (long)973521421);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1406538424 ^ (long)1406538240);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1634103881 ^ (long)1634103991);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-154695450 ^ (long)-154695575);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1416027670 ^ (long)1416027851);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1900046403 ^ (long)-1900046442);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)452262814 ^ (long)452262787);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1946286087 ^ (long)1946286099);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)518150457 ^ (long)518150557);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1911382150 ^ (long)1911382083);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-989085879 ^ (long)-989085846);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-287752532 ^ (long)-287752576);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-155316620 ^ (long)-155316566);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1979864992 ^ (long)1979865032);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)2098236101 ^ (long)2098236127);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-208109552 ^ (long)-208109434);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1328580538 ^ (long)1328580408);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-2036139389 ^ (long)-2036139479);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)627593021 ^ (long)627593081);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-711005167 ^ (long)-711005024);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-977582042 ^ (long)-977582056);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1179530361 ^ (long)1179530287);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1633629322 ^ (long)1633629190);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)336855757 ^ (long)336855633);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-205339403 ^ (long)-205339498);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)322925863 ^ (long)322926035);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1356124791 ^ (long)-1356124674);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1297690924 ^ (long)-1297690974);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1451521542 ^ (long)1451521672);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)445400772 ^ (long)445400757);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-880241922 ^ (long)-880242116);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)527761093 ^ (long)527761005);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)174294298 ^ (long)174294327);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1751710745 ^ (long)-1751710882);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)867891842 ^ (long)867891818);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1093276743 ^ (long)1093276844);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1539034639 ^ (long)-1539034843);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1667340295 ^ (long)1667340290);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1201915593 ^ (long)-1201915600);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1076755264 ^ (long)-1076755430);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1228640596 ^ (long)-1228640585);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1509481448 ^ (long)-1509481228);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1888078189 ^ (long)1888078288);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)817187157 ^ (long)817187265);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-834728739 ^ (long)-834728863);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)805901359 ^ (long)805901471);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1786261652 ^ (long)1786261683);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1384758472 ^ (long)1384758279);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1755165482 ^ (long)1755165543);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1095488984 ^ (long)-1095489011);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1878626505 ^ (long)-1878626460);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)148865071 ^ (long)148865244);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-772096230 ^ (long)-772096214);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1764319882 ^ (long)1764319893);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1463490077 ^ (long)1463490172);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1922875952 ^ (long)-1922876067);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)377171371 ^ (long)377171438);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1602254629 ^ (long)-1602254817);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-665182047 ^ (long)-665182077);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)424744609 ^ (long)424744508);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1714303067 ^ (long)1714303114);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)599626046 ^ (long)599626104);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1788704636 ^ (long)1788704734);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)72005327 ^ (long)72005158);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-258625216 ^ (long)-258625077);
                    if (!6F.\u2009) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)89720296 ^ (long)89720176);
                    if (!6F.\u2009) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-239779251 ^ (long)-239779259);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-655659898 ^ (long)-655659911)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)365797376 ^ (long)365780991)) >>> (int)((long)-2078524121 ^ (long)-2078524113)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1907525820 ^ (long)-1907525820);
            if (!6F.\u2009) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1056837277 ^ (long)1056837279);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-2012497185 ^ (long)-2012497188) | var5_6 << (int)((long)-753990483 ^ (long)-753990488)) ^ var3_4[var7_8]) & (int)((long)172691492 ^ (long)172691675);
                    if (6F.\u2009) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)880655984 ^ (long)880655987) | var6_7 << (int)((long)84753613 ^ (long)84753608)) ^ var3_4[var7_8]) & (int)((long)1488816078 ^ (long)1488815921);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            6F.b[var2_3] = new String(var3_4).intern();
        }
        return 6F.b[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 6F.\u2009;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)15373944 ^ (long)15373948)];
            if (var7) break block23;
            var3_2 = (int)((long)1063561151 ^ (long)1063561151);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u4833\u60de\u7371\u7b17\u48bd\u609b\u73d6\u7bbd\u4804\u6014\u73c5\u7bd4\u4824\u60a2\u73d8\u7b81", -1860866373);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-316771645 ^ (long)-316771638);
            if (var7) break block23;
            var0_6 = (int)((long)1570614751 ^ (long)-1570614752);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1349750702 ^ (long)1349750687);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1704040888 ^ (long)1704040887);
                    if (6F.\u2009) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!6F.\u2009) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u2d7a\u0580\u160a\u1ed4\u2dbd\u0565\u1690\u1e90\u2dee\u05c8\u16ec\u1e40\u2db5\u05c0\u16ee\u1e85\u2d67\u0556\u16d1\u1eba\u2df9\u05fc\u16a5\u1e84\u2d6a\u05a7\u160f", -1843983468);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-960154302 ^ (long)-960154278);
                            var0_6 = (int)((long)1743471547 ^ (long)-1743471548);
                            while (true) {
                                v0 = (int)((long)-2024653710 ^ (long)-2024653774);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1012216067 ^ (long)-1012216067);
                                if (!6F.\u2009) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!6F.\u2009) ** continue;
                                throw null;
                            }
                            6F.a = var5_1;
                            6F.b = new String[(int)((long)-372169382 ^ (long)-372169378)];
                            if (!6F.\u2009) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1409061393 ^ (long)1409061393);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-324035006 ^ (long)-324035005)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)689076411 ^ (long)689076412)) {
                                case 0: {
                                    v15 = (int)((long)636239120 ^ (long)636239147);
                                    if (!6F.\u2009) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1282980686 ^ (long)1282980731);
                                    if (!6F.\u2009) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-183698520 ^ (long)-183698553);
                                    if (!6F.\u2009) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1087211993 ^ (long)1087211965);
                                    if (!6F.\u2009) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)322861680 ^ (long)322861655);
                                    if (!6F.\u2009) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1713823815 ^ (long)1713823811);
                                    if (!6F.\u2009) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)2079991365 ^ (long)2079991391);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!6F.\u2009);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 3(Consumer<6w> consumer) {
        block3: {
            block2: {
                boolean bl = \u2009;
                if (bl || bl) break block2;
                this.2.0();
                if (bl || bl) break block2;
                this.9 = 0x7B3D32F0670549ADL ^ 0x7B3D32F067056EBDL;
                if (bl || bl) break block2;
                3A.6.subscribe(this);
                if (bl || bl) break block2;
                this.6 = consumer;
                if (bl || bl) break block2;
                this.4 = (int)((long)-101628445 ^ (long)101628444);
                if (bl || bl) break block2;
                6F.3.s.e.b().a(new CommandContext(null, 2w$6X.KAOZ("\ub8f9", -1639735766), null, null, null, null, null, null, null, (boolean)((long)-1963160964 ^ (long)-1963160964)), null);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 6F() {
        block3: {
            block2: {
                boolean bl = \u2009;
                if (bl || bl) break block2;
                this.2 = new 8H();
                if (bl || bl) break block2;
                Predicate[] predicateArray = new Predicate[(int)((long)749478498 ^ (long)749478499)];
                predicateArray[(int)((long)1522472426 ^ (long)1522472426)] = sh -> {
                    boolean bl = \u2009;
                    if (bl || bl) {
                        return true;
                    }
                    return this.2.8(this.9);
                };
                this.1 = new Listener(sh -> {
                    block3: {
                        block2: {
                            boolean bl = \u2009;
                            if (bl || bl) break block2;
                            3A.6.unsubscribe(this);
                            if (bl || bl) break block2;
                            this.6.accept(new 6w(6F.a((int)((long)1418292216 ^ (long)1418282811), (int)((long)532857005 ^ (long)-532849788)) /* "Request timed out after " */ + this.9 + 6F.a((int)((long)-994436402 ^ (long)-994429428), (int)((long)-25768546 ^ (long)25768446)) /* "ms" */));
                            if (!bl && !bl) break block3;
                        }
                        return;
                    }
                }, predicateArray);
                if (bl || bl) break block2;
                Predicate[] predicateArray2 = new Predicate[(int)((long)2126767892 ^ (long)2126767893)];
                Class[] classArray = new Class[(int)((long)179523419 ^ (long)179523418)];
                classArray[(int)((long)2045164818 ^ (long)2045164818)] = sh.class;
                predicateArray2[(int)((long)235098857 ^ (long)235098857)] = new 34s(classArray);
                this.7 = new Listener(c2 -> {
                    block4: {
                        block2: {
                            boolean bl;
                            block3: {
                                bl = \u2009;
                                if (bl || bl) break block2;
                                if (this.4 >= 0) break block3;
                                if (bl || bl) break block2;
                                c2 = (sh)c2.7;
                                if (bl || bl) break block2;
                                this.4 = c2.b();
                                if (bl) break block2;
                            }
                            if (!bl) break block4;
                        }
                        return;
                    }
                }, predicateArray2);
                if (bl || bl) break block2;
                Predicate[] predicateArray3 = new Predicate[(int)((long)1088987627 ^ (long)1088987626)];
                Class[] classArray2 = new Class[(int)((long)-853884341 ^ (long)-853884342)];
                classArray2[(int)((long)-2118266785 ^ (long)-2118266785)] = pc.class;
                predicateArray3[(int)((long)1576153649 ^ (long)1576153649)] = new 34s(classArray2);
                this.8 = new Listener(i -> {
                    boolean bl = \u2009;
                    if (bl || bl) return;
                    if (i.2 != EventState.POST) {
                        if (bl || bl) return;
                        return;
                    }
                    if (bl) return;
                    i = (pc)i.7;
                    if (i.b() != this.4) {
                        if (bl || bl) return;
                        return;
                    }
                    if (bl) return;
                    LinkedHashSet linkedHashSet = Sets.newLinkedHashSet();
                    if (bl || bl) return;
                    i.c().getList().stream().map(Suggestion::getText).filter(string -> {
                        boolean bl = \u2009;
                        if (bl || bl) {
                            return true;
                        }
                        return string.contains(2w$6X.KAOZ("\u290d", -174780469));
                    }).forEach(string -> {
                        block4: {
                            block2: {
                                boolean bl;
                                block3: {
                                    bl = \u2009;
                                    if (bl || bl) break block2;
                                    string = string.split(2w$6X.KAOZ("\u2daf", -366277783))[(int)((long)1599896464 ^ (long)1599896464)].replaceFirst(2w$6X.KAOZ("\u237b", -23525976), 2w$6X.KAOZ("", -718639905));
                                    if (bl || bl) break block2;
                                    if (linkedHashSet.contains(string)) break block3;
                                    if (bl) break block2;
                                    if (string.equalsIgnoreCase(6F.a((int)((long)-104769371 ^ (long)-104762268), (int)((long)2058570569 ^ (long)2058578907)) /* "minecraft" */)) break block3;
                                    if (bl) break block2;
                                    if (string.equalsIgnoreCase(6F.a((int)((long)668784307 ^ (long)668793459), (int)((long)1732728038 ^ (long)-1732712346)) /* "bukkit" */)) break block3;
                                    if (bl || bl) break block2;
                                    linkedHashSet.add(string);
                                    if (bl) break block2;
                                }
                                if (!bl) break block4;
                            }
                            return;
                        }
                    });
                    if (bl || bl) return;
                    this.6.accept(new 6w(linkedHashSet));
                    if (bl || bl) return;
                    this.6 = null;
                    if (bl || bl) return;
                    3A.6.unsubscribe(this);
                    if (!bl && !bl) return;
                }, predicateArray3);
                if (!bl) break block3;
            }
            return;
        }
    }
}

