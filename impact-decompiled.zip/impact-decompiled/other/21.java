/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  org.apache.logging.log4j.Level
 */
package net.impactclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.reflect.Type;
import java.util.Map;
import net.impactclient.2w$6X;
import net.impactclient.349;
import net.impactclient.3K;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.5w;
import net.impactclient.5z;
import net.impactclient.6e;
import net.impactclient.7m;
import net.impactclient.90;
import org.apache.logging.log4j.Level;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@Deprecated
public final class 21
implements 349<Boolean> {
    private static final String[] a;
    public static final boolean \u2004\u200c;
    private static final String[] b;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 21.\u2004\u200c;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)449923704 ^ (long)449923700)];
            if (var7) break block23;
            var3_2 = (int)((long)-804589542 ^ (long)-804589542);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\uf135\ud99a\uca5b\uc2a3\uf169\ud953\ucab1\uc278\uf1c7\ud94a\ucab6\uc22d\uf112\ud90b\uca8e\uc2c3\uf122\ud920\ucaab\uc2f2\uf177\ud9a8\uca75\uc2fe\uf156\ud94a\ucacd\uc20b\uf14f\ud919\uca85\uc2b8\uf190\ud9fc\uca9f\uc26a\uf1a2\ud953\ucaa7\uc24c\uf139\ud986\ucad9\uc278\uf1b9\ud92e\ucaba\uc2d7\uf107\ud93f\uca2a\uc254\uf184\ud96c\ucacb\uc2c5\uf123\ud941\uca42\uc284\uf13f\ud960\uca88\uc2ae\uf169\ud936\uca63\uc267\uf16a\ud9bd\ucab6\uc279\uf1c3\ud90f\ucabc\uc2c2\uf1ca\ud9be\ucabe\uc237\uf14c\ud999\uca84\uc2a8\uf1b0\ud9fe\uca9b\uc22a\uf122\ud95b\ucab7\uc24d\uf13b\ud9a6\uca99\uc27c\uf1b1\ud9ae\ucabb\uc2c7\uf127\ud93d\uca2e\uc214\uf104\ud964\ucadb\uc2c4\uf121\ud961\uca02\uc280\uf137", -1089022201);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1763349951 ^ (long)1763349945);
            if (var7) break block23;
            var0_6 = (int)((long)1203784272 ^ (long)-1203784273);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)794791297 ^ (long)794791347);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-369880222 ^ (long)369880221);
                    if (21.\u2004\u200c) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!21.\u2004\u200c) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u91e4\ub9aa\uaa7b\ua20e\u91f3\ub911\uaafc", 616871882);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)1069577868 ^ (long)1069577870);
                            var0_6 = (int)((long)-1587937817 ^ (long)1587937816);
                            while (true) {
                                v0 = (int)((long)458694598 ^ (long)458694654);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1862007653 ^ (long)-1862007653);
                                if (!21.\u2004\u200c) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!21.\u2004\u200c) ** continue;
                                throw null;
                            }
                            21.a = var5_1;
                            21.b = new String[(int)((long)-1821376086 ^ (long)-1821376090)];
                            if (!21.\u2004\u200c) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)664118122 ^ (long)664118122);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)380949954 ^ (long)380949955)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)191516194 ^ (long)191516197)) {
                                case 0: {
                                    v15 = (int)((long)1036006563 ^ (long)1036006528);
                                    if (!21.\u2004\u200c) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)111297250 ^ (long)111297279);
                                    if (!21.\u2004\u200c) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1969969204 ^ (long)-1969969206);
                                    if (!21.\u2004\u200c) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-2069038808 ^ (long)-2069038812);
                                    if (!21.\u2004\u200c) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1125277977 ^ (long)1125277969);
                                    if (!21.\u2004\u200c) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1024787108 ^ (long)-1024787120);
                                    if (!21.\u2004\u200c) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1616310773 ^ (long)1616310695);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!21.\u2004\u200c);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 21() {
        boolean bl = \u2004\u200c;
        if (bl) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 21.\u2004\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-365909502 ^ (long)-365909788)) & (int)((long)1528884622 ^ (long)1528828529);
            if (var9_2) ** GOTO lbl-1000
            if (21.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 21.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)176676466 ^ (long)176676466)] & (int)((long)136941426 ^ (long)136941453)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-144243665 ^ (long)-144243612);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)2111160696 ^ (long)2111160722);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)792988019 ^ (long)792987985);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1804630560 ^ (long)-1804630549);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-151542593 ^ (long)-151542617);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)845365034 ^ (long)845365110);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)259701348 ^ (long)259701425);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-523038816 ^ (long)-523038958);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1355068736 ^ (long)1355068687);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1006410808 ^ (long)1006410878);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-436515126 ^ (long)-436515184);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1086314695 ^ (long)1086314644);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-806183783 ^ (long)-806183901);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-729643146 ^ (long)-729643201);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-204246103 ^ (long)-204246243);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1597478255 ^ (long)-1597478387);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1752342117 ^ (long)-1752342180);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-635853880 ^ (long)-635853915);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-951597054 ^ (long)-951596849);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)138261638 ^ (long)138261733);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1614856863 ^ (long)1614856732);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-56321612 ^ (long)-56321662);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-433425077 ^ (long)-433424935);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1769390486 ^ (long)-1769390447);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-599267418 ^ (long)-599267468);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)482941887 ^ (long)482941900);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)943820854 ^ (long)943820996);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)814612304 ^ (long)814612242);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)995878794 ^ (long)995878736);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1324752669 ^ (long)-1324752730);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1473840417 ^ (long)1473840590);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1732538905 ^ (long)1732538969);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)321886357 ^ (long)321886374);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-827002324 ^ (long)-827002219);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1515248103 ^ (long)1515248049);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1959452999 ^ (long)-1959452986);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1865780373 ^ (long)1865780453);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1558789570 ^ (long)1558789598);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-2002743585 ^ (long)-2002743597);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1018709231 ^ (long)1018709186);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)578505234 ^ (long)578505352);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)371469986 ^ (long)371470022);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-2103022186 ^ (long)-2103022290);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)691009086 ^ (long)691009103);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-86433685 ^ (long)-86433651);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)931403187 ^ (long)931403224);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1349091938 ^ (long)1349091926);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)99507766 ^ (long)99507756);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)349687581 ^ (long)349687763);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)592681755 ^ (long)592681845);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)729285930 ^ (long)729285951);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1441195408 ^ (long)-1441195431);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)586187347 ^ (long)586187282);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-874474345 ^ (long)-874474304);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)31118297 ^ (long)31118292);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1476321440 ^ (long)1476321312);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1908141569 ^ (long)1908141742);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-853974337 ^ (long)-853974397);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1020325721 ^ (long)-1020325790);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)993255201 ^ (long)993255258);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-239820867 ^ (long)-239820828);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)2144594889 ^ (long)2144594785);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-213090435 ^ (long)-213090382);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-2052680495 ^ (long)-2052680485);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1529467265 ^ (long)-1529467180);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-820618018 ^ (long)-820618114);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1088002076 ^ (long)-1088002093);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1265513310 ^ (long)1265513333);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-895475208 ^ (long)-895475210);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1158943400 ^ (long)1158943381);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1104185504 ^ (long)1104185416);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1821291202 ^ (long)-1821291168);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1569146179 ^ (long)-1569146159);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-817431107 ^ (long)-817431279);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1126630725 ^ (long)-1126630845);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1509072029 ^ (long)-1509071880);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)395364234 ^ (long)395364340);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1864203576 ^ (long)1864203677);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)896242057 ^ (long)896242013);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-81790858 ^ (long)-81790781);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-2026509032 ^ (long)-2026508936);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-610515876 ^ (long)-610515722);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-414933562 ^ (long)-414933754);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-2095737978 ^ (long)-2095738058);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)2007189256 ^ (long)2007189441);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1140028042 ^ (long)1140028151);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1194066880 ^ (long)-1194066797);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)583783887 ^ (long)583783890);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1448775055 ^ (long)-1448775038);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1642843915 ^ (long)-1642844139);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1661692397 ^ (long)1661692403);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1379952791 ^ (long)1379952829);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1115212047 ^ (long)-1115212103);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1225041220 ^ (long)-1225041206);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1951866392 ^ (long)-1951866498);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1441858378 ^ (long)1441858370);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1682209331 ^ (long)1682209444);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)394946479 ^ (long)394946424);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-377354211 ^ (long)-377354176);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-973128500 ^ (long)-973128488);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)530972993 ^ (long)530973160);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)2101299204 ^ (long)2101299356);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1770329507 ^ (long)1770329349);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)371539663 ^ (long)371539709);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1681192172 ^ (long)-1681192055);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1528624268 ^ (long)-1528624202);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-2023920468 ^ (long)-2023920396);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)798337904 ^ (long)798338044);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1938033593 ^ (long)-1938033557);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)393160435 ^ (long)393160359);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1109538835 ^ (long)1109538923);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1700160332 ^ (long)1700160402);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-2047382648 ^ (long)-2047382774);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-415479679 ^ (long)-415479646);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-532560147 ^ (long)-532560223);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-876740061 ^ (long)-876739844);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1005164378 ^ (long)1005164289);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)8974910 ^ (long)8975067);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1717537890 ^ (long)-1717537888);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)180175496 ^ (long)180175374);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-516984976 ^ (long)-516984937);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1106599844 ^ (long)-1106599701);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)744766145 ^ (long)744766004);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)462484665 ^ (long)462484723);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)301965069 ^ (long)301965172);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1442312630 ^ (long)1442312456);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1421234794 ^ (long)1421234699);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1173610633 ^ (long)-1173610499);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)580922254 ^ (long)580922347);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1130980049 ^ (long)1130979861);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1757030845 ^ (long)1757030681);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-302794452 ^ (long)-302794433);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1370624502 ^ (long)1370624415);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1859922412 ^ (long)1859922259);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)598941037 ^ (long)598941100);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1443695695 ^ (long)1443695777);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1752100405 ^ (long)-1752100405);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1162541844 ^ (long)1162541835);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-431939169 ^ (long)-431939154);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1709814896 ^ (long)-1709814809);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)476825574 ^ (long)476825573);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)504730980 ^ (long)504730994);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)2024344517 ^ (long)2024344565);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1138373051 ^ (long)-1138372924);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)91084970 ^ (long)91084945);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1304030153 ^ (long)1304029962);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1423653095 ^ (long)1423653080);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1555195803 ^ (long)1555195864);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)828968202 ^ (long)828968334);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-296155285 ^ (long)-296155313);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1534983114 ^ (long)1534983147);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1612557298 ^ (long)-1612557208);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1323512272 ^ (long)1323512212);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1521314035 ^ (long)-1521314011);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1370382656 ^ (long)1370382728);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)330198634 ^ (long)330198536);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1728365570 ^ (long)-1728365816);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1547503568 ^ (long)1547503489);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1791076787 ^ (long)1791076765);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)358851676 ^ (long)358851685);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)2139664179 ^ (long)2139664150);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1296803655 ^ (long)1296803670);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-966359918 ^ (long)-966360028);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1016044872 ^ (long)1016044964);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1157720216 ^ (long)-1157720205);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)357596591 ^ (long)357596600);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1156326052 ^ (long)-1156326075);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)96428005 ^ (long)96427938);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-909032117 ^ (long)-909032187);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)733612467 ^ (long)733612308);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-446206307 ^ (long)-446206389);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1176592854 ^ (long)1176592731);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1451460500 ^ (long)-1451460385);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1860530345 ^ (long)-1860530183);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1250378624 ^ (long)-1250378518);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1361529809 ^ (long)1361529694);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-861889948 ^ (long)-861889795);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1522034837 ^ (long)-1522034876);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-2117424537 ^ (long)-2117424632);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1305767205 ^ (long)1305767350);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-790260329 ^ (long)-790260377);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-2088632670 ^ (long)-2088632762);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1360606046 ^ (long)-1360606087);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)807163457 ^ (long)807163579);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)944992622 ^ (long)944992619);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1960979021 ^ (long)1960979023);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1505835484 ^ (long)-1505835434);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)701352474 ^ (long)701352668);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-85893110 ^ (long)-85892869);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1002155655 ^ (long)1002155641);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)802394159 ^ (long)802394135);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-818285396 ^ (long)-818285534);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)118763303 ^ (long)118763510);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-523801469 ^ (long)-523801437);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-384259410 ^ (long)-384259386);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1049466200 ^ (long)1049466339);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1184810342 ^ (long)1184810385);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)657470762 ^ (long)657470931);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-538535536 ^ (long)-538535572);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1864311565 ^ (long)-1864311596);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-900798714 ^ (long)-900798573);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)787979989 ^ (long)787979880);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-308762815 ^ (long)-308762827);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-146503873 ^ (long)-146503931);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-709766247 ^ (long)-709766261);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1169474824 ^ (long)-1169474850);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1303411993 ^ (long)-1303412078);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-693527577 ^ (long)-693527638);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1555171864 ^ (long)-1555171848);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1326235593 ^ (long)-1326235417);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)359638099 ^ (long)359638103);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1770364534 ^ (long)1770364618);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)8204655 ^ (long)8204774);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1490133461 ^ (long)1490133300);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1331106702 ^ (long)1331106626);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1848848803 ^ (long)-1848848678);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1337108132 ^ (long)1337108219);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-319125427 ^ (long)-319125359);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1158817469 ^ (long)1158817311);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-437676777 ^ (long)-437676766);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-663517467 ^ (long)-663517649);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1246956870 ^ (long)-1246956953);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-97406619 ^ (long)-97406475);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1833463914 ^ (long)1833463830);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)143743288 ^ (long)143743289);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1109783205 ^ (long)-1109783236);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1728121647 ^ (long)-1728121634);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)493558793 ^ (long)493559030);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)635815331 ^ (long)635815233);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)704223071 ^ (long)704223168);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1271154377 ^ (long)-1271154263);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1460422834 ^ (long)1460422887);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)674685224 ^ (long)674685404);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)883977722 ^ (long)883977599);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1492820372 ^ (long)-1492820300);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1179976402 ^ (long)-1179976317);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1889093015 ^ (long)-1889092988);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1503083488 ^ (long)1503083293);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1120186087 ^ (long)-1120185920);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1896945099 ^ (long)1896945002);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1931875155 ^ (long)1931875298);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)839873859 ^ (long)839873809);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1107513414 ^ (long)1107513485);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)978613176 ^ (long)978613036);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1152439963 ^ (long)-1152439924);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)66266856 ^ (long)66266635);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1565380407 ^ (long)1565380518);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)868793065 ^ (long)868792979);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)999480318 ^ (long)999480313);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1987293959 ^ (long)-1987294094);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1834443142 ^ (long)1834443117);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-120712284 ^ (long)-120712204);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1868133385 ^ (long)-1868133548);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)844995398 ^ (long)844995392);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1453276945 ^ (long)-1453277081);
                    if (!21.\u2004\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)2009300621 ^ (long)2009300612);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-449624111 ^ (long)-449624274)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1414796262 ^ (long)-1414851611)) >>> (int)((long)997992866 ^ (long)997992874)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1145168893 ^ (long)1145168893);
            if (!21.\u2004\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1631756626 ^ (long)-1631756628);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1582399540 ^ (long)-1582399537) | var5_6 << (int)((long)-1560578963 ^ (long)-1560578968)) ^ var3_4[var7_8]) & (int)((long)-134982594 ^ (long)-134982463);
                    if (21.\u2004\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1856441938 ^ (long)1856441937) | var6_7 << (int)((long)-643353055 ^ (long)-643353052)) ^ var3_4[var7_8]) & (int)((long)838418262 ^ (long)838418345);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            21.b[var2_3] = new String(var3_4).intern();
        }
        return 21.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 1(90 var1_1, JsonArray jsonArray) {
        block3: {
            block2: {
                boolean bl = \u2004\u200c;
                if (bl || bl) break block2;
                jsonArray.forEach(jsonElement -> {
                    boolean bl;
                    block11: {
                        block10: {
                            bl = \u2004\u200c;
                            if (bl || bl) return;
                            if (!jsonElement.isJsonObject()) {
                                if (bl || bl) return;
                                return;
                            }
                            if (bl) return;
                            if (!(jsonElement = jsonElement.getAsJsonObject()).has(21.a((int)((long)-1618258989 ^ (long)-1618259657), (int)((long)2133744209 ^ (long)2133737774)) /* "name" */)) break block10;
                            if (bl) return;
                            if (!jsonElement.get(21.a((int)((long)-2082410419 ^ (long)-2082409815), (int)((long)1563397760 ^ (long)1563399679)) /* "name" */).isJsonPrimitive()) break block10;
                            if (bl) return;
                            var1_1 = ((90)object).1.6(jsonElement.get(21.a((int)((long)179909505 ^ (long)179908965), (int)((long)-1990802221 ^ (long)-1990795348)) /* "name" */).getAsString());
                            if (var1_1 != null) break block11;
                            if (bl) return;
                        }
                        if (bl) return;
                        return;
                    }
                    if (bl) return;
                    jsonElement.entrySet().forEach(arg_0 -> 21.9((3X)((Object)var1_1), arg_0));
                    if (!bl && !bl) return;
                });
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean 9(Type type) {
        boolean bl;
        block7: {
            block8: {
                bl = \u2004\u200c;
                if (bl || bl) return true;
                if (!(type instanceof Class)) break block7;
                if (bl) return true;
                if (Boolean.class.isAssignableFrom((Class)type)) break block8;
                if (bl) return true;
                if (!Boolean.TYPE.isAssignableFrom((Class)type)) break block7;
                if (bl) return true;
            }
            if (bl) return true;
            return (int)((long)1422278397 ^ (long)1422278396) != 0;
        }
        if (!bl) return (int)((long)1074176134 ^ (long)1074176134) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static /* synthetic */ void 9(3X x, Map.Entry entry) {
        boolean bl = \u2004\u200c;
        if (bl || bl) return;
        String string = (String)entry.getKey();
        if (bl || bl) return;
        entry = (JsonElement)entry.getValue();
        if (bl) return;
        try {
            if (bl) return;
            if (string.equals(21.a((int)((long)800966395 ^ (long)800965661), (int)((long)-38091228 ^ (long)38084750)))) {
                if (bl) return;
                if (entry.isJsonArray()) {
                    if (bl || bl) return;
                    3K.4(x, entry.getAsJsonArray());
                    if (bl) return;
                }
            }
            if (bl) return;
            if (string.equals(21.a((int)((long)-1124148251 ^ (long)-1124148987), (int)((long)-698658296 ^ (long)698671627)) /* "modes" */)) {
                if (bl) return;
                if (entry.isJsonArray()) {
                    if (bl) return;
                    if (x.4()) {
                        if (bl || bl) return;
                        entry.getAsJsonArray().forEach(jsonElement -> {
                            block4: {
                                block2: {
                                    boolean bl;
                                    block3: {
                                        bl = \u2004\u200c;
                                        if (bl || bl) break block2;
                                        if (!jsonElement.isJsonObject()) break block3;
                                        if (bl || bl) break block2;
                                        21.1(x, jsonElement.getAsJsonObject());
                                        if (bl) break block2;
                                    }
                                    if (!bl) break block4;
                                }
                                return;
                            }
                        });
                        if (bl) return;
                    }
                }
            }
            if (bl) return;
            6e.9(x, string, (JsonElement)entry);
            if (bl || bl) return;
            return;
        }
        catch (Exception exception) {
            if (bl || bl) return;
            5z.9.log(Level.WARN, 21.a((int)((long)-1879749323 ^ (long)-1879748646), (int)((long)1757331033 ^ (long)-1757332186)) /* "Unable to load setting for {}.{}" */, (Object)x.2(), (Object)string);
            if (bl || bl) return;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final /* synthetic */ Object 9(5w object, Type type, String string) {
        boolean bl = \u2004\u200c;
        if (bl) return null;
        object = string.toLowerCase();
        String[] stringArray = 3e.5();
        if (bl) return null;
        int n = (int)((long)871936064 ^ (long)-871936065);
        if (bl) return null;
        switch (((String)object).hashCode()) {
            case 3569038: {
                if (bl) return null;
                if (!((String)object).equals(21.a((int)((long)1224062965 ^ (long)1224062232), (int)((long)-1347238131 ^ (long)1347236692)) /* "true" */)) break;
                if (bl) return null;
                n = (int)((long)-779412484 ^ (long)-779412484);
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 119527: {
                if (bl) return null;
                if (!((String)object).equals(21.a((int)((long)-393358587 ^ (long)-393358878), (int)((long)-1134108707 ^ (long)-1134121032)) /* "yes" */)) break;
                if (bl) return null;
                n = (int)((long)-2111938390 ^ (long)-2111938389);
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 49: {
                if (bl) return null;
                if (!((String)object).equals(2w$6X.KAOZ("\ucbd6", 1500441996))) break;
                if (bl) return null;
                n = (int)((long)2132219986 ^ (long)2132219984);
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 97196323: {
                if (bl) return null;
                if (!((String)object).equals(21.a((int)((long)-181631880 ^ (long)-181631331), (int)((long)259247028 ^ (long)-259259403)) /* "false" */)) break;
                if (bl) return null;
                n = (int)((long)824558877 ^ (long)824558878);
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 3521: {
                if (bl) return null;
                if (!((String)object).equals(21.a((int)((long)626895457 ^ (long)626894989), (int)((long)-1961021859 ^ (long)-1961019493)) /* "no" */)) break;
                if (bl) return null;
                n = (int)((long)-618027045 ^ (long)-618027041);
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 48: {
                if (bl) return null;
                if (!((String)object).equals(2w$6X.KAOZ("\udf29", 1973156210))) break;
                if (bl) return null;
                n = (int)((long)1810025452 ^ (long)1810025449);
                if (bl) return null;
                break;
            }
        }
        if (bl) return null;
        switch (n) {
            case 0: 
            case 1: 
            case 2: {
                if (bl) return null;
                return Boolean.TRUE;
            }
            case 3: 
            case 4: 
            case 5: {
                if (bl) return null;
                return Boolean.FALSE;
            }
            default: {
                if (!bl) return null;
            }
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    static void 1(3X x, JsonObject jsonObject) {
        7m m;
        boolean bl;
        block8: {
            block7: {
                bl = \u2004\u200c;
                if (bl || bl) return;
                if (!jsonObject.has(21.a((int)((long)-310678929 ^ (long)-310679423), (int)((long)-853596669 ^ (long)-853573936)))) break block7;
                if (bl) return;
                if (!jsonObject.get(21.a((int)((long)2132157481 ^ (long)2132158157), (int)((long)-650394994 ^ (long)-650389007)) /* "name" */).isJsonPrimitive()) break block7;
                if (bl) return;
                m = x.9(jsonObject.get(21.a((int)((long)1841132 ^ (long)1840392), (int)((long)2056299383 ^ (long)2056304648)) /* "name" */).getAsString());
                if (m != null) break block8;
                if (bl) return;
            }
            if (bl) return;
            return;
        }
        if (bl) return;
        jsonObject.entrySet().forEach(entry -> {
            boolean bl = \u2004\u200c;
            if (bl || bl) return;
            String string = (String)entry.getKey();
            if (bl || bl) return;
            entry = (JsonElement)entry.getValue();
            if (bl) return;
            try {
                if (bl) return;
                if (string.equals(21.a((int)((long)817021566 ^ (long)817021084), (int)((long)1461230858 ^ (long)1461247846)) /* "values" */)) {
                    if (bl) return;
                    if (entry.isJsonArray()) {
                        if (bl || bl) return;
                        3K.4(m, entry.getAsJsonArray());
                        if (bl) return;
                    }
                }
                if (bl) return;
                if (string.equals(21.a((int)((long)-645219983 ^ (long)-645219440), (int)((long)777329243 ^ (long)777341293)) /* "bind" */)) {
                    if (bl || bl) return;
                    m.9().3 = entry.getAsInt();
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            catch (Exception exception) {
                if (bl || bl) return;
                5z.9.log(Level.WARN, 21.a((int)((long)-157882024 ^ (long)-157881413), (int)((long)-1577872331 ^ (long)1577851705)) /* "Unable to load setting for {}.{}.{}" */, (Object)x.2(), (Object)m.2(), (Object)string);
                if (bl || bl) return;
                return;
            }
        });
        if (!bl && !bl) return;
    }
}

