/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 */
package net.impactclient;

import net.impactclient.2w$6X;
import net.impactclient.9V;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class 8S {
    private static final String[] b;
    public double 2;
    private static final String[] a;
    public double 1;
    public static final boolean \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
    public double 9;

    /*
     * Enabled aggressive block sorting
     */
    public final 9V 1(8S object) {
        double d;
        block3: {
            block2: {
                boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
                if (bl || bl) break block2;
                double[] dArray = new double[(int)((long)1895727217 ^ (long)1895727218)];
                dArray[(int)((long)-1286167683 ^ (long)-1286167683)] = ((8S)object).9 - this.9;
                dArray[(int)((long)1015434707 ^ (long)1015434706)] = ((8S)object).1 - this.1;
                dArray[(int)((long)-1822116640 ^ (long)-1822116638)] = ((8S)object).2 - this.2;
                object = dArray;
                d = Math.sqrt(dArray[(int)((long)1138286976 ^ (long)1138286976)] * object[(int)((long)-2031573206 ^ (long)-2031573206)] + object[(int)((long)-1683220852 ^ (long)-1683220850)] * object[(int)((long)213156628 ^ (long)213156630)]);
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return new 9V(Math.toDegrees(afm.d((double)object[(int)((long)-696387559 ^ (long)-696387557)], (double)object[(int)((long)-1704209641 ^ (long)-1704209641)])) - 90.0, -Math.toDegrees(afm.d((double)object[(int)((long)-217124802 ^ (long)-217124801)], (double)d)));
    }

    public final 8S 4(double d, double d2, double d3) {
        boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
        if (bl || bl) {
            return null;
        }
        return new 8S(this.9 - d, this.1 - d2, this.2 - d3);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final double 4(8S s) {
        double d;
        double d2;
        double d3;
        block3: {
            block2: {
                boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
                if (bl || bl) break block2;
                d3 = this.9 - s.9;
                if (bl || bl) break block2;
                d2 = this.1 - s.1;
                if (bl || bl) break block2;
                d = this.2 - s.2;
                if (!bl && !bl) break block3;
            }
            return 0.0;
        }
        double d4 = d3;
        double d5 = d2;
        double d6 = d;
        return Math.sqrt(d4 * d4 + d5 * d5 + d6 * d6);
    }

    public final 8S 2(8S s) {
        boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
        if (bl || bl) {
            return null;
        }
        return this.7(s.9, s.1, s.2);
    }

    public final 8S 1(8S s) {
        boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
        if (bl || bl) {
            return null;
        }
        return new 8S(this.9 - s.9, this.1 - s.1, this.2 - s.2);
    }

    public 8S(8S s) {
        boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
        this(s.9, s.1, s.2);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)-1103614710 ^ (long)-1103614711)];
            if (var7) break block16;
            var3_2 = (int)((long)-863098368 ^ (long)-863098368);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u8d86\ua48e\ub7ea\ubf98\u8ddb\ua49a\ub7ee\ubfc3\u8d91\ua436\ub702\ubfa4\u8dfa\ua45b\ub782\ubffc\u8d1b", -2048546152);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)157020996 ^ (long)157020992);
            if (var7) break block16;
            var0_6 = (int)((long)-61578057 ^ (long)61578056);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)1467540064 ^ (long)-1467540065);
                if (8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) continue block8;
                            throw null;
                        }
                        8S.a = var5_1;
                        8S.b = new String[(int)((long)-2138922341 ^ (long)-2138922344)];
                        if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)959928775 ^ (long)959928775);
                v5 = (int)((long)-289167703 ^ (long)-289167698);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)-1689132165 ^ (long)-1689132166)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1426367196 ^ (long)-1426367197)) {
                                case 0: {
                                    v12 = (int)((long)-2036099691 ^ (long)-2036099678);
                                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)-925021378 ^ (long)-925021406);
                                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-854205657 ^ (long)-854205671);
                                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)-769807132 ^ (long)-769807185);
                                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)2112432652 ^ (long)2112432723);
                                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)744734828 ^ (long)744734759);
                                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)99408261 ^ (long)99408273);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) ** continue;
                throw null;
            }
        }
    }

    public final String toString() {
        boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
        if (bl || bl) {
            return null;
        }
        return 8S.a((int)((long)214432421 ^ (long)214416963), (int)((long)1827401361 ^ (long)-1827403715)) /* "Vec3{x=" */ + this.9 + 8S.a((int)((long)-1508142749 ^ (long)-1508125306), (int)((long)-1170589952 ^ (long)-1170579928)) /* ", y=" */ + this.1 + 8S.a((int)((long)208867859 ^ (long)208885495), (int)((long)1825208649 ^ (long)-1825182191)) /* ", z=" */ + this.2 + (char)((long)711812939 ^ (long)711812918);
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-2067043623 ^ (long)-2067059139)) & (int)((long)1199299348 ^ (long)1199252715);
            if (var9_2) ** GOTO lbl-1000
            if (8S.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 8S.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1079299254 ^ (long)1079299254)] & (int)((long)1035579543 ^ (long)1035579496)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-2122849188 ^ (long)-2122849262);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-55444465 ^ (long)-55444348);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-724700194 ^ (long)-724700188);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1620422280 ^ (long)1620422356);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1432453187 ^ (long)1432453321);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-495895247 ^ (long)-495895091);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1815357717 ^ (long)-1815357912);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-198194698 ^ (long)-198194711);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-2049515321 ^ (long)-2049515404);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-994302483 ^ (long)-994302642);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1134410195 ^ (long)1134410067);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)376915930 ^ (long)376915774);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1078826395 ^ (long)-1078826344);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1088404280 ^ (long)1088404230);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-88133870 ^ (long)-88133784);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1548906966 ^ (long)-1548906962);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)770812848 ^ (long)770812838);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)68531428 ^ (long)68531426);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-2015653301 ^ (long)-2015653188);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-289799994 ^ (long)-289800096);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-2037258696 ^ (long)-2037258519);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)197104871 ^ (long)197104703);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1314321390 ^ (long)-1314321401);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1065964866 ^ (long)1065964807);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)307900155 ^ (long)307900116);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-134616231 ^ (long)-134616205);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)236274151 ^ (long)236273922);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)527823063 ^ (long)527822848);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1815665615 ^ (long)-1815665632);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)256626505 ^ (long)256626466);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1490927420 ^ (long)1490927612);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1061679691 ^ (long)1061679656);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-59149987 ^ (long)-59150010);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1453986930 ^ (long)1453986879);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1726771763 ^ (long)-1726771930);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-525722683 ^ (long)-525722633);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1901550353 ^ (long)1901550466);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1465979533 ^ (long)-1465979481);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1876515246 ^ (long)-1876515096);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)927024086 ^ (long)927024097);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1878163466 ^ (long)-1878163544);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1944349463 ^ (long)-1944349681);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)523686626 ^ (long)523686536);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-159575561 ^ (long)-159575712);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-737966048 ^ (long)-737965888);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1683049871 ^ (long)1683049959);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-923358480 ^ (long)-923358618);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)191189303 ^ (long)191189385);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1842094236 ^ (long)-1842094111);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)231926823 ^ (long)231926996);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)503307989 ^ (long)503307950);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)553221241 ^ (long)553221308);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1616172419 ^ (long)-1616172315);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1215400825 ^ (long)-1215400799);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1334513654 ^ (long)1334513538);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)606706646 ^ (long)606706634);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1644310760 ^ (long)1644310537);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)599105397 ^ (long)599105508);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)155456992 ^ (long)155456818);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1220717167 ^ (long)1220717114);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1124727091 ^ (long)1124727086);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)924433913 ^ (long)924433802);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1537277437 ^ (long)-1537277415);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)889170424 ^ (long)889170273);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1273126350 ^ (long)1273126348);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-750425311 ^ (long)-750425091);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-343894897 ^ (long)-343894879);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)908464931 ^ (long)908464987);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1883948595 ^ (long)-1883948613);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1244658418 ^ (long)-1244658356);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1997929346 ^ (long)-1997929403);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-398674044 ^ (long)-398673989);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)81586204 ^ (long)81586364);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1476224715 ^ (long)1476224517);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1814631483 ^ (long)1814631644);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1684206808 ^ (long)1684206633);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)18078904 ^ (long)18078974);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1535561853 ^ (long)1535561844);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-609929556 ^ (long)-609929640);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1688564010 ^ (long)1688564152);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1709233279 ^ (long)1709233193);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1121367173 ^ (long)-1121367089);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1360873746 ^ (long)1360873922);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)995753357 ^ (long)995753270);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-832525498 ^ (long)-832525446);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1248982346 ^ (long)-1248982476);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1917700746 ^ (long)1917700810);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)362970303 ^ (long)362970194);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1340132090 ^ (long)-1340131916);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)571076627 ^ (long)571076756);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1993833153 ^ (long)-1993833051);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1611576905 ^ (long)-1611577039);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1531410399 ^ (long)1531410255);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1804673977 ^ (long)1804673988);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1373137171 ^ (long)-1373137405);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)409735748 ^ (long)409735691);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-2112872893 ^ (long)-2112872870);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-697753290 ^ (long)-697753286);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1906612975 ^ (long)1906612926);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)130335199 ^ (long)130335194);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)757585941 ^ (long)757586111);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)960370718 ^ (long)960370873);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)839714119 ^ (long)839714079);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1671740864 ^ (long)-1671740709);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)820448242 ^ (long)820448056);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1110209318 ^ (long)1110209333);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1790844004 ^ (long)-1790844060);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)226151298 ^ (long)226151350);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)37733656 ^ (long)37733706);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1923742936 ^ (long)-1923742749);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)671280798 ^ (long)671280765);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1737210902 ^ (long)-1737211128);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1492514316 ^ (long)1492514311);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)2100676286 ^ (long)2100676325);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)938912169 ^ (long)938912141);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1244753460 ^ (long)-1244753661);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-428090617 ^ (long)-428090526);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)97869772 ^ (long)97869626);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)265782015 ^ (long)265781817);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-634554156 ^ (long)-634554216);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1232963449 ^ (long)1232963569);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-5854821 ^ (long)-5854792);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1122910657 ^ (long)1122910602);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-572788331 ^ (long)-572788472);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1204314941 ^ (long)-1204315122);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1344691925 ^ (long)-1344691848);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)849528351 ^ (long)849528496);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1682706344 ^ (long)-1682706341);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)136137164 ^ (long)136137164);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-198278637 ^ (long)-198278446);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1784748845 ^ (long)1784748874);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)306302146 ^ (long)306301963);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)2109496939 ^ (long)2109497009);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)2018519727 ^ (long)2018519670);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)193841298 ^ (long)193841368);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1729972642 ^ (long)-1729972525);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1540970367 ^ (long)-1540970381);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1202744576 ^ (long)1202744577);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1142829095 ^ (long)-1142829297);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1114079723 ^ (long)-1114079665);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)517454224 ^ (long)517454108);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)278357864 ^ (long)278357962);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1329430272 ^ (long)-1329430221);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)627976084 ^ (long)627976132);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1240305966 ^ (long)-1240305945);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1478875920 ^ (long)-1478876012);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1354744277 ^ (long)-1354744294);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-264756931 ^ (long)-264756787);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1874134166 ^ (long)-1874134180);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)907866547 ^ (long)907866615);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)569338590 ^ (long)569338422);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1021757409 ^ (long)1021757344);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1789600438 ^ (long)1789600406);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)711954540 ^ (long)711954560);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1161043373 ^ (long)-1161043206);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1420579768 ^ (long)1420579785);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)558649148 ^ (long)558649117);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1173480077 ^ (long)-1173480180);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1509598246 ^ (long)1509598446);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)158019056 ^ (long)158018931);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-766939985 ^ (long)-766940046);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-125948596 ^ (long)-125948580);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-2026265521 ^ (long)-2026265350);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1368571375 ^ (long)-1368571179);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1713222662 ^ (long)-1713222786);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1630047670 ^ (long)-1630047646);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-378323460 ^ (long)-378323709);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)2060238589 ^ (long)2060238450);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-491562946 ^ (long)-491562903);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-263434744 ^ (long)-263434660);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1634397647 ^ (long)-1634397672);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1221260274 ^ (long)-1221260217);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)341299972 ^ (long)341300209);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1607012634 ^ (long)1607012801);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-2048998154 ^ (long)-2048998310);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1923333867 ^ (long)-1923333771);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1907647119 ^ (long)-1907647226);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1771936555 ^ (long)1771936606);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1910937897 ^ (long)-1910938005);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1693615197 ^ (long)1693615284);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)359784301 ^ (long)359784193);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1231045107 ^ (long)1231045108);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1619509500 ^ (long)-1619509395);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1889777574 ^ (long)-1889777661);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)955920694 ^ (long)955920666);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1157706428 ^ (long)-1157706385);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1096557574 ^ (long)-1096557635);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)902220861 ^ (long)902220938);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1861379168 ^ (long)-1861379234);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-896017197 ^ (long)-896017332);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-323090543 ^ (long)-323090500);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)311931458 ^ (long)311931440);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1121920062 ^ (long)-1121920069);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)260309397 ^ (long)260309450);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1417293811 ^ (long)-1417293799);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-473272510 ^ (long)-473272454);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1713374805 ^ (long)-1713374757);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)955453730 ^ (long)955453920);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1642480118 ^ (long)1642480100);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1675785394 ^ (long)-1675785407);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1827742892 ^ (long)1827742724);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1907577596 ^ (long)-1907577345);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1271098899 ^ (long)1271099050);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1969775220 ^ (long)-1969775226);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-754291771 ^ (long)-754291834);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)952799648 ^ (long)952799686);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)2042564340 ^ (long)2042564297);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1329584826 ^ (long)1329584859);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1553427770 ^ (long)-1553427804);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-649889576 ^ (long)-649889689);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-2068598152 ^ (long)-2068598099);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1082576378 ^ (long)-1082576129);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-288640630 ^ (long)-288640540);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)208183186 ^ (long)208183221);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1414054389 ^ (long)1414054312);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1270255771 ^ (long)1270255766);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1397659303 ^ (long)1397659158);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)266637041 ^ (long)266636876);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-925823819 ^ (long)-925823995);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-2110731633 ^ (long)-2110731709);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-727666253 ^ (long)-727666343);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-513269645 ^ (long)-513269563);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1404778273 ^ (long)1404778378);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-315798199 ^ (long)-315798236);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)2046359286 ^ (long)2046359230);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-2135650980 ^ (long)-2135650997);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1645637407 ^ (long)1645637383);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)523999039 ^ (long)523999224);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)710991631 ^ (long)710991633);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-971716487 ^ (long)-971716601);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-725246818 ^ (long)-725246899);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1367203422 ^ (long)1367203558);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-795000506 ^ (long)-795000504);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1862636131 ^ (long)1862636139);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-2039865674 ^ (long)-2039865822);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)2142805487 ^ (long)2142805361);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-2007199839 ^ (long)-2007199948);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-132066371 ^ (long)-132066508);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1751805809 ^ (long)-1751805938);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1037380394 ^ (long)1037380491);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)528562908 ^ (long)528562867);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-815360730 ^ (long)-815360764);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)977924961 ^ (long)977925117);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)816310467 ^ (long)816310381);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-477680029 ^ (long)-477679922);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1082328899 ^ (long)-1082328956);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1916480675 ^ (long)1916480636);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1403416744 ^ (long)1403416788);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1874724448 ^ (long)1874724421);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-2056644116 ^ (long)-2056644330);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-567711236 ^ (long)-567711400);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-960430403 ^ (long)-960430493);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-431944662 ^ (long)-431944540);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1332807915 ^ (long)-1332807686);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1161427275 ^ (long)-1161427323);
                    if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-897563700 ^ (long)-897563799);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)455796918 ^ (long)455796809)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1043386674 ^ (long)1043345101)) >>> (int)((long)552277987 ^ (long)552277995)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-2084702793 ^ (long)-2084702793);
            if (!8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1804531361 ^ (long)-1804531363);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-579637400 ^ (long)-579637397) | var5_6 << (int)((long)86069847 ^ (long)0x5215252)) ^ var3_4[var7_8]) & (int)((long)130108145 ^ (long)130107918);
                    if (8S.\u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-2053812087 ^ (long)-2053812086) | var6_7 << (int)((long)1894377582 ^ (long)1894377579)) ^ var3_4[var7_8]) & (int)((long)-161160527 ^ (long)-161160626);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            8S.b[var2_3] = new String(var3_4).intern();
        }
        return 8S.b[var2_3];
    }

    public 8S() {
        boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
        this(0.0, 0.0, 0.0);
    }

    public final 8S 6(float f) {
        boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
        if (bl || bl) {
            return null;
        }
        return new 8S(this.9 * (double)f, this.1 * (double)f, this.2 * (double)f);
    }

    /*
     * Enabled aggressive block sorting
     */
    public 8S(double d, double d2, double d3) {
        block3: {
            block2: {
                boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
                if (bl || bl) break block2;
                this.9 = d;
                if (bl || bl) break block2;
                this.1 = d2;
                if (bl || bl) break block2;
                this.2 = d3;
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    public final 8S 7(double d, double d2, double d3) {
        boolean bl = \u200a\u2000\u200f\u2000\u2007\u200b\u2009\u2009\u2006;
        if (bl || bl) {
            return null;
        }
        return new 8S(this.9 + d, this.1 + d2, this.2 + d3);
    }
}

