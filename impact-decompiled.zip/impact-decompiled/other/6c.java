/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dfm
 *  dku
 *  dlj
 *  nr
 *  oe
 */
package net.impactclient;

import java.util.AbstractCollection;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.zero.clarinet.hook.mixin.accessor.AccessorFontRenderer;
import net.impactclient.2f;
import net.impactclient.2w$6X;
import net.impactclient.3e;
import net.impactclient.51;
import net.impactclient.5e;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 6c
extends dlj {
    private static final String[] d;
    public final dku 0;
    private static final String[] e;
    private 5e 1;
    public static final boolean \u200b\u2002\u200d\u2001;
    private final int 5;
    private final int 3;
    private List<2f> 7;
    public List<51> 6;

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 9(List list, int[] nArray, 51 var3_3) {
        block3: {
            block2: {
                boolean bl = \u200b\u2002\u200d\u2001;
                if (bl || bl) break block2;
                list.addAll(var3_3.6(nArray[(int)((long)1000175280 ^ (long)1000175280)]));
                if (bl || bl) break block2;
                int n = (int)((long)-1694628852 ^ (long)-1694628852);
                nArray[n] = nArray[n] + this.8();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 6c.\u200b\u2002\u200d\u2001;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1978684635 ^ (long)-1978670529)) & (int)((long)-886305909 ^ (long)-886246284);
            if (var9_2) ** GOTO lbl-1000
            if (6c.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 6c.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-2117846306 ^ (long)-2117846306)] & (int)((long)1692211111 ^ (long)1692211032)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1566677174 ^ (long)-1566677223);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-504365180 ^ (long)-504365230);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1952695488 ^ (long)-1952695547);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1947175824 ^ (long)1947175874);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)541040866 ^ (long)541040711);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1706786417 ^ (long)-1706786543);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)381552782 ^ (long)381552773);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-452972343 ^ (long)-452972416);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-233173569 ^ (long)-233173670);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1710585791 ^ (long)1710585662);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1033015077 ^ (long)1033015184);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1887489063 ^ (long)-1887489187);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1174486219 ^ (long)-1174486108);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1091170135 ^ (long)-1091170171);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-81302863 ^ (long)-81302794);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-8306429 ^ (long)-8306280);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1784204796 ^ (long)1784204593);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-775062357 ^ (long)-775062311);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1791644634 ^ (long)1791644512);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1244489918 ^ (long)-1244489743);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1225184761 ^ (long)1225184551);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)557981502 ^ (long)557981644);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-474177692 ^ (long)-474177555);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1968554398 ^ (long)-1968554425);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1253712708 ^ (long)-1253712768);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1721378312 ^ (long)-1721378450);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1723085480 ^ (long)-1723085521);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1627804479 ^ (long)-1627804578);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)113966290 ^ (long)113966201);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1348071290 ^ (long)-1348071327);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1433306962 ^ (long)1433306973);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)0x37735375 ^ (long)930304986);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-15419090 ^ (long)-15419096);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)892968077 ^ (long)892968006);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1066666035 ^ (long)-1066666160);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1742776781 ^ (long)1742776651);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)529406419 ^ (long)529406394);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1192144168 ^ (long)-1192144133);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)303643341 ^ (long)303643264);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1471166350 ^ (long)-1471166443);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)2086650054 ^ (long)2086650042);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-891604016 ^ (long)-891604208);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-2037646987 ^ (long)-2037646875);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-587266273 ^ (long)-587266267);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)887806344 ^ (long)887806299);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-254818041 ^ (long)-254818031);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-992890353 ^ (long)-992890360);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-522393376 ^ (long)-522393424);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1568466807 ^ (long)1568466757);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-660326753 ^ (long)-660326851);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-673083198 ^ (long)-673083229);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1432785337 ^ (long)-1432785157);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)2004641733 ^ (long)2004641770);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1980201411 ^ (long)1980201255);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)2052287138 ^ (long)2052287052);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-883858234 ^ (long)-883858318);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)844238604 ^ (long)844238770);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1263121092 ^ (long)1263120934);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)774783830 ^ (long)774783998);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-938121921 ^ (long)-938121767);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1675889294 ^ (long)1675889247);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-93520681 ^ (long)-93520866);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-721170626 ^ (long)-721170677);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1308859661 ^ (long)1308859663);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1398989853 ^ (long)1398989943);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1169648191 ^ (long)-1169648291);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1415529478 ^ (long)-1415529568);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1026395496 ^ (long)-1026395539);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1421174058 ^ (long)1421174242);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)229197756 ^ (long)229197614);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1290820139 ^ (long)1290820203);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1469758261 ^ (long)-1469758360);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1520142835 ^ (long)-1520142789);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1393849900 ^ (long)-1393849951);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-347780760 ^ (long)-347780839);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-427761110 ^ (long)-427761110);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)897667903 ^ (long)897667894);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)537579520 ^ (long)537579643);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-341152386 ^ (long)-341152456);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)301275530 ^ (long)301275410);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-690337412 ^ (long)-690337316);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1053184429 ^ (long)-1053184396);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1061794870 ^ (long)1061794904);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)55179821 ^ (long)55179869);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-551404042 ^ (long)-551404040);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)557646243 ^ (long)557646193);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)209394953 ^ (long)209395044);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1069710893 ^ (long)1069710881);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1644212744 ^ (long)-1644212965);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)722346260 ^ (long)722346305);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1629914059 ^ (long)-1629914029);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1782418371 ^ (long)1782418263);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1451613108 ^ (long)-1451612930);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)597787463 ^ (long)597787546);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)118203181 ^ (long)118203209);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-280706868 ^ (long)-280707035);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1624273025 ^ (long)1624273051);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)493983773 ^ (long)493983747);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1542053016 ^ (long)1542052927);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1146070044 ^ (long)1146070083);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1570866878 ^ (long)-1570866763);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1182183132 ^ (long)-1182182960);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1134593886 ^ (long)1134594014);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)2016295496 ^ (long)2016295426);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-265284146 ^ (long)-265284318);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1653469479 ^ (long)-1653469662);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1850066523 ^ (long)-1850066592);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1381288805 ^ (long)1381288776);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-936328872 ^ (long)-936328739);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)530029038 ^ (long)530029028);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1830371357 ^ (long)-1830371358);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-111585572 ^ (long)-111585664);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)977962172 ^ (long)977962065);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-573339492 ^ (long)-573339516);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1707363561 ^ (long)-1707363351);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1979498744 ^ (long)-1979498667);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-558739549 ^ (long)-558739612);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)739643199 ^ (long)739643289);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-2105419081 ^ (long)-2105419219);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1237983365 ^ (long)-1237983482);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1776318526 ^ (long)-1776318479);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)985713980 ^ (long)985714059);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1913274028 ^ (long)1913273951);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)428701834 ^ (long)428701940);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)98018580 ^ (long)98018658);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1447911531 ^ (long)1447911526);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)745318200 ^ (long)745318345);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1837575319 ^ (long)1837575405);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)2101165878 ^ (long)2101165965);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)968452091 ^ (long)968452048);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-281649332 ^ (long)-281649381);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)290046447 ^ (long)290046463);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1176964955 ^ (long)-1176964900);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)164272552 ^ (long)164272457);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1470433651 ^ (long)-1470433613);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)2044365107 ^ (long)2044365098);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1947248200 ^ (long)-1947248285);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1433072046 ^ (long)1433072120);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)671412884 ^ (long)671412983);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-2087524395 ^ (long)-2087524370);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)406550393 ^ (long)406550374);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1400103280 ^ (long)1400103377);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1419261775 ^ (long)-1419261792);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1160904314 ^ (long)-1160904374);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1789126035 ^ (long)-1789126087);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1221758258 ^ (long)-1221758437);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1819605691 ^ (long)-1819605653);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1554363631 ^ (long)1554363516);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1193417056 ^ (long)-1193417036);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)891748142 ^ (long)891748227);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-135354965 ^ (long)-135355114);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-628755368 ^ (long)-628755310);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1539406911 ^ (long)1539406967);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-41136043 ^ (long)-41135999);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-30953447 ^ (long)-30953306);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1767098827 ^ (long)-1767098721);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1117191629 ^ (long)1117191483);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)195478568 ^ (long)195478605);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-269544262 ^ (long)-269544221);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)412761998 ^ (long)412762012);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-2096849376 ^ (long)-2096849169);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)619489296 ^ (long)619489316);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)627010021 ^ (long)627009959);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1031501153 ^ (long)1031501113);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)666220566 ^ (long)666220654);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1189530130 ^ (long)-1189530266);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1036236567 ^ (long)1036236686);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1462893562 ^ (long)1462893423);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1129138907 ^ (long)1129138826);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1745926342 ^ (long)1745926391);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1067316431 ^ (long)1067316225);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1513034353 ^ (long)-1513034493);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)2116395971 ^ (long)2116396002);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1750877645 ^ (long)-1750877490);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-2035532838 ^ (long)-2035532930);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1997102351 ^ (long)1997102447);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-2055348155 ^ (long)-2055348017);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)765439070 ^ (long)765438994);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)439272127 ^ (long)439272006);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1691504765 ^ (long)1691504675);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)165634097 ^ (long)165634062);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1635216971 ^ (long)1635217019);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-369636196 ^ (long)-369636187);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)378238744 ^ (long)378238889);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1026362680 ^ (long)-1026362668);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1467399760 ^ (long)1467399830);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)454818683 ^ (long)454818618);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1632603415 ^ (long)1632603631);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1221239836 ^ (long)-1221240040);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)755108442 ^ (long)755108483);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1437921143 ^ (long)1437921088);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)2066886097 ^ (long)2066886015);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-209040847 ^ (long)-209040844);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1584394870 ^ (long)-1584394830);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-804494912 ^ (long)-804494942);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)301972903 ^ (long)301972837);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)608588567 ^ (long)608588632);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1287005502 ^ (long)-1287005481);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1990524399 ^ (long)-1990524326);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-96207009 ^ (long)-96206979);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)120102599 ^ (long)120102637);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)851371289 ^ (long)851371330);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)587905097 ^ (long)587905108);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-997140 ^ (long)-997241);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1766186698 ^ (long)1766186734);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1934682433 ^ (long)1934682525);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1813054001 ^ (long)1813054030);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)706429073 ^ (long)706429054);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)302878914 ^ (long)302878929);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-2141277113 ^ (long)-2141277141);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1518323554 ^ (long)1518323681);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1848418022 ^ (long)-1848417843);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)555150477 ^ (long)555150445);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1070661368 ^ (long)-1070661128);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)597491037 ^ (long)597491061);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)418899134 ^ (long)418899184);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)965828925 ^ (long)965829012);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)38870340 ^ (long)38870446);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1025775082 ^ (long)1025774901);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)387134594 ^ (long)387134534);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)2076712938 ^ (long)2076712878);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1460872767 ^ (long)-1460872840);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1717163706 ^ (long)1717163705);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1102265020 ^ (long)1102264961);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-287963125 ^ (long)-287962895);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1912768597 ^ (long)1912768605);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-640810633 ^ (long)-640810502);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1572166586 ^ (long)-1572166590);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)810051153 ^ (long)810051129);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-957164520 ^ (long)-957164482);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)848283996 ^ (long)848284144);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)984533863 ^ (long)984533903);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)32899194 ^ (long)32899274);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)509983315 ^ (long)509983452);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)2110264074 ^ (long)2110264309);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1555061986 ^ (long)1555061818);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1012807128 ^ (long)1012807007);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1398741373 ^ (long)1398741341);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-53671806 ^ (long)-53671871);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1768069796 ^ (long)-1768069654);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1458550110 ^ (long)-1458550063);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)42224027 ^ (long)42223884);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-185727186 ^ (long)-185726988);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)36798897 ^ (long)36798886);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-84007630 ^ (long)-84007437);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1605416152 ^ (long)1605416108);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)204608805 ^ (long)204608939);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)367612047 ^ (long)367612004);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1272279532 ^ (long)-1272279393);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)2076394357 ^ (long)2076394487);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-69818913 ^ (long)-69818890);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)559632010 ^ (long)559631962);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1794011217 ^ (long)-1794011369);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)143846083 ^ (long)143846104);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)310145931 ^ (long)310145992);
                    if (!6c.\u200b\u2002\u200d\u2001) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1329892628 ^ (long)-1329892733);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-452587523 ^ (long)-452587774)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1784261195 ^ (long)1784239540)) >>> (int)((long)114300879 ^ (long)114300871)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1985890799 ^ (long)-1985890799);
            if (!6c.\u200b\u2002\u200d\u2001) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-21991537 ^ (long)-21991539);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-2068891883 ^ (long)-2068891882) | var5_6 << (int)((long)1896480763 ^ (long)1896480766)) ^ var3_4[var7_8]) & (int)((long)1474064917 ^ (long)1474065130);
                    if (6c.\u200b\u2002\u200d\u2001) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1885432378 ^ (long)1885432377) | var6_7 << (int)((long)381054694 ^ (long)381054691)) ^ var3_4[var7_8]) & (int)((long)835033195 ^ (long)835033236);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            6c.e[var2_3] = new String(var3_4).intern();
        }
        return 6c.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean a(double d2, double d3, int n) {
        block3: {
            block2: {
                boolean bl = \u200b\u2002\u200d\u2001;
                if (bl || bl) break block2;
                this.7.forEach(f -> {
                    block3: {
                        block2: {
                            boolean bl = \u200b\u2002\u200d\u2001;
                            if (bl || bl) break block2;
                            f.a(d2, d3, n);
                            if (!bl) break block3;
                        }
                        return;
                    }
                });
                if (!bl && !bl) break block3;
            }
            return true;
        }
        return (int)((long)896415962 ^ (long)896415962) != 0;
    }

    public 6c(dku object, int n, int n2, 5e object2, String string) {
        boolean bl = \u200b\u2002\u200d\u2001;
        super(n, n2, (int)((long)-960126087 ^ (long)960126086), (int)((long)-1967893280 ^ (long)1967893279), (nr)new oe(string), dlj2 -> {
            boolean bl = \u200b\u2002\u200d\u2001;
            if (bl || bl) {
                return;
            }
        });
        this.0 = object;
        this.5 = (int)((long)-351886628 ^ (long)-351886344);
        this.1 = object2;
        this.3 = (int)((long)-389306946 ^ (long)389306945);
        List<51> list = this.6 = this.8(string);
        object = this;
        LinkedList<2f> linkedList = new LinkedList<2f>();
        int[] nArray = new int[(int)((long)1542198121 ^ (long)1542198120)];
        nArray[(int)((long)1274045103 ^ (long)1274045103)] = object.m;
        object2 = nArray;
        list.forEach(arg_0 -> ((6c)((Object)object)).9(linkedList, (int[])object2, arg_0));
        this.7 = linkedList;
    }

    static /* synthetic */ int 2() {
        boolean bl = \u200b\u2002\u200d\u2001;
        if (bl || bl) {
            return -1929608886;
        }
        return (int)((long)445343790 ^ (long)-445343791);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void a(dfm dfm2, int n, int n2, float f) {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u200b\u2002\u200d\u2001;
                    if (bl || bl) break block2;
                    if (!this.p) break block3;
                    if (bl || bl) break block2;
                    int[] nArray = new int[(int)((long)-2017168541 ^ (long)-2017168542)];
                    nArray[(int)((long)-525591175 ^ (long)-525591175)] = this.m;
                    int[] nArray2 = nArray;
                    if (bl || bl) break block2;
                    this.6.forEach(var3_3 -> {
                        block3: {
                            block2: {
                                boolean bl = \u200b\u2002\u200d\u2001;
                                if (bl || bl) break block2;
                                var3_3.8(dfm2, nArray2[(int)((long)2009963706 ^ (long)2009963706)]);
                                if (bl || bl) break block2;
                                int n = (int)((long)1572783706 ^ (long)1572783706);
                                nArray[n] = nArray2[n] + this.8();
                                if (!bl && !bl) break block3;
                            }
                            return;
                        }
                    });
                    if (bl || bl) break block2;
                    this.7.forEach(f2 -> {
                        block3: {
                            block2: {
                                boolean bl = \u200b\u2002\u200d\u2001;
                                if (bl || bl) break block2;
                                f2.a(dfm2, n, n2, f);
                                if (!bl) break block3;
                            }
                            return;
                        }
                    });
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private List<51> 8(String object) {
        51 v3;
        int n;
        String[] stringArray;
        51 var4_4;
        block13: {
            boolean bl = \u200b\u2002\u200d\u2001;
            if (bl || bl) return null;
            51 var3_3 = new 51(this);
            if (bl || bl) return null;
            var4_4 = new LinkedList();
            if (bl) return null;
            object = ((String)object).replaceAll(2w$6X.KAOZ("\u3299", 2052330889), 6c.a((int)((long)32246619 ^ (long)-32260676), (int)((long)-2038767202 ^ (long)-2038771432)) /* "    " */);
            stringArray = 3e.5();
            if (bl) return null;
            object = Pattern.compile(6c.a((int)((long)-849237819 ^ (long)849223201), (int)((long)24288595 ^ (long)24281489)) /* "([\\S\\u00A0]*)(\\R|[^\\S\\u00A0]|$)" */, (int)((long)-1655005676 ^ (long)-1655005668)).matcher((CharSequence)object);
            if (bl) return null;
            do {
                int n2;
                if (bl) return null;
                if (!((Matcher)object).find()) break;
                if (bl || bl) return null;
                String string = ((Matcher)object).group().replaceAll(6c.a((int)((long)208483618 ^ (long)-208501817), (int)((long)-1302859377 ^ (long)-1302873896)) /* "\\R" */, 2w$6X.KAOZ("", -1142108687));
                if (bl || bl) return null;
                Object object2 = object;
                boolean bl2 = ((Matcher)object2).group(((Matcher)object2).groupCount()).matches(6c.a((int)((long)1574269412 ^ (long)-1574254846), (int)((long)737979589 ^ (long)738000088)));
                if (bl || bl) return null;
                n = (int)((long)-90228543 ^ (long)-90228251);
                if (stringArray != null) break block13;
                if (n < this.0.b(var3_3.toString() + string)) {
                    if (bl) {
                        return null;
                    }
                    n2 = (int)((long)1033009331 ^ (long)1033009330);
                    if (\u200b\u2002\u200d\u2001) {
                        throw null;
                    }
                } else {
                    n2 = (int)((long)513305070 ^ (long)513305070);
                }
                if (n2 != 0) {
                    this.8(var4_4, var3_3);
                }
                var3_3.4(string);
                if (!bl2) continue;
                this.8(var4_4, var3_3);
            } while (stringArray == null);
            var4_4.add(var3_3);
            var4_4.removeIf(Objects::isNull);
            n = ((AbstractCollection)var4_4).isEmpty();
        }
        if (n == 0) {
            while (var4_4.peekLast() != null) {
                v3 = var4_4.peekLast();
                if (stringArray != null) return v3;
                if (!v3.isEmpty()) break;
                var4_4.removeLast();
                if (stringArray == null) continue;
            }
        } else {
            v3 = var4_4;
        }
        return v3;
    }

    static /* synthetic */ 5e 7(6c c2) {
        boolean bl = \u200b\u2002\u200d\u2001;
        if (bl || bl) {
            return null;
        }
        return c2.1;
    }

    public final int 8() {
        boolean bl = \u200b\u2002\u200d\u2001;
        if (bl || bl) {
            return 1257256710;
        }
        return ((AccessorFontRenderer)this.0).getFontHeight() + (int)((long)790020014 ^ (long)790020012);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 8(List<51> list, 51 var2_2) {
        block3: {
            block2: {
                boolean bl = \u200b\u2002\u200d\u2001;
                if (bl || bl) break block2;
                51 var3_4 = new 51(this, var2_2);
                var3_4.4();
                if (bl || bl) break block2;
                list.add(var3_4);
                if (bl || bl) break block2;
                var2_2.clear();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 6c.\u200b\u2002\u200d\u2001;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)176626379 ^ (long)176626383)];
            if (var7) break block23;
            var3_2 = (int)((long)-1889665964 ^ (long)-1889665964);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u09ee\u20f6\u33df\u3b8e\u0949\u207c\u3384\u3b85\u092c\u20c2\u33e0\u3b26\u091c\u20ce\u3350\u3b36\u09eb\u20d3\u33d0\u3b92\u09af\u205d\u334b\u3b5d\u09ea\u20db\u33bd\u3b67\u0947\u20cb\u3341\u3ba9\u09ad\u202c", 685059690);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1234315193 ^ (long)1234315174);
            if (var7) break block23;
            var0_6 = (int)((long)1322118038 ^ (long)-1322118039);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1420812107 ^ (long)1420812036);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-83146790 ^ (long)83146789);
                    if (6c.\u200b\u2002\u200d\u2001) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!6c.\u200b\u2002\u200d\u2001) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u4c74\u658e\u7626\u7ec8\u4ccb\u6517\u7652", 1295608727);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1840633909 ^ (long)-1840633911);
                            var0_6 = (int)((long)1633356901 ^ (long)-1633356902);
                            while (true) {
                                v0 = (int)((long)672985638 ^ (long)672985627);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-584854725 ^ (long)-584854725);
                                if (!6c.\u200b\u2002\u200d\u2001) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!6c.\u200b\u2002\u200d\u2001) ** continue;
                                throw null;
                            }
                            6c.d = var5_1;
                            6c.e = new String[(int)((long)1435978203 ^ (long)1435978207)];
                            if (!6c.\u200b\u2002\u200d\u2001) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1022748302 ^ (long)1022748302);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)139306599 ^ (long)139306598)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1236747964 ^ (long)1236747963)) {
                                case 0: {
                                    v15 = (int)((long)-2000233063 ^ (long)-2000233045);
                                    if (!6c.\u200b\u2002\u200d\u2001) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)298543694 ^ (long)298543693);
                                    if (!6c.\u200b\u2002\u200d\u2001) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1764432394 ^ (long)-1764432428);
                                    if (!6c.\u200b\u2002\u200d\u2001) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-553702262 ^ (long)-553702228);
                                    if (!6c.\u200b\u2002\u200d\u2001) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1963777534 ^ (long)-1963777455);
                                    if (!6c.\u200b\u2002\u200d\u2001) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1685475556 ^ (long)1685475537);
                                    if (!6c.\u200b\u2002\u200d\u2001) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1120255307 ^ (long)1120255356);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!6c.\u200b\u2002\u200d\u2001);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

