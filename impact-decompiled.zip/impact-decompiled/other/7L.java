/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  oj
 *  sr
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.0p;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.34s;
import net.impactclient.3C;
import net.impactclient.3sx;
import net.impactclient.4f;
import net.impactclient.7m;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7L
extends 7m<0p> {
    private static final String[] b;
    @EventHandler
    private final Listener<4f> 0;
    @EventHandler
    private final Listener<3C> 9;
    private long 1;
    private sr 2;
    private long 5;
    private boolean 4;
    private boolean 7;
    private static final String[] a;
    @EventHandler
    private final Listener<3sx> 6;
    public static final boolean \u2003;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 7L.\u2003;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1946141028 ^ (long)-1946140791)) & (int)((long)684628978 ^ (long)684614669);
            if (var9_2) ** GOTO lbl-1000
            if (7L.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7L.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1386735023 ^ (long)1386735023)] & (int)((long)461606410 ^ (long)461606645)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-755944618 ^ (long)-755944563);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1273905177 ^ (long)1273905267);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-841377403 ^ (long)-841377346);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-3694759 ^ (long)-3694837);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1822092755 ^ (long)1822092736);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)70242443 ^ (long)70242414);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1069601922 ^ (long)-1069601989);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1755952030 ^ (long)-1755951927);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)142318707 ^ (long)142318616);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1024995270 ^ (long)-1024995250);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)703726919 ^ (long)703726874);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1357593107 ^ (long)-1357593227);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1536916560 ^ (long)-1536916710);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1087531883 ^ (long)1087531985);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1844778960 ^ (long)1844778870);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1552686287 ^ (long)1552686139);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1164512077 ^ (long)-1164512115);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1470869538 ^ (long)-1470869523);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-191328546 ^ (long)-191328666);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1786216746 ^ (long)-1786216765);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)744723247 ^ (long)744723380);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)514447250 ^ (long)514447122);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1768527052 ^ (long)-1768527011);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)315842175 ^ (long)315842048);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-70426718 ^ (long)-70426633);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1040402034 ^ (long)1040402139);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-457437571 ^ (long)-457437570);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-172060589 ^ (long)-172060493);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1871196568 ^ (long)-1871196460);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)229864460 ^ (long)229864457);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1513865707 ^ (long)1513865652);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1325074026 ^ (long)1325074114);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)468702346 ^ (long)468702425);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)763043950 ^ (long)763043950);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-339037462 ^ (long)-339037550);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)129715667 ^ (long)129715618);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-364306555 ^ (long)-364306675);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-868370655 ^ (long)-868370586);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-951286355 ^ (long)-951286362);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1701261276 ^ (long)-1701261132);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)864343712 ^ (long)864343628);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)403824141 ^ (long)403824371);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1555462775 ^ (long)1555462801);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1849761227 ^ (long)1849761187);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)63568562 ^ (long)63568447);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)890763377 ^ (long)890763401);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1647469708 ^ (long)-1647469584);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)166029355 ^ (long)166029386);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-113064208 ^ (long)-113064235);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1429406986 ^ (long)-1429407010);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-881233007 ^ (long)-881233045);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-117874181 ^ (long)-117874379);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1939264678 ^ (long)1939264723);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1157442740 ^ (long)1157442603);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1216777839 ^ (long)1216777780);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1614796853 ^ (long)1614796998);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1849647013 ^ (long)1849647103);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-284319402 ^ (long)-284319315);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)436365185 ^ (long)436365078);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-148518755 ^ (long)-148518736);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)746496762 ^ (long)746496563);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-516446874 ^ (long)-516446737);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1329071062 ^ (long)1329071098);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-913007912 ^ (long)-913007890);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)962846707 ^ (long)962846685);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)661531194 ^ (long)661531153);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1877774497 ^ (long)1877774570);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-903622037 ^ (long)-903622019);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-342570470 ^ (long)-342570376);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)70562097 ^ (long)70562165);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)903788623 ^ (long)903788628);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)110360766 ^ (long)110360782);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)2092999873 ^ (long)2092999872);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-792350234 ^ (long)-792350345);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1108809086 ^ (long)-1108809022);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)743691273 ^ (long)743691332);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1926625099 ^ (long)-1926625273);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1751797709 ^ (long)1751797528);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1426585627 ^ (long)-1426585652);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1835086605 ^ (long)-1835086657);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)84631157 ^ (long)84631155);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)2042280653 ^ (long)2042280609);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-945095526 ^ (long)-945095544);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1549716918 ^ (long)1549716857);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-571043886 ^ (long)-571043931);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-557719883 ^ (long)-557719936);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-470058343 ^ (long)-470058404);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)854208908 ^ (long)854208889);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1172109924 ^ (long)-1172109990);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1462536127 ^ (long)1462535984);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1367410975 ^ (long)-1367411163);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1307190676 ^ (long)-1307190775);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1769325836 ^ (long)1769325968);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)585970281 ^ (long)585970208);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1873257721 ^ (long)-1873257719);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1950671309 ^ (long)-1950671345);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)773165652 ^ (long)773165750);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1421688736 ^ (long)-1421688623);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1109333378 ^ (long)-1109333357);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-488783406 ^ (long)-488783372);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-152050483 ^ (long)-152050605);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1667526935 ^ (long)-1667527053);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1958335482 ^ (long)1958335282);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1830454082 ^ (long)1830454139);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1359918826 ^ (long)1359918597);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-461245141 ^ (long)-461245006);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-539941970 ^ (long)-539941942);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)668538802 ^ (long)668538724);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1024889805 ^ (long)1024889840);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)842509808 ^ (long)842509750);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1503421617 ^ (long)1503421537);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)2109278096 ^ (long)2109277978);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-2061589017 ^ (long)-2061589001);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1644332032 ^ (long)-1644331812);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)559826424 ^ (long)559826285);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)319961329 ^ (long)319961148);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1500369015 ^ (long)-1500369002);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-74479784 ^ (long)-74479617);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1505426304 ^ (long)1505426321);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)355621849 ^ (long)355621640);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1685192167 ^ (long)-1685192041);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-2045419488 ^ (long)-2045419434);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-201484736 ^ (long)-201484602);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1653178991 ^ (long)-1653178894);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1967694475 ^ (long)1967694585);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-71669043 ^ (long)-71669036);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1924493913 ^ (long)1924493876);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1592681355 ^ (long)1592681348);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)565129299 ^ (long)565129388);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-64121999 ^ (long)-64121963);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)411735549 ^ (long)411735540);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1342790395 ^ (long)1342790146);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-960924619 ^ (long)-960924582);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1499957348 ^ (long)1499957318);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-2061000075 ^ (long)-2061000108);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1588162775 ^ (long)-1588162765);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)510912303 ^ (long)510912339);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1623913896 ^ (long)-1623913857);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1443359373 ^ (long)1443359272);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1683456276 ^ (long)1683456333);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1900641704 ^ (long)1900641689);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-78983234 ^ (long)-78983290);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-2047673604 ^ (long)-2047673688);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-345427174 ^ (long)-345427097);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)2101024815 ^ (long)2101024997);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-510562372 ^ (long)-510562529);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-314552317 ^ (long)-314552108);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-638552565 ^ (long)-638552387);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)417295348 ^ (long)417295113);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1414614706 ^ (long)-1414614738);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1084480913 ^ (long)1084480819);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1096433177 ^ (long)-1096433293);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1019133788 ^ (long)1019133868);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-591525164 ^ (long)-591525325);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)151949839 ^ (long)151949885);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1288323147 ^ (long)1288323293);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1766102352 ^ (long)-1766102385);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-2119225210 ^ (long)-2119225135);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)328720897 ^ (long)328721074);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1128462145 ^ (long)-1128462233);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1219383651 ^ (long)1219383716);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-2044605234 ^ (long)-2044605395);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1785970652 ^ (long)-1785970483);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1749512933 ^ (long)-1749512762);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1930020882 ^ (long)1930021031);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1308162462 ^ (long)-1308162555);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)168508080 ^ (long)168508004);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1171949211 ^ (long)1171949164);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-45452421 ^ (long)-45452515);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1446115618 ^ (long)1446115806);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)227313531 ^ (long)227313593);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-787892506 ^ (long)-787892571);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-730620025 ^ (long)-730619955);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)2054681457 ^ (long)2054681565);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1724654137 ^ (long)-1724654113);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)854619872 ^ (long)854619726);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1622111233 ^ (long)-1622111313);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)756375098 ^ (long)756375173);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1418099350 ^ (long)-1418099352);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-2111626708 ^ (long)-2111626530);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)564225339 ^ (long)564225463);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1047324351 ^ (long)1047324304);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-2123272339 ^ (long)-2123272214);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1055472838 ^ (long)-1055472664);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1807740913 ^ (long)-1807740917);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1644620780 ^ (long)-1644620601);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)193512547 ^ (long)193512584);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1015157867 ^ (long)1015157813);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)486345789 ^ (long)486345948);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1515016028 ^ (long)-1515016110);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1850208363 ^ (long)1850208307);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)142016789 ^ (long)142016975);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1121531642 ^ (long)-1121531638);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-202049785 ^ (long)-202049719);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-974219377 ^ (long)-974219473);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)6070306 ^ (long)6070432);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-746474780 ^ (long)-746474911);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)119924031 ^ (long)119924078);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1847610211 ^ (long)-1847610340);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1741430035 ^ (long)-1741430023);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)953854230 ^ (long)953854225);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1592034224 ^ (long)1592034303);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-819347763 ^ (long)-819347962);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)141620757 ^ (long)141620904);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-853040661 ^ (long)-853040733);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1618327371 ^ (long)-1618327354);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-47012793 ^ (long)-47012729);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1910255108 ^ (long)-1910255226);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1332270653 ^ (long)1332270640);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-396509765 ^ (long)-396509739);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1744465546 ^ (long)-1744465560);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)2073944119 ^ (long)2073944252);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-207560138 ^ (long)-207560120);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1979018032 ^ (long)1979018092);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1545961504 ^ (long)1545961615);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1008163560 ^ (long)-1008163423);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)533260364 ^ (long)533260302);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)91788286 ^ (long)91788052);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1515872614 ^ (long)-1515872595);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1090779530 ^ (long)-1090779450);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)53098292 ^ (long)53098371);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-569110258 ^ (long)-569110236);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)331664177 ^ (long)331664139);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-778914031 ^ (long)-778913999);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)165753372 ^ (long)165753541);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)842343335 ^ (long)842343241);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)678398134 ^ (long)678397995);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1184072310 ^ (long)-1184072375);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)33911071 ^ (long)33911048);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-173344870 ^ (long)-173344839);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-35942264 ^ (long)-35942346);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1937846071 ^ (long)-1937846250);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)207112419 ^ (long)207112403);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)287834425 ^ (long)287834616);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)0x17477444 ^ (long)390558944);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-900408172 ^ (long)-900408107);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)645627808 ^ (long)645627818);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)2080730833 ^ (long)2080730748);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1757988519 ^ (long)1757988527);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1085524415 ^ (long)-1085524270);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)108386783 ^ (long)108386606);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-2036629133 ^ (long)-2036629240);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1264593369 ^ (long)1264593201);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1962061642 ^ (long)1962061655);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)465825394 ^ (long)465825316);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-100276200 ^ (long)-100276164);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1287769580 ^ (long)-1287769592);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1239427386 ^ (long)1239427395);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-216410614 ^ (long)-216410426);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)681526859 ^ (long)681527001);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-375991646 ^ (long)-375991805);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-465169473 ^ (long)-465169604);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)221903727 ^ (long)221903828);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)598377227 ^ (long)598377407);
                    if (!7L.\u2003) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)164618291 ^ (long)164618477);
                    if (!7L.\u2003) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1534405941 ^ (long)1534405889);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-428974029 ^ (long)-428973876)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-65577697 ^ (long)-65559840)) >>> (int)((long)-1146053681 ^ (long)-1146053689)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-526242779 ^ (long)-526242779);
            if (!7L.\u2003) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)211845456 ^ (long)211845458);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-71104559 ^ (long)-71104558) | var5_6 << (int)((long)-1062855666 ^ (long)-1062855669)) ^ var3_4[var7_8]) & (int)((long)1279504403 ^ (long)1279504620);
                    if (7L.\u2003) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1205852615 ^ (long)-1205852614) | var6_7 << (int)((long)1217260684 ^ (long)1217260681)) ^ var3_4[var7_8]) & (int)((long)-1312042995 ^ (long)-1312042766);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7L.b[var2_3] = new String(var3_4).intern();
        }
        return 7L.b[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7L.\u2003;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1958158617 ^ (long)1958158623)];
            if (var7) break block23;
            var3_2 = (int)((long)-583422871 ^ (long)-583422871);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ub316\u9ab3\u89a6\u819c\ub307\u9adb\u8964\u81d5\ub3dd\u9ae8\u8910\u8141\ub3e2\u9a45\u8933\u8113\ub33b\u9a5e\u8996\u8112\ub316\u9a7b\u8996\u8133\ub38c\u9a02\u89b1\u8184\ub325\u9a92\u8961\u81e4\ub379\u9a7c\u896a\u8128\ub33f\u9aaa\u899e\u8105\ub3bf\u9a20\u89c7\u8165\ub3f1\u9abd\u89ab\u81b7\ub343\u9a50\u89c2\u8124\ub351\u9a8d\u89bc\u8187\ub3bf\u9a04\u8927\u8154\ub335\u9a24\u899c\u8193\ub363\u9a2c\u8994\u8146\ub312\u9a8d\u8973\u819f\ub35b\u9a78\u8930\u811b\ub364\u9aec\u8959\u81b0", -1203268393);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)2072996279 ^ (long)2072996273);
            if (var7) break block23;
            var0_6 = (int)((long)1926280376 ^ (long)-1926280377);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-571226257 ^ (long)-571226320);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-943321283 ^ (long)943321282);
                    if (7L.\u2003) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7L.\u2003) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ua8f0\u814b\u9242\u9ab0\ua88c\u8102\u922e\u9adb\ua873\u8148\u9264\u9afe\ua818\u8114\u922e\u9a50", -1058762842);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)89277492 ^ (long)89277488);
                            var0_6 = (int)((long)-609954619 ^ (long)609954618);
                            while (true) {
                                v0 = (int)((long)-1285968533 ^ (long)-1285968630);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-735580571 ^ (long)-735580571);
                                if (!7L.\u2003) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7L.\u2003) ** continue;
                                throw null;
                            }
                            7L.a = var5_1;
                            7L.b = new String[(int)((long)-4424053 ^ (long)-4424051)];
                            if (!7L.\u2003) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)296596878 ^ (long)296596878);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)157131128 ^ (long)157131129)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-586275054 ^ (long)-586275051)) {
                                case 0: {
                                    v15 = (int)((long)893745089 ^ (long)893745082);
                                    if (!7L.\u2003) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1513556291 ^ (long)1513556264);
                                    if (!7L.\u2003) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1258833527 ^ (long)-1258833423);
                                    if (!7L.\u2003) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1192401455 ^ (long)-1192401530);
                                    if (!7L.\u2003) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1276599248 ^ (long)-1276599263);
                                    if (!7L.\u2003) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)2121932654 ^ (long)2121932566);
                                    if (!7L.\u2003) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)533434782 ^ (long)533434831);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7L.\u2003);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2003;
                    if (bl || bl) break block2;
                    this.3();
                    if (bl || bl) break block2;
                    if (this.2 == null) break block3;
                    if (bl) break block2;
                    if (7L.3.s == null) break block3;
                    if (bl || bl) break block2;
                    7L l = this;
                    l.0((oj<?>)l.2);
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 0(oj<?> oj2) {
        block3: {
            block2: {
                boolean bl = \u2003;
                if (bl || bl) break block2;
                this.4 = (int)((long)-1699709035 ^ (long)-1699709036);
                if (bl || bl) break block2;
                7L.3.s.e.a(oj2);
                if (bl || bl) break block2;
                this.4 = (int)((long)-133867405 ^ (long)-133867405);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 3() {
        block3: {
            block2: {
                boolean bl = \u2003;
                if (bl || bl) break block2;
                this.2 = null;
                if (bl || bl) break block2;
                this.7 = (int)((long)1836264410 ^ (long)1836264410);
                if (bl || bl) break block2;
                this.5 = 0x18C59B78E4A8F9F9L ^ 0x18C59B78E4A8F9F9L;
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    public 7L(0p p) {
        boolean bl = \u2003;
        super(p, 7L.a((int)((long)-8162448 ^ (long)-8162719), (int)((long)-1738290469 ^ (long)-1738293334)) /* "Fake" */, 7L.a((int)((long)-1588001991 ^ (long)-1588002258), (int)((long)-414717618 ^ (long)-414717549)) /* "Choke packets to cause your ping to apparently be very high" */);
        Predicate[] predicateArray = new Predicate[(int)((long)1149398529 ^ (long)1149398531)];
        Class[] classArray = new Class[(int)((long)785104691 ^ (long)785104690)];
        classArray[(int)((long)-7696863 ^ (long)-7696863)] = sr.class;
        predicateArray[(int)((long)-1866412549 ^ (long)-1866412549)] = new 34s(classArray);
        predicateArray[(int)((long)503212977 ^ (long)503212976)] = c2 -> {
            boolean bl = \u2003;
            if (bl || bl) return true;
            if (!this.4) {
                if (bl) return true;
                return (int)((long)1270774845 ^ (long)1270774844) != 0;
            }
            if (!bl) return (int)((long)1052907734 ^ (long)1052907734) != 0;
            return true;
        };
        this.9 = new Listener(c2 -> {
            block5: {
                block2: {
                    boolean bl;
                    block4: {
                        sr sr2;
                        block3: {
                            bl = \u2003;
                            if (bl || bl) break block2;
                            sr2 = (sr)c2.7;
                            if (bl || bl) break block2;
                            if (this.2 == null) break block3;
                            if (bl || bl) break block2;
                            this.5 = System.currentTimeMillis() - this.1;
                            if (bl || bl) break block2;
                            2R.1(this.8, 7L.a((int)((long)538436460 ^ (long)538436218), (int)((long)-1176037080 ^ (long)-1176026050)), afm.c((double)((double)this.5 / 50.0)) + 7L.a((int)((long)893175331 ^ (long)893175607), (int)((long)-908651930 ^ (long)-908633920)) /* " ticks" */);
                            if (bl) break block2;
                        }
                        if (bl) break block2;
                        this.2 = sr2;
                        if (bl || bl) break block2;
                        this.1 = System.currentTimeMillis();
                        if (bl || bl) break block2;
                        if (this.5 <= (0x3C42DA1B0E0C1311L ^ 0x3C42DA1B0E0C1311L)) break block4;
                        if (bl || bl) break block2;
                        this.7 = (int)((long)-341493753 ^ (long)-341493754);
                        if (bl || bl) break block2;
                        c2.cancel();
                        if (bl) break block2;
                    }
                    if (!bl) break block5;
                }
                return;
            }
        }, predicateArray);
        this.0 = new Listener(f -> {
            block5: {
                block2: {
                    boolean bl;
                    block4: {
                        block3: {
                            bl = \u2003;
                            if (bl || bl) break block2;
                            if (!this.7) break block3;
                            if (bl || bl) break block2;
                            if (!((double)(System.currentTimeMillis() - this.1) > (double)this.5 * 0.6666666666666666)) break block3;
                            if (bl || bl) break block2;
                            7L l = this;
                            l.0((oj<?>)l.2);
                            if (bl || bl) break block2;
                            this.7 = (int)((long)-1997714179 ^ (long)-1997714179);
                            if (bl) break block2;
                        }
                        if (bl) break block2;
                        if (this.5 != (0x2E9F08ED1CB2FB1EL ^ 0x2E9F08ED1CB2FB1EL)) break block4;
                        if (bl || bl) break block2;
                        2R.1(this.8, 7L.a((int)((long)252777890 ^ (long)252777655), (int)((long)1964777515 ^ (long)1964781847)) /* "suffix" */, 7L.a((int)((long)-1552268205 ^ (long)-1552267965), (int)((long)34192963 ^ (long)-34182256)) /* "Calibrating" */);
                        if (bl) break block2;
                    }
                    if (!bl) break block5;
                }
                return;
            }
        }, new Predicate[(int)((long)1419324528 ^ (long)1419324528)]);
        this.6 = new Listener(sx -> {
            block3: {
                block2: {
                    boolean bl = \u2003;
                    if (bl || bl) break block2;
                    this.3();
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)1279814362 ^ (long)1279814362)]);
    }
}

