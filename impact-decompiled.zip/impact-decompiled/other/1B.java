/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  apw
 *  aqa
 *  baritone.api.BaritoneAPI
 *  brc
 *  ceh
 *  cuy
 *  dci
 *  dde
 *  ddh
 *  fx
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import baritone.api.BaritoneAPI;
import clientapi.load.mixin.7.2;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.01;
import net.impactclient.1P;
import net.impactclient.2w$6X;
import net.impactclient.34X;
import net.impactclient.4W;
import net.impactclient.4X;
import net.impactclient.4f;
import net.impactclient.4m;
import net.impactclient.66;
import net.impactclient.7m;
import net.impactclient.8S;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 1B
extends 7m<01> {
    private static final String[] b;
    public static 1B 9;
    public boolean 2;
    private static final String[] a;
    @EventHandler
    private final Listener<4f> 7;
    private boolean 5;
    public static final ddh 6;
    private 1P 4;
    private boolean 8;
    private 1P 1;
    @EventHandler
    private final Listener<4W> 0;
    public static final boolean \u2003\u2004\u2007\u200c\u2008\u200b;
    @EventHandler
    private final Listener<4X> 9C;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 1B.\u2003\u2004\u2007\u200c\u2008\u200b;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-599647363 ^ (long)-599629488)) & (int)((long)-52357316 ^ (long)-52303677);
            if (var9_2) ** GOTO lbl-1000
            if (1B.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 1B.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)775613328 ^ (long)775613328)] & (int)((long)-1053753172 ^ (long)-1053753261)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1094638745 ^ (long)-1094638593);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)2100952367 ^ (long)2100952512);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-224730497 ^ (long)-224730547);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)235359746 ^ (long)235359836);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1056432001 ^ (long)-1056431898);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1487567101 ^ (long)1487566883);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)129968019 ^ (long)129968034);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1818708338 ^ (long)-1818708394);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1629276346 ^ (long)-1629276338);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)517000559 ^ (long)517000664);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1995125449 ^ (long)-1995125417);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)83375553 ^ (long)83375372);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-980743410 ^ (long)-980743181);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-445185621 ^ (long)-445185579);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)181496481 ^ (long)181496347);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-2103725013 ^ (long)-2103724983);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-674306753 ^ (long)-674306623);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)909957176 ^ (long)909957148);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1489997643 ^ (long)-1489997711);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1992969569 ^ (long)1992969689);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-846363321 ^ (long)-846363256);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)136372586 ^ (long)136372674);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)2035614935 ^ (long)2035614760);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1379215786 ^ (long)1379215624);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1018350120 ^ (long)-1018350116);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1133525222 ^ (long)-1133525076);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-825243944 ^ (long)-825243971);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1492794314 ^ (long)-1492794238);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-777648210 ^ (long)-777648380);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-448436198 ^ (long)-448436025);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1177208292 ^ (long)-1177208234);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-995441654 ^ (long)-995441604);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1031666109 ^ (long)1031666000);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)71972822 ^ (long)71972796);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1473410958 ^ (long)-1473410851);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)999057285 ^ (long)999057394);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-674003871 ^ (long)-674003822);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-313797435 ^ (long)-313797387);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1060130735 ^ (long)1060130563);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1851611045 ^ (long)-1851611129);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)323548540 ^ (long)323548435);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1466935461 ^ (long)-1466935390);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)282348258 ^ (long)282348265);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1497841466 ^ (long)1497841661);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1296364925 ^ (long)-1296364818);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-859512573 ^ (long)-859512462);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-908892166 ^ (long)-908892384);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1880971086 ^ (long)1880971047);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)56581327 ^ (long)56581258);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1632282195 ^ (long)-1632282278);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)730438581 ^ (long)730438631);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)65264344 ^ (long)65264150);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1463095630 ^ (long)1463095632);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1691131916 ^ (long)-1691131931);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-327363308 ^ (long)-327363086);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1769662585 ^ (long)1769662552);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1501236657 ^ (long)-1501236581);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1181012423 ^ (long)1181012229);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1700474501 ^ (long)-1700474582);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1600626448 ^ (long)-1600626541);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-822004866 ^ (long)-822004886);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1236803220 ^ (long)1236803218);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1853162367 ^ (long)1853162494);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1090452798 ^ (long)1090452791);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1373499101 ^ (long)1373499118);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-797429812 ^ (long)-797429958);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1519266000 ^ (long)1519265951);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1278326876 ^ (long)-1278326940);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)187082934 ^ (long)187082992);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)271145103 ^ (long)271145187);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)320898065 ^ (long)320898200);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)981885269 ^ (long)981885194);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1197035075 ^ (long)1197035097);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-541150106 ^ (long)-541149993);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1800141417 ^ (long)-1800141467);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1532211198 ^ (long)-1532211154);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1683343762 ^ (long)-1683343748);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1004276081 ^ (long)-1004276028);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)403398477 ^ (long)403398510);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)95304989 ^ (long)95304968);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)290622639 ^ (long)290622665);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)54441943 ^ (long)54441907);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1980646085 ^ (long)1980646014);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1502704185 ^ (long)1502704348);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1673952209 ^ (long)1673952236);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1161144664 ^ (long)1161144824);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1729212539 ^ (long)-1729212498);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1126350151 ^ (long)1126350207);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)2002027769 ^ (long)2002027552);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-780912304 ^ (long)-780912339);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1344241228 ^ (long)-1344241277);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1283820146 ^ (long)-1283820049);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1242824729 ^ (long)1242824835);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1140983606 ^ (long)1140983612);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-862220769 ^ (long)-862220605);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-111191300 ^ (long)-111191476);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1114301841 ^ (long)1114301736);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1019653459 ^ (long)1019653399);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)2128080298 ^ (long)2128080230);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-339890608 ^ (long)-339890601);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1935208615 ^ (long)-1935208612);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1517700386 ^ (long)1517700399);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-566834349 ^ (long)-566834395);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1897961688 ^ (long)1897961540);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-143784171 ^ (long)-143783955);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)850040220 ^ (long)850040094);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-2139822437 ^ (long)-2139822379);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)998775550 ^ (long)998775393);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)244971787 ^ (long)244971998);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1747568230 ^ (long)1747568375);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-273968347 ^ (long)-273968161);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-956281490 ^ (long)-956281578);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1154686083 ^ (long)1154685976);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1118963933 ^ (long)1118963766);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1771593703 ^ (long)-1771593475);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1173794381 ^ (long)-1173794503);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1351726376 ^ (long)-1351726429);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)671943873 ^ (long)671943919);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1693146662 ^ (long)-1693146822);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)897897867 ^ (long)897897861);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)594459889 ^ (long)594459778);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-64819586 ^ (long)-64819655);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1539376775 ^ (long)-1539376774);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1963388859 ^ (long)-1963388906);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1957466077 ^ (long)-1957465941);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-80192436 ^ (long)-80192357);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)509020830 ^ (long)509020779);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1997437979 ^ (long)1997438012);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1194045579 ^ (long)1194045472);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-243007156 ^ (long)-243007137);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)761276032 ^ (long)761276084);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-631304782 ^ (long)-631304923);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1578992070 ^ (long)1578991968);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-22331194 ^ (long)-22331345);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)572116131 ^ (long)572116056);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-380048893 ^ (long)-380048812);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)921344089 ^ (long)921344035);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-837842097 ^ (long)-837841969);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-243314663 ^ (long)-243314653);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-2135072 ^ (long)-2135194);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)622870851 ^ (long)622870875);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-566719674 ^ (long)-566719619);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1604118099 ^ (long)1604118239);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1159398760 ^ (long)1159398699);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1971664837 ^ (long)-1971664813);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)748866699 ^ (long)748866661);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1124694334 ^ (long)1124694479);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1891835801 ^ (long)-1891835702);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)880632384 ^ (long)880632425);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-2080584122 ^ (long)-2080583967);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1641957480 ^ (long)1641957460);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-44456316 ^ (long)-44456416);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-199927198 ^ (long)-199927179);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-889345633 ^ (long)-889345768);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-771041547 ^ (long)-771041729);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-66001295 ^ (long)-66001300);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1521078299 ^ (long)-1521078492);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-900804832 ^ (long)-900804739);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1953991780 ^ (long)1953991924);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)998846391 ^ (long)998846241);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1652164865 ^ (long)-1652164905);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1547054501 ^ (long)-1547054589);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)332349874 ^ (long)332349697);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)950186297 ^ (long)950186374);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)84266218 ^ (long)0x505CC00);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1256627028 ^ (long)-1256627047);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1864485228 ^ (long)1864485166);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)521481439 ^ (long)521481366);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-660794485 ^ (long)-660794395);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1668076972 ^ (long)1668076934);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1731809339 ^ (long)1731809438);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-738479302 ^ (long)-738479144);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1702058633 ^ (long)-1702058584);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1198536484 ^ (long)1198536498);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)192423278 ^ (long)192423359);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1554177746 ^ (long)1554177644);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-141396249 ^ (long)-141396278);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)2078324895 ^ (long)2078324868);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1464045143 ^ (long)1464045095);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1213087425 ^ (long)-1213087426);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-181042280 ^ (long)-181042265);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-471788554 ^ (long)-471788770);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1134745110 ^ (long)1134745259);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1465722184 ^ (long)-1465722164);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)154005478 ^ (long)154005270);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-736985989 ^ (long)-736985991);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-2063942749 ^ (long)-2063942667);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1072365736 ^ (long)1072365811);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-910339966 ^ (long)-910339867);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-817957470 ^ (long)-817957532);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-949313786 ^ (long)-949313563);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)875674008 ^ (long)875673915);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)591276711 ^ (long)591276578);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)901459585 ^ (long)901459668);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1432683838 ^ (long)1432683800);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-729991960 ^ (long)-729991987);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1353738673 ^ (long)-1353738617);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1583228067 ^ (long)1583227953);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-2124091920 ^ (long)-2124092101);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)432148844 ^ (long)432148941);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1374274426 ^ (long)-1374274362);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-494065776 ^ (long)-494065718);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)857402729 ^ (long)857402766);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1358576190 ^ (long)-1358576366);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1345622022 ^ (long)1345622047);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1643888869 ^ (long)1643888695);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-202993627 ^ (long)-202993564);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)49987592 ^ (long)49987717);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1803480818 ^ (long)-1803480814);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1215197007 ^ (long)1215197068);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)985058094 ^ (long)985058082);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-2087146244 ^ (long)-2087146260);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)397483825 ^ (long)397483844);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)605320846 ^ (long)605320887);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-258858292 ^ (long)-258858320);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-349556363 ^ (long)-349556261);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)778122398 ^ (long)778122465);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)894362124 ^ (long)894362264);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1889623178 ^ (long)-1889623281);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1273807972 ^ (long)-1273807928);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)274915341 ^ (long)274915346);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1853142471 ^ (long)1853142345);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-922537932 ^ (long)-922537974);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)739405121 ^ (long)739405229);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1036292332 ^ (long)1036292256);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)640281980 ^ (long)640282062);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1787217732 ^ (long)1787217764);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-514126518 ^ (long)-514126380);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)855333012 ^ (long)855332925);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-44873535 ^ (long)-44873591);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-524496973 ^ (long)-524497097);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1794921118 ^ (long)1794921205);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1845331323 ^ (long)-1845331323);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1132064385 ^ (long)-1132064465);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1715681032 ^ (long)1715681163);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1503632756 ^ (long)-1503632784);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1197143608 ^ (long)1197143735);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1013017329 ^ (long)1013017299);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1505316441 ^ (long)1505316352);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1096889559 ^ (long)1096889509);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-173340817 ^ (long)-173340743);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-321674246 ^ (long)-321674393);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1731937143 ^ (long)1731937252);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)2067880139 ^ (long)2067880055);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-663090542 ^ (long)-663090499);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-500538701 ^ (long)-500538798);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-231206113 ^ (long)-231205930);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1821704529 ^ (long)1821704666);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-235770694 ^ (long)-235770753);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)929400270 ^ (long)929400257);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-2135879562 ^ (long)-2135879507);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-674873326 ^ (long)-674873151);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)140791611 ^ (long)140791759);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1561634196 ^ (long)1561634081);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)768650903 ^ (long)768650754);
                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-188391987 ^ (long)-188392064);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)85636649 ^ (long)85636822)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1344581182 ^ (long)-1344557507)) >>> (int)((long)55392083 ^ (long)55392091)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1464624308 ^ (long)-1464624308);
            if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1334974086 ^ (long)-1334974088);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1780355546 ^ (long)-1780355547) | var5_6 << (int)((long)-1739605608 ^ (long)-1739605603)) ^ var3_4[var7_8]) & (int)((long)-125394796 ^ (long)-125394837);
                    if (1B.\u2003\u2004\u2007\u200c\u2008\u200b) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-326493980 ^ (long)-326493977) | var6_7 << (int)((long)-114024377 ^ (long)-114024382)) ^ var3_4[var7_8]) & (int)((long)194497881 ^ (long)194497958);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            1B.b[var2_3] = new String(var3_4).intern();
        }
        return 1B.b[var2_3];
    }

    public 1B(01 var1_1) {
        boolean bl = \u2003\u2004\u2007\u200c\u2008\u200b;
        super(var1_1, 1B.a((int)((long)-1067400122 ^ (long)-1067401619), (int)((long)301235760 ^ (long)301222270)) /* "Solid" */, null);
        this.1 = (1P)((34X)((34X)((34X)this.4().5(1B.a((int)((long)825355052 ^ (long)825331970), (int)((long)1631660349 ^ (long)-1631650299)) /* "Flowing" */)).7(1B.a((int)((long)347065311 ^ (long)347058679), (int)((long)-1332494956 ^ (long)-1332509573)) /* "flowing" */)).1(1B.a((int)((long)-899531177 ^ (long)-899529605), (int)((long)-246042246 ^ (long)246036602)) /* "Jesus stays active on flowing water blocks" */)).5();
        this.4 = (1P)((34X)((34X)((34X)this.4().5(1B.a((int)((long)-1946440846 ^ (long)-1946431139), (int)((long)1038314266 ^ (long)-1038315230)) /* "Extinguish" */)).7(1B.a((int)((long)-47604894 ^ (long)-47586993), (int)((long)-927527374 ^ (long)927509419)) /* "extinguish" */)).1(1B.a((int)((long)-1038004949 ^ (long)-1038010622), (int)((long)-669769793 ^ (long)-669773334)) /* "Dips down into the water when you're on fire" */)).5();
        this.7 = new Listener(f -> {
            block14: {
                int n;
                8S s;
                block18: {
                    block15: {
                        block17: {
                            block13: {
                                boolean bl;
                                block16: {
                                    bl = \u2003\u2004\u2007\u200c\u2008\u200b;
                                    if (bl || bl) break block13;
                                    BaritoneAPI.getSettings().assumeWalkOnWater.value = Boolean.TRUE;
                                    if (bl || bl) break block13;
                                    if (f.8 != EventState.PRE) break block14;
                                    if (bl || bl) break block13;
                                    f = 1B.3.s.cr();
                                    s = ((2)((Object)f)).getPos().7(0.0, 0.01, 0.0);
                                    if (bl || bl) break block13;
                                    this.2 = (int)((long)-1128115513 ^ (long)-1128115513);
                                    if (bl || bl) break block13;
                                    this.8 = (int)((long)-2138275295 ^ (long)-2138275295);
                                    if (bl || bl) break block13;
                                    if (!this.4.2) break block15;
                                    if (bl) break block13;
                                    if (f.aQ()) break block15;
                                    if (bl) break block13;
                                    if (f.bq()) break block16;
                                    if (bl) break block13;
                                    if (!1B.3.s.bq()) break block15;
                                    if (bl) break block13;
                                    if (1B.3.s.a(apw.l)) break block15;
                                    if (bl) break block13;
                                }
                                if (!bl) break block17;
                            }
                            return;
                        }
                        n = (int)((long)21433164 ^ (long)21433165);
                        if (\u2003\u2004\u2007\u200c\u2008\u200b) {
                            throw null;
                        }
                        break block18;
                    }
                    n = (int)((long)-2140640606 ^ (long)-2140640606);
                }
                if (n != 0) {
                    return;
                }
                if (1B.3.r.b(66.3(s)).a() != cuy.a) {
                    s = new fx(s.9, s.1, s.2);
                    if (1B.3.s.bz()) {
                        return;
                    }
                    if (!1B.4((fx)s) && !this.1.2) {
                        this.8 = (int)((long)-1982626675 ^ (long)-1982626676);
                        return;
                    }
                    4m.9((aqa)f, 0.13);
                    return;
                }
                s = s.4(0.0, 0.125, 0.0);
                s = new fx(s.9, s.1, s.2);
                ceh ceh2 = 1B.3.r.d_((fx)s);
                if (1B.3.s.C < 3.0f && !1B.3.s.bz() && ceh2.m().a() != cuy.a && (this.2 = 1B.4((fx)s))) {
                    int n2;
                    if (f == 1B.3.s) {
                        n2 = (int)((long)-203692983 ^ (long)-203692984);
                        if (\u2003\u2004\u2007\u200c\u2008\u200b) {
                            throw null;
                        }
                    } else {
                        n2 = (int)((long)-528600196 ^ (long)-528600196);
                    }
                    this.5 = n2;
                }
            }
        }, new Predicate[(int)((long)-1458348563 ^ (long)-1458348563)]);
        this.9C = new Listener(x2 -> {
            block8: {
                double d2;
                block9: {
                    block7: {
                        boolean bl = \u2003\u2004\u2007\u200c\u2008\u200b;
                        if (bl || bl) break block7;
                        if (!this.5) break block8;
                        if (!bl && !bl) break block9;
                    }
                    return;
                }
                4X x3 = x2;
                double d3 = x3.2.1;
                if (1B.3.s.K % (int)((long)-1057268625 ^ (long)-1057268627) == 0) {
                    d2 = 0.0125;
                    if (\u2003\u2004\u2007\u200c\u2008\u200b) {
                        throw null;
                    }
                } else {
                    d2 = 0.0;
                }
                x3.9(d3 + d2);
                x2.1 = (int)((long)-1474258548 ^ (long)-1474258547);
                this.5 = (int)((long)1638447279 ^ (long)1638447279);
            }
        }, new Predicate[(int)((long)-1215884073 ^ (long)-1215884073)]);
        this.0 = new Listener(w -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2003\u2004\u2007\u200c\u2008\u200b;
                        if (bl || bl) break block2;
                        if (!this.8) break block3;
                        if (bl || bl) break block2;
                        w.9.g = (int)((long)-134122297 ^ (long)-134122298);
                        if (bl || bl) break block2;
                        this.8 = (int)((long)1384434884 ^ (long)1384434884);
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-1794511519 ^ (long)-1794511519)]);
        9 = this;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean 4(fx fx2) {
        boolean bl = \u2003\u2004\u2007\u200c\u2008\u200b;
        if (bl || bl) return true;
        fx2 = 1B.3.r.b(fx2).c((brc)1B.3.r, fx2);
        if (fx2.b == 0.0) {
            if (bl) return true;
            if (fx2.d == 0.0) {
                if (bl) return true;
                return (int)((long)1875358997 ^ (long)1875358996) != 0;
            }
        }
        if (!bl) return (int)((long)-1481773272 ^ (long)-1481773272) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u2003\u2004\u2007\u200c\u2008\u200b;
                if (bl || bl) break block2;
                BaritoneAPI.getSettings().assumeWalkOnWater.value = Boolean.FALSE;
                if (bl || bl) break block2;
                this.2 = (int)((long)-242535105 ^ (long)-242535105);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 1B.\u2003\u2004\u2007\u200c\u2008\u200b;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)915072163 ^ (long)915072164)];
            if (var7) break block25;
            var3_2 = (int)((long)-1196856952 ^ (long)-1196856952);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\u2feb\u073a\u1482\u1c1f\u2fa2\u07c5\u14f5\u1c0e\u2f1b\u0720\u1468\u1c69\u2f7f\u0790\u14ff\u1c05\u2f7b\u0736\u1481\u1ca8\u2f04\u0708\u1465\u1c1d\u2f69\u07ab\u14b3\u1c51\u2f0e\u07ae\u14ed\u1c02\u2f54\u07f2\u1480\u1cdd\u2fe0\u0755\u149c\u1cdd\u2f1d\u078a\u144a\u1cc5\u2f1e\u07c8\u1494\u1c55\u2f6d\u07c8\u14bc\u1c90\u2f69\u0754\u14ed\u1c4a\u2f93\u0774\u1475\u1ccd\u2ffa\u076a\u140f\u1cc9\u2fad\u0700\u14bb\u1c49\u2fb8\u07de\u146a\u1c65\u2f86\u0747\u1493\u1cfc\u2f1c\u07dd\u1470\u1c6d\u2fda\u0736\u14a0\u1c4a\u2f38\u077c\u14bc\u1c01\u2f6c\u07a1\u14be\u1c08\u2f16\u07bc\u1491\u1cad\u2f0d\u077f\u1479\u1cc3\u2f51\u0742\u143b\u1c3a\u2f75\u0778\u1481\u1c3b\u2fdd\u070c\u145f\u1c8d\u2f2f\u0771\u14df\u1ca2\u2fd7", -481359369);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)1293153448 ^ (long)1293153442);
            if (var7) break block25;
            var0_6 = (int)((long)1313380821 ^ (long)-1313380822);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)1953266452 ^ (long)1953266477);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)-1660134885 ^ (long)1660134884);
                        if (1B.\u2003\u2004\u2007\u200c\u2008\u200b) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\u20da\u0842\u1b91\u13d5\u20f2\u0805\u1b47\u1313\u206b\u08a6\u1b37\u1334\u2048", 283379415);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)-1102460920 ^ (long)-1102460913);
                                var0_6 = (int)((long)163109328 ^ (long)-163109329);
                                while (true) {
                                    v0 = (int)((long)-1387226076 ^ (long)-1387226020);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)-1320390438 ^ (long)-1320390438);
                                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) ** continue;
                                    throw null;
                                }
                                1B.a = var5_1;
                                1B.b = new String[(int)((long)1743191290 ^ (long)1743191293)];
                                if (1B.\u2003\u2004\u2007\u200c\u2008\u200b) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)204565483 ^ (long)204565483);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)-1798339408 ^ (long)-1798339407)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)408999721 ^ (long)408999726)) {
                                    case 0: {
                                        v15 = (int)((long)837625707 ^ (long)837625617);
                                        if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)1442705326 ^ (long)1442705400);
                                        if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)-2043970373 ^ (long)-2043970369);
                                        if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)-1668841240 ^ (long)-1668841337);
                                        if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)-728196559 ^ (long)-728196565);
                                        if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)491917665 ^ (long)491917583);
                                        if (!1B.\u2003\u2004\u2007\u200c\u2008\u200b) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)-908835840 ^ (long)-908835779);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!1B.\u2003\u2004\u2007\u200c\u2008\u200b);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                1B.6 = dde.a((dci)new dci(0.0, 0.0, 0.0, 1.0, 0.99, 1.0));
                break;
            }
        }
    }
}

