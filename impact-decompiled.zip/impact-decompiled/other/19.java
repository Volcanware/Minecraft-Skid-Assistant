/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  bmb
 *  dcj
 *  dcl$a
 *  fx
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import clientapi.load.mixin.7.2;
import java.lang.invoke.LambdaMetafactory;
import java.util.List;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.2w;
import net.impactclient.2w$6X;
import net.impactclient.34X;
import net.impactclient.34c;
import net.impactclient.34p;
import net.impactclient.3sx;
import net.impactclient.4X;
import net.impactclient.5y;
import net.impactclient.66;
import net.impactclient.75;
import net.impactclient.7m;
import net.impactclient.86;
import net.impactclient.8S;
import net.impactclient.9V;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 19
extends 7m<75> {
    @EventHandler
    private final Listener<4X> 1;
    @EventHandler
    private final Listener<3sx> 4;
    private 1P 2;
    private fx 8;
    private static final 2w<bmb> 7;
    private 1P 5;
    private 9V 0y;
    private static final String[] b;
    private static final 2w<bmb> 6;
    public static final boolean \u200e\u2004\u200e\u2001\u2008\u200b;
    private int 0H;
    private int 0;
    private static final String[] a;

    /*
     * Enabled aggressive block sorting
     */
    private void 7() {
        block3: {
            block2: {
                boolean bl = \u200e\u2004\u200e\u2001\u2008\u200b;
                if (bl || bl) break block2;
                19.3.s.bm.d = this.0;
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var9 = 19.\u200e\u2004\u200e\u2001\u2008\u200b;
                if (!var9) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)-374355061 ^ (long)-374355070)];
            if (var9) break block25;
            var3_2 = (int)((long)1118876296 ^ (long)1118876296);
            if (var9) break block25;
            var2_3 = 2w$6X.KAOZ("\u00d6\u28ae\u3b27\u335f\u0017\u2878\u3bb0\u33b4\u0099\u2869\u3bce\u33a7*\u2867\u3b17\u3320\u00d3\u285c\u3b4a\u33af\u0095\u28f1\u3b77\u33bf\u0001\u281f\u3bd9\u33dd\u00e8\u28fb\u3b50\u33be3\u28f0\u3b7c\u3397\u00dc\u28a6\u3b84\u33f5h\u2886\u3b24\u33bf\u00d2\u2862\u3bbf\u3349_\u2838\u3bed\u3358g\u287c\u3bad\u336aU\u28b1\u3be1\u337c\u00c2\u28ba\u3b60\u33d1\u00cc\u28e5\u3bfc\u33a5\u0092\u28c7\u3bfa\u332e\u00be\u28f0\u3bef\u3398=\u28cc\u3bc2\u3380U\u2863\u3b9e\u3383(\u28de\u3bef\u33b5\u0089\u28cd\u3b41\u3307\u009e\u28d2\u3b6b\u3307\u00ef\u2849\u3b1e\u33d7\u00e4\u2810\u3be5\u33e6k\u28b7\u3bb5\u336b\t\u28a7\u3bbf\u338el\u2802\u3b7e\u33fb\u007f\u281c\u3b10\u3321T\u28f4\u3bed\u332af\u2820\u3b22\u33f0\u0087\u28c4\u3bd1\u3398`\u2833\u3bdf\u33b2\u00e6\u2835", -999807393);
            var4_4 = var2_3.length();
            if (var9) break block25;
            var1_5 = (int)((long)-1963177806 ^ (long)-1963177803);
            if (var9) break block25;
            var0_6 = (int)((long)1065113757 ^ (long)-1065113758);
            if (var9) break block25;
            block11: while (!var9) {
                block22: {
                    block21: {
                        v0 = (int)((long)-1418815217 ^ (long)-1418815121);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)812391906 ^ (long)-812391907);
                        if (19.\u200e\u2004\u200e\u2001\u2008\u200b) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\u0c46\u247b\u3796\u3fdb\u0c4f\u2412\u3721\u3ffe\u0c17\u240b\u379d\u3fea\u0ca9", 303114898);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)-136125993 ^ (long)-136125999);
                                var0_6 = (int)((long)-1306324639 ^ (long)1306324638);
                                while (true) {
                                    v0 = (int)((long)1571473537 ^ (long)1571473600);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)55826666 ^ (long)55826666);
                                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) ** continue;
                                    throw null;
                                }
                                19.a = var5_1;
                                19.b = new String[(int)((long)-1632117954 ^ (long)-1632117961)];
                                if (19.\u200e\u2004\u200e\u2001\u2008\u200b) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)460465903 ^ (long)460465903);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)852296396 ^ (long)852296397)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-766953008 ^ (long)-766953001)) {
                                    case 0: {
                                        v15 = (int)((long)-607520080 ^ (long)-607520047);
                                        if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)1920119146 ^ (long)1920119139);
                                        if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)192377141 ^ (long)192377156);
                                        if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)-324344846 ^ (long)-324344933);
                                        if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)357738977 ^ (long)357738882);
                                        if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)2017344196 ^ (long)2017344177);
                                        if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)-1237450394 ^ (long)-1237450494);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!19.\u200e\u2004\u200e\u2001\u2008\u200b);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                v17 = new Predicate[(int)((long)1094331272 ^ (long)1094331273)];
                v17[(int)((long)359487723 ^ (long)359487723)] = (Predicate<bmb>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, 1(bmb ), (Lbmb;)Z)();
                var8_8 = v17;
                var7_9 = new 5y<T>();
                new 5y<T>().1 = var8_8;
                19.6 = var7_9.7();
                v18 = new Predicate[(int)((long)-884516794 ^ (long)-884516793)];
                v18[(int)((long)-1812835807 ^ (long)-1812835807)] = (Predicate<bmb>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, 7(bmb ), (Lbmb;)Z)();
                var8_8 = v18;
                var7_9 = new 5y<T>();
                new 5y<T>().1 = var8_8;
                19.7 = var7_9.7();
                break;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 19.\u200e\u2004\u200e\u2001\u2008\u200b;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1787529046 ^ (long)-1787536604)) & (int)((long)-55751528 ^ (long)-55725209);
            if (var9_2) ** GOTO lbl-1000
            if (19.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 19.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-199048177 ^ (long)-199048177)] & (int)((long)1836270545 ^ (long)1836270382)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-961304973 ^ (long)-961304935);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-251805086 ^ (long)-251805094);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-2012801960 ^ (long)-2012801902);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)640539065 ^ (long)640538909);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1065904877 ^ (long)-1065904703);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)986695157 ^ (long)986695087);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)9193646 ^ (long)9193699);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)770838929 ^ (long)770838952);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-352808903 ^ (long)-352808834);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1243584327 ^ (long)-1243584358);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1168901952 ^ (long)1168902017);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)794866759 ^ (long)794866816);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-446926943 ^ (long)-446927079);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1525093166 ^ (long)1525093147);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-614091908 ^ (long)-614091823);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1927763290 ^ (long)-1927763433);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)2016651330 ^ (long)2016651409);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)844204324 ^ (long)844204327);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)2002656302 ^ (long)2002656356);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-161883681 ^ (long)-161883773);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1590591448 ^ (long)1590591485);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-772293534 ^ (long)-772293478);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1421784046 ^ (long)-1421783912);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1712188249 ^ (long)1712188193);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1340018707 ^ (long)-1340018808);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)186392182 ^ (long)186392169);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)2080320131 ^ (long)2080320148);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1558048098 ^ (long)-1558048153);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1033076433 ^ (long)1033076441);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-523749465 ^ (long)-523749417);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1128981993 ^ (long)-1128981993);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-2034498592 ^ (long)-2034498736);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1847886317 ^ (long)1847886166);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1792142435 ^ (long)-1792142401);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1598437836 ^ (long)-1598437726);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1577127101 ^ (long)1577126912);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1921262892 ^ (long)1921262971);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1141959707 ^ (long)1141959903);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)955908609 ^ (long)955908833);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)544071357 ^ (long)544071227);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)642802004 ^ (long)642801935);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-590305041 ^ (long)-590305212);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1301043002 ^ (long)-1301042982);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1729895682 ^ (long)-1729895707);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1136854750 ^ (long)-1136854717);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)7952047 ^ (long)7951974);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1429497632 ^ (long)-1429497721);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)535206127 ^ (long)535206049);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1039648945 ^ (long)1039648862);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1254893588 ^ (long)1254893592);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1775384745 ^ (long)1775384725);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-270271707 ^ (long)-270271576);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)332618540 ^ (long)332618621);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1034170398 ^ (long)1034170561);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1515235554 ^ (long)-1515235428);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-388221825 ^ (long)-388221919);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)2095505437 ^ (long)2095505467);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1223074096 ^ (long)-1223074213);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1268912990 ^ (long)1268913079);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-64019775 ^ (long)-64019728);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)598869518 ^ (long)598869718);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1348994461 ^ (long)-1348994493);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1130556701 ^ (long)1130556775);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)368862181 ^ (long)368862188);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-174294974 ^ (long)-174294922);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-175631666 ^ (long)-175631783);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1678975499 ^ (long)-1678975627);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)2139428469 ^ (long)2139428480);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-483664123 ^ (long)-483663908);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1929684215 ^ (long)1929683979);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1399362476 ^ (long)-1399362487);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1981981890 ^ (long)1981981815);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1409954138 ^ (long)1409954191);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)178887102 ^ (long)178887053);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1984242481 ^ (long)1984242661);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)104197464 ^ (long)104197541);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1391282281 ^ (long)-1391282423);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-207986722 ^ (long)-207986927);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)781454929 ^ (long)781454932);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1204049928 ^ (long)-1204050031);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)2005504312 ^ (long)2005504488);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1123269020 ^ (long)1123268930);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)219360155 ^ (long)219360062);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1625109899 ^ (long)-1625109799);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-320655734 ^ (long)-320655679);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1098422519 ^ (long)-1098422372);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-397774033 ^ (long)-397773992);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1848346809 ^ (long)-1848346826);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-951787002 ^ (long)-951786925);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1374904535 ^ (long)1374904514);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-2014610952 ^ (long)-2014611170);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-831783243 ^ (long)-831783211);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1957563675 ^ (long)-1957563740);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-234304061 ^ (long)-234304131);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-129477692 ^ (long)-129477664);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)584903571 ^ (long)584903551);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1000853351 ^ (long)-1000853393);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-433832341 ^ (long)-433832272);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1857635165 ^ (long)1857635113);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1210108554 ^ (long)1210108622);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-907254420 ^ (long)-907254389);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-2003907515 ^ (long)-2003907551);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)668750584 ^ (long)668750536);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-54066268 ^ (long)-54066361);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)693831035 ^ (long)693831016);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)926037936 ^ (long)0x37323722);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1142986197 ^ (long)1142986207);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-636767824 ^ (long)-636767985);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1581300961 ^ (long)-1581300890);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)317235827 ^ (long)317235911);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1210186496 ^ (long)1210186591);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1445308297 ^ (long)1445308385);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-859420584 ^ (long)-859420580);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1218986126 ^ (long)1218986124);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)943500177 ^ (long)943500221);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)683165992 ^ (long)683166113);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-653433472 ^ (long)-653433524);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)2105536005 ^ (long)2105536191);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)525521947 ^ (long)525521980);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-269282916 ^ (long)-269283045);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1840726505 ^ (long)-1840726344);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)318938708 ^ (long)318938815);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1692507974 ^ (long)1692508024);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1010168581 ^ (long)-1010168761);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-271645662 ^ (long)-271645617);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)858890983 ^ (long)858890984);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-838008590 ^ (long)-838008621);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1389015005 ^ (long)1389014796);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-102015929 ^ (long)-102015762);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1004393813 ^ (long)-1004393906);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1262261896 ^ (long)-1262261993);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1863618201 ^ (long)-1863618111);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)566496506 ^ (long)566496399);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)571081639 ^ (long)571081669);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1974414698 ^ (long)-1974414660);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1132659539 ^ (long)1132659487);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1263221393 ^ (long)-1263221304);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)163872112 ^ (long)163872113);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1471746754 ^ (long)-1471746800);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)943500861 ^ (long)943500942);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-110084957 ^ (long)-110085082);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-292541866 ^ (long)-292541938);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-2006937161 ^ (long)-2006937177);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-76652735 ^ (long)-76652730);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)270246005 ^ (long)270245899);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1645914849 ^ (long)-1645914775);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1664886873 ^ (long)-1664886815);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1027073351 ^ (long)1027073481);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1644165567 ^ (long)1644165412);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1632086771 ^ (long)-1632086537);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)516602511 ^ (long)516602477);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1425950064 ^ (long)-1425950019);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1302517840 ^ (long)1302517838);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1020745268 ^ (long)1020745248);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)834708912 ^ (long)834708955);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1540010093 ^ (long)-1540010171);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-949469768 ^ (long)-949469925);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-211687099 ^ (long)-211687096);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1223805706 ^ (long)1223805889);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-10211259 ^ (long)-10211244);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)140030108 ^ (long)140030041);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1489995695 ^ (long)-1489995535);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)924095052 ^ (long)924095114);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-339497512 ^ (long)-339497535);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)836987956 ^ (long)836987935);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1834238761 ^ (long)1834238856);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)2145398886 ^ (long)2145398961);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)123148659 ^ (long)123148661);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-926754639 ^ (long)-926754610);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1647288480 ^ (long)1647288385);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-881000554 ^ (long)-881000671);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1170104528 ^ (long)-1170104334);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)712378719 ^ (long)712378660);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-55931630 ^ (long)-55931477);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)189342517 ^ (long)189342660);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)457036300 ^ (long)457036357);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)2111758291 ^ (long)2111758255);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1995291638 ^ (long)-1995291593);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1002467586 ^ (long)-1002467643);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1544594388 ^ (long)-1544594206);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)542217543 ^ (long)542217495);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)995022288 ^ (long)995022126);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1389623610 ^ (long)1389623570);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1529555978 ^ (long)-1529556075);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1774795354 ^ (long)-1774795435);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)746591388 ^ (long)746591286);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-794453361 ^ (long)-794453392);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-478979142 ^ (long)-478979256);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1530831630 ^ (long)-1530831761);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-284908983 ^ (long)-284909050);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1246198711 ^ (long)1246198587);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)640121386 ^ (long)640121360);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1936739840 ^ (long)1936739992);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1373910086 ^ (long)1373910229);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-63632113 ^ (long)-63632090);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)473684108 ^ (long)473684087);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-167746318 ^ (long)-167746396);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)243645992 ^ (long)243646058);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1844587502 ^ (long)-1844587313);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1419083930 ^ (long)-1419083867);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1103141608 ^ (long)1103141525);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)976978528 ^ (long)976978527);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)713837634 ^ (long)713837787);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-678869840 ^ (long)-678869886);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)234722189 ^ (long)234722179);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1783725837 ^ (long)-1783725957);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1304858839 ^ (long)1304858647);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)513266099 ^ (long)513266171);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-708614925 ^ (long)-708615039);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-2135107710 ^ (long)-2135107723);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1228986798 ^ (long)1228986861);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-2095095184 ^ (long)-2095095068);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1275487388 ^ (long)-1275487433);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-943735073 ^ (long)-943735227);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)331225213 ^ (long)331225342);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1929490775 ^ (long)-1929490873);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)482830170 ^ (long)482830197);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-999536827 ^ (long)-999536782);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1701191342 ^ (long)-1701191229);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1125922251 ^ (long)-1125922149);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1130141447 ^ (long)-1130141667);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1633117994 ^ (long)1633117980);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)116417173 ^ (long)116417117);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)0x4885585 ^ (long)76043629);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-33451375 ^ (long)-33451445);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1214079240 ^ (long)-1214079476);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1269763482 ^ (long)-1269763475);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1684077072 ^ (long)1684077064);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)827222288 ^ (long)827222420);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-528597464 ^ (long)-528597391);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-2071823605 ^ (long)-2071823527);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1033400635 ^ (long)-1033400609);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)643010658 ^ (long)643010623);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1203904836 ^ (long)-1203904948);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)280025130 ^ (long)280025224);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)746536490 ^ (long)746536647);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)333815689 ^ (long)333815637);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1023702972 ^ (long)1023702804);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-157952092 ^ (long)-157952016);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1207094972 ^ (long)1207094954);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-385727340 ^ (long)-385727279);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1004794876 ^ (long)-1004794732);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)338519069 ^ (long)338519169);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1584007220 ^ (long)1584007250);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-412148266 ^ (long)-412148294);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-914702270 ^ (long)-914702141);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1373625404 ^ (long)-1373625509);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-2064010319 ^ (long)-2064010277);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1301235194 ^ (long)-1301235083);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1487194205 ^ (long)-1487194324);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1818082061 ^ (long)-1818082147);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1953299504 ^ (long)-1953299683);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1034915041 ^ (long)1034914977);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-702064642 ^ (long)-702064660);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1411933936 ^ (long)1411933766);
                    if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-994988190 ^ (long)-994988080);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1075198525 ^ (long)1075198658)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-149486603 ^ (long)-149423094)) >>> (int)((long)-1278664293 ^ (long)-1278664301)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-180861919 ^ (long)-180861919);
            if (!19.\u200e\u2004\u200e\u2001\u2008\u200b) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1441592668 ^ (long)1441592670);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1074891869 ^ (long)-1074891872) | var5_6 << (int)((long)-1239445584 ^ (long)-1239445579)) ^ var3_4[var7_8]) & (int)((long)-720910805 ^ (long)-720910636);
                    if (19.\u200e\u2004\u200e\u2001\u2008\u200b) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-125584245 ^ (long)-125584248) | var6_7 << (int)((long)-356353211 ^ (long)-356353216)) ^ var3_4[var7_8]) & (int)((long)2031981222 ^ (long)2031981145);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            19.b[var2_3] = new String(var3_4).intern();
        }
        return 19.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 2(int n) {
        block3: {
            block2: {
                boolean bl = \u200e\u2004\u200e\u2001\u2008\u200b;
                if (bl || bl) break block2;
                this.0 = 19.3.s.bm.d;
                if (bl || bl) break block2;
                19.3.s.bm.d = n;
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    public 19(75 object) {
        boolean bl = \u200e\u2004\u200e\u2001\u2008\u200b;
        super(object, 19.a((int)((long)1639378680 ^ (long)-1639370100), (int)((long)-1881253064 ^ (long)1881257994)) /* "Bucket" */, null);
        Boolean bl2 = Boolean.TRUE;
        object = (34X)((34X)((34X)this.4().5(19.a((int)((long)-1038858645 ^ (long)1038850585), (int)((long)-414721531 ^ (long)-414738298)) /* "Collect" */)).7(19.a((int)((long)-446566552 ^ (long)446575384), (int)((long)1334388903 ^ (long)1334379968)) /* "collect" */)).1(19.a((int)((long)-512431666 ^ (long)512439741), (int)((long)1075871317 ^ (long)1075861771)) /* "Collect the water once you've landed in it" */);
        ((34X)((34X)((34X)this.4().5(19.a((int)((long)-1038858645 ^ (long)1038850585), (int)((long)-414721531 ^ (long)-414738298)) /* "Collect" */)).7(19.a((int)((long)-446566552 ^ (long)446575384), (int)((long)1334388903 ^ (long)1334379968)) /* "collect" */)).1(19.a((int)((long)-512431666 ^ (long)512439741), (int)((long)1075871317 ^ (long)1075861771)) /* "Collect the water once you've landed in it" */)).7 = bl2;
        this.2 = (1P)((34X)object).5();
        bl2 = Boolean.FALSE;
        object = (34X)((34X)((34X)this.4().5(19.a((int)((long)1554522741 ^ (long)-1554514417), (int)((long)445109351 ^ (long)445087870)) /* "Lethal" */)).7(19.a((int)((long)-492290099 ^ (long)492299192), (int)((long)1046571030 ^ (long)1046567559)) /* "lethal" */)).1(19.a((int)((long)15426766 ^ (long)-15419207), (int)((long)-2016300658 ^ (long)2016302076)) /* "Only use the bucket when the fall is lethal" */);
        ((34X)((34X)((34X)this.4().5(19.a((int)((long)1554522741 ^ (long)-1554514417), (int)((long)445109351 ^ (long)445087870)) /* "Lethal" */)).7(19.a((int)((long)-492290099 ^ (long)492299192), (int)((long)1046571030 ^ (long)1046567559)) /* "lethal" */)).1(19.a((int)((long)15426766 ^ (long)-15419207), (int)((long)-2016300658 ^ (long)2016302076)) /* "Only use the bucket when the fall is lethal" */)).7 = bl2;
        this.5 = (1P)((34X)object).5();
        this.0H = 86.a;
        this.1 = new Listener(x2 -> {
            boolean bl = \u200e\u2004\u200e\u2001\u2008\u200b;
            if (bl || bl) return;
            switch (34p.5[x2.7.ordinal()]) {
                case 1: {
                    if (bl) return;
                    switch (34p.0[this.0H - (int)((long)1970191323 ^ (long)1970191322)]) {
                        case 1: {
                            int n;
                            int n2;
                            int n3;
                            int n4;
                            float f;
                            if (bl) return;
                            if (19.3.s.ao()) {
                                if (bl || bl) return;
                                return;
                            }
                            if (bl) return;
                            float f2 = 19.3.s.C - 3.0f;
                            if (f > 0.0f) {
                                if (bl) {
                                    return;
                                }
                                n4 = (int)((long)1514878230 ^ (long)1514878231);
                                if (\u200e\u2004\u200e\u2001\u2008\u200b) {
                                    throw null;
                                }
                            } else {
                                n4 = n3 = (int)((long)-405986538 ^ (long)-405986538);
                            }
                            if (f2 - 1.0f >= (float)((int)19.3.s.dk())) {
                                n2 = (int)((long)866944812 ^ (long)866944813);
                                if (\u200e\u2004\u200e\u2001\u2008\u200b) {
                                    throw null;
                                }
                            } else {
                                n2 = n = (int)((long)1298896354 ^ (long)1298896354);
                            }
                            if (this.5.2 ? n == 0 : n3 == 0) {
                                return;
                            }
                            n3 = 6.0((List<bmb>)19.3.s.bm.a);
                            if (n3 < 0) {
                                return;
                            }
                            34c.3(19.3.s.p, 90.0f, dcl2 -> {
                                boolean bl = \u200e\u2004\u200e\u2001\u2008\u200b;
                                if (bl || bl) return;
                                if (dcl2.c() == dcl.a.b) {
                                    if (bl || bl) return;
                                    x2.2(90.0f);
                                    if (bl || bl) return;
                                    this.2(n3);
                                    if (bl || bl) return;
                                    this.0H = 86.b;
                                    if (bl) return;
                                    return;
                                }
                                if (bl) return;
                                this.0H = 86.a;
                                if (!bl && !bl) return;
                            });
                            return;
                        }
                        case 2: {
                            this.0H = 86.a;
                            return;
                        }
                        case 3: {
                            8S s = ((2)19.3.s).getPos().7(0.0, 19.3.s.ce(), 0.0);
                            8S s2 = new 8S(this.8.u(), this.8.v(), this.8.w()).7(0.5, 0.5, 0.5);
                            if (s.4(s2) >= 4.25) {
                                this.0H = 86.a;
                                return;
                            }
                            if (!19.3.s.aE() || !19.3.s.aX()) return;
                            int n = 7.0((List<bmb>)19.3.s.bm.a);
                            if (n < 0) {
                                return;
                            }
                            this.0y = 66.3(s2);
                            x2.6(this.0y.6).2(this.0y.3);
                            this.2(n);
                            return;
                        }
                    }
                    return;
                }
                case 2: {
                    switch (34p.0[this.0H - (int)((long)606371787 ^ (long)606371786)]) {
                        case 2: {
                            34c.3(19.3.s.p, 90.0f, dcl2 -> {
                                int n;
                                block8: {
                                    block7: {
                                        boolean bl = \u200e\u2004\u200e\u2001\u2008\u200b;
                                        if (bl || bl) break block7;
                                        9.clickMouse((int)((long)-1986618833 ^ (long)-1986618834));
                                        if (bl || bl) break block7;
                                        this.8 = ((dcj)dcl2).a().b((int)((long)1233380705 ^ (long)1233380705), (int)((long)-1503656209 ^ (long)-1503656210), (int)((long)1167471769 ^ (long)1167471769));
                                        if (!bl && !bl) break block8;
                                    }
                                    return;
                                }
                                if (this.2.2) {
                                    n = 86.c;
                                    if (\u200e\u2004\u200e\u2001\u2008\u200b) {
                                        throw null;
                                    }
                                } else {
                                    n = 86.a;
                                }
                                this.0H = n;
                                this.7();
                            });
                            return;
                        }
                        case 3: {
                            if (this.0y == null) {
                                return;
                            }
                            34c.3(this.0y.6, this.0y.3, dcl2 -> {
                                block3: {
                                    block2: {
                                        boolean bl = \u200e\u2004\u200e\u2001\u2008\u200b;
                                        if (bl || bl) break block2;
                                        9.clickMouse((int)((long)333640066 ^ (long)333640067));
                                        if (bl || bl) break block2;
                                        this.0H = 86.a;
                                        if (bl || bl) break block2;
                                        this.7();
                                        if (!bl && !bl) break block3;
                                    }
                                    return;
                                }
                            });
                        }
                    }
                    return;
                }
            }
        }, new Predicate[(int)((long)1332567752 ^ (long)1332567752)]);
        this.4 = new Listener(sx -> {
            block3: {
                block2: {
                    boolean bl = \u200e\u2004\u200e\u2001\u2008\u200b;
                    if (bl || bl) break block2;
                    this.0H = 86.a;
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)-1558943213 ^ (long)-1558943213)]);
    }

    private static /* synthetic */ boolean 1(bmb bmb2) {
        boolean bl = \u200e\u2004\u200e\u2001\u2008\u200b;
        if (bl || bl) {
            return true;
        }
        return bmb2.b().a().equals(19.a((int)((long)-1708918923 ^ (long)1708927747), (int)((long)-219030532 ^ (long)219037417)) /* "item.bucketWater" */);
    }

    private static /* synthetic */ boolean 7(bmb bmb2) {
        boolean bl = \u200e\u2004\u200e\u2001\u2008\u200b;
        if (bl || bl) {
            return true;
        }
        return bmb2.b().a().equals(19.a((int)((long)2039534056 ^ (long)-2039542375), (int)((long)-1645624161 ^ (long)1645619261)) /* "item.bucket" */);
    }
}

