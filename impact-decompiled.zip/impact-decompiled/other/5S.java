/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  baritone.api.utils.Helper
 *  com.mojang.authlib.exceptions.AuthenticationException
 */
package net.impactclient;

import baritone.api.utils.Helper;
import com.mojang.authlib.exceptions.AuthenticationException;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Objects;
import net.impactclient.2w$6X;
import net.impactclient.34y;
import net.impactclient.3e;
import net.impactclient.5z;
import net.impactclient.81;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 5S
implements Helper {
    private static final String[] b;
    public static final boolean \u2003\u2002\u200e;
    private static final String[] a;

    /*
     * Unable to fully structure code
     */
    public static 34y 8() {
        block14: {
            block13: {
                block12: {
                    block11: {
                        block10: {
                            var5 = 5S.\u2003\u2002\u200e;
                            if (var5) lbl-1000:
                            // 30 sources

                            {
                                return null;
                            }
                            var1_1 = new byte[(int)((long)-655625238 ^ (long)-655625218)];
                            var0_3 = 3e.5();
                            if (var5 || var5) ** GOTO lbl-1000
                            new SecureRandom().nextBytes((byte[])var1_1);
                            if (var5 || var5) ** GOTO lbl-1000
                            var2_4 = new StringBuilder();
                            if (var5 || var5) ** GOTO lbl-1000
                            var3_5 = (int)((long)-370016105 ^ (long)-370016105);
                            if (var5) ** GOTO lbl-1000
                            do {
                                if (var5) ** GOTO lbl-1000
                                if (var3_5 >= (int)((long)119986333 ^ (long)119986313)) break block10;
                                if (var5) ** GOTO lbl-1000
                                var4_7 = var1_1[var3_5];
                                if (var5 || var5) ** GOTO lbl-1000
                                v0 = new Object[(int)((long)1303488514 ^ (long)1303488515)];
                                v0[(int)((long)897052821 ^ (long)897052821)] = var4_7;
                                v1 = var2_4.append(String.format(5S.a((int)((long)-2036945703 ^ (long)2036931822), (int)((long)1251851052 ^ (long)1251841111)) /* "%02x" */, v0));
                                if (var0_3 != null) break block11;
                                if (var5 || var5) ** GOTO lbl-1000
                                ++var3_5;
                                if (var5) ** GOTO lbl-1000
                            } while (var0_3 == null);
                            if (var5) ** GOTO lbl-1000
                        }
                        if (var5) ** GOTO lbl-1000
                        v1 = var2_4;
                    }
                    var1_1 = v1.substring((int)((long)828343099 ^ (long)828343098));
                    if (var5 || var5) ** GOTO lbl-1000
                    var2_4 = 2w$6X.KAOZ("\u46c2", -1662033896).concat(String.valueOf(var1_1));
                    if (var5) ** GOTO lbl-1000
                    try {
                        if (var5) ** GOTO lbl-1000
                        5S.mc.Y().joinServer(5S.mc.J().e(), 5S.mc.J().d(), (String)var2_4);
                        if (var5 || var5) ** GOTO lbl-1000
                        ** if (!5S.\u2003\u2002\u200e) goto lbl-1000
                    }
                    catch (AuthenticationException v2) {
                        if (var5 || var5) ** GOTO lbl-1000
                        return null;
                    }
lbl-1000:
                    // 1 sources

                    {
                        throw null;
                    }
lbl-1000:
                    // 1 sources

                    {
                    }
                    try {
                        if (var5) ** GOTO lbl-1000
                        v3 = 81.6(5S.a((int)((long)1588315751 ^ (long)-1588300207), (int)((long)-318787549 ^ (long)318777904)) /* "https://api.impactclient.net/v1/login/minecraft?hash=" */ + (String)var1_1 + 5S.a((int)((long)-1448652889 ^ (long)1448673172), (int)((long)1495849076 ^ (long)-1495845533)) /* "&username=" */ + 5S.mc.J().e().getName(), null);
                        var1_1 = v3;
                        if (v3.2()) break block12;
                        if (var5 || var5) ** GOTO lbl-1000
                        throw new IOException(5S.a((int)((long)-120527976 ^ (long)120542124), (int)((long)363599891 ^ (long)363618102)) /* "/login/minecraft is not ok, it's " */ + var1_1.2);
                    }
                    catch (IOException var1_2) {
                        if (var5 || var5) ** GOTO lbl-1000
                        5z.9.error(5S.a((int)((long)-786939812 ^ (long)786952300), (int)((long)-1045546611 ^ (long)1045561164)) /* "Error getting Impact API token from minecraft login" */, (Throwable)var1_2);
                        if (!var5 && !var5) ** break;
                        ** continue;
                        return null;
                    }
                }
                if (var5) ** GOTO lbl-1000
                var2_4 = 34y.8(var1_1.1());
                if (var2_4 != null) break block13;
                if (var5 || var5) ** GOTO lbl-1000
                5z.9.error(5S.a((int)((long)601485386 ^ (long)-601472897), (int)((long)-454749573 ^ (long)454722308)) /* "Invalid token " */ + var1_1.1());
                if (var5 || var5) ** GOTO lbl-1000
                return null;
            }
            if (var5) ** GOTO lbl-1000
            var1_1 = var2_4.1;
            if (var5 || var5) ** GOTO lbl-1000
            var3_6 = 5S.mc.J().e().getId().toString();
            if (var5 || var5) ** GOTO lbl-1000
            if (Objects.equals(var1_1, var3_6)) break block14;
            if (var5 || var5) ** GOTO lbl-1000
            5z.9.error(5S.a((int)((long)-264279345 ^ (long)264297213), (int)((long)-1327195502 ^ (long)-1327188620)) /* "Expected " */ + var3_6 + 5S.a((int)((long)-1877120056 ^ (long)1877138425), (int)((long)1412893840 ^ (long)1412916874)) /* " but got " */ + (String)var1_1);
            if (var5 || var5) ** GOTO lbl-1000
            return null;
        }
        if (var5) ** GOTO lbl-1000
        return var2_4;
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 5S.\u2003\u2002\u200e;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-514812351 ^ (long)514795123)) & (int)((long)1567686549 ^ (long)1567621226);
            if (var9_2) ** GOTO lbl-1000
            if (5S.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 5S.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1108803151 ^ (long)-1108803151)] & (int)((long)-736158341 ^ (long)-736158332)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-477199692 ^ (long)-477199736);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1921668399 ^ (long)1921668587);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-196772834 ^ (long)-196772768);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-42182164 ^ (long)-42182191);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)476717960 ^ (long)476717894);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-310608827 ^ (long)-310608866);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1614765352 ^ (long)-1614765492);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)610585811 ^ (long)610585632);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1785116685 ^ (long)1785116824);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1528874431 ^ (long)-1528874325);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)2095285005 ^ (long)2095285202);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1874595973 ^ (long)-1874595976);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)539188778 ^ (long)539188903);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1896636923 ^ (long)-1896636846);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-92497507 ^ (long)-92497528);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1602148238 ^ (long)1602148175);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1289011174 ^ (long)1289011086);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-8511789 ^ (long)-8511883);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-814017174 ^ (long)-814017277);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1951620229 ^ (long)1951620319);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)343855524 ^ (long)343855520);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1274378892 ^ (long)1274378952);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)2110104955 ^ (long)2110104933);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)173576063 ^ (long)173576075);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1434457762 ^ (long)1434457733);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-2083483180 ^ (long)-2083483274);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-616285856 ^ (long)-616285741);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1011433724 ^ (long)1011433606);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)2031314689 ^ (long)2031314926);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1574163367 ^ (long)1574163424);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1421909851 ^ (long)-1421909865);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1274355211 ^ (long)-1274355297);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1790810635 ^ (long)-1790810786);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)875401812 ^ (long)875401751);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-18997902 ^ (long)-18998003);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1719666634 ^ (long)-1719666492);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1977460490 ^ (long)-1977460593);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1106068398 ^ (long)-1106068350);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1322202329 ^ (long)1322202353);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-2067019891 ^ (long)-2067019809);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)37321792 ^ (long)37321964);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)42157817 ^ (long)42157668);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1088499674 ^ (long)-1088499506);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1035273984 ^ (long)-1035273853);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-750201387 ^ (long)-750201492);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1470688239 ^ (long)1470688137);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)498030055 ^ (long)498029853);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-190531716 ^ (long)-190531733);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1647160843 ^ (long)1647160902);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1616183517 ^ (long)-1616183434);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-175707081 ^ (long)-175707044);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-75412702 ^ (long)-75412565);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)2100096913 ^ (long)2100096915);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)395359118 ^ (long)395359058);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1306054227 ^ (long)-1306054169);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1898791310 ^ (long)-1898791343);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)963860929 ^ (long)963860922);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1183646690 ^ (long)-1183646674);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-891887715 ^ (long)-891887690);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-288245407 ^ (long)-288245300);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1524988685 ^ (long)-1524988895);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)828011882 ^ (long)828011900);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)797111468 ^ (long)797111476);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1806203949 ^ (long)1806203956);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1991699065 ^ (long)-1991698973);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1848418179 ^ (long)-1848418201);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1150823538 ^ (long)1150823529);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1483072567 ^ (long)1483072615);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)2039250086 ^ (long)2039250087);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-2114252224 ^ (long)-2114252048);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)528637767 ^ (long)528637951);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1238592387 ^ (long)1238592421);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)44827700 ^ (long)44827830);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1107397643 ^ (long)-1107397869);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-129347463 ^ (long)-129347357);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1520261684 ^ (long)1520261829);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1914841153 ^ (long)1914841116);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-203153348 ^ (long)-203153185);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)39464713 ^ (long)39464863);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-368740601 ^ (long)-368740588);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-131970780 ^ (long)-131970730);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1710726969 ^ (long)-1710727046);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-689638102 ^ (long)-689637962);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1115259352 ^ (long)1115259307);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1117509437 ^ (long)1117509627);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1743488223 ^ (long)1743488192);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1203997140 ^ (long)1203997140);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1510825263 ^ (long)-1510825360);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)692043767 ^ (long)692043754);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-596292573 ^ (long)-596292424);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1494154254 ^ (long)-1494154366);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)641466579 ^ (long)641466486);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1423725403 ^ (long)-1423725339);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1049234483 ^ (long)1049234538);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)2139730554 ^ (long)2139730561);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1178289006 ^ (long)-1178289107);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-484136342 ^ (long)-484136365);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-544954105 ^ (long)-544953977);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)172668430 ^ (long)172668630);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1764808207 ^ (long)1764808250);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1724150927 ^ (long)-1724150875);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)2074963199 ^ (long)2074962974);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1640714030 ^ (long)-1640714171);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1269632618 ^ (long)-1269632611);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-854838215 ^ (long)-854838032);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1862866239 ^ (long)1862866185);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)463836123 ^ (long)463835920);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1826976548 ^ (long)-1826976630);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)815904364 ^ (long)815904307);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1777526414 ^ (long)1777526486);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-602138516 ^ (long)-602138403);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)2086891232 ^ (long)2086891204);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-909965080 ^ (long)-909965062);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-881007034 ^ (long)-881006929);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-313355998 ^ (long)-313356015);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-534216089 ^ (long)-534216003);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1256777268 ^ (long)1256777248);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1968146597 ^ (long)1968146455);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1009656398 ^ (long)-1009656516);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)228021796 ^ (long)228021906);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1930195173 ^ (long)-1930195035);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1057697825 ^ (long)-1057697872);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1772651774 ^ (long)-1772651614);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)975932180 ^ (long)975932401);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-102979580 ^ (long)-102979388);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1534446966 ^ (long)-1534447050);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1966957409 ^ (long)1966957446);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-943848154 ^ (long)-943848159);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1223693347 ^ (long)-1223693476);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1919759416 ^ (long)1919759511);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-379882830 ^ (long)-379882856);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)866178614 ^ (long)866178705);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)380195814 ^ (long)380195615);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)2082483977 ^ (long)2082484199);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1678190659 ^ (long)1678190724);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-273614774 ^ (long)-273614644);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-204519148 ^ (long)-204518954);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1575588129 ^ (long)-1575588174);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-2065157338 ^ (long)-2065157171);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1800269328 ^ (long)-1800269381);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-260947787 ^ (long)-260947789);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1574341997 ^ (long)1574341987);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-950057374 ^ (long)-950057395);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-450706776 ^ (long)-450706913);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1835380108 ^ (long)1835380152);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1584942272 ^ (long)-1584942267);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)182209682 ^ (long)182209763);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)854217447 ^ (long)854217308);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1213776413 ^ (long)1213776592);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1845147508 ^ (long)-1845147551);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-2046584287 ^ (long)-2046584070);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1038074292 ^ (long)-1038074182);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-386188778 ^ (long)-386188646);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)216694187 ^ (long)216694178);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1450165271 ^ (long)-1450165359);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)609276891 ^ (long)609276899);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-425493826 ^ (long)-425493770);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1448152088 ^ (long)-1448152071);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1339329405 ^ (long)-1339329529);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-879315982 ^ (long)-879316009);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-703943912 ^ (long)-703943785);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1789728564 ^ (long)-1789728728);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1841047944 ^ (long)1841047808);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)735638367 ^ (long)735638306);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-474025388 ^ (long)-474025263);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1815893664 ^ (long)1815893645);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-296533791 ^ (long)-296533944);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1198337652 ^ (long)1198337537);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1646512847 ^ (long)1646512879);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)611213660 ^ (long)611213772);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)629030514 ^ (long)629030558);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1194304679 ^ (long)-1194304581);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1600450933 ^ (long)1600450903);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1115045083 ^ (long)-1115044874);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-475407983 ^ (long)-475408034);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1110540858 ^ (long)1110540920);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)849171744 ^ (long)849171941);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)878292493 ^ (long)878292699);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-700253881 ^ (long)-700253875);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)781486696 ^ (long)781486742);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1238456391 ^ (long)-1238456480);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)734108339 ^ (long)734108381);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1537589587 ^ (long)1537589751);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-502672753 ^ (long)-502672687);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)60253902 ^ (long)60253698);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)553701276 ^ (long)553701330);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1223172344 ^ (long)1223172203);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-113145200 ^ (long)-113145185);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)328686551 ^ (long)328686342);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)613995250 ^ (long)613995078);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)110395775 ^ (long)110395710);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)941845929 ^ (long)941845895);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-2057373764 ^ (long)-2057373854);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1964055508 ^ (long)1964055523);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1049918807 ^ (long)1049918921);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)657538678 ^ (long)657538791);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-39567510 ^ (long)-39567513);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-715015172 ^ (long)-715015324);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1363535680 ^ (long)1363535635);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1890011147 ^ (long)1890011263);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1540427179 ^ (long)-1540427054);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1660123480 ^ (long)1660123594);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1221291696 ^ (long)-1221291721);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1842821132 ^ (long)-1842821284);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)505932062 ^ (long)505932156);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-866528368 ^ (long)-866528435);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1364372311 ^ (long)1364372267);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-823523892 ^ (long)-823524025);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)340828998 ^ (long)340829132);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1096505370 ^ (long)1096505436);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1468707651 ^ (long)-1468707709);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1512019177 ^ (long)-1512019130);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-245876602 ^ (long)-245876506);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-266375122 ^ (long)-266375054);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)683853220 ^ (long)683853215);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-64373262 ^ (long)-64373353);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1037584906 ^ (long)-1037585067);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-2103761205 ^ (long)-2103761167);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)604979650 ^ (long)604979547);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1316695422 ^ (long)1316695375);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-940360214 ^ (long)-940360407);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-212335752 ^ (long)-212335667);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-939532996 ^ (long)-939533053);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1042115360 ^ (long)-1042115433);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1880361023 ^ (long)-1880361011);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-409938529 ^ (long)-409938590);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-965343532 ^ (long)-965343548);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)522545389 ^ (long)522545348);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1443040733 ^ (long)1443040522);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1403918222 ^ (long)1403918273);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1843500796 ^ (long)1843500614);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1263067430 ^ (long)-1263067579);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-55455290 ^ (long)-55455476);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)853665585 ^ (long)853665656);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-535458477 ^ (long)-535458405);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1352108672 ^ (long)-1352108680);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1964509328 ^ (long)1964509295);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-831926781 ^ (long)-831926773);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1081639630 ^ (long)-1081639528);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1778656645 ^ (long)1778656704);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-590902921 ^ (long)-590903018);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-427871779 ^ (long)-427871863);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)51359890 ^ (long)51359858);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)787802018 ^ (long)787801987);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1422900149 ^ (long)1422900032);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1243127831 ^ (long)-1243127905);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1924989553 ^ (long)-1924989469);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1970983031 ^ (long)-1970983129);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)633391645 ^ (long)633391850);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-940302523 ^ (long)-940302407);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1745722152 ^ (long)-1745722172);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)483024002 ^ (long)483024078);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1835491930 ^ (long)1835491983);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-517857506 ^ (long)-517857411);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)581451112 ^ (long)581451076);
                    if (!5S.\u2003\u2002\u200e) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1822814236 ^ (long)1822814444);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)509393663 ^ (long)509393408)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1552210312 ^ (long)1552164471)) >>> (int)((long)31665351 ^ (long)31665359)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)556666434 ^ (long)556666434);
            if (!5S.\u2003\u2002\u200e) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-332543450 ^ (long)-332543452);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)2039864517 ^ (long)2039864518) | var5_6 << (int)((long)929640834 ^ (long)929640839)) ^ var3_4[var7_8]) & (int)((long)-140883212 ^ (long)-140883445);
                    if (5S.\u2003\u2002\u200e) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1482350317 ^ (long)-1482350320) | var6_7 << (int)((long)1499274291 ^ (long)1499274294)) ^ var3_4[var7_8]) & (int)((long)-1774596358 ^ (long)-1774596603);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            5S.b[var2_3] = new String(var3_4).intern();
        }
        return 5S.b[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 5S.\u2003\u2002\u200e;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)856798573 ^ (long)856798565)];
            if (var7) break block23;
            var3_2 = (int)((long)-414079803 ^ (long)-414079803);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u6bec\u435f\u5059\u58cc\u6bfb\u437c\u5065\u58e0\u6be8\u43c6\u50fb\u58a8\u6b03\u43fb\u5076\u58e5\u6b57\u43e6\u50db\u5864\u6bbc\u43fb\u50c1\u58a5\u6bf6\u43fa\u505d\u5868\u6bb3\u4392\u5092\u58f4\u6b0b\u43e5\u5092\u588f\u6bb6\u43c1\u505e\u5840\u6b67\u432e\u50ba\u58b4\u6b9a\u43bc\u503e\u58e1\u6b92\u434f\u5023\u5845\u6b3c\u43fe\u5063\u58e2\u6b97\u4391\u50e6\u58a9\u6b30\u43ad\u50cd\u582a\u6b4e\u435c\u506a\u5878\u6b93\u4380\u5074\u58f0\u6b86\u43ef\u507b\u58e9\u6ba8\u43c6\u50a9\u58ff\u6b93\u433d\u50e5\u58fc\u6b58\u43ae\u50a8\u5839\u6bc4\u431c\u5027\u582d\u6bb3\u43d1\u505f\u582a\u6ba9\u43e5\u508d\u58e4\u6b15\u43f0\u5015\u5814\u6b7f\u43c8\u500b\u58a1\u6b38\u43e2\u50a0\u584b\u6b35\u43b2\u5018\u5848\u6b33\u4386\u5060\u5830\u6b8a\u4398\u508b\u5880\u6b94\u4344\u5030\u58a3\u6bc1\u434d\u508c\u5857\u6b71\u439c\u5052\u5886\u6b8b\u4327\u50f8\u5812\u6bcc", 1574915429);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1263022755 ^ (long)1263022762);
            if (var7) break block23;
            var0_6 = (int)((long)1341090218 ^ (long)-1341090219);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1278042733 ^ (long)1278042732);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-813148677 ^ (long)813148676);
                    if (5S.\u2003\u2002\u200e) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!5S.\u2003\u2002\u200e) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u2c15\u04ed\u175e\u1f0e\u2ced\u047c\u17a6\u1fb0\u2cda\u0498\u1753\u1fb6\u2c44\u04b1\u173f\u1f0a\u2c80\u0482\u173e\u1f09\u2c70\u04fe\u17c0\u1f38\u2c10\u0448\u178d\u1f43\u2c28\u0458\u173f\u1fb7\u2cc9\u049e\u17a5\u1f1e\u2c4f\u0451\u1744\u1f33\u2cc9\u0496\u17bc\u1fdc\u2c9b\u047c\u173a\u1f0a", -1411249607);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1988176682 ^ (long)-1988176649);
                            var0_6 = (int)((long)-2002579165 ^ (long)2002579164);
                            while (true) {
                                v0 = (int)((long)-1622222019 ^ (long)-1622221984);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1064210325 ^ (long)-1064210325);
                                if (!5S.\u2003\u2002\u200e) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!5S.\u2003\u2002\u200e) ** continue;
                                throw null;
                            }
                            5S.a = var5_1;
                            5S.b = new String[(int)((long)1051912876 ^ (long)1051912868)];
                            if (!5S.\u2003\u2002\u200e) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-866522563 ^ (long)-866522563);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1028206588 ^ (long)1028206589)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1285085766 ^ (long)1285085761)) {
                                case 0: {
                                    v15 = (int)((long)188885578 ^ (long)188885514);
                                    if (!5S.\u2003\u2002\u200e) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)910719449 ^ (long)910719363);
                                    if (!5S.\u2003\u2002\u200e) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1169143667 ^ (long)1169143586);
                                    if (!5S.\u2003\u2002\u200e) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1070536084 ^ (long)-1070536178);
                                    if (!5S.\u2003\u2002\u200e) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)416677899 ^ (long)416677976);
                                    if (!5S.\u2003\u2002\u200e) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)705952825 ^ (long)705952852);
                                    if (!5S.\u2003\u2002\u200e) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)570291554 ^ (long)570291576);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!5S.\u2003\u2002\u200e);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

