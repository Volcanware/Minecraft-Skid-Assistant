/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.07;
import net.impactclient.1K;
import net.impactclient.2w$6X;
import net.impactclient.34e;
import net.impactclient.3e;
import net.impactclient.4f;
import net.impactclient.4m;
import net.impactclient.5Q;
import net.impactclient.7m;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7F
extends 7m<07> {
    private 1K 6;
    private static final String[] b;
    public static final boolean \u200a\u200d\u200c;
    private static final String[] a;
    @EventHandler
    private final Listener<4f> 9;

    public 7F(07 object) {
        boolean bl = \u200a\u200d\u200c;
        super(object, 7F.a((int)((long)87553940 ^ (long)-87537458), (int)((long)-1708913082 ^ (long)1708902525)) /* "3D" */, null);
        Double d2 = 1.0;
        object = ((34e)((34e)((34e)this.7().5(7F.a((int)((long)-1739722757 ^ (long)1739739298), (int)((long)-323136204 ^ (long)-323127035)) /* "Speed" */)).7(7F.a((int)((long)-1248993468 ^ (long)1249009692), (int)((long)1794543131 ^ (long)-1794571729)) /* "speed" */)).1(7F.a((int)((long)-820322090 ^ (long)820338573), (int)((long)2041146898 ^ (long)2041132457)) /* "Flight speed" */)).3(1.0).2(20.0);
        ((34e)((34e)((34e)this.7().5(7F.a((int)((long)-1739722757 ^ (long)1739739298), (int)((long)-323136204 ^ (long)-323127035)) /* "Speed" */)).7(7F.a((int)((long)-1248993468 ^ (long)1249009692), (int)((long)1794543131 ^ (long)-1794571729)) /* "speed" */)).1(7F.a((int)((long)-820322090 ^ (long)820338573), (int)((long)2041146898 ^ (long)2041132457)) /* "Flight speed" */)).3(1.0).2(20.0).7 = d2;
        this.6 = (1K)((34e)object).5();
        this.9 = new Listener(f -> {
            float f2;
            float f3;
            double d2;
            double d3;
            double d4;
            block30: {
                block33: {
                    String[] stringArray;
                    block32: {
                        block31: {
                            int n;
                            boolean bl = \u200a\u200d\u200c;
                            if (bl || bl) return;
                            d4 = 4m.1(5Q.b) * this.6.1;
                            if (bl || bl) return;
                            d3 = 7F.3.s.aT;
                            if (bl) return;
                            d2 = 7F.3.s.aR;
                            stringArray = 3e.5();
                            if (bl || bl) return;
                            f3 = 7F.3.s.p;
                            if (bl || bl) return;
                            f2 = 7F.3.s.q;
                            if (bl || bl) return;
                            if (d3 == 0.0) {
                                if (bl) return;
                                if (d2 == 0.0) {
                                    if (bl || bl) return;
                                    4m.4(0.0);
                                    if (bl || bl) return;
                                    4m.1(0.0);
                                    if (bl || bl) return;
                                    4m.2(0.0);
                                    if (bl) return;
                                    return;
                                }
                            }
                            if (bl) return;
                            if (d3 == 0.0) break block30;
                            if (bl || bl) return;
                            if (!(d2 > 0.0)) break block31;
                            if (bl || bl) {
                                return;
                            }
                            if (d3 > 0.0) {
                                n = (int)((long)-1867322772 ^ (long)1867322815);
                                if (\u200a\u200d\u200c) {
                                    throw null;
                                }
                            } else {
                                n = (int)((long)958472827 ^ (long)958472790);
                            }
                            f3 += (float)n;
                            if (stringArray == null) break block32;
                        }
                        if (d2 < 0.0) {
                            int n;
                            if (d3 > 0.0) {
                                n = (int)((long)-1813442436 ^ (long)-1813442479);
                                if (\u200a\u200d\u200c) {
                                    throw null;
                                }
                            } else {
                                n = (int)((long)-264768082 ^ (long)264768125);
                            }
                            f3 += (float)n;
                        }
                    }
                    d2 = 0.0;
                    if (!(d3 > 0.0)) break block33;
                    d3 = 1.0;
                    if (stringArray == null) break block30;
                }
                if (d3 < 0.0) {
                    d3 = -1.0;
                }
            }
            double d5 = afm.a((float)((float)Math.toRadians(f3 + 90.0f)));
            double d6 = afm.b((float)((float)Math.toRadians(f3 + 90.0f)));
            f3 = (float)Math.toRadians(f3);
            f2 = (float)Math.toRadians(f2);
            double d7 = -afm.a((float)f3) * afm.b((float)f2);
            double d8 = afm.b((float)f3) * afm.b((float)f2);
            double d9 = -afm.a((float)f2);
            4m.4(d3 * d4 * d7 + d2 * d4 * d5);
            4m.2(d3 * d4 * d8 - d2 * d4 * d6);
            4m.1(d3 * d4 * d9);
        }, new Predicate[(int)((long)1577902986 ^ (long)1577902986)]);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7F.\u200a\u200d\u200c;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1825746844 ^ (long)1825746840)];
            if (var7) break block23;
            var3_2 = (int)((long)-1907777665 ^ (long)-1907777665);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ue55c\ucc8b\udf45\ud73e\ue581\ucc03\udf34\ud768\ue517\ucc27\udfb0", 883212975);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-896636395 ^ (long)-896636400);
            if (var7) break block23;
            var0_6 = (int)((long)1507712696 ^ (long)-1507712697);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)910198047 ^ (long)910198025);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1877773116 ^ (long)1877773115);
                    if (7F.\u200a\u200d\u200c) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7F.\u200a\u200d\u200c) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u308a\u19b4\u0a5c\u02a1\u30bf\u1944\u0a61\u021f\u3042\u1985\u0adc\u0210\u3048\u194e\u0a3d", -395175963);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-692654331 ^ (long)-692654329);
                            var0_6 = (int)((long)-954150816 ^ (long)954150815);
                            while (true) {
                                v0 = (int)((long)903577521 ^ (long)903577551);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1833791964 ^ (long)1833791964);
                                if (!7F.\u200a\u200d\u200c) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7F.\u200a\u200d\u200c) ** continue;
                                throw null;
                            }
                            7F.a = var5_1;
                            7F.b = new String[(int)((long)1499163973 ^ (long)1499163969)];
                            if (!7F.\u200a\u200d\u200c) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-2053730803 ^ (long)-2053730803);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-27239668 ^ (long)-27239667)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1842145090 ^ (long)-1842145095)) {
                                case 0: {
                                    v15 = (int)((long)1510929702 ^ (long)1510929698);
                                    if (!7F.\u200a\u200d\u200c) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)830157736 ^ (long)830157730);
                                    if (!7F.\u200a\u200d\u200c) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-2005298001 ^ (long)-2005297983);
                                    if (!7F.\u200a\u200d\u200c) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1092903858 ^ (long)1092903901);
                                    if (!7F.\u200a\u200d\u200c) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)546710711 ^ (long)546710749);
                                    if (!7F.\u200a\u200d\u200c) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)339692866 ^ (long)339692923);
                                    if (!7F.\u200a\u200d\u200c) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-2048619480 ^ (long)-2048619457);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7F.\u200a\u200d\u200c);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 7F.\u200a\u200d\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-390518832 ^ (long)390502536)) & (int)((long)2058595589 ^ (long)2058572538);
            if (var9_2) ** GOTO lbl-1000
            if (7F.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7F.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)521029660 ^ (long)521029660)] & (int)((long)-454340660 ^ (long)-454340813)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-542699471 ^ (long)-542699472);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1257811649 ^ (long)1257811605);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)2088511643 ^ (long)2088511512);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)978891983 ^ (long)978892010);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1742661057 ^ (long)-1742661016);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1420596249 ^ (long)1420596265);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1244002684 ^ (long)1244002706);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)674960883 ^ (long)674960715);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1794328160 ^ (long)1794328151);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)875547904 ^ (long)875548153);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)542381268 ^ (long)542381253);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-214985868 ^ (long)-214985784);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)69711399 ^ (long)69711612);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-578380524 ^ (long)-578380384);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1335277005 ^ (long)1335276851);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-534445284 ^ (long)-534445147);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1535663967 ^ (long)1535663961);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)389333973 ^ (long)389333873);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1577445435 ^ (long)-1577445540);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1138465986 ^ (long)1138465844);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-363206699 ^ (long)-363206817);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1313880170 ^ (long)-1313880265);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-630700944 ^ (long)-630700899);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)459923611 ^ (long)459923551);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)929126008 ^ (long)929125976);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-207132896 ^ (long)-207132733);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-141703655 ^ (long)-141703546);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-930521863 ^ (long)-930521951);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-703439098 ^ (long)-703439003);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1528102738 ^ (long)1528102829);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1814379129 ^ (long)-1814379044);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1772619741 ^ (long)-1772619749);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)262553675 ^ (long)262553795);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1184166312 ^ (long)1184166189);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)977005804 ^ (long)977005610);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1476871064 ^ (long)1476870995);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1999956884 ^ (long)-1999956781);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1591960715 ^ (long)1591960712);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1432324725 ^ (long)-1432324786);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1432065898 ^ (long)1432066046);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1290699124 ^ (long)-1290699252);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1877099865 ^ (long)1877099818);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-822857807 ^ (long)-822857874);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-395124448 ^ (long)-395124402);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1981418196 ^ (long)-1981418108);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1244542294 ^ (long)1244542328);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-749214873 ^ (long)-749214906);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)2025125585 ^ (long)2025125535);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1462650733 ^ (long)-1462650801);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)558710428 ^ (long)558710447);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1288207678 ^ (long)-1288207765);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1304717411 ^ (long)-1304717377);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-2139630417 ^ (long)-2139630579);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1242798486 ^ (long)-1242798356);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1404038110 ^ (long)1404038075);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)723140780 ^ (long)723140642);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1499770405 ^ (long)-1499770532);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1901356509 ^ (long)1901356484);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-958238108 ^ (long)-958237996);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)36909121 ^ (long)36909266);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)139417226 ^ (long)139417160);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-565489277 ^ (long)-565489324);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)948327715 ^ (long)948327808);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)689759325 ^ (long)689759452);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)337750854 ^ (long)337750804);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)799410018 ^ (long)799410097);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1134452075 ^ (long)-1134452128);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1071981923 ^ (long)-1071981903);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1410386768 ^ (long)1410386818);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)553969900 ^ (long)553969841);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)758250487 ^ (long)758250253);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-612283763 ^ (long)-612283872);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1840195730 ^ (long)-1840195648);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-2127729721 ^ (long)-2127729692);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)896868432 ^ (long)896868379);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-178639519 ^ (long)-178639459);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)881036241 ^ (long)881036168);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-2107753317 ^ (long)-2107753336);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-2046079241 ^ (long)-2046079473);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)991627433 ^ (long)991627408);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-688410418 ^ (long)-688410414);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)505176637 ^ (long)505176631);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1287433957 ^ (long)1287433742);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-476948961 ^ (long)-476948831);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1686405257 ^ (long)-1686405178);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)516448796 ^ (long)516448806);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-681215898 ^ (long)-681215886);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)864732296 ^ (long)864732207);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1710190745 ^ (long)-1710190743);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-482981673 ^ (long)-482981744);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1840316556 ^ (long)1840316636);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1369273810 ^ (long)-1369273746);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)704018626 ^ (long)704018521);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1487793413 ^ (long)1487793491);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-666328113 ^ (long)-666328158);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1795257586 ^ (long)1795257550);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)910365067 ^ (long)910365180);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1669534275 ^ (long)-1669534269);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1006025805 ^ (long)-1006025758);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)369144792 ^ (long)369144594);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)688553759 ^ (long)688553944);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1357123326 ^ (long)1357123300);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-289646317 ^ (long)-289646084);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-272916647 ^ (long)-272916643);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-941080413 ^ (long)-941080345);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1294795057 ^ (long)1294795247);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1822194181 ^ (long)-1822194331);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-868752799 ^ (long)-868752664);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1062457935 ^ (long)-1062457890);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)256358198 ^ (long)256358276);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1604339173 ^ (long)1604339107);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-27949736 ^ (long)-27949656);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1997677661 ^ (long)-1997677705);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1416287950 ^ (long)-1416287976);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1356755284 ^ (long)1356755389);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1903936839 ^ (long)-1903936808);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)112678047 ^ (long)112678040);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1877228405 ^ (long)1877228378);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1912683590 ^ (long)1912683601);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1503105435 ^ (long)-1503105504);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)715617341 ^ (long)715617366);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1007231577 ^ (long)1007231515);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1585560359 ^ (long)-1585560519);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1980482992 ^ (long)1980482925);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1010284272 ^ (long)1010284211);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)930532529 ^ (long)930532426);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-935365960 ^ (long)-935365936);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)793853929 ^ (long)793853734);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1332349517 ^ (long)-1332349528);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-795479783 ^ (long)-795479623);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-2027636587 ^ (long)-2027636736);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)875241629 ^ (long)875241659);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-4776305 ^ (long)-4776322);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1288273717 ^ (long)-1288273857);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)217407499 ^ (long)217407585);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)2024626869 ^ (long)2024626768);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1713744240 ^ (long)-1713744265);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)222267668 ^ (long)222267652);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1718654727 ^ (long)1718654798);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-198496853 ^ (long)-198496995);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-146673499 ^ (long)-146673634);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-842647562 ^ (long)-842647749);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)161978483 ^ (long)161978530);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)747152299 ^ (long)747152193);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)422857005 ^ (long)422857040);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1527759125 ^ (long)-1527759206);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1469894800 ^ (long)-1469894828);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-370549388 ^ (long)-370549276);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1448498547 ^ (long)-1448498576);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)474276211 ^ (long)474276204);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1475424600 ^ (long)-1475424558);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)844712037 ^ (long)844712041);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-763784109 ^ (long)-763784033);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-902052272 ^ (long)-902052107);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1219783058 ^ (long)-1219782981);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1156759714 ^ (long)-1156759777);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)144510178 ^ (long)144509956);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-759383033 ^ (long)-759382996);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)300555961 ^ (long)300556005);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-130234487 ^ (long)-130234593);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)594275726 ^ (long)594275751);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1717177650 ^ (long)-1717177605);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1847290888 ^ (long)-1847291080);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1992452429 ^ (long)1992452542);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1613050298 ^ (long)-1613050134);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)405407006 ^ (long)405407086);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1357365204 ^ (long)1357365068);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-389330489 ^ (long)-389330484);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-501325667 ^ (long)-501325580);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1157953569 ^ (long)-1157953723);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)2042763718 ^ (long)2042763556);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-880960750 ^ (long)-880960736);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1325845041 ^ (long)-1325845115);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1484357544 ^ (long)-1484357482);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1500520195 ^ (long)-1500520340);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1361400176 ^ (long)-1361400146);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-57388073 ^ (long)-57388070);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1000933717 ^ (long)-1000933849);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1710423237 ^ (long)1710423229);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-815982133 ^ (long)-815982130);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)292528926 ^ (long)292529080);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)340046588 ^ (long)340046451);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1734714260 ^ (long)-1734714204);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1554253760 ^ (long)1554253756);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1622145211 ^ (long)1622145119);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1486299018 ^ (long)1486299018);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)755170007 ^ (long)755170014);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)33578186 ^ (long)33578119);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-784523451 ^ (long)-784523422);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1907641194 ^ (long)1907641136);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-351491681 ^ (long)-351491832);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)2065552124 ^ (long)2065552071);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-864512400 ^ (long)-864512377);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)345958228 ^ (long)345958194);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1222208512 ^ (long)-1222208371);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-776725867 ^ (long)-776725775);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)855924988 ^ (long)855924880);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)787537525 ^ (long)787537639);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)986672432 ^ (long)986672562);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1244023164 ^ (long)1244023188);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)42196371 ^ (long)42196429);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)216657349 ^ (long)216657400);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1544532679 ^ (long)1544532503);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-171367923 ^ (long)-171367721);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1700897625 ^ (long)1700897690);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)79097811 ^ (long)79097772);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)869987971 ^ (long)869988011);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-895842977 ^ (long)-895842937);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-191909128 ^ (long)-191909172);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1737186575 ^ (long)-1737186684);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1740629405 ^ (long)1740629503);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)22963461 ^ (long)22963585);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)309511535 ^ (long)309511432);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1500262683 ^ (long)1500262866);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-690410053 ^ (long)-690410099);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1546381413 ^ (long)1546381331);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-364883364 ^ (long)-364883299);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-593406076 ^ (long)-593406068);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)940790403 ^ (long)940790334);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1353783629 ^ (long)-1353783668);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-707885890 ^ (long)-707886071);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)342794666 ^ (long)342794611);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-941408660 ^ (long)-941408652);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1548774374 ^ (long)1548774217);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-878338049 ^ (long)-878338132);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-131477686 ^ (long)-131477704);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)23845993 ^ (long)23846004);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-517275838 ^ (long)-517275890);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1859321188 ^ (long)1859321119);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1405443934 ^ (long)1405443904);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-856309318 ^ (long)-856309298);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-119617175 ^ (long)-119617062);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-2111325143 ^ (long)-2111325028);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1338091220 ^ (long)-1338091130);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-653159596 ^ (long)-653159499);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1988897572 ^ (long)1988897545);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1080300823 ^ (long)1080300910);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-390798394 ^ (long)-390798515);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1406864711 ^ (long)1406864679);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-61076726 ^ (long)-61076516);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1300742204 ^ (long)-1300742346);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1130811705 ^ (long)1130811861);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)834687576 ^ (long)834687495);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1891466413 ^ (long)-1891466469);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-719409549 ^ (long)-719409425);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)2143128675 ^ (long)2143128689);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1654003711 ^ (long)1654003696);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1511398062 ^ (long)-1511398076);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1296540314 ^ (long)-1296540165);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-2072771826 ^ (long)-2072771749);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)104070661 ^ (long)104070830);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1854240541 ^ (long)-1854240522);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1782173350 ^ (long)1782173417);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-915183044 ^ (long)-915182970);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)930990583 ^ (long)930990534);
                    if (!7F.\u200a\u200d\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1561344412 ^ (long)1561344414);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)664720316 ^ (long)664720195)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1030600132 ^ (long)-1030572605)) >>> (int)((long)1193439832 ^ (long)1193439824)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-276936471 ^ (long)-276936471);
            if (!7F.\u200a\u200d\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)279536370 ^ (long)279536368);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1948323312 ^ (long)1948323315) | var5_6 << (int)((long)177442621 ^ (long)177442616)) ^ var3_4[var7_8]) & (int)((long)-1558381889 ^ (long)-1558382016);
                    if (7F.\u200a\u200d\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)328521396 ^ (long)328521399) | var6_7 << (int)((long)632323620 ^ (long)632323617)) ^ var3_4[var7_8]) & (int)((long)-219608431 ^ (long)-219608466);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7F.b[var2_3] = new String(var3_4).intern();
        }
        return 7F.b[var2_3];
    }
}

