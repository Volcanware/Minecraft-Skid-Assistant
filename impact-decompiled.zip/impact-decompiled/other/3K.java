/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  buo
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonPrimitive
 *  gm
 *  pw.knx.feather.structures.Color
 *  vk
 */
package net.impactclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.lang.reflect.Type;
import java.util.Objects;
import net.impactclient.1J;
import net.impactclient.2w$6X;
import net.impactclient.349;
import net.impactclient.3b;
import net.impactclient.3e;
import net.impactclient.5w;
import net.impactclient.8D;
import net.impactclient.8T;
import net.impactclient.8z;
import pw.knx.feather.structures.Color;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3K
implements 349<buo> {
    public static final boolean \u200c\u2002\u2008;
    private static final String[] b;
    private static final String[] a;

    /*
     * Enabled aggressive block sorting
     */
    public static JsonArray 7(3b b2) {
        boolean bl = \u200c\u2002\u2008;
        if (bl || bl) return null;
        JsonArray jsonArray = new JsonArray();
        if (bl || bl) return null;
        b2.9().stream().map(3K::8).filter(Objects::nonNull).forEach(arg_0 -> ((JsonArray)jsonArray).add(arg_0));
        if (bl || bl) return null;
        if (jsonArray.size() > 0) {
            if (bl) return null;
            return jsonArray;
        }
        if (!bl) return null;
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean 9(Type type) {
        boolean bl = \u200c\u2002\u2008;
        if (bl || bl) return true;
        if (type instanceof Class) {
            if (bl) return true;
            if (buo.class.isAssignableFrom((Class)type)) {
                if (bl) return true;
                return (int)((long)-109666705 ^ (long)-109666706) != 0;
            }
        }
        if (!bl) return (int)((long)-963903385 ^ (long)-963903385) != 0;
        return true;
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 3K.\u200c\u2002\u2008;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)532919853 ^ (long)-532931938)) & (int)((long)-1797681171 ^ (long)-1797689326);
            if (var9_2) ** GOTO lbl-1000
            if (3K.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3K.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-763457239 ^ (long)-763457239)] & (int)((long)1510354693 ^ (long)1510354938)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1181922258 ^ (long)1181922227);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1261493022 ^ (long)1261493099);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-2096311396 ^ (long)-2096311303);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-589327700 ^ (long)-589327799);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1121872185 ^ (long)1121872232);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)770349294 ^ (long)770349118);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)766252996 ^ (long)766253011);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1953117484 ^ (long)1953117486);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1110298901 ^ (long)1110298980);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)676609764 ^ (long)676609580);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)27543933 ^ (long)27543894);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-212538148 ^ (long)-212538114);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-531230373 ^ (long)-531230401);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1735086155 ^ (long)1735086313);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1372985875 ^ (long)-1372985900);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)803398838 ^ (long)803398786);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1424345976 ^ (long)1424345931);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1739223892 ^ (long)-1739224025);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1621401400 ^ (long)1621401367);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)845744135 ^ (long)845744315);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)372989753 ^ (long)372989807);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1470680102 ^ (long)-1470680084);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-660480426 ^ (long)-660480290);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1359964011 ^ (long)-1359964112);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1543336653 ^ (long)-1543336518);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1083093967 ^ (long)-1083093797);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-919538991 ^ (long)-919538986);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)850181249 ^ (long)850181145);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)987697125 ^ (long)987696990);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-726763206 ^ (long)-726763027);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)985488170 ^ (long)985488149);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)605507718 ^ (long)605507722);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1171250544 ^ (long)1171250640);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-71358845 ^ (long)-71358890);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-729395464 ^ (long)-729395574);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)122546899 ^ (long)122546865);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1626785902 ^ (long)1626786001);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1874600273 ^ (long)1874600220);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1836693481 ^ (long)-1836693297);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1048942476 ^ (long)-1048942441);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-944379819 ^ (long)-944379694);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-488313783 ^ (long)-488313770);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)295133224 ^ (long)295133250);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-110487926 ^ (long)-110488016);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1220066824 ^ (long)-1220067070);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)913794701 ^ (long)913794718);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)698380620 ^ (long)698380629);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-832187484 ^ (long)-832187433);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1335771441 ^ (long)-1335771401);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1073759815 ^ (long)-1073759775);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-848867009 ^ (long)-848866957);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1580484267 ^ (long)1580484310);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1706806813 ^ (long)1706807018);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)529078734 ^ (long)529078671);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1462093311 ^ (long)-1462093070);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-29163734 ^ (long)-29163538);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1261385188 ^ (long)1261385080);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1730200662 ^ (long)-1730200825);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1830566624 ^ (long)1830566525);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1424889605 ^ (long)1424889769);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1907807461 ^ (long)1907807422);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1823890988 ^ (long)1823891136);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1652870745 ^ (long)-1652870878);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-215636706 ^ (long)-215636600);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1166633349 ^ (long)-1166633256);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)995735164 ^ (long)995735196);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1834916305 ^ (long)-1834916127);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-2125032391 ^ (long)-2125032334);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1631408992 ^ (long)-1631408968);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1947300015 ^ (long)-1947300029);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)645217965 ^ (long)645217984);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)2034091563 ^ (long)2034091679);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1001505677 ^ (long)-1001505678);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1687703958 ^ (long)1687703833);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)645075559 ^ (long)645075623);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-2030430446 ^ (long)-2030430452);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)133196590 ^ (long)133196615);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1389815044 ^ (long)-1389815178);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)364891143 ^ (long)364891262);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1550392133 ^ (long)1550392264);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1297128329 ^ (long)1297128414);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1699925377 ^ (long)1699925361);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1840088250 ^ (long)-1840088109);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)482181384 ^ (long)482181413);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)700032094 ^ (long)700032186);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1983287423 ^ (long)-1983287456);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1455580678 ^ (long)-1455580738);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-372007621 ^ (long)-372007541);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)744240255 ^ (long)744240159);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1011533919 ^ (long)-1011533913);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1050945051 ^ (long)1050945264);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1286970004 ^ (long)-1286969928);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-961848998 ^ (long)-961848974);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)113662418 ^ (long)113662216);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-2081102692 ^ (long)-2081102759);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-868507299 ^ (long)-868507281);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1344356534 ^ (long)-1344356387);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-792876981 ^ (long)-792876933);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)509138372 ^ (long)509138424);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1239604364 ^ (long)-1239604472);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1416149116 ^ (long)1416149153);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1770581654 ^ (long)-1770581703);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)311593104 ^ (long)311593146);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1586198592 ^ (long)-1586198546);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1204137013 ^ (long)1204136962);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-570063824 ^ (long)-570063819);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)2087960547 ^ (long)2087960522);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-501212377 ^ (long)-501212228);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-743263443 ^ (long)-743263250);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-552186055 ^ (long)-552186016);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1355339938 ^ (long)1355339947);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)111397993 ^ (long)111397894);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1507991472 ^ (long)-1507991520);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-856584760 ^ (long)-856584826);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1719567462 ^ (long)-1719567549);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-683803949 ^ (long)-683804023);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)733867064 ^ (long)733867068);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1800210802 ^ (long)-1800210845);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1284108326 ^ (long)-1284108305);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1367103789 ^ (long)-1367103754);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-281656941 ^ (long)-281656996);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)291262444 ^ (long)291262316);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1611280325 ^ (long)1611280315);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1773146296 ^ (long)1773146171);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1338678534 ^ (long)-1338678740);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-991615804 ^ (long)-991615944);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1034540818 ^ (long)1034540909);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-515012337 ^ (long)-515012147);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)574033873 ^ (long)574033869);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-367000150 ^ (long)-367000212);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-164409961 ^ (long)-164410026);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)979627655 ^ (long)979627706);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)763032044 ^ (long)763031973);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1902873629 ^ (long)-1902873783);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1438247583 ^ (long)1438247489);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1894367251 ^ (long)1894367260);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1511765833 ^ (long)1511765992);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)870623387 ^ (long)870623274);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-403228429 ^ (long)-403228646);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1990057037 ^ (long)-1990057188);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)465169053 ^ (long)465168928);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)922059867 ^ (long)922059979);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)856763387 ^ (long)856763288);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)742519741 ^ (long)742519761);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1888806054 ^ (long)-1888806018);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)728536632 ^ (long)728536699);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1967774343 ^ (long)-1967774283);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-468572567 ^ (long)-468572642);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1777653946 ^ (long)1777653916);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-357550107 ^ (long)-357550163);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1574144844 ^ (long)-1574144830);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)556853199 ^ (long)556853099);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-516511120 ^ (long)-516511117);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1180146195 ^ (long)-1180146342);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)788989770 ^ (long)788989708);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-501823715 ^ (long)-501823639);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)170410008 ^ (long)170410066);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)790072673 ^ (long)790072813);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1130342832 ^ (long)-1130342750);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-854134417 ^ (long)-854134469);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1353377365 ^ (long)1353377476);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)124498406 ^ (long)124498317);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1879814583 ^ (long)1879814446);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)968380789 ^ (long)968380915);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1768892971 ^ (long)-1768893006);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1052712670 ^ (long)1052712604);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-680434926 ^ (long)-680434822);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1325915051 ^ (long)-1325915110);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1284788606 ^ (long)1284788537);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-661447312 ^ (long)-661447282);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-688808350 ^ (long)-688808239);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1934908586 ^ (long)1934908419);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1886095988 ^ (long)-1886095950);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)2015515118 ^ (long)2015514940);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)343870988 ^ (long)343871162);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)214002611 ^ (long)214002503);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1883888603 ^ (long)1883888482);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1855948466 ^ (long)-1855948312);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)2005554331 ^ (long)2005554320);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1974853855 ^ (long)-1974853701);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)291529212 ^ (long)291529058);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-175454238 ^ (long)-175454352);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1444364703 ^ (long)-1444364666);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-142848951 ^ (long)-142848777);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-752498136 ^ (long)-752497977);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)166446487 ^ (long)166446493);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-742548634 ^ (long)-742548600);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1613758422 ^ (long)1613758412);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-646617714 ^ (long)-646617841);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)924229073 ^ (long)924228886);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-886563995 ^ (long)-886563965);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1270595561 ^ (long)-1270595515);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-957172195 ^ (long)-957172152);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1849799989 ^ (long)-1849799997);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1893829928 ^ (long)1893830007);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-978478981 ^ (long)-978479014);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1624730149 ^ (long)1624730179);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)895849078 ^ (long)895849083);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1557855987 ^ (long)-1557855758);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-788395512 ^ (long)-788395406);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)631098489 ^ (long)631098511);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1155585985 ^ (long)-1155586017);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-182730583 ^ (long)-182730687);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1963320415 ^ (long)-1963320446);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-2109829066 ^ (long)-2109829066);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1020860346 ^ (long)-1020860237);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1442470051 ^ (long)1442470061);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-741934755 ^ (long)-741934746);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1211478311 ^ (long)-1211478435);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1934272204 ^ (long)1934272145);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-793587092 ^ (long)-793587080);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1162602176 ^ (long)1162601997);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1883071136 ^ (long)1883070997);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1000525524 ^ (long)1000525342);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1415964866 ^ (long)1415964683);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)959451811 ^ (long)959451827);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1935507526 ^ (long)-1935507641);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1953271331 ^ (long)1953271484);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1327072377 ^ (long)1327072392);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1978894417 ^ (long)-1978894406);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-151810738 ^ (long)-151810731);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-615209853 ^ (long)-615209861);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1814134929 ^ (long)-1814134789);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)273813258 ^ (long)273813432);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)684293506 ^ (long)684293388);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1413789492 ^ (long)1413789599);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1198019652 ^ (long)1198019647);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1306413765 ^ (long)-1306413801);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-371517926 ^ (long)-371517884);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1382260841 ^ (long)-1382260819);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1259996773 ^ (long)-1259996856);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1961880114 ^ (long)-1961880302);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-10245467 ^ (long)-10245387);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1854906152 ^ (long)1854906282);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1260681055 ^ (long)1260681201);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)193088460 ^ (long)193088356);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-996158637 ^ (long)-996158654);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-95536775 ^ (long)-95536674);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)458944731 ^ (long)458944516);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-933485437 ^ (long)-933485370);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-2112605581 ^ (long)-2112605667);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1777529931 ^ (long)-1777529949);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-2079799496 ^ (long)-2079799357);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)45698830 ^ (long)45699063);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-8085530 ^ (long)-8085643);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)425778835 ^ (long)425778923);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-2124193311 ^ (long)-2124193338);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-983097065 ^ (long)-983096868);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)417121008 ^ (long)417120801);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1696669929 ^ (long)-1696669877);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1391385109 ^ (long)1391385173);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1197482391 ^ (long)-1197482380);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)53891302 ^ (long)53891076);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-192320538 ^ (long)-192320553);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1211738108 ^ (long)-1211737924);
                    if (!3K.\u200c\u2002\u2008) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1826922884 ^ (long)-1826922841);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)857689578 ^ (long)857689365)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1040696601 ^ (long)-1040661224)) >>> (int)((long)-49705398 ^ (long)-49705406)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1460792927 ^ (long)-1460792927);
            if (!3K.\u200c\u2002\u2008) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-2094882317 ^ (long)-2094882319);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1580999868 ^ (long)1580999871) | var5_6 << (int)((long)-2040208524 ^ (long)-2040208527)) ^ var3_4[var7_8]) & (int)((long)2107388469 ^ (long)2107388618);
                    if (3K.\u200c\u2002\u2008) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-80288164 ^ (long)-80288161) | var6_7 << (int)((long)1924991357 ^ (long)1924991352)) ^ var3_4[var7_8]) & (int)((long)-66179134 ^ (long)-66179267);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3K.b[var2_3] = new String(var3_4).intern();
        }
        return 3K.b[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public 3K() {
        boolean bl = \u200c\u2002\u2008;
        if (bl) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void 4(3b b2, JsonArray jsonArray) {
        block3: {
            block2: {
                boolean bl = \u200c\u2002\u2008;
                if (bl || bl) break block2;
                jsonArray.forEach(jsonElement -> {
                    boolean bl;
                    block30: {
                        Object t;
                        3b b3;
                        JsonPrimitive jsonPrimitive;
                        String[] stringArray;
                        block32: {
                            block31: {
                                bl = \u200c\u2002\u2008;
                                if (bl) return;
                                stringArray = 3e.5();
                                if (bl || bl) return;
                                if (!jsonElement.isJsonObject()) {
                                    if (bl || bl) return;
                                    return;
                                }
                                if (bl) return;
                                if (!(jsonElement = jsonElement.getAsJsonObject()).has(3K.a((int)((long)1453069514 ^ (long)-1453082497), (int)((long)-1514442423 ^ (long)1514438900)))) break block31;
                                if (bl) return;
                                if (jsonElement.get(3K.a((int)((long)1569580826 ^ (long)-1569567825), (int)((long)932973285 ^ (long)-932971688))).isJsonPrimitive()) break block32;
                                if (bl) return;
                            }
                            if (bl) return;
                            return;
                        }
                        if (bl) return;
                        if ((b2 = b2.9(jsonElement.get(3K.a((int)((long)-363771301 ^ (long)363783918), (int)((long)-84799988 ^ (long)84803505))).getAsString())) == null) {
                            if (bl || bl) return;
                            return;
                        }
                        if (bl) return;
                        if (!jsonElement.has(3K.a((int)((long)602549952 ^ (long)-602570122), (int)((long)477692135 ^ (long)477713442)))) break block30;
                        if (bl) return;
                        if (!jsonElement.get(3K.a((int)((long)1323702997 ^ (long)-1323714973), (int)((long)-1507444535 ^ (long)-1507431412))).isJsonPrimitive()) break block30;
                        if (bl) return;
                        try {
                            if (bl) return;
                            jsonPrimitive = jsonElement.get(3K.a((int)((long)-1259588867 ^ (long)1259576907), (int)((long)-102580021 ^ (long)-102591474))).getAsJsonPrimitive();
                            b3 = b2;
                            t = b3.0();
                            if (bl || bl) return;
                            if (b3 instanceof 8T) {
                                if (bl || bl) return;
                                boolean bl2 = jsonPrimitive.getAsString().equals(3K.a((int)((long)384461813 ^ (long)-384448702), (int)((long)1283183926 ^ (long)-1283188897)) /* "rainbow" */);
                                if (bl || bl) return;
                                8D.a.8((8T)b3, bl2);
                                if (bl || bl) return;
                                if (!bl2) {
                                    if (bl || bl) return;
                                    b3.3(Color.fromHex((int)((int)Long.parseLong(jsonPrimitive.getAsString(), (int)((long)27437629 ^ (long)27437613)))));
                                    if (bl) return;
                                }
                                if (bl) return;
                                if (\u200c\u2002\u2008) {
                                    throw null;
                                }
                                break block30;
                            }
                        }
                        catch (Exception exception) {
                            exception.printStackTrace();
                            if (bl) return;
                            break block30;
                        }
                        {
                            if (bl) return;
                            if (t instanceof Float) {
                                if (bl || bl) return;
                                b3.3(Float.valueOf(jsonPrimitive.getAsNumber().floatValue()));
                                if (bl) return;
                                if (stringArray == null) break block30;
                                if (bl) return;
                            }
                            if (bl) return;
                            if (t instanceof Integer) {
                                if (bl || bl) return;
                                b3.3(jsonPrimitive.getAsNumber().intValue());
                                if (bl) return;
                                if (stringArray == null) break block30;
                                if (bl) return;
                            }
                            if (bl) return;
                            if (t instanceof Double) {
                                if (bl || bl) return;
                                b3.3(jsonPrimitive.getAsNumber().doubleValue());
                                if (bl) return;
                                if (stringArray == null) break block30;
                                if (bl) return;
                            }
                            if (bl) return;
                            if (t instanceof Boolean) {
                                if (bl || bl) return;
                                b3.3(jsonPrimitive.getAsBoolean());
                                if (bl) return;
                                if (stringArray == null) break block30;
                                if (bl) return;
                            }
                            if (bl) return;
                            if (t instanceof String) {
                                if (bl || bl) return;
                                b3.3(jsonPrimitive.getAsString());
                                if (bl) return;
                                if (stringArray == null) break block30;
                                if (bl) return;
                            }
                            if (bl) return;
                            if (t instanceof Enum) {
                                if (bl || bl) return;
                                b3.3(Enum.valueOf(((Enum)t).getDeclaringClass(), jsonPrimitive.getAsString()));
                                if (bl) return;
                                if (stringArray == null) break block30;
                                if (bl) return;
                            }
                            if (bl) return;
                            throw new IllegalStateException(3K.a((int)((long)1748559967 ^ (long)-1748548373), (int)((long)1349304241 ^ (long)1349298535)) /* "Unknown class " */ + t + 2w$6X.KAOZ("\u57f0", -1890881164) + t.getClass());
                        }
                    }
                    if (bl) return;
                    if (jsonElement.has(3K.a((int)((long)1338719189 ^ (long)-1338730650), (int)((long)-1523956234 ^ (long)-1523954450)))) {
                        if (bl) return;
                        if (jsonElement.get(3K.a((int)((long)1658377225 ^ (long)-1658357574), (int)((long)-1109041284 ^ (long)-1109043612))).isJsonArray()) {
                            if (bl || bl) return;
                            3K.4(b2, jsonElement.get(3K.a((int)((long)1838176825 ^ (long)-1838156150), (int)((long)1495706946 ^ (long)1495704666))).getAsJsonArray());
                            if (bl) return;
                        }
                    }
                    if (!bl) return;
                });
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final /* synthetic */ Object 9(5w object, Type type, String string) {
        block3: {
            block2: {
                boolean bl = \u200c\u2002\u2008;
                if (bl || bl) break block2;
                object = string;
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return gm.Q.b(vk.a((String)object)).orElse(null);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 3K.\u200c\u2002\u2008;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)600074098 ^ (long)600074107)];
            if (var7) break block23;
            var3_2 = (int)((long)-1469299 ^ (long)-1469299);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ue81a\uc02f\ud3e4\udb98\ue80b\uc0fd\ud3f1\udb92\ue836\uc045\ud36e\udbd9\ue8e3\uc0b1\ud315\udb44\ue839\uc09c\ud379\udb82\ue8c0\uc066\ud3f3\udb71\ue8c0\uc0b8\ud3ab\udbc4\ue87c\uc035\ud3f1\udb0f\ue8d0\uc0f6\ud3b2\udbaf\ue8e7\uc005\ud3f6", -1892954559);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1696748354 ^ (long)-1696748360);
            if (var7) break block23;
            var0_6 = (int)((long)-1229917194 ^ (long)1229917193);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1278273167 ^ (long)-1278273270);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)715779571 ^ (long)-715779572);
                    if (3K.\u200c\u2002\u2008) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3K.\u200c\u2002\u2008) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u736e\u5ba6\u48f2\u4084\u73fc\u5bda\u48ef\u40f6\u737b\u5b8d\u4849\u400e\u730a\u5bd0\u481b\u4036\u73e4\u5b88\u48f7\u401a\u732f\u5b36", -563587671);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)1978136550 ^ (long)1978136552);
                            var0_6 = (int)((long)1205541337 ^ (long)-1205541338);
                            while (true) {
                                v0 = (int)((long)1753796014 ^ (long)1753796093);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1291339494 ^ (long)-1291339494);
                                if (!3K.\u200c\u2002\u2008) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3K.\u200c\u2002\u2008) ** continue;
                                throw null;
                            }
                            3K.a = var5_1;
                            3K.b = new String[(int)((long)-993669748 ^ (long)-993669755)];
                            if (!3K.\u200c\u2002\u2008) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1006622438 ^ (long)-1006622438);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1817959191 ^ (long)-1817959192)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1086744306 ^ (long)1086744309)) {
                                case 0: {
                                    v15 = (int)((long)-2088121965 ^ (long)-2088121925);
                                    if (!3K.\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-92107212 ^ (long)-92107230);
                                    if (!3K.\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1812930755 ^ (long)1812930793);
                                    if (!3K.\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)103370679 ^ (long)103370681);
                                    if (!3K.\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-413516766 ^ (long)-413516773);
                                    if (!3K.\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1082596920 ^ (long)1082596947);
                                    if (!3K.\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-432888544 ^ (long)-432888545);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!3K.\u200c\u2002\u2008);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static JsonObject 8(8z z) {
        JsonPrimitive jsonPrimitive;
        boolean bl = \u200c\u2002\u2008;
        if (bl) return null;
        if (bl) return null;
        if (z instanceof 1J) {
            if (bl) return null;
            if (bl) return null;
            return null;
        }
        if (bl) return null;
        JsonObject jsonObject = new JsonObject();
        if (bl) return null;
        if (bl) return null;
        8z z2 = z;
        Object t = z2.0();
        if (bl) return null;
        if (bl) return null;
        if (z2 instanceof 8T) {
            if (bl) return null;
            if (bl) return null;
            if (8D.a.5((8T)z2)) {
                if (bl) return null;
                if (bl) return null;
                jsonPrimitive = new JsonPrimitive(3K.a((int)((long)334533097 ^ (long)-334545582), (int)((long)907845454 ^ (long)907838954)));
                if (\u200c\u2002\u2008) {
                    throw null;
                }
            } else {
                jsonPrimitive = new JsonPrimitive(Integer.toHexString((int)((long)-574079411 ^ (long)-583548494) & ((Color)t).getHex()));
                if (\u200c\u2002\u2008) {
                    throw null;
                }
            }
        } else if (t instanceof Number) {
            jsonPrimitive = new JsonPrimitive((Number)t);
            if (\u200c\u2002\u2008) {
                throw null;
            }
        } else if (t instanceof Boolean) {
            jsonPrimitive = new JsonPrimitive((Boolean)t);
            if (\u200c\u2002\u2008) {
                throw null;
            }
        } else if (t instanceof String) {
            jsonPrimitive = new JsonPrimitive((String)t);
            if (\u200c\u2002\u2008) {
                throw null;
            }
        } else {
            if (!(t instanceof Enum)) return null;
            jsonPrimitive = new JsonPrimitive(((Enum)t).name());
            if (\u200c\u2002\u2008) {
                throw null;
            }
        }
        z2 = jsonPrimitive;
        if (jsonPrimitive == null) {
            return null;
        }
        jsonObject.addProperty(3K.a((int)((long)-1801630529 ^ (long)1801641999), (int)((long)-1127776526 ^ (long)1127793318)) /* "id" */, z.3());
        jsonObject.add(3K.a((int)((long)285413385 ^ (long)-285426501), (int)((long)291146781 ^ (long)-291163382)) /* "value" */, (JsonElement)z2);
        z = 3K.7(z);
        if (z == null) {
            return jsonObject;
        }
        jsonObject.add(3K.a((int)((long)1676987223 ^ (long)-1676974106), (int)((long)80193054 ^ (long)80199353)) /* "values" */, (JsonElement)z);
        return jsonObject;
    }
}

