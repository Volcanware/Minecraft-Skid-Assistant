/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  blx
 *  gm
 *  vk
 */
package net.impactclient;

import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Arrays;
import net.impactclient.2w$6X;
import net.impactclient.349;
import net.impactclient.3p;
import net.impactclient.5w;
import net.impactclient.5z;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3s9
implements 349<blx> {
    public static final boolean \u2008\u200f;
    private static final String[] b;
    private static final String[] a;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final /* synthetic */ Object 9(5w object, Type type, String string) {
        block3: {
            block2: {
                boolean bl = \u2008\u200f;
                if (bl || bl) break block2;
                object = string;
                if (!bl && !bl) break block3;
            }
            return null;
        }
        return gm.T.b(vk.a((String)object)).orElse(null);
    }

    private static /* synthetic */ RuntimeException 4(int n) {
        boolean bl = \u2008\u200f;
        if (bl || bl) {
            return null;
        }
        return new RuntimeException(String.valueOf(n));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void 0() {
        boolean bl = \u2008\u200f;
        if (bl) return;
        try {
            if (bl) return;
            Field field2 = Arrays.stream(5z.class.getDeclaredFields()).filter(field -> {
                boolean bl = \u2008\u200f;
                if (bl || bl) {
                    return true;
                }
                return Integer.TYPE.equals(field.getType());
            }).findFirst().orElseThrow(() -> 3s9.4((int)((long)1281552606 ^ (long)1281552570)));
            Class[] classArray = new Class[(int)((long)-147477582 ^ (long)-147477584)];
            classArray[(int)((long)-525586725 ^ (long)-525586725)] = Object.class;
            classArray[(int)((long)473409559 ^ (long)473409558)] = Integer.TYPE;
            Object[] objectArray = new Object[(int)((long)-1424335600 ^ (long)-1424335598)];
            objectArray[(int)((long)336702058 ^ (long)336702058)] = 5z.4();
            objectArray[(int)((long)-2112262179 ^ (long)-2112262180)] = (int)((long)-418153508 ^ (long)-418153544);
            3p.0(field2, 3p.6(field2.getClass(), 3s9.a((int)((long)290899937 ^ (long)290890684), (int)((long)1818612060 ^ (long)-1818592166)) /* "setInt" */, classArray), objectArray);
            if (bl || bl) return;
            return;
        }
        catch (RuntimeException runtimeException) {
            if (bl || bl) return;
            throw new RuntimeException(3s9.a((int)((long)112181030 ^ (long)112188282), (int)((long)372081029 ^ (long)372089227)) /* "100" */);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 3s9() {
        boolean bl = \u2008\u200f;
        if (bl) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 3s9.\u2008\u200f;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1332284503 ^ (long)-1332307979)) & (int)((long)-708751911 ^ (long)-708726234);
            if (var9_2) ** GOTO lbl-1000
            if (3s9.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3s9.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-888984238 ^ (long)-888984238)] & (int)((long)-562808513 ^ (long)-562808384)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1571849952 ^ (long)1571849941);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1718843886 ^ (long)1718843897);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)777050339 ^ (long)777050252);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1699180829 ^ (long)-1699180915);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1027985282 ^ (long)1027985228);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)879743080 ^ (long)879743120);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1641915806 ^ (long)1641915690);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-445601342 ^ (long)-445601485);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-245196917 ^ (long)-245196803);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1419477780 ^ (long)1419477869);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1582965427 ^ (long)-1582965402);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1656136924 ^ (long)-1656136852);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)607119278 ^ (long)607119359);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1625998546 ^ (long)-1625998550);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-103055918 ^ (long)-103056027);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1449582894 ^ (long)-1449583026);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-345731001 ^ (long)-345730848);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1971731960 ^ (long)-1971731824);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-580197608 ^ (long)-580197444);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1570855992 ^ (long)1570856110);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)278128555 ^ (long)278128533);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)626159981 ^ (long)626160006);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1167330887 ^ (long)1167330832);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)406599162 ^ (long)406599026);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1350782349 ^ (long)1350782209);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-173280096 ^ (long)-173280063);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1459419207 ^ (long)1459419258);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)927616736 ^ (long)927616651);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1274244472 ^ (long)1274244450);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)2082695883 ^ (long)2082695700);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)770924924 ^ (long)770924824);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1288625848 ^ (long)-1288625675);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)315789360 ^ (long)315789438);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)346698425 ^ (long)346698242);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-612688657 ^ (long)-612688663);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1363437902 ^ (long)1363437935);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1233686619 ^ (long)-1233686676);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-510008267 ^ (long)-510008164);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)515833167 ^ (long)515833297);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)74469879 ^ (long)74469639);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)359565275 ^ (long)359565160);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1977653590 ^ (long)-1977653636);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1900300804 ^ (long)-1900300932);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-414829750 ^ (long)-414829631);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1917341270 ^ (long)-1917341434);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1378851977 ^ (long)1378851910);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1591696808 ^ (long)1591696782);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)640000274 ^ (long)640000341);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)511548754 ^ (long)511548697);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1143651042 ^ (long)-1143651032);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)196621215 ^ (long)196621249);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)748229183 ^ (long)748229220);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1534083975 ^ (long)-1534083870);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)281187484 ^ (long)281187471);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)719584346 ^ (long)719584266);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-58740614 ^ (long)-58740695);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)102454274 ^ (long)102454408);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-968924129 ^ (long)-968924002);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-563325146 ^ (long)-563325173);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-707310283 ^ (long)-707310308);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-164670177 ^ (long)-164669987);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)397139814 ^ (long)397139834);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)2046461587 ^ (long)2046461478);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)2117613722 ^ (long)2117613573);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)185152417 ^ (long)185152457);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1470844803 ^ (long)-1470844704);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1612130690 ^ (long)1612130795);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1524128912 ^ (long)1524128969);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-90311727 ^ (long)-90311773);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)312976882 ^ (long)312976679);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)341339103 ^ (long)341339054);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-360595602 ^ (long)-360595613);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1106967937 ^ (long)1106967982);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-415132331 ^ (long)-415132330);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1277890054 ^ (long)1277890090);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1427979911 ^ (long)1427979790);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)2142575510 ^ (long)2142575527);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1042860839 ^ (long)-1042860951);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-701479673 ^ (long)-701479635);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-875938597 ^ (long)-875938695);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)157284024 ^ (long)157283999);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)508868325 ^ (long)508868124);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1727103781 ^ (long)-1727103825);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1579869085 ^ (long)1579869051);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-638434258 ^ (long)-638434159);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1122632715 ^ (long)-1122632927);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1115988054 ^ (long)1115988074);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)140816351 ^ (long)140816274);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)363072889 ^ (long)363072898);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1367554089 ^ (long)-1367554055);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)86683327 ^ (long)86683271);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1906627312 ^ (long)1906627319);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)582209083 ^ (long)582209278);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)896598313 ^ (long)896598309);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1189101419 ^ (long)-1189101454);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-735256222 ^ (long)-735256119);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-656259803 ^ (long)-656259635);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)425870870 ^ (long)425871023);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1243890402 ^ (long)1243890288);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1724159155 ^ (long)1724159177);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1019618963 ^ (long)1019618878);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1095788524 ^ (long)-1095788508);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)904793660 ^ (long)904793813);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-151535799 ^ (long)-151535869);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)130244343 ^ (long)130244194);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1786259613 ^ (long)1786259584);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-785290478 ^ (long)-785290303);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-124073163 ^ (long)-124073022);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1270845461 ^ (long)-1270845622);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)400933489 ^ (long)400933502);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)976250790 ^ (long)976250640);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1135664445 ^ (long)1135664577);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1602233603 ^ (long)1602233626);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-108394553 ^ (long)-108394752);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1887986773 ^ (long)-1887986879);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)349807621 ^ (long)349807851);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1107655802 ^ (long)1107655792);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-96584842 ^ (long)-96584925);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)906661979 ^ (long)906662019);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)2085955634 ^ (long)2085955834);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1462070138 ^ (long)1462070023);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1352094738 ^ (long)1352094870);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1702152059 ^ (long)1702151958);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1483742520 ^ (long)1483742583);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1410524914 ^ (long)1410524812);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1822292622 ^ (long)1822292646);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)393754606 ^ (long)393754607);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1384840751 ^ (long)-1384840950);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)985273582 ^ (long)985273546);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-922142264 ^ (long)-922142420);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)162675784 ^ (long)162675943);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1420163693 ^ (long)-1420163647);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1829797296 ^ (long)1829797242);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-964299808 ^ (long)-964299988);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)500140989 ^ (long)500141025);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)292568687 ^ (long)292568668);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1354750561 ^ (long)-1354750471);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1406263217 ^ (long)-1406263094);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-199921450 ^ (long)-199921560);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1262066199 ^ (long)1262066188);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)873946996 ^ (long)873947025);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1782932319 ^ (long)1782932251);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)685122393 ^ (long)685122477);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)17751932 ^ (long)17752044);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-727174362 ^ (long)-727174372);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1005745687 ^ (long)1005745884);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-334096089 ^ (long)-334096031);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)985489002 ^ (long)985488956);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)411399478 ^ (long)411399539);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)265613334 ^ (long)265613544);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1475150967 ^ (long)1475151018);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-643941827 ^ (long)-643941635);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1478959590 ^ (long)-1478959459);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)70338316 ^ (long)70338387);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)978925360 ^ (long)978925441);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)229515863 ^ (long)229515796);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1366593159 ^ (long)1366593146);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1824750339 ^ (long)-1824750559);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1762701374 ^ (long)-1762701440);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1126519933 ^ (long)1126519944);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-2115284327 ^ (long)-2115284343);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)232904533 ^ (long)232904642);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)836028394 ^ (long)836028326);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1775247719 ^ (long)-1775247773);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-997093440 ^ (long)-997093429);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1740864903 ^ (long)-1740864949);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-780033011 ^ (long)-780032787);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1175319487 ^ (long)1175319357);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1365826596 ^ (long)-1365826652);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1254804381 ^ (long)-1254804373);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)786403130 ^ (long)786403168);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1537406147 ^ (long)-1537405956);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)566589599 ^ (long)566589599);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)806109478 ^ (long)806109542);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1354225021 ^ (long)1354225063);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1782432633 ^ (long)1782432533);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1044090454 ^ (long)-1044090423);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1734914865 ^ (long)1734914994);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1985765405 ^ (long)1985765432);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1458946234 ^ (long)1458946124);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1769516428 ^ (long)1769516436);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-488447976 ^ (long)-488447953);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1056473289 ^ (long)1056473113);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1045097359 ^ (long)1045097403);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1500102685 ^ (long)1500102788);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1537012554 ^ (long)-1537012702);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1290431594 ^ (long)1290431517);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)2022409912 ^ (long)2022409910);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-2068343143 ^ (long)-2068343261);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-442692139 ^ (long)-442692156);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-869077894 ^ (long)-869077867);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1991977904 ^ (long)-1991977736);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1713784129 ^ (long)-1713784164);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1731786044 ^ (long)1731786192);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-710313124 ^ (long)-710313157);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-2000712351 ^ (long)-2000712254);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-313287972 ^ (long)-313288078);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1442758139 ^ (long)1442757913);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)282563780 ^ (long)282563650);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1387892697 ^ (long)-1387892685);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-2112751821 ^ (long)-2112751646);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1809144793 ^ (long)-1809144705);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1674818560 ^ (long)-1674818443);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-400081815 ^ (long)-400081784);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-317751703 ^ (long)-317751654);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-29882658 ^ (long)-29882778);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)155313279 ^ (long)155313206);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-747438940 ^ (long)-747439062);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1622539139 ^ (long)1622539146);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)672107016 ^ (long)672107170);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-759648844 ^ (long)-759648854);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-485816258 ^ (long)-485816072);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1267475248 ^ (long)-1267475221);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1021830488 ^ (long)1021830461);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-832348705 ^ (long)-832348868);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1679943143 ^ (long)1679943138);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1271984223 ^ (long)1271984269);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)2067043321 ^ (long)2067043302);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1274965884 ^ (long)-1274965772);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)96322093 ^ (long)96322134);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1480052309 ^ (long)1480052464);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)533252189 ^ (long)533252168);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-2063247951 ^ (long)-2063247909);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1869773007 ^ (long)1869773046);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)83640314 ^ (long)83640300);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1115717714 ^ (long)1115717651);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1880335923 ^ (long)1880336100);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-259225558 ^ (long)-259225511);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1551907503 ^ (long)1551907469);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)329177568 ^ (long)329177524);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)400531515 ^ (long)400531613);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)279900315 ^ (long)279900161);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1864698427 ^ (long)-1864698616);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1689172979 ^ (long)-1689172781);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)182156523 ^ (long)182156308);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)467596923 ^ (long)467597019);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)632110137 ^ (long)632110283);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1287257727 ^ (long)-1287257768);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-125379665 ^ (long)-125379806);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)345867627 ^ (long)345867543);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)577959854 ^ (long)577959713);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)171811233 ^ (long)171811230);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)752968116 ^ (long)752968118);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1713147421 ^ (long)-1713147458);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)254788869 ^ (long)254788901);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)935727556 ^ (long)935727478);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1805177532 ^ (long)-1805177385);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-47685007 ^ (long)-47684939);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1484714678 ^ (long)1484714613);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1283091770 ^ (long)1283091802);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1814756746 ^ (long)1814756635);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)840964013 ^ (long)840963857);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1566071567 ^ (long)-1566071666);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-710766295 ^ (long)-710766261);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1322090499 ^ (long)-1322090513);
                    if (!3s9.\u2008\u200f) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)407738858 ^ (long)407738631);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1897066002 ^ (long)-1897066223)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1173209366 ^ (long)-1173176043)) >>> (int)((long)1605074861 ^ (long)1605074853)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-910825144 ^ (long)-910825144);
            if (!3s9.\u2008\u200f) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1099994669 ^ (long)1099994671);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)489983113 ^ (long)489983114) | var5_6 << (int)((long)-1280662258 ^ (long)-1280662261)) ^ var3_4[var7_8]) & (int)((long)944052021 ^ (long)944052170);
                    if (3s9.\u2008\u200f) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1871857080 ^ (long)-1871857077) | var6_7 << (int)((long)-222474628 ^ (long)-222474631)) ^ var3_4[var7_8]) & (int)((long)-1873563283 ^ (long)-1873563246);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3s9.b[var2_3] = new String(var3_4).intern();
        }
        return 3s9.b[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 3s9.\u2008\u200f;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)671790065 ^ (long)671790067)];
            if (var7) break block16;
            var3_2 = (int)((long)1006582997 ^ (long)1006582997);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\uf612\u4a37\u59ce\u513c\uf6ab\u4a5e\u59b7\u5182\uf6b6\u4a2e", 1750877435);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)-425961448 ^ (long)-425961445);
            if (var7) break block16;
            var0_6 = (int)((long)448129258 ^ (long)-448129259);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-1073996307 ^ (long)1073996306);
                if (3s9.\u2008\u200f) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!3s9.\u2008\u200f) continue block8;
                            throw null;
                        }
                        3s9.a = var5_1;
                        3s9.b = new String[(int)((long)13092289 ^ (long)13092291)];
                        if (!3s9.\u2008\u200f) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)-830533933 ^ (long)-830533933);
                v5 = (int)((long)-328079998 ^ (long)-328079987);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)1496601260 ^ (long)1496601261)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1625580658 ^ (long)1625580661)) {
                                case 0: {
                                    v12 = (int)((long)102047416 ^ (long)102047428);
                                    if (!3s9.\u2008\u200f) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)-895449484 ^ (long)-895449482);
                                    if (!3s9.\u2008\u200f) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-1892288750 ^ (long)-1892288684);
                                    if (!3s9.\u2008\u200f) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)1366106145 ^ (long)1366106166);
                                    if (!3s9.\u2008\u200f) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)-832655419 ^ (long)-832655384);
                                    if (!3s9.\u2008\u200f) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)1689482555 ^ (long)1689482568);
                                    if (!3s9.\u2008\u200f) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-1604204834 ^ (long)-1604204915);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!3s9.\u2008\u200f);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!3s9.\u2008\u200f) ** continue;
                throw null;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean 9(Type type) {
        boolean bl = \u2008\u200f;
        if (bl || bl) return true;
        if (type instanceof Class) {
            if (bl) return true;
            if (blx.class.isAssignableFrom((Class)type)) {
                if (bl) return true;
                return (int)((long)1879148315 ^ (long)1879148314) != 0;
            }
        }
        if (!bl) return (int)((long)1204254155 ^ (long)1204254155) != 0;
        return true;
    }
}

