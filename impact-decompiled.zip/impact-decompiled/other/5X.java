/*
 * Decompiled with CFR 0.152.
 */
package net.impactclient;

import java.util.HashMap;
import java.util.Map;
import net.impactclient.2w$6X;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 5X {
    private static final String[] a;
    public static final boolean \u200e\u200a;
    private static final String[] b;
    private static final Map<String, Boolean> 1;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 5X.\u200e\u200a;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)364274112 ^ (long)364269815)) & (int)((long)1935106892 ^ (long)1935121587);
            if (var9_2) ** GOTO lbl-1000
            if (5X.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 5X.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1324843257 ^ (long)-1324843257)] & (int)((long)-1988785955 ^ (long)-1988786142)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-767470627 ^ (long)-767470759);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1888910534 ^ (long)1888910574);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1306355288 ^ (long)-1306355400);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1222428003 ^ (long)1222427966);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-524901727 ^ (long)-524901868);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1334281176 ^ (long)-1334281154);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-762046174 ^ (long)-762046112);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1364231399 ^ (long)1364231273);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1549134879 ^ (long)-1549135043);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1601118638 ^ (long)1601118670);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1651588384 ^ (long)-1651588590);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)918991311 ^ (long)918991157);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1605571463 ^ (long)-1605571494);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)2032424157 ^ (long)2032423998);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-64136167 ^ (long)-64136105);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1582156083 ^ (long)1582156249);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1998996852 ^ (long)1998996846);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)553079553 ^ (long)553079667);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1052743018 ^ (long)1052743112);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-416706807 ^ (long)-416706737);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)546843301 ^ (long)546843247);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-674664866 ^ (long)-674664738);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-2052500256 ^ (long)-2052500433);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1667509212 ^ (long)1667509156);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-963482376 ^ (long)-963482481);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)266640188 ^ (long)266640188);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-128839110 ^ (long)-128839147);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1689403691 ^ (long)1689403698);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-857143180 ^ (long)-857143269);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1592536336 ^ (long)1592536442);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)2134163507 ^ (long)2134163682);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1289403685 ^ (long)-1289403841);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1288867202 ^ (long)1288867216);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1560645397 ^ (long)1560645398);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1137346174 ^ (long)1137346101);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-160323545 ^ (long)-160323387);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-391006071 ^ (long)-391005980);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)580365605 ^ (long)580365624);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1100926462 ^ (long)-1100926230);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1666326302 ^ (long)1666326393);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-460929364 ^ (long)-460929284);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-533479518 ^ (long)-533479537);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-990576998 ^ (long)-990577150);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-299023571 ^ (long)-299023381);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)265283167 ^ (long)265283249);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1259109149 ^ (long)-1259109167);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-862434827 ^ (long)-862435029);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-743064791 ^ (long)-743064618);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1253961878 ^ (long)-1253961755);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-313565355 ^ (long)-313565203);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)444840295 ^ (long)444840387);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1358773861 ^ (long)1358773849);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1799626519 ^ (long)-1799626656);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1859002280 ^ (long)1859002331);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1520277539 ^ (long)1520277509);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)816751701 ^ (long)816751745);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1634071180 ^ (long)1634071232);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1516090486 ^ (long)-1516090563);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)278662134 ^ (long)278662143);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1361392195 ^ (long)-1361392355);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)696361696 ^ (long)696361659);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)2138123486 ^ (long)2138123431);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)2004536620 ^ (long)2004536823);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1785670159 ^ (long)1785670210);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1431181104 ^ (long)-1431181236);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1202057939 ^ (long)-1202057739);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1159613547 ^ (long)-1159613533);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-8652949 ^ (long)-8653034);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1486346937 ^ (long)1486346795);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1314941594 ^ (long)1314941644);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-404108974 ^ (long)-404108927);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)477299568 ^ (long)477299541);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1400513700 ^ (long)-1400513740);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-296055058 ^ (long)-296055068);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1807865187 ^ (long)-1807865206);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-2144271183 ^ (long)-2144271205);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)604124415 ^ (long)604124314);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-987868790 ^ (long)-987868748);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-614085789 ^ (long)-614085814);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)595652672 ^ (long)595652636);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1594798231 ^ (long)-1594798088);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1723523096 ^ (long)1723523102);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)517394165 ^ (long)517394038);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1044144246 ^ (long)-1044144309);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1410440338 ^ (long)1410440198);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)878063715 ^ (long)878063775);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1548722773 ^ (long)1548722940);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1384581606 ^ (long)1384581436);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-313536604 ^ (long)-313536688);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-282877157 ^ (long)-282877153);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-161174069 ^ (long)-161174207);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-616299190 ^ (long)-616299143);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-906988561 ^ (long)-906988687);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)717640454 ^ (long)717640646);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-336249708 ^ (long)-336249676);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)2033409469 ^ (long)2033409378);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)47250967 ^ (long)47251152);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-166036926 ^ (long)-166036755);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-280316205 ^ (long)-280316399);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-193790530 ^ (long)-193790484);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1206970025 ^ (long)-1206969868);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1718878767 ^ (long)1718878821);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)738899072 ^ (long)738899059);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-634983786 ^ (long)-634983818);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1715546927 ^ (long)-1715547039);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1754731605 ^ (long)1754731561);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1319525222 ^ (long)-1319525349);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)359912923 ^ (long)359912722);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1067428019 ^ (long)-1067427941);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1699608692 ^ (long)-1699608777);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1027800591 ^ (long)-1027800825);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1365724252 ^ (long)1365724375);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1054532813 ^ (long)1054532815);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1639853369 ^ (long)1639853500);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)164581775 ^ (long)164581666);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1962354125 ^ (long)1962354024);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-284667398 ^ (long)-284667573);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-794820020 ^ (long)-794819983);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-628629214 ^ (long)-628629047);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)794694864 ^ (long)794694903);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1686510592 ^ (long)-1686510504);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1115048691 ^ (long)1115048615);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-2008283238 ^ (long)-2008283293);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1540384001 ^ (long)1540384014);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1252466465 ^ (long)1252466522);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1076209781 ^ (long)-1076209729);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)438222797 ^ (long)438222666);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-471068318 ^ (long)-471068356);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)52631564 ^ (long)52631561);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-713094647 ^ (long)-713094523);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1725228728 ^ (long)-1725228548);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)169571570 ^ (long)169571390);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)889111962 ^ (long)889112037);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1435345571 ^ (long)-1435345425);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-543615850 ^ (long)-543615980);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-2016548380 ^ (long)-2016548467);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)111966317 ^ (long)111966403);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)91661782 ^ (long)91661645);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)333758673 ^ (long)333758692);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1083607714 ^ (long)-1083607580);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1205719047 ^ (long)1205719100);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1664399429 ^ (long)1664399588);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-2093294505 ^ (long)-2093294557);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-177906677 ^ (long)-177906683);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)934842625 ^ (long)934842708);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1760648514 ^ (long)-1760648497);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1168900886 ^ (long)1168900874);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1313350583 ^ (long)-1313350570);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1583717431 ^ (long)1583717496);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1544091567 ^ (long)1544091431);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-2035550624 ^ (long)-2035550681);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1870562411 ^ (long)-1870562520);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-581201041 ^ (long)-581201004);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)112271415 ^ (long)112271470);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)263859519 ^ (long)263859485);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)989539479 ^ (long)989539496);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1974512069 ^ (long)-1974511956);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-890234322 ^ (long)-890234138);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1847929015 ^ (long)-1847928850);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-899593164 ^ (long)-899593159);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)680878217 ^ (long)680878257);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)0x11CCE11C ^ (long)298639620);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1978779861 ^ (long)-1978779675);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-630160905 ^ (long)-630160932);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-906351949 ^ (long)-906352036);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1480858420 ^ (long)1480858595);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1850437619 ^ (long)-1850437577);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-204180859 ^ (long)-204180850);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1730663676 ^ (long)1730663510);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)922677029 ^ (long)922677041);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-53175549 ^ (long)-53175353);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1808519420 ^ (long)-1808519273);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)230944873 ^ (long)230944793);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)115758681 ^ (long)115758618);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)965044945 ^ (long)965044788);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)824970520 ^ (long)824970686);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-427614861 ^ (long)-427614874);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1227088554 ^ (long)-1227088493);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-228613763 ^ (long)-228613779);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1538548522 ^ (long)-1538548733);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-261874620 ^ (long)-261874469);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)894159006 ^ (long)894159062);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1885150393 ^ (long)-1885150223);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-715954097 ^ (long)-715953959);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-110839658 ^ (long)-110839766);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1351719107 ^ (long)1351719023);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1180358555 ^ (long)1180358499);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1477326100 ^ (long)-1477326283);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)894326127 ^ (long)894326175);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)135629790 ^ (long)135629775);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)504246510 ^ (long)504246408);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)698405069 ^ (long)698405027);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)809028154 ^ (long)809028203);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1303405061 ^ (long)1303405238);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-500500028 ^ (long)-500500020);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)2112627396 ^ (long)2112627347);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-593414491 ^ (long)-593414621);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1186445388 ^ (long)1186445331);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1536196384 ^ (long)-1536196499);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1158822815 ^ (long)1158822889);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1327397965 ^ (long)1327398045);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-463999778 ^ (long)-463999769);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1643103627 ^ (long)1643103590);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-657982409 ^ (long)-657982345);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1165197416 ^ (long)1165197477);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)519171045 ^ (long)519171017);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1781169597 ^ (long)-1781169598);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)801328412 ^ (long)801328549);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)663911564 ^ (long)663911441);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1682718271 ^ (long)1682718419);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1167984993 ^ (long)-1167985048);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)435538077 ^ (long)435538099);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)437838255 ^ (long)437838315);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-2012579871 ^ (long)-2012579846);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)2142397596 ^ (long)2142397474);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1625464319 ^ (long)-1625464065);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1866943778 ^ (long)1866943750);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1316834715 ^ (long)1316834640);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)190108418 ^ (long)190108651);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1598582914 ^ (long)1598582917);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1678205260 ^ (long)1678205354);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)755154516 ^ (long)755154480);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1972732222 ^ (long)-1972732264);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1348076486 ^ (long)1348076534);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-2047134770 ^ (long)-2047134863);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1872471223 ^ (long)-1872471209);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-2125031620 ^ (long)-2125031669);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)126982428 ^ (long)126982505);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1517810663 ^ (long)-1517810510);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1856706828 ^ (long)1856706926);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1012527856 ^ (long)1012527639);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1379766044 ^ (long)-1379766159);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1228979326 ^ (long)1228979221);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1585913665 ^ (long)1585913788);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-228597975 ^ (long)-228597887);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1942808193 ^ (long)-1942808242);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)237207295 ^ (long)237207222);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-111210363 ^ (long)-111210468);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1619092295 ^ (long)1619092244);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1417118574 ^ (long)-1417118562);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-602227412 ^ (long)-602227274);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1636213190 ^ (long)-1636213207);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-462172282 ^ (long)-462172249);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1854661401 ^ (long)-1854661500);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-56679020 ^ (long)-56678955);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)2127464113 ^ (long)2127464144);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1495528404 ^ (long)1495528198);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1610628930 ^ (long)1610629043);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1735882945 ^ (long)-1735882786);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1256016423 ^ (long)-1256016459);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)919959989 ^ (long)919959872);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)546821322 ^ (long)546821129);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1124147551 ^ (long)1124147482);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1360132195 ^ (long)-1360132125);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1629949267 ^ (long)-1629949225);
                    if (!5X.\u200e\u200a) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)920312578 ^ (long)920312799);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1897365159 ^ (long)1897365080)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1372611157 ^ (long)-1372626348)) >>> (int)((long)1592981041 ^ (long)1592981049)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-429039859 ^ (long)-429039859);
            if (!5X.\u200e\u200a) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)673960285 ^ (long)673960287);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1531554930 ^ (long)-1531554931) | var5_6 << (int)((long)815570942 ^ (long)815570939)) ^ var3_4[var7_8]) & (int)((long)1185059737 ^ (long)1185059686);
                    if (5X.\u200e\u200a) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1685190070 ^ (long)1685190069) | var6_7 << (int)((long)-1434621876 ^ (long)-1434621879)) ^ var3_4[var7_8]) & (int)((long)889076497 ^ (long)889076718);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            5X.b[var2_3] = new String(var3_4).intern();
        }
        return 5X.b[var2_3];
    }

    public static boolean 9() {
        boolean bl = \u200e\u200a;
        if (bl || bl) {
            return true;
        }
        return 5X.6(5X.a((int)((long)-1779011156 ^ (long)-1779023718), (int)((long)-1595542824 ^ (long)1595545582)) /* "net.minecraftforge.common.MinecraftForge" */);
    }

    public static boolean 1() {
        boolean bl = \u200e\u200a;
        if (bl || bl) {
            return true;
        }
        return 5X.6(5X.a((int)((long)-1571030557 ^ (long)-1571043116), (int)((long)353286828 ^ (long)353296184)) /* "net.optifine.Config" */);
    }

    private static boolean 6(String string2) {
        boolean bl = \u200e\u200a;
        if (bl || bl) {
            return true;
        }
        return 1.computeIfAbsent(string2, string -> {
            boolean bl = \u200e\u200a;
            if (bl) return null;
            try {
                if (bl) return null;
                Class.forName(string);
                if (bl || bl) return null;
                return Boolean.TRUE;
            }
            catch (ClassNotFoundException classNotFoundException) {
                if (bl || bl) return null;
                return Boolean.FALSE;
            }
        });
    }

    /*
     * Unable to fully structure code
     */
    static {
        block18: {
            block17: {
                var7 = 5X.\u200e\u200a;
                if (!var7) break block17;
                break block18;
            }
            var5_1 = new String[(int)((long)-707556992 ^ (long)-707556990)];
            if (var7) break block18;
            var3_2 = (int)((long)-109562991 ^ (long)-109562991);
            if (var7) break block18;
            var2_3 = 2w$6X.KAOZ("\u267b\u0e63\u1d6f\u1533\u26e7\u0ea3\u1d82\u154f\u2680\u0eca\u1dd0\u154a\u2601\u0e92\u1d34\u15f6\u26a4\u0ec9\u1dd7\u15a4\u264d\u0eab\u1da9\u152a\u263d\u0e99\u1d81\u153e\u26bc\u0e72\u1dfd\u1526\u2610\u0e59\u1d07\u1512\u26c3\u0ec6\u1d53\u1549\u2677\u0e02\u1d5c\u1584\u2630\u0e6b\u1d6f\u15db\u26e6\u0ede\u1dcb\u15d8\u2688\u0e1f\u1da0\u1523\u26cd\u0e96\u1d58\u15b9", 356515917);
            var4_4 = var2_3.length();
            if (var7) break block18;
            var1_5 = (int)((long)-358597323 ^ (long)-358597338);
            if (var7) break block18;
            var0_6 = (int)((long)1305106118 ^ (long)-1305106119);
            if (var7) break block18;
            block8: while (!var7) {
                block15: {
                    v0 = ++var0_6;
                    v1 = (int)((long)-1073536709 ^ (long)1073536708);
                    if (5X.\u200e\u200a) {
                        throw null;
                        while (true) {
                            var5_1[var3_2++] = new String(v2).intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!5X.\u200e\u200a) continue block8;
                                throw null;
                            }
                            5X.a = var5_1;
                            5X.b = new String[(int)((long)1398630060 ^ (long)1398630062)];
                            if (5X.\u200e\u200a) {
                                throw null;
                            }
                            break block15;
                            break;
                        }
                    }
                    v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                    v4 = v3.length;
                    var6_7 = (int)((long)1707035566 ^ (long)1707035566);
                    v5 = (int)((long)-444458980 ^ (long)-444458930);
                    v6 = v3;
                    v7 = v4;
                    if (v4 > (int)((long)-1383553213 ^ (long)-1383553214)) ** GOTO lbl88
                    do {
                        block16: {
                            v8 = v5;
                            v6 = v6;
                            v9 = v6;
                            v10 = v5;
                            v11 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)1287312257 ^ (long)1287312262)) {
                                    case 0: {
                                        v12 = (int)((long)-1669314823 ^ (long)-1669314822);
                                        if (!5X.\u200e\u200a) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v12 = (int)((long)1190809292 ^ (long)1190809291);
                                        if (!5X.\u200e\u200a) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v12 = (int)((long)-1255830167 ^ (long)-1255830166);
                                        if (!5X.\u200e\u200a) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v12 = (int)((long)-2051543751 ^ (long)-2051543703);
                                        if (!5X.\u200e\u200a) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v12 = (int)((long)2037509428 ^ (long)2037509486);
                                        if (!5X.\u200e\u200a) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v12 = (int)((long)1269773771 ^ (long)1269773810);
                                        if (!5X.\u200e\u200a) break;
                                        throw null;
                                    }
                                    default: {
                                        v12 = (int)((long)558472800 ^ (long)558472727);
                                    }
                                }
                                v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                                ++var6_7;
                                v5 = v8;
                                if (v8 != 0) break block16;
                                v8 = v5;
                                v6 = v6;
                                v11 = v5;
                                v9 = v6;
                                v10 = v5;
                            } while (!5X.\u200e\u200a);
                            throw null;
                        }
                        v2 = v6;
                        v7 = v7;
                    } while (v7 > var6_7);
                    if (!5X.\u200e\u200a) ** continue;
                    throw null;
                }
                5X.1 = new HashMap<String, Boolean>();
                break;
            }
        }
    }
}

