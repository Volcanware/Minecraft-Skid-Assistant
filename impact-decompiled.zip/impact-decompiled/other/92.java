/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  k
 *  nr
 */
package net.impactclient;

import java.util.ArrayList;
import java.util.Optional;
import net.impactclient.20;
import net.impactclient.2O;
import net.impactclient.2w$6X;
import net.impactclient.342;
import net.impactclient.3sC;
import net.impactclient.5p;
import net.impactclient.5w;
import net.impactclient.5z;
import net.impactclient.6r;
import net.impactclient.9e;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@342(a={"friend", "f"}, b="Manage friends")
public final class 92
extends 9e {
    private static final String[] d;
    private static final String[] b;
    public static final boolean \u2004;

    /*
     * Enabled aggressive block sorting
     */
    @6r(a={"list"})
    private void 3(5w object) {
        block3: {
            block2: {
                boolean bl = \u2004;
                if (bl || bl) break block2;
                object = 5z.4().1;
                if (bl || bl) break block2;
                k[] kArray = new k[(int)((long)-1800808540 ^ (long)-1800808539)];
                kArray[(int)((long)-147000271 ^ (long)-147000271)] = k.h;
                k[] kArray2 = kArray;
                k[] kArray3 = new k[(int)((long)-49196176 ^ (long)-49196175)];
                kArray3[(int)((long)-1536985930 ^ (long)-1536985930)] = k.j;
                k[] kArray4 = kArray3;
                5p.9((nr)new 3sC().2((String)92.b((int)((int)((long)-1183883964 ^ (long)1183900471)), (int)((int)((long)-1843871351 ^ (long)-1843878360))), null, (k[])kArray2).2((String)new StringBuilder((String)2w$6X.KAOZ((Object)"\ue604", (int)-1263353495)).append((int)((ArrayList)object).size()).append((String)2w$6X.KAOZ((Object)"\u22e1", (int)932906381)).toString(), null, (k[])kArray4).7);
                if (bl || bl) break block2;
                3sC sC = new 3sC();
                if (bl || bl) break block2;
                Object object2 = object;
                ((ArrayList)object2).forEach(arg_0 -> 92.7((20)object2, sC, arg_0));
                if (bl || bl) break block2;
                5p.9((nr)sC.7);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 92.\u2004;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)246846934 ^ (long)246846932)];
            if (var7) break block16;
            var3_2 = (int)((long)1951572780 ^ (long)1951572780);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\uce38\ue708\uf4c7\ufc4e\uce92\ue791\uf4ca\ufcff\uce80\ue7c9\uf4a0\ufcae\ucece\ue716\uf499\ufca3\uce88\ue73a\uf44b", 128313698);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)1266389968 ^ (long)1266389970);
            if (var7) break block16;
            var0_6 = (int)((long)1279482514 ^ (long)-1279482515);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-76854579 ^ (long)76854578);
                if (92.\u2004) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!92.\u2004) continue block8;
                            throw null;
                        }
                        92.b = var5_1;
                        92.d = new String[(int)((long)-866325492 ^ (long)-866325490)];
                        if (!92.\u2004) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)-1470334682 ^ (long)-1470334682);
                v5 = (int)((long)-769083279 ^ (long)-769083301);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)514214057 ^ (long)514214056)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)400087833 ^ (long)400087838)) {
                                case 0: {
                                    v12 = (int)((long)1128215106 ^ (long)1128215075);
                                    if (!92.\u2004) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)664641826 ^ (long)664641892);
                                    if (!92.\u2004) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-514299260 ^ (long)-514299242);
                                    if (!92.\u2004) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)701814212 ^ (long)701814264);
                                    if (!92.\u2004) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)-1183704955 ^ (long)-1183704958);
                                    if (!92.\u2004) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)1773478317 ^ (long)1773478356);
                                    if (!92.\u2004) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-226326972 ^ (long)-226327040);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!92.\u2004);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!92.\u2004) ** continue;
                throw null;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @6r(a={"del", "delete", "rem", "remove", "-"}, b={"name"})
    private void 4(5w w, String string) {
        block3: {
            block2: {
                boolean bl = \u2004;
                if (bl || bl) break block2;
                5z.4().1.1(string);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @6r(a={"add", "+"}, b={"name", "nickname"})
    private void 8(5w w, String string, Optional<String> optional) {
        block3: {
            block2: {
                boolean bl = \u2004;
                if (bl || bl) break block2;
                5z.4().1.8(new 2O(string, optional.orElse(string)));
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 92() {
        boolean bl = \u2004;
        if (bl) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 92.\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-979789561 ^ (long)979773301)) & (int)((long)443926643 ^ (long)443889548);
            if (var9_2) ** GOTO lbl-1000
            if (92.d[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 92.b[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)24783830 ^ (long)24783830)] & (int)((long)275526208 ^ (long)275526335)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1134057699 ^ (long)-1134057552);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1217104302 ^ (long)-1217104228);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1849108275 ^ (long)1849108419);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-186986528 ^ (long)-186986669);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)923350609 ^ (long)923350552);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1059684177 ^ (long)-1059684252);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1220439187 ^ (long)1220439134);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-624372722 ^ (long)-624372658);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-2104249618 ^ (long)-2104249849);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1456352125 ^ (long)-1456352215);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)908242427 ^ (long)908242176);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1752401130 ^ (long)1752400970);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1354556617 ^ (long)1354556548);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1666160267 ^ (long)-1666160178);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-2088725397 ^ (long)-2088725478);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)532447756 ^ (long)532447999);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)189598195 ^ (long)189598193);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1678905512 ^ (long)1678905490);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1814280343 ^ (long)1814280430);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)803071116 ^ (long)803071099);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-2140604618 ^ (long)-2140604473);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1559997977 ^ (long)1559998108);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-293039662 ^ (long)-293039647);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1066063701 ^ (long)1066063669);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-917914340 ^ (long)-917914308);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1656934145 ^ (long)-1656934355);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)2114768049 ^ (long)2114767873);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-759595764 ^ (long)-759595645);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)389862964 ^ (long)389862929);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1732510692 ^ (long)1732510476);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1217943110 ^ (long)1217943075);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1614660655 ^ (long)-1614660776);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1477104780 ^ (long)1477104834);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)2062758576 ^ (long)2062758458);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)195514829 ^ (long)195514835);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-542428470 ^ (long)-542428553);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)23822862 ^ (long)23823062);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1348234452 ^ (long)1348234458);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)669227703 ^ (long)669227572);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-269965146 ^ (long)-269965098);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1522080439 ^ (long)1522080339);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)943428608 ^ (long)943428660);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)680929907 ^ (long)680929902);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1041211563 ^ (long)-1041211583);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)867335083 ^ (long)867334950);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1769070159 ^ (long)-1769070245);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)2130739211 ^ (long)2130739257);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)451133237 ^ (long)451133364);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1908444216 ^ (long)-1908444194);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1204608022 ^ (long)-1204608207);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)140853847 ^ (long)140853877);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)923095497 ^ (long)923095321);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1006124451 ^ (long)-1006124303);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-739515988 ^ (long)-739515911);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1250741656 ^ (long)-1250741556);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1123558732 ^ (long)1123558727);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)349498832 ^ (long)349498739);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)266233898 ^ (long)266234032);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1932036790 ^ (long)-1932036807);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)656389034 ^ (long)656388946);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1667126502 ^ (long)1667126360);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)38529535 ^ (long)38529432);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1238526481 ^ (long)-1238526522);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)2099956457 ^ (long)2099956382);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1063851620 ^ (long)-1063851528);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1928717503 ^ (long)-1928717371);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1211789927 ^ (long)-1211789985);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-74924665 ^ (long)-74924555);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)146377831 ^ (long)146377825);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1886938611 ^ (long)-1886938454);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-607911783 ^ (long)-607911764);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1199780164 ^ (long)-1199780118);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-940393606 ^ (long)-940393714);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)33696527 ^ (long)33696551);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1205633460 ^ (long)-1205633468);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-562110224 ^ (long)-562110249);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-501335146 ^ (long)-501335083);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1643845641 ^ (long)-1643845747);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1623338566 ^ (long)-1623338590);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-862975307 ^ (long)-862975452);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1092861835 ^ (long)1092861768);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-368779490 ^ (long)-368779332);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1603107878 ^ (long)-1603107929);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-375152247 ^ (long)-375152312);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-2047503620 ^ (long)-2047503813);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1435870345 ^ (long)-1435870348);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-158141093 ^ (long)-158140930);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1484035231 ^ (long)-1484035286);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-226143933 ^ (long)-226143826);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1881287124 ^ (long)-1881287166);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-498090702 ^ (long)-498090681);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-312825287 ^ (long)-312825298);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1335780134 ^ (long)-1335780305);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-191817947 ^ (long)-191817767);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-6067839 ^ (long)-6067777);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1751848074 ^ (long)-1751848074);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-394684737 ^ (long)-394684701);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-2063215518 ^ (long)-2063215405);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-486311066 ^ (long)-486311063);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)29797471 ^ (long)29797430);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1509201301 ^ (long)-1509201338);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1189692490 ^ (long)1189692544);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)974174778 ^ (long)974174892);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1450414733 ^ (long)1450414628);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1538184897 ^ (long)-1538184768);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1358431376 ^ (long)-1358431389);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)2110262829 ^ (long)2110262961);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1942154258 ^ (long)1942154242);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-114132942 ^ (long)-114132877);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1111676449 ^ (long)-1111676661);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1846994927 ^ (long)-1846994941);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1389060050 ^ (long)-1389059975);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-718491589 ^ (long)-718491543);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1250619153 ^ (long)1250619278);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-918894315 ^ (long)-918894327);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)163007644 ^ (long)163007738);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1307610105 ^ (long)-1307609859);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1103501120 ^ (long)-1103501273);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)632011129 ^ (long)632011053);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1254574117 ^ (long)1254574262);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)803485994 ^ (long)803486143);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)470444094 ^ (long)470444172);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-40644020 ^ (long)-40644068);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)2043401259 ^ (long)2043401336);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)511886466 ^ (long)511886469);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-165691923 ^ (long)-165692027);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-519941138 ^ (long)-519941200);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)300914915 ^ (long)300914873);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)219995471 ^ (long)219995428);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-660880922 ^ (long)-660881046);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1877377305 ^ (long)-1877377502);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-2103825818 ^ (long)-2103825696);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-946416383 ^ (long)-946416354);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)2124901921 ^ (long)2124902079);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1173765482 ^ (long)1173765422);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1605702089 ^ (long)-1605701984);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-104384466 ^ (long)-104384430);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)986539478 ^ (long)986539450);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1127563288 ^ (long)1127563463);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1361799499 ^ (long)1361799556);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)691386470 ^ (long)691386397);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1371674231 ^ (long)1371674200);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-951615884 ^ (long)-951615951);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-194063335 ^ (long)-194063110);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1018169346 ^ (long)1018169533);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1617835438 ^ (long)1617835472);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)383820508 ^ (long)383820438);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1658592058 ^ (long)1658592248);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-81012852 ^ (long)-81012907);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-452313639 ^ (long)-452313711);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1640746242 ^ (long)1640746378);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1613862682 ^ (long)1613862689);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)842178919 ^ (long)842179001);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)14510617 ^ (long)0xDD6AAD);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)684427499 ^ (long)684427466);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)333641567 ^ (long)333641608);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1794837153 ^ (long)1794837002);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-943177626 ^ (long)-943177659);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)301083850 ^ (long)301083857);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-656927567 ^ (long)-656927707);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1245077928 ^ (long)1245077833);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1148683012 ^ (long)-1148683049);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1744029314 ^ (long)1744029292);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-111365323 ^ (long)-111365270);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1401325917 ^ (long)1401325925);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-5588099 ^ (long)-5588148);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1714853736 ^ (long)1714853855);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1104588006 ^ (long)-1104587833);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1399318177 ^ (long)-1399318258);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-889959636 ^ (long)-889959532);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)732417348 ^ (long)732417373);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-508031014 ^ (long)-508031223);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1154749936 ^ (long)-1154749770);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1490677070 ^ (long)-1490677148);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-625957626 ^ (long)-625957525);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-954191795 ^ (long)-954191826);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1224496470 ^ (long)1224496563);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)89095864 ^ (long)89095793);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-209727954 ^ (long)-209727882);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)448701530 ^ (long)448701484);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1468773354 ^ (long)-1468773334);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1517655661 ^ (long)1517655682);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1107498259 ^ (long)-1107498481);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1809179775 ^ (long)1809179885);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1083395749 ^ (long)1083395721);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)2022871243 ^ (long)2022871122);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)509468689 ^ (long)509468700);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)2089302649 ^ (long)2089302596);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1290552612 ^ (long)1290552616);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-483350541 ^ (long)-483350603);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1281074592 ^ (long)-1281074450);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1292682010 ^ (long)-1292682202);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)12370314 ^ (long)12370271);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1971392809 ^ (long)1971392953);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1892230182 ^ (long)-1892230197);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1820486097 ^ (long)1820486113);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-910116398 ^ (long)-910116523);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)388876562 ^ (long)388876750);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)603461106 ^ (long)603460970);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-569718083 ^ (long)-569718208);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1741577240 ^ (long)-1741577458);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1088323907 ^ (long)-1088323911);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1752242264 ^ (long)-1752242233);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1421064439 ^ (long)-1421064193);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-752766922 ^ (long)-752766961);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-983185483 ^ (long)-983185422);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)834044228 ^ (long)834044225);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1065027301 ^ (long)-1065027117);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1115270621 ^ (long)-1115270515);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1373660774 ^ (long)-1373660842);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-159967875 ^ (long)-159967897);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1383413839 ^ (long)-1383413762);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-779488679 ^ (long)-779488551);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)2037391632 ^ (long)2037391730);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1243935704 ^ (long)-1243935609);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-928623711 ^ (long)-928623645);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)2015601196 ^ (long)2015601284);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1639272975 ^ (long)1639273206);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-991040822 ^ (long)-991040786);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1336719147 ^ (long)-1336719264);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1154803080 ^ (long)1154802954);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1770535971 ^ (long)-1770536128);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1720137429 ^ (long)1720137443);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-2071518974 ^ (long)-2071518750);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-47957265 ^ (long)-47957362);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1230551477 ^ (long)1230551443);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1925938815 ^ (long)-1925938918);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1114180202 ^ (long)1114180316);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1306872848 ^ (long)1306872987);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)519317047 ^ (long)519316992);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-452552167 ^ (long)-452551957);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1286044155 ^ (long)-1286044148);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1480911684 ^ (long)1480911647);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-693895128 ^ (long)-693894932);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)17436070 ^ (long)17435935);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1625774678 ^ (long)-1625774677);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1144896735 ^ (long)1144896679);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1183107510 ^ (long)1183107418);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1890003893 ^ (long)-1890003874);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-2061002550 ^ (long)-2061002700);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)314485638 ^ (long)314485562);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-164655252 ^ (long)-164655277);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1560077675 ^ (long)1560077745);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-958412511 ^ (long)-958412416);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1759255513 ^ (long)-1759255464);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-275579784 ^ (long)-275579757);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)182592935 ^ (long)182593022);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-604734019 ^ (long)-604733993);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)853355075 ^ (long)853355053);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-485401150 ^ (long)-485401112);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-844867871 ^ (long)-844868048);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-506612457 ^ (long)-506612253);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-991444478 ^ (long)-991444296);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1040133035 ^ (long)-1040133025);
                    if (!92.\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-906720278 ^ (long)-906720346);
                    if (!92.\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1397363178 ^ (long)-1397363125);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1314280295 ^ (long)1314280344)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1011939455 ^ (long)-1011877762)) >>> (int)((long)186195855 ^ (long)186195847)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1399182218 ^ (long)1399182218);
            if (!92.\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1088203123 ^ (long)-1088203121);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-851354289 ^ (long)-851354292) | var5_6 << (int)((long)1675950759 ^ (long)1675950754)) ^ var3_4[var7_8]) & (int)((long)-866801765 ^ (long)-866801820);
                    if (92.\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1376531883 ^ (long)-1376531882) | var6_7 << (int)((long)-1421336348 ^ (long)-1421336351)) ^ var3_4[var7_8]) & (int)((long)2093068347 ^ (long)2093068484);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            92.d[var2_3] = new String(var3_4).intern();
        }
        return 92.d[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ void 7(20 var0, 3sC sC, 2O kArray) {
        String string;
        int n;
        block11: {
            block9: {
                block10: {
                    block8: {
                        boolean bl = \u2004;
                        if (bl || bl) break block8;
                        if (var0.indexOf(kArray) != var0.size() - (int)((long)-35124341 ^ (long)-35124342)) break block9;
                        if (!bl) break block10;
                    }
                    return;
                }
                n = (int)((long)1779080521 ^ (long)1779080520);
                if (\u2004) {
                    throw null;
                }
                break block11;
            }
            n = (int)((long)1524427895 ^ (long)1524427895);
        }
        int n2 = n;
        StringBuilder stringBuilder = new StringBuilder().append(kArray.8);
        if (n2 != 0) {
            string = 2w$6X.KAOZ("\u1622", 607465801);
            if (\u2004) {
                throw null;
            }
        } else {
            string = 92.b((int)((long)-1745236423 ^ (long)1745252427), (int)((long)-438788000 ^ (long)-438765985)) /* ", " */;
        }
        k[] kArray2 = new k[(int)((long)-541194482 ^ (long)-541194481)];
        kArray2[(int)((long)-1156818651 ^ (long)-1156818651)] = k.h;
        kArray = kArray2;
        sC.2(stringBuilder.append(string).toString(), null, kArray);
    }
}

