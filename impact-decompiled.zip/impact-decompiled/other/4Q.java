/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  org.apache.logging.log4j.Level
 */
package net.impactclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import net.impactclient.2w$6X;
import net.impactclient.348;
import net.impactclient.3sU;
import net.impactclient.5z;
import net.impactclient.6L;
import net.impactclient.6Y;
import net.impactclient.8y;
import net.impactclient.93;
import org.apache.logging.log4j.Level;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
final class 4Q
implements 3sU {
    private final Path 8;
    public static final boolean \u200e\u200b\u2000\u2007\u200e;
    private static final String[] b;
    private /* synthetic */ 8y 9;
    private static final String[] a;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 6() {
        block3: {
            block2: {
                boolean bl = \u200e\u200b\u2000\u2007\u200e;
                if (bl || bl) break block2;
                JsonObject jsonObject = new JsonObject();
                if (bl || bl) break block2;
                348.1(8y.4(this.9)).forEach(y -> {
                    block3: {
                        block2: {
                            boolean bl = \u200e\u200b\u2000\u2007\u200e;
                            if (bl || bl) break block2;
                            JsonObject jsonObject2 = new JsonObject();
                            jsonObject2.addProperty(4Q.a((int)((long)260967421 ^ (long)260971458), (int)((long)99044896 ^ (long)99034087)), (Number)y.5);
                            if (bl || bl) break block2;
                            JsonArray jsonArray = new JsonArray();
                            if (bl || bl) break block2;
                            Arrays.stream(y.6).forEach(arg_0 -> ((JsonArray)jsonArray).add(arg_0));
                            if (bl || bl) break block2;
                            jsonObject2.add(4Q.a((int)((long)2131061303 ^ (long)2131065354), (int)((long)1403820469 ^ (long)1403844534)), (JsonElement)jsonArray);
                            if (bl || bl) break block2;
                            jsonObject.add(y.7, (JsonElement)jsonObject2);
                            if (!bl && !bl) break block3;
                        }
                        return;
                    }
                });
                if (bl || bl) break block2;
                93.5((JsonElement)jsonObject, this.8);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /* synthetic */ 4Q(8y y, byte by) {
        boolean bl = \u200e\u200b\u2000\u2007\u200e;
        this(y);
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 4Q.\u200e\u200b\u2000\u2007\u200e;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1296206347 ^ (long)-1296210486)) & (int)((long)-1073536721 ^ (long)-1073488176);
            if (var9_2) ** GOTO lbl-1000
            if (4Q.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 4Q.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)335844017 ^ (long)335844017)] & (int)((long)-508669180 ^ (long)-508668933)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1246249502 ^ (long)-1246249559);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-211348812 ^ (long)-211348861);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1790931084 ^ (long)1790930953);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)234192039 ^ (long)234191921);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-689181075 ^ (long)-689181113);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1750050077 ^ (long)-1750050095);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)702517629 ^ (long)702517696);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1558502943 ^ (long)1558503112);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)356996371 ^ (long)356996433);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-294449211 ^ (long)-294449352);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-22002809 ^ (long)-22002786);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)646136922 ^ (long)646136860);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1821864443 ^ (long)1821864299);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-2115165963 ^ (long)-2115166186);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)2029937131 ^ (long)2029937108);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-2883798 ^ (long)-2883624);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-619748251 ^ (long)-619748264);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1079100706 ^ (long)-1079100760);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)763338943 ^ (long)763338935);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1050065399 ^ (long)-1050065234);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1795669271 ^ (long)-1795669502);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)752037220 ^ (long)752037297);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1093831190 ^ (long)-1093831303);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1068742516 ^ (long)-1068742448);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1756916284 ^ (long)-1756916294);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1024814499 ^ (long)1024814491);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1796173701 ^ (long)-1796173693);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-475225948 ^ (long)-475225960);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1862476321 ^ (long)1862476385);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1872861416 ^ (long)-1872861373);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1769818467 ^ (long)1769818469);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)2092474153 ^ (long)2092474258);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1233434923 ^ (long)1233435128);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)481745791 ^ (long)481745916);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1956129957 ^ (long)1956129902);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1824657281 ^ (long)-1824657265);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1397377076 ^ (long)1397377058);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-2011638957 ^ (long)-2011638951);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1198744798 ^ (long)1198744708);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)50584190 ^ (long)50584149);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1539399754 ^ (long)1539399818);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1431678758 ^ (long)-1431678951);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-983288513 ^ (long)-983288490);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)278676346 ^ (long)278676317);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-881702945 ^ (long)-881703141);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1543048061 ^ (long)1543048150);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)469972691 ^ (long)469972510);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-903560006 ^ (long)-903560049);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1480267923 ^ (long)1480268007);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)399477480 ^ (long)399477467);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1940043920 ^ (long)-1940043858);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)727707503 ^ (long)727707566);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-441102448 ^ (long)-441102554);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1915340996 ^ (long)1915340837);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)736967009 ^ (long)736967029);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1167438288 ^ (long)1167438279);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-372163623 ^ (long)-372163592);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1947107901 ^ (long)1947107959);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)616700562 ^ (long)616700519);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)475349543 ^ (long)475349682);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-127608133 ^ (long)-127608281);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1172268021 ^ (long)-1172267958);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1100954580 ^ (long)1100954541);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)2119730858 ^ (long)2119730722);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1804378469 ^ (long)-1804378423);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)884075704 ^ (long)884075606);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-2101370221 ^ (long)-2101370177);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-2005413962 ^ (long)-2005413977);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1594288328 ^ (long)1594288229);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1753857268 ^ (long)1753857075);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)618902830 ^ (long)618902790);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)138555687 ^ (long)138555837);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-682101783 ^ (long)-682101787);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1615899959 ^ (long)-1615900008);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1715196493 ^ (long)1715196565);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1467943794 ^ (long)1467943755);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1863578675 ^ (long)1863578809);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-337553219 ^ (long)-337553383);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1641679289 ^ (long)-1641679346);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-88869747 ^ (long)-88869851);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1702144634 ^ (long)-1702144679);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1332504235 ^ (long)1332504164);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)118964104 ^ (long)118964079);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)919578550 ^ (long)919578424);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-411883451 ^ (long)-411883372);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)524838202 ^ (long)524838317);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)20814417 ^ (long)20814569);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1338276211 ^ (long)-1338276307);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)13678156 ^ (long)13678292);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)241907450 ^ (long)241907235);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-581998323 ^ (long)-581998224);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)716423570 ^ (long)716423612);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-67598722 ^ (long)-67598807);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1534440168 ^ (long)-1534440114);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1921976012 ^ (long)1921976033);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)565616545 ^ (long)565616606);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)91361524 ^ (long)91361361);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-2043659039 ^ (long)-2043659122);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-938798398 ^ (long)-938798393);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)513321854 ^ (long)513321826);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)105872895 ^ (long)105872752);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1732735280 ^ (long)1732735369);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)958111826 ^ (long)958111750);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)825117431 ^ (long)825117346);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1812666941 ^ (long)1812667068);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-535344154 ^ (long)-535344188);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1854143394 ^ (long)1854143432);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-447558317 ^ (long)-447558231);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-169344592 ^ (long)-169344619);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)2024601701 ^ (long)2024601784);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)309251583 ^ (long)309251420);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1755297358 ^ (long)1755297442);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)184663771 ^ (long)184663724);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1281656583 ^ (long)-1281656694);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)108613513 ^ (long)108613432);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)232437356 ^ (long)232437405);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)459708611 ^ (long)459708598);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1348008750 ^ (long)1348008852);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1564900672 ^ (long)-1564900618);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1321926639 ^ (long)-1321926424);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-734660511 ^ (long)-734660545);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)773550034 ^ (long)773550028);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1980816031 ^ (long)1980816000);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-194754405 ^ (long)-194754376);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-267944944 ^ (long)-267944750);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-2004775477 ^ (long)-2004775628);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1901145777 ^ (long)1901145771);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1479705361 ^ (long)-1479705591);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1474643338 ^ (long)-1474643347);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1633612617 ^ (long)1633612763);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)37749090 ^ (long)37749127);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1057120782 ^ (long)-1057120906);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)2048280130 ^ (long)2048280318);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)574263993 ^ (long)574263891);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1910927349 ^ (long)1910927250);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1334873729 ^ (long)-1334873648);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-2116884637 ^ (long)-2116884605);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1889852420 ^ (long)-1889852424);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1043592108 ^ (long)1043592113);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1078355022 ^ (long)-1078354980);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-177606978 ^ (long)-177606949);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-341476650 ^ (long)-341476710);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)624575321 ^ (long)624575472);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)528029106 ^ (long)528028973);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1819222476 ^ (long)1819222477);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)68193033 ^ (long)68193098);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-2138289627 ^ (long)-2138289447);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1806387366 ^ (long)1806387266);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-26005119 ^ (long)-26005242);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)520254546 ^ (long)520254527);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1655867928 ^ (long)-1655868056);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)512131362 ^ (long)512131341);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-42719780 ^ (long)-42719780);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)2041026920 ^ (long)2041026905);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-342920747 ^ (long)-342920722);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)583847473 ^ (long)583847589);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1824127437 ^ (long)-1824127432);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1764061639 ^ (long)1764061457);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)277178529 ^ (long)277178428);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1785517806 ^ (long)1785517636);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1817485101 ^ (long)-1817485100);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)700274990 ^ (long)700275174);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1412634051 ^ (long)-1412633949);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)791397524 ^ (long)791397616);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-335883118 ^ (long)-335883180);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1507512789 ^ (long)-1507512673);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1278340465 ^ (long)1278340490);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1623034604 ^ (long)1623034399);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)543053019 ^ (long)543053029);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1058690513 ^ (long)-1058690482);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1863022261 ^ (long)-1863022126);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)760947114 ^ (long)760947173);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1458107383 ^ (long)1458107186);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)573551513 ^ (long)573551605);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-715836783 ^ (long)-715836782);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1531236107 ^ (long)1531236261);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)548928265 ^ (long)548928377);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)2041499143 ^ (long)2041499145);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-440083286 ^ (long)-440083385);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-2089472792 ^ (long)-2089472990);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1799628869 ^ (long)1799628978);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)63327680 ^ (long)63327586);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1303662626 ^ (long)1303662686);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)2074755652 ^ (long)2074755725);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-200795958 ^ (long)-200795976);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-31203750 ^ (long)-31203624);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1900571343 ^ (long)-1900571248);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)201427632 ^ (long)201427551);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-842700102 ^ (long)-842700284);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-405089739 ^ (long)-405089628);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)2118250050 ^ (long)2118250164);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-683928367 ^ (long)-683928502);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1644930622 ^ (long)-1644930748);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1867413659 ^ (long)-1867413675);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1892103031 ^ (long)1892102958);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1360145858 ^ (long)1360145850);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1125426626 ^ (long)-1125426591);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1488322753 ^ (long)-1488322577);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-2118012123 ^ (long)-2118011919);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1450986666 ^ (long)-1450986722);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-869848685 ^ (long)-869848581);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-379569737 ^ (long)-379569858);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-870500947 ^ (long)-870501082);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-2133186689 ^ (long)-2133186788);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-327348332 ^ (long)-327348238);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-730256051 ^ (long)-730255873);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-693426148 ^ (long)-693426136);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1784082901 ^ (long)1784082824);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)812680525 ^ (long)812680553);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)891341169 ^ (long)891341245);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)972032662 ^ (long)972032616);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)588885307 ^ (long)588885430);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)378114523 ^ (long)378114404);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1141793357 ^ (long)1141793344);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-365461010 ^ (long)-365461115);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1053132194 ^ (long)-1053132261);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)2076287497 ^ (long)2076287723);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1714067746 ^ (long)-1714067714);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)449438730 ^ (long)449438906);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-695206015 ^ (long)-695205940);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1569161070 ^ (long)1569161095);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-898333400 ^ (long)-898333276);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1801771602 ^ (long)-1801771542);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)534607905 ^ (long)534608123);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-30289095 ^ (long)-30289119);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-836755923 ^ (long)-836755891);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1416314526 ^ (long)1416314513);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-304806465 ^ (long)-304806435);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1066757776 ^ (long)1066757814);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)156909237 ^ (long)156909262);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)330200343 ^ (long)330200391);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1581024691 ^ (long)-1581024713);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-874349683 ^ (long)-874349611);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1501138772 ^ (long)-1501138718);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1806461566 ^ (long)1806461455);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)467861585 ^ (long)467861526);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1266900677 ^ (long)-1266900686);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)475816842 ^ (long)475816863);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1296222589 ^ (long)1296222630);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1039762528 ^ (long)1039762645);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)995327617 ^ (long)995327593);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1033903566 ^ (long)1033903388);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1573978623 ^ (long)1573978540);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1285495067 ^ (long)-1285495223);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-156186584 ^ (long)-156186380);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1581191724 ^ (long)-1581191910);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1003725194 ^ (long)1003725182);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)92621006 ^ (long)92621021);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)203035270 ^ (long)203035168);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-2087513721 ^ (long)-2087513707);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-389551339 ^ (long)-389551337);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1467012057 ^ (long)1467012067);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1969798715 ^ (long)-1969798798);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)263549244 ^ (long)263549327);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)53475629 ^ (long)53475588);
                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)381754160 ^ (long)381754144);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1616448636 ^ (long)-1616448645)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1726667916 ^ (long)-1726620533)) >>> (int)((long)-1144392831 ^ (long)-1144392823)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1473044211 ^ (long)1473044211);
            if (!4Q.\u200e\u200b\u2000\u2007\u200e) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1164542196 ^ (long)1164542198);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)498868760 ^ (long)498868763) | var5_6 << (int)((long)714740658 ^ (long)714740663)) ^ var3_4[var7_8]) & (int)((long)-1838305080 ^ (long)-1838305225);
                    if (4Q.\u200e\u200b\u2000\u2007\u200e) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)194076872 ^ (long)194076875) | var6_7 << (int)((long)-845255134 ^ (long)-845255129)) ^ var3_4[var7_8]) & (int)((long)-1909366203 ^ (long)-1909366086);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            4Q.b[var2_3] = new String(var3_4).intern();
        }
        return 4Q.b[var2_3];
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void 7() {
        JsonElement jsonElement;
        boolean bl = \u200e\u200b\u2000\u2007\u200e;
        if (bl || bl) return;
        if (!Files.exists(this.8, new LinkOption[(int)((long)192623077 ^ (long)192623077)])) {
            if (bl || bl) return;
            6L.9(this.8);
            if (bl || bl) return;
            return;
        }
        try {
            if (bl) return;
            jsonElement = 93.0(Files.newBufferedReader(this.8));
            if (!jsonElement.isJsonObject()) {
                if (bl || bl) return;
                throw new Exception(4Q.a((int)((long)1232833677 ^ (long)1232837815), (int)((long)-1905046935 ^ (long)1905064992)) /* "Spam config file is in invalid format" */);
            }
        }
        catch (Exception exception) {
            if (bl || bl) return;
            5z.9.log(Level.FATAL, 4Q.a((int)((long)-174014156 ^ (long)-174010104), (int)((long)1717324164 ^ (long)1717318462)) /* "Unable to load spam config file: {}" */, (Object)exception.getMessage());
            if (bl || bl) return;
            return;
        }
        {
            if (bl) return;
            jsonElement.getAsJsonObject().entrySet().forEach(entry -> {
                String string;
                boolean bl;
                block13: {
                    block12: {
                        bl = \u200e\u200b\u2000\u2007\u200e;
                        if (bl || bl) return;
                        string = (String)entry.getKey();
                        if (bl || bl) return;
                        if (!(entry = (JsonElement)entry.getValue()).isJsonObject()) {
                            if (bl || bl) return;
                            return;
                        }
                        if (bl) return;
                        if (!(entry = entry.getAsJsonObject()).has(4Q.a((int)((long)2103643205 ^ (long)2103647355), (int)((long)-2116957141 ^ (long)2116962616)) /* "delay" */)) break block12;
                        if (bl) return;
                        if (!entry.has(4Q.a((int)((long)1510836140 ^ (long)1510840215), (int)((long)1191802808 ^ (long)1191773891)) /* "messages" */)) break block12;
                        if (bl) return;
                        if (!entry.get(4Q.a((int)((long)-483072919 ^ (long)-483068841), (int)((long)-435709718 ^ (long)435691001)) /* "delay" */).isJsonPrimitive()) break block12;
                        if (bl) return;
                        if (entry.get(4Q.a((int)((long)-463612005 ^ (long)-463616096), (int)((long)-481505655 ^ (long)-481509390)) /* "messages" */).isJsonArray()) break block13;
                        if (bl) return;
                    }
                    if (bl) return;
                    return;
                }
                if (bl) return;
                ArrayList arrayList = new ArrayList();
                if (bl || bl) return;
                entry.getAsJsonArray(4Q.a((int)((long)-1345997661 ^ (long)-1346001768), (int)((long)-1795868696 ^ (long)-1795864941)) /* "messages" */).forEach(jsonElement -> {
                    block4: {
                        block2: {
                            boolean bl;
                            block3: {
                                bl = \u200e\u200b\u2000\u2007\u200e;
                                if (bl || bl) break block2;
                                if (!jsonElement.isJsonPrimitive()) break block3;
                                if (bl || bl) break block2;
                                arrayList.add(jsonElement.getAsString());
                                if (bl) break block2;
                            }
                            if (!bl) break block4;
                        }
                        return;
                    }
                });
                if (bl || bl) return;
                if (arrayList.size() == 0) {
                    if (bl || bl) return;
                    return;
                }
                if (bl) return;
                348.9(8y.4(this.9), new 6Y(string, entry.getAsJsonPrimitive(4Q.a((int)((long)-92878737 ^ (long)-92874671), (int)((long)-602605256 ^ (long)602635307)) /* "delay" */).getAsLong(), arrayList.toArray(new String[(int)((long)1339429987 ^ (long)1339429987)]), (byte)((long)-765534477 ^ (long)-765534477)));
                if (!bl && !bl) return;
            });
            if (bl || bl) return;
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 4Q.\u200e\u200b\u2000\u2007\u200e;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-1913930651 ^ (long)-1913930654)];
            if (var7) break block23;
            var3_2 = (int)((long)1653991090 ^ (long)1653991090);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u981e\ub0b2\ua399\uab38\u9841\ub0f3\ua397\uab3b\u985b\ub06c\ua3ea\uab96\u9871\ub0e5\ua343\uabc0\u98fe\ub08c\ua309\uabdd\u98b5\ub04f\ua343\uabd1\u98e4\ub01f\ua324\uaba4\u9806\ub041\ua3c4\uab00\u9839\ub06e\ua33f\uab14\u980c\ub015\ua343\uabd0\u9805\ub05a\ua327\uabd1\u982d\ub053\ua371\uab85\u98ce\ub02c\ua39c\uab02\u9805\ub0ad\ua355\uab6a\u989e\ub0ab\ua3da\uab60\u98ac\ub074\ua31c\uab20\u9844", 1093254751);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1462638681 ^ (long)-1462638686);
            if (var7) break block23;
            var0_6 = (int)((long)971794721 ^ (long)-971794722);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1136391728 ^ (long)1136391796);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1528271173 ^ (long)-1528271174);
                    if (4Q.\u200e\u200b\u2000\u2007\u200e) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!4Q.\u200e\u200b\u2000\u2007\u200e) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\udab5\uf272\ue19c\ue937\udab8\uf207\ue10e\ue999\udaf9\uf296\ue1e0\ue97b\uda5d\uf26d\ue10d\ue9db\udae1\uf2d4\ue1de\ue9d9\uda0e\uf20c\ue18a\ue941\udafa\uf2b2\ue1c2\ue9a8\udaef\uf2a2\ue1eb\ue9b0\uda70\uf28c\ue1b3\ue9d4\uda1e\uf2fc\ue180\ue9a1\udaed\uf228\ue16b\ue988\uda54\uf224\ue1d6", 1003813980);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)1928366376 ^ (long)1928366349);
                            var0_6 = (int)((long)517384904 ^ (long)-517384905);
                            while (true) {
                                v0 = (int)((long)508008257 ^ (long)508008203);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1102098666 ^ (long)-1102098666);
                                if (!4Q.\u200e\u200b\u2000\u2007\u200e) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!4Q.\u200e\u200b\u2000\u2007\u200e) ** continue;
                                throw null;
                            }
                            4Q.a = var5_1;
                            4Q.b = new String[(int)((long)-1737943770 ^ (long)-1737943775)];
                            if (!4Q.\u200e\u200b\u2000\u2007\u200e) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-2028765915 ^ (long)-2028765915);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)831469894 ^ (long)831469895)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1540937709 ^ (long)1540937706)) {
                                case 0: {
                                    v15 = (int)((long)1474411927 ^ (long)1474412015);
                                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1341848793 ^ (long)1341848778);
                                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1203398788 ^ (long)1203398817);
                                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1810517200 ^ (long)1810517240);
                                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-384544369 ^ (long)-384544314);
                                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)448149169 ^ (long)448149171);
                                    if (!4Q.\u200e\u200b\u2000\u2007\u200e) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-204665950 ^ (long)-204665983);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!4Q.\u200e\u200b\u2000\u2007\u200e);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private 4Q(8y y) {
        block3: {
            block2: {
                boolean bl = \u200e\u200b\u2000\u2007\u200e;
                this.9 = y;
                if (bl || bl) break block2;
                5z.4();
                this.8 = 5z.1(4Q.a((int)((long)1469853891 ^ (long)1469849850), (int)((long)448275659 ^ (long)448292765)) /* "spam.json" */);
                if (!bl) break block3;
            }
            return;
        }
    }
}

