/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.blaze3d.systems.RenderSystem
 *  djl
 *  it.unimi.dsi.fastutil.objects.Object2LongArrayMap
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  st
 *  st$a
 *  st$b
 */
package net.impactclient;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.objects.Object2LongArrayMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.0p;
import net.impactclient.1P;
import net.impactclient.1q;
import net.impactclient.1z;
import net.impactclient.2n;
import net.impactclient.2w$6X;
import net.impactclient.345;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3C;
import net.impactclient.3W;
import net.impactclient.3sh;
import net.impactclient.3sx;
import net.impactclient.4I;
import net.impactclient.7m;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7v
extends 7m<0p> {
    @EventHandler
    private final Listener<1q> 5;
    @EventHandler
    private final Listener<3W> 8;
    private 1P 3p;
    private boolean 6;
    private List<4I> 4;
    private 345 3Y;
    @EventHandler
    private final Listener<3C> 1;
    @EventHandler
    private final Listener<3sx> 2;
    @EventHandler
    private final Listener<3sh> 9;
    private Object2LongArrayMap<4I> 7;
    private static final String[] b;
    private 1z 0;
    public static final boolean \u2001\u200b\u2002\u2006\u200e;
    private static final String[] a;

    /*
     * Enabled aggressive block sorting
     */
    private void 3(boolean bl) {
        block5: {
            block2: {
                boolean bl2;
                block4: {
                    block3: {
                        bl2 = \u2001\u200b\u2002\u2006\u200e;
                        if (bl2 || bl2) break block2;
                        if (!bl) break block3;
                        if (bl2 || bl2) break block2;
                        this.7.keySet().forEach(this::8);
                        if (bl2) break block2;
                    }
                    if (bl2) break block2;
                    if (7v.3.r == null) break block4;
                    if (bl2 || bl2) break block2;
                    7v.3.r.d((int)((long)-1288398600 ^ (long)1261689587));
                    if (bl2) break block2;
                }
                if (bl2) break block2;
                this.3Y = null;
                if (bl2 || bl2) break block2;
                this.7.clear();
                if (!bl2 && !bl2) break block5;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7v.\u2001\u200b\u2002\u2006\u200e;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)744213183 ^ (long)744213176)];
            if (var7) break block23;
            var3_2 = (int)((long)-1505173173 ^ (long)-1505173173);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u44f0\u6dc6\u7e33\u768d\u44a4\u6dbb\u7e80\u76db\u44ce\u6dec\u7e3c\u7645\u4452\u6da1\u7ebe\u7615\u448b\u6d0c\u7e36\u76bd\u447c\u6d74\u7e26\u7681\u44f5\u6da2\u7e13\u769b\u44ab\u6d9e\u7ec4\u763b\u44e4\u6d24\u7e9d\u76a8\u4423\u6d81\u7ea4\u7647\u44cc\u6dc1\u7e2a\u7603\u44da\u6d34\u7eb7\u7652\u4474\u6ded\u7ef9\u762a\u44e9\u6dd3\u7e9d\u7669\u44d3\u6d9d\u7e6f\u768b\u44a8\u6df9\u7ea0\u76f2\u44a4\u6df9\u7e6c\u76a6\u44db\u6dbe\u7e7c\u7682\u444b\u6ded", -1947901154);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-817712299 ^ (long)-817712302);
            if (var7) break block23;
            var0_6 = (int)((long)993330719 ^ (long)-993330720);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1348284860 ^ (long)1348284900);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1732261052 ^ (long)1732261051);
                    if (7v.\u2001\u200b\u2002\u2006\u200e) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7v.\u2001\u200b\u2002\u2006\u200e) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u9ef0\ub73f\ua4e3\uac20\u9efb\ub729\ua44f\uac3b\u9eaf\ub73e\ua4f2\uac36\u9ece\ub75f\ua44c\uac81\u9e0e\ub7aa\ua48b\uac25\u9e45\ub7d5\ua421\uacc7\u9e0b\ub74a\ua4de\uac03\u9ec5\ub75b\ua496\uac6c\u9e02\ub772\ua486\uac80\u9ef2\ub7f2\ua44e\uacbf\u9ef5\ub763\ua451\uace2\u9e6b\ub753\ua44a\uac10\u9e46", -1298286095);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)407719522 ^ (long)407719492);
                            var0_6 = (int)((long)2042162941 ^ (long)-2042162942);
                            while (true) {
                                v0 = (int)((long)1800848467 ^ (long)1800848426);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-223488505 ^ (long)-223488505);
                                if (!7v.\u2001\u200b\u2002\u2006\u200e) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7v.\u2001\u200b\u2002\u2006\u200e) ** continue;
                                throw null;
                            }
                            7v.a = var5_1;
                            7v.b = new String[(int)((long)162858186 ^ (long)162858189)];
                            if (!7v.\u2001\u200b\u2002\u2006\u200e) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1020312648 ^ (long)-1020312648);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1316617176 ^ (long)-1316617175)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)805441811 ^ (long)805441812)) {
                                case 0: {
                                    v15 = (int)((long)115322609 ^ (long)115322501);
                                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)940253817 ^ (long)940253744);
                                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-2472017 ^ (long)-2471953);
                                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1619565447 ^ (long)-1619565481);
                                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-622973996 ^ (long)-622973959);
                                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-184374261 ^ (long)-184374159);
                                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1425625952 ^ (long)1425625945);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7v.\u2001\u200b\u2002\u2006\u200e);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 7v.\u2001\u200b\u2002\u2006\u200e;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1255159022 ^ (long)-1255171938)) & (int)((long)155339103 ^ (long)155367072);
            if (var9_2) ** GOTO lbl-1000
            if (7v.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7v.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-813026120 ^ (long)-813026120)] & (int)((long)-1650283265 ^ (long)-1650283520)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1821864052 ^ (long)1821864089);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1494966552 ^ (long)-1494966649);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)605882833 ^ (long)605882807);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1898935710 ^ (long)-1898935627);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-591532666 ^ (long)-591532788);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1224391251 ^ (long)1224391214);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-54325594 ^ (long)-54325529);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)250956286 ^ (long)250956179);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-995062150 ^ (long)-995062172);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-20374426 ^ (long)-20374457);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)52619881 ^ (long)52620026);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)158624086 ^ (long)158624186);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-894266935 ^ (long)-894267110);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-947563735 ^ (long)-947563612);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1959720591 ^ (long)-1959720455);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1499261470 ^ (long)-1499261597);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1839735271 ^ (long)-1839735134);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1946310898 ^ (long)1946310891);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1480920984 ^ (long)1480920985);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-2091505760 ^ (long)-2091505835);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)161710083 ^ (long)161710262);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-266238288 ^ (long)-266238377);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1180083366 ^ (long)-1180083328);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-51532345 ^ (long)-51532421);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)827157324 ^ (long)827157463);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-921245139 ^ (long)-921245003);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1395163384 ^ (long)1395163189);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1134125948 ^ (long)1134125893);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1982268930 ^ (long)-1982269015);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)731124334 ^ (long)731124410);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1934227172 ^ (long)1934227159);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)375516515 ^ (long)375516671);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-826832851 ^ (long)-826832713);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-404426889 ^ (long)-404426918);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-349672188 ^ (long)-349672020);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1737389117 ^ (long)-1737389063);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)130792570 ^ (long)130792649);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)335700638 ^ (long)335700693);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-993896607 ^ (long)-993896560);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1701054526 ^ (long)1701054702);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)504261666 ^ (long)504261885);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1192529202 ^ (long)1192529386);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)631321534 ^ (long)631321514);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)340574215 ^ (long)340574345);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-842025817 ^ (long)-842025797);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-316990135 ^ (long)-316990016);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1156920659 ^ (long)1156920764);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)829293995 ^ (long)829293916);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-746126184 ^ (long)-746126235);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)195944930 ^ (long)195944948);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-8259512 ^ (long)-8259364);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1877577503 ^ (long)-1877577491);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)835180447 ^ (long)835180536);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1362882503 ^ (long)-1362882495);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1904055367 ^ (long)1904055360);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1485313944 ^ (long)-1485314025);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-69638857 ^ (long)-69638826);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1051045797 ^ (long)-1051045729);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1658814002 ^ (long)-1658813979);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-494027439 ^ (long)-494027363);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1755758152 ^ (long)-1755758234);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1686023145 ^ (long)-1686022945);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1907794598 ^ (long)1907794563);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-2114936132 ^ (long)-2114936205);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)958257034 ^ (long)958257025);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1086138937 ^ (long)-1086138899);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1198052590 ^ (long)-1198052526);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)737151519 ^ (long)737151552);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)755187874 ^ (long)755187751);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1888198644 ^ (long)-1888198486);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)120163555 ^ (long)120163355);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1972095334 ^ (long)1972095345);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1895228696 ^ (long)1895228874);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-653459052 ^ (long)-653459159);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-390192202 ^ (long)-390192249);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1549133239 ^ (long)0x5C55E5E5);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1179693937 ^ (long)-1179694027);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-4185998 ^ (long)-4186009);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)503096747 ^ (long)503096801);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)536784696 ^ (long)536784775);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1515228210 ^ (long)1515228271);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)511315918 ^ (long)511315815);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-2056539449 ^ (long)-2056539589);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-2036281765 ^ (long)-2036281610);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)505958388 ^ (long)505958333);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)126256000 ^ (long)126256050);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1309396260 ^ (long)-1309396427);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1685417286 ^ (long)-1685417304);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1193233179 ^ (long)1193233400);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-96575681 ^ (long)-96575719);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-888236025 ^ (long)-888235945);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-37740123 ^ (long)-37740250);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1555585326 ^ (long)1555585351);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1238844448 ^ (long)-1238844517);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1586894212 ^ (long)-1586894268);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1294468768 ^ (long)-1294468619);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)834419918 ^ (long)834419883);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1106016452 ^ (long)-1106016325);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)877131822 ^ (long)877131893);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-209312313 ^ (long)-209312365);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1628940639 ^ (long)1628940795);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)650467563 ^ (long)650467557);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1575888043 ^ (long)-1575888042);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)688544291 ^ (long)688544423);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)374762105 ^ (long)374762201);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)19171606 ^ (long)19171673);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)847094576 ^ (long)847094532);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)340513931 ^ (long)340513891);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-690419757 ^ (long)-690419757);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1458033108 ^ (long)-1458032903);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-433780725 ^ (long)-433780665);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1203279179 ^ (long)1203279280);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)239680949 ^ (long)239680913);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1935230048 ^ (long)-1935230000);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1886305156 ^ (long)1886305077);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1497338625 ^ (long)1497338840);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-107266932 ^ (long)-107266970);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1719809599 ^ (long)-1719809737);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1445415015 ^ (long)1445415081);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-68260902 ^ (long)-68260905);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-811137130 ^ (long)-811137052);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1469880677 ^ (long)1469880608);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)221081863 ^ (long)221082046);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-432215039 ^ (long)-432215035);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)2042301468 ^ (long)2042301654);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-871067762 ^ (long)-871067683);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1137906059 ^ (long)-1137906129);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1379864889 ^ (long)1379864909);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1598092762 ^ (long)-1598092630);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1151333599 ^ (long)1151333594);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)297371011 ^ (long)297371005);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1952213319 ^ (long)-1952213293);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-404174461 ^ (long)-404174448);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)327833149 ^ (long)327833094);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-679019700 ^ (long)-679019692);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)378331578 ^ (long)378331464);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1625270140 ^ (long)-1625270187);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)784909280 ^ (long)784909093);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1076981296 ^ (long)1076981248);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1627047839 ^ (long)1627047682);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1482244020 ^ (long)-1482243914);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-20434312 ^ (long)-20434207);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1019172978 ^ (long)1019172910);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)175886627 ^ (long)175886695);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1552687590 ^ (long)1552687442);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1029169777 ^ (long)-1029169744);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-2044574544 ^ (long)-2044574478);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1589213707 ^ (long)-1589213922);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)326799105 ^ (long)326799138);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-256519938 ^ (long)-256520017);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-451931594 ^ (long)-451931537);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)855319398 ^ (long)855319512);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-904958492 ^ (long)-904958471);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1889222929 ^ (long)1889223059);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1519161098 ^ (long)-1519161126);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1234053511 ^ (long)1234053622);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-878873492 ^ (long)-878873426);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-660094506 ^ (long)-660094559);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1368450462 ^ (long)-1368450445);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)801539580 ^ (long)801539336);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1968631802 ^ (long)-1968631730);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-700514565 ^ (long)-700514592);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)2137224448 ^ (long)2137224456);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1886364966 ^ (long)-1886365061);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)634077264 ^ (long)634077294);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)489196167 ^ (long)489196268);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-119762979 ^ (long)-119763039);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-133936408 ^ (long)-133936518);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-2077702341 ^ (long)-2077702249);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1820470797 ^ (long)1820470791);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1086242748 ^ (long)1086242786);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1231838359 ^ (long)1231838370);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1054420643 ^ (long)-1054420728);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)597378426 ^ (long)597378304);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)312722070 ^ (long)312722159);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1861352126 ^ (long)-1861352191);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-198664760 ^ (long)-198664792);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1860450455 ^ (long)-1860450327);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1958580883 ^ (long)1958580797);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)950092714 ^ (long)950092775);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1483969632 ^ (long)-1483969570);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1786123903 ^ (long)1786123961);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-908962383 ^ (long)-908962419);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1020146971 ^ (long)-1020147143);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1246246915 ^ (long)-1246247110);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1595624560 ^ (long)1595624658);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1917051909 ^ (long)1917052019);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1308060791 ^ (long)-1308060905);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1862306149 ^ (long)1862306293);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)2079653291 ^ (long)2079653180);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1162519031 ^ (long)1162519016);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1726033087 ^ (long)-1726033100);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)305410867 ^ (long)305410844);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1332269926 ^ (long)1332269991);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)246818132 ^ (long)246818219);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1630250973 ^ (long)-1630251004);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1090843179 ^ (long)1090843215);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-697816934 ^ (long)-697816968);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1752576299 ^ (long)-1752576315);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-687949820 ^ (long)-687949722);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1400227850 ^ (long)1400227980);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1501815925 ^ (long)-1501816003);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-586060771 ^ (long)-586060793);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-5281913 ^ (long)-5281951);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)2015782842 ^ (long)2015782677);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-445521045 ^ (long)-445521000);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-514559938 ^ (long)-514559984);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1475207793 ^ (long)-1475207875);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)826975531 ^ (long)826975707);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-2035409901 ^ (long)-2035409740);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1046535963 ^ (long)1046535954);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)2052939535 ^ (long)2052939724);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1978331761 ^ (long)1978331825);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-139892162 ^ (long)-139892215);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)119156658 ^ (long)119156656);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1670972766 ^ (long)-1670972902);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1690562387 ^ (long)-1690562427);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1294362957 ^ (long)1294363060);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1470460851 ^ (long)-1470460893);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-320246930 ^ (long)-320246792);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)2117945631 ^ (long)2117945812);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-717429053 ^ (long)-717429116);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)750050793 ^ (long)750050662);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1484940853 ^ (long)1484940915);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1070050241 ^ (long)1070050095);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1114276709 ^ (long)1114276800);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-579768141 ^ (long)-579768233);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1741958410 ^ (long)-1741958591);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1723156677 ^ (long)-1723156684);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-2120614089 ^ (long)-2120614033);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-265828083 ^ (long)-265827859);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1916288021 ^ (long)-1916288053);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)2004916548 ^ (long)2004916519);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1558575189 ^ (long)1558575228);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1464597062 ^ (long)1464597159);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-980569007 ^ (long)-980568838);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-886351793 ^ (long)-886351724);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-506772922 ^ (long)-506772756);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1504193404 ^ (long)-1504193447);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)208006812 ^ (long)208006730);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-613370709 ^ (long)-613370681);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)984139431 ^ (long)984139318);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1127155709 ^ (long)-1127155552);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-2089012472 ^ (long)-2089012438);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-706074589 ^ (long)-706074477);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1445678737 ^ (long)-1445678820);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1546527854 ^ (long)1546527750);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-916679236 ^ (long)-916679190);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1656831007 ^ (long)-1656831126);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-283482037 ^ (long)-283481938);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1326199508 ^ (long)-1326199526);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-609451064 ^ (long)-609451177);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1890665129 ^ (long)1890665056);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)355245828 ^ (long)355245881);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)631905303 ^ (long)631905297);
                    if (!7v.\u2001\u200b\u2002\u2006\u200e) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)514074183 ^ (long)514074121);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1698468767 ^ (long)-1698468706)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)383929630 ^ (long)383955681)) >>> (int)((long)1403485716 ^ (long)1403485724)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1510198439 ^ (long)1510198439);
            if (!7v.\u2001\u200b\u2002\u2006\u200e) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-483764462 ^ (long)-483764464);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)19876003 ^ (long)19876000) | var5_6 << (int)((long)-1397647213 ^ (long)-1397647210)) ^ var3_4[var7_8]) & (int)((long)1665620492 ^ (long)1665620723);
                    if (7v.\u2001\u200b\u2002\u2006\u200e) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-412719694 ^ (long)-412719695) | var6_7 << (int)((long)-1677448273 ^ (long)-1677448278)) ^ var3_4[var7_8]) & (int)((long)1669977790 ^ (long)1669977665);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7v.b[var2_3] = new String(var3_4).intern();
        }
        return 7v.b[var2_3];
    }

    public 7v(0p p) {
        boolean bl = \u2001\u200b\u2002\u2006\u200e;
        super(p, 7v.a((int)((long)-2063137928 ^ (long)-2063118091), (int)((long)468566112 ^ (long)468568993)) /* "Real" */, null);
        this.0 = (1z)((34e)((34e)((34e)this.1().5(7v.a((int)((long)1160479835 ^ (long)1160501207), (int)((long)-1787640564 ^ (long)1787626374)) /* "Latency" */)).7(7v.a((int)((long)-873379246 ^ (long)-873391652), (int)((long)-744859754 ^ (long)744867607)) /* "latency" */)).1(7v.a((int)((long)88296251 ^ (long)88283316), (int)((long)1600261469 ^ (long)-1600272436)) /* "The additional latency that you will have" */)).3((int)((long)535703508 ^ (long)535703518)).2((int)((long)-1587431096 ^ (long)-1587429736)).5();
        this.3p = (1P)((34X)((34X)((34X)this.4().5(7v.a((int)((long)-757771100 ^ (long)-757790932), (int)((long)1140477766 ^ (long)-1140475004)) /* "Render Real" */)).7(7v.a((int)((long)817602659 ^ (long)817624041), (int)((long)1628768456 ^ (long)1628770342)) /* "renderReal" */)).1(7v.a((int)((long)-1728867587 ^ (long)-1728855692), (int)((long)-1525832909 ^ (long)-1525814753)) /* "Render the position of the real player" */)).5();
        this.7 = new Object2LongArrayMap();
        this.4 = new ArrayList<4I>();
        Predicate[] predicateArray = new Predicate[(int)((long)-1373679944 ^ (long)-1373679943)];
        predicateArray[(int)((long)-251896832 ^ (long)-251896832)] = c2 -> {
            boolean bl = \u2001\u200b\u2002\u2006\u200e;
            if (bl || bl) return true;
            if (7v.3.s != null) {
                if (bl) return true;
                if (!this.6) {
                    if (bl) return true;
                    return (int)((long)720537050 ^ (long)720537051) != 0;
                }
            }
            if (!bl) return (int)((long)-353258395 ^ (long)-353258395) != 0;
            return true;
        };
        this.1 = new Listener(c2 -> {
            block3: {
                block2: {
                    boolean bl = \u2001\u200b\u2002\u2006\u200e;
                    if (bl || bl) break block2;
                    this.7.put((Object)new 4I(c2.7, 7v.3.s.av, 7v.3.s.K, 7v.3.s.bA(), 7v.3.s.bz(), (byte)((long)519968503 ^ (long)519968503)), System.nanoTime() / (0xB45244862621A04BL ^ 0xB4524486262EE20BL));
                    if (bl || bl) break block2;
                    c2.cancel();
                    if (!bl && !bl) break block3;
                }
                return;
            }
        }, predicateArray);
        Predicate[] predicateArray2 = new Predicate[(int)((long)1516251898 ^ (long)1516251899)];
        predicateArray2[(int)((long)-1201500306 ^ (long)-1201500306)] = sh2 -> {
            boolean bl = \u2001\u200b\u2002\u2006\u200e;
            if (bl || bl) return true;
            if (7v.3.s != null) {
                if (bl) return true;
                if (sh2.5 == EventState.POST) {
                    if (bl) return true;
                    return (int)((long)-383783993 ^ (long)-383783994) != 0;
                }
            }
            if (!bl) return (int)((long)-281422616 ^ (long)-281422616) != 0;
            return true;
        };
        this.9 = new Listener(object -> {
            block6: {
                block2: {
                    boolean bl;
                    block5: {
                        block4: {
                            block3: {
                                bl = \u2001\u200b\u2002\u2006\u200e;
                                if (bl || bl) break block2;
                                object = this;
                                if (!((7v)object).3p.2) break block3;
                                if (bl) break block2;
                                if (((7v)object).3Y != null) break block3;
                                if (bl || bl) break block2;
                                ((7v)object).3Y = new 345(7v.3.r, new GameProfile(UUID.randomUUID(), 2w$6X.KAOZ("", 270620134)));
                                if (bl || bl) break block2;
                                ((7v)object).3Y.7((int)((long)-1391416930 ^ (long)1427630997));
                                if (bl) break block2;
                            }
                            if (bl) break block2;
                            if (((7v)object).3p.2) break block4;
                            if (bl) break block2;
                            if (((7v)object).3Y == null) break block4;
                            if (bl || bl) break block2;
                            7v.3.r.d((int)((long)1143988315 ^ (long)-1138187696));
                            if (bl || bl) break block2;
                            ((7v)object).3Y = null;
                            if (bl) break block2;
                        }
                        if (bl) break block2;
                        this.4.clear();
                        if (bl || bl) break block2;
                        this.7.forEach((i, l) -> {
                            block4: {
                                block2: {
                                    boolean bl;
                                    block3: {
                                        bl = \u2001\u200b\u2002\u2006\u200e;
                                        if (bl || bl) break block2;
                                        if (System.nanoTime() / (0x26C02912838921D9L ^ 0x26C0291283866399L) - l <= (long)this.0.4) break block3;
                                        if (bl || bl) break block2;
                                        this.8((4I)i);
                                        if (bl || bl) break block2;
                                        this.4.add((4I)i);
                                        if (bl) break block2;
                                    }
                                    if (!bl) break block4;
                                }
                                return;
                            }
                        });
                        if (bl || bl) break block2;
                        if (this.3Y == null) break block5;
                        if (bl || bl) break block2;
                        this.7.keySet().stream().filter(i -> {
                            boolean bl;
                            block8: {
                                block7: {
                                    bl = \u2001\u200b\u2002\u2006\u200e;
                                    if (bl || bl) return true;
                                    if (i.3 instanceof st.a) break block7;
                                    if (bl) return true;
                                    if (!(i.3 instanceof st.b)) break block8;
                                    if (bl) return true;
                                }
                                if (bl) return true;
                                return (int)((long)-39818425 ^ (long)-39818426) != 0;
                            }
                            if (!bl) return (int)((long)-48258806 ^ (long)-48258806) != 0;
                            return true;
                        }).filter(i -> {
                            boolean bl = \u2001\u200b\u2002\u2006\u200e;
                            if (bl || bl) return true;
                            if (System.nanoTime() / (0x5DF98E06DF4BEECBL ^ 0x5DF98E06DF44AC8BL) - this.7.getLong(i) > (long)this.0.4) {
                                if (bl) return true;
                                return (int)((long)-807083793 ^ (long)-807083794) != 0;
                            }
                            if (!bl) return (int)((long)-1292039588 ^ (long)-1292039588) != 0;
                            return true;
                        }).max(Comparator.comparingLong(i -> {
                            boolean bl = \u2001\u200b\u2002\u2006\u200e;
                            if (bl || bl) {
                                return -2835842732633331755L;
                            }
                            return this.7.getLong(i);
                        })).ifPresent(i -> {
                            block3: {
                                block2: {
                                    boolean bl = \u2001\u200b\u2002\u2006\u200e;
                                    if (bl || bl) break block2;
                                    st st2 = (st)i.3;
                                    if (bl || bl) break block2;
                                    this.3Y.aD = this.3Y.aC;
                                    if (bl || bl) break block2;
                                    this.3Y.aC = st2.a(this.3Y.p);
                                    this.3Y.a(st2.a(this.3Y.cD()), st2.b(this.3Y.cE()), st2.c(this.3Y.cH()), this.3Y.aC, st2.b(this.3Y.q));
                                    if (bl || bl) break block2;
                                    this.3Y.av = i.9;
                                    if (bl || bl) break block2;
                                    this.3Y.K = i.1;
                                    if (bl || bl) break block2;
                                    this.3Y.g(i.5);
                                    if (bl || bl) break block2;
                                    this.3Y.f(i.0);
                                    if (!bl && !bl) break block3;
                                }
                                return;
                            }
                        });
                        if (bl) break block2;
                    }
                    if (bl) break block2;
                    this.4.forEach(arg_0 -> this.7.removeLong(arg_0));
                    if (!bl && !bl) break block6;
                }
                return;
            }
        }, predicateArray2);
        Predicate[] predicateArray3 = new Predicate[(int)((long)-1731351275 ^ (long)-1731351276)];
        predicateArray3[(int)((long)-1689452817 ^ (long)-1689452817)] = w2 -> {
            boolean bl = \u2001\u200b\u2002\u2006\u200e;
            if (bl || bl) return true;
            if (w2.7 == EventState.PRE) {
                if (bl) return true;
                if (w2.1 == this.3Y) {
                    if (bl) return true;
                    return (int)((long)-960652062 ^ (long)-960652061) != 0;
                }
            }
            if (!bl) return (int)((long)1508739417 ^ (long)1508739417) != 0;
            return true;
        };
        this.8 = new Listener(w2 -> {
            block5: {
                block2: {
                    boolean bl;
                    block4: {
                        block3: {
                            bl = \u2001\u200b\u2002\u2006\u200e;
                            if (bl || bl) break block2;
                            w2.cancel();
                            if (bl || bl) break block2;
                            if (7v.3.k.g() != djl.a) break block3;
                            if (bl) break block2;
                            if (3.aa() == 7v.3.s) break block4;
                            if (bl) break block2;
                        }
                        if (bl) break block2;
                        RenderSystem.pushMatrix();
                        if (bl || bl) break block2;
                        RenderSystem.disableTexture();
                        if (bl || bl) break block2;
                        RenderSystem.color4f((float)1.0f, (float)1.0f, (float)1.0f, (float)0.6f);
                        if (bl || bl) break block2;
                        2n.4(w2);
                        if (bl || bl) break block2;
                        RenderSystem.enableTexture();
                        if (bl || bl) break block2;
                        RenderSystem.popMatrix();
                        if (bl) break block2;
                    }
                    if (!bl) break block5;
                }
                return;
            }
        }, predicateArray3);
        Predicate[] predicateArray4 = new Predicate[(int)((long)1599885675 ^ (long)1599885674)];
        predicateArray4[(int)((long)-2059637140 ^ (long)-2059637140)] = q -> {
            boolean bl = \u2001\u200b\u2002\u2006\u200e;
            if (bl || bl) return true;
            if (q.9 == this.3Y) {
                if (bl) return true;
                return (int)((long)1294868196 ^ (long)1294868197) != 0;
            }
            if (!bl) return (int)((long)-109365929 ^ (long)-109365929) != 0;
            return true;
        };
        this.5 = new Listener(q -> {
            block3: {
                block2: {
                    boolean bl = \u2001\u200b\u2002\u2006\u200e;
                    if (bl || bl) break block2;
                    q.cancel();
                    if (!bl && !bl) break block3;
                }
                return;
            }
        }, predicateArray4);
        this.2 = new Listener(sx -> {
            block3: {
                block2: {
                    boolean bl = \u2001\u200b\u2002\u2006\u200e;
                    if (bl || bl) break block2;
                    this.3((boolean)((long)-1877582266 ^ (long)-1877582266));
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)-1504824525 ^ (long)-1504824525)]);
    }

    @Override
    public final void 9() {
        int n;
        boolean bl = \u2001\u200b\u2002\u2006\u200e;
        if (bl || bl) {
            return;
        }
        if (7v.3.s != null) {
            n = (int)((long)689563856 ^ (long)689563857);
            if (\u2001\u200b\u2002\u2006\u200e) {
                throw null;
            }
        } else {
            n = (int)((long)-2107932823 ^ (long)-2107932823);
        }
        this.3(n != 0);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 8(4I i) {
        block3: {
            block2: {
                boolean bl = \u2001\u200b\u2002\u2006\u200e;
                if (bl || bl) break block2;
                this.6 = (int)((long)56061838 ^ (long)56061839);
                if (bl || bl) break block2;
                7v.3.s.e.a(i.3);
                if (bl || bl) break block2;
                this.6 = (int)((long)-1219961708 ^ (long)-1219961708);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }
}

