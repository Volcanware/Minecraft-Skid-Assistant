/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.07;
import net.impactclient.1;
import net.impactclient.1K;
import net.impactclient.2w$6X;
import net.impactclient.34e;
import net.impactclient.4E;
import net.impactclient.4f;
import net.impactclient.4m;
import net.impactclient.5Q;
import net.impactclient.7m;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 15
extends 7m<07> {
    @EventHandler
    private final Listener<1> 2;
    @EventHandler
    private final Listener<4f> 1;
    public static final boolean \u2002;
    private static final String[] a;
    @EventHandler
    private final Listener<4E> 8;
    private 1K 4;
    private static final String[] b;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 15.\u2002;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-159961401 ^ (long)159942580)) & (int)((long)1662410607 ^ (long)1662427280);
            if (var9_2) ** GOTO lbl-1000
            if (15.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 15.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-111865130 ^ (long)-111865130)] & (int)((long)-31698640 ^ (long)-31698481)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-17133120 ^ (long)-17133085);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)621394070 ^ (long)621394097);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1734687488 ^ (long)1734687731);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-2106441655 ^ (long)-2106441481);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)492427845 ^ (long)492427929);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-506579993 ^ (long)-506580011);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1919557751 ^ (long)-1919557749);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-2104640533 ^ (long)-2104640570);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)181831216 ^ (long)181831329);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-663691651 ^ (long)-663691555);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)2050138741 ^ (long)2050138821);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1926069922 ^ (long)1926069858);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1425148701 ^ (long)-1425148730);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1599615963 ^ (long)-1599615894);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-780833516 ^ (long)-780833492);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)488656142 ^ (long)488656256);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-792121864 ^ (long)-792121911);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-776744505 ^ (long)-776744533);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1862485517 ^ (long)-1862485626);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1681019279 ^ (long)-1681019166);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)816729094 ^ (long)816729274);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1356346031 ^ (long)-1356346049);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)310978095 ^ (long)310978065);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-793319175 ^ (long)-793319340);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-617947926 ^ (long)-617948150);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1193214276 ^ (long)1193214269);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1980973463 ^ (long)1980973350);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1155156499 ^ (long)-1155156566);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1861858304 ^ (long)1861858434);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-2028759966 ^ (long)-2028759946);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1578919620 ^ (long)-1578919601);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1410764490 ^ (long)-1410764496);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1491743996 ^ (long)-1491743914);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1511973824 ^ (long)1511973709);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-49971150 ^ (long)-49971031);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-824324532 ^ (long)-824324443);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1052352422 ^ (long)1052352438);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1212062184 ^ (long)1212062009);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-2114791150 ^ (long)-2114791051);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1359871073 ^ (long)-1359871123);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1949296063 ^ (long)-1949295889);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1584026972 ^ (long)1584027129);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-569600395 ^ (long)-569600408);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1707561307 ^ (long)1707561229);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1083582295 ^ (long)-1083582307);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1141742800 ^ (long)1141742809);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1760041251 ^ (long)-1760041418);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1786130505 ^ (long)-1786130517);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-597339520 ^ (long)-597339618);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1263642393 ^ (long)-1263642441);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1711493288 ^ (long)1711493137);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)22135801 ^ (long)22135565);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)531819052 ^ (long)531819247);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1988509956 ^ (long)1988510185);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1304440566 ^ (long)1304440358);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1064951761 ^ (long)-1064951759);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1783738704 ^ (long)1783738736);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1574988771 ^ (long)-1574988601);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)2013141792 ^ (long)2013141973);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)19315703 ^ (long)19315551);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1910988142 ^ (long)-1910988220);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)270221800 ^ (long)270221704);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1887755229 ^ (long)1887755034);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)410350994 ^ (long)410350897);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1749066344 ^ (long)-1749066491);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1618719274 ^ (long)1618719299);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-15207726 ^ (long)-15207733);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1271842933 ^ (long)1271842996);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)613080536 ^ (long)613080512);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1992657201 ^ (long)1992657378);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-317114201 ^ (long)-317114317);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)975382181 ^ (long)975382166);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)984435224 ^ (long)984435254);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)448489181 ^ (long)448488977);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1129091215 ^ (long)-1129091322);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-757457815 ^ (long)-757457720);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)742593944 ^ (long)742594042);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1428560204 ^ (long)1428560291);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)975953275 ^ (long)975953215);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1685435668 ^ (long)1685435749);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1436998824 ^ (long)1436998793);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)620731252 ^ (long)620731388);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-2081006342 ^ (long)-2081006434);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1854497910 ^ (long)1854497867);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)741953678 ^ (long)741953663);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)333464634 ^ (long)333464748);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-778752511 ^ (long)-778752458);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1274203514 ^ (long)-1274203645);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)697527640 ^ (long)697527568);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1671531842 ^ (long)1671532004);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)439630978 ^ (long)439630904);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1049006916 ^ (long)1049006968);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1061196643 ^ (long)-1061196762);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-644697664 ^ (long)-644697650);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1050187636 ^ (long)-1050187533);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-196378635 ^ (long)-196378638);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1984199344 ^ (long)-1984199410);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1447746199 ^ (long)-1447746116);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-962980004 ^ (long)-962980081);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-555214672 ^ (long)-555214642);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)443413017 ^ (long)443413132);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1875804085 ^ (long)-1875804080);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)945981046 ^ (long)945981113);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1301728700 ^ (long)-1301728576);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)2102573641 ^ (long)2102573675);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-997393230 ^ (long)-997393330);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1562748529 ^ (long)-1562748417);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1920069807 ^ (long)1920069727);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-593913639 ^ (long)-593913773);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-406889047 ^ (long)-406889132);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1946216412 ^ (long)1946216254);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1054949870 ^ (long)1054949733);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1305988029 ^ (long)-1305987892);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1249822874 ^ (long)-1249822801);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1947526138 ^ (long)1947526092);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-2079041736 ^ (long)-2079041563);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1233265466 ^ (long)1233265620);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-836485341 ^ (long)-836485128);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1351645558 ^ (long)-1351645651);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)410471450 ^ (long)410471636);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)127140580 ^ (long)127140452);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1188099385 ^ (long)1188099394);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)874777880 ^ (long)874777884);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1973927638 ^ (long)1973927489);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)2039109931 ^ (long)2039109953);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1788141879 ^ (long)1788142016);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-2029214577 ^ (long)-2029214634);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)403450452 ^ (long)403450622);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1935304804 ^ (long)1935304835);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1928877267 ^ (long)1928877196);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-272950474 ^ (long)-272950320);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1536930985 ^ (long)-1536931037);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)645777137 ^ (long)645776989);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-2096977233 ^ (long)-2096977241);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-179065138 ^ (long)-179065189);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1256655546 ^ (long)1256655552);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1199002605 ^ (long)-1199002594);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1786343034 ^ (long)-1786343120);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1439889073 ^ (long)1439889045);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)985864273 ^ (long)985864242);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)613707977 ^ (long)613708006);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1039326195 ^ (long)-1039326169);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1897472973 ^ (long)1897472768);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)568016374 ^ (long)568016312);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1777725794 ^ (long)-1777725737);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)2008933748 ^ (long)2008933853);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)2011956333 ^ (long)2011956281);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1738969379 ^ (long)-1738969598);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-829262801 ^ (long)-829262651);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)626790505 ^ (long)626790645);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-865890157 ^ (long)-865890158);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)712606083 ^ (long)712606170);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)2091932678 ^ (long)2091932800);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-858631340 ^ (long)-858631220);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-408640522 ^ (long)-408640535);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1736704050 ^ (long)-1736704179);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1863183553 ^ (long)1863183488);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1566162515 ^ (long)-1566162612);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)989124880 ^ (long)989124984);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1939141124 ^ (long)1939141142);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1464586506 ^ (long)-1464586527);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1985086266 ^ (long)1985086310);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)264972935 ^ (long)264972983);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1596469178 ^ (long)-1596469086);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)85093529 ^ (long)85093478);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1479451561 ^ (long)-1479451648);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1494362162 ^ (long)-1494362244);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)173011401 ^ (long)173011372);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1640698134 ^ (long)1640698312);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1692833017 ^ (long)1692832859);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)2089280156 ^ (long)2089280199);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1255254652 ^ (long)1255254630);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)570074034 ^ (long)570073862);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-884029134 ^ (long)-884028984);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-777894706 ^ (long)-777894667);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-247189200 ^ (long)-247189220);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-137938021 ^ (long)-137938136);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1240605779 ^ (long)-1240605849);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1208920542 ^ (long)1208920433);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-190314448 ^ (long)-190314486);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1159689539 ^ (long)-1159689659);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1608317558 ^ (long)1608317440);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1110412785 ^ (long)-1110412715);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-588606395 ^ (long)-588606424);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)195233796 ^ (long)195233913);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1720946445 ^ (long)-1720946542);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1344978242 ^ (long)1344978373);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-948798336 ^ (long)-948798411);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-413968384 ^ (long)-413968367);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-2135015769 ^ (long)-2135015835);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1239447990 ^ (long)1239448004);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1293626888 ^ (long)1293626946);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1892823727 ^ (long)-1892823613);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-187059287 ^ (long)-187059221);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-536075131 ^ (long)-536075231);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-947720464 ^ (long)-947720485);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-425343834 ^ (long)-425343920);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-663078647 ^ (long)-663078596);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1330417749 ^ (long)1330417686);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-2018627418 ^ (long)-2018627496);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1500177720 ^ (long)-1500177725);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1884183738 ^ (long)1884183807);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-163262610 ^ (long)-163262633);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-689027920 ^ (long)-689028088);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)697080139 ^ (long)697080273);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)2107692514 ^ (long)2107692529);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1833564366 ^ (long)1833564391);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1994993393 ^ (long)-1994993405);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1843081099 ^ (long)-1843081040);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1523200404 ^ (long)1523200336);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-442111497 ^ (long)-442111732);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-338719641 ^ (long)-338719631);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1202872030 ^ (long)-1202871890);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1504943752 ^ (long)1504943799);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1838783596 ^ (long)-1838783596);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1377607511 ^ (long)1377607447);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-2019205282 ^ (long)-2019205143);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-503704316 ^ (long)-503704241);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1141865627 ^ (long)1141865598);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1804498973 ^ (long)-1804498954);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-539960069 ^ (long)-539960131);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)198439865 ^ (long)198439862);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)777805209 ^ (long)777805212);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-505550144 ^ (long)-505550209);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1419971910 ^ (long)-1419971850);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)162673124 ^ (long)162673026);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-639637453 ^ (long)-639637285);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1477955678 ^ (long)-1477955601);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)801946245 ^ (long)801946255);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)37529212 ^ (long)37529111);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-187640380 ^ (long)-187640392);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)131028323 ^ (long)131028352);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-403921222 ^ (long)-403921284);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-149390752 ^ (long)-149390599);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1588074820 ^ (long)1588074895);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-201988024 ^ (long)-201987940);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1101331059 ^ (long)1101331186);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1621419981 ^ (long)1621419925);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-640261677 ^ (long)-640261643);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-465293324 ^ (long)-465293495);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)782958867 ^ (long)782959082);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)221544073 ^ (long)221544001);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1780656046 ^ (long)1780655990);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)92215443 ^ (long)92215502);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-699284375 ^ (long)-699284347);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1342705828 ^ (long)-1342705716);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-7910245 ^ (long)-7910324);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-374608257 ^ (long)-374608260);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1513179997 ^ (long)-1513179941);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)544521725 ^ (long)544521558);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)784868822 ^ (long)784868743);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)80503731 ^ (long)80503649);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)896685497 ^ (long)896685526);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1992933354 ^ (long)-1992933314);
                    if (!15.\u2002) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1377213408 ^ (long)1377213311);
                    if (!15.\u2002) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1242821839 ^ (long)-1242821704);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1958591324 ^ (long)-1958591397)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-2043596929 ^ (long)-2043555712)) >>> (int)((long)-2019952008 ^ (long)-2019952016)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)518747660 ^ (long)518747660);
            if (!15.\u2002) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-540520644 ^ (long)-540520642);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1677418642 ^ (long)1677418641) | var5_6 << (int)((long)107952984 ^ (long)107952989)) ^ var3_4[var7_8]) & (int)((long)-557129104 ^ (long)-557129073);
                    if (15.\u2002) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)46006335 ^ (long)46006332) | var6_7 << (int)((long)818172781 ^ (long)818172776)) ^ var3_4[var7_8]) & (int)((long)1728895012 ^ (long)1728895195);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            15.b[var2_3] = new String(var3_4).intern();
        }
        return 15.b[var2_3];
    }

    public 15(07 object) {
        boolean bl = \u2002;
        super(object, 15.a((int)((long)493204903 ^ (long)-493216554), (int)((long)815034365 ^ (long)-815028083)) /* "Vanilla" */, null);
        Double d2 = 1.0;
        object = ((34e)((34e)((34e)this.7().5(15.a((int)((long)-1583288501 ^ (long)1583302201), (int)((long)-592816588 ^ (long)592828418)) /* "Speed" */)).7(15.a((int)((long)-1240539631 ^ (long)1240561505), (int)((long)290757044 ^ (long)290758167)) /* "speed" */)).1(15.a((int)((long)-1962123051 ^ (long)1962133926), (int)((long)-33527085 ^ (long)-33545569)) /* "Flight speed" */)).3(1.0).2(20.0);
        ((34e)((34e)((34e)this.7().5(15.a((int)((long)-1583288501 ^ (long)1583302201), (int)((long)-592816588 ^ (long)592828418)) /* "Speed" */)).7(15.a((int)((long)-1240539631 ^ (long)1240561505), (int)((long)290757044 ^ (long)290758167)) /* "speed" */)).1(15.a((int)((long)-1962123051 ^ (long)1962133926), (int)((long)-33527085 ^ (long)-33545569)) /* "Flight speed" */)).3(1.0).2(20.0).7 = d2;
        this.4 = (1K)((34e)object).5();
        this.1 = new Listener(f -> {
            block3: {
                block2: {
                    boolean bl = \u2002;
                    if (bl || bl) break block2;
                    4m.1((double)Boolean.compare(15.3.s.f.g, 15.3.s.f.h) * (this.4.1 / 3.5));
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)930504802 ^ (long)930504802)]);
        this.8 = new Listener(e2 -> {
            block3: {
                block2: {
                    boolean bl = \u2002;
                    if (bl || bl) break block2;
                    4m.7(e2, 4m.1(5Q.b) * this.4.1);
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)602690662 ^ (long)602690662)]);
        this.2 = new Listener(var0 -> {
            block3: {
                block2: {
                    boolean bl = \u2002;
                    if (bl || bl) break block2;
                    var0.1 = (int)((long)330722995 ^ (long)330722994);
                    if (!bl && !bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)-635536559 ^ (long)-635536559)]);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 15.\u2002;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)470148261 ^ (long)470148257)];
            if (var7) break block23;
            var3_2 = (int)((long)2063221111 ^ (long)2063221111);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ua009\u88cf\u9bbd\u9305\ua09c\u8843\u9be6\u938e\ua005\u88fc\u9b8a\u9327\ua07c\u88d7\u9b59\u9396\ua058\u880f", -842168791);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1364040969 ^ (long)-1364040965);
            if (var7) break block23;
            var0_6 = (int)((long)-195874312 ^ (long)195874311);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)211750843 ^ (long)211750797);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1426614907 ^ (long)1426614906);
                    if (15.\u2002) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!15.\u2002) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u92d4\ubada\ua951\ua147\u92a0\uba9e\ua9e6\ua1d1\u92c1\uba8e\ua979\ua1f2\u92c7", -933907435);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)1551971297 ^ (long)1551971302);
                            var0_6 = (int)((long)-853173146 ^ (long)853173145);
                            while (true) {
                                v0 = (int)((long)168209456 ^ (long)168209464);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)497043183 ^ (long)497043183);
                                if (!15.\u2002) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!15.\u2002) ** continue;
                                throw null;
                            }
                            15.a = var5_1;
                            15.b = new String[(int)((long)-345069527 ^ (long)-345069523)];
                            if (!15.\u2002) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-718041875 ^ (long)-718041875);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1811940306 ^ (long)-1811940305)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-364737887 ^ (long)-364737882)) {
                                case 0: {
                                    v15 = (int)((long)167457248 ^ (long)167457256);
                                    if (!15.\u2002) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-550520825 ^ (long)-550520810);
                                    if (!15.\u2002) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-496539669 ^ (long)-496539694);
                                    if (!15.\u2002) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)732943091 ^ (long)732943011);
                                    if (!15.\u2002) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)988209229 ^ (long)988209271);
                                    if (!15.\u2002) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-904241210 ^ (long)-904241219);
                                    if (!15.\u2002) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)904472988 ^ (long)904473000);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!15.\u2002);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

