/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  bfw
 *  brx
 *  dfm
 *  dku
 *  dzm
 *  k
 *  org.apache.commons.lang3.StringUtils
 */
package net.impactclient;

import clientapi.load.mixin.7.2;
import me.zero.clarinet.hook.mixin.accessor.AccessorFontRenderer;
import net.impactclient.2w$6X;
import net.impactclient.34b;
import net.impactclient.3e;
import net.impactclient.5z;
import net.impactclient.6C;
import net.impactclient.7N;
import net.impactclient.8S;
import org.apache.commons.lang3.StringUtils;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 63
extends 6C {
    private static final String[] a;
    public static final boolean \u2000\u2002\u2002\u200d\u2000\u200c\u2007;
    private static final String[] b;

    /*
     * Enabled aggressive block sorting
     */
    public 63() {
        boolean bl = \u2000\u2002\u2002\u200d\u2000\u200c\u2007;
        if (bl) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1331122818 ^ (long)1331122835)];
            if (var7) break block23;
            var3_2 = (int)((long)-12481374 ^ (long)-12481374);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u5eb7\u7693\u6536\u6dc0\u5ec5\u76b1\u6502\u6dc0\u5e1f\u76fd\u6578\u6dc5\u5e7e\u76fd\u65f5\u6d1e\u5e63\u7644\u65b2\u6d18\u5e7f\u76d2\u65cd\u6d1b\u5eee\u76c0\u656a\u6dac\u5eb8\u76b1\u65b8\u6de9\u5ede\u7649\u65c9\u6d64\u5e09\u7661\u6579\u6d0a\u5e6f\u7689\u6545\u6d48\u5e7d\u76d5\u65b4\u6d46\u5e87\u7664\u65b4\u6d20\u5e5e\u76aa\u65b5\u6dd5\u5e1b\u76af\u655a\u6db6\u5ec7\u7683\u65be\u6d3e\u5edb\u76d4\u65cd\u6dcd\u5eb4\u761e\u6515\u6dbc\u5ee8\u7673\u65ce\u6dea\u5ee8\u761c\u6509\u6d48\u5ee8\u7684\u655f\u6d59", -1302693886);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)2144230276 ^ (long)2144230279);
            if (var7) break block23;
            var0_6 = (int)((long)995721691 ^ (long)-995721692);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)589907682 ^ (long)589907587);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1528999195 ^ (long)-1528999196);
                    if (63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\uab48\u839d\u9025\u98ac\uab69\u833b\u909d\u9869\uabb0\u83c3\u908f\u9857\uabbd\u833f\u90e4\u989f\uabe3\u83f0", -1298100848);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)595134854 ^ (long)595134861);
                            var0_6 = (int)((long)-901782836 ^ (long)901782835);
                            while (true) {
                                v0 = (int)((long)1568145495 ^ (long)1568145519);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-243401385 ^ (long)-243401385);
                                if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) ** continue;
                                throw null;
                            }
                            63.a = var5_1;
                            63.b = new String[(int)((long)-506351078 ^ (long)-506351093)];
                            if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-271492456 ^ (long)-271492456);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1191168221 ^ (long)-1191168222)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1148990171 ^ (long)1148990172)) {
                                case 0: {
                                    v15 = (int)((long)966159193 ^ (long)966159154);
                                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1382099513 ^ (long)-1382099560);
                                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)733807636 ^ (long)733807671);
                                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)895306743 ^ (long)895306727);
                                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1612302964 ^ (long)1612302850);
                                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)426756362 ^ (long)426756358);
                                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1940686546 ^ (long)1940686542);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean 9() {
        boolean bl = \u2000\u2002\u2002\u200d\u2000\u200c\u2007;
        if (bl || bl) return true;
        7N n = 5z.4().1z.7(7N.class);
        if (bl || bl) return true;
        if (63.3.s.l.Y() == brx.h) {
            if (bl || bl) return true;
            return n.7U.2;
        }
        if (bl) return true;
        if (63.3.s.l.Y() == brx.g) {
            if (bl || bl) return true;
            return n.7Q.2;
        }
        if (!bl) return (int)((long)83947628 ^ (long)83947628) != 0;
        return true;
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1913706677 ^ (long)1913711214)) & (int)((long)716367111 ^ (long)716315384);
            if (var9_2) ** GOTO lbl-1000
            if (63.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 63.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1732906143 ^ (long)1732906143)] & (int)((long)1340321691 ^ (long)1340321636)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1409555420 ^ (long)1409555281);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1272493404 ^ (long)-1272493409);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)217051689 ^ (long)217051864);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)84547256 ^ (long)84547172);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1566211011 ^ (long)1566210987);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-999762142 ^ (long)-999761991);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1451431454 ^ (long)-1451431603);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)2036729986 ^ (long)2036729941);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-20445365 ^ (long)-20445311);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-524389735 ^ (long)-524389881);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-419694412 ^ (long)-419694362);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-333638741 ^ (long)-333638757);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)378593938 ^ (long)378593955);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)942131273 ^ (long)942131397);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)916875464 ^ (long)916875361);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1227524533 ^ (long)-1227524571);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-256999151 ^ (long)-256999130);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1950624961 ^ (long)-1950624848);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1353568504 ^ (long)-1353568356);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)453558195 ^ (long)453558263);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1730331342 ^ (long)-1730331205);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1849408931 ^ (long)1849409004);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)2069185961 ^ (long)2069185815);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1253683985 ^ (long)-1253684179);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1943378353 ^ (long)-1943378380);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-24128139 ^ (long)-24128082);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1627674678 ^ (long)-1627674762);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)738992667 ^ (long)738992825);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)398522906 ^ (long)398523007);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1402546923 ^ (long)-1402546876);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)848978554 ^ (long)848978642);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)704608569 ^ (long)704608594);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)892464784 ^ (long)892464699);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)105185463 ^ (long)105185437);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1886713847 ^ (long)-1886713607);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-750505070 ^ (long)-750505149);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1101950224 ^ (long)-1101950361);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)314876999 ^ (long)314877022);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1333837645 ^ (long)1333837735);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)451402264 ^ (long)451402346);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1252720226 ^ (long)-1252720205);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1836701011 ^ (long)-1836701050);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)909297391 ^ (long)909297167);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1175071245 ^ (long)-1175071404);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1606898403 ^ (long)1606898352);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-777755766 ^ (long)-777755885);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)2068275534 ^ (long)2068275621);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1542236497 ^ (long)1542236491);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)2066163110 ^ (long)2066163157);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1421529508 ^ (long)-1421529567);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)658643854 ^ (long)658643766);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)351620429 ^ (long)351620560);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1822578708 ^ (long)1822578712);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)743342157 ^ (long)743342093);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1241716099 ^ (long)-1241716140);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)693849395 ^ (long)693849549);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-539491348 ^ (long)-539491563);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1601277284 ^ (long)-1601277300);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-679577495 ^ (long)-679577435);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)448937170 ^ (long)448937025);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)325793106 ^ (long)325793075);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-846369444 ^ (long)-846369464);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1670466150 ^ (long)1670466052);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1674052545 ^ (long)-1674052505);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1672383352 ^ (long)1672383446);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1208652816 ^ (long)-1208652820);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)770547164 ^ (long)770547020);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-823638417 ^ (long)-823638417);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1859982506 ^ (long)-1859982558);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1013771182 ^ (long)-1013771250);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-191099000 ^ (long)-191098958);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1533554960 ^ (long)-1533555096);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)2146341533 ^ (long)2146341454);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1328427953 ^ (long)1328427939);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1775740963 ^ (long)-1775741012);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1119637626 ^ (long)-1119637624);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)590982125 ^ (long)590981923);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-821386672 ^ (long)-821386589);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-2047499424 ^ (long)-2047499327);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)56244110 ^ (long)56244190);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)901887621 ^ (long)901887704);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-659145014 ^ (long)-659145089);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)183128299 ^ (long)183128253);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1981466317 ^ (long)-1981466330);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1217439369 ^ (long)-1217439335);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1675991351 ^ (long)-1675991537);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-72524350 ^ (long)-72524344);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1671541522 ^ (long)1671541557);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1204314857 ^ (long)1204314687);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1040757637 ^ (long)1040757754);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1342653758 ^ (long)1342653801);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)232451871 ^ (long)232452074);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)200447310 ^ (long)200447466);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1763248540 ^ (long)1763248572);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1176316364 ^ (long)-1176316175);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1764823854 ^ (long)1764823874);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)2009542506 ^ (long)2009542431);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-116016636 ^ (long)-116016391);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1969806425 ^ (long)1969806442);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1276459375 ^ (long)-1276459297);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)18285797 ^ (long)18285698);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)745078105 ^ (long)745078090);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-888134915 ^ (long)-888135048);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-848304207 ^ (long)-848304212);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1139330931 ^ (long)1139330861);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-931148840 ^ (long)-931149028);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1966671147 ^ (long)-1966671119);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1203811094 ^ (long)-1203811117);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)11875711 ^ (long)11875657);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1466544035 ^ (long)1466544056);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-229809589 ^ (long)-229809628);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)80413431 ^ (long)80413356);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)2054355591 ^ (long)2054355555);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1486446951 ^ (long)1486447084);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-97456160 ^ (long)-97456288);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)826088332 ^ (long)826088274);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-542595653 ^ (long)-542595645);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1425728492 ^ (long)-1425728347);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-432765270 ^ (long)-432765424);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1730349793 ^ (long)1730349728);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-720395918 ^ (long)-720395820);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1870469897 ^ (long)1870469942);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-103933424 ^ (long)-103933344);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1442385444 ^ (long)1442385590);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-2064159121 ^ (long)-2064159046);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)340247418 ^ (long)340247525);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1619303503 ^ (long)-1619303473);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)887059123 ^ (long)887059086);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-939717310 ^ (long)-939717273);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)576978698 ^ (long)576978910);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1260972494 ^ (long)-1260972365);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1440116245 ^ (long)1440116267);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1493528292 ^ (long)1493528306);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-773548330 ^ (long)-773548447);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1997566835 ^ (long)1997566870);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1917857872 ^ (long)-1917857846);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-826582117 ^ (long)-826582204);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)357861562 ^ (long)357861574);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)2114747801 ^ (long)2114747764);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-886077248 ^ (long)-886077355);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)2107756502 ^ (long)2107756437);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1675205177 ^ (long)-1675205290);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1308947678 ^ (long)-1308947552);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-89014120 ^ (long)-89014172);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1723264669 ^ (long)-1723264658);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-245083395 ^ (long)-245083590);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)997862876 ^ (long)997862766);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)318698600 ^ (long)318698643);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)2068443078 ^ (long)2068443086);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1282501370 ^ (long)-1282501344);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1737250545 ^ (long)1737250309);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)126287520 ^ (long)126287589);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-733564586 ^ (long)-733564452);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)321052150 ^ (long)321052081);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)283225289 ^ (long)283225258);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1848890234 ^ (long)1848890210);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)509283189 ^ (long)509283280);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1267298402 ^ (long)1267298340);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1638915317 ^ (long)-1638915157);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1825780066 ^ (long)1825780138);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1283474023 ^ (long)1283473950);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)2084233594 ^ (long)2084233527);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-871355763 ^ (long)-871355809);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1184765946 ^ (long)1184765896);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-2143021021 ^ (long)-2143020885);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)588820190 ^ (long)588820223);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1135304571 ^ (long)-1135304566);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-718396367 ^ (long)-718396324);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-524511881 ^ (long)-524511804);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1485247998 ^ (long)1485247745);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)513227677 ^ (long)513227612);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)2018761023 ^ (long)2018761021);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1901950282 ^ (long)1901950370);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-545491871 ^ (long)-545491889);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-2120402373 ^ (long)-2120402322);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1253475780 ^ (long)-1253475809);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1027564913 ^ (long)1027564911);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1485768197 ^ (long)-1485768389);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1157748411 ^ (long)-1157748342);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-160733261 ^ (long)-160733341);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)867980484 ^ (long)867980499);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)915688046 ^ (long)915687975);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-279083810 ^ (long)-279083791);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)632146962 ^ (long)632146992);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)230022155 ^ (long)230022311);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1060673953 ^ (long)1060673853);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)672409103 ^ (long)672409282);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)811060082 ^ (long)811060175);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1110476662 ^ (long)-1110476659);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1346318290 ^ (long)-1346318131);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1521544755 ^ (long)1521544916);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)582334494 ^ (long)582334711);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)11018582 ^ (long)11018656);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-101404486 ^ (long)-101404468);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)2039551838 ^ (long)2039551961);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-394565381 ^ (long)-394565594);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-963418531 ^ (long)-963418405);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)714207516 ^ (long)714207622);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1797928494 ^ (long)1797928495);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-924063353 ^ (long)-924063309);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-2083062909 ^ (long)-2083062912);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)774009269 ^ (long)774009335);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)2030392126 ^ (long)2030392167);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)114988283 ^ (long)114988177);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1632714587 ^ (long)1632714515);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-170735077 ^ (long)-170735069);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-18847731 ^ (long)-18847707);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1862328913 ^ (long)1862328969);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-217036008 ^ (long)-217035808);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-515604939 ^ (long)-515604833);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1284587089 ^ (long)1284587198);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)260586909 ^ (long)260586855);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-213051183 ^ (long)-213051321);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1943278543 ^ (long)-1943278377);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-209611130 ^ (long)-209611136);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1001551093 ^ (long)1001551033);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)423702827 ^ (long)423702807);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)766573295 ^ (long)766573193);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-2026925144 ^ (long)-2026925199);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1072127602 ^ (long)-1072127667);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)213071286 ^ (long)213071191);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)327036057 ^ (long)327036021);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)2015668867 ^ (long)2015668872);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-645199903 ^ (long)-645200106);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1969894204 ^ (long)1969894328);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-74770531 ^ (long)-74770626);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1600807531 ^ (long)1600807647);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1916991 ^ (long)-1917064);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)934992506 ^ (long)934992470);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1033507614 ^ (long)-1033507597);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-592993309 ^ (long)-592993405);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-481793130 ^ (long)-481793187);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)224058792 ^ (long)224058643);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1928884590 ^ (long)-1928884664);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1949830161 ^ (long)1949830261);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1492092292 ^ (long)1492092315);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1879195438 ^ (long)-1879195461);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-451034078 ^ (long)-451033994);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-975612566 ^ (long)-975612452);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-590443163 ^ (long)-590443113);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)993931458 ^ (long)993931275);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1892343170 ^ (long)1892343174);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)451860277 ^ (long)451860224);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1683844396 ^ (long)-1683844445);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1303618002 ^ (long)1303617840);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1568301587 ^ (long)1568301657);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)797831711 ^ (long)797831855);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)293006571 ^ (long)293006406);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1169047570 ^ (long)1169047575);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1744684785 ^ (long)1744684718);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-401686970 ^ (long)-401686840);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)741854341 ^ (long)741854414);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-138690632 ^ (long)-138690809);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-943199631 ^ (long)-943199502);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-482614325 ^ (long)-482614383);
                    if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1979740204 ^ (long)1979740197);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)383200431 ^ (long)383200336)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1121658454 ^ (long)1121704361)) >>> (int)((long)1072379513 ^ (long)1072379505)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1272565592 ^ (long)1272565592);
            if (!63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1424185585 ^ (long)-1424185587);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-829168133 ^ (long)-829168136) | var5_6 << (int)((long)-593595475 ^ (long)-593595480)) ^ var3_4[var7_8]) & (int)((long)-1225269800 ^ (long)-1225269977);
                    if (63.\u2000\u2002\u2002\u200d\u2000\u200c\u2007) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1198214570 ^ (long)1198214569) | var6_7 << (int)((long)-597773963 ^ (long)-597773968)) ^ var3_4[var7_8]) & (int)((long)-17059663 ^ (long)-17059762);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            63.b[var2_3] = new String(var3_4).intern();
        }
        return 63.b[var2_3];
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     */
    @Override
    public final void 4(dfm dfm2, dku dku2) {
        int n;
        int n2;
        block34: {
            void var11_29;
            void var11_23;
            String string;
            String string2;
            String string3;
            String string4;
            String string5;
            block36: {
                block35: {
                    int n3;
                    double d2;
                    dzm dzm2;
                    7N n4;
                    String[] stringArray;
                    block33: {
                        block31: {
                            block32: {
                                block30: {
                                    boolean bl = \u2000\u2002\u2002\u200d\u2000\u200c\u2007;
                                    if (bl) break block30;
                                    stringArray = 3e.5();
                                    if (bl || bl) break block30;
                                    n4 = 5z.4().1z.7(7N.class);
                                    if (!n4.7a.2) break block31;
                                    if (!bl) break block32;
                                }
                                return;
                            }
                            dzm2 = 3.aa();
                            if (\u2000\u2002\u2002\u200d\u2000\u200c\u2007) {
                                throw null;
                            }
                            break block33;
                        }
                        dzm2 = 63.3.s;
                    }
                    8S s = ((2)dzm2).getPos();
                    if (63.3.s.l.Y() == brx.h) {
                        d2 = 8.0;
                        if (\u2000\u2002\u2002\u200d\u2000\u200c\u2007) {
                            throw null;
                        }
                    } else {
                        d2 = 0.125;
                    }
                    double d3 = d2;
                    n2 = (int)((long)244129384 ^ (long)244129384);
                    n = (int)((long)861178950 ^ (long)861178950);
                    string5 = ((String)n4.6.0()).toLowerCase();
                    int n5 = (int)((long)1387132153 ^ (long)-1387132154);
                    switch (string5.hashCode()) {
                        case 3322014: {
                            if (!string5.equals(63.a((int)((long)311643360 ^ (long)-311655985), (int)((long)-982678169 ^ (long)982673457)) /* "list" */)) break;
                            int n6 = (int)((long)508875346 ^ (long)508875346);
                            if (stringArray == null) break;
                        }
                        case -1183997287: {
                            if (!string5.equals(63.a((int)((long)1431791339 ^ (long)-1431786530), (int)((long)-984428177 ^ (long)-984447700)) /* "inline" */)) break;
                            n3 = (int)((long)1293558685 ^ (long)1293558684);
                            break;
                        }
                    }
                    switch (n3) {
                        case 0: {
                            void var11_18;
                            string4 = 63.a((int)((long)2089903543 ^ (long)-2089899885), (int)((long)-885316421 ^ (long)885297576)) /* "X: " */ + k.p + 63.5(s.9);
                            string3 = 63.a((int)((long)-2068558305 ^ (long)2068546360), (int)((long)2079339039 ^ (long)-2079351266)) /* "Y: " */ + k.p + 63.5(s.1);
                            String string6 = 63.a((int)((long)1939270968 ^ (long)-1939267567), (int)((long)-358373522 ^ (long)-358364391)) /* "Z: " */ + k.p + 63.5(s.2);
                            if (63.9()) {
                                Object[] objectArray = new Object[(int)((long)-974500483 ^ (long)-974500484)];
                                objectArray[(int)((long)155149270 ^ (long)155149270)] = 63.5(s.9 * d3);
                                string4 = string4 + String.format(63.a((int)((long)-1423045225 ^ (long)1423032502), (int)((long)-1021794918 ^ (long)-1021802239)), objectArray);
                                Object[] objectArray2 = new Object[(int)((long)-457786415 ^ (long)-457786416)];
                                objectArray2[(int)((long)1983767689 ^ (long)1983767689)] = 63.5(s.2 * d3);
                                String string7 = string6 + String.format(63.a((int)((long)1746269351 ^ (long)-1746257529), (int)((long)1842183793 ^ (long)-1842170289)) /* " (%s)" */, objectArray2);
                            }
                            n2 = Math.max((int)((long)815496293 ^ (long)815496293), this.2(dfm2, dku2, string4, 0.0f, 0.0f, (int)((long)458643220 ^ (long)-466291248)));
                            n = (int)((long)-951287841 ^ (long)-951287841) + (((AccessorFontRenderer)dku2).getFontHeight() + (int)((long)1750693714 ^ (long)1750693712));
                            n2 = Math.max(n2, this.2(dfm2, dku2, string3, 0.0f, n, (int)((long)-756306104 ^ (long)763956620)));
                            n2 = Math.max(n2, this.2(dfm2, dku2, (String)var11_18, 0.0f, n += ((AccessorFontRenderer)dku2).getFontHeight() + (int)((long)933806859 ^ (long)933806857), (int)((long)-732852994 ^ (long)724774458)));
                            n += ((AccessorFontRenderer)dku2).getFontHeight();
                            if (!\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                            throw null;
                        }
                        case 1: {
                            String string8;
                            string4 = 63.a((int)((long)1646337456 ^ (long)-1646341988), (int)((long)597661413 ^ (long)597668987)) /* "%s" */ + k.p + 63.a((int)((long)-1694918190 ^ (long)1694913784), (int)((long)572399336 ^ (long)572393373)) /* " %s, %s, %s" */;
                            string3 = 63.a((int)((long)-2056417526 ^ (long)2056405551), (int)((long)1871794911 ^ (long)1871788999)) /* "XYZ" */;
                            Object[] objectArray = new Object[(int)((long)-1221368157 ^ (long)-1221368153)];
                            objectArray[(int)((long)1365612600 ^ (long)1365612600)] = string3;
                            objectArray[(int)((long)364416840 ^ (long)364416841)] = 63.5(s.9);
                            objectArray[(int)((long)-1754319561 ^ (long)-1754319563)] = 63.5(s.1);
                            objectArray[(int)((long)1994278988 ^ (long)1994278991)] = 63.5(s.2);
                            String string9 = String.format(string4, objectArray);
                            n2 = Math.max((int)((long)-1381229034 ^ (long)-1381229034), this.2(dfm2, dku2, string9, 0.0f, 0.0f, (int)((long)207224847 ^ (long)-214392117)));
                            n = (int)((long)-1387768278 ^ (long)-1387768278) + ((AccessorFontRenderer)dku2).getFontHeight();
                            if (!63.9()) break;
                            n += 2;
                            if (63.3.s.l.Y() == brx.h) {
                                string8 = 63.a((int)((long)1310159620 ^ (long)-1310147030), (int)((long)-1784064782 ^ (long)-1784057449)) /* "Overworld" */;
                                if (\u2000\u2002\u2002\u200d\u2000\u200c\u2007) {
                                    throw null;
                                }
                            } else {
                                string8 = 63.a((int)((long)-693548442 ^ (long)693536576), (int)((long)-394215015 ^ (long)394204160)) /* "Nether" */;
                            }
                            string2 = string8;
                            string = 63.5(s.9 * d3);
                            String string10 = 63.5(s.2 * d3);
                            Object[] objectArray3 = new Object[(int)((long)2018955741 ^ (long)2018955737)];
                            objectArray3[(int)((long)-2115856698 ^ (long)-2115856698)] = string2;
                            objectArray3[(int)((long)957361255 ^ (long)957361254)] = string;
                            objectArray3[(int)((long)-2042452553 ^ (long)-2042452555)] = 63.5(s.1);
                            objectArray3[(int)((long)-1909705085 ^ (long)-1909705088)] = string10;
                            String string11 = String.format(string4, objectArray3);
                            n2 = Math.max(n2, this.2(dfm2, dku2, string11, 0.0f, n, (int)((long)-526189564 ^ (long)532700864)));
                            n += ((AccessorFontRenderer)dku2).getFontHeight();
                            break;
                        }
                    }
                    if (!n4.7W.2) break block34;
                    n += 2;
                    string5 = 63.a((int)((long)1521714976 ^ (long)-1521726973), (int)((long)1023315687 ^ (long)1023323479)) /* "%s%s%s (%s, %s)" */;
                    if (!n4.7a.2 || !(3.aa() instanceof bfw)) break block35;
                    bfw bfw2 = (bfw)3.aa();
                    if (stringArray == null) break block36;
                }
                dzm dzm3 = 63.3.s;
            }
            string4 = var11_23.bZ();
            string3 = StringUtils.capitalize((String)string4.name().toLowerCase());
            string2 = 63.5(afm.g((float)var11_23.p));
            string = 63.5(afm.g((float)var11_23.q));
            switch (34b.2[string4.ordinal()]) {
                case 1: {
                    String string12 = 63.a((int)((long)1492277771 ^ (long)-1492281565), (int)((long)908680866 ^ (long)-908669406)) /* " -Z" */;
                    if (!\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 2: {
                    String string13 = 63.a((int)((long)1573508398 ^ (long)-1573513213), (int)((long)1617975654 ^ (long)1617961925)) /* " +Z" */;
                    if (!\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 3: {
                    String string14 = 63.a((int)((long)-2140889302 ^ (long)2140885512), (int)((long)-1411320425 ^ (long)-1411346884)) /* " -X" */;
                    if (!\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                case 4: {
                    String string15 = 63.a((int)((long)101525386 ^ (long)-101520735), (int)((long)-2032053842 ^ (long)-2032056400)) /* " +X" */;
                    if (!\u2000\u2002\u2002\u200d\u2000\u200c\u2007) break;
                    throw null;
                }
                default: {
                    String string16 = 2w$6X.KAOZ("", 2028333819);
                }
            }
            Object[] objectArray = new Object[(int)((long)1869218633 ^ (long)1869218636)];
            objectArray[(int)((long)-1974706745 ^ (long)-1974706745)] = string3;
            objectArray[(int)((long)912790559 ^ (long)912790558)] = k.p;
            objectArray[(int)((long)-1766423550 ^ (long)-1766423552)] = var11_29;
            objectArray[(int)((long)208056545 ^ (long)208056546)] = string2;
            objectArray[(int)((long)1551016423 ^ (long)1551016419)] = string;
            String string17 = String.format(string5, objectArray);
            n2 = Math.max(n2, this.2(dfm2, dku2, string17, 0.0f, n, (int)((long)-874380141 ^ (long)880846423)));
            n += ((AccessorFontRenderer)dku2).getFontHeight();
        }
        this.0 = n2;
        this.2 = n;
    }
}

