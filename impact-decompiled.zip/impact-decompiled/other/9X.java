/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  baritone.api.BaritoneAPI
 *  baritone.api.Settings$Setting
 *  baritone.api.event.events.ChatEvent
 *  k
 *  np
 *  np$a
 *  nr
 */
package net.impactclient;

import baritone.api.BaritoneAPI;
import baritone.api.Settings;
import baritone.api.event.events.ChatEvent;
import net.impactclient.2w$6X;
import net.impactclient.342;
import net.impactclient.3sC;
import net.impactclient.5p;
import net.impactclient.5w;
import net.impactclient.6r;
import net.impactclient.9e;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@342(a={"b", "baritone"}, b="Passthrough to ExampleBaritoneControl. See Baritone's github for usage.")
public final class 9X
extends 9e {
    private static final String[] b;
    public static final boolean \u200c;
    private static final String[] d;

    /*
     * Enabled aggressive block sorting
     */
    @6r(b={"arg1", "arg2", "arg3", "arg4", "arg5", "arg6"})
    private void 9(5w w2, String string, String string2, String string3, String string4, String string5, String string6) {
        block3: {
            block2: {
                boolean bl = \u200c;
                if (bl || bl) break block2;
                String[] stringArray = new String[(int)((long)146534460 ^ (long)146534458)];
                stringArray[(int)((long)-645743062 ^ (long)-645743062)] = string;
                stringArray[(int)((long)1633971040 ^ (long)1633971041)] = string2;
                stringArray[(int)((long)1190946862 ^ (long)1190946860)] = string3;
                stringArray[(int)((long)2061162242 ^ (long)2061162241)] = string4;
                stringArray[(int)((long)-2058939458 ^ (long)-2058939462)] = string5;
                stringArray[(int)((long)1775037775 ^ (long)1775037770)] = string6;
                9X.6(stringArray);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @6r(b={"arg1"})
    private void 4(5w w2, String string) {
        block3: {
            block2: {
                boolean bl = \u200c;
                if (bl || bl) break block2;
                String[] stringArray = new String[(int)((long)-1947748570 ^ (long)-1947748569)];
                stringArray[(int)((long)1363991791 ^ (long)1363991791)] = string;
                9X.6(stringArray);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 9X.\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)496192761 ^ (long)496182738)) & (int)((long)303931241 ^ (long)303915158);
            if (var9_2) ** GOTO lbl-1000
            if (9X.d[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 9X.b[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-667739284 ^ (long)-667739284)] & (int)((long)-2042594838 ^ (long)-2042595051)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)567214928 ^ (long)567214927);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1701529109 ^ (long)-1701529216);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-89165707 ^ (long)-89165656);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)554823517 ^ (long)554823474);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-528655214 ^ (long)-528655326);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1906719622 ^ (long)-1906719735);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1625926582 ^ (long)-1625926559);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)28493644 ^ (long)28493574);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1330709539 ^ (long)1330709521);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1483379847 ^ (long)-1483379723);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-57090538 ^ (long)-57090386);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1067648164 ^ (long)-1067648163);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-662926495 ^ (long)-662926440);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1818433810 ^ (long)-1818433869);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1743518898 ^ (long)1743518900);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)790425153 ^ (long)790425241);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1857330908 ^ (long)1857330787);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-64155315 ^ (long)-64155352);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)17100515 ^ (long)17100476);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)2001336329 ^ (long)2001336330);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-890957364 ^ (long)-890957557);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1215138448 ^ (long)-1215138367);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-783401428 ^ (long)-783401265);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-817843771 ^ (long)-817843853);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1450871060 ^ (long)-1450871126);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1676208705 ^ (long)1676208784);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)919178553 ^ (long)919178717);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-611312185 ^ (long)-611312334);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1943883698 ^ (long)1943883724);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)431637913 ^ (long)431637865);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)928705229 ^ (long)928705054);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)562890101 ^ (long)562890042);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1282637331 ^ (long)1282637341);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-709014829 ^ (long)-709014920);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-406174436 ^ (long)-406174258);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1874232732 ^ (long)-1874232683);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1790440216 ^ (long)-1790440221);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-792345627 ^ (long)-792345679);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-126507762 ^ (long)-126507737);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)456763909 ^ (long)456764138);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)2007662877 ^ (long)2007662887);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1517686116 ^ (long)1517686149);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)658135397 ^ (long)658135473);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1420811692 ^ (long)-1420811712);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)180155382 ^ (long)180155309);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1293679643 ^ (long)-1293679796);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1063854903 ^ (long)-1063854941);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-957884429 ^ (long)-957884535);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1536426375 ^ (long)1536426428);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)2115130667 ^ (long)2115130706);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)2065851974 ^ (long)2065852152);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1634959281 ^ (long)-1634959349);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1090155031 ^ (long)-1090155048);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1627108122 ^ (long)-1627108320);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1227436849 ^ (long)-1227436992);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1098121029 ^ (long)1098121031);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1798579760 ^ (long)1798579827);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1912738006 ^ (long)-1912737862);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)570594927 ^ (long)570594851);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-339338412 ^ (long)-339338367);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1646841374 ^ (long)-1646841509);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1861786537 ^ (long)-1861786569);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)2076802498 ^ (long)2076802559);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-303611943 ^ (long)-303611938);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1635071602 ^ (long)1635071660);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-641185131 ^ (long)-641185153);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)2082098609 ^ (long)2082098460);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-169743124 ^ (long)-169743128);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-442083588 ^ (long)-442083704);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-2069687362 ^ (long)-2069687394);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1863529959 ^ (long)-1863529930);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-2129755351 ^ (long)-2129755295);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1664002975 ^ (long)1664002925);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1504560896 ^ (long)1504561114);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1330056851 ^ (long)1330056846);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1836114857 ^ (long)-1836114704);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-570565502 ^ (long)-570565484);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-276376110 ^ (long)-276376139);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)217191357 ^ (long)217191185);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1048543713 ^ (long)-1048543639);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1766123768 ^ (long)1766123609);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-2113462117 ^ (long)-2113462098);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-868613565 ^ (long)-868613493);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1147247306 ^ (long)1147247357);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)769963970 ^ (long)769963846);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-215046975 ^ (long)-215047110);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)502701412 ^ (long)502701503);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)519196929 ^ (long)519197059);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1434608241 ^ (long)-1434608196);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1126008433 ^ (long)-1126008534);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)744435252 ^ (long)744435426);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1779775259 ^ (long)1779775244);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)763101915 ^ (long)763101809);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-718829667 ^ (long)-718829631);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1439358342 ^ (long)-1439358451);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1112014139 ^ (long)1112014103);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)2041584232 ^ (long)2041584260);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1790177226 ^ (long)-1790177148);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-189907418 ^ (long)-189907283);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)2044464936 ^ (long)2044465098);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1979098977 ^ (long)1979099115);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)916091946 ^ (long)916092147);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1515784653 ^ (long)-1515784646);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)219068002 ^ (long)219068127);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1798616670 ^ (long)1798616718);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1269970077 ^ (long)-1269970085);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-170813473 ^ (long)-170813679);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)34841852 ^ (long)34841740);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1168040543 ^ (long)1168040579);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1335211323 ^ (long)-1335211477);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1548010113 ^ (long)-1548010123);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1414428370 ^ (long)1414428353);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)985906035 ^ (long)985906072);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1898802550 ^ (long)1898802524);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1025340104 ^ (long)-1025340152);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-983154168 ^ (long)-983154006);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1100905311 ^ (long)1100905360);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1500610603 ^ (long)-1500610647);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1134188734 ^ (long)-1134188745);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1784606303 ^ (long)-1784606364);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1429297743 ^ (long)1429297907);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-991307344 ^ (long)-991307435);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-767418277 ^ (long)-767418149);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-280870729 ^ (long)-280870682);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1741526374 ^ (long)-1741526470);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)478133142 ^ (long)478133100);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1047432753 ^ (long)-1047432947);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-612637988 ^ (long)-612637984);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-2130164341 ^ (long)-2130164311);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1483041184 ^ (long)1483041261);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-19130228 ^ (long)-19130184);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1395433098 ^ (long)1395433090);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1830246180 ^ (long)-1830246196);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-2025337860 ^ (long)-2025337931);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1298488260 ^ (long)-1298488219);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1619571073 ^ (long)1619570994);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1658021692 ^ (long)1658021703);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1047317268 ^ (long)-1047317362);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1014911257 ^ (long)1014911391);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-929538795 ^ (long)-929538676);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-175142057 ^ (long)-175141996);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1725242080 ^ (long)1725242098);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1891404755 ^ (long)1891404673);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-392805075 ^ (long)-392805005);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1945041386 ^ (long)1945041272);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1380493650 ^ (long)1380493619);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)757845967 ^ (long)757845830);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-593365260 ^ (long)-593365256);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1957899038 ^ (long)1957899138);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-544837234 ^ (long)-544837221);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)914560200 ^ (long)914560048);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1596109319 ^ (long)1596109556);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1769829506 ^ (long)-1769829479);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1032044919 ^ (long)-1032044916);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1292292199 ^ (long)1292292164);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1971965173 ^ (long)-1971965011);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1758228444 ^ (long)1758228466);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-380839533 ^ (long)-380839515);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1771252416 ^ (long)-1771252469);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-971687013 ^ (long)-971687138);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)795519535 ^ (long)795519627);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-762986839 ^ (long)-762986913);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-352766888 ^ (long)-352766781);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1784792703 ^ (long)1784792735);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)2027493051 ^ (long)2027492982);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-287793922 ^ (long)-287793957);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1165452536 ^ (long)1165452463);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-131440600 ^ (long)-131440475);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)2072966049 ^ (long)2072966060);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-771334384 ^ (long)-771334331);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)729117829 ^ (long)729117910);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)718182294 ^ (long)718182153);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)954809763 ^ (long)954809694);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1507718713 ^ (long)1507718833);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1620500748 ^ (long)1620500776);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1269491216 ^ (long)-1269491396);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1137582281 ^ (long)-1137582245);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1776316052 ^ (long)1776316122);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1192277541 ^ (long)-1192277733);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1114153146 ^ (long)1114153083);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)2052825646 ^ (long)2052825791);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1740660748 ^ (long)1740660847);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)218095168 ^ (long)218095213);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-762257590 ^ (long)-762257638);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1718202636 ^ (long)1718202866);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-2088938603 ^ (long)-2088938504);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)135541100 ^ (long)135541242);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1698461485 ^ (long)-1698461513);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1437302735 ^ (long)-1437302776);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1158650484 ^ (long)-1158650553);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1485764232 ^ (long)-1485764209);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-472023517 ^ (long)-472023496);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1545043362 ^ (long)-1545043233);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1831005325 ^ (long)1831005356);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1042171158 ^ (long)-1042171214);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-686593540 ^ (long)-686593766);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1606198458 ^ (long)1606198418);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-625763507 ^ (long)-625763346);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1503505815 ^ (long)-1503505670);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-227972151 ^ (long)-227972278);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)762035698 ^ (long)762035557);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1619743562 ^ (long)1619743499);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)945995566 ^ (long)945995738);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1961578594 ^ (long)1961578709);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1029316195 ^ (long)-1029316311);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-302524546 ^ (long)-302524432);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1930060154 ^ (long)1930060093);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)198326889 ^ (long)198326804);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1558956261 ^ (long)1558956261);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)256518358 ^ (long)256518203);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1950580518 ^ (long)1950580658);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-271499477 ^ (long)-271499469);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)53063061 ^ (long)53063049);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)994306041 ^ (long)994305990);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1751601032 ^ (long)-1751601050);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1889308232 ^ (long)-1889308163);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)26079923 ^ (long)26079773);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-238527540 ^ (long)-238527625);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-984344848 ^ (long)-984345031);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-941421741 ^ (long)-941421780);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1913680667 ^ (long)1913680774);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1968057115 ^ (long)-1968057213);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-87440798 ^ (long)-87440707);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1932577361 ^ (long)-1932577391);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)840247108 ^ (long)840247187);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-545679969 ^ (long)-545679881);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1472693142 ^ (long)-1472693025);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)654660051 ^ (long)654659963);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-155121637 ^ (long)-155121484);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-572557908 ^ (long)-572557978);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)530488374 ^ (long)530488436);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1663438704 ^ (long)1663438745);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1267309219 ^ (long)1267309301);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1311225534 ^ (long)-1311225517);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1602182755 ^ (long)-1602182823);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)126298948 ^ (long)126298933);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1191145680 ^ (long)-1191145656);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)815460149 ^ (long)815460188);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-2042790129 ^ (long)-2042790019);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)517816515 ^ (long)517816409);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1042345217 ^ (long)-1042345366);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)784793633 ^ (long)784793679);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1231247489 ^ (long)1231247485);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-127846381 ^ (long)-127846149);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1990712442 ^ (long)-1990712455);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)2105187627 ^ (long)2105187597);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1393724065 ^ (long)1393724088);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)385549154 ^ (long)385549306);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1873519575 ^ (long)1873519440);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1568403794 ^ (long)1568403916);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1917415533 ^ (long)-1917415639);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-465201299 ^ (long)-465201289);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-2121967714 ^ (long)-2121967676);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)857633579 ^ (long)857633572);
                    if (!9X.\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1697602054 ^ (long)1697602081);
                    if (!9X.\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1216886647 ^ (long)-1216886583);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1957784847 ^ (long)1957785072)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1396734164 ^ (long)-1396737837)) >>> (int)((long)1390183193 ^ (long)1390183185)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-2012326606 ^ (long)-2012326606);
            if (!9X.\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)304626902 ^ (long)304626900);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-731145841 ^ (long)-731145844) | var5_6 << (int)((long)112160001 ^ (long)112160004)) ^ var3_4[var7_8]) & (int)((long)-56225874 ^ (long)-56225967);
                    if (9X.\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1805526713 ^ (long)1805526714) | var6_7 << (int)((long)-899867736 ^ (long)-899867731)) ^ var3_4[var7_8]) & (int)((long)1563608257 ^ (long)1563608126);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            9X.d[var2_3] = new String(var3_4).intern();
        }
        return 9X.d[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void 6(String ... stringArray) {
        block4: {
            block2: {
                boolean bl;
                boolean bl2;
                block3: {
                    bl2 = \u200c;
                    if (bl2 || bl2) break block2;
                    Settings.Setting setting = BaritoneAPI.getSettings().chatControl;
                    bl = (Boolean)setting.value;
                    if (bl2 || bl2) break block2;
                    setting.value = Boolean.TRUE;
                    if (bl2 || bl2) break block2;
                    ChatEvent chatEvent = new ChatEvent(String.join((CharSequence)2w$6X.KAOZ("\uaeab", 2140703200), stringArray));
                    if (bl2 || bl2) break block2;
                    BaritoneAPI.getProvider().getPrimaryBaritone().getGameEventHandler().onSendChatMessage(chatEvent);
                    if (bl2 || bl2) break block2;
                    if (chatEvent.isCancelled()) break block3;
                    if (bl2) break block2;
                    if (stringArray[(int)((long)-828076770 ^ (long)-828076770)].equals(9X.b((int)((long)-1867557727 ^ (long)-1867563637), (int)((long)1204407707 ^ (long)-1204401329)) /* "damn" */)) break block3;
                    if (bl2 || bl2) break block2;
                    k[] kArray = new k[(int)((long)772686724 ^ (long)772686725)];
                    kArray[(int)((long)527632324 ^ (long)527632324)] = k.h;
                    stringArray = kArray;
                    k[] kArray2 = new k[(int)((long)1099308752 ^ (long)1099308754)];
                    kArray2[(int)((long)254350854 ^ (long)254350854)] = k.t;
                    kArray2[(int)((long)-1571158141 ^ (long)-1571158142)] = k.j;
                    5p.9((nr)new 3sC().2((String)9X.b((int)((int)((long)-1606740957 ^ (long)-1606714102)), (int)((int)((long)-1279522848 ^ (long)1279523778))), null, (k[])stringArray).2((String)9X.b((int)((int)((long)1151752875 ^ (long)1151742848)), (int)((int)((long)-162353020 ^ (long)-162355585))), (np)new np((np.a)np.a.a, (String)9X.b((int)((int)((long)-1722879076 ^ (long)-1722901836)), (int)((int)((long)-1760028248 ^ (long)-1760007557)))), (k[])kArray2).7);
                    if (bl2) break block2;
                }
                if (bl2) break block2;
                setting.value = bl;
                if (!bl2 && !bl2) break block4;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @6r(b={"arg1", "arg2"})
    private void 5(5w w2, String string, String string2) {
        block3: {
            block2: {
                boolean bl = \u200c;
                if (bl || bl) break block2;
                String[] stringArray = new String[(int)((long)2048113709 ^ (long)2048113711)];
                stringArray[(int)((long)-1740797183 ^ (long)-1740797183)] = string;
                stringArray[(int)((long)1696672924 ^ (long)1696672925)] = string2;
                9X.6(stringArray);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @6r(b={"arg1", "arg2", "arg3"})
    private void 2(5w w2, String string, String string2, String string3) {
        block3: {
            block2: {
                boolean bl = \u200c;
                if (bl || bl) break block2;
                String[] stringArray = new String[(int)((long)-244912272 ^ (long)-244912269)];
                stringArray[(int)((long)1535853941 ^ (long)1535853941)] = string;
                stringArray[(int)((long)1450734198 ^ (long)1450734199)] = string2;
                stringArray[(int)((long)-1591456410 ^ (long)-1591456412)] = string3;
                9X.6(stringArray);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @6r(b={"arg1", "arg2", "arg3", "arg4", "arg5"})
    private void 1(5w w2, String string, String string2, String string3, String string4, String string5) {
        block3: {
            block2: {
                boolean bl = \u200c;
                if (bl || bl) break block2;
                String[] stringArray = new String[(int)((long)-2062388864 ^ (long)-2062388859)];
                stringArray[(int)((long)-1837142754 ^ (long)-1837142754)] = string;
                stringArray[(int)((long)475535069 ^ (long)475535068)] = string2;
                stringArray[(int)((long)1707301491 ^ (long)1707301489)] = string3;
                stringArray[(int)((long)-1803693312 ^ (long)-1803693309)] = string4;
                stringArray[(int)((long)-1138719641 ^ (long)-1138719645)] = string5;
                9X.6(stringArray);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @6r(b={"arg1", "arg2", "arg3", "arg4"})
    private void 5(5w w2, String string, String string2, String string3, String string4) {
        block3: {
            block2: {
                boolean bl = \u200c;
                if (bl || bl) break block2;
                String[] stringArray = new String[(int)((long)1324874954 ^ (long)1324874958)];
                stringArray[(int)((long)1566283177 ^ (long)1566283177)] = string;
                stringArray[(int)((long)-2069227241 ^ (long)-2069227242)] = string2;
                stringArray[(int)((long)-1093643792 ^ (long)-1093643790)] = string3;
                stringArray[(int)((long)1805447789 ^ (long)1805447790)] = string4;
                9X.6(stringArray);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 9X() {
        boolean bl = \u200c;
        if (bl) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 9X.\u200c;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1976480768 ^ (long)1976480772)];
            if (var7) break block23;
            var3_2 = (int)((long)1845163889 ^ (long)1845163889);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ua660\u8fb4\u9c73\u94b3\ua620\u8fb5\u9c8a\u94b7\ua637\u8f9e\u9cc0", 574980411);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1410495520 ^ (long)1410495526);
            if (var7) break block23;
            var0_6 = (int)((long)535142778 ^ (long)-535142779);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1944515097 ^ (long)-1944515105);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-501915738 ^ (long)501915737);
                    if (9X.\u200c) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!9X.\u200c) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u99c9\ub097\ua37e\uabec\u992f\ub0ac\ua3ec\uabcd\u996d\ub0fc\ua30a\uaba0\u99da\ub053\ua326\uab2f\u99c6\ub069\ua3a3\uabb6\u9921\ub0ae\ua3e6\uab40\u99e1\ub02c\ua32b\uab22\u99d2\ub0fb\ua34e\uabc2\u9990\ub098\ua3d3\uabf2\u9902\ub0af\ua35d\uaba4\u996d\ub014\ua301\uabb7\u99ce\ub035\ua3c0\uab7d\u9937\ub0bc\ua30a\uab8d\u99dc\ub0bf\ua3db\uaba1\u99c6\ub065\ua366\uabc2\u992a\ub0e3\ua34a\uab4d\u999f\ub06b\ua316\uab42\u9912\ub093\ua3de\uaba1\u99f9\ub000\ua35d\uab3f\u9976\ub00a\ua32f\uab7a\u9925\ub067\ua35e\uab6c\u99db\ub0d0\ua3dc\uabb2\u9937\ub0c2\ua3bd\uabe3\u99af\ub03a\ua348\uab66\u99f6\ub0c6\ua3d6\uabd0\u99db\ub0a5\ua35c\uab50\u99c0\ub00c\ua368\uaba0\u9998\ub09c", -1190871434);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)1240709823 ^ (long)1240709772);
                            var0_6 = (int)((long)848034343 ^ (long)-848034344);
                            while (true) {
                                v0 = (int)((long)-1271587578 ^ (long)-1271587484);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1281576224 ^ (long)1281576224);
                                if (!9X.\u200c) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!9X.\u200c) ** continue;
                                throw null;
                            }
                            9X.b = var5_1;
                            9X.d = new String[(int)((long)-2041437193 ^ (long)-2041437197)];
                            if (!9X.\u200c) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)760782420 ^ (long)760782420);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-3854233 ^ (long)-3854234)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)522890035 ^ (long)522890036)) {
                                case 0: {
                                    v15 = (int)((long)305558243 ^ (long)305558163);
                                    if (!9X.\u200c) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)700864270 ^ (long)700864291);
                                    if (!9X.\u200c) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)216823252 ^ (long)216823237);
                                    if (!9X.\u200c) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1296560735 ^ (long)1296560708);
                                    if (!9X.\u200c) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-223448184 ^ (long)-223448107);
                                    if (!9X.\u200c) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1799688448 ^ (long)-1799688335);
                                    if (!9X.\u200c) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)38977615 ^ (long)38977574);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!9X.\u200c);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

