/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.07;
import net.impactclient.1A;
import net.impactclient.2w$6X;
import net.impactclient.34e;
import net.impactclient.4f;
import net.impactclient.4m;
import net.impactclient.7m;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 1k
extends 7m<07> {
    private 1A 8;
    private 1A 7;
    public static final boolean \u200e\u2000\u2005\u200f\u2007;
    @EventHandler
    private final Listener<4f> 0;
    private static final String[] b;
    private static final String[] a;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 1k.\u200e\u2000\u2005\u200f\u2007;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1167605013 ^ (long)1167605010)];
            if (var7) break block23;
            var3_2 = (int)((long)-82400189 ^ (long)-82400189);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\uf196\ud972\uca61\uc2fb\uf144\ud9d0\uca19\uc265\uf1bc\ud9b9\uca7f\uc271\uf1d8\ud9be\ucaa2\uc2d1\uf10f\ud983\uca49\uc2ec\uf1dd\ud97e\uca59\uc277\uf1d7\ud930\ucab4\uc2e5\uf19c\ud957\ucafa\uc2b7\uf15d\ud953\uca5c\uc283\uf1eb\ud99d\ucae1\uc280\uf17d\ud90f\uca73\uc2c7\uf1f0\ud9f3\uca70\uc2ab\uf17c\ud950\uca00\uc299\uf14c\ud921\uca2b\uc238\uf11c\ud98f\uca4d\uc284\uf15a", -1493772292);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-443437702 ^ (long)-443437733);
            if (var7) break block23;
            var0_6 = (int)((long)1092244792 ^ (long)-1092244793);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)914928277 ^ (long)914928257);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)496609860 ^ (long)-496609861);
                    if (1k.\u200e\u2000\u2005\u200f\u2007) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!1k.\u200e\u2000\u2005\u200f\u2007) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u2476\u0c99\u1f2e\u17d5\u24fe\u0c46\u1f1d\u17e4\u246f\u0cda\u1f56\u174e\u24ae\u0c0a\u1f3f\u1714\u24ef\u0c68\u1f06\u17c2\u2467\u0ce8\u1f5d\u17f6\u2404\u0c56\u1f8b\u17cf\u24fa\u0c58\u1fa9\u1778\u24fd\u0cdb\u1fd5\u1729\u24a5\u0c1e\u1f45", 1693450877);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1771108113 ^ (long)-1771108145);
                            var0_6 = (int)((long)226944454 ^ (long)-226944455);
                            while (true) {
                                v0 = (int)((long)2004060263 ^ (long)2004060245);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-575433896 ^ (long)-575433896);
                                if (!1k.\u200e\u2000\u2005\u200f\u2007) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!1k.\u200e\u2000\u2005\u200f\u2007) ** continue;
                                throw null;
                            }
                            1k.a = var5_1;
                            1k.b = new String[(int)((long)-1123721169 ^ (long)-1123721176)];
                            if (!1k.\u200e\u2000\u2005\u200f\u2007) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-948342396 ^ (long)-948342396);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-386779822 ^ (long)-386779821)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1705251181 ^ (long)-1705251180)) {
                                case 0: {
                                    v15 = (int)((long)-497764411 ^ (long)-497764470);
                                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)561276460 ^ (long)561276432);
                                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)458023312 ^ (long)458023393);
                                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1507568150 ^ (long)-1507568228);
                                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)820831594 ^ (long)820831571);
                                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1892393627 ^ (long)1892393674);
                                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1544941572 ^ (long)1544941658);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!1k.\u200e\u2000\u2005\u200f\u2007);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 1k.\u200e\u2000\u2005\u200f\u2007;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1872400634 ^ (long)1872427287)) & (int)((long)1704070230 ^ (long)1704129449);
            if (var9_2) ** GOTO lbl-1000
            if (1k.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 1k.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)2063895088 ^ (long)2063895088)] & (int)((long)1366151785 ^ (long)1366151830)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1650883144 ^ (long)-1650883079);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1702567538 ^ (long)-1702567670);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1422379042 ^ (long)1422379192);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1720803239 ^ (long)-1720803083);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1619353102 ^ (long)1619353195);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)247777335 ^ (long)247777420);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1647914045 ^ (long)-1647914094);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1254710317 ^ (long)1254710502);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1290518023 ^ (long)-1290518197);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-135249593 ^ (long)-135249593);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-2016016232 ^ (long)-2016016195);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1212175115 ^ (long)1212175184);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1812972320 ^ (long)1812972537);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-912918582 ^ (long)-912918685);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-900113804 ^ (long)-900113773);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1328698920 ^ (long)-1328699109);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1837194045 ^ (long)-1837194006);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)442487481 ^ (long)442487330);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-91994123 ^ (long)-91994202);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1159115263 ^ (long)-1159115247);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-903163559 ^ (long)-903163486);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-632806620 ^ (long)-632806511);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1915173982 ^ (long)1915174103);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1733253509 ^ (long)-1733253421);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)521592937 ^ (long)521592881);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1300267601 ^ (long)1300267628);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1297968934 ^ (long)1297969037);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1083274346 ^ (long)1083274390);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)228624305 ^ (long)228624306);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-688196024 ^ (long)-688196043);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-2089668193 ^ (long)-2089668231);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1240684752 ^ (long)1240684688);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1822713394 ^ (long)1822713448);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1971269156 ^ (long)-1971269236);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1248979106 ^ (long)1248979110);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1385336895 ^ (long)1385336839);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1613522183 ^ (long)1613522404);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-947510339 ^ (long)-947510470);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-269116718 ^ (long)-269116912);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1235311339 ^ (long)1235311270);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1874758303 ^ (long)-1874758263);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1361085767 ^ (long)-1361085697);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-460700141 ^ (long)-460700048);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1427614581 ^ (long)1427614600);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1485110774 ^ (long)-1485110720);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1198417086 ^ (long)-1198416899);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1924070852 ^ (long)1924070694);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1932054451 ^ (long)1932054452);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)255473909 ^ (long)255473751);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-2087038867 ^ (long)-2087038899);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1769511129 ^ (long)1769510941);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)431429320 ^ (long)431429310);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1248371063 ^ (long)-1248371189);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1929190630 ^ (long)-1929190522);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-355317281 ^ (long)-355317370);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1488480940 ^ (long)1488480989);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1266534139 ^ (long)1266534093);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)544202664 ^ (long)544202521);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1915163534 ^ (long)1915163427);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1629928087 ^ (long)-1629928094);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1449557193 ^ (long)-1449557012);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-90592707 ^ (long)-90592678);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1529745645 ^ (long)1529745605);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1006792494 ^ (long)1006792530);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1244069884 ^ (long)-1244069735);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)842658395 ^ (long)842658309);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-935815019 ^ (long)-935815115);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)642065174 ^ (long)642065266);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-822915628 ^ (long)-822915807);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-2097747708 ^ (long)-2097747642);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-869416768 ^ (long)-869416886);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)749180912 ^ (long)749180775);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)673892277 ^ (long)673892301);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)820485225 ^ (long)820485338);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-386525210 ^ (long)-386525359);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)197757046 ^ (long)197757055);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)736612985 ^ (long)736612881);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1684567979 ^ (long)-1684568042);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1582516987 ^ (long)1582516741);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1980131398 ^ (long)1980131520);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-164346594 ^ (long)-164346388);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1466860402 ^ (long)1466860299);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1840521888 ^ (long)1840521881);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1087256934 ^ (long)-1087256874);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1135054440 ^ (long)-1135054520);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-50034319 ^ (long)-50034354);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1412043207 ^ (long)1412043056);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-436913810 ^ (long)-436913883);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1303842451 ^ (long)1303842552);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1676280637 ^ (long)-1676280682);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1891146867 ^ (long)-1891146825);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-2060477856 ^ (long)-2060477942);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1780036117 ^ (long)1780036130);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)782809129 ^ (long)782809103);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-386208630 ^ (long)-386208574);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)844037402 ^ (long)844037459);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)310939813 ^ (long)310939847);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1871008888 ^ (long)1871008933);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1023176206 ^ (long)1023176208);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1799931572 ^ (long)1799931494);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)953142639 ^ (long)953142624);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-433068666 ^ (long)-433068725);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1939038636 ^ (long)-1939038630);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1404195152 ^ (long)-1404195217);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-466851564 ^ (long)-466851569);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1210949735 ^ (long)-1210949834);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)459917444 ^ (long)459917418);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)827457468 ^ (long)827457363);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-2080629695 ^ (long)-2080629666);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1269228447 ^ (long)-1269228445);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)275538608 ^ (long)275538522);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1344691784 ^ (long)1344691834);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1146753227 ^ (long)1146753201);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1947732965 ^ (long)1947732779);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1151250688 ^ (long)-1151250547);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)678733476 ^ (long)678733424);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-161489986 ^ (long)-161490162);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1597201690 ^ (long)1597201716);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-501700215 ^ (long)-501700231);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1374390901 ^ (long)-1374390948);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)572042288 ^ (long)572042259);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)2130519707 ^ (long)2130519614);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)86810375 ^ (long)86810492);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-2073582291 ^ (long)-2073582095);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1847099925 ^ (long)1847100149);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1634447023 ^ (long)-1634446898);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)265187742 ^ (long)265187601);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-295237833 ^ (long)-295237817);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1766776342 ^ (long)1766776544);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)420320512 ^ (long)420320640);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1575678617 ^ (long)1575678606);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1535187233 ^ (long)1535187203);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1995213127 ^ (long)-1995213165);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)725080065 ^ (long)725080298);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-741628225 ^ (long)-741628345);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-552119256 ^ (long)-552119259);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-68814617 ^ (long)-68814702);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1172557768 ^ (long)1172557742);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1514730616 ^ (long)-1514730564);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)232111289 ^ (long)232111350);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)83947154 ^ (long)83947025);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-2140895330 ^ (long)-2140895354);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)114293937 ^ (long)114293914);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-87465062 ^ (long)-87465143);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)876693575 ^ (long)876693585);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1823937526 ^ (long)-1823937360);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1786645046 ^ (long)-1786645097);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)628242877 ^ (long)628242724);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1285598407 ^ (long)-1285598404);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1228495748 ^ (long)-1228495853);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)693496618 ^ (long)693496644);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-906651744 ^ (long)-906651775);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)687065435 ^ (long)687065574);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-935587102 ^ (long)-935587171);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1168375388 ^ (long)1168375426);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-383382701 ^ (long)-383382699);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1885429940 ^ (long)-1885429983);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1310118747 ^ (long)-1310118861);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)810049404 ^ (long)810049516);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1160398912 ^ (long)-1160398943);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-873206216 ^ (long)-873206083);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1424340755 ^ (long)1424340921);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-2035475259 ^ (long)-2035475372);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1885913798 ^ (long)-1885913754);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1414950627 ^ (long)1414950604);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1213199774 ^ (long)1213199634);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-155195754 ^ (long)-155195737);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)584507633 ^ (long)584507394);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-800448306 ^ (long)-800448302);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1715974836 ^ (long)-1715974662);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1263973560 ^ (long)-1263973489);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1557333515 ^ (long)-1557333583);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1884128156 ^ (long)1884128073);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)2111509007 ^ (long)2111509219);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)2128460823 ^ (long)2128461021);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)162113249 ^ (long)162113029);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1375555673 ^ (long)-1375555802);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)807855576 ^ (long)807855443);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)576559958 ^ (long)576559881);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)114362775 ^ (long)114362627);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-971364108 ^ (long)-971364123);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)844359912 ^ (long)844359766);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1372012165 ^ (long)1372012261);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)955867624 ^ (long)955867599);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-2065507314 ^ (long)-2065507122);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1538483380 ^ (long)-1538483318);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)918856942 ^ (long)918856943);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)764436175 ^ (long)764436167);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-210071148 ^ (long)-210071252);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1617121325 ^ (long)1617121386);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1873327735 ^ (long)-1873327754);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)292804733 ^ (long)292804786);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-187149307 ^ (long)-187149149);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-492342998 ^ (long)-492342903);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)458795026 ^ (long)458795054);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-968963749 ^ (long)-968963694);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)508822045 ^ (long)508822121);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1943677217 ^ (long)-1943677238);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-9068552 ^ (long)-9068688);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1242734636 ^ (long)-1242734600);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1155263989 ^ (long)1155263791);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1884288307 ^ (long)-1884288500);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1565052328 ^ (long)1565052353);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-902706385 ^ (long)-902706344);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1606997567 ^ (long)1606997608);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)944418332 ^ (long)944418521);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-491415485 ^ (long)-491415442);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-241783156 ^ (long)-241783102);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1076016223 ^ (long)-1076016272);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1107941991 ^ (long)1107942045);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1892936803 ^ (long)-1892936885);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)958868519 ^ (long)958868635);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1799349265 ^ (long)-1799349275);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1908261780 ^ (long)1908261664);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)813576772 ^ (long)813576800);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-293666364 ^ (long)-293666431);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1616650142 ^ (long)-1616650117);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1133487589 ^ (long)-1133487374);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-831612174 ^ (long)-831612191);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)693338039 ^ (long)693337996);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1657235688 ^ (long)1657235579);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)100395398 ^ (long)100395283);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)2121037182 ^ (long)2121037056);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1397935589 ^ (long)1397935593);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-2053432627 ^ (long)-2053432615);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-305904501 ^ (long)-305904495);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)90303288 ^ (long)90303274);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-308711276 ^ (long)-308711376);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1988860129 ^ (long)-1988859930);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1269198944 ^ (long)-1269199048);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-356781838 ^ (long)-356781997);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1735010889 ^ (long)1735010940);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1839067447 ^ (long)-1839067462);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)13438953 ^ (long)13438907);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)938312032 ^ (long)938311990);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-43105712 ^ (long)-43105570);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)160268967 ^ (long)160268948);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)464691115 ^ (long)464691143);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)457716353 ^ (long)457716332);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1300704095 ^ (long)1300704011);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-324045056 ^ (long)-324044910);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-596988408 ^ (long)-596988183);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-81784240 ^ (long)-81784210);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)961661484 ^ (long)961661489);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)502335754 ^ (long)502335864);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1593250326 ^ (long)-1593250510);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1202528393 ^ (long)-1202528295);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1686637612 ^ (long)1686637792);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1344155930 ^ (long)1344156159);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-546090083 ^ (long)-546090067);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1240101104 ^ (long)-1240100978);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1404036582 ^ (long)-1404036370);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)774061490 ^ (long)774061379);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1464823564 ^ (long)1464823733);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1087056367 ^ (long)1087056200);
                    if (!1k.\u200e\u2000\u2005\u200f\u2007) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)362962670 ^ (long)362962470);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1256978576 ^ (long)1256978543)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)907573324 ^ (long)907577267)) >>> (int)((long)743894562 ^ (long)743894570)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)772816677 ^ (long)772816677);
            if (!1k.\u200e\u2000\u2005\u200f\u2007) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-693426484 ^ (long)-693426482);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)360062172 ^ (long)360062175) | var5_6 << (int)((long)1958130774 ^ (long)1958130771)) ^ var3_4[var7_8]) & (int)((long)-1854317074 ^ (long)-1854317295);
                    if (1k.\u200e\u2000\u2005\u200f\u2007) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)2104064896 ^ (long)2104064899) | var6_7 << (int)((long)1132906379 ^ (long)1132906382)) ^ var3_4[var7_8]) & (int)((long)-1516983156 ^ (long)-1516983181);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            1k.b[var2_3] = new String(var3_4).intern();
        }
        return 1k.b[var2_3];
    }

    public 1k(07 e2) {
        boolean bl = \u200e\u2000\u2005\u200f\u2007;
        super(e2, 1k.a((int)((long)-1145614675 ^ (long)-1145624764), (int)((long)1070065591 ^ (long)1070064214)) /* "Glide" */, null);
        Float f2 = Float.valueOf(0.125f);
        e2 = ((34e)((34e)((34e)this.9().5(1k.a((int)((long)1399958642 ^ (long)1399965084), (int)((long)997849316 ^ (long)997827203)) /* "Ascend" */)).7(1k.a((int)((long)-1947158038 ^ (long)-1947152378), (int)((long)-1094129881 ^ (long)1094124554)) /* "aspeed" */)).1(1k.a((int)((long)521256328 ^ (long)521262176), (int)((long)-257996371 ^ (long)258012315)) /* "The speed at which glide ascends" */)).3(Float.valueOf(0.1f)).2(Float.valueOf(0.3f));
        ((34e)((34e)((34e)this.9().5(1k.a((int)((long)1399958642 ^ (long)1399965084), (int)((long)997849316 ^ (long)997827203)) /* "Ascend" */)).7(1k.a((int)((long)-1947158038 ^ (long)-1947152378), (int)((long)-1094129881 ^ (long)1094124554)) /* "aspeed" */)).1(1k.a((int)((long)521256328 ^ (long)521262176), (int)((long)-257996371 ^ (long)258012315)) /* "The speed at which glide ascends" */)).3(Float.valueOf(0.1f)).2(Float.valueOf(0.3f)).7 = f2;
        this.7 = (1A)((34e)e2).5();
        f2 = Float.valueOf(0.125f);
        e2 = ((34e)((34e)((34e)this.9().5(1k.a((int)((long)850937183 ^ (long)850930864), (int)((long)-1013184999 ^ (long)1013186000)) /* "Descend" */)).7(1k.a((int)((long)1875631329 ^ (long)1875621130), (int)((long)1321077988 ^ (long)-1321082553)) /* "dspeed" */)).1(1k.a((int)((long)-1356081196 ^ (long)-1356087751), (int)((long)888634110 ^ (long)-888605452)) /* "The speed at which glide descends" */)).3(Float.valueOf(0.1f)).2(Float.valueOf(0.3f));
        ((34e)((34e)((34e)this.9().5(1k.a((int)((long)850937183 ^ (long)850930864), (int)((long)-1013184999 ^ (long)1013186000)) /* "Descend" */)).7(1k.a((int)((long)1875631329 ^ (long)1875621130), (int)((long)1321077988 ^ (long)-1321082553)) /* "dspeed" */)).1(1k.a((int)((long)-1356081196 ^ (long)-1356087751), (int)((long)888634110 ^ (long)-888605452)) /* "The speed at which glide descends" */)).3(Float.valueOf(0.1f)).2(Float.valueOf(0.3f)).7 = f2;
        this.8 = (1A)e2.5();
        this.0 = new Listener(f -> {
            block6: {
                double d2;
                block9: {
                    block7: {
                        block8: {
                            block5: {
                                boolean bl = \u200e\u2000\u2005\u200f\u2007;
                                if (bl || bl) break block5;
                                if (!1k.3.s.Z) break block6;
                                if (bl) break block5;
                                if (1k.3.s.aE()) break block6;
                                if (bl) break block5;
                                if (1k.3.s.c_()) break block6;
                                if (bl) break block5;
                                if (1k.3.s.aQ()) break block6;
                                if (bl || bl) break block5;
                                if (!1k.3.s.f.g) break block7;
                                if (!bl) break block8;
                            }
                            return;
                        }
                        d2 = this.7.9;
                        if (\u200e\u2000\u2005\u200f\u2007) {
                            throw null;
                        }
                        break block9;
                    }
                    d2 = -this.8.9;
                }
                4m.1(d2);
            }
        }, new Predicate[(int)((long)796655696 ^ (long)796655696)]);
    }
}

