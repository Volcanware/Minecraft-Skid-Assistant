/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.handler.codec.http.HttpMethod
 *  javax.annotation.Nullable
 */
package net.impactclient;

import io.netty.handler.codec.http.HttpMethod;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.invoke.LambdaMetafactory;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import javax.annotation.Nullable;
import net.impactclient.2B;
import net.impactclient.2w$6X;
import net.impactclient.349;
import net.impactclient.3e;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 81
implements 349<String> {
    private static final String[] b;
    private static final String[] a;
    public static final boolean \u2001\u2003\u2004;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 81.\u2001\u2003\u2004;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-970551564 ^ (long)-970551568)];
            if (var7) break block23;
            var3_2 = (int)((long)1115353075 ^ (long)1115353075);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u048b\u2d4b\u3e57\u3642\u04dc\u2dba\u3e24\u3679\u047b\u2df2\u3ef8\u3682\u0443\u2da9", -289987749);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)73276497 ^ (long)73276505);
            if (var7) break block23;
            var0_6 = (int)((long)-1462754121 ^ (long)1462754120);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-866238212 ^ (long)-866238252);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-360504401 ^ (long)360504400);
                    if (81.\u2001\u2003\u2004) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!81.\u2001\u2003\u2004) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u51fd\u7821\u6bdc\u63da\u51c9\u780d\u6bd3\u6340\u519a\u7876\u6b90\u6313\u51c9\u78fd\u6b56\u6303\u51da\u784d\u6bad\u63fe\u513c\u78e3\u6bb7\u63d3\u5174\u7873\u6bef\u6390\u51a2\u7882\u6b30", 1944614410);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)2082409952 ^ (long)2082409974);
                            var0_6 = (int)((long)2087330375 ^ (long)-2087330376);
                            while (true) {
                                v0 = (int)((long)548737025 ^ (long)548737087);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1189971583 ^ (long)1189971583);
                                if (!81.\u2001\u2003\u2004) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!81.\u2001\u2003\u2004) ** continue;
                                throw null;
                            }
                            81.a = var5_1;
                            81.b = new String[(int)((long)-1167973173 ^ (long)-1167973169)];
                            if (!81.\u2001\u2003\u2004) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1851956658 ^ (long)1851956658);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1692458242 ^ (long)1692458243)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1893267756 ^ (long)1893267755)) {
                                case 0: {
                                    v15 = (int)((long)-1389634796 ^ (long)-1389634798);
                                    if (!81.\u2001\u2003\u2004) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-2105911573 ^ (long)-2105911645);
                                    if (!81.\u2001\u2003\u2004) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)803861319 ^ (long)803861259);
                                    if (!81.\u2001\u2003\u2004) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-501110133 ^ (long)-501110109);
                                    if (!81.\u2001\u2003\u2004) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1256034347 ^ (long)1256034401);
                                    if (!81.\u2001\u2003\u2004) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1310487281 ^ (long)-1310487216);
                                    if (!81.\u2001\u2003\u2004) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1690213497 ^ (long)-1690213400);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!81.\u2001\u2003\u2004);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 81() {
        boolean bl = \u2001\u2003\u2004;
        if (bl) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 81.\u2001\u2003\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-140966675 ^ (long)-140952552)) & (int)((long)606148864 ^ (long)606201599);
            if (var9_2) ** GOTO lbl-1000
            if (81.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 81.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-796673316 ^ (long)-796673316)] & (int)((long)1720399640 ^ (long)1720399847)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-334130790 ^ (long)-334130915);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1643458508 ^ (long)-1643458555);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-801553215 ^ (long)-801553340);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1415982625 ^ (long)-1415982692);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-79671682 ^ (long)-79671771);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)869657433 ^ (long)869657497);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)606423909 ^ (long)606423877);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-468596454 ^ (long)-468596298);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1111358229 ^ (long)1111358423);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)602115124 ^ (long)602115099);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-153557311 ^ (long)-153557408);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-2100596703 ^ (long)-2100596598);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-741448407 ^ (long)-741448270);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)665233177 ^ (long)665233291);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-425609020 ^ (long)-425609155);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1629429711 ^ (long)-1629429659);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)210042135 ^ (long)210042227);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1716877951 ^ (long)-1716877963);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-868019531 ^ (long)-868019478);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-655069522 ^ (long)-655069580);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-21181428 ^ (long)-21181188);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-819021784 ^ (long)-819021598);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)278684409 ^ (long)278684312);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1539409756 ^ (long)1539409835);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1734248453 ^ (long)-1734248484);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1222400327 ^ (long)1222400496);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1714752234 ^ (long)-1714752127);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-994636425 ^ (long)-994636356);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1362034022 ^ (long)-1362034137);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-694681034 ^ (long)-694681088);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)330415178 ^ (long)330415122);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1330111665 ^ (long)-1330111718);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)891188233 ^ (long)891188318);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-468923737 ^ (long)-468923874);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)471904907 ^ (long)471904897);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)2069510514 ^ (long)2069510491);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1237092884 ^ (long)1237093062);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)2106655196 ^ (long)2106655074);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1190530422 ^ (long)1190530407);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-2065686599 ^ (long)-2065686622);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-154447974 ^ (long)-154448045);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1555552444 ^ (long)1555552442);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-668418216 ^ (long)-668418220);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)888288086 ^ (long)888288046);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-496312052 ^ (long)-496311854);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1184246055 ^ (long)-1184246144);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)944243731 ^ (long)944243871);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)957195958 ^ (long)957195945);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1164673822 ^ (long)-1164673972);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)503923865 ^ (long)503923811);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)935044761 ^ (long)935044746);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-183359574 ^ (long)-183359564);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1821405395 ^ (long)1821405340);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-474996414 ^ (long)-474996359);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)161482822 ^ (long)161482924);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)813935631 ^ (long)813935653);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-212601367 ^ (long)-212601366);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1216531578 ^ (long)1216531571);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1502746794 ^ (long)-1502746848);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-319897474 ^ (long)-319897584);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-886457594 ^ (long)-886457394);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)730419150 ^ (long)730419158);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1926932405 ^ (long)-1926932348);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-324456512 ^ (long)-324456664);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)758637154 ^ (long)758637283);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-148357219 ^ (long)-148357300);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1028879263 ^ (long)1028879301);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1162861678 ^ (long)1162861728);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1586442635 ^ (long)-1586442613);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)720483264 ^ (long)720483278);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)64541939 ^ (long)64541915);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)857847181 ^ (long)857847104);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1555405812 ^ (long)-1555405784);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1051907442 ^ (long)-1051907353);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)593361798 ^ (long)593361809);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1202373564 ^ (long)1202373527);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-445782916 ^ (long)-445782909);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1166730907 ^ (long)-1166730785);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1840755167 ^ (long)-1840755085);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-565492271 ^ (long)-565492403);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-251509929 ^ (long)-251509931);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1293438340 ^ (long)1293438297);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1071465964 ^ (long)-1071465984);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-2138271284 ^ (long)-2138271400);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)913359995 ^ (long)913360086);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)2021459262 ^ (long)2021459249);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)44011551 ^ (long)44011540);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1347702680 ^ (long)1347702549);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-826829350 ^ (long)-826829441);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)994390900 ^ (long)994390807);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-138199911 ^ (long)-138199834);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1635177214 ^ (long)1635177072);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)2145355257 ^ (long)2145355026);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1432317936 ^ (long)-1432317952);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1447264677 ^ (long)1447264665);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-619117931 ^ (long)-619118004);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)396436126 ^ (long)396436026);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-899886839 ^ (long)-899886696);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1264632857 ^ (long)1264632946);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)750621763 ^ (long)750621840);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)158435885 ^ (long)158436024);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1113882402 ^ (long)1113882512);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1507118191 ^ (long)-1507118324);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1198699580 ^ (long)-1198699635);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)980341037 ^ (long)980341201);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1429986232 ^ (long)1429986280);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1520577294 ^ (long)1520577332);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1811923161 ^ (long)1811923153);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1845854705 ^ (long)-1845854598);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1919115103 ^ (long)-1919115243);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1359302216 ^ (long)1359302388);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1879540641 ^ (long)1879540606);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)141451513 ^ (long)141451444);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)342741915 ^ (long)342741971);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)970781082 ^ (long)970781142);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1096946694 ^ (long)-1096946798);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)549674773 ^ (long)549674796);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-156120154 ^ (long)-156120106);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-864715843 ^ (long)-864715975);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-884600367 ^ (long)-884600540);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1588632606 ^ (long)1588632773);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-817262546 ^ (long)-817262379);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-672254497 ^ (long)-672254596);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)721306725 ^ (long)721306755);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1504973288 ^ (long)-1504973116);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)898821825 ^ (long)898821810);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)2066001563 ^ (long)2066001583);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-32008404 ^ (long)-32008340);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-997497448 ^ (long)-997497484);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-692190967 ^ (long)-692190898);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)303119744 ^ (long)303119809);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1817192023 ^ (long)-1817192088);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1596633314 ^ (long)1596633105);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1301116324 ^ (long)-1301116362);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-115030489 ^ (long)-115030386);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-718427667 ^ (long)-718427757);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-28358030 ^ (long)-28358025);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)709607649 ^ (long)709607449);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1636551961 ^ (long)1636552004);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-357060501 ^ (long)-357060538);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1686383030 ^ (long)1686383065);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)888925210 ^ (long)888925184);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1481296579 ^ (long)-1481296500);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-727051375 ^ (long)-727051452);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1543006915 ^ (long)1543006906);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-2028549420 ^ (long)-2028549457);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-866780604 ^ (long)-866780636);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1133334942 ^ (long)1133334945);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1378436151 ^ (long)-1378436198);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-671035323 ^ (long)-671035335);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)107089795 ^ (long)107089683);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)350391474 ^ (long)350391414);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)472496679 ^ (long)472496846);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-700305552 ^ (long)-700305467);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1624707250 ^ (long)1624707316);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1399078116 ^ (long)1399077990);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-266901062 ^ (long)-266901059);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-442831072 ^ (long)-442831034);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1304411118 ^ (long)-1304411114);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)850406020 ^ (long)850405915);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)5423415 ^ (long)5423380);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1308930472 ^ (long)1308930350);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1308320465 ^ (long)1308320436);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-71090679 ^ (long)-71090543);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-510618756 ^ (long)-510618784);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-909611377 ^ (long)-909611288);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1472505762 ^ (long)1472505762);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-231396421 ^ (long)-231396535);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)142474766 ^ (long)142474800);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1203084359 ^ (long)-1203084490);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-792054123 ^ (long)-792054237);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)260592859 ^ (long)260592712);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1482496741 ^ (long)1482496536);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1684321303 ^ (long)1684321438);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)410500490 ^ (long)410500386);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1933810327 ^ (long)-1933810185);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-56697755 ^ (long)-56697781);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1053107925 ^ (long)-1053107761);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)99004964 ^ (long)99005138);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1726071518 ^ (long)1726071380);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1907255442 ^ (long)-1907255308);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1121632404 ^ (long)-1121632342);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-699180248 ^ (long)-699180033);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)636943551 ^ (long)636943391);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-910751698 ^ (long)-910751715);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)987514931 ^ (long)987515074);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1031900951 ^ (long)1031900933);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1699114280 ^ (long)1699114256);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-815248689 ^ (long)-815248682);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-2107232610 ^ (long)-2107232516);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-514204204 ^ (long)-514204191);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1088017880 ^ (long)1088017913);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)2115253916 ^ (long)2115253780);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-2081365277 ^ (long)-2081365266);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)829649893 ^ (long)829649851);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-91126937 ^ (long)-91126927);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1524541244 ^ (long)1524541195);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-2077159395 ^ (long)-2077159336);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-956712567 ^ (long)-956712596);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-796576411 ^ (long)-796576377);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1502270786 ^ (long)-1502270956);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-312055155 ^ (long)-312055121);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1146180694 ^ (long)-1146180648);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1908367471 ^ (long)-1908367490);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-940916343 ^ (long)-940916236);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1765682293 ^ (long)1765682354);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)371190763 ^ (long)371190608);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-682470750 ^ (long)-682470698);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)534794313 ^ (long)534794486);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1508196379 ^ (long)-1508196555);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1007244710 ^ (long)-1007244676);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)719636024 ^ (long)719636221);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)599735565 ^ (long)599735643);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1229374918 ^ (long)1229374753);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1884925248 ^ (long)1884925195);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1930017011 ^ (long)1930016860);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1932010804 ^ (long)-1932010892);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1057142079 ^ (long)-1057142184);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1125943340 ^ (long)-1125943339);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)838035119 ^ (long)838035198);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)841057886 ^ (long)841057938);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1483452675 ^ (long)-1483452721);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1443659975 ^ (long)1443659873);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)2116913539 ^ (long)2116913411);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)2007394219 ^ (long)2007394247);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-2085155105 ^ (long)-2085155255);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-323835942 ^ (long)-323836040);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-526580549 ^ (long)-526580725);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-230161835 ^ (long)-230161736);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)557811408 ^ (long)557811405);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1864514521 ^ (long)1864514360);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)825109791 ^ (long)825109841);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1706192563 ^ (long)-1706192515);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1306419643 ^ (long)1306419541);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)2040748868 ^ (long)2040748999);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)71796254 ^ (long)71796308);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1326087386 ^ (long)-1326087195);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1458575906 ^ (long)1458575957);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-124290925 ^ (long)-124290863);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1477822573 ^ (long)-1477822494);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1818220900 ^ (long)-1818220929);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1189548769 ^ (long)1189548684);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-2072104616 ^ (long)-2072104670);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1150111716 ^ (long)-1150111711);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1650368681 ^ (long)1650368538);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-922550170 ^ (long)-922550096);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-470358307 ^ (long)-470358287);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-810058781 ^ (long)-810058953);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)868733809 ^ (long)868733865);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-85765764 ^ (long)-85765832);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-531733256 ^ (long)-531733389);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-644099530 ^ (long)-644099565);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1849408543 ^ (long)1849408522);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1607538008 ^ (long)-1607538161);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1191582671 ^ (long)-1191582611);
                    if (!81.\u2001\u2003\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)563566027 ^ (long)563565867);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1204881705 ^ (long)1204881878)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1767006275 ^ (long)1767022524)) >>> (int)((long)-861704272 ^ (long)-861704264)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1672800761 ^ (long)1672800761);
            if (!81.\u2001\u2003\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1568965067 ^ (long)-1568965065);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-260915287 ^ (long)-260915286) | var5_6 << (int)((long)1601776962 ^ (long)1601776967)) ^ var3_4[var7_8]) & (int)((long)-1732560547 ^ (long)-1732560478);
                    if (81.\u2001\u2003\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)894480264 ^ (long)894480267) | var6_7 << (int)((long)-126786256 ^ (long)-126786251)) ^ var3_4[var7_8]) & (int)((long)0x5B9555B5 ^ (long)1536513354);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            81.b[var2_3] = new String(var3_4).intern();
        }
        return 81.b[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    public static 2B 2(String var0, @Nullable Map<String, String> var1_1, @Nullable String var2_2, HttpMethod var3_3) {
        block8: {
            var9_4 = 81.\u2001\u2003\u2004;
            if (var9_4) lbl-1000:
            // 3 sources

            {
                return null;
            }
            var6_5 = new HashMap<String, Integer>();
            var4_6 = 3e.5();
            if (var9_4 || var9_4) ** GOTO lbl-1000
            if (var2_2 == null) break block8;
            if (!var9_4) ** break;
            ** while (true)
            v0 = (int)((long)1271654743 ^ (long)1271654742);
            if (81.\u2001\u2003\u2004) {
                throw null;
            }
            ** GOTO lbl18
        }
        block1: do {
            v0 = var7_8 = (int)((long)-759812896 ^ (long)-759812896);
lbl18:
            // 2 sources

            do {
                if (var6_5.compute((String)var0, (BiFunction<String, Integer, Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, 9(java.lang.String java.lang.Integer ), (Ljava/lang/String;Ljava/lang/Integer;)Ljava/lang/Integer;)()) > (int)((long)-1239472279 ^ (long)-1239472278)) {
                    throw new IOException(81.a((int)((long)-1900337548 ^ (long)-1900339581), (int)((long)810806129 ^ (long)810805325)) /* "Stuck in redirect loop" */);
                }
                var5_7 = (HttpURLConnection)new URL((String)var0).openConnection();
                var5_7.setConnectTimeout((int)((long)615661199 ^ (long)615646231));
                var5_7.setReadTimeout((int)((long)865250194 ^ (long)865243402));
                var5_7.setDoInput((boolean)((long)-2128950825 ^ (long)-2128950826));
                var5_7.setDoOutput((boolean)var7_8);
                var5_7.setRequestMethod(var3_3.toString());
                var5_7.setInstanceFollowRedirects((boolean)((long)471384853 ^ (long)471384853));
                if (var1_1 != null && var1_1.size() > 0) {
                    var1_1.forEach((BiConsumer<String, String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;Ljava/lang/Object;)V, setRequestProperty(java.lang.String java.lang.String ), (Ljava/lang/String;Ljava/lang/String;)V)((HttpURLConnection)var5_7));
                }
                if (var7_8 != 0) {
                    var8_9 = new OutputStreamWriter(var5_7.getOutputStream());
                    var8_9.write(var2_2);
                    var8_9.flush();
                }
                if (!81.2(var5_7)) break block1;
                var8_9 = URLDecoder.decode(var5_7.getHeaderField(81.a((int)((long)-106082962 ^ (long)-106072677), (int)((long)172762606 ^ (long)172761606)) /* "Location" */), 81.a((int)((long)298926962 ^ (long)298941318), (int)((long)1429304468 ^ (long)-1429284205)) /* "UTF-8" */);
                var0 = new URL((String)var0);
                var0 = new URL((URL)var0, (String)var8_9).toExternalForm();
            } while (var5_7.getResponseCode() != (int)((long)-1848058355 ^ (long)-1848058078));
            var3_3 = HttpMethod.GET;
        } while (var4_6 == null);
        var8_9 = new 2B(var5_7);
        var5_7.disconnect();
        return var8_9;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean 2(HttpURLConnection httpURLConnection) {
        boolean bl = \u2001\u2003\u2004;
        if (bl) return true;
        String[] stringArray = 3e.5();
        if (bl || bl) return true;
        switch (httpURLConnection.getResponseCode()) {
            case 301: 
            case 302: 
            case 303: 
            case 307: 
            case 308: {
                if (bl) return true;
                if (stringArray == null) break;
                if (bl) return true;
            }
            default: {
                if (bl) return true;
                return (int)((long)340306259 ^ (long)340306259) != 0;
            }
        }
        if (bl) return true;
        if (!httpURLConnection.getHeaderField(81.a((int)((long)784137846 ^ (long)784123520), (int)((long)-1155950246 ^ (long)1155924121))).isEmpty()) {
            if (bl) return true;
            return (int)((long)-1333727836 ^ (long)-1333727835) != 0;
        }
        if (!bl) return (int)((long)-1544249188 ^ (long)-1544249188) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ Integer 9(String string, Integer n) {
        int n2;
        boolean bl = \u2001\u2003\u2004;
        if (bl || bl) return null;
        if (n == null) {
            if (bl) {
                return null;
            }
            n2 = (int)((long)996459967 ^ (long)996459966);
            if (!\u2001\u2003\u2004) return n2;
            throw null;
        }
        n2 = n + (int)((long)635216119 ^ (long)635216118);
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final boolean 9(Type type) {
        boolean bl = \u2001\u2003\u2004;
        if (bl || bl) return true;
        if (type instanceof Class) {
            if (bl) return true;
            if (String.class.isAssignableFrom((Class)type)) {
                if (bl) return true;
                return (int)((long)1161929221 ^ (long)1161929220) != 0;
            }
        }
        if (!bl) return (int)((long)-1085622339 ^ (long)-1085622339) != 0;
        return true;
    }

    public static 2B 6(String string, @Nullable Map<String, String> map) {
        boolean bl = \u2001\u2003\u2004;
        if (bl || bl) {
            return null;
        }
        return 81.2(string, map, null, HttpMethod.GET);
    }
}

