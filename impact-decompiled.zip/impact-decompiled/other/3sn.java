/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  javax.annotation.Nullable
 *  vk
 */
package net.impactclient;

import com.google.gson.annotations.SerializedName;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import javax.annotation.Nullable;
import net.impactclient.2B;
import net.impactclient.2w$6X;
import net.impactclient.34y;
import net.impactclient.3R;
import net.impactclient.3z;
import net.impactclient.6J;
import net.impactclient.6L;
import net.impactclient.81;
import net.impactclient.8Q;
import net.impactclient.9B;
import net.impactclient.9n;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class 3sn {
    private static final String[] c;
    @SerializedName(value="legacy_enabled")
    private boolean 8;
    @Nullable
    @SerializedName(value="email")
    private String 6;
    @Nullable
    @SerializedName(value="info")
    public 3R 3;
    @Nullable
    @SerializedName(value="roles")
    public String[] 7;
    @Nullable
    @SerializedName(value="edition")
    private 9B 0;
    @SerializedName(value="incognito")
    private boolean 1;
    @Nullable
    @SerializedName(value="discord")
    private 8Q 2;
    public static final boolean \u2001\u2008;
    private static String 5;
    @Nullable
    @SerializedName(value="minecraft")
    private 9n 6A;
    private static final String[] a;
    private final Map<String, OptionalInt> 9;
    @Nullable
    @SerializedName(value="features")
    public 3z 4;

    /*
     * Enabled aggressive block sorting
     */
    public final String 5() {
        boolean bl = \u2001\u2008;
        if (bl || bl) return null;
        if (this.6 == null) {
            if (bl) return null;
            return 2w$6X.KAOZ("", 1637026827);
        }
        if (!bl) return this.6;
        return null;
    }

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 3sn.\u2001\u2008;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1769134552 ^ (long)1769121890)) & (int)((long)-758887159 ^ (long)-758861066);
            if (var9_2) ** GOTO lbl-1000
            if (3sn.c[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3sn.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1984323264 ^ (long)1984323264)] & (int)((long)1756869583 ^ (long)1756869424)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1443092700 ^ (long)1443092499);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-567283627 ^ (long)-567283707);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-389970231 ^ (long)-389970263);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)2119341043 ^ (long)2119340956);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-166164298 ^ (long)-166164426);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)656204039 ^ (long)656204160);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-2036915557 ^ (long)-2036915681);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1419986156 ^ (long)-1419985927);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-735129191 ^ (long)-735129223);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1563006208 ^ (long)-1563006086);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1251542797 ^ (long)1251542816);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)142775277 ^ (long)142775291);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-238489017 ^ (long)-238488877);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)663848622 ^ (long)663848462);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1745820898 ^ (long)1745820927);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1097489992 ^ (long)-1097489965);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1169899563 ^ (long)1169899569);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-501559525 ^ (long)-501559319);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-505146743 ^ (long)-505146769);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)404963479 ^ (long)404963389);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-876337306 ^ (long)-876337262);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-677619328 ^ (long)-677619278);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1931068871 ^ (long)1931068797);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)711053719 ^ (long)711053585);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)555702370 ^ (long)555702326);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)889771806 ^ (long)889771880);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)2090630239 ^ (long)2090630355);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1540609378 ^ (long)1540609413);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1265354220 ^ (long)1265354235);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1543258951 ^ (long)1543258953);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)20288214 ^ (long)20288235);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1676282272 ^ (long)1676282333);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-647364918 ^ (long)-647365031);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)310263754 ^ (long)310263598);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-366256537 ^ (long)-366256571);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-325960997 ^ (long)-325961127);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1829634151 ^ (long)1829634242);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)38777670 ^ (long)38777701);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-2126320184 ^ (long)-2126320278);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1600224739 ^ (long)1600224751);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-2028266758 ^ (long)-2028266785);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-574679288 ^ (long)-574679162);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1955648069 ^ (long)1955648122);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)202749469 ^ (long)202749489);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1525623074 ^ (long)-1525623131);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-82940689 ^ (long)-82940760);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-2050250124 ^ (long)-2050250200);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)406533270 ^ (long)406533338);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)2097917455 ^ (long)2097917657);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1030212484 ^ (long)1030212383);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1586069298 ^ (long)-1586069365);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-26798551 ^ (long)-26798424);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)585669498 ^ (long)585669446);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-301250110 ^ (long)-301250216);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-472579734 ^ (long)-472579764);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1868171245 ^ (long)-1868171123);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)812031432 ^ (long)812031365);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1840031143 ^ (long)1840031195);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)634319882 ^ (long)634319884);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-995653369 ^ (long)-995653217);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)11389186 ^ (long)11389399);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1144343642 ^ (long)-1144343711);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1771972878 ^ (long)-1771973108);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1557183647 ^ (long)1557183490);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)496301093 ^ (long)496301287);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1627552570 ^ (long)1627552567);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1590536289 ^ (long)1590536370);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)2107886737 ^ (long)2107886738);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-697212600 ^ (long)-697212642);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1530218066 ^ (long)-1530218079);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1120291987 ^ (long)-1120291919);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-633818007 ^ (long)-633817976);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)972091607 ^ (long)972091598);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1658526016 ^ (long)1658526114);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)2055961267 ^ (long)2055961235);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1872794282 ^ (long)1872794311);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-400398422 ^ (long)-400398369);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1438235386 ^ (long)1438235209);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-607404399 ^ (long)-607404536);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-534529592 ^ (long)-534529562);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1394124809 ^ (long)-1394124877);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-818622653 ^ (long)-818622517);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-888494057 ^ (long)-888493848);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1105089204 ^ (long)-1105089274);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1564369578 ^ (long)1564369651);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)495601886 ^ (long)495601897);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1678606062 ^ (long)1678605999);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-2118348424 ^ (long)-2118348506);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1200560436 ^ (long)-1200560450);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)976066035 ^ (long)976066029);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1731030653 ^ (long)-1731030722);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-371569659 ^ (long)-371569611);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)291263823 ^ (long)291263904);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1751100527 ^ (long)-1751100639);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-76958748 ^ (long)-76958900);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-2049564488 ^ (long)-2049564575);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)723733394 ^ (long)723733251);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)451930398 ^ (long)451930373);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1399205514 ^ (long)1399205475);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)2039820116 ^ (long)2039820047);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-2011824087 ^ (long)-2011823962);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)58548637 ^ (long)58548682);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)790907464 ^ (long)790907617);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)628195505 ^ (long)628195571);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-110001628 ^ (long)-110001617);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1348608789 ^ (long)1348608891);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1291135523 ^ (long)-1291135502);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)2120166690 ^ (long)2120166761);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-602499771 ^ (long)-602499771);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)2125687574 ^ (long)2125687777);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-72667783 ^ (long)-72667699);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-312822933 ^ (long)-312822825);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1467154465 ^ (long)1467154609);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)198311121 ^ (long)198310990);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-810301368 ^ (long)-810301394);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)570978063 ^ (long)570978157);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1324154345 ^ (long)-1324154242);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1146107376 ^ (long)-1146107320);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1157433294 ^ (long)1157433215);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)958881601 ^ (long)958881555);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1897118131 ^ (long)1897118027);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-644410193 ^ (long)-644410235);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-548815298 ^ (long)-548815203);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1698829487 ^ (long)1698829418);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)579744833 ^ (long)579744906);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-655485052 ^ (long)-655485044);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)359064769 ^ (long)359064797);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-880236914 ^ (long)-880236870);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)766531066 ^ (long)766530995);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1355128732 ^ (long)1355128643);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)910986848 ^ (long)910986971);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-663449139 ^ (long)-663449298);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-365201320 ^ (long)-365201315);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1792141788 ^ (long)-1792141647);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1009685549 ^ (long)1009685699);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)7033934 ^ (long)7033987);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)846428534 ^ (long)846428430);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1557675918 ^ (long)-1557675812);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1024859881 ^ (long)1024859896);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1984733214 ^ (long)1984733429);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1547569224 ^ (long)-1547569302);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1705797129 ^ (long)1705797203);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1638809009 ^ (long)1638808982);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)2105191023 ^ (long)2105190980);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1582501486 ^ (long)-1582501384);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1866648304 ^ (long)-1866648103);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-687858540 ^ (long)-687858448);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1620851571 ^ (long)1620851695);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1174904505 ^ (long)-1174904489);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1747256339 ^ (long)-1747256380);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1799568490 ^ (long)1799568405);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1655398138 ^ (long)1655398053);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1667177226 ^ (long)-1667177417);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1274490539 ^ (long)-1274490524);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)2110508680 ^ (long)2110508545);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1407003073 ^ (long)-1407003124);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)155837791 ^ (long)155837710);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)900733801 ^ (long)900733886);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1579518491 ^ (long)1579518628);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1938516395 ^ (long)1938516424);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1716585565 ^ (long)-1716585627);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-786023834 ^ (long)-786023785);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-101546724 ^ (long)-101546544);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1452890429 ^ (long)1452890449);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-10229819 ^ (long)-10229839);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)655127517 ^ (long)655127420);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1053427644 ^ (long)-1053427532);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-372064237 ^ (long)-372064236);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)598666114 ^ (long)598666029);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)506218868 ^ (long)506218922);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-633146427 ^ (long)-633146603);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-411596882 ^ (long)-411596805);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1631110566 ^ (long)-1631110526);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)2146332453 ^ (long)2146332460);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)185518448 ^ (long)185518534);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-460159629 ^ (long)-460159519);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1016759832 ^ (long)-1016760020);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-636316364 ^ (long)-636316300);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1767867132 ^ (long)-1767867049);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1830408191 ^ (long)1830407948);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1995968215 ^ (long)1995968013);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1760233018 ^ (long)-1760233155);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1814218529 ^ (long)1814218701);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)2106189820 ^ (long)2106189725);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1890442216 ^ (long)1890442136);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-749759396 ^ (long)-749759238);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1455210639 ^ (long)1455210536);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)508855940 ^ (long)508855986);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-570440476 ^ (long)-570440621);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1284747527 ^ (long)1284747716);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-168124940 ^ (long)-168124971);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1029981668 ^ (long)1029981661);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1120811867 ^ (long)1120811985);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1725917833 ^ (long)1725917944);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1045461130 ^ (long)1045461058);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)243433345 ^ (long)243433365);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1032233287 ^ (long)1032233225);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)734213229 ^ (long)734213283);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1027431609 ^ (long)-1027431472);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)763770395 ^ (long)763770599);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1704274668 ^ (long)1704274529);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)415175494 ^ (long)415175518);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-587296681 ^ (long)-587296575);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1814792157 ^ (long)-1814791950);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1632520884 ^ (long)-1632520820);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-2096199352 ^ (long)-2096199337);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1059241792 ^ (long)1059241845);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-775309042 ^ (long)-775308951);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-645410794 ^ (long)-645410653);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1276911614 ^ (long)1276911442);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1359103820 ^ (long)1359103814);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1152608491 ^ (long)1152608335);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1773549942 ^ (long)1773549943);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1181180663 ^ (long)-1181180588);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)660325029 ^ (long)660325078);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-533411119 ^ (long)-533411224);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-945211947 ^ (long)-945212010);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-527007555 ^ (long)-527007639);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)224889929 ^ (long)224890002);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1111232226 ^ (long)1111232217);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1784288482 ^ (long)1784288420);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)859244690 ^ (long)859244664);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)575386944 ^ (long)575387134);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1792201777 ^ (long)-1792201916);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1131409347 ^ (long)-1131409403);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)960152444 ^ (long)960152430);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-720910651 ^ (long)-720910792);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-621884407 ^ (long)-621884390);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-461005147 ^ (long)-461005078);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1710311318 ^ (long)1710311358);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1373282763 ^ (long)-1373282736);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1319955713 ^ (long)-1319955886);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1578018271 ^ (long)1578018103);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1792789193 ^ (long)-1792789235);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1702586138 ^ (long)1702586339);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1999230810 ^ (long)-1999230846);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)369014348 ^ (long)369014516);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1398333220 ^ (long)1398333274);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1310221941 ^ (long)-1310221937);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)529055034 ^ (long)529055043);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-269619060 ^ (long)-269619078);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1587172592 ^ (long)-1587172459);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1878416020 ^ (long)1878415945);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1217233752 ^ (long)1217233883);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1650867758 ^ (long)-1650867928);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)379018635 ^ (long)379018691);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1396683609 ^ (long)1396683623);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1802910967 ^ (long)-1802910781);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-33875574 ^ (long)-33875553);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1236097251 ^ (long)-1236097249);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1347838875 ^ (long)-1347838770);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1089958005 ^ (long)1089957917);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1593007314 ^ (long)-1593007204);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1259152623 ^ (long)1259152410);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1350053262 ^ (long)-1350053225);
                    if (!3sn.\u2001\u2008) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1010901666 ^ (long)-1010901719);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1015710616 ^ (long)-1015710569)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-147304027 ^ (long)-147280294)) >>> (int)((long)819934196 ^ (long)819934204)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-776142080 ^ (long)-776142080);
            if (!3sn.\u2001\u2008) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)286256178 ^ (long)286256176);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1238889190 ^ (long)1238889189) | var5_6 << (int)((long)447861844 ^ (long)447861841)) ^ var3_4[var7_8]) & (int)((long)-1752740772 ^ (long)-1752740701);
                    if (3sn.\u2001\u2008) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1855040274 ^ (long)-1855040275) | var6_7 << (int)((long)1854121617 ^ (long)1854121620)) ^ var3_4[var7_8]) & (int)((long)-866427250 ^ (long)-866427279);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3sn.c[var2_3] = new String(var3_4).intern();
        }
        return 3sn.c[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public final Optional<vk> 7() {
        boolean bl;
        block8: {
            block7: {
                bl = \u2001\u2008;
                if (bl || bl) return null;
                if (this.0 == null) break block7;
                if (bl) return null;
                if (this.0.3 == null) break block7;
                if (bl) return null;
                if (!this.0.3.isEmpty()) break block8;
                if (bl) return null;
            }
            if (bl) return null;
            return Optional.empty();
        }
        if (!bl) return Optional.ofNullable(6J.0(this.0.3, (boolean)((long)-1880399875 ^ (long)-1880399875)));
        return null;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 3sn.\u2001\u2008;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)-1375665437 ^ (long)-1375665435)];
            if (var7) break block25;
            var3_2 = (int)((long)644962615 ^ (long)644962615);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\u1b74\ua657\ub553\ubd80\u1b9f\ua6f6\ub5f1\ubde3\u1b08\ua611\ub5e0\ubd97\u1bb2\ua611\ub56a\ubd95\u1bcf\ua62b\ub583\ubdfe\u1b1d\ua604\ub5d0\ubd7e\u1b2a\ua69d\ub567\ubd83\u1b9f\ua658\ub566\ubd53\u1b68\ua692\ub5ee\ubdf7\u1bb7\ua6f4\ub521\ubdb5\u1bfb\ua669", 1597024307);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)828577300 ^ (long)0x31631613);
            if (var7) break block25;
            var0_6 = (int)((long)1502822221 ^ (long)-1502822222);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)-1016745917 ^ (long)-1016745864);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)609995000 ^ (long)-609995001);
                        if (3sn.\u2001\u2008) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!3sn.\u2001\u2008) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\ud448\u69ff\u7a52\u7258\ud4e2\u691b\u7a79\u72d8\ud46f\u698b\u7ae1\u7260\ud440\u69fd\u7ad0\u7295\ud428\u69c3\u7a2d\u72df\ud4b1\u69f3\u7a92\u728c\ud492\u6921\u7ae8\u72e1\ud472\u695e\u7aff\u72ef\ud40b\u698e\u7a36\u724f\ud472\u69aa\u7ab2\u72fa\ud498\u6934\u7a1f\u7252\ud498", -1174903005);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)1347816968 ^ (long)1347816983);
                                var0_6 = (int)((long)474475203 ^ (long)-474475204);
                                while (true) {
                                    v0 = (int)((long)-1334387809 ^ (long)-1334387797);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)-1757020907 ^ (long)-1757020907);
                                    if (!3sn.\u2001\u2008) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!3sn.\u2001\u2008) ** continue;
                                    throw null;
                                }
                                3sn.a = var5_1;
                                3sn.c = new String[(int)((long)-473491670 ^ (long)-473491668)];
                                if (3sn.\u2001\u2008) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)-1739953953 ^ (long)-1739953953);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)-1206007331 ^ (long)-1206007332)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-406251060 ^ (long)-406251061)) {
                                    case 0: {
                                        v15 = (int)((long)1771783594 ^ (long)1771783616);
                                        if (!3sn.\u2001\u2008) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)1965953365 ^ (long)1965953341);
                                        if (!3sn.\u2001\u2008) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)-501909886 ^ (long)-501909887);
                                        if (!3sn.\u2001\u2008) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)-1024088186 ^ (long)-1024088153);
                                        if (!3sn.\u2001\u2008) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)1815655685 ^ (long)1815655717);
                                        if (!3sn.\u2001\u2008) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)1550914341 ^ (long)1550914353);
                                        if (!3sn.\u2001\u2008) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)235114064 ^ (long)235114055);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!3sn.\u2001\u2008);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                3sn.5 = 3sn.a((int)((long)1093416875 ^ (long)1093420562), (int)((long)1084564667 ^ (long)-1084572887)) /* "/user/me" */;
                break;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 3sn() {
        block3: {
            block2: {
                boolean bl = \u2001\u2008;
                if (bl || bl) break block2;
                this.9 = new HashMap<String, OptionalInt>();
                if (!bl) break block3;
            }
            return;
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static 3sn 9(@Nullable 34y object) {
        boolean bl = \u2001\u2008;
        if (bl || bl) return null;
        HashMap<String, String> hashMap = new HashMap<String, String>();
        if (bl || bl) return null;
        if (object != null) {
            if (bl || bl) return null;
            hashMap.put(3sn.a((int)((long)1499216937 ^ (long)1499221398), (int)((long)1090127088 ^ (long)-1090157922)) /* "Authorization" */, 3sn.a((int)((long)-410622853 ^ (long)-410643007), (int)((long)-1370780499 ^ (long)-1370768609)) /* "Bearer " */ + ((34y)object).toString());
            if (bl) return null;
        }
        try {
            if (bl) return null;
            object = 81.6(3sn.a((int)((long)416775576 ^ (long)416746534), (int)((long)-1188926597 ^ (long)1188923518)) /* "https://api.impactclient.net/v1" */ + 5, hashMap);
            if (!((2B)object).2()) {
                if (bl || bl) return null;
                throw new IOException(5 + 3sn.a((int)((long)948676961 ^ (long)948689114), (int)((long)1815927578 ^ (long)-1815932517)) /* " is not ok, it's " */ + ((2B)object).2);
            }
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            if (bl || bl) return null;
            return new 3sn();
        }
        {
            if (bl) return null;
            return ((2B)object).0(3sn.class);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final String 1() {
        boolean bl;
        block8: {
            block7: {
                bl = \u2001\u2008;
                if (bl || bl) return null;
                if (this.0 == null) break block7;
                if (bl) return null;
                if (this.0.6 != null) break block8;
                if (bl) return null;
            }
            if (bl) return null;
            return 2w$6X.KAOZ("", -104445924);
        }
        if (!bl) return this.0.6;
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final OptionalInt 3() {
        boolean bl;
        block8: {
            block7: {
                bl = \u2001\u2008;
                if (bl || bl) return null;
                if (this.0 == null) break block7;
                if (bl) return null;
                if (this.0.7 != null) break block8;
                if (bl) return null;
            }
            if (bl) return null;
            return OptionalInt.empty();
        }
        if (!bl) return this.9.computeIfAbsent(3sn.a((int)((long)-910967093 ^ (long)-910962829), (int)((long)-1397164343 ^ (long)-1397162928)) /* "edition" */, string -> {
            boolean bl = \u2001\u2008;
            if (bl || bl) {
                return null;
            }
            return 6L.8(this.0.7);
        });
        return null;
    }
}

