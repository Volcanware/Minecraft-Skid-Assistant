/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  baritone.api.utils.Helper
 */
package net.impactclient;

import baritone.api.utils.Helper;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import net.impactclient.2w$6X;
import net.impactclient.34y;
import net.impactclient.3R;
import net.impactclient.3sf;
import net.impactclient.3sn;
import net.impactclient.5S;
import net.impactclient.6O;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class 3sH
extends 3sf
implements Helper {
    private final List<6O> 4;
    private static final String[] b;
    private final 34y 7;
    private static final String[] a;
    public static final boolean \u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c;
    public final 3sn 6;

    /*
     * Unable to fully structure code
     */
    private static String a(int var0, int var1_1) {
        block265: {
            var9_2 = 3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)583062201 ^ (long)-583048075)) & (int)((long)967798208 ^ (long)967807551);
            if (var9_2) ** GOTO lbl-1000
            if (3sH.b[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3sH.a[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1587388155 ^ (long)-1587388155)] & (int)((long)2029094061 ^ (long)2029093970)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-2086426899 ^ (long)-2086427036);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1089154624 ^ (long)-1089154566);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)345078885 ^ (long)345078966);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-98795923 ^ (long)-98795797);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-912880207 ^ (long)-912880297);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-417941705 ^ (long)-417941582);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)868753640 ^ (long)868753606);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)2054975113 ^ (long)2054974990);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)622489390 ^ (long)622489478);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1821901871 ^ (long)1821901926);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-730354036 ^ (long)-730354056);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)680828715 ^ (long)680828725);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1262011384 ^ (long)1262011169);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-315547829 ^ (long)-315547681);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)54380446 ^ (long)54380511);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-24143541 ^ (long)-24143596);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-809243228 ^ (long)-809243280);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-614032484 ^ (long)-614032414);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)354472419 ^ (long)354472406);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1433104746 ^ (long)-1433104737);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-2069510219 ^ (long)-2069510150);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1272556143 ^ (long)-1272556143);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)888632883 ^ (long)888632960);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-2038488634 ^ (long)-2038488793);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1976517648 ^ (long)-1976517792);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1864598008 ^ (long)-1864597768);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-224202412 ^ (long)-224202484);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1061072993 ^ (long)-1061073062);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)72981053 ^ (long)72981037);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-967489537 ^ (long)-967489568);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)364698944 ^ (long)364699072);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-2058818597 ^ (long)-2058818807);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1599252142 ^ (long)1599251992);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)747908531 ^ (long)747908487);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-926421674 ^ (long)-926421574);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1008246113 ^ (long)1008246207);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1576042198 ^ (long)-1576042111);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)2141883379 ^ (long)2141883204);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)928368917 ^ (long)928368956);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1677732784 ^ (long)-1677732669);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1927246097 ^ (long)1927246251);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1924899510 ^ (long)1924899347);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-500595633 ^ (long)-500595482);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1137596541 ^ (long)-1137596517);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1752234817 ^ (long)-1752234970);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1399809654 ^ (long)1399809780);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1562382035 ^ (long)1562381941);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-2074281199 ^ (long)-2074281102);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)851692137 ^ (long)851692089);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1748218117 ^ (long)1748218136);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)174319898 ^ (long)174320107);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-703426578 ^ (long)-703426638);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)611318700 ^ (long)611318714);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1588306836 ^ (long)-1588306740);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-511345725 ^ (long)-511345719);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-837487358 ^ (long)-837487144);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1380295463 ^ (long)1380295633);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1585521095 ^ (long)1585520897);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)337008073 ^ (long)337008088);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-2110636625 ^ (long)-2110636662);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)389115970 ^ (long)389115918);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1244352863 ^ (long)-1244352915);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)406249452 ^ (long)406249352);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-436737081 ^ (long)-436737203);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1106340527 ^ (long)-1106340519);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)2007254667 ^ (long)2007254622);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1083436142 ^ (long)-1083436140);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-797093287 ^ (long)-797093176);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1956235593 ^ (long)1956235527);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1806833000 ^ (long)-1806833063);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1307780342 ^ (long)-1307780301);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1921687403 ^ (long)-1921687418);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1807063925 ^ (long)1807063971);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)960199444 ^ (long)960199651);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-723399084 ^ (long)-723399064);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-832935937 ^ (long)-832935986);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1567805132 ^ (long)-1567805072);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1686463891 ^ (long)1686463772);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-205448919 ^ (long)-205448860);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-155038731 ^ (long)-155038921);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1880202109 ^ (long)-1880201985);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1887995647 ^ (long)-1887995539);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-36852172 ^ (long)-36852013);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)852842213 ^ (long)852842210);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)425383354 ^ (long)425383289);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-2073477496 ^ (long)-2073477544);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1143854852 ^ (long)-1143854864);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-920274798 ^ (long)-920274877);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1237557301 ^ (long)1237557454);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)970901025 ^ (long)970901212);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-647123509 ^ (long)-647123525);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1754083090 ^ (long)-1754083086);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)991576278 ^ (long)991576246);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)575803897 ^ (long)575803800);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)308913030 ^ (long)308913068);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)94139495 ^ (long)94139473);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1918719050 ^ (long)-1918719100);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1403210532 ^ (long)-1403210619);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)530592623 ^ (long)530592761);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1627809749 ^ (long)1627809658);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)370186579 ^ (long)370186552);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-393417378 ^ (long)-393417274);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1509528960 ^ (long)-1509529031);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-616450556 ^ (long)-616450310);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1340887309 ^ (long)1340887333);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1342691693 ^ (long)1342691757);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-804194911 ^ (long)-804194856);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)280678514 ^ (long)280678447);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-511531835 ^ (long)-511531910);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1334976241 ^ (long)1334976185);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-716824617 ^ (long)-716824757);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1728619749 ^ (long)-1728619549);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1171590928 ^ (long)1171591073);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1710255701 ^ (long)-1710255800);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1118772291 ^ (long)1118772276);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)791855396 ^ (long)791855398);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)418764592 ^ (long)418764587);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)324179398 ^ (long)324179209);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1130100013 ^ (long)1130100078);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)790573988 ^ (long)790573984);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-556437122 ^ (long)-556437155);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1279954658 ^ (long)1279954560);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-393504787 ^ (long)-393504845);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)733246795 ^ (long)733246825);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)417544899 ^ (long)417544868);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)272409249 ^ (long)272409093);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1244333630 ^ (long)1244333604);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-839642477 ^ (long)-839642597);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-157089574 ^ (long)-157089612);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1410108229 ^ (long)-1410108304);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)522519978 ^ (long)522519815);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-949816532 ^ (long)-949816492);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-485904016 ^ (long)-485903995);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-2128618228 ^ (long)-2128618066);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1824541699 ^ (long)1824541782);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1020358124 ^ (long)-1020357961);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1258256490 ^ (long)1258256551);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1524189037 ^ (long)-1524189109);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-757033224 ^ (long)-757033261);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1451026128 ^ (long)-1451025941);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-513174726 ^ (long)-513174749);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1073256021 ^ (long)1073256167);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-2069654336 ^ (long)-2069654443);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1291680407 ^ (long)-1291680349);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1008201712 ^ (long)1008201603);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-2119208361 ^ (long)-2119208410);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1721045818 ^ (long)1721045940);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1764787594 ^ (long)-1764787632);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)296879012 ^ (long)296879009);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1688893154 ^ (long)1688893045);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)857332995 ^ (long)857333167);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)527262597 ^ (long)527262565);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1524249403 ^ (long)1524249426);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)418933966 ^ (long)418933882);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1328995577 ^ (long)1328995331);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)205127346 ^ (long)205127308);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1387589761 ^ (long)-1387589878);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)429563182 ^ (long)429563357);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1933516090 ^ (long)-1933516079);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-525748380 ^ (long)-525748427);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1345805495 ^ (long)-1345805374);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)411047394 ^ (long)411047408);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-2037024121 ^ (long)-2037024136);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)305797762 ^ (long)305797860);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-295864197 ^ (long)-295864311);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1729824190 ^ (long)-1729824039);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-284159411 ^ (long)-284159458);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1712632305 ^ (long)1712632258);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1031499719 ^ (long)-1031499646);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-558029444 ^ (long)-558029463);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-872436893 ^ (long)-872436954);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1174038768 ^ (long)1174038652);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1698521317 ^ (long)-1698521178);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)691144276 ^ (long)691144303);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-795444839 ^ (long)-795444770);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-715626771 ^ (long)-715626959);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1265746615 ^ (long)1265746617);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1750030256 ^ (long)1750030282);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-14803606 ^ (long)-14803472);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-443843726 ^ (long)-443843784);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)105753405 ^ (long)105753552);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)177947801 ^ (long)177947726);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1415562830 ^ (long)1415562760);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1650083942 ^ (long)1650084058);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)382713910 ^ (long)382713972);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-804262525 ^ (long)-804262528);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)140536330 ^ (long)140536416);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-375906934 ^ (long)-375906943);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)697337770 ^ (long)697337807);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1749035010 ^ (long)-1749035237);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-423817615 ^ (long)-423817716);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-874715000 ^ (long)-874715071);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-2105575393 ^ (long)-2105575247);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)566334535 ^ (long)566334713);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-397432701 ^ (long)-397432825);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)320130961 ^ (long)320131050);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)2102116214 ^ (long)2102116105);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-2138395499 ^ (long)-2138395555);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1872404963 ^ (long)1872404781);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)140087033 ^ (long)140087006);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1039681749 ^ (long)-1039681596);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-2002101754 ^ (long)-2002101721);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1902935173 ^ (long)-1902935093);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1632715466 ^ (long)-1632715402);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1764858781 ^ (long)-1764858741);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1446285632 ^ (long)1446285647);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-234060970 ^ (long)-234060969);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)908181334 ^ (long)908181387);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1741693283 ^ (long)-1741693264);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1317757184 ^ (long)1317757300);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1558768009 ^ (long)1558767899);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1024870126 ^ (long)1024869967);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-822030470 ^ (long)-822030385);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-2041601564 ^ (long)-2041601757);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1121535523 ^ (long)-1121535495);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)685978615 ^ (long)685978595);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)825300141 ^ (long)0x31311444);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-2082526866 ^ (long)-2082526890);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1280141484 ^ (long)-1280141395);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)47759869 ^ (long)47759715);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-2125168544 ^ (long)-2125168413);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)282893021 ^ (long)282893026);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1375539048 ^ (long)1375538944);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1199213056 ^ (long)-1199213009);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1052447230 ^ (long)1052446978);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1410007686 ^ (long)1410007660);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-494366834 ^ (long)-494366935);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1157113012 ^ (long)1157112969);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1076034603 ^ (long)-1076034707);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)711345828 ^ (long)711345750);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1087953703 ^ (long)1087953779);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1004524664 ^ (long)1004524754);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1359177530 ^ (long)1359177482);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1976024742 ^ (long)-1976024824);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)917280840 ^ (long)917280965);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-153278457 ^ (long)-153278235);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1857343310 ^ (long)-1857343379);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1237208810 ^ (long)-1237208579);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)640718575 ^ (long)640718521);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-34060904 ^ (long)-34060845);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1552663478 ^ (long)-1552663388);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-860034188 ^ (long)-860034059);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1679792266 ^ (long)1679792298);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1741933774 ^ (long)1741933731);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1270464595 ^ (long)1270464612);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1913727209 ^ (long)1913726989);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1262593722 ^ (long)-1262593575);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1054575290 ^ (long)1054575328);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-2016613222 ^ (long)-2016613282);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1341522150 ^ (long)-1341522068);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1522227700 ^ (long)1522227611);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)225905473 ^ (long)225905430);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-592595104 ^ (long)-592595091);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1587902718 ^ (long)1587902674);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1710506266 ^ (long)-1710506373);
                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1282241045 ^ (long)1282241102);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1281218837 ^ (long)-1281219052)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)662801214 ^ (long)662795457)) >>> (int)((long)1815900609 ^ (long)1815900617)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1883924775 ^ (long)1883924775);
            if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-687236095 ^ (long)-687236093);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1991648347 ^ (long)1991648344) | var5_6 << (int)((long)-1190152435 ^ (long)-1190152440)) ^ var3_4[var7_8]) & (int)((long)860701758 ^ (long)860701889);
                    if (3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1497405600 ^ (long)1497405603) | var6_7 << (int)((long)-1379079922 ^ (long)-1379079925)) ^ var3_4[var7_8]) & (int)((long)2002278089 ^ (long)2002277942);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3sH.b[var2_3] = new String(var3_4).intern();
        }
        return 3sH.b[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)1304743940 ^ (long)1304743942)];
            if (var7) break block16;
            var3_2 = (int)((long)847913386 ^ (long)847913386);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u4e50\uf2bb\ue16b\ue9dc\u4eeb\uf217\ue13b\ue9f7\u4e1a\uf298\ue185\ue911\u4e64\uf27c\ue178\ue95d\u4e04\uf268\ue174\ue93e\u4e00\uf2b6\ue139\ue9a2\u4e8f\uf290\ue1bc\ue996\u4ec5\uf248\ue1a3\ue97d\u4eda\uf24d\ue1a2\ue9b1\u4ee1\uf2ad\ue1df", -1824588626);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)1409630808 ^ (long)1409630814);
            if (var7) break block16;
            var0_6 = (int)((long)574781618 ^ (long)-574781619);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)345393372 ^ (long)-345393373);
                if (3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) continue block8;
                            throw null;
                        }
                        3sH.a = var5_1;
                        3sH.b = new String[(int)((long)1326254307 ^ (long)1326254305)];
                        if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)509036161 ^ (long)509036161);
                v5 = (int)((long)-849088488 ^ (long)-849088449);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)1146209583 ^ (long)1146209582)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-2124774243 ^ (long)-2124774246)) {
                                case 0: {
                                    v12 = (int)((long)-439241427 ^ (long)-439241420);
                                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)1789068571 ^ (long)1789068591);
                                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)443770134 ^ (long)443770219);
                                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)-912104485 ^ (long)-912104573);
                                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)440891417 ^ (long)440891505);
                                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)1810912287 ^ (long)1810912374);
                                    if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)1581481592 ^ (long)1581481520);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!3sH.\u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c) ** continue;
                throw null;
            }
        }
    }

    3sH() {
        boolean bl = \u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c;
        super(mc.J().e().getId());
        this.7 = mc.J().e().getId() == null ? null : 5S.8();
        3sn sn = this.6 = this.7 == null ? new 3sn() : 3sn.9(this.7);
        this.4 = (sn.7 == null ? Collections.emptyList() : Collections.unmodifiableList(Arrays.asList(sn.7))).stream().map(6O::6).filter(Objects::nonNull).collect(Collectors.toList());
    }

    private static /* synthetic */ boolean 8(6O o, 6O o2) {
        boolean bl = \u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c;
        if (bl || bl) {
            return true;
        }
        return o2.equals(o);
    }

    public final boolean 4(String object) {
        boolean bl = \u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c;
        if (bl || bl) {
            return true;
        }
        object = 6O.6((String)object);
        return this.4.stream().anyMatch(arg_0 -> 3sH.8((6O)object, arg_0));
    }

    public final boolean 1() {
        boolean bl = \u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c;
        if (bl || bl) {
            return true;
        }
        return this.4.stream().anyMatch(6O::3);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final 3R 4() {
        boolean bl = \u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c;
        if (bl || bl) return null;
        3R r2 = this.6.3;
        if (r2 == null) {
            if (bl) return null;
            return super.4();
        }
        if (!bl) return r2;
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public final boolean 0() {
        boolean bl = \u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c;
        if (bl || bl) return true;
        if (this.7 != null) {
            if (bl) return true;
            return (int)((long)-520449980 ^ (long)-520449979) != 0;
        }
        if (!bl) return (int)((long)1216823897 ^ (long)1216823897) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final URL 1() {
        boolean bl = \u2004\u2007\u2009\u2006\u200a\u200f\u2009\u200c;
        if (bl || bl) return null;
        String string = 3sH.a((int)((long)1357210485 ^ (long)-1357195848), (int)((long)-413452294 ^ (long)413447643)) /* "https://impactclient.net/account" */;
        if (bl || bl) return null;
        String string2 = 2w$6X.KAOZ("", 151374399);
        if (bl) return null;
        try {
            if (bl) return null;
            if (this.7 != null) {
                if (bl || bl) return null;
                string2 = 3sH.a((int)((long)1644172656 ^ (long)-1644190788), (int)((long)625488690 ^ (long)625486205)) /* "?auth=" */ + URLEncoder.encode(this.7.toString(), StandardCharsets.UTF_8.toString());
                if (bl) return null;
            }
            if (bl) return null;
            return new URL(string + string2);
        }
        catch (UnsupportedEncodingException | MalformedURLException iOException) {
            iOException.printStackTrace();
            if (bl || bl) return null;
            System.exit((int)((long)1670024792 ^ (long)1670024793));
            if (bl || bl) return null;
            return null;
        }
    }
}

