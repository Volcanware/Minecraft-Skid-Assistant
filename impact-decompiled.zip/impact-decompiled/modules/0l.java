/* ==========================================================================
 * MODULE: Baritone
 * CATEGORY (inferred): Misc
 * DESCRIPTION: Manage the Baritone settings
 * OBFUSCATED CLASS: net.impactclient.0l
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  baritone.api.BaritoneAPI
 *  baritone.api.Settings
 *  baritone.api.Settings$Setting
 *  baritone.api.event.events.PathEvent
 *  baritone.api.event.listener.AbstractGameEventListener
 *  baritone.api.event.listener.IGameEventListener
 *  bmb
 *  k
 *  nr
 */
package net.impactclient;

import baritone.api.BaritoneAPI;
import baritone.api.Settings;
import baritone.api.event.events.PathEvent;
import baritone.api.event.listener.AbstractGameEventListener;
import baritone.api.event.listener.IGameEventListener;
import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import net.impactclient.1E;
import net.impactclient.1P;
import net.impactclient.1X;
import net.impactclient.1e;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.34X;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3sC;
import net.impactclient.5p;
import net.impactclient.8z;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0l
extends 3X
implements AbstractGameEventListener,
34B {
    public 1P 1;
    private static final String[] d;
    private static final String[] e;
    public static final boolean \u2003\u200a\u2008\u2000;

    public static 1E<Float> 7(Settings.Setting<Float> setting, String string, String string2, float f, float f2) {
        boolean bl = \u2003\u200a\u2008\u2000;
        if (bl || bl) {
            return null;
        }
        return new 1E<Float>(setting, string, string2, Float.valueOf(f), Float.valueOf(f2), Number::floatValue);
    }

    public static 1e 0(Settings.Setting<Boolean> setting, String string, String string2) {
        boolean bl = \u2003\u200a\u2008\u2000;
        if (bl || bl) {
            return null;
        }
        return new 1e(setting, string, string2);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0l.\u2003\u200a\u2008\u2000;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-6701576 ^ (long)-6701627)];
            if (var7) break block23;
            var3_2 = (int)((long)-413097521 ^ (long)-413097521);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u9554\ubdf1\uae12\ua691\u9582\ubd6d\uaef1\ua636\u95a7\ubd55\uae20\ua601\u95eb\ubde3\uaec2\ua6c0\u95fb\ubd0c\uae38\ua6fb\u952e\ubd22\uae2c\ua6f1\u95e4\ubd5b\uae74\ua6f3\u95de\ubdc5\uaeb6\ua6b9\u95f2\ubd87\uae5e\ua6d0\u957a\ubd1c\uaefe\ua684\u9505\ubdcb\uae02\ua6d1\u9545\ubdbf\uae57\ua6b1\u95d8\ubdb4\uae57\ua6a0\u95c1\ubdf8\uaea3\ua64e\u953a\ubdce\uaeec\ua68a\u95b4\ubde6\uae6e\ua644\u95ed\ubd63\uaeb3\ua64e\u9592\ubd16\uae7e\ua673\u952b\ubd9f\uae76\ua602\u95ea\ubdfb\uaeb7\ua68e\u9568\ubd60\uae21\ua670\u950b\ubdce\uaee5\ua658\u95a4\ubdad\uaeca\ua65a\u95c9\ubd51\uaeb5\ua619\u9553\ubdb4\uae28\ua602\u9527\ubdac\uaeba\ua69c\u9532\ubdce\uaea2\ua617\u9532\ubdfa\uae91\ua6ca\u95e0\ubd1c\uae0a\ua620\u956d\ubd1b\uae1a\ua6d3\u95d7\ubd74\uae8b\ua6dd\u958d\ubd08\uae23\ua609\u95b1\ubd3c\uae51\ua600\u9533\ubdaa\uaed8\ua65b\u95a5\ubd06\uae71\ua6d2\u950d\ubd70\uaed5\ua6a6\u955e\ubdfd\uaefa\ua624\u95e3\ubd0c\uae73\ua663\u95e6\ubde7\uae3e\ua684\u95f6\ubdff\uae32\ua626\u95d2\ubd09\uae2c\ua6dc\u95ad\ubd03\uae62\ua624\u95ce\ubd19\uae7c\ua6aa\u95c9\ubd53\uae15\ua6ac\u954b\ubd7d\uae21\ua661\u95e9\ubd65\uaed1\ua6ce\u9584\ubdae\uaefa\ua6db\u95e4\ubd1f\uaebe\ua690\u9512\ubd58\uae48\ua6aa\u9503\ubd42\uae51\ua65f\u95d8\ubd0e\uae9a\ua68b\u95b6\ubd58\uaea0\ua6e8\u95e1\ubd33\uae07\ua624\u95f9\ubdd2\uaebc\ua6a8\u95b3\ubdf6\uae3f\ua614\u9579\ubd8e\uae1d\ua6f0\u9599\ubd63\uae1b\ua6d2\u95c9\ubd33\uae36\ua673\u950b\ubdad\uae55\ua694\u958e\ubd06\uaed1\ua6e0\u9590\ubd7b\uae2d\ua6c4\u95dc\ubd95\uaedb\ua6ac\u953d\ubdaf\uae60\ua676\u95d4\ubd40\uae39\ua662\u95f9\ubd91\uaea4\ua6f4\u95c9\ubdf1\uae40\ua6eb\u955c\ubd72\uae37\ua605\u9500\ubd35\uaef6\ua64a\u9547\ubd00\uae17\ua6cd\u95ad\ubd02\uae64\ua649\u9583\ubd62\uae9a\ua67d\u95ae\ubd95\uae93\ua60c\u951b\ubdee\uaec9\ua604\u9503\ubd1d\uae0d\ua603\u95e2\ubd1b\uae92\ua6a5\u95c2\ubde3\uaee9\ua679\u95f1\ubd08\uae04\ua63d\u9545\ubd3a\uae4b\ua64e\u954c\ubda8\uaefa\ua62a\u959d\ubdca\uaee8\ua696\u95c5\ubdc9\uae4e\ua64f\u9590\ubd92\uae30\ua696\u95d7\ubd9c\uae89\ua628\u9583\ubda2\uae90\ua6b2\u955e\ubdfd\uaeea\ua6c5\u95a9\ubdae\uae79\ua686\u95e0\ubd12\uae4e\ua61f\u952c\ubd62\uaec7\ua683\u95ca\ubd5f\uae72\ua6fb\u9582\ubd31\uae8b\ua69c\u954e\ubd47\uae1a\ua611\u956c\ubd38\uaef6\ua6e7\u9508\ubd31\uae69\ua692\u955a\ubdb0\uaefa\ua606\u954b\ubdf2\uaefe\ua658\u95c9\ubdbf\uaeb7\ua635\u953a\ubd2e\uae9c\ua67f\u95ac\ubd3b\uae46\ua69f\u95e6\ubdca\uae81\ua6f4\u9507\ubdf3\uae1c\ua6d3\u95a6\ubdbe\uae2f\ua68e\u95cb\ubdba\uae03\ua60a\u951d\ubdd8\uae08\ua61d\u9521\ubda5\uaebc\ua664\u95be\ubda3\uae82\ua60b\u95a0\ubd95\uaea9\ua6b3\u9512\ubd2e\uaea6\ua667\u9518\ubd68\uaec0\ua610\u9520\ubdc3\uae0f\ua657\u956e\ubdc6\uae49\ua6ab\u95ca\ubd5e\uaee0\ua67b\u95e9\ubdc5\uae49\ua635\u9507\ubd0a\uae4d\ua695\u95fe\ubd5a\uae31\ua624\u95ae\ubd62\uae79\ua657\u9531\ubde8\uae89\ua6cd\u95fb\ubd0c\uae3b\ua6df\u9530\ubd19\uaec0\ua601\u95eb\ubdaa\uae2d\ua626\u9546\ubdef\uae71\ua64d\u95a0\ubdb3\uae22\ua6ac\u951b\ubd31\uaef7\ua63a\u9596\ubdbb\uaee2\ua68b\u959b\ubd55\uaec9\ua61a\u9578\ubdcd\uae02\ua67f\u9524\ubd0c\uaeca\ua653\u95fe\ubd0b\uae5d\ua686\u95ad\ubd15\uae9b\ua636\u954b\ubd85\uae2b\ua637\u954a\ubd33\uaeb1\ua6ce\u9504\ubd36\uaeea\ua6c0\u955c\ubdb9\uaece\ua64c\u95dd\ubd8b\uae39\ua67a\u95df\ubda7\uaeb3\ua63a\u95bb\ubd0e\uae9b\ua6a3\u95cd\ubd03\uaed3\ua66e\u95c1\ubda9\uae1a\ua646\u9583\ubd88\uaecd\ua6e3\u95e3\ubd62\uae43\ua607\u9503\ubdf3\uae72\ua67f\u950e\ubdad\uaea1\ua643\u95f7\ubd54\uae92\ua604\u950f\ubdef\uae6e\ua6b8\u956d\ubd74\uaecf\ua654\u952d\ubd08\uaede\ua605\u9581\ubdd0\uae0f\ua683\u95e0\ubd70\uaeac\ua683\u95bb\ubdd5\uaed2\ua64d\u9519\ubd27\uae68\ua608\u95b8\ubd60\uae55\ua64d\u95df\ubdd6\uae09\ua6fb\u9529\ubd1e\uaefe\ua6c0\u9582\ubd30\uaed7\ua6f9\u9547\ubdf8\uae49\ua688\u9546\ubd2a\uae6d\ua6e7\u95e2\ubde0\uaecf\ua603\u95e6\ubde4\uae6f\ua6bb\u9544\ubdcd\uae19\ua698\u9563\ubd18\uae06\ua695\u950c\ubdab\uae9d\ua67c\u958b\ubde4\uaede\ua6d1\u958e\ubd1d\uae4c\ua662\u95bd\ubd4e\uaecc\ua616\u950c\ubd11\uae50\ua65c\u955a\ubd08\uae83\ua632\u9596\ubd59\uaead\ua6e4\u956d\ubda4\uae17\ua6bd\u9572\ubdc7\uaee1\ua633\u95f1\ubd96\uaed1\ua668\u95a8\ubdc0\uae9f\ua6d3\u95c0\ubd70\uaeec\ua6d4\u9549\ubd18\uae56\ua600\u955d\ubd9d\uaef0\ua633\u95e9\ubdea\uae34\ua635\u95ce\ubdfe\uaef7\ua634\u95f9\ubd77\uae14\ua657\u95bb\ubd51\uae48\ua66f\u9524\ubd89\uaea2\ua60c\u9552\ubd4b\uaeef\ua635\u95be\ubde4\uae8e\ua65e\u9575\ubd06\uae8c\ua6c6\u95c8\ubd62\uae7e\ua64a\u95a0\ubdfd\uae58\ua693\u9524\ubdb1\uae1d\ua6aa\u95cb\ubd9a\uae19\ua602\u95f4\ubd03\uae2f\ua6fb\u958b\ubdb2\uaeeb\ua6bb\u9530\ubdf1\uae97\ua6f7\u95c9\ubdda\uaecf\ua670\u9558\ubdd8\uaeec\ua6b4\u95b4\ubd06\uae51\ua6ec\u95dd\ubd1f\uaefe\ua65c\u95a5\ubdd2\uae9d\ua6a6\u9518\ubdbc\uae2f\ua6f3\u95c4\ubd4d\uae04\ua68c\u95ea\ubd18\uaeb3\ua635\u95fa\ubdd1\uaea7\ua660\u95ba\ubd67\uaeb6\ua64a\u953a\ubd91\uae47\ua678\u9516\ubd16\uaee7\ua6e1\u9566\ubd1f\uae61\ua633\u959c\ubdd7\uaec0\ua635\u95d7\ubded\uaec9\ua643\u95e1\ubd8f\uae02\ua606\u9555\ubd93\uae02\ua6f7\u9597\ubd76\uaebd\ua6c4\u9599\ubdbf\uae9b\ua651\u95e3\ubd5e\uaeb7\ua63a\u9557\ubdff\uae9d\ua647\u95d9\ubd06\uae45\ua602\u9582\ubd4d\uae89\ua6d6\u952c\ubd1b\uae2f\ua60b\u954e\ubd97\uae41\ua612\u956c\ubdaf\uae16\ua690\u9552\ubd80\uaef9\ua639\u9554\ubd21\uae51\ua6ff\u9562\ubd09\uae73\ua631\u9526\ubdee\uae58\ua674\u9542\ubd09\uae1c\ua645\u9517\ubd50\uaeac\ua6f4\u956f\ubd62\uae5c\ua6de\u95fb\ubd1e\uae52\ua6c6\u9573\ubde9\uae5e\ua6a8\u95f3\ubdc4\uae7c\ua6fd\u9589\ubd5d\uaea6\ua601\u958c\ubdde\uaedd\ua635\u9581\ubdc5\uaeca\ua6af\u9504\ubd62\uae12\ua69c\u955d\ubd93\uaeee\ua6ad\u95df\ubdff\uaec1\ua646\u9513\ubdc3\uae5d\ua693\u95a9\ubdd5\uae27\ua611\u957e\ubd11\uae6d\ua668\u950a\ubd01\uae14\ua6a2\u9500\ubdee\uaea8\ua6f2\u951d\ubd9d\uae00\ua62d\u954b\ubde5\uae33\ua65a\u95ad\ubde0\uaed5\ua666\u9542\ubddb\uaecc\ua64c\u95b4\ubda7\uae3a\ua6da\u95b7\ubddd\uae1c\ua69f\u9514\ubd3b\uae9e\ua66e\u95c6\ubdb7\uaebd\ua694\u95fc\ubdd2\uaec9\ua6bd\u953e\ubd6d\uaedb\ua691\u9534\ubdab\uae4e\ua671\u9545\ubd04\uaef0\ua62c\u957c\ubd96\uae88\ua6d5\u95fe\ubd6a\uaee5\ua663\u9503\ubd8c\uaef8\ua64c\u9569\ubda9\uaeb8\ua6a7\u95a8\ubdb5\uaee4\ua61b\u95e6\ubd0f\uaeb5\ua6ef\u95be\ubdd6\uaef4\ua651\u956a\ubdff\uae3e\ua6f7\u95a5\ubdc0\uae8d\ua63d\u9539\ubd36\uae77\ua665\u9547\ubd42\uae0d\ua6c7\u9549\ubd0e\uae93\ua6d7\u956b\ubd50\uaed3\ua604\u95c4\ubded\uae5d\ua6af\u9588\ubddf\uae65\ua653\u9548\ubd43\uae38\ua6f3\u95bb\ubdff\uae6b\ua630\u959e\ubd7a\uae75\ua663\u9569\ubdc4\uaec5\ua615\u95eb\ubd8d\uaecc\ua63c\u95b7\ubd22\uae53\ua6b3\u9529\ubdf8\uae6e\ua6f3\u9578\ubd03\uae41\ua6ba\u95d2\ubde4\uaeee\ua6b0\u9544\ubdb3\uaeaa\ua64d\u9584\ubdae\uae3b\ua693\u954e\ubd72\uae70\ua6d5\u9508\ubd30\uaea4\ua628\u959e\ubd46\uaeec\ua618\u95fb\ubde0\uae95\ua691\u9523\ubd05\uaea7\ua689\u95de\ubd33\uae52\ua605\u9577\ubdfa\uae60\ua692\u958f\ubdaa\uae8a\ua675\u957b\ubdd6\uaef7\ua675\u953e\ubdf1\uae66\ua6b8\u9552\ubd38\uae63\ua6fe\u95dd\ubd18\uaeca\ua654\u953d\ubd8a\uaec7\ua6d6\u9509\ubd15\uae1d\ua64b\u9592\ubdf4\uaeb1\ua697\u9518\ubd9b\uae0c\ua666\u954c\ubd0f\uaebd\ua6c0\u9593\ubd8c\uae72\ua6b1\u95dd\ubd58\uae3f\ua664\u9525\ubdd4\uae16\ua668\u9526\ubd33\uaefb\ua609\u9514\ubd02\uae33\ua61d\u9541\ubd08\uae6d\ua64f\u9584\ubdcd\uae29\ua622\u9523\ubdf9\uaec9\ua6c3\u957f\ubd43\uae29\ua6df\u95e5\ubda7\uae1c\ua679\u95ad\ubd88\uae17\ua6ba\u955c\ubd0c\uae98\ua629\u95c3\ubda1\uaee1\ua658\u95b8\ubde5\uae7c\ua64d\u9523\ubd21\uaea0\ua683\u95cd\ubd05\uae33\ua6b8\u954f\ubda0\uae11\ua68a\u950e\ubd69\uae5b\ua6f9\u95bb\ubdc6\uae9f\ua6d8\u95d4\ubd3b\uae05\ua661\u95bd\ubd91\uae34\ua6c0\u95a2\ubdcc\uae1e\ua682\u9531\ubd23\uae5a\ua652\u95ec\ubd2b\uae13\ua68b\u95e3\ubd80\uae0e\ua64f\u9543\ubd76\uaec5\ua61a\u95ef\ubdab\uae13\ua61a\u95ea\ubda5\uaef1\ua6af\u9520\ubdf7\uaeab\ua62e\u95bf\ubd70\uaeb3\ua657\u952d\ubdf7\uaef7\ua6c9\u952c\ubd7c\uaeaa\ua6f8\u9557\ubdf7\uae96\ua6fa\u9573\ubd25\uae9a\ua673\u95bf\ubd59\uaebf\ua68c\u95c2\ubd06\uae53\ua6f1\u95cd\ubd5f\uae3b\ua616\u957f\ubd43\uae0b\ua60c\u95b7\ubd03\uae9c\ua66a\u95fe\ubdfc\uae7f\ua6d8\u95ea\ubdb1\uaeb3\ua6e8\u95dd\ubd54\uae9b\ua6fa\u95f8\ubdff\uaea5\ua6dd\u9579\ubd6a\uae7a\ua632\u95bf\ubd3c\uaec9\ua668\u959e\ubd6c\uae5f\ua664\u9536\ubd80\uae61\ua617\u95ea\ubd18\uae15\ua60d\u95c9\ubd9b\uae6f\ua6cd\u95e6\ubdfe\uae94\ua648\u95ad\ubd1f\uae7e\ua6a6\u9588\ubd70\uae5a\ua609\u959b\ubddf\uaeaa\ua61c\u9541\ubd40\uae10\ua65a\u95e3\ubd02\uaedd\ua68d\u9535\ubd59\uae10\ua6b4\u9590\ubd4f\uae33\ua649\u95c8\ubda8\uaea5\ua6a8\u9537\ubd74\uae45\ua667\u95b5\ubde0\uae43\ua601\u9597\ubdc6\uae91\ua62d\u9514\ubd58\uae45\ua6d9\u9572\ubdd1\uae9d\ua66c\u954b\ubd51\uae65\ua6c6\u9524\ubd8b\uae6e\ua643\u9553\ubd73\uae42\ua660\u95cf\ubdcf\uae53\ua644\u9528\ubda7\uae9d\ua688\u95dc\ubd70\uae90\ua63d\u95f7\ubd30\uaebc\ua680\u95b5\ubdac\uaeea\ua687\u9560\ubdc9\uae10\ua680\u9553\ubdf8\uae22\ua6d1\u9589\ubd73\uaedd\ua60c\u9505\ubdf6\uaeca\ua6d0\u95f4\ubd7a\uae62\ua6fb\u95ce\ubd02\uae1f\ua666\u95cf\ubd82\uae63\ua647\u9569\ubd7c\uae8c\ua677\u95f9\ubd47\uaed9\ua6c4\u9544\ubd14\uae69\ua6ee\u9537\ubd27\uaeaa\ua6a8\u957d\ubd13\uae51\ua671\u9586\ubd66\uae55\ua630\u95b3\ubd65\uae30\ua6cf\u95f8\ubd03\uaebc\ua6e5\u9530\ubddd\uae89\ua656\u958f\ubd5f\uae1b\ua657\u954d\ubde1\uae6c\ua6a9\u95ec\ubdea\uae84\ua6f1\u954d\ubd19\uae6f\ua6ac\u9520\ubd97\uaeed\ua611\u9592\ubd1e\uae23\ua669\u9513\ubd57\uaefa\ua645\u959f\ubdf7\uae52\ua665\u95d3\ubd3f\uaeae\ua64c\u953a\ubd4a\uaef8\ua6f5\u95bd\ubd2c\uae24\ua6d2\u9523\ubd3b\uaee8\ua68e\u95c0\ubddd\uaebf\ua6bc\u9531\ubd6d\uae72\ua6af\u95be\ubd40\uae4d\ua6f0\u95a2\ubddd\uae72\ua62c\u9593\ubd93\uae1c\ua638\u9591\ubd4e\uae89\ua6ad\u9509\ubd04\uae23\ua68e\u95c1\ubdbc\uaee4\ua6cc\u9520\ubddd\uae75\ua6dc\u95e3\ubde6\uaec6\ua6d7\u95f2\ubdfd\uae10\ua65e\u95f1\ubd10\uaea1\ua647\u95cc\ubd64\uaef9\ua69b\u95f3\ubd91\uae38\ua62b\u95c7\ubdab\uaee7\ua61d\u95da\ubdd8\uae7b\ua644\u95ce\ubd6e\uae67\ua626\u9529\ubdcb\uae9d\ua6c1\u954e\ubd9b\uaef2\ua679\u9541\ubd9f\uae1a\ua699\u9599\ubd1d\uaeb3\ua653\u95e6\ubde3\uae23\ua659\u95ee\ubdae\uae8f\ua6fc\u9502\ubda7\uaed8\ua61d\u9572\ubdad\uaea0\ua6f0\u958f\ubde4\uae47\ua682\u95c5\ubd6f\uae71\ua648\u9560\ubdac\uae78\ua630\u9590\ubd28\uae5e\ua6a1\u9579\ubd2b\uaebd\ua644\u959c\ubde3\uae0a\ua630\u954b\ubdf8\uae46\ua6e2\u95e5\ubdc9\uaece\ua6d7\u955b\ubdb0\uaec7\ua6a5\u9594\ubdc9\uae39\ua639\u953b\ubd43\uaea2\ua6bf\u952f\ubdf6\uaecb\ua639\u9500\ubd41\uae9e\ua69c\u9576\ubdf2\uaeec\ua6d7\u95d9\ubdf1\uae72\ua6f6\u95f7\ubd97\uae25\ua63f\u95eb\ubd30\uaee9\ua64b\u959a\ubd08\uaed1\ua6e6\u953c\ubd19\uaea9\ua6b7\u950d\ubdb5\uaee3\ua631\u9553\ubdf3\uae92\ua6d6\u9560\ubd35\uae66\ua6a0\u95cd\ubdb2\uaef1\ua6c7\u959e\ubd13\uaebd\ua6d9\u959b\ubdd3\uae07\ua69d\u9586\ubde5\uae53\ua64e\u954e\ubd38\uae9e\ua699\u9592\ubdb5\uae05\ua61a\u9514\ubdfb\uaed6\ua6f2\u95d9\ubd3f\uae90\ua6ff\u95dd\ubd4d\uaee4\ua69a\u9579\ubdc4\uae6d\ua61d\u959e\ubd7c\uaebe\ua69c\u95a9\ubd3e\uae41\ua6f2\u958f\ubd3f\uae73\ua600\u9568\ubdc5\uae23\ua62c\u955c\ubdc6\uaec9\ua649\u9512\ubd22\uae7d\ua6a1\u95aa\ubd4e\uaea0\ua6b9\u9547\ubd25\uaeba\ua66c\u95b0\ubd1a\uaed8\ua631\u95c6\ubd37\uaebb\ua62b\u95e3\ubd87\uaeb8\ua6e7\u95e6\ubd51\uae64\ua68c\u9573\ubd40\uae1e\ua66c", -1485458503);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)913751463 ^ (long)913751477);
            if (var7) break block23;
            var0_6 = (int)((long)1775168856 ^ (long)-1775168857);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)2075791963 ^ (long)2075791940);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)731085969 ^ (long)-731085970);
                    if (0l.\u2003\u200a\u2008\u2000) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0l.\u2003\u200a\u2008\u2000) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u7480\u5cac\u4f2f\u4755\u74aa\u5cf5\u4f2f\u47e1\u7427\u5c79\u4f1d\u4746\u7486\u5c5e\u4f52\u47f9\u74c8\u5c6e\u4fe0\u47e3\u7403\u5c6a\u4f28\u47d9\u74dd\u5c2e\u4fb6\u4762\u7444\u5cef\u4ffc\u47d1\u74da\u5c38\u4f0e\u4717\u743a\u5c76\u4f93\u477f", 1853313742);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1800614709 ^ (long)-1800614718);
                            var0_6 = (int)((long)-1697966505 ^ (long)1697966504);
                            while (true) {
                                v0 = (int)((long)943222749 ^ (long)943222727);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1713730371 ^ (long)-1713730371);
                                if (!0l.\u2003\u200a\u2008\u2000) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0l.\u2003\u200a\u2008\u2000) ** continue;
                                throw null;
                            }
                            0l.d = var5_1;
                            0l.e = new String[(int)((long)-770983236 ^ (long)-770983295)];
                            if (!0l.\u2003\u200a\u2008\u2000) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1005607675 ^ (long)1005607675);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)646393221 ^ (long)646393220)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-2058745322 ^ (long)-2058745327)) {
                                case 0: {
                                    v15 = (int)((long)464375548 ^ (long)464375506);
                                    if (!0l.\u2003\u200a\u2008\u2000) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)2007172919 ^ (long)2007172936);
                                    if (!0l.\u2003\u200a\u2008\u2000) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1827595742 ^ (long)1827595691);
                                    if (!0l.\u2003\u200a\u2008\u2000) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1697726181 ^ (long)-1697726157);
                                    if (!0l.\u2003\u200a\u2008\u2000) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1570927469 ^ (long)-1570927393);
                                    if (!0l.\u2003\u200a\u2008\u2000) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-978148399 ^ (long)-978148354);
                                    if (!0l.\u2003\u200a\u2008\u2000) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-852395391 ^ (long)-852395327);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0l.\u2003\u200a\u2008\u2000);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0l.\u2003\u200a\u2008\u2000;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1331560086 ^ (long)-1331548150)) & (int)((long)456420273 ^ (long)456430670);
            if (var9_2) ** GOTO lbl-1000
            if (0l.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0l.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-280849525 ^ (long)-280849525)] & (int)((long)422331465 ^ (long)422331574)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1090234316 ^ (long)1090234245);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1900267386 ^ (long)1900267350);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1812360370 ^ (long)1812360221);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1917827797 ^ (long)-1917827813);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)920854306 ^ (long)920854430);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1219653108 ^ (long)1219652917);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-581892468 ^ (long)-581892538);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)740619785 ^ (long)740619988);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1501846255 ^ (long)-1501846225);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-88535320 ^ (long)-88535398);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-196946537 ^ (long)-196946598);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-521356838 ^ (long)-521356867);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-458874011 ^ (long)-458874076);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1680299972 ^ (long)1680299877);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1360119827 ^ (long)-1360119842);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)641311604 ^ (long)641311606);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)517445028 ^ (long)517445072);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1833160525 ^ (long)-1833160623);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-507585998 ^ (long)-507585868);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)51425581 ^ (long)51425678);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-654536536 ^ (long)-654536513);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)767098685 ^ (long)767098813);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)2041848297 ^ (long)2041848079);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1511779525 ^ (long)-1511779452);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1826819692 ^ (long)1826819673);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-2079826201 ^ (long)-2079826336);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1914553902 ^ (long)1914553901);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-197058704 ^ (long)-197058731);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-2044190546 ^ (long)-2044190622);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-442456309 ^ (long)-442456309);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1474192684 ^ (long)-1474192844);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)87985021 ^ (long)87984928);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1807080350 ^ (long)-1807080359);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-569401940 ^ (long)-569401874);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-68903859 ^ (long)-68903740);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)158163552 ^ (long)158163711);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1963453977 ^ (long)-1963454051);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)522684024 ^ (long)522683947);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)759615195 ^ (long)759615006);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)844815201 ^ (long)844815290);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)194371904 ^ (long)194372090);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)688912892 ^ (long)688912657);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)855518570 ^ (long)855518566);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-28868255 ^ (long)-28868154);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-2039321150 ^ (long)-2039321180);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-170379156 ^ (long)-170379187);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)966932779 ^ (long)966932790);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1105661200 ^ (long)1105661311);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1611711653 ^ (long)1611711721);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-630384380 ^ (long)-630384185);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1545032927 ^ (long)-1545032908);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)729311593 ^ (long)729311635);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)504885051 ^ (long)504885039);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)176794645 ^ (long)176794700);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-837964746 ^ (long)-837964576);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1599274747 ^ (long)1599274703);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1895338037 ^ (long)-1895338139);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)611259368 ^ (long)611259376);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1286265199 ^ (long)1286265278);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1765647483 ^ (long)1765647488);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)932301234 ^ (long)932301274);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1517856761 ^ (long)-1517856621);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1470137410 ^ (long)-1470137524);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)351276579 ^ (long)351276562);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-2137636900 ^ (long)-2137637061);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)399696293 ^ (long)399696202);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-2122258266 ^ (long)-2122258237);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-371795689 ^ (long)-371795679);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1374635791 ^ (long)-1374635807);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-2074924892 ^ (long)-2074924854);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1835392687 ^ (long)-1835392751);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)680618811 ^ (long)680618770);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1913394565 ^ (long)-1913394579);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1745692296 ^ (long)1745692221);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-754623888 ^ (long)-754623807);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1396699775 ^ (long)1396699797);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-658259232 ^ (long)-658259225);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1847809569 ^ (long)-1847809667);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1957496681 ^ (long)-1957496805);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)134886102 ^ (long)134885958);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1164129200 ^ (long)-1164129031);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)624697688 ^ (long)624697751);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)630554823 ^ (long)630554840);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-208460709 ^ (long)-208460793);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-388433843 ^ (long)-388433911);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1327127163 ^ (long)-1327127229);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1638003308 ^ (long)1638003299);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-195236780 ^ (long)-195236793);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1885240169 ^ (long)1885240075);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)827255480 ^ (long)827255296);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-2072933735 ^ (long)-2072933797);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)270833466 ^ (long)270833443);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)395821142 ^ (long)395821277);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-404898147 ^ (long)-404898105);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-366008163 ^ (long)-366008220);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-295145021 ^ (long)-295145090);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)737738870 ^ (long)737738860);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-2025466106 ^ (long)-2025465960);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1107393530 ^ (long)-1107393392);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)2120882312 ^ (long)2120882392);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1909639242 ^ (long)-1909639226);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1461721164 ^ (long)1461721187);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1260280240 ^ (long)-1260280143);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)2006093779 ^ (long)2006093600);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1168944252 ^ (long)-1168944278);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1006607958 ^ (long)-1006607992);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-293765710 ^ (long)-293765848);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-74076597 ^ (long)-74076490);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1206945104 ^ (long)1206945113);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1618093601 ^ (long)-1618093689);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1324310248 ^ (long)-1324310033);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1393416267 ^ (long)-1393416210);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1088321866 ^ (long)-1088321930);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)819421737 ^ (long)819421806);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1054143047 ^ (long)1054143107);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1457336192 ^ (long)-1457336194);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1210560771 ^ (long)-1210560897);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-888732219 ^ (long)-888732255);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1793215769 ^ (long)-1793215818);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)689955706 ^ (long)689955764);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-935041778 ^ (long)-935041645);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)82107749 ^ (long)0x4E4DDDE);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)671150071 ^ (long)671149905);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1152881167 ^ (long)-1152881306);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)395948276 ^ (long)395948282);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1210615855 ^ (long)-1210615834);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1951320240 ^ (long)-1951320259);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1296913789 ^ (long)-1296913824);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1205402133 ^ (long)-1205402313);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-358131525 ^ (long)-358131690);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)25153081 ^ (long)25153092);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-981801476 ^ (long)-981801590);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-2021647091 ^ (long)-2021647096);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)272604428 ^ (long)272604446);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)443840755 ^ (long)443840705);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)186874409 ^ (long)186874560);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1673220383 ^ (long)1673220555);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)148834450 ^ (long)148834337);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-48697362 ^ (long)-48697413);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1438196823 ^ (long)1438196914);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1141193293 ^ (long)1141193323);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1792273565 ^ (long)1792273420);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)2010787227 ^ (long)2010787313);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)552186286 ^ (long)552186165);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)63331319 ^ (long)63331290);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)346357274 ^ (long)346357320);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1881328701 ^ (long)-1881328892);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-82585822 ^ (long)-82585766);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-479330629 ^ (long)-479330777);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-830509870 ^ (long)-830509906);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-379989612 ^ (long)-379989698);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)87845462 ^ (long)87845403);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1718153552 ^ (long)1718153603);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1519908235 ^ (long)-1519908219);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-896876086 ^ (long)-896876130);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1557802332 ^ (long)-1557802453);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)275524896 ^ (long)275524991);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)955852753 ^ (long)955852602);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)947966196 ^ (long)947966167);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)100722815 ^ (long)100722741);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1260123285 ^ (long)-1260123193);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1704082795 ^ (long)-1704082924);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)817726478 ^ (long)817726605);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1273622214 ^ (long)-1273622074);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1198083758 ^ (long)1198083716);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)547994062 ^ (long)547994051);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1585717474 ^ (long)-1585717407);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1817153324 ^ (long)-1817153412);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1967820063 ^ (long)1967820156);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)750893090 ^ (long)750893193);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1276848914 ^ (long)1276848997);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1040182311 ^ (long)1040182272);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-374155382 ^ (long)-374155342);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-106916212 ^ (long)-106916321);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-569373313 ^ (long)-569373371);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1640152205 ^ (long)1640152230);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-979185356 ^ (long)-979185348);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1748607183 ^ (long)1748607034);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1739938204 ^ (long)1739938293);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1474077981 ^ (long)1474078099);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)489816146 ^ (long)489816294);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1811862108 ^ (long)-1811862268);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1026352736 ^ (long)1026352790);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-2135263593 ^ (long)-2135263506);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1063027347 ^ (long)1063027254);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1661098150 ^ (long)-1661098175);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)465897780 ^ (long)465897739);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)918273053 ^ (long)918273177);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1855335296 ^ (long)1855335263);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1882620515 ^ (long)-1882620629);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1247873633 ^ (long)-1247873567);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1242870910 ^ (long)1242870878);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1343249141 ^ (long)1343249083);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)784405258 ^ (long)784405355);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1719960461 ^ (long)1719960476);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-244796153 ^ (long)-244795938);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-346077428 ^ (long)-346077228);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1019060168 ^ (long)1019060076);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-999624079 ^ (long)-999624135);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1067867023 ^ (long)1067867025);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)92591275 ^ (long)92591137);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1451827778 ^ (long)-1451827968);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)879479058 ^ (long)879479202);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-222223386 ^ (long)-222223560);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1667556043 ^ (long)-1667555875);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)820093128 ^ (long)820093096);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1133009284 ^ (long)-1133009357);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-624189989 ^ (long)-624189987);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1161462787 ^ (long)-1161462966);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-812982069 ^ (long)-812982220);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)269966492 ^ (long)269966350);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1371938671 ^ (long)-1371938727);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1590235108 ^ (long)1590235128);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)59515573 ^ (long)59515453);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-842625824 ^ (long)-842625831);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)689013442 ^ (long)689013302);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-456016440 ^ (long)-456016498);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1582782304 ^ (long)1582782270);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1837150682 ^ (long)-1837150529);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1355675379 ^ (long)-1355675194);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)29821052 ^ (long)29820992);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-288675009 ^ (long)-288675045);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)878587137 ^ (long)878587183);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-625571938 ^ (long)-625571942);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-283630950 ^ (long)-283630881);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1812565633 ^ (long)1812565673);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)2114636597 ^ (long)2114636643);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1005554945 ^ (long)1005555158);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-983590052 ^ (long)-983590057);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1556402070 ^ (long)1556402034);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1313302169 ^ (long)1313302036);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)166702874 ^ (long)166702937);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-848732163 ^ (long)-848732296);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)574686968 ^ (long)574686729);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-377863750 ^ (long)-377863832);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-961023596 ^ (long)-961023636);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1613865023 ^ (long)1613865101);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-74193637 ^ (long)-74193647);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)684866730 ^ (long)684866711);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1012805056 ^ (long)-1012805055);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1621720283 ^ (long)-1621720065);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-695949476 ^ (long)-695949419);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1917549719 ^ (long)-1917549639);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-180279768 ^ (long)-180279619);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-479909231 ^ (long)-479909148);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-348497987 ^ (long)-348498172);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1250189893 ^ (long)-1250189844);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-2103765357 ^ (long)-2103765249);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1342046521 ^ (long)1342046538);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1097802272 ^ (long)-1097802357);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1525018521 ^ (long)-1525018596);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-2047642720 ^ (long)-2047642671);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-81634337 ^ (long)-81634412);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1012458831 ^ (long)1012458915);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1336363150 ^ (long)-1336363097);
                    if (!0l.\u2003\u200a\u2008\u2000) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)174789116 ^ (long)174788964);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1195469081 ^ (long)-1195469288)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)921017403 ^ (long)921002948)) >>> (int)((long)1823681621 ^ (long)1823681629)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-561205522 ^ (long)-561205522);
            if (!0l.\u2003\u200a\u2008\u2000) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-46236999 ^ (long)-46236997);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)52030000 ^ (long)52030003) | var5_6 << (int)((long)1993315446 ^ (long)1993315443)) ^ var3_4[var7_8]) & (int)((long)-1960376826 ^ (long)-1960376583);
                    if (0l.\u2003\u200a\u2008\u2000) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)669222791 ^ (long)669222788) | var6_7 << (int)((long)-577207063 ^ (long)-577207060)) ^ var3_4[var7_8]) & (int)((long)1385330570 ^ (long)1385330549);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0l.e[var2_3] = new String(var3_4).intern();
        }
        return 0l.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void onPathEvent(PathEvent pathEvent) {
        boolean bl;
        block12: {
            int n;
            int n2;
            block10: {
                int n3;
                block9: {
                    String[] stringArray;
                    block11: {
                        bl = \u2003\u200a\u2008\u2000;
                        if (bl) return;
                        stringArray = 3e.5();
                        if (bl) return;
                        if (bl) return;
                        if (0l.3.s == null) {
                            if (bl) return;
                            if (bl) return;
                            return;
                        }
                        if (bl) return;
                        if (pathEvent == PathEvent.CALC_FINISHED_NOW_EXECUTING) break block11;
                        if (bl) return;
                        if (pathEvent != PathEvent.CALC_FAILED) break block12;
                        if (bl) return;
                    }
                    if (bl) return;
                    pathEvent = 0l.3.s.bm.a;
                    if (bl) return;
                    if (bl) return;
                    n3 = (int)((long)-147879905 ^ (long)-147879905);
                    if (bl) return;
                    n2 = (int)((long)-1175776153 ^ (long)-1175776153);
                    if (bl) return;
                    if (bl) return;
                    int n4 = (int)((long)-558694364 ^ (long)-558694364);
                    if (bl) return;
                    do {
                        if (bl) return;
                        if (n4 >= pathEvent.size()) break block9;
                        if (bl) return;
                        if (bl) return;
                        n = ((List)BaritoneAPI.getSettings().acceptableThrowawayItems.value).contains(((bmb)pathEvent.get(n4)).b()) ? 1 : 0;
                        if (stringArray != null) break block10;
                        if (n != 0) {
                            if (bl) return;
                            if (bl) return;
                            if (n4 < (int)((long)1130565776 ^ (long)1130565785)) {
                                if (bl) return;
                                n3 = (int)((long)275366247 ^ (long)275366246);
                                if (bl) return;
                            }
                            if (bl) return;
                            if (n4 >= (int)((long)1240942018 ^ (long)1240942027)) {
                                if (bl) return;
                                n2 = (int)((long)-1096866821 ^ (long)-1096866822);
                                if (bl) return;
                            }
                        }
                        if (bl) return;
                        ++n4;
                        if (bl) return;
                    } while (stringArray == null);
                    if (bl) return;
                }
                if (bl) return;
                n = n3;
            }
            if (n == 0) {
                if (bl) return;
                if (n2 != 0) {
                    if (bl) return;
                    if (((Boolean)BaritoneAPI.getSettings().allowPlace.value).booleanValue()) {
                        if (bl) return;
                        if (bl) return;
                        k[] kArray = new k[(int)((long)2040451412 ^ (long)2040451413)];
                        kArray[(int)((long)1279055280 ^ (long)1279055280)] = k.m;
                        k[] kArray2 = kArray;
                        5p.9((nr)new 3sC().2((String)0l.b((int)((int)((long)-2124716441 ^ (long)-2124720374)), (int)((int)((long)-52611368 ^ (long)-52610165))), null, (k[])kArray2).7);
                        if (bl) return;
                    }
                }
            }
        }
        if (bl) return;
    }

    public static 1E<Double> 6(Settings.Setting<Double> setting, String string, String string2, double d, double d2) {
        boolean bl = \u2003\u200a\u2008\u2000;
        if (bl || bl) {
            return null;
        }
        return new 1E<Double>(setting, string, string2, d, d2, Number::doubleValue);
    }

    public 0l() {
        boolean bl = \u2003\u200a\u2008\u2000;
        super(0l.b((int)((long)1883989880 ^ (long)1883985464), (int)((long)1553324147 ^ (long)-1553317550)) /* "Baritone" */, 0l.b((int)((long)460993812 ^ (long)460981341), (int)((long)1270097012 ^ (long)1270089960)) /* "Manage the Baritone settings" */);
        Boolean bl2 = Boolean.TRUE;
        34X x = (34X)((34X)((34X)this.4().5(0l.b((int)((long)574512104 ^ (long)574515887), (int)((long)-1443827292 ^ (long)1443827006)) /* "Combat Pause" */)).7(0l.b((int)((long)1710257229 ^ (long)1710245160), (int)((long)-1425737884 ^ (long)1425764938)) /* "targetPause" */)).1(0l.b((int)((long)-140233105 ^ (long)-140245248), (int)((long)-1806597605 ^ (long)1806575900)) /* "Pause when engaging a target" */);
        ((34X)((34X)((34X)this.4().5(0l.b((int)((long)574512104 ^ (long)574515887), (int)((long)-1443827292 ^ (long)1443827006)) /* "Combat Pause" */)).7(0l.b((int)((long)1710257229 ^ (long)1710245160), (int)((long)-1425737884 ^ (long)1425764938)) /* "targetPause" */)).1(0l.b((int)((long)-140233105 ^ (long)-140245248), (int)((long)-1806597605 ^ (long)1806575900)) /* "Pause when engaging a target" */)).7 = bl2;
        this.1 = (1P)x.5();
        2R.1(this, 0l.b((int)((long)1138698571 ^ (long)1138694179), (int)((long)1595582024 ^ (long)-1595582589)) /* "stateless" */, Boolean.TRUE);
        x = BaritoneAPI.getSettings();
        8z[] zArray = new 8z[(int)((long)2023046398 ^ (long)2023046373)];
        zArray[(int)((long)-911706399 ^ (long)-911706399)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).allowBreak, 0l.b((int)((long)991695756 ^ (long)991699675), (int)((long)-1109935533 ^ (long)-1109930526)) /* "Allow Break" */, 0l.b((int)((long)-908357567 ^ (long)-908353251), (int)((long)-384369875 ^ (long)-384392161)) /* "Allow Baritone to break blocks" */);
        zArray[(int)((long)-226832004 ^ (long)-226832003)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).allowPlace, 0l.b((int)((long)1684277174 ^ (long)1684289247), (int)((long)792579195 ^ (long)792572159)) /* "Allow Place" */, 0l.b((int)((long)-771074009 ^ (long)-771069606), (int)((long)-1115918197 ^ (long)1115925922)) /* "Allow Baritone to place blocks" */);
        zArray[(int)((long)-801645385 ^ (long)-801645387)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).allowSprint, 0l.b((int)((long)-1677350656 ^ (long)-1677354919), (int)((long)-797220362 ^ (long)797215936)) /* "Allow Sprint" */, 0l.b((int)((long)229864835 ^ (long)229852391), (int)((long)-509950943 ^ (long)-509955632)) /* "Allow Baritone to sprint" */);
        zArray[(int)((long)-938813655 ^ (long)-938813654)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).allowParkour, 0l.b((int)((long)-1090436608 ^ (long)-1090423989), (int)((long)1760121034 ^ (long)1760104213)) /* "Allow Parkour" */, 0l.b((int)((long)-1149785992 ^ (long)-1149789909), (int)((long)-422001169 ^ (long)422011218)) /* "Experimental\\nAllow Baritone to perform parkour jumps" */);
        zArray[(int)((long)157738129 ^ (long)157738133)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).allowParkourPlace, 0l.b((int)((long)-984224468 ^ (long)-984228775), (int)((long)-1074007757 ^ (long)-1074031781)) /* "Parkour Place" */, 0l.b((int)((long)1850917231 ^ (long)1850929156), (int)((long)-246862032 ^ (long)246863057)) /* "Experimental\\nAllow Baritone to place blocks to make parkour jumps" */);
        zArray[(int)((long)842541124 ^ (long)842541121)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).allowWaterBucketFall, 0l.b((int)((long)-1953225402 ^ (long)-1953229788), (int)((long)-383570526 ^ (long)-383560251)) /* "Bucket Fall" */, 0l.b((int)((long)668842477 ^ (long)668829835), (int)((long)1342101440 ^ (long)1342089974)) /* "Allow Baritone to perform water bucket falls" */);
        zArray[(int)((long)902073328 ^ (long)902073334)] = 0l.0((Settings.Setting<Integer>)((Settings)x).maxFallHeightNoWater, 0l.b((int)((long)-304001437 ^ (long)-303988946), (int)((long)1689392758 ^ (long)-1689400403)) /* "Max Fall Height" */, 0l.b((int)((long)-2126755944 ^ (long)-2126743856), (int)((long)246350867 ^ (long)-246380282)) /* "The maximum height to fall onto solid blocks" */, (int)((long)1197791200 ^ (long)1197791203), (int)((long)-1154897221 ^ (long)-1154897340));
        zArray[(int)((long)-295745262 ^ (long)-295745259)] = 0l.0((Settings.Setting<Integer>)((Settings)x).maxFallHeightBucket, 0l.b((int)((long)-1468649379 ^ (long)-1468661462), (int)((long)670424539 ^ (long)-670421154)) /* "Max Bucket Height" */, 0l.b((int)((long)2080363216 ^ (long)2080367523), (int)((long)913897146 ^ (long)913867118)) /* "The maximum height to perform a water bucket fall" */, (int)((long)-1899079085 ^ (long)-1899079082), (int)((long)-2134261058 ^ (long)-2134261183));
        zArray[(int)((long)1484253875 ^ (long)1484253883)] = 0l.9((Settings.Setting<Long>)((Settings)x).primaryTimeoutMS, 0l.b((int)((long)1772104770 ^ (long)1772100920), (int)((long)2014724444 ^ (long)-2014717399)) /* "Path Timeout" */, 0l.b((int)((long)536315571 ^ (long)536328161), (int)((long)-643257340 ^ (long)-643267120)) /* "The maximum time path calculation can take, in milliseconds." */, 0xB51A2FC07E315724L ^ 0xB51A2FC07E315740L, 0xDEDA1CC860FD5AF0L ^ 0xDEDA1CC860FD7DE0L);
        zArray[(int)((long)-401276064 ^ (long)-401276055)] = 0l.9((Settings.Setting<Long>)((Settings)x).planAheadPrimaryTimeoutMS, 0l.b((int)((long)-1102293031 ^ (long)-1102289254), (int)((long)592473806 ^ (long)-592448929)) /* "Plan Ahead Timeout" */, 0l.b((int)((long)1676633304 ^ (long)1676629414), (int)((long)-2115104833 ^ (long)-2115104881)) /* "The maximum time planning ahead can take, in milliseconds." */, 0x233CE80663C7F6F1L ^ 0x233CE80663C7F695L, 0x706CE9940AF4D346L ^ 0x706CE9940AF4F456L);
        zArray[(int)((long)2046307642 ^ (long)2046307632)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).renderCachedChunks, 0l.b((int)((long)731767976 ^ (long)731764194), (int)((long)879029819 ^ (long)879002907)) /* "Render Cached Chunks" */, 0l.b((int)((long)593060428 ^ (long)593056565), (int)((long)1509615711 ^ (long)1509614044)) /* "Render cached chunks semitransprently (very cool)\\nGlitchy, crashy, incompatible with OptiFine" */);
        zArray[(int)((long)41741055 ^ (long)41741044)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).chatDebug, 0l.b((int)((long)1790418867 ^ (long)1790422727), (int)((long)1350005999 ^ (long)1350001972)) /* "Chat Debug" */, 0l.b((int)((long)-1315020833 ^ (long)-1315017052), (int)((long)229871323 ^ (long)229897083)) /* "Prints Baritone debug messages to the chat" */);
        zArray[(int)((long)530909542 ^ (long)530909546)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).freeLook, 0l.b((int)((long)292956378 ^ (long)292952450), (int)((long)1536485312 ^ (long)1536480433)) /* "Free Look" */, 0l.b((int)((long)1957162529 ^ (long)1957158743), (int)((long)1599053677 ^ (long)-1599075867)) /* "Allows you to look around while pathing,\\nrather than having a locked view." */);
        zArray[(int)((long)-1001161080 ^ (long)-1001161083)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).antiCheatCompatibility, 0l.b((int)((long)1835863032 ^ (long)1835874944), (int)((long)-277105016 ^ (long)-277116765)) /* "Anti-Cheat Compatibility" */, 0l.b((int)((long)-796358516 ^ (long)-796345872), (int)((long)423288059 ^ (long)423292951)) /* "When free look is on, this ensures that it is compatible\\nwith any anticheats that servers may be running." */);
        zArray[(int)((long)1663856064 ^ (long)1663856078)] = 0l.0((Settings.Setting<Integer>)((Settings)x).followRadius, 0l.b((int)((long)1604974559 ^ (long)1604961952), (int)((long)1418005063 ^ (long)1418023467)) /* "Follow Radius" */, 0l.b((int)((long)-156796012 ^ (long)-156808476), (int)((long)-837253266 ^ (long)-837230635)) /* "The distance from the follow target that must be reached" */, (int)((long)-1643215921 ^ (long)-1643215922), (int)((long)454028036 ^ (long)454028128));
        zArray[(int)((long)1306749401 ^ (long)1306749398)] = 0l.6((Settings.Setting<Double>)((Settings)x).followOffsetDistance, 0l.b((int)((long)-1105596017 ^ (long)-1105608465), (int)((long)-1980935801 ^ (long)1980953377)) /* "Follow Offset Dist" */, 0l.b((int)((long)1013874106 ^ (long)1013861631), (int)((long)-2005462664 ^ (long)-2005466018)) /* "The offset distance from the actual set follow goal" */, 0.0, 10.0);
        zArray[(int)((long)923612210 ^ (long)923612194)] = 0l.7((Settings.Setting<Float>)((Settings)x).followOffsetDirection, 0l.b((int)((long)-354459471 ^ (long)-354463264), (int)((long)534219303 ^ (long)-534227091)) /* "Follow Offset Dir" */, 0l.b((int)((long)-2056295166 ^ (long)-2056299450), (int)((long)-1538896470 ^ (long)-1538914386)) /* "The offset direction from the actual set follow goal" */, 0.0f, 360.0f);
        zArray[(int)((long)-691499020 ^ (long)-691499035)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).renderGoalIgnoreDepth, 0l.b((int)((long)1998995246 ^ (long)1998982767), (int)((long)2079105985 ^ (long)-2079107019)) /* "Goal Ignore Depth" */, 0l.b((int)((long)-658631183 ^ (long)-658627440), (int)((long)-1997336437 ^ (long)-1997311505)) /* "Ignores the depth buffer when rendering the goal box" */);
        zArray[(int)((long)-697924329 ^ (long)-697924347)] = 0l.0((Settings.Setting<Boolean>)((Settings)x).renderPathIgnoreDepth, 0l.b((int)((long)-908272174 ^ (long)-908268360), (int)((long)1558032237 ^ (long)1558039401)) /* "Path Ignore Depth" */, 0l.b((int)((long)-2061667029 ^ (long)-2061679489), (int)((long)-88926022 ^ (long)88903455)) /* "Ignores the depth buffer when rendering the path" */);
        zArray[(int)((long)345005261 ^ (long)345005278)] = 0l.4((Settings.Setting<Color>)((Settings)x).colorCurrentPath, 0l.b((int)((long)1823103791 ^ (long)1823107693), (int)((long)1334560489 ^ (long)-1334565092)) /* "Current Path" */, 0l.b((int)((long)1345081081 ^ (long)1345093567), (int)((long)1214724291 ^ (long)1214726386)) /* "The current path color" */);
        zArray[(int)((long)-185050731 ^ (long)-185050751)] = 0l.4((Settings.Setting<Color>)((Settings)x).colorNextPath, 0l.b((int)((long)1031338338 ^ (long)1031325740), (int)((long)-1172989670 ^ (long)-1172976365)) /* "Next Path" */, 0l.b((int)((long)-696859741 ^ (long)-696847636), (int)((long)-665670056 ^ (long)-665654054)) /* "The next path color" */);
        zArray[(int)((long)457046611 ^ (long)457046598)] = 0l.4((Settings.Setting<Color>)((Settings)x).colorBlocksToBreak, 0l.b((int)((long)-1373954888 ^ (long)-1373950501), (int)((long)739269735 ^ (long)-739273264)) /* "To Break" */, 0l.b((int)((long)-1410899316 ^ (long)-1410903104), (int)((long)-677185258 ^ (long)-677203635)) /* "The color of blocks to break" */);
        zArray[(int)((long)-179511176 ^ (long)-179511186)] = 0l.4((Settings.Setting<Color>)((Settings)x).colorBlocksToPlace, 0l.b((int)((long)1021600329 ^ (long)1021596444), (int)((long)551812898 ^ (long)551802649)) /* "To Place" */, 0l.b((int)((long)342868320 ^ (long)342880273), (int)((long)-1423032935 ^ (long)1423028886)) /* "The color of blocks to place" */);
        zArray[(int)((long)-678691402 ^ (long)-678691423)] = 0l.4((Settings.Setting<Color>)((Settings)x).colorBlocksToWalkInto, 0l.b((int)((long)-293072019 ^ (long)-293068227), (int)((long)-1867132399 ^ (long)1867130421)) /* "Walk Into" */, 0l.b((int)((long)-2003325651 ^ (long)-2003329925), (int)((long)1330257325 ^ (long)1330268721)) /* "The color of blocks to walk into" */);
        zArray[(int)((long)-1427490032 ^ (long)-1427490040)] = 0l.4((Settings.Setting<Color>)((Settings)x).colorBestPathSoFar, 0l.b((int)((long)-846509142 ^ (long)-846497039), (int)((long)-238278946 ^ (long)-238258424)) /* "Best Path" */, 0l.b((int)((long)-1716849979 ^ (long)-1716862025), (int)((long)-1017691979 ^ (long)-1017691948)) /* "The color of the best path that has been found so far" */);
        zArray[(int)((long)1709825791 ^ (long)1709825766)] = 0l.4((Settings.Setting<Color>)((Settings)x).colorMostRecentConsidered, 0l.b((int)((long)-164727372 ^ (long)-164739878), (int)((long)-965566964 ^ (long)965562919)) /* "Most Recent Path" */, 0l.b((int)((long)1772418689 ^ (long)1772406747), (int)((long)1178698792 ^ (long)-1178725346)) /* "The color of the most recently considered path" */);
        zArray[(int)((long)-1357847319 ^ (long)-1357847309)] = 0l.4((Settings.Setting<Color>)((Settings)x).colorGoalBox, 0l.b((int)((long)212189375 ^ (long)212201939), (int)((long)696021950 ^ (long)696020491)) /* "Goal Box" */, 0l.b((int)((long)1586316874 ^ (long)1586329389), (int)((long)2144450013 ^ (long)2144453448)) /* "The color of the goal box" */);
        Arrays.asList(zArray).forEach(this::2);
        BaritoneAPI.getProvider().getPrimaryBaritone().getGameEventHandler().registerEventListener((IGameEventListener)this);
    }

    public static 1X 4(Settings.Setting<Color> setting, String string, String string2) {
        boolean bl = \u2003\u200a\u2008\u2000;
        if (bl || bl) {
            return null;
        }
        return new 1X(setting, string, string2);
    }

    public static 1E<Long> 9(Settings.Setting<Long> setting, String string, String string2, long l, long l2) {
        boolean bl = \u2003\u200a\u2008\u2000;
        if (bl || bl) {
            return null;
        }
        return new 1E<Long>(setting, string, string2, l, l2, Number::longValue);
    }

    public static 1E<Integer> 0(Settings.Setting<Integer> setting, String string, String string2, int n, int n2) {
        boolean bl = \u2003\u200a\u2008\u2000;
        if (bl || bl) {
            return null;
        }
        return new 1E<Integer>(setting, string, string2, n, n2, Number::intValue);
    }
}

