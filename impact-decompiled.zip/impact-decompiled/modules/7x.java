/* ==========================================================================
 * MODULE: Camera Clip
 * CATEGORY (inferred): Render
 * DESCRIPTION: Allows your 3rd person camera to clip through blocks
 * OBFUSCATED CLASS: net.impactclient.7x
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.event.ICancellable
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  me.zero.alpine.listener.MethodRefListener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.event.ICancellable;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import me.zero.alpine.listener.MethodRefListener;
import net.impactclient.2w$6X;
import net.impactclient.3X;
import net.impactclient.8J;
import net.impactclient.8h;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7x
extends 3X
implements 8h {
    @EventHandler
    private final Listener<8J> 7;
    public static 7x 9;
    private static final String[] d;
    private static final String[] e;
    public static final boolean \u200d\u2000;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7x.\u200d\u2000;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)468292758 ^ (long)468317154)) & (int)((long)1247079605 ^ (long)1247023946);
            if (var9_2) ** GOTO lbl-1000
            if (7x.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7x.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1601632541 ^ (long)1601632541)] & (int)((long)-1725502890 ^ (long)-1725502807)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)165058828 ^ (long)0x9D69969);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-384196134 ^ (long)-384196268);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1946461470 ^ (long)-1946461521);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-935196347 ^ (long)-935196312);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-695945018 ^ (long)-695945016);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1990940700 ^ (long)-1990940846);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-780831129 ^ (long)-780831170);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1350777589 ^ (long)-1350777542);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1719820267 ^ (long)1719820199);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)728320256 ^ (long)728320496);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-814705909 ^ (long)-814705735);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)677500673 ^ (long)677500742);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-415153335 ^ (long)-415153371);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)793660047 ^ (long)793660054);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-783115277 ^ (long)-783115399);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)220299159 ^ (long)220299168);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)2000798801 ^ (long)2000798894);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1404558771 ^ (long)1404558728);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-587692098 ^ (long)-587692258);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1065278758 ^ (long)-1065278738);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-50387527 ^ (long)-50387583);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)963475996 ^ (long)963476069);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-482317510 ^ (long)-482317477);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)554515785 ^ (long)554515810);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1511043503 ^ (long)1511043546);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1075564889 ^ (long)-1075564825);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1088131932 ^ (long)1088131864);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-980615581 ^ (long)-980615561);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1950778895 ^ (long)1950779050);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)2106943075 ^ (long)2106943208);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1202828216 ^ (long)1202828236);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1247809153 ^ (long)1247809080);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1022678067 ^ (long)-1022678251);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1646724156 ^ (long)1646724321);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-2031211675 ^ (long)-2031211557);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1143253211 ^ (long)1143253243);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)2087585640 ^ (long)2087585789);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1489707688 ^ (long)-1489707606);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1205268351 ^ (long)1205268372);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1504473425 ^ (long)1504473494);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1101136341 ^ (long)1101136319);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1784811373 ^ (long)-1784811432);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-325412865 ^ (long)-325413062);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-2072106401 ^ (long)-2072106331);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1432766460 ^ (long)-1432766408);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-406691933 ^ (long)-406691894);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-2046267563 ^ (long)-2046267419);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1211915863 ^ (long)-1211915908);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1756429749 ^ (long)1756429633);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1156375564 ^ (long)-1156375583);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)503753502 ^ (long)503753705);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-571842205 ^ (long)-571842181);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-547228295 ^ (long)-547228322);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)2120393333 ^ (long)2120393379);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-754386325 ^ (long)-754386338);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1102103226 ^ (long)1102103205);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1707850946 ^ (long)-1707850760);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1886316480 ^ (long)1886316355);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-829626866 ^ (long)-829626786);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1894665712 ^ (long)-1894665678);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)603771321 ^ (long)603771175);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1657976775 ^ (long)1657976616);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1518789525 ^ (long)-1518789409);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1851416078 ^ (long)-1851416170);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1799027170 ^ (long)-1799027192);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-732702245 ^ (long)-732702297);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-593035989 ^ (long)-593035928);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1718587574 ^ (long)1718587513);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-995778205 ^ (long)-995778074);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1081016340 ^ (long)1081016356);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1549729621 ^ (long)-1549729545);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-969458481 ^ (long)-969458634);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)484406590 ^ (long)484406592);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1763882163 ^ (long)1763882106);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1354823768 ^ (long)-1354823689);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1120245132 ^ (long)-1120245237);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-2113536992 ^ (long)-2113537006);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-770516478 ^ (long)-770516435);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)109695398 ^ (long)109695251);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1485285504 ^ (long)-1485285458);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1289476255 ^ (long)-1289476206);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1459505887 ^ (long)-1459505828);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)14590046 ^ (long)14589968);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-571568570 ^ (long)-571568475);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1617803549 ^ (long)-1617803661);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)509755547 ^ (long)509755636);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1054941530 ^ (long)-1054941493);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1810837002 ^ (long)1810837081);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1334595456 ^ (long)-1334595539);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)865528274 ^ (long)865528133);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1867360367 ^ (long)-1867360317);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)682092963 ^ (long)682092924);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)547428386 ^ (long)547428512);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1003886815 ^ (long)1003886610);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1609342243 ^ (long)-1609342255);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)194659576 ^ (long)194659344);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-886704385 ^ (long)-886704542);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-2119298097 ^ (long)-2119298115);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1478883517 ^ (long)1478883555);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-878174246 ^ (long)-878174388);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-144877659 ^ (long)-144877569);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1636794181 ^ (long)1636794239);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1884861042 ^ (long)1884861080);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1502384333 ^ (long)1502384264);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1532549647 ^ (long)-1532549838);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)782667655 ^ (long)782667734);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-988894747 ^ (long)-988894804);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1190327355 ^ (long)1190327545);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1171182553 ^ (long)1171182383);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)888824594 ^ (long)888824763);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)429972305 ^ (long)429972310);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1907906582 ^ (long)1907906758);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)2017746037 ^ (long)2017746018);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-2005870153 ^ (long)-2005870289);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1058782587 ^ (long)1058782558);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1964946347 ^ (long)1964946306);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1143183130 ^ (long)1143183158);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1488729295 ^ (long)1488729287);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)236733127 ^ (long)236732970);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)916965322 ^ (long)916965239);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)893674144 ^ (long)893674036);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-2119437181 ^ (long)-2119437178);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1388589815 ^ (long)1388589791);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)243224000 ^ (long)243224009);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1779706824 ^ (long)-1779706801);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-894858233 ^ (long)-894858159);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-466032758 ^ (long)-466032788);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1182217228 ^ (long)1182217244);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)32157555 ^ (long)32157695);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1687131921 ^ (long)1687132147);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1785160321 ^ (long)-1785160331);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1925810040 ^ (long)-1925810028);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1612411336 ^ (long)1612411225);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1179992268 ^ (long)-1179992297);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1851432189 ^ (long)1851432060);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)131714201 ^ (long)131714083);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)33713702 ^ (long)33713671);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-444482263 ^ (long)-444482175);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-2117439964 ^ (long)-2117439841);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1489691033 ^ (long)1489690902);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1141271425 ^ (long)1141271341);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-797469174 ^ (long)-797469013);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-980515903 ^ (long)-980515899);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)440546399 ^ (long)440546341);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-2104546904 ^ (long)-2104546972);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)280708884 ^ (long)280708980);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1903412557 ^ (long)1903412502);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1948401728 ^ (long)1948401881);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1564144107 ^ (long)-1564144088);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-209047982 ^ (long)-209047914);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)281457016 ^ (long)281457141);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-67253507 ^ (long)-67253743);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1206737144 ^ (long)1206737143);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-128077157 ^ (long)-128077100);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1477454336 ^ (long)-1477454216);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-2144209868 ^ (long)-2144209838);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1892953530 ^ (long)1892953446);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-108467196 ^ (long)-108467025);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)38185093 ^ (long)38184993);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1780098346 ^ (long)-1780098487);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1221408385 ^ (long)-1221408488);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1156693324 ^ (long)-1156693428);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)677768732 ^ (long)677768957);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)493694158 ^ (long)493694088);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-2134817811 ^ (long)-2134817829);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1045388314 ^ (long)1045388489);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)633214913 ^ (long)633214720);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1497399815 ^ (long)-1497400024);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1628790822 ^ (long)-1628790967);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1974110343 ^ (long)-1974110446);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)242099025 ^ (long)242098960);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1967405968 ^ (long)1967405864);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-603770731 ^ (long)-603770731);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)403887162 ^ (long)403887336);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-484001671 ^ (long)-484001566);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-241629058 ^ (long)-241629020);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1970848581 ^ (long)-1970848651);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)203211321 ^ (long)203211304);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)532895668 ^ (long)532895562);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1982079996 ^ (long)-1982079850);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1458247115 ^ (long)1458247040);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)274469054 ^ (long)274468865);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-439848179 ^ (long)-439848021);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)208526263 ^ (long)208526257);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-70609270 ^ (long)-70609257);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1052827057 ^ (long)1052827113);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1898850466 ^ (long)-1898850323);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-800742389 ^ (long)-800742161);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1998361316 ^ (long)1998361187);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-31829588 ^ (long)-31829673);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1772066548 ^ (long)0x699F9696);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1806465357 ^ (long)1806465406);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-219217969 ^ (long)-219218129);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)919940895 ^ (long)919941052);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1768261909 ^ (long)-1768262025);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1995482034 ^ (long)1995482032);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-439969944 ^ (long)-439969812);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)192941856 ^ (long)192942023);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-695753078 ^ (long)-695752995);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1481813730 ^ (long)-1481813728);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)258301544 ^ (long)258301672);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-607238440 ^ (long)-607238461);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)2116832540 ^ (long)2116832585);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1339025267 ^ (long)1339025282);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)955748936 ^ (long)955749074);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1518858426 ^ (long)-1518858249);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-180943269 ^ (long)-180943230);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)589890395 ^ (long)589890376);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1044084788 ^ (long)1044084924);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1549670428 ^ (long)-1549670643);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1648162513 ^ (long)-1648162350);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1110995481 ^ (long)1110995467);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1461609157 ^ (long)1461609058);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1174110468 ^ (long)1174110672);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1031799908 ^ (long)-1031799930);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)287472022 ^ (long)287471978);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)297506781 ^ (long)297506741);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)2062478237 ^ (long)2062478267);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1200813203 ^ (long)1200813133);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1992489696 ^ (long)1992489559);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1772447027 ^ (long)1772447056);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1495950706 ^ (long)-1495950684);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-432257034 ^ (long)-432257048);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)207230490 ^ (long)207230703);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)865754258 ^ (long)865754185);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1935942905 ^ (long)1935942743);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1027675743 ^ (long)1027675825);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-225753344 ^ (long)-225753333);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1494501429 ^ (long)1494501584);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1309685934 ^ (long)1309685800);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1880200897 ^ (long)1880200726);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-431981419 ^ (long)-431981368);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)3583462 ^ (long)3583376);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1084512948 ^ (long)-1084512827);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1931014979 ^ (long)-1931015167);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)181804648 ^ (long)181804578);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1036808993 ^ (long)-1036808996);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)713906721 ^ (long)713906787);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)702508922 ^ (long)702508976);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1858528500 ^ (long)-1858528308);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-792489326 ^ (long)-792489274);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-978509659 ^ (long)-978509670);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)108686704 ^ (long)108686592);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-563534261 ^ (long)-563534103);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1730119541 ^ (long)1730119451);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1481066937 ^ (long)-1481066882);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1715581628 ^ (long)-1715581600);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-420432583 ^ (long)-420432527);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-157793711 ^ (long)-157793712);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1514235994 ^ (long)-1514236050);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)106233568 ^ (long)106233423);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)969924121 ^ (long)969924275);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1378431509 ^ (long)-1378431590);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)425246942 ^ (long)425246931);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1089697834 ^ (long)-1089697875);
                    if (!7x.\u200d\u2000) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1851824963 ^ (long)1851824944);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1708770802 ^ (long)1708770573)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1496047202 ^ (long)1495998877)) >>> (int)((long)1437757491 ^ (long)1437757499)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1517818965 ^ (long)-1517818965);
            if (!7x.\u200d\u2000) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)510294603 ^ (long)510294601);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1143940694 ^ (long)1143940693) | var5_6 << (int)((long)-2131014571 ^ (long)-2131014576)) ^ var3_4[var7_8]) & (int)((long)-1818787221 ^ (long)-1818787180);
                    if (7x.\u200d\u2000) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1985070333 ^ (long)1985070334) | var6_7 << (int)((long)-165726956 ^ (long)-165726959)) ^ var3_4[var7_8]) & (int)((long)-994615645 ^ (long)-994615716);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7x.e[var2_3] = new String(var3_4).intern();
        }
        return 7x.e[var2_3];
    }

    public 7x() {
        boolean bl = \u200d\u2000;
        super(7x.b((int)((long)-314817757 ^ (long)-314825641), (int)((long)8256781 ^ (long)-8238936)) /* "Camera Clip" */, 7x.b((int)((long)-2132483184 ^ (long)-2132507419), (int)((long)1101015489 ^ (long)-1101007165)) /* "Allows your 3rd person camera to clip through blocks" */);
        this.7 = new MethodRefListener(8J.class, ICancellable::cancel, new Predicate[(int)((long)94814397 ^ (long)94814397)]);
        9 = this;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u200d\u2000;
                if (bl || bl) break block2;
                7x.3.e.e();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        block3: {
            block2: {
                boolean bl = \u200d\u2000;
                if (bl || bl) break block2;
                7x.3.e.e();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 7x.\u200d\u2000;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)-574342378 ^ (long)-574342380)];
            if (var7) break block16;
            var3_2 = (int)((long)103756986 ^ (long)103756986);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u77f6\u5e19\u4deb\u4585\u7755\u5ede\u4d0e\u45f5\u77b8\u5e02\u4de0\u459f\u7723\u5eb4\u4d12\u4596\u774e\u5ee5\u4dc8\u45f8\u7763\u5ec2\u4dfa\u4536\u77fc\u5ea5\u4d66\u4596\u77c0\u5e78\u4d69\u4516\u7721\u5ef4\u4d50\u45c5\u77ce\u5e2a\u4dba\u45a7\u77d0\u5eb3\u4d50\u45b3\u774a\u5e51\u4db9\u456c\u7797\u5e17\u4d9e\u453b\u77f7\u5e58\u4d7f\u45d0\u77c8\u5e5a\u4d63\u45a0\u7772\u5ed3\u4d71\u459d", -1346023318);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)631913157 ^ (long)631913166);
            if (var7) break block16;
            var0_6 = (int)((long)-473367492 ^ (long)473367491);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-893004143 ^ (long)893004142);
                if (7x.\u200d\u2000) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!7x.\u200d\u2000) continue block8;
                            throw null;
                        }
                        7x.d = var5_1;
                        7x.e = new String[(int)((long)-1110496859 ^ (long)-1110496857)];
                        if (!7x.\u200d\u2000) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)2024771325 ^ (long)2024771325);
                v5 = (int)((long)406682102 ^ (long)406682043);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)1223001112 ^ (long)1223001113)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1186058859 ^ (long)1186058860)) {
                                case 0: {
                                    v12 = (int)((long)787636787 ^ (long)787636838);
                                    if (!7x.\u200d\u2000) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)743088948 ^ (long)743088984);
                                    if (!7x.\u200d\u2000) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-425742083 ^ (long)-425742085);
                                    if (!7x.\u200d\u2000) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)-1434478202 ^ (long)-1434478158);
                                    if (!7x.\u200d\u2000) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)-1744961344 ^ (long)-1744961374);
                                    if (!7x.\u200d\u2000) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)285251095 ^ (long)285251077);
                                    if (!7x.\u200d\u2000) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-5722610 ^ (long)-5722587);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!7x.\u200d\u2000);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!7x.\u200d\u2000) ** continue;
                throw null;
            }
        }
    }
}

