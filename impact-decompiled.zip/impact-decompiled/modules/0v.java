/* ==========================================================================
 * MODULE: Auto Eject
 * CATEGORY (inferred): Player
 * DESCRIPTION: Removes unwanted items from your inventory
 * OBFUSCATED CLASS: net.impactclient.0v
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  bfw
 *  bik
 *  blx
 *  bmb
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.1z;
import net.impactclient.2w;
import net.impactclient.2w$6X;
import net.impactclient.34J;
import net.impactclient.34R;
import net.impactclient.34X;
import net.impactclient.34_;
import net.impactclient.34e;
import net.impactclient.38;
import net.impactclient.3S;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.4X;
import net.impactclient.5y;
import net.impactclient.8H;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0v
extends 3X
implements 34R {
    public final List<blx> 8;
    private static final String[] d;
    private 1z 4f;
    private final Queue<bmb> 5;
    private final 8H 7;
    private final 2w<bmb> 9;
    private 1P 0;
    public static final boolean \u2002\u2008\u2006\u2007;
    private 1P 4;
    @EventHandler
    private final Listener<4X> 2;
    private static final String[] e;
    public final 34_ 1;
    private 1P 6;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0v.\u2002\u2008\u2006\u2007;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-617207744 ^ (long)617196964)) & (int)((long)1208494749 ^ (long)1208538466);
            if (var9_2) ** GOTO lbl-1000
            if (0v.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0v.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)304765618 ^ (long)304765618)] & (int)((long)-1936535271 ^ (long)-1936535066)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)103566501 ^ (long)103566469);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1328941734 ^ (long)1328941817);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)357723249 ^ (long)357723262);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)880764573 ^ (long)880764516);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-683297555 ^ (long)-683297738);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1187800120 ^ (long)-1187800109);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-732665270 ^ (long)-732665341);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-2047634284 ^ (long)-2047634399);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1915365603 ^ (long)1915365516);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1246636744 ^ (long)-1246636588);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1194098820 ^ (long)-1194098885);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)842361007 ^ (long)842361061);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1596250134 ^ (long)-1596250220);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-676116316 ^ (long)-676116341);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)0xC0DCD0 ^ (long)12639325);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-550110514 ^ (long)-550110568);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)785632167 ^ (long)785632058);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1169348844 ^ (long)1169348807);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1890879232 ^ (long)1890879245);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)2050142132 ^ (long)2050142010);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1982094952 ^ (long)-1982095008);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-68785600 ^ (long)-68785422);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1977880370 ^ (long)-1977880534);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-860577950 ^ (long)-860578003);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-290541632 ^ (long)-290541751);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-9076594 ^ (long)-9076660);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1324796674 ^ (long)-1324796697);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1046838414 ^ (long)-1046838502);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-246940970 ^ (long)-246941118);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-69130053 ^ (long)-69130113);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)331801443 ^ (long)331801520);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-2097415599 ^ (long)-2097415494);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1540430760 ^ (long)1540430662);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1517385631 ^ (long)-1517385698);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1096874913 ^ (long)1096874922);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1806403056 ^ (long)1806402984);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1846220194 ^ (long)-1846220120);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-397846246 ^ (long)-397846159);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)473431038 ^ (long)473430867);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1236043412 ^ (long)-1236043398);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-231912269 ^ (long)-231912331);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1943631327 ^ (long)1943631275);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-208294312 ^ (long)-208294189);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-38063039 ^ (long)-38063100);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1068264341 ^ (long)-1068264410);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-2070948834 ^ (long)-2070948748);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1094879031 ^ (long)-1094879142);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1391751847 ^ (long)-1391751696);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-920247792 ^ (long)-920247577);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1085428203 ^ (long)1085428109);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-389327257 ^ (long)-389327203);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1975882716 ^ (long)-1975882548);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)320822033 ^ (long)320822262);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1766943158 ^ (long)1766942976);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-614865299 ^ (long)-614865214);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1643730931 ^ (long)1643730809);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-2077613139 ^ (long)-2077613283);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1554869146 ^ (long)-1554869030);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)740499044 ^ (long)740499021);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1222842338 ^ (long)-1222842183);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-544446369 ^ (long)-544446370);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1046427255 ^ (long)1046427235);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-120548209 ^ (long)-120548306);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-131425043 ^ (long)-131425230);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1442432885 ^ (long)1442432996);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-98575059 ^ (long)-98574996);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1241932987 ^ (long)1241932864);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)290197340 ^ (long)290197503);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-901694310 ^ (long)-901694345);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1313462080 ^ (long)1313462235);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-587222213 ^ (long)-587222140);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-273635583 ^ (long)-273635372);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1609842038 ^ (long)1609841986);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1392400024 ^ (long)1392399882);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-2144163104 ^ (long)-2144163134);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-2094442303 ^ (long)-2094442279);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1449993326 ^ (long)-1449993410);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1421557734 ^ (long)-1421557528);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1084772754 ^ (long)1084772689);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)85051173 ^ (long)85051229);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)550230469 ^ (long)550230518);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1439602200 ^ (long)-1439602387);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1066210702 ^ (long)-1066210562);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-648583738 ^ (long)-648583850);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-144771938 ^ (long)-144771990);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1664646169 ^ (long)1664646353);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1414542850 ^ (long)1414543034);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-2092620810 ^ (long)-2092621009);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)678884395 ^ (long)678884445);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)65835649 ^ (long)65835695);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)2142944383 ^ (long)2142944454);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1526836777 ^ (long)-1526836759);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1511645063 ^ (long)-1511645163);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1338006560 ^ (long)1338006605);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-399381374 ^ (long)-399381390);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1034467699 ^ (long)-1034467755);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-734566336 ^ (long)-734566246);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1150658843 ^ (long)1150658949);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1174906333 ^ (long)1174906128);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1244191768 ^ (long)1244191754);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1131721994 ^ (long)-1131722051);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1659355159 ^ (long)-1659355248);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)229087184 ^ (long)229087143);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)906968185 ^ (long)906968254);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)836538428 ^ (long)836538388);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)98569492 ^ (long)98569601);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-526213781 ^ (long)-526213762);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1968607859 ^ (long)1968607844);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1795747756 ^ (long)-1795747729);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-46993038 ^ (long)-46993134);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-2107575314 ^ (long)-2107575336);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-954454705 ^ (long)-954454760);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-264610408 ^ (long)-264610531);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)906449491 ^ (long)906449485);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)155952434 ^ (long)155952633);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-2017605692 ^ (long)-2017605730);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)699071825 ^ (long)699071840);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-34816509 ^ (long)-34816363);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)633685036 ^ (long)633685067);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1939664379 ^ (long)1939664287);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1739214174 ^ (long)-1739214329);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1090792567 ^ (long)-1090792588);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-930441455 ^ (long)-930441365);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1446274124 ^ (long)-1446274072);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1404620411 ^ (long)1404620468);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1925383526 ^ (long)-1925383463);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)212338829 ^ (long)212338879);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-72430580 ^ (long)-72430356);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1238047882 ^ (long)-1238047898);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1499726121 ^ (long)-1499726172);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)72035414 ^ (long)72035466);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1066994295 ^ (long)-1066994293);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-57030526 ^ (long)-57030409);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1816381637 ^ (long)-1816381666);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-545090778 ^ (long)-545090696);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)61135549 ^ (long)61135514);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-870299130 ^ (long)-870299136);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-285745918 ^ (long)-285745852);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-151405574 ^ (long)-151405797);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-921550573 ^ (long)-921550467);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)632810559 ^ (long)632810604);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-150367194 ^ (long)-150367179);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)2097668040 ^ (long)2097668040);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1323682549 ^ (long)1323682521);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)485449250 ^ (long)485449220);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)824871955 ^ (long)824872031);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1228309227 ^ (long)1228309015);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)145508303 ^ (long)145508158);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1565067074 ^ (long)1565067254);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1955139923 ^ (long)1955139939);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1438670263 ^ (long)-1438670088);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)2002403103 ^ (long)2002403111);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)603367875 ^ (long)603367934);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)411117796 ^ (long)411117793);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1518801044 ^ (long)1518800943);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1811311080 ^ (long)-1811310969);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1114151568 ^ (long)-1114151506);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1178979411 ^ (long)-1178979505);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)555838538 ^ (long)555838579);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1370802678 ^ (long)-1370802635);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1663811936 ^ (long)-1663812022);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1414670164 ^ (long)1414670232);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1553342230 ^ (long)1553342241);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1204668494 ^ (long)1204668444);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-492565912 ^ (long)-492565918);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1435138957 ^ (long)-1435138992);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1787036808 ^ (long)-1787036710);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-134724357 ^ (long)-134724500);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1382039547 ^ (long)1382039391);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1731550054 ^ (long)-1731550075);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-269289875 ^ (long)-269289884);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)961759551 ^ (long)961759636);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-523964304 ^ (long)-523964249);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1144296315 ^ (long)1144296440);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)394965459 ^ (long)394965267);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1034392199 ^ (long)-1034392125);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)2084607385 ^ (long)2084607395);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1811378287 ^ (long)1811378194);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1949220053 ^ (long)-1949219924);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1265347314 ^ (long)1265347106);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-46163307 ^ (long)-46163332);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)610634123 ^ (long)610634174);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1565912441 ^ (long)-1565912338);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1880622459 ^ (long)1880622513);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-178418176 ^ (long)-178417987);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1166511005 ^ (long)-1166511031);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-2092229420 ^ (long)-2092229435);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1786749773 ^ (long)1786749801);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-778232678 ^ (long)-778232802);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-885720445 ^ (long)-885720362);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)2048173210 ^ (long)2048173084);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1191643733 ^ (long)1191643814);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1290192411 ^ (long)-1290192596);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-152998585 ^ (long)-152998601);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-633834313 ^ (long)-633834390);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-452840388 ^ (long)-452840225);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-562545713 ^ (long)-562545730);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1051782393 ^ (long)1051782298);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-250597874 ^ (long)-250597703);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-338238632 ^ (long)-338238708);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1042554389 ^ (long)1042554397);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1744702259 ^ (long)-1744702321);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1102913711 ^ (long)-1102913697);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)906911723 ^ (long)906911690);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1848579765 ^ (long)-1848579625);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1161808071 ^ (long)1161807993);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1743676748 ^ (long)1743676758);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1692602985 ^ (long)1692603014);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1617002978 ^ (long)1617002922);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1067788755 ^ (long)-1067788675);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)633404288 ^ (long)633404200);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1075734465 ^ (long)1075734345);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1819786997 ^ (long)-1819786791);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)175847783 ^ (long)175847740);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)2099981046 ^ (long)2099980808);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1772919084 ^ (long)-1772919081);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)860144810 ^ (long)0x3344C433);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1205757163 ^ (long)-1205757033);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1145454309 ^ (long)1145454131);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-819126175 ^ (long)-819126079);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1156682195 ^ (long)-1156682101);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-628199377 ^ (long)-628199298);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1095432502 ^ (long)1095432633);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-778435249 ^ (long)-778435113);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1116056120 ^ (long)-1116056147);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-2059530735 ^ (long)-2059530730);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1940013008 ^ (long)-1940012930);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1316291492 ^ (long)1316291440);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1426811905 ^ (long)-1426812084);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1296080521 ^ (long)1296080589);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-686952430 ^ (long)-686952343);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1824642476 ^ (long)1824642349);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)2080794687 ^ (long)2080794842);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1489790181 ^ (long)1489790136);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1825457220 ^ (long)1825457314);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)491419927 ^ (long)491420005);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-861352299 ^ (long)-861352312);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)85984931 ^ (long)85984910);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)2032807310 ^ (long)2032807200);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)286939649 ^ (long)286939803);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)118015991 ^ (long)118015863);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1085202709 ^ (long)-1085202907);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1307355466 ^ (long)-1307355581);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1976402427 ^ (long)1976402338);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1505084562 ^ (long)1505084654);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-439566355 ^ (long)-439566383);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1585640266 ^ (long)1585640416);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-422580301 ^ (long)-422580305);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)730391732 ^ (long)730391728);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)374377869 ^ (long)374377857);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-587149939 ^ (long)-587149988);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)280776092 ^ (long)280776190);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)998938460 ^ (long)998938396);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-253365475 ^ (long)-253365380);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)2018668456 ^ (long)2018668375);
                    if (!0v.\u2002\u2008\u2006\u2007) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-425685271 ^ (long)-425685464);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)649340500 ^ (long)649340587)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1149108706 ^ (long)-1149173279)) >>> (int)((long)-1037773719 ^ (long)-1037773727)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)746889416 ^ (long)746889416);
            if (!0v.\u2002\u2008\u2006\u2007) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1136809785 ^ (long)-1136809787);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)121347130 ^ (long)121347129) | var5_6 << (int)((long)718716675 ^ (long)718716678)) ^ var3_4[var7_8]) & (int)((long)-395854144 ^ (long)-395854273);
                    if (0v.\u2002\u2008\u2006\u2007) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-237039319 ^ (long)-237039318) | var6_7 << (int)((long)1517056097 ^ (long)1517056100)) ^ var3_4[var7_8]) & (int)((long)1602461260 ^ (long)1602461363);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0v.e[var2_3] = new String(var3_4).intern();
        }
        return 0v.e[var2_3];
    }

    static /* synthetic */ List 7(0v v) {
        boolean bl = \u2002\u2008\u2006\u2007;
        if (bl || bl) {
            return null;
        }
        return v.8;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void 4(bmb bmb2) {
        boolean bl = \u2002\u2008\u2006\u2007;
        if (bl || bl) return;
        int n = 0v.3.s.bm.a.indexOf((Object)bmb2);
        if (n < 0) {
            if (bl || bl) return;
            return;
        }
        if (bl) return;
        if (n < (int)((long)985914947 ^ (long)985914954)) {
            if (bl || bl) return;
            n += 36;
            if (bl) return;
        }
        if (bl) return;
        0v.3.q.a(0v.3.s.bo.b, n, (int)((long)-1620882160 ^ (long)-1620882159), bik.e, (bfw)0v.3.s);
        if (!bl && !bl) return;
    }

    public 0v() {
        boolean bl = \u2002\u2008\u2006\u2007;
        super(0v.b((int)((long)1029117563 ^ (long)-1029139558), (int)((long)-2126874805 ^ (long)-2126892350)) /* "Auto Eject" */, 0v.b((int)((long)1236061659 ^ (long)-1236056014), (int)((long)-763994333 ^ (long)-764005230)) /* "Removes unwanted items from your inventory" */);
        Predicate[] predicateArray = Boolean.TRUE;
        Object object = (34X)((34X)((34X)this.4().5(0v.b((int)((long)1487389903 ^ (long)-1487388374), (int)((long)-2130522866 ^ (long)2130526404)) /* "Weapons" */)).7(0v.b((int)((long)-1012352980 ^ (long)1012350403), (int)((long)1393501375 ^ (long)1393502409)) /* "weapons" */)).1(0v.b((int)((long)2093952613 ^ (long)-2093962363), (int)((long)-162674925 ^ (long)-162676716)) /* "Removes all weapons that are worse than an existing one" */);
        ((34X)((34X)((34X)this.4().5(0v.b((int)((long)1487389903 ^ (long)-1487388374), (int)((long)-2130522866 ^ (long)2130526404)) /* "Weapons" */)).7(0v.b((int)((long)-1012352980 ^ (long)1012350403), (int)((long)1393501375 ^ (long)1393502409)) /* "weapons" */)).1(0v.b((int)((long)2093952613 ^ (long)-2093962363), (int)((long)-162674925 ^ (long)-162676716)) /* "Removes all weapons that are worse than an existing one" */)).7 = predicateArray;
        this.0 = (1P)((34J)object).5();
        predicateArray = Boolean.TRUE;
        object = (34X)((34X)((34X)this.4().5(0v.b((int)((long)-420115160 ^ (long)420088015), (int)((long)-536797987 ^ (long)-536791383)) /* "Armor" */)).7(0v.b((int)((long)686148522 ^ (long)-686141886), (int)((long)-918279455 ^ (long)-918278909)) /* "armor" */)).1(0v.b((int)((long)1777419761 ^ (long)-1777418211), (int)((long)-363992041 ^ (long)363994820)) /* "Removes all armor that is worse than an existing one" */);
        ((34X)((34X)((34X)this.4().5(0v.b((int)((long)-420115160 ^ (long)420088015), (int)((long)-536797987 ^ (long)-536791383)) /* "Armor" */)).7(0v.b((int)((long)686148522 ^ (long)-686141886), (int)((long)-918279455 ^ (long)-918278909)) /* "armor" */)).1(0v.b((int)((long)1777419761 ^ (long)-1777418211), (int)((long)-363992041 ^ (long)363994820)) /* "Removes all armor that is worse than an existing one" */)).7 = predicateArray;
        this.6 = (1P)((34J)object).5();
        predicateArray = Boolean.TRUE;
        object = (34X)((34X)((34X)this.4().5(0v.b((int)((long)1315720021 ^ (long)-1315713353), (int)((long)-2008410120 ^ (long)2008414900)) /* "Custom" */)).7(0v.b((int)((long)1257900530 ^ (long)-1257927658), (int)((long)-147532448 ^ (long)147527720)) /* "custom" */)).1(0v.b((int)((long)-834118971 ^ (long)834133795), (int)((long)1176923656 ^ (long)-1176926233)) /* "Removes user-defined items specified by the eject command" */);
        ((34X)((34X)((34X)this.4().5(0v.b((int)((long)1315720021 ^ (long)-1315713353), (int)((long)-2008410120 ^ (long)2008414900)) /* "Custom" */)).7(0v.b((int)((long)1257900530 ^ (long)-1257927658), (int)((long)-147532448 ^ (long)147527720)) /* "custom" */)).1(0v.b((int)((long)-834118971 ^ (long)834133795), (int)((long)1176923656 ^ (long)-1176926233)) /* "Removes user-defined items specified by the eject command" */)).7 = predicateArray;
        this.4 = (1P)((34J)object).5();
        this.4f = (1z)((34e)((34e)((34e)this.1().5(0v.b((int)((long)493330979 ^ (long)-493344819), (int)((long)172296136 ^ (long)172319703)) /* "Delay" */)).7(0v.b((int)((long)-1035931076 ^ (long)1035958239), (int)((long)-2060714975 ^ (long)-2060738183)) /* "delay" */)).1(0v.b((int)((long)-1178519468 ^ (long)1178516921), (int)((long)332669452 ^ (long)332678856)) /* "The delay in milliseconds between each item drop" */)).3((int)((long)-1814174437 ^ (long)-1814174437)).2((int)((long)-1330340847 ^ (long)-1330342443)).5();
        this.8 = new ArrayList<blx>();
        this.5 = new ArrayDeque<bmb>();
        this.7 = new 8H();
        Predicate[] predicateArray2 = new Predicate[(int)((long)1288634796 ^ (long)1288634797)];
        predicateArray2[(int)((long)1306997724 ^ (long)1306997724)] = bmb2 -> {
            boolean bl = \u2002\u2008\u2006\u2007;
            if (bl || bl) {
                return true;
            }
            return this.8.contains(bmb2.b());
        };
        predicateArray = predicateArray2;
        object = new 5y();
        new 5y().1 = predicateArray;
        this.9 = ((5y)object).7();
        this.2 = new Listener(x2 -> {
            boolean bl;
            block10: {
                bl = \u2002\u2008\u2006\u2007;
                if (bl) return;
                String[] stringArray = 3e.5();
                if (bl) return;
                if (bl) return;
                if (0v.3.s.bo != 0v.3.s.bp) {
                    if (bl) return;
                    return;
                }
                if (bl) return;
                x2 = 0v.3.s.bm.a;
                if (bl) return;
                if (bl) return;
                this.5.removeIf(arg_0 -> 0v.0((List)((Object)x2), arg_0));
                if (bl) return;
                if (bl) return;
                if (this.0.2) {
                    if (bl) return;
                    if (bl) return;
                    List<bmb> list = 38.8.8((List<bmb>)((Object)x2));
                    if (list.size() > 0) {
                        if (bl) return;
                        if (bl) return;
                        bmb bmb4 = list.get((int)((long)-1276943963 ^ (long)-1276943963));
                        if (bl) return;
                        if (bl) return;
                        list.forEach(bmb3 -> {
                            block4: {
                                block2: {
                                    boolean bl;
                                    block3: {
                                        bl = \u2002\u2008\u2006\u2007;
                                        if (bl || bl) break block2;
                                        if (bmb3 == bmb4) break block3;
                                        if (bl) break block2;
                                        if (this.5.contains(bmb3)) break block3;
                                        if (bl || bl) break block2;
                                        this.5.offer((bmb)bmb3);
                                        if (bl) break block2;
                                    }
                                    if (!bl) break block4;
                                }
                                return;
                            }
                        });
                        if (bl) return;
                    }
                }
                if (bl) return;
                if (this.6.2) {
                    if (bl) return;
                    if (bl) return;
                    3S.0.forEach(arg_0 -> this.9((List)((Object)x2), arg_0));
                    if (bl) return;
                }
                if (bl) return;
                if (this.4.2) {
                    if (bl) return;
                    if (bl) return;
                    this.9.8((List<bmb>)((Object)x2)).stream().filter(bmb2 -> {
                        boolean bl = \u2002\u2008\u2006\u2007;
                        if (bl || bl) return true;
                        if (!this.5.contains(bmb2)) {
                            if (bl) return true;
                            return (int)((long)-2084765251 ^ (long)-2084765252) != 0;
                        }
                        if (!bl) return (int)((long)-1290770652 ^ (long)-1290770652) != 0;
                        return true;
                    }).forEach(this.5::offer);
                    if (bl) return;
                }
                if (bl) return;
                if (this.4f.4 > 0) {
                    if (bl) return;
                    if (bl) return;
                    if (this.7.8(this.4f.4)) {
                        if (bl) return;
                        if (bl) return;
                        if (0v.9(this.5.peek())) {
                            if (bl) return;
                            if (bl) return;
                            0v.4(this.5.poll());
                            if (bl) return;
                        }
                        if (bl) return;
                        this.7.0();
                        if (bl) return;
                        return;
                    }
                } else {
                    do {
                        if (bl) return;
                        if (!0v.9(this.5.peek())) break block10;
                        if (bl) return;
                        if (bl) return;
                        0v.4(this.5.poll());
                        if (bl) return;
                    } while (stringArray == null);
                    if (bl) return;
                }
            }
            if (bl) return;
        }, new Predicate[(int)((long)-1238691631 ^ (long)-1238691631)]);
        this.1 = new 34_(this, (byte)((long)-2058869355 ^ (long)-2058869355));
        this.1.9();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ boolean 0(List list, bmb bmb2) {
        boolean bl = \u2002\u2008\u2006\u2007;
        if (bl || bl) return true;
        if (!list.contains(bmb2)) {
            if (bl) return true;
            return (int)((long)-1924113668 ^ (long)-1924113667) != 0;
        }
        if (!bl) return (int)((long)940424185 ^ (long)940424185) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean 9(bmb bmb2) {
        boolean bl = \u2002\u2008\u2006\u2007;
        if (bl || bl) return true;
        if (bmb2 != null) {
            if (bl) return true;
            if (0v.3.s.bm.a.indexOf((Object)bmb2) >= 0) {
                if (bl) return true;
                return (int)((long)1737196967 ^ (long)1737196966) != 0;
            }
        }
        if (!bl) return (int)((long)-2101565841 ^ (long)-2101565841) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 9(List list, 2w w) {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2002\u2008\u2006\u2007;
                    if (bl || bl) break block2;
                    if ((list = w.8(list)).size() <= 0) break block3;
                    if (bl || bl) break block2;
                    w = list.get((int)((long)706714352 ^ (long)706714352));
                    if (bl || bl) break block2;
                    list.forEach(arg_0 -> this.0((bmb)w, arg_0));
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 0(bmb bmb2, bmb bmb3) {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2002\u2008\u2006\u2007;
                    if (bl || bl) break block2;
                    if (bmb3 == bmb2) break block3;
                    if (bl) break block2;
                    if (this.5.contains(bmb3)) break block3;
                    if (bl || bl) break block2;
                    this.5.offer(bmb3);
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0v.\u2002\u2008\u2006\u2007;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-1892482803 ^ (long)-1892482813)];
            if (var7) break block23;
            var3_2 = (int)((long)1930615202 ^ (long)1930615202);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\uf34a\udb20\uc869\uc042\uf353\udb05\uc8ea\uc0d8\uf3b2\udbf1\uc809\uc020\uf3be\udbec\uc8d4\uc0ba\uf328\udb14\uc845\uc008\uf3c0\udbd3\uc86b\uc0a3\uf359\udb46\uc877\uc093\uf3fa\udb6f\uc86f\uc01e\uf3f0\udbbb\uc869\uc0e2\uf309\udbd8\uc85c\uc065\uf33d\udb96\uc8ba\uc013\uf3ae\udb49\uc893\uc07c\uf3d0\udb59\uc8a0\uc073\uf3fd\udbbf\uc882\uc06a\uf350\udb22\uc8f1\uc0bb\uf3a9\udb82\uc8c1\uc091\uf3b2\udb7f\uc841\uc064\uf3cb\udbf7\uc8a4\uc042\uf32f\udbff\uc8b6\uc0a8\uf35c\udbfe\uc8da\uc015\uf3bd\udbe1\uc8f7\uc0b6\uf396\udb04\uc8a1\uc04d\uf31f\udb04\uc811\uc0a9\uf32f\udb3d\uc8e2\uc0d6\uf395\udb72\uc881\uc05b\uf3d9\udb24\uc876\uc000\uf359\udb8c\uc870\uc018\uf331\udb7e\uc82b\uc002\uf3b3\udb64\uc851\uc071\uf3d2\udba9\uc804\uc048\uf386\udb94\uc8a8\uc09d\uf36c\udbee\uc80d\uc0d5\uf390\udb4d\uc8cd\uc0a4\uf3ff\udba9\uc8e7\uc0d0\uf3bf\udb31\uc8a5\uc0c0\uf3fc\udb4f\uc88d\uc01c\uf36f\udbf7\uc834\uc0fb\uf3bd\udb5c\uc8f6\uc0a3\uf32f\udb64\uc85a\uc05b\uf33a\udbaa\uc8d9\uc00e\uf387\udb82\uc8b0\uc0da\uf37e\udb89\uc8bc\uc0fc\uf3bc\udb32\uc865\uc079\uf3b6\udbff\uc83b\uc01e\uf31c\udbd2\uc87f\uc0bd\uf35b\udb0e\uc8a4\uc07f\uf3fc\udb5f\uc8a7\uc095\uf384\udbdd\uc84b\uc03a\uf3aa\udbc5\uc8c4\uc064\uf339\udb4a\uc879\uc030\uf33f\udb56\uc85d\uc0a9\uf306\udbf8\uc853\uc0e0\uf32b\udb82\uc8de\uc0a9\uf315\udbbe\uc845\uc07b\uf309\udbf4\uc8d6\uc0a3\uf3c3\udb2f\uc8a1\uc093\uf3df\udba5\uc82c\uc0a9\uf3ce\udb31\uc878\uc0b8\uf33d\udb41\uc878\uc09d\uf306\udb22\uc80f\uc079\uf31e\udb45\uc800\uc0bd\uf3ab\udb84\uc8c0\uc040\uf333\udb1b\uc8af\uc053\uf32a\udb52\uc848\uc012\uf3ce\udb98\uc86d\uc0e0\uf32f\udb36\uc86c\uc035\uf3fc\udb67\uc8ea\uc0b7\uf394\udb38\uc8cd\uc019\uf326\udbcb", 1472910680);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-250118641 ^ (long)-250118647);
            if (var7) break block23;
            var0_6 = (int)((long)894175692 ^ (long)-894175693);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)151077002 ^ (long)151077068);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-187042233 ^ (long)187042232);
                    if (0v.\u2002\u2008\u2006\u2007) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0v.\u2002\u2008\u2006\u2007) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u8c2b\ua42a\ub7d6\ubf30\u8cab\ua4a0\ub7ec\ubfc9\u8c44\ua4dc\ub7c2\ubf0c\u8c10\ua457\ub71b\ubf3c\u8cd9\ua4d3\ub7b3\ubff0\u8cda\ua49b\ub721\ubfd4\u8cb7\ua4ae\ub7dd\ubf35\u8c15\ua424\ub7dd\ubfb2\u8caa\ua422\ub7b9\ubf71\u8cb8\ua49d\ub710\ubf96\u8ccb\ua4df\ub7ce\ubfb1\u8c72\ua46c\ub7b9\ubfc5", 949791267);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)34513390 ^ (long)34513387);
                            var0_6 = (int)((long)278929389 ^ (long)-278929390);
                            while (true) {
                                v0 = (int)((long)295227312 ^ (long)295227267);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)2143552435 ^ (long)2143552435);
                                if (!0v.\u2002\u2008\u2006\u2007) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0v.\u2002\u2008\u2006\u2007) ** continue;
                                throw null;
                            }
                            0v.d = var5_1;
                            0v.e = new String[(int)((long)-746245608 ^ (long)-746245610)];
                            if (!0v.\u2002\u2008\u2006\u2007) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1053107531 ^ (long)1053107531);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)999556989 ^ (long)999556988)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-194084740 ^ (long)-194084741)) {
                                case 0: {
                                    v15 = (int)((long)732601820 ^ (long)732601742);
                                    if (!0v.\u2002\u2008\u2006\u2007) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)765981263 ^ (long)765981233);
                                    if (!0v.\u2002\u2008\u2006\u2007) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1710652283 ^ (long)1710652235);
                                    if (!0v.\u2002\u2008\u2006\u2007) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)78432294 ^ (long)78432297);
                                    if (!0v.\u2002\u2008\u2006\u2007) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)178854430 ^ (long)178854413);
                                    if (!0v.\u2002\u2008\u2006\u2007) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1798291630 ^ (long)1798291673);
                                    if (!0v.\u2002\u2008\u2006\u2007) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1094495279 ^ (long)1094495256);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0v.\u2002\u2008\u2006\u2007);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

