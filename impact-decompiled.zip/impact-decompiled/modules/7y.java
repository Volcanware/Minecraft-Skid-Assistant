/* ==========================================================================
 * MODULE: Scaffold
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Places blocks under you
 * OBFUSCATED CLASS: net.impactclient.7y
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aot
 *  aou
 *  bfw
 *  bkh
 *  blx
 *  bmb
 *  bny
 *  boa
 *  brc
 *  brw
 *  brx
 *  buo
 *  bup
 *  bwz
 *  byb
 *  bzw
 *  cai
 *  ceh
 *  com.mojang.blaze3d.systems.RenderSystem
 *  dci
 *  dcj
 *  dcn
 *  ddh
 *  fx
 *  gc
 *  gc$a
 *  gr
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  oj
 *  tq
 */
package net.impactclient;

import clientapi.load.mixin.7.2;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.1o;
import net.impactclient.1r;
import net.impactclient.2c;
import net.impactclient.2o;
import net.impactclient.2w$6X;
import net.impactclient.34L;
import net.impactclient.34R;
import net.impactclient.34X;
import net.impactclient.3X;
import net.impactclient.3d;
import net.impactclient.3e;
import net.impactclient.3sx;
import net.impactclient.4L;
import net.impactclient.4X;
import net.impactclient.4m;
import net.impactclient.4s;
import net.impactclient.5H;
import net.impactclient.5K;
import net.impactclient.5Q;
import net.impactclient.66;
import net.impactclient.8S;
import net.impactclient.9C;
import net.impactclient.9N;
import net.impactclient.9V;
import net.impactclient.9b;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7y
extends 3X
implements 34R {
    private 1P 9;
    private 1P 4X;
    private 5H 8;
    @EventHandler
    private final Listener<2o> 45;
    private 1P 4p;
    @EventHandler
    private final Listener<4X> 47;
    private boolean 6;
    private 1P 4;
    @EventHandler
    private final Listener<3sx> 0;
    private static final String[] d;
    private 5H 5;
    private 1P 2;
    private 1P 7;
    private static final String[] e;
    public static final boolean \u200c;
    private final 9N<Integer> 4f;
    private 1P 4M;
    private 1P 1;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7y.\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-187143315 ^ (long)187143356)) & (int)((long)-688392795 ^ (long)-688453030);
            if (var9_2) ** GOTO lbl-1000
            if (7y.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7y.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1301105050 ^ (long)1301105050)] & (int)((long)1427455437 ^ (long)1427455282)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)80869690 ^ (long)80869741);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1626818439 ^ (long)1626818337);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1427618297 ^ (long)1427618175);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1191361094 ^ (long)1191361113);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-729492435 ^ (long)-729492398);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1340978144 ^ (long)-1340978009);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1373722269 ^ (long)-1373722123);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1372740928 ^ (long)1372741054);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-111210021 ^ (long)-111210199);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1814768944 ^ (long)1814768936);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1557633458 ^ (long)1557633379);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1133942990 ^ (long)1133943005);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1485870336 ^ (long)1485870442);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-663347948 ^ (long)-663347756);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-106730131 ^ (long)-106730020);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-26652504 ^ (long)-26652430);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1764054970 ^ (long)1764054842);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-162959289 ^ (long)-162959308);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1288438632 ^ (long)1288438562);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-468550156 ^ (long)-468550310);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1215997119 ^ (long)1215997044);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-873534922 ^ (long)-873534974);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1528491813 ^ (long)1528491933);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1210552534 ^ (long)-1210552446);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-714914491 ^ (long)-714914459);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1065440527 ^ (long)-1065440747);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1386602342 ^ (long)-1386602324);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-2085161385 ^ (long)-2085161378);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-374507166 ^ (long)-374507195);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1562918483 ^ (long)-1562918462);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-663990533 ^ (long)-663990656);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1190793400 ^ (long)-1190793306);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1284056319 ^ (long)1284056211);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-454374423 ^ (long)-454374532);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)333075548 ^ (long)333075686);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1116611887 ^ (long)1116611954);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1678245861 ^ (long)-1678245781);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)567008408 ^ (long)567008289);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)911724407 ^ (long)911724530);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1877597172 ^ (long)1877597125);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-159432333 ^ (long)-159432271);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1419049602 ^ (long)1419049571);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-443424579 ^ (long)-443424682);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-76770313 ^ (long)-76770449);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1175555015 ^ (long)1175554900);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1868779088 ^ (long)1868779234);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-38832735 ^ (long)-38832826);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1188314998 ^ (long)1188315101);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1990247451 ^ (long)-1990247479);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-978287492 ^ (long)-978287416);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)617853642 ^ (long)617853454);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)262390212 ^ (long)262390105);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1008308493 ^ (long)-1008308660);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1645281528 ^ (long)-1645281371);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1891704039 ^ (long)1891703883);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1915148993 ^ (long)1915148894);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)744338056 ^ (long)744338013);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1776754496 ^ (long)-1776754539);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1738255894 ^ (long)1738255983);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1965717836 ^ (long)1965717970);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)467330316 ^ (long)467330559);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1883842451 ^ (long)-1883842427);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1206358682 ^ (long)-1206358746);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-330812421 ^ (long)-330812460);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-708481987 ^ (long)-708481807);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1485463721 ^ (long)-1485463800);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)601974726 ^ (long)601974542);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-474217868 ^ (long)-474217829);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1879647636 ^ (long)1879647625);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-294859602 ^ (long)-294859531);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)917066036 ^ (long)917066084);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)541144172 ^ (long)541144317);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-850199884 ^ (long)-850199846);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-87230955 ^ (long)-87230793);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1538603129 ^ (long)1538603169);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1237946741 ^ (long)-1237946782);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1778832923 ^ (long)-1778832932);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)214689310 ^ (long)214689501);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-373870326 ^ (long)-373870147);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)772104425 ^ (long)772104369);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)871319362 ^ (long)871319339);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)2009430176 ^ (long)2009430212);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)316317526 ^ (long)316317655);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1927187688 ^ (long)-1927187558);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)219897362 ^ (long)219897433);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1806397574 ^ (long)-1806397685);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1217528695 ^ (long)1217528598);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1841873936 ^ (long)-1841874107);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1854757602 ^ (long)1854757596);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-277107519 ^ (long)-277107685);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)2040340311 ^ (long)2040340337);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-933330138 ^ (long)-933330036);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)479380062 ^ (long)479380219);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1775390517 ^ (long)1775390505);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1640553746 ^ (long)1640553900);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-2113388918 ^ (long)-2113388825);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1175229332 ^ (long)-1175229270);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1954888601 ^ (long)1954888595);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-850152393 ^ (long)-850152382);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-783874528 ^ (long)-783874356);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1468305807 ^ (long)-1468305829);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1574115070 ^ (long)1574114911);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)930918548 ^ (long)930918572);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-861341808 ^ (long)-861341738);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-92980972 ^ (long)-92980751);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1568977139 ^ (long)1568977039);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-477124922 ^ (long)-477124977);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-521436886 ^ (long)-521436704);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1595528190 ^ (long)-1595528116);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1411924901 ^ (long)1411924888);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1398920400 ^ (long)1398920391);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1869860868 ^ (long)-1869860910);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1865134998 ^ (long)-1865135059);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-441755044 ^ (long)-441754893);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-27762047 ^ (long)-27762100);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-218330949 ^ (long)-218330943);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1734939079 ^ (long)-1734938978);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-376893448 ^ (long)-376893621);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)381208103 ^ (long)381208209);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)741563338 ^ (long)741563326);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1554694837 ^ (long)-1554694838);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1922230846 ^ (long)-1922230949);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1426664739 ^ (long)1426664761);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)695383039 ^ (long)695382809);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-937908998 ^ (long)-937909021);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1269865456 ^ (long)1269865456);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1970698221 ^ (long)1970698143);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)62640980 ^ (long)62640984);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1609942297 ^ (long)1609942321);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)12951585 ^ (long)12951714);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1912574158 ^ (long)-1912574106);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1084351556 ^ (long)-1084351649);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1733035420 ^ (long)-1733035437);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1099736625 ^ (long)-1099736682);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-2095409117 ^ (long)-2095409135);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)211285893 ^ (long)211285846);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1396456984 ^ (long)-1396457102);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)496881237 ^ (long)496881240);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1256131573 ^ (long)1256131372);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-549366569 ^ (long)-549366749);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1217190332 ^ (long)-1217190223);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1206537646 ^ (long)-1206537692);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1326978597 ^ (long)-1326978696);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-931999248 ^ (long)-931999293);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-109712770 ^ (long)-109712761);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-226324002 ^ (long)-226324143);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-544484164 ^ (long)-544484137);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1256545492 ^ (long)1256545324);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-571474881 ^ (long)-571474703);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-795245476 ^ (long)-795245415);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1695948906 ^ (long)-1695948921);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)154155769 ^ (long)154155558);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)454589511 ^ (long)454589445);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-972224955 ^ (long)-972225001);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1206101476 ^ (long)1206101453);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)80616120 ^ (long)80615972);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)155430975 ^ (long)155431094);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1333223994 ^ (long)-1333224028);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)2076684347 ^ (long)2076684502);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)109100742 ^ (long)109100709);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1993060012 ^ (long)-1993060069);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1669815875 ^ (long)1669815993);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-484983348 ^ (long)-484983365);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1450346000 ^ (long)1450346068);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1654280804 ^ (long)-1654280801);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1938367385 ^ (long)1938367419);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-708132672 ^ (long)-708132780);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1764978389 ^ (long)-1764978373);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1621564394 ^ (long)-1621564179);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1345180279 ^ (long)1345180259);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)245458502 ^ (long)245458617);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-584961303 ^ (long)-584961336);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-391000991 ^ (long)-391001007);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-908516250 ^ (long)-908516242);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1981782278 ^ (long)1981782420);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-869955889 ^ (long)-869955994);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)466292874 ^ (long)466292872);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)2014804111 ^ (long)2014804020);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1681125137 ^ (long)-1681125164);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-292563897 ^ (long)-292563935);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1203408520 ^ (long)1203408455);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1647120849 ^ (long)-1647120772);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-613881942 ^ (long)-613881866);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1448474196 ^ (long)-1448474309);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-970533673 ^ (long)-970533713);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-192770766 ^ (long)-192770734);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-840829250 ^ (long)-840829382);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)463409120 ^ (long)463409029);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1186229518 ^ (long)-1186229634);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)437434167 ^ (long)437434132);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1686846097 ^ (long)1686846040);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)503261247 ^ (long)503261187);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1960303968 ^ (long)1960304039);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1885924337 ^ (long)1885924324);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1883434026 ^ (long)1883434020);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1521180949 ^ (long)1521180946);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1894658838 ^ (long)-1894658976);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)243267046 ^ (long)243266992);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1753354308 ^ (long)-1753354322);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-282642019 ^ (long)-282642099);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1018465861 ^ (long)1018465971);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-246708581 ^ (long)-246708634);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-605176833 ^ (long)-605176839);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1948138069 ^ (long)1948138120);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-896725001 ^ (long)-896725216);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)145205477 ^ (long)145205358);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-601580029 ^ (long)-601579838);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-942401850 ^ (long)-942401913);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1693902066 ^ (long)-1693902031);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1899670295 ^ (long)1899670525);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1476481201 ^ (long)-1476481199);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1617429685 ^ (long)1617429739);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1803350870 ^ (long)-1803351018);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1060536722 ^ (long)1060536677);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)2009961211 ^ (long)2009961007);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1771655006 ^ (long)1771655040);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1829150774 ^ (long)-1829150846);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-550150340 ^ (long)-550150335);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1683427039 ^ (long)1683427045);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-234978217 ^ (long)-234978284);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-31363393 ^ (long)-31363438);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-431435557 ^ (long)-431435712);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1326427179 ^ (long)-1326427291);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-447261035 ^ (long)-447260967);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1860663998 ^ (long)1860663811);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)515670920 ^ (long)515670878);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)745372987 ^ (long)745372973);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-353138087 ^ (long)-353138062);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1520054791 ^ (long)-1520054860);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1737051615 ^ (long)-1737051590);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)584550711 ^ (long)584550807);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-996850400 ^ (long)-996850223);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1569906984 ^ (long)1569907084);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1401437680 ^ (long)-1401437544);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1910068445 ^ (long)-1910068442);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-852765307 ^ (long)-852765319);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-785847155 ^ (long)-785847096);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1269497320 ^ (long)-1269497271);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-598016243 ^ (long)-598016250);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)0xEB6666B ^ (long)246834827);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1465255926 ^ (long)-1465255801);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)607966897 ^ (long)607966934);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)281741139 ^ (long)281741233);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1243703516 ^ (long)-1243703520);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1182327301 ^ (long)-1182327346);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)774679871 ^ (long)774680036);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-347516346 ^ (long)-347516317);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1845436020 ^ (long)-1845436029);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1153869539 ^ (long)1153869451);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)860878845 ^ (long)860878809);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-80542797 ^ (long)-80542909);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1846718838 ^ (long)1846718968);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1361732331 ^ (long)-1361732245);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1425647107 ^ (long)-1425647251);
                    if (!7y.\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-767853723 ^ (long)-767853639);
                    if (!7y.\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-972999218 ^ (long)-972999396);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-810261093 ^ (long)-810261148)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-34563857 ^ (long)-34576624)) >>> (int)((long)-625180203 ^ (long)-625180195)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1338726896 ^ (long)-1338726896);
            if (!7y.\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1740362841 ^ (long)-1740362843);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1438917149 ^ (long)1438917150) | var5_6 << (int)((long)792113169 ^ (long)792113172)) ^ var3_4[var7_8]) & (int)((long)67528478 ^ (long)67528673);
                    if (7y.\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-96530014 ^ (long)-96530015) | var6_7 << (int)((long)-1564834633 ^ (long)-1564834638)) ^ var3_4[var7_8]) & (int)((long)1921856897 ^ (long)1921856894);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7y.e[var2_3] = new String(var3_4).intern();
        }
        return 7y.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean 1(blx blx2) {
        boolean bl = \u200c;
        if (bl || bl) return true;
        if (!(blx2 instanceof bkh)) {
            if (bl || bl) return true;
            return (int)((long)-1669528235 ^ (long)-1669528235) != 0;
        }
        if (!bl) return 7y.0(((bkh)blx2).e().n());
        return true;
    }

    public 7y() {
        boolean bl = \u200c;
        super(7y.b((int)((long)-1005122109 ^ (long)1005122058), (int)((long)-1877184750 ^ (long)-1877194005)) /* "Scaffold" */, 7y.b((int)((long)-908197751 ^ (long)908197714), (int)((long)-601115914 ^ (long)601104389)) /* "Places blocks under you" */);
        Boolean bl2 = Boolean.TRUE;
        34X x2 = (34X)((34X)((34X)this.4().5(7y.b((int)((long)536802607 ^ (long)-536802578), (int)((long)703866361 ^ (long)-703856980)) /* "Safe" */)).7(7y.b((int)((long)1656781727 ^ (long)-1656781729), (int)((long)-1296856110 ^ (long)-1296856098)) /* "safe" */)).1(7y.b((int)((long)-2005987362 ^ (long)2005987341), (int)((long)-549246172 ^ (long)549232925)) /* "Locks the scaffold block in your hand" */);
        ((34X)((34X)((34X)this.4().5(7y.b((int)((long)536802607 ^ (long)-536802578), (int)((long)703866361 ^ (long)-703856980)) /* "Safe" */)).7(7y.b((int)((long)1656781727 ^ (long)-1656781729), (int)((long)-1296856110 ^ (long)-1296856098)) /* "safe" */)).1(7y.b((int)((long)-2005987362 ^ (long)2005987341), (int)((long)-549246172 ^ (long)549232925)) /* "Locks the scaffold block in your hand" */)).7 = bl2;
        this.2 = (1P)x2.5();
        bl2 = Boolean.TRUE;
        x2 = (34X)((34X)((34X)this.4().5(7y.b((int)((long)-1291584228 ^ (long)1291584203), (int)((long)297361585 ^ (long)-297361678)) /* "Swing" */)).7(7y.b((int)((long)2025662176 ^ (long)-2025662146), (int)((long)-789441968 ^ (long)789417594)) /* "swing" */)).1(7y.b((int)((long)-829606991 ^ (long)829607015), (int)((long)-2073530385 ^ (long)2073554941)) /* "Whether or not you swing your arm when you place blocks" */);
        ((34X)((34X)((34X)this.4().5(7y.b((int)((long)-1291584228 ^ (long)1291584203), (int)((long)297361585 ^ (long)-297361678)) /* "Swing" */)).7(7y.b((int)((long)2025662176 ^ (long)-2025662146), (int)((long)-789441968 ^ (long)789417594)) /* "swing" */)).1(7y.b((int)((long)-829606991 ^ (long)829607015), (int)((long)-2073530385 ^ (long)2073554941)) /* "Whether or not you swing your arm when you place blocks" */)).7 = bl2;
        this.7 = (1P)x2.5();
        bl2 = Boolean.TRUE;
        x2 = (34X)((34X)((34X)this.4().5(7y.b((int)((long)-1387478158 ^ (long)1387478176), (int)((long)154056657 ^ (long)154043227)) /* "Prefer Offhand" */)).7(7y.b((int)((long)1341360727 ^ (long)-1341360766), (int)((long)1149522106 ^ (long)-1149525444)) /* "preferOffhand" */)).1(7y.b((int)((long)1531231394 ^ (long)-1531231386), (int)((long)324650183 ^ (long)-324635967)) /* "If both the hotbar and offhand have valid blocks,\\nthe offhand's item will be prefered over the hotbar." */);
        ((34X)((34X)((34X)this.4().5(7y.b((int)((long)-1387478158 ^ (long)1387478176), (int)((long)154056657 ^ (long)154043227)) /* "Prefer Offhand" */)).7(7y.b((int)((long)1341360727 ^ (long)-1341360766), (int)((long)1149522106 ^ (long)-1149525444)) /* "preferOffhand" */)).1(7y.b((int)((long)1531231394 ^ (long)-1531231386), (int)((long)324650183 ^ (long)-324635967)) /* "If both the hotbar and offhand have valid blocks,\\nthe offhand's item will be prefered over the hotbar." */)).7 = bl2;
        this.4p = (1P)x2.5();
        this.4 = (1P)((34X)((34X)((34X)this.4().5(7y.b((int)((long)1119869214 ^ (long)-1119869221), (int)((long)-551793544 ^ (long)551799620)) /* "Tower" */)).7(7y.b((int)((long)1606187530 ^ (long)-1606187568), (int)((long)1236879467 ^ (long)-1236866665)) /* "tower" */)).1(7y.b((int)((long)-976525829 ^ (long)976525866), (int)((long)-843388345 ^ (long)-843395943)) /* "Eases creating towers when scaffolding" */)).5();
        this.1 = (1P)((34X)((34X)((34X)this.4().5(7y.b((int)((long)-548001462 ^ (long)548001426), (int)((long)-1341205 ^ (long)1336977)) /* "Debug" */)).7(7y.b((int)((long)-285456175 ^ (long)285456141), (int)((long)-1015961925 ^ (long)1015941643)) /* "debug" */)).1(7y.b((int)((long)-383502300 ^ (long)383502316), (int)((long)-500975593 ^ (long)-500981284)) /* "Shows a debug view of block placement" */)).5();
        bl2 = Boolean.TRUE;
        x2 = (34X)((34X)((34X)this.4().5(7y.b((int)((long)-386272056 ^ (long)386272017), (int)((long)1587898606 ^ (long)-1587886486)) /* "Face" */)).7(7y.b((int)((long)868549372 ^ (long)-868549341), (int)((long)1888801466 ^ (long)1888793775)) /* "face" */)).1(7y.b((int)((long)-1406171748 ^ (long)1406171713), (int)((long)127453556 ^ (long)-127457901)) /* "Shows the block face that was placed off of" */);
        ((34X)((34X)((34X)this.4().5(7y.b((int)((long)-386272056 ^ (long)386272017), (int)((long)1587898606 ^ (long)-1587886486)) /* "Face" */)).7(7y.b((int)((long)868549372 ^ (long)-868549341), (int)((long)1888801466 ^ (long)1888793775)) /* "face" */)).1(7y.b((int)((long)-1406171748 ^ (long)1406171713), (int)((long)127453556 ^ (long)-127457901)) /* "Shows the block face that was placed off of" */)).7 = bl2;
        this.4X = (1P)((34X)x2.3(this.1)).5();
        bl2 = Boolean.TRUE;
        x2 = (34X)((34X)((34X)this.4().5(7y.b((int)((long)550765079 ^ (long)-550765103), (int)((long)-1374813331 ^ (long)-1374785430)) /* "Place Offset" */)).7(7y.b((int)((long)1321697120 ^ (long)-1321697104), (int)((long)-930096928 ^ (long)930110264)) /* "offset" */)).1(7y.b((int)((long)1014492618 ^ (long)-1014492664), (int)((long)-1369499182 ^ (long)1369489628)) /* "Shows the random placement offset" */);
        ((34X)((34X)((34X)this.4().5(7y.b((int)((long)550765079 ^ (long)-550765103), (int)((long)-1374813331 ^ (long)-1374785430)) /* "Place Offset" */)).7(7y.b((int)((long)1321697120 ^ (long)-1321697104), (int)((long)-930096928 ^ (long)930110264)) /* "offset" */)).1(7y.b((int)((long)1014492618 ^ (long)-1014492664), (int)((long)-1369499182 ^ (long)1369489628)) /* "Shows the random placement offset" */)).7 = bl2;
        this.4M = (1P)((34X)x2.3(this.1)).5();
        bl2 = Boolean.TRUE;
        x2 = (34X)((34X)((34X)this.4().5(7y.b((int)((long)-506329029 ^ (long)506329084), (int)((long)800157277 ^ (long)-800132211)) /* "Predict Trace" */)).7(7y.b((int)((long)-889477703 ^ (long)889477741), (int)((long)-1568488311 ^ (long)1568498565)) /* "predict" */)).1(7y.b((int)((long)-4216071 ^ (long)4216122), (int)((long)-789070779 ^ (long)-789058976)) /* "Shows a line tracing the prediction path for placement" */);
        ((34X)((34X)((34X)this.4().5(7y.b((int)((long)-506329029 ^ (long)506329084), (int)((long)800157277 ^ (long)-800132211)) /* "Predict Trace" */)).7(7y.b((int)((long)-889477703 ^ (long)889477741), (int)((long)-1568488311 ^ (long)1568498565)) /* "predict" */)).1(7y.b((int)((long)-4216071 ^ (long)4216122), (int)((long)-789070779 ^ (long)-789058976)) /* "Shows a line tracing the prediction path for placement" */)).7 = bl2;
        this.9 = (1P)((34X)x2.3(this.1)).5();
        this.4f = 4s.6();
        this.8 = null;
        this.5 = null;
        this.0 = new Listener(sx -> {
            block3: {
                block2: {
                    boolean bl = \u200c;
                    if (bl || bl) break block2;
                    this.5 = null;
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)1327536387 ^ (long)1327536387)]);
        this.47 = new Listener(this::7, new Predicate[(int)((long)2131629578 ^ (long)2131629578)]);
        this.45 = new Listener(object -> {
            boolean bl;
            block12: {
                block11: {
                    bl = \u200c;
                    if (bl || bl) return;
                    if (!this.1.2) break block11;
                    if (bl) return;
                    if (this.5 != null) break block12;
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            RenderSystem.pushMatrix();
            if (bl || bl) return;
            9b.6((boolean)((long)-2056399722 ^ (long)-2056399721));
            if (bl || bl) return;
            object = (2c)3.ac();
            RenderSystem.translated((double)(-object.getRenderPosX()), (double)(-object.getRenderPosY()), (double)(-object.getRenderPosZ()));
            if (bl || bl) return;
            if (this.4X.2) {
                if (bl || bl) return;
                int n = Math.max((int)((long)-1740094093 ^ (long)-1740094093), this.5.9.e().a());
                if (bl || bl) return;
                fx fx2 = 66.5(fx.b, this.5.9.n(), (double)n);
                if (bl || bl) return;
                fx fx3 = 66.5(66.2, this.5.9.n(), (double)n);
                if (bl || bl) return;
                fx3 = new dci(fx2, fx3).a(this.5.7);
                if (bl || bl) return;
                float[] fArray = 34L.5((int)((long)200112245 ^ (long)-195607737));
                if (bl || bl) return;
                9C.1((dci)fx3, 34L.4(fArray), 1.0f);
                if (bl || bl) return;
                fArray[(int)((long)-1525631501 ^ (long)-1525631504)] = 0.2f;
                if (bl || bl) return;
                9C.1((dci)fx3, 34L.4(fArray));
                if (bl) return;
            }
            if (bl) return;
            if (this.4M.2) {
                if (bl || bl) return;
                9C.1(new dci(-0.03125, -0.03125, -0.03125, 0.03125, 0.03125, 0.03125).c(this.5.4).a(this.5.7), (int)((long)-1627291764 ^ (long)-553549940));
                if (bl) return;
            }
            if (bl) return;
            if (this.9.2) {
                if (bl || bl) return;
                RenderSystem.lineWidth((float)1.5f);
                if (bl || bl) return;
                5K.6((int)((long)-1591504792 ^ (long)1579389032));
                if (bl || bl) return;
                4L[] lArray = new 4L[(int)((long)-1520565398 ^ (long)-1520565397)];
                lArray[(int)((long)394668781 ^ (long)394668781)] = 4L.c;
                9b.3(lArray);
                if (bl || bl) return;
                9b.5.addVertex((float)this.5.1.9, (float)this.5.1.1, (float)this.5.1.2).addVertex((float)this.5.6.9, (float)this.5.6.1 + 1.0f, (float)this.5.6.2).addVertex((float)this.5.5.u() + 0.5f, (float)this.5.5.v() + 1.0f, (float)this.5.5.w() + 0.5f).draw((int)((long)-2068463066 ^ (long)-2068463067));
                if (bl || bl) return;
                9b.3();
                if (bl) return;
            }
            if (bl) return;
            9b.6((boolean)((long)1831745258 ^ (long)1831745258));
            if (bl || bl) return;
            RenderSystem.popMatrix();
            if (!bl && !bl) return;
        }, new Predicate[(int)((long)-834553846 ^ (long)-834553846)]);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        block3: {
            block2: {
                boolean bl = \u200c;
                if (bl || bl) break block2;
                7y y = this;
                y.5 = null;
                y.8 = null;
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean 0(ceh ceh2) {
        boolean bl;
        block8: {
            block7: {
                bl = \u200c;
                if (bl || bl) return true;
                buo buo2 = ceh2.b();
                if (bl || bl) return true;
                if (buo.a((ddh)ceh2.k((brc)7y.3.r, fx.b))) break block7;
                if (bl) return true;
                if (buo2 instanceof bwz) break block7;
                if (bl) return true;
                if (buo2 instanceof cai) break block7;
                if (bl) return true;
                if (!(buo2 instanceof bzw)) break block8;
                if (bl) return true;
            }
            if (bl) return true;
            return (int)((long)334445342 ^ (long)334445343) != 0;
        }
        if (!bl) return (int)((long)-1047281812 ^ (long)-1047281812) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static 5H 6(fx fx2, bkh bkh2, 8S s, 8S s2) {
        boolean bl;
        gr gr2;
        gc gc2;
        int n;
        dcn dcn2;
        boolean bl2;
        boolean bl3;
        block10: {
            bl3 = \u200c;
            if (bl3) return null;
            if (bl3) return null;
            bl2 = bkh2.e() instanceof bzw;
            if (bl3) return null;
            if (bl3) return null;
            dcn2 = gc.values();
            int n2 = ((gc[])dcn2).length;
            if (bl3) return null;
            n = (int)((long)-1535319866 ^ (long)-1535319866);
            if (bl3) return null;
            do {
                block11: {
                    block12: {
                        if (bl3) return null;
                        if (n >= n2) return null;
                        if (bl3) return null;
                        gc2 = dcn2[n];
                        if (gc2 == gc.a) break block11;
                        if (bl3) return null;
                        if (bl3) return null;
                        if (gc2 != gc.b) break block12;
                        if (bl3) return null;
                        if (bl2) break block11;
                        if (bl3) return null;
                    }
                    if (bl3) return null;
                    gr2 = gc2.p();
                    if (bl3) return null;
                    if (bl3) return null;
                    gr2 = new fx(fx2.u() - gr2.u(), fx2.v() - gr2.v(), fx2.w() - gr2.w());
                    if (bl3) return null;
                    if (bl3) return null;
                    ceh ceh2 = 7y.3.r.d_((fx)gr2);
                    bl = ceh2.b() instanceof bzw;
                    if (bl3) return null;
                    if (bl3) return null;
                    if (7y.0(ceh2)) break block10;
                }
                ++n;
            } while (!\u200c);
            throw null;
        }
        if (bl3) return null;
        if (bl3) return null;
        dcn2 = dcn.a;
        if (bl3) return null;
        if (bl3) return null;
        gc.a[] aArray = gc.a.values();
        n = aArray.length;
        if (bl3) return null;
        int n3 = (int)((long)-989875399 ^ (long)-989875399);
        if (bl3) return null;
        do {
            double d2;
            int n4;
            if (bl3) return null;
            if (n3 >= n) return new 5H((fx)gr2, gc2, dcn2, fx2, s, s2, (byte)((long)710769288 ^ (long)710769288));
            if (bl3) return null;
            gc.a a2 = aArray[n3];
            if (a2 == gc2.n()) {
                if (bl3) return null;
                n4 = (int)((long)1878863672 ^ (long)1878863673);
                if (\u200c) {
                    throw null;
                }
            } else {
                n4 = (int)((long)-1378278432 ^ (long)-1378278432);
            }
            int n5 = n4;
            double d3 = 66.4();
            if (bl || bl2) {
                d3 = d3 * 0.5 + 0.5;
            }
            if (n5 != 0) {
                d2 = Math.max((int)((long)101883506 ^ (long)101883506), gc2.e().a());
                if (\u200c) {
                    throw null;
                }
            } else {
                d2 = d3;
            }
            dcn2 = 66.6(dcn2, a2, d2);
            ++n3;
        } while (!\u200c);
        throw null;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private /* synthetic */ void 7(4X var1_1) {
        block38: {
            var9_3 = 7y.\u200c;
            if (var9_3) lbl-1000:
            // 9 sources

            {
                return;
            }
            var2_4 = 3e.5();
            if (var9_3 || var9_3) ** GOTO lbl-1000
            if (!3d.3(this)) break block38;
            if (var9_3 || var9_3) ** GOTO lbl-1000
            return;
        }
        if (var9_3) ** GOTO lbl-1000
        switch (1r.2[var1_1.7.ordinal()]) {
            case 1: {
                if (var9_3) ** GOTO lbl-1000
                var8_5 = (int)((long)1592009185 ^ (long)1592009157);
                if (var9_3) ** GOTO lbl-1000
                do {
                    if (var9_3) ** GOTO lbl-1000
                    if (var8_5 >= (int)((long)-585641326 ^ (long)-585641281)) break;
                    if (var9_3 || var9_3) ** GOTO lbl-1000
                    v0 = (int)7y.1(7y.3.s.bo.a(var8_5).e().b());
                    if (var2_4 != null) ** GOTO lbl33
                    if (v0 == 0) ** GOTO lbl30
                    if (!var9_3 && !var9_3) ** break;
                    ** continue;
                    v0 = var8_5;
                    if (7y.\u200c) {
                        throw null;
                    }
                    ** GOTO lbl33
lbl30:
                    // 1 sources

                    ++var8_5;
                } while (var2_4 == null);
                v0 = (int)((long)-1028508869 ^ (long)1028508868);
lbl33:
                // 3 sources

                var3_7 = v0;
                var4_9 /* !! */  = 7y.3.s.b(aot.b).b();
                if (var3_7 > 0) {
                    v1 = (int)((long)637031151 ^ (long)637031150);
                    if (7y.\u200c) {
                        throw null;
                    }
                } else {
                    v1 = (int)((long)-124084072 ^ (long)-124084072);
                }
                var5_11 = v1;
                var6_14 = 7y.1(var4_9 /* !! */ );
                if (var5_11 == 0 && !var6_14) {
                    return;
                }
                this.8 = null;
                if (7y.3.s.bz()) {
                    return;
                }
                if (!(var5_11 == 0 || this.4p.2 && var6_14)) {
                    v2 = (int)((long)-1250809812 ^ (long)-1250809811);
                    if (7y.\u200c) {
                        throw null;
                    }
                } else {
                    v2 = var7_17 = (int)((long)-1462297588 ^ (long)-1462297588);
                }
                if (v2 != 0) {
                    v3 = aot.a;
                    if (7y.\u200c) {
                        throw null;
                    }
                } else {
                    v3 = var5_12 = aot.b;
                }
                if (var7_17 != 0) {
                    v4 = 7y.3.s.bm.a(var3_7 - (int)((long)955479167 ^ (long)955479131)).b();
                    if (7y.\u200c) {
                        throw null;
                    }
                } else {
                    v4 = var4_9 /* !! */ ;
                }
                var4_9 /* !! */  = (bkh)v4;
                if (this.4.2 && 7y.3.s.aT == 0.0f && 7y.3.s.aR == 0.0f && (7y.3.s.ao() || 7y.3.s.cE() - (double)((int)7y.3.s.cE()) < 0.01)) {
                    v5 = (int)((long)1457377939 ^ (long)1457377938);
                    if (7y.\u200c) {
                        throw null;
                    }
                } else {
                    v5 = (int)((long)50136828 ^ (long)50136828);
                }
                if (v5 != 0 && 7y.3.s.f.g && !(var4_9 /* !! */ .e() instanceof bzw)) {
                    4m.1(0.36838498711586);
                    7y.3.s.c((boolean)((long)-1651551497 ^ (long)-1651551497));
                    var1_1.1 = (int)((long)775121529 ^ (long)775121528);
                }
                if (!this.1(var1_1, (bkh)var4_9 /* !! */ , var5_12, 7y.3.s.p, (boolean)((long)1651893034 ^ (long)1651893034))) {
                    var8_6 = var5_12;
                    var5_12 = var4_9 /* !! */ ;
                    var4_9 /* !! */  = var1_1;
                    var6_15 = this;
                    for (var1_2 = (int)((long)-313535355 ^ (long)313535348); var1_2 < (int)((long)-478913762 ^ (long)-478913775); ++var1_2) {
                        v6 = (int)var6_15.1((4X)var4_9 /* !! */ , (bkh)var5_12, var8_6, 7y.3.s.p + (float)var1_2, (boolean)((long)1538229645 ^ (long)1538229644));
                        if (var2_4 == null) {
                            if (v6 != 0) break;
                            if (var2_4 == null) continue;
                        }
                        break;
                    }
                } else {
                    if (var7_17 != 0 && this.8 != null) {
                        v7 = (int)((long)604842235 ^ (long)604842234);
                        if (7y.\u200c) {
                            throw null;
                        }
                    } else {
                        v7 = (int)((long)1326343165 ^ (long)1326343165);
                    }
                    this.6 = v7;
                    v6 = (int)this.6;
                }
                if (v6 == 0) break;
                this.4f.accept(var3_7 - (int)((long)-1219836020 ^ (long)-1219835992));
                return;
            }
            case 2: {
                if (this.8 == null) {
                    return;
                }
                var3_8 = this.8.7;
                var4_10 = aot.values();
                var5_13 = var4_10.length;
                for (var6_16 = (int)((long)-2027440397 ^ (long)-2027440397); var6_16 < var5_13; ++var6_16) {
                    var7_18 = var4_10[var6_16];
                    if (var2_4 == null) {
                        if (7y.3.q.a(7y.3.s, 7y.3.r, var7_18, new dcj(this.8.4, this.8.9, var3_8, (boolean)((long)-67881795 ^ (long)-67881795))) != aou.a) continue;
                        if (this.7.2) {
                            7y.3.s.a(var7_18);
                            if (var2_4 == null) break;
                        }
                        7y.3.s.e.a((oj)new tq(var7_18));
                        if (var2_4 == null) break;
                        if (var2_4 == null) continue;
                    }
                    ** GOTO lbl118
                }
                if (!this.2.2 && this.6) {
                    this.4f.8();
                }
lbl118:
                // 4 sources

                this.5 = this.8;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7y.\u200c;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-191718807 ^ (long)-191718797)];
            if (var7) break block23;
            var3_2 = (int)((long)-1297512017 ^ (long)-1297512017);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u8ad2\ua3c8\ub014\ub803\u8a67\ua323\ub0ac\ub891\u8a2b\ua352\ub062\ub8e9\u8a1b\ua3cd\ub0cb\ub89e\u8a66\ua309\ub024\ub805\u8a84\ua37a\ub0aa\ub85b\u8a97\ua382\ub05c\ub836\u8a63\ua307\ub0d5\ub8f9\u8af4\ua353\ub046\ub841\u8a9a\ua336\ub0f0\ub870\u8a8a\ua3d7\ub032\ub8b2\u8aec\ua3cf\ub0e6\ub8f1\u8a2e\ua380\ub0b6\ub8f9\u8a05\ua3b5\ub06f\ub8ab\u8a69\ua3d0\ub016\ub8c5\u8a46\ua3c0\ub0de\ub8cc\u8a91\ua3b9\ub044\ub8d5\u8ade\ua36e\ub04e\ub825\u8a40\ua313\ub0f9\ub8f1\u8a48\ua399\ub0fd\ub8a8\u8a40\ua3d8\ub071\ub88c\u8a1f\ua311\ub00c\ub84a\u8aa6\ua33b\ub003\ub8b7\u8af6\ua30b\ub0a6\ub82d\u8a1c\ua35f\ub0fb\ub8ba\u8ab2\ua371\ub0b6\ub805\u8acd\ua3f5\ub0c8\ub8a6\u8a8f\ua348\ub0f5\ub8ef\u8a0a\ua3b6\ub006\ub895\u8aa6\ua3f0\ub018\ub898\u8a08\ua340\ub0ac\ub800\u8a5c\ua3c1\ub0c1\ub887\u8a90\ua315\ub0b9\ub884\u8a6b\ua354\ub0af\ub801\u8af7\ua3d5\ub0a3\ub83e\u8a19\ua3a3\ub0f0\ub867\u8a03\ua3ac\ub08f\ub870\u8a2a\ua344\ub0b6\ub839\u8aaf\ua3c6\ub0e8\ub88b\u8a32\ua311\ub0aa\ub885\u8a8a\ua3d4\ub036\ub8be\u8a99\ua369\ub0e6\ub8a9\u8a45\ua351\ub053\ub83a\u8a4b\ua327\ub006\ub87d\u8ac4\ua35a\ub009\ub8fb\u8a43\ua3a9\ub0f2\ub8a9\u8a3e\ua3e5\ub055\ub887\u8a3b\ua360\ub019\ub882\u8ae1\ua3fd\ub020\ub816\u8a6b\ua317\ub04a\ub851\u8a1a\ua393\ub05b\ub86b\u8ad7\ua366\ub0c1\ub85c\u8aff\ua37c\ub090\ub87b\u8a03\ua32c\ub01b\ub86d\u8a94\ua3ef\ub08a\ub899\u8a88\ua383\ub0f5\ub8a9\u8a57\ua391\ub06c\ub812\u8af7\ua351\ub0a9\ub8c5\u8a7e\ua3c0\ub0de\ub8d7\u8a59\ua3ab\ub0e9\ub882\u8a09\ua342\ub0e7\ub8af\u8a69\ua38e\ub031\ub812\u8a09\ua3cd\ub0eb\ub84a\u8a38\ua399\ub0ba\ub849\u8ac3\ua301\ub06e\ub8e8\u8af0\ua3a7\ub0e6\ub897\u8a95\ua3e4\ub0db\ub887\u8a53\ua3a0\ub030\ub89a\u8ac4\ua3ee\ub028\ub89b\u8a98\ua30c\ub0f3\ub845\u8a29\ua3e1\ub068\ub898\u8a09\ua315\ub0a0\ub8a5\u8a02\ua3ee\ub04d\ub826\u8a86\ua3bb\ub0c0\ub87e\u8a08\ua3a4\ub0a9\ub8e2\u8a4f\ua3f3\ub0c6\ub887\u8ac1\ua328\ub016\ub849\u8ac5\ua3b9\ub073\ub830\u8a74\ua385\ub0ea\ub885\u8a0d\ua341\ub0ee\ub85f\u8aef\ua317\ub0d8\ub819\u8a6f\ua395\ub067\ub853\u8aba\ua393\ub0de\ub879\u8aca\ua372\ub073\ub85b\u8ad7\ua3e6\ub072\ub826\u8a3c\ua36e\ub0df\ub8f9\u8a7c\ua3e0\ub0f3\ub880\u8a48\ua3cb\ub021\ub840\u8a26\ua34d\ub03a\ub8df\u8a94\ua371\ub05d\ub833\u8a2e\ua3c1\ub0d0\ub8a7\u8a79\ua3cc\ub05d\ub81b\u8a68\ua3d6\ub0b1\ub851\u8a80\ua3bb\ub004\ub84d\u8ac0\ua3ef\ub071\ub8c1\u8aa3\ua3a0\ub012\ub887\u8aa7\ua321\ub08d\ub8f1\u8ad1\ua38c\ub09f\ub885\u8ae7\ua32f\ub0b8\ub870\u8a47\ua312\ub0a9\ub856\u8a94\ua36d\ub074\ub850\u8a30\ua357\ub04d\ub884\u8a4f\ua367\ub09d\ub866\u8ae4\ua376\ub064\ub8ad\u8a8d\ua3ad\ub091\ub844\u8ae5\ua35f\ub0f6\ub837\u8a4c\ua3b8\ub066\ub80a\u8a26\ua387\ub006\ub822\u8ae5\ua3b1\ub02d\ub886\u8ac7\ua306\ub0ec\ub874\u8a94\ua390\ub0b7\ub8d0\u8a93\ua38b\ub0bd\ub86b\u8a28\ua331\ub023\ub86d\u8a45\ua388\ub08c\ub819\u8a8e\ua356\ub07f\ub8cb\u8a0d\ua331\ub059\ub8d5\u8a23\ua351\ub054\ub830\u8a08\ua320\ub0e1\ub82f\u8a27\ua39a\ub097\ub862\u8a21\ua349\ub0cc\ub82c\u8aca\ua30b\ub045\ub8a6\u8ad3\ua397\ub076\ub855\u8a81\ua38c\ub0bc\ub8c0\u8a00\ua371\ub069\ub849\u8a4b\ua36b\ub0a5\ub8eb\u8a34\ua36e\ub000\ub840\u8ad4\ua38a\ub0fa\ub85b\u8a6d\ua36d\ub095\ub802\u8a5e\ua315\ub0a2\ub8ba\u8ad9\ua3cf\ub05d", -873812669);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1365832229 ^ (long)1365832195);
            if (var7) break block23;
            var0_6 = (int)((long)-710245797 ^ (long)710245796);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-508077281 ^ (long)-508077231);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1701275537 ^ (long)1701275536);
                    if (7y.\u200c) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7y.\u200c) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u9eff\ub755\ua406\uac80\u9e11\ub70e\ua4ab\uacf5\u9e84\ub726\ua446\uacbb\u9e95\ub715\ua43d\uac19\u9e7d\ub7c6\ua44f\uac11\u9eaf\ub7b0\ua441\uac39\u9ec0\ub7b6\ua4e0\uacc9\u9e58\ub7d9\ua4f3\uac5a\u9e13\ub72c\ua49e\uacd2\u9e37\ub79b\ua48f\uac45\u9e3c\ub713\ua4d3\uac09\u9e0a\ub750", -378029585);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)1631130878 ^ (long)1631130870);
                            var0_6 = (int)((long)-1655312152 ^ (long)1655312151);
                            while (true) {
                                v0 = (int)((long)-2025517041 ^ (long)-2025517055);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-678428405 ^ (long)-678428405);
                                if (!7y.\u200c) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7y.\u200c) ** continue;
                                throw null;
                            }
                            7y.d = var5_1;
                            7y.e = new String[(int)((long)1261626957 ^ (long)1261626967)];
                            if (!7y.\u200c) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)2002990170 ^ (long)2002990170);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)2078780524 ^ (long)2078780525)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)596010142 ^ (long)596010137)) {
                                case 0: {
                                    v15 = (int)((long)-1193806795 ^ (long)-1193806843);
                                    if (!7y.\u200c) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-423436661 ^ (long)-423436630);
                                    if (!7y.\u200c) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1830564118 ^ (long)1830564112);
                                    if (!7y.\u200c) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)303796356 ^ (long)303796426);
                                    if (!7y.\u200c) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1411071964 ^ (long)1411071939);
                                    if (!7y.\u200c) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)240658384 ^ (long)240658318);
                                    if (!7y.\u200c) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)767585250 ^ (long)767585263);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7y.\u200c);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     */
    private boolean 1(4X x2, bkh object, aot aot2, float f, boolean bl) {
        float f2;
        double[] dArray;
        2 var6_10;
        block15: {
            block13: {
                block14: {
                    block12: {
                        void var5_7;
                        void var4_5;
                        boolean bl2 = \u200c;
                        if (bl2 || bl2) break block12;
                        var6_10 = (2)7y.3.s;
                        if (bl2 || bl2) break block12;
                        dArray = 4m.8(4m.1(5Q.b), 7y.3.s.aT, 7y.3.s.aR, (float)var4_5);
                        if (bl2 || bl2) break block12;
                        if (var5_7 == false) break block13;
                        if (!bl2) break block14;
                    }
                    return true;
                }
                f2 = 0.2f;
                if (\u200c) {
                    throw null;
                }
                break block15;
            }
            if (7y.3.s.bA()) {
                f2 = 0.8f;
                if (\u200c) {
                    throw null;
                }
            } else {
                f2 = 0.6f;
            }
        }
        float f3 = f2;
        float f4 = 0.0f;
        do {
            if (!(f4 < 3.0f * f3)) {
                return (int)((long)-1049099632 ^ (long)-1049099632) != 0;
            }
            8S s = var6_10.getPos().7(dArray[(int)((long)1546399933 ^ (long)1546399933)] * (double)f4, -1.0, dArray[(int)((long)-1826281337 ^ (long)-1826281338)] * (double)f4);
            fx fx2 = new fx(s.9, s.1, s.2);
            ceh ceh2 = 7y.3.r.d_(fx2);
            8S s2 = var6_10.getPos();
            this.8 = 7y.6(fx2, object, new 8S(s2), s);
            if (this.8 != null) {
                void var3_4;
                dcn dcn2 = this.8.4.e(new dcn((double)fx2.u(), (double)fx2.v(), (double)fx2.w()));
                1o o = new 1o(this, (brx)7y.3.r, (bfw)7y.3.s, (aot)var3_4, new bmb((brw)object), new dcj(dcn2, this.8.9, this.8.7, (boolean)((long)-63645553 ^ (long)-63645553)));
                bny bny2 = new bny((boa)o);
                if (ceh2.b() == bup.a || ceh2.a(bny2) || ceh2.b() instanceof byb) {
                    9V v = 66.3(66.5(this.8.7).2(66.4(this.8.4)));
                    x2.6(v.6).2(v.3);
                    return (int)((long)-700857471 ^ (long)-700857472) != 0;
                }
            }
            f4 = (float)((double)f4 + 0.05);
        } while (!\u200c);
        throw null;
    }
}

