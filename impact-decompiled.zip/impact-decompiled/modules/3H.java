/* ==========================================================================
 * MODULE: Kill Aura
 * CATEGORY (inferred): Combat
 * DESCRIPTION: Attacks other entities
 * OBFUSCATED CLASS: net.impactclient.3H
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aot
 *  aqm
 *  bjx
 *  bmv
 *  bnf
 *  dck
 *  dcl$a
 *  dzm
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  rd
 */
package net.impactclient;

import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.0F;
import net.impactclient.11;
import net.impactclient.1A;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.1z;
import net.impactclient.2w$6X;
import net.impactclient.2z;
import net.impactclient.33;
import net.impactclient.34H;
import net.impactclient.34X;
import net.impactclient.34c;
import net.impactclient.34e;
import net.impactclient.34s;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3i;
import net.impactclient.3s5;
import net.impactclient.3sx;
import net.impactclient.4X;
import net.impactclient.4t;
import net.impactclient.56;
import net.impactclient.5_;
import net.impactclient.5r;
import net.impactclient.5z;
import net.impactclient.64;
import net.impactclient.66;
import net.impactclient.7E;
import net.impactclient.7H;
import net.impactclient.7S;
import net.impactclient.7X;
import net.impactclient.7f;
import net.impactclient.7m;
import net.impactclient.8F;
import net.impactclient.94;
import net.impactclient.9V;
import net.impactclient.9i;
import net.impactclient.9p;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3H
extends 3X
implements 56 {
    private 1K 2l;
    public 1P 2K;
    private 1P 2a;
    @EventHandler
    private final Listener<3i> 2y;
    private static final String[] e;
    private 1K 7;
    private 1P 5;
    public boolean 22;
    private 1P 2M;
    @EventHandler
    private final Listener<4X> 2L;
    public final 4t 2e;
    public 1A 23;
    private 1z 4;
    public 1K 2Z;
    public 1P 0;
    public static final boolean \u200b;
    private 1P 9;
    private 1P 2g;
    private 1P 2w;
    private 1P 2J;
    private 1P 2z;
    private 1P 2T;
    private 11 2d;
    public 1K 8;
    private static final String[] d;
    public 1P 2A;
    public 1A 2C;
    @EventHandler
    private final Listener<3sx> 2;
    private 1P 2H;
    private 8F 2N;
    public 1A 6;
    private 1P 1;
    private 1P 2s;

    /*
     * Enabled aggressive block sorting
     */
    public final List<aqm> 5(List<aqm> list) {
        boolean bl = \u200b;
        if (bl) return null;
        String string = ((String)this.2d.0()).toLowerCase();
        int n = (int)((long)-2008213620 ^ (long)2008213619);
        String[] stringArray = 3e.5();
        if (bl) return null;
        switch (string.hashCode()) {
            case 288459765: {
                if (bl) return null;
                if (!string.equals(3H.b((int)((long)-967539444 ^ (long)967518062), (int)((long)-2036215489 ^ (long)2036212692)) /* "distance" */)) break;
                if (bl) return null;
                n = (int)((long)1618962993 ^ (long)1618962993);
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case -1221262756: {
                if (bl) return null;
                if (!string.equals(3H.b((int)((long)-2129994536 ^ (long)2130017963), (int)((long)-307845735 ^ (long)307851868)) /* "health" */)) break;
                if (bl) return null;
                n = (int)((long)2103393807 ^ (long)2103393806);
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 1397962786: {
                if (bl) return null;
                if (!string.equals(3H.b((int)((long)-326299938 ^ (long)326282409), (int)((long)-1590098880 ^ (long)-1590080728)) /* "crosshair" */)) break;
                if (bl) return null;
                n = (int)((long)-263174023 ^ (long)-263174021);
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 109549001: {
                if (bl) return null;
                if (!string.equals(3H.b((int)((long)-1371907507 ^ (long)1371928597), (int)((long)-1220904542 ^ (long)-1220912077)) /* "smart" */)) break;
                if (bl) return null;
                n = (int)((long)-1064519822 ^ (long)-1064519823);
                if (bl) return null;
                break;
            }
        }
        if (bl) return null;
        switch (n) {
            case 0: {
                if (bl) return null;
                list.sort(Comparator.comparingDouble(arg_0 -> ((dzm)3H.3.s).g(arg_0)));
                if (bl || bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 1: {
                if (bl) return null;
                list.sort(Comparator.comparingDouble(aqm::dk));
                if (bl || bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 2: {
                if (bl) return null;
                list.sort(Comparator.comparingDouble(66::3));
                if (bl || bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 3: {
                if (bl) return null;
                list.sort(Comparator.comparingDouble(66::2).reversed());
                if (bl) return null;
                break;
            }
        }
        if (!bl) return list;
        return null;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 3H.\u200b;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)231794857 ^ (long)231794939)];
            if (var7) break block23;
            var3_2 = (int)((long)1104599968 ^ (long)1104599968);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ue2e0\uca58\ud98d\ud100\ue2ff\ucae3\ud9d0\ud1c3\ue217\uca8d\ud9cf\ud11d\ue219\ucab4\ud962\ud104\ue231\ucae3\ud955\ud1ce\ue2ce\uca11\ud90c\ud11f\ue20d\uca07\ud935\ud10b\ue2b1\uca10\ud913\ud111\ue2e2\uca10\ud927\ud1a1\ue269\ucaa4\ud953\ud1f8\ue293\ucaf9\ud925\ud11b\ue219\uca28\ud9ec\ud1c9\ue2e1\uca6f\ud9fb\ud19b\ue2e6\ucaad\ud985\ud162\ue2fa\ucaf5\ud999\ud1db\ue21e\uca82\ud9d5\ud162\ue2d3\uca32\ud96f\ud12a\ue201\ucad6\ud9af\ud173\ue2ea\uca79\ud929\ud16e\ue2b9\uca9c\ud943\ud105\ue263\ucaca\ud9c4\ud1d1\ue26f\uca01\ud96b\ud109\ue26d\uca6b\ud927\ud1ce\ue2a1\uca40\ud9c3\ud14c\ue253\uca65\ud9bc\ud1d4\ue28c\uca65\ud965\ud145\ue2a9\uca23\ud9f9\ud145\ue2e7\ucaaf\ud9f0\ud195\ue2d1\uca1f\ud992\ud1f9\ue2d3\uca21\ud92d\ud11c\ue2d0\ucae2\ud9be\ud1fd\ue2bf\uca41\ud904\ud11c\ue244\ucad5\ud916\ud147\ue299\uca91\ud9eb\ud192\ue2d7\ucaf1\ud908\ud1d0\ue272\uca27\ud997\ud1e7\ue243\ucaad\ud9ab\ud12b\ue290\ucafd\ud958\ud15e\ue206\uca3e\ud9ed\ud16b\ue25d\uca73\ud9e2\ud1d7\ue26b\ucae4\ud974\ud1e9\ue297\ucaa5\ud9e4\ud1a5\ue2ab\ucad1\ud92c\ud174\ue2f6\ucaf4\ud958\ud1fc\ue20d\uca81\ud9e0\ud105\ue2f8\uca39\ud945\ud14f\ue2b1\ucaf2\ud9dd\ud17c\ue272\uca13\ud94f\ud189\ue2e2\ucae2\ud95f\ud177\ue2f7\ucad4\ud9a3\ud11f\ue29a\uca85\ud9ec\ud1a5\ue298\uca31\ud9db\ud1fc\ue22d\uca4b\ud9b0\ud199\ue2c1\uca55\ud9d1\ud141\ue2d1\ucaa7\ud91f\ud164\ue2e4\uca01\ud942\ud1b3\ue216\ucaeb\ud982\ud119\ue201\uca3b\ud9a6\ud18d\ue2d6\uca0f\ud99e\ud119\ue2eb\ucad6\ud9d5\ud111\ue203\uca9c\ud9e1\ud11c\ue2fc\uca1a\ud9d4\ud126\ue2b6\uca68\ud9f4\ud153\ue2e7\uca72\ud968\ud1b8\ue241\uca77\ud9c1\ud17e\ue20e\uca08\ud9b5\ud1a1\ue209\uca65\ud98c\ud1f9\ue29d\ucab9\ud9a6\ud197\ue2fc\uca5a\ud989\ud141\ue2a3\uca24\ud907\ud15d\ue2fd\ucafd\ud9c0\ud19d\ue2c1\ucafe\ud9ab\ud1de\ue268\ucaeb\ud963\ud1c4\ue29e\ucaa3\ud9a8\ud178\ue21e\ucaf5\ud939\ud1d6\ue212\ucacd\ud9c8\ud1ba\ue25f\uca0b\ud9af\ud1c3\ue22f\uca69\ud987\ud1d0\ue2fc\uca6d\ud979\ud110\ue2ac\uca0f\ud994\ud18f\ue2c2\ucadb\ud956\ud1a7\ue20e\uca18\ud95c\ud1be\ue2e7\ucab6\ud9c0\ud1cd\ue285\uca3c\ud967\ud1be\ue2b0\uca9f\ud970\ud114\ue2d5\uca87\ud96b\ud1fd\ue2ba\uca32\ud9c9\ud105\ue2b5\uca50\ud9cf\ud130\ue28d\ucad4\ud976\ud1b6\ue276\uca53\ud905\ud1ee\ue232\ucad4\ud93d\ud1c7\ue20c\ucad1\ud914\ud1e4\ue2e3\ucada\ud9b6\ud173\ue212\uca16\ud983\ud14a\ue286\ucac6\ud955\ud1bc\ue215\uca99\ud966\ud1b4\ue2cf\ucab1\ud90c\ud1b6\ue254\ucaaa\ud95d\ud196\ue2a1\ucadf\ud95a\ud199\ue208\ucafe\ud9e9\ud1de\ue2dd\ucad0\ud99c\ud1b3\ue230\ucad0\ud926\ud1b9\ue2a8\ucadb\ud9bd\ud169\ue24e\uca18\ud951\ud145\ue2b5\uca3c\ud9e9\ud11c\ue238\ucac5\ud98e\ud181\ue25a\uca6a\ud95c\ud1ed\ue2c0\uca45\ud96c\ud1ab\ue26d\uca10\ud9e8\ud1b8\ue2f2\uca0a\ud9ad\ud163\ue208\uca26\ud929\ud12c\ue2f0\uca7d\ud986\ud1f2\ue20f\uca08\ud968\ud1c8\ue2ef\ucae0\ud9c2\ud111\ue219\ucad6\ud94c\ud1e5\ue2b3\ucae2\ud97e\ud1be\ue2e1\ucafd\ud9e3\ud1cc\ue2c0\ucad0\ud9d7\ud1b1\ue25d\ucad4\ud9b2\ud1cb\ue23b\uca53\ud9f2\ud1d5\ue23d\ucad9\ud995\ud185\ue2fc\uca08\ud9c7\ud164\ue2f0\uca20\ud93c\ud15a\ue2d0\ucaf0\ud973\ud186\ue2a3\uca00\ud9b0\ud13c\ue27a\uca26\ud98d\ud101\ue2c0\ucae4\ud973\ud132\ue296\uca5a\ud9cb\ud162\ue272\uca09\ud95c\ud122\ue226\uca74\ud946\ud164\ue24e\ucac8\ud953\ud19a\ue2f3\ucaa1\ud922\ud105\ue212\ucafc\ud982\ud1e7\ue2dc\uca78\ud9f6\ud143\ue271\ucac9\ud985\ud1bb\ue2de\uca33\ud9f0\ud186\ue25f\uca8c\ud9e3\ud1dc\ue2f0\ucac0\ud93b\ud1f0\ue28b\ucab3\ud98a\ud190\ue26f\uca64\ud944\ud1c3\ue24e\ucaf5\ud978\ud1a5\ue2ce\uca0f\ud9af\ud18f\ue23a\uca7f\ud943\ud13f\ue254\uca71\ud9a8\ud1a0\ue210\ucaac\ud974\ud140\ue22b\uca73\ud98b\ud1dd\ue2e3\uca3a\ud9d7\ud144\ue277\ucac1\ud970\ud1bd\ue2d7\uca36\ud92c\ud1e7\ue2da\uca94\ud9c7\ud1f4\ue203\uca3f\ud928\ud1ca\ue26f\uca8d\ud979\ud1bf\ue2d0\ucab2\ud9aa\ud1ce\ue2df\uca32\ud9ba\ud145\ue2a9\ucadb\ud9b8\ud157\ue27b\uca65\ud9b8\ud16e\ue21d\uca57\ud9ca\ud1bc\ue29d\uca32\ud9cd\ud1eb\ue2de\uca24\ud9eb\ud1e9\ue206\uca5e\ud9cb\ud102\ue29d\ucac6\ud957\ud1b2\ue233\uca40\ud92d\ud158\ue2fd\uca17\ud926\ud1d9\ue26d\ucaf8\ud9bb\ud134\ue2a0\uca70\ud9ac\ud1d8\ue23e\uca23\ud981\ud141\ue2a0\uca57\ud965\ud1d4\ue2ba\uca6f\ud9d3\ud118\ue296\uca5e\ud96b\ud192\ue2a1\uca87\ud9e4\ud1d9\ue213\uca62\ud9ff\ud1db\ue26b\uca4e\ud905\ud1b7\ue28f\uca2d\ud9f9\ud116\ue233\ucaf0\ud963\ud195\ue2e0\ucad6\ud979\ud16e\ue222\uca3b\ud963\ud18a\ue296\uca2a\ud968\ud1c9\ue2b1\uca08\ud9e8\ud191\ue26c\uca16\ud960\ud110\ue22f\ucab3\ud91f\ud11e\ue2fc\uca81\ud93f\ud19d\ue20d\uca8c\ud9c0\ud128\ue20f\uca19\ud991\ud158\ue202\uca5b\ud932\ud197\ue2ac\ucaca\ud9cc\ud1e1\ue255\uca83\ud9c4\ud13a\ue21e\uca1c\ud931\ud140\ue21c\ucabb\ud9dd\ud107\ue233\ucac7\ud93d\ud17b\ue2c1\uca28\ud940\ud10a\ue265\uca94\ud9ec\ud182\ue2cd\ucae8\ud900\ud10f\ue28a\ucaef\ud9f9\ud1b1\ue269\ucae8\ud9c9\ud178\ue23d\ucaf6\ud9ce\ud173\ue29a\ucac5\ud90e\ud165\ue216\uca5a\ud97a\ud19d\ue2e4\uca9e\ud9d8\ud154\ue2d9\uca53\ud943\ud122\ue210\uca12\ud952\ud131\ue2b3\uca47\ud93d\ud11d\ue2dc\ucae2\ud927\ud1f6\ue248\uca5b\ud9c3\ud1eb\ue2f4\ucad9\ud988\ud1c2\ue226\uca8b\ud9ce\ud14b\ue2a7\uca5d\ud965\ud1fb\ue2b2\uca78\ud958\ud13b\ue2dd\uca05\ud932\ud198\ue2c6\uca6a\ud9a5\ud1ba\ue2f2\uca51\ud99d\ud148\ue22b\uca5f\ud928\ud10b\ue2b6\uca30\ud9c8\ud1c3\ue2e6\uca28\ud9ae\ud1a0\ue24b\uca6d\ud9f6\ud10c\ue2aa\ucaf4\ud91c\ud12b\ue2d2\ucac1\ud9dd\ud1c0\ue2ae\uca18\ud9fc\ud1de\ue2b2\ucaf8\ud9c6\ud14c\ue2f0\uca62\ud918\ud113\ue2e4\ucad9\ud903\ud109\ue2d3\ucaad\ud99e\ud155\ue20d\ucae2\ud95d\ud1ed\ue2a9\ucad6\ud9ec\ud107\ue2b4\uca16\ud9b1\ud1b2\ue266\ucafa\ud96f\ud1ce\ue25b\uca35\ud9ee\ud17f\ue2fd\ucafc\ud9e9\ud105\ue2f9\uca59\ud9a1\ud123\ue23d\uca51\ud942\ud1d6\ue259\uca08\ud987\ud15b\ue285\uca32\ud956\ud1d6\ue23e\uca18\ud945\ud104\ue263\ucadf\ud913\ud13c\ue2dc\ucab4\ud90f\ud125\ue27f\uca5b\ud98d\ud1e1\ue294\ucada\ud9dc\ud147\ue2eb\ucaa4\ud9af\ud19c\ue235\ucad2\ud96a\ud16f\ue2da\ucafb\ud935\ud18b\ue293\ucaab\ud931\ud120\ue242\ucad7\ud906\ud106\ue244\uca7d\ud94b\ud14b\ue2f5\uca30\ud9db\ud195\ue255\uca01\ud997\ud171\ue23f\ucab7\ud95f\ud12b\ue208\uca14\ud918\ud145\ue2fb\ucac9\ud9d5\ud1ca\ue21e\ucabb\ud94a\ud1c3\ue2b4\ucaa1\ud9c6\ud155\ue224\uca13\ud907\ud107\ue25f\uca58\ud950\ud14d\ue2cc\uca7c\ud9b7\ud1bb\ue286\ucadf\ud973\ud1b3\ue2dd\uca21\ud940\ud16b\ue20b\ucab7\ud994\ud1f5\ue2a4\uca09\ud9e5\ud17f\ue2f8\uca06\ud937\ud18e\ue2dc\uca03\ud9f5\ud1f5\ue2da\uca3b\ud96c\ud1e7\ue2dd\uca0e\ud9bf\ud146\ue235\uca11\ud9de\ud1b3\ue2bd\uca8b\ud9c1\ud1f8\ue233\ucac7\ud99c\ud1fc\ue2d3\uca26\ud9c1\ud13d\ue27b\uca72\ud98c\ud1b0\ue298\ucad5\ud9c5\ud10e\ue296\uca17\ud914\ud159\ue2dd\uca75\ud9a7\ud11f\ue21b\ucabc\ud981\ud1b3\ue27f\ucaec\ud98f\ud15e\ue2ec\ucada\ud91e\ud1ac\ue2f0\ucafa\ud9d8\ud1da\ue2f5\uca3d\ud901\ud1b2\ue225\ucad3\ud96c\ud1a0\ue2db\ucac0\ud96e\ud1ee\ue21f\uca61\ud9ad\ud151\ue203\ucac8\ud9be\ud12b\ue276\uca49\ud96e\ud158\ue233\uca27\ud9d4\ud153\ue26d\ucade\ud974\ud156\ue208\ucafe\ud947\ud1db\ue2da\ucaa6\ud9a7\ud17e\ue2c2\uca92\ud943\ud166\ue218\uca64\ud9a0\ud1c4\ue2a6\ucace\ud90b\ud1aa\ue2dd\uca34\ud910\ud16c\ue2d3\ucab1\ud91a\ud1e8\ue234\uca13\ud9bf\ud136\ue213\uca2d\ud9ca\ud1e6\ue2fb\ucab8\ud99c\ud1ff\ue2cb\ucac6\ud927\ud1ec\ue294\uca35\ud931\ud1ee\ue289\uca80\ud947\ud10d\ue2bf\uca4c\ud997\ud163\ue2e1\ucad0\ud9e6\ud1d3\ue29d\ucad4\ud9e9\ud133\ue2a1\ucae3\ud9ff\ud1f8\ue26d\ucaf8\ud95e\ud12a\ue20f\ucaa9\ud97c\ud188\ue2e3\uca70\ud95f\ud12b\ue2fd\uca0f\ud9f2\ud12d\ue2f1\ucafc\ud95b\ud10c\ue245\uca32\ud9c6\ud15e\ue228\uca7b\ud93c\ud1d3\ue28c\uca3d\ud967\ud1d0\ue23f\uca96\ud93f\ud160\ue23c\uca8d\ud9e1\ud14b\ue28f\uca16\ud9fb\ud1a6\ue20f\ucaf8\ud9c2\ud12d\ue2fb\ucaff\ud976\ud19a\ue217\ucae5\ud983\ud1bb\ue260\uca3b\ud99a\ud148\ue25f\uca8a\ud931\ud101\ue221\uca3d\ud943\ud1ca\ue2cf\uca3c\ud974\ud11d\ue2e4\uca2d\ud94f\ud10b\ue2d9\uca67\ud93a\ud184\ue20b\uca8a\ud928\ud141\ue275\uca80\ud90d\ud11d\ue21e\ucad6\ud9dd\ud141\ue211\ucad5\ud951\ud1ac\ue282\uca63\ud911\ud1ff\ue20c\uca4c\ud9bc\ud1c1\ue248\ucac8\ud9fb\ud1f9\ue2de\ucada\ud9f4\ud18e\ue2af\ucab0\ud9de\ud1b1\ue2b4\uca0e\ud9ad\ud18b\ue2fa\uca30\ud9b4\ud10a\ue20d\ucaa2\ud9f6\ud103\ue206\uca3f\ud9c7\ud123\ue20b\uca3b\ud94f\ud138\ue2ee\ucafd\ud955\ud1da\ue273\ucaed\ud90f\ud1be\ue2ed\uca0e\ud9fd\ud1c0\ue2d4\uca26\ud9b8\ud1be\ue2e2\ucaab\ud9e2\ud129\ue22f\uca55\ud96c\ud194\ue262\uca79\ud9ed\ud117\ue2b8\uca98\ud997\ud1dc\ue2df\uca37\ud9a9\ud121\ue247\ucac5\ud9d5\ud143\ue2dc\uca2f\ud9e3\ud1ea\ue242\ucadc\ud936\ud153\ue276\uca04\ud985\ud1c8\ue2c8\uca4f\ud949\ud19a\ue2d0\uca32\ud951\ud1b3\ue2fa\ucacc\ud9e9\ud1ad\ue24d\uca1d\ud90a\ud1eb\ue2ff\uca2b\ud9af\ud116\ue20c\ucaa3\ud9ca\ud181\ue22a\ucaa4\ud9c5\ud19b\ue263\ucada\ud940\ud174\ue25b\uca4e\ud930\ud1a8\ue23c\uca36\ud932\ud1fe\ue20c\uca0d\ud9ca\ud10b\ue213\ucaf9\ud92c\ud142\ue2d3\uca20\ud99e\ud1af\ue2da\uca32\ud9ec\ud1af\ue281\ucad9\ud935\ud1d2\ue2ab\ucaaf\ud958\ud159\ue2eb\uca15\ud934\ud13f", 36684922);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-668326399 ^ (long)-668326396);
            if (var7) break block23;
            var0_6 = (int)((long)-1274933412 ^ (long)1274933411);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-360439213 ^ (long)-360439207);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)959586135 ^ (long)-959586136);
                    if (3H.\u200b) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3H.\u200b) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u1ef2\u363c\u2536\u2dc7\u1e55\u36ef\u25e1\u2dd7\u1ee1\u3685\u2538\u2d61", 1502033987);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1247615756 ^ (long)-1247615748);
                            var0_6 = (int)((long)991494722 ^ (long)-991494723);
                            while (true) {
                                v0 = (int)((long)65310677 ^ (long)65310603);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1607365807 ^ (long)-1607365807);
                                if (!3H.\u200b) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3H.\u200b) ** continue;
                                throw null;
                            }
                            3H.d = var5_1;
                            3H.e = new String[(int)((long)96110567 ^ (long)96110517)];
                            if (!3H.\u200b) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1244579888 ^ (long)1244579888);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1687277838 ^ (long)-1687277837)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1390412340 ^ (long)1390412339)) {
                                case 0: {
                                    v15 = (int)((long)-1042523393 ^ (long)-1042523466);
                                    if (!3H.\u200b) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)696312536 ^ (long)696312491);
                                    if (!3H.\u200b) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1519544776 ^ (long)1519544819);
                                    if (!3H.\u200b) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1356712452 ^ (long)1356712537);
                                    if (!3H.\u200b) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)16765752 ^ (long)16765761);
                                    if (!3H.\u200b) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1335585638 ^ (long)-1335585646);
                                    if (!3H.\u200b) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1617927613 ^ (long)1617927609);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!3H.\u200b);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 3H.\u200b;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)538594568 ^ (long)-538579120)) & (int)((long)-25080754 ^ (long)-25054287);
            if (var9_2) ** GOTO lbl-1000
            if (3H.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3H.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1488073527 ^ (long)1488073527)] & (int)((long)1483416817 ^ (long)1483416590)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-307199888 ^ (long)-307199905);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1470007997 ^ (long)1470007865);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-685560451 ^ (long)-685560531);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1130543750 ^ (long)1130543855);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-588091802 ^ (long)-588091901);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1742548358 ^ (long)-1742548225);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)990657405 ^ (long)990657424);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)647253481 ^ (long)647253312);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)683685428 ^ (long)683685585);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-52335266 ^ (long)-52335199);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)255732369 ^ (long)255732268);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1710700915 ^ (long)-1710701013);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1175401722 ^ (long)1175401726);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1471344003 ^ (long)-1471343901);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1829619926 ^ (long)1829619791);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-201158437 ^ (long)-201158454);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-279532276 ^ (long)-279532100);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1667843323 ^ (long)-1667843174);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)2088079465 ^ (long)2088079574);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)314133191 ^ (long)314133091);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1411796892 ^ (long)-1411796864);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)868800559 ^ (long)868800594);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1092565261 ^ (long)-1092565466);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1498541329 ^ (long)-1498541494);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-783162400 ^ (long)-783162380);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)98413972 ^ (long)98413938);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1667502454 ^ (long)-1667502587);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-469802509 ^ (long)-469802533);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1152589026 ^ (long)1152589022);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1652387777 ^ (long)-1652387736);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-877305219 ^ (long)-877305193);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)669323176 ^ (long)669323015);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1963287229 ^ (long)-1963287248);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1406534525 ^ (long)1406534495);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)260167163 ^ (long)260166956);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1539112061 ^ (long)-1539112027);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)2082808150 ^ (long)2082808198);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1917970204 ^ (long)1917970358);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1277523235 ^ (long)1277523233);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1313600646 ^ (long)1313600767);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-138011351 ^ (long)-138011345);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1827784628 ^ (long)-1827784660);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)13012777 ^ (long)13012914);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)103530372 ^ (long)103530309);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1082243399 ^ (long)1082243416);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1393662781 ^ (long)-1393662797);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1918367854 ^ (long)-1918367795);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)2090214020 ^ (long)2090214041);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-93994678 ^ (long)-93994591);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1121295752 ^ (long)-1121295851);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-37137025 ^ (long)-37137071);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)2080037752 ^ (long)2080037826);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)130021600 ^ (long)130021416);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1917805208 ^ (long)1917805265);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)892994789 ^ (long)892994726);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1250923599 ^ (long)1250923717);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-455681252 ^ (long)-455681199);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1564074077 ^ (long)-1564074001);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)30213593 ^ (long)30213487);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-557689961 ^ (long)-557689932);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1867850861 ^ (long)1867850762);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1766685263 ^ (long)-1766685372);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1199913707 ^ (long)-1199913529);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1382038515 ^ (long)-1382038478);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)879920349 ^ (long)879920240);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1952203258 ^ (long)-1952203024);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1227220035 ^ (long)1227220071);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-20903818 ^ (long)-20903708);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1271093289 ^ (long)1271093404);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1132181385 ^ (long)1132181323);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1489469280 ^ (long)-1489469410);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-889200298 ^ (long)-889200329);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-881962922 ^ (long)-881962842);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1187223300 ^ (long)1187223388);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1367501282 ^ (long)1367501190);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1875543255 ^ (long)-1875543138);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1518188604 ^ (long)1518188733);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1579947727 ^ (long)-1579947632);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-862849512 ^ (long)-862849513);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)789317365 ^ (long)789317134);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)593352908 ^ (long)593352902);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)109640965 ^ (long)109641011);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)564818218 ^ (long)564818206);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1597197862 ^ (long)-1597197922);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1087291815 ^ (long)1087291698);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-508074164 ^ (long)-508074185);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)90505144 ^ (long)90504982);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)199264783 ^ (long)199264853);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)944105468 ^ (long)944105465);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)959745404 ^ (long)959745286);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-24066293 ^ (long)-24066297);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1769751180 ^ (long)-1769751263);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)2102703591 ^ (long)2102703470);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-668311817 ^ (long)-668311921);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1878253688 ^ (long)1878253769);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1498016484 ^ (long)-1498016312);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-571639691 ^ (long)-571639627);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)2052152567 ^ (long)2052152484);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)174151669 ^ (long)174151666);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-539058265 ^ (long)-539058413);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1395768256 ^ (long)1395768269);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)342420731 ^ (long)342420649);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1741974681 ^ (long)1741974737);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-421753128 ^ (long)-421753158);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1544685299 ^ (long)1544685191);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1067731070 ^ (long)-1067731110);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-2019850826 ^ (long)-2019850952);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-535653004 ^ (long)-535652982);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-205682640 ^ (long)-205682472);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1959830169 ^ (long)1959830183);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1521915845 ^ (long)1521915730);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-681079806 ^ (long)-681079773);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)171521948 ^ (long)171521888);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1680202785 ^ (long)-1680202777);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1622554786 ^ (long)-1622554733);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)676069099 ^ (long)676068895);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-926149094 ^ (long)-926149020);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)151867755 ^ (long)151867734);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1470068383 ^ (long)-1470068293);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)21312237 ^ (long)21312035);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1103775787 ^ (long)1103775917);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-350637777 ^ (long)-350637617);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1412659207 ^ (long)-1412659362);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1487207747 ^ (long)-1487207815);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-2005219702 ^ (long)-2005219813);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1025724486 ^ (long)1025724634);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-604241142 ^ (long)-604241149);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-683530004 ^ (long)-683530172);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)154040669 ^ (long)154040704);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1170355037 ^ (long)1170355003);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-108176016 ^ (long)-108176025);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1917942200 ^ (long)-1917942095);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1764631321 ^ (long)-1764631460);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-26652736 ^ (long)-26652844);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1374867824 ^ (long)-1374867806);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1141525022 ^ (long)1141525077);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)2101433019 ^ (long)2101432870);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1517163165 ^ (long)-1517163229);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-179316165 ^ (long)-179316024);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-346054131 ^ (long)-346054139);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-417514622 ^ (long)-417514604);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-609472038 ^ (long)-609472019);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1109838352 ^ (long)-1109838368);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)363410447 ^ (long)363410533);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1413724811 ^ (long)1413724858);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1169475457 ^ (long)1169475549);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)770973535 ^ (long)770973594);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)2017793304 ^ (long)2017793356);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)696602924 ^ (long)696603094);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)869013808 ^ (long)869013811);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1007143047 ^ (long)1007143101);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-860230109 ^ (long)-860229912);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)940454179 ^ (long)940454299);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1459498122 ^ (long)1459498098);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1775418455 ^ (long)-1775418525);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)2091722867 ^ (long)2091722757);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)482556269 ^ (long)482556292);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1159674721 ^ (long)1159674700);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)942918085 ^ (long)942917961);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-284534207 ^ (long)-284534272);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1269593977 ^ (long)1269593938);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)245426326 ^ (long)245426353);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-2138621733 ^ (long)-2138621782);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)2055355630 ^ (long)2055355508);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)131852870 ^ (long)131852953);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1966512732 ^ (long)1966512764);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1670149261 ^ (long)1670149287);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1768488204 ^ (long)1768488324);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)359762891 ^ (long)359762692);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)681312385 ^ (long)681312336);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)484522185 ^ (long)484522123);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1310856360 ^ (long)1310856287);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-506004835 ^ (long)-506004767);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)354782527 ^ (long)354782712);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1280194115 ^ (long)1280194129);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)998458351 ^ (long)998458310);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)2122266423 ^ (long)2122266544);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1460228924 ^ (long)-1460228967);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)658741472 ^ (long)658741310);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-174770032 ^ (long)-174770021);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-263756335 ^ (long)-263756471);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-21249326 ^ (long)-21249301);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)648577686 ^ (long)648577672);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1966686625 ^ (long)-1966686531);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1562526147 ^ (long)-1562526088);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1454867602 ^ (long)-1454867507);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-921226984 ^ (long)-921226986);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)259624914 ^ (long)259624915);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1901499880 ^ (long)1901499823);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1092334174 ^ (long)-1092334309);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-492212558 ^ (long)-492212711);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1509823469 ^ (long)-1509823391);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1730340063 ^ (long)1730339868);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1128899831 ^ (long)1128899589);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1485723746 ^ (long)-1485723827);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1610632010 ^ (long)1610631989);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1457847741 ^ (long)-1457847718);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1178498270 ^ (long)-1178498159);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1648454645 ^ (long)-1648454532);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1940424470 ^ (long)-1940424486);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-768638939 ^ (long)-768638939);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-156378987 ^ (long)-156378940);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1391585784 ^ (long)1391585541);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1853888910 ^ (long)-1853888875);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1130553574 ^ (long)1130553482);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1634202163 ^ (long)1634202259);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-243748259 ^ (long)-243748242);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1132676466 ^ (long)1132676574);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)647132533 ^ (long)647132460);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-713990746 ^ (long)-713990801);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-271188063 ^ (long)-271188018);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1531723785 ^ (long)-1531723871);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1683180834 ^ (long)1683180873);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1015482413 ^ (long)1015482542);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-290671173 ^ (long)-290671115);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1947312006 ^ (long)-1947311980);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1426494583 ^ (long)1426494636);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-2009161176 ^ (long)-2009161026);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)2114287663 ^ (long)2114287808);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1640201465 ^ (long)1640201429);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-403757427 ^ (long)-403757418);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1658722073 ^ (long)1658722293);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1584504529 ^ (long)-1584504486);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1553888347 ^ (long)1553888397);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-344132256 ^ (long)-344132232);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-160326522 ^ (long)-160326427);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)47164203 ^ (long)47164215);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1958973235 ^ (long)1958973347);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1045442851 ^ (long)1045442924);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-312556052 ^ (long)-312556210);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-424127046 ^ (long)-424127108);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1194098577 ^ (long)1194098451);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)514486865 ^ (long)514487002);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)480574155 ^ (long)480574115);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)2135227318 ^ (long)2135227277);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-78673167 ^ (long)-78673238);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)519371876 ^ (long)519371944);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-101364971 ^ (long)-101364869);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)429083671 ^ (long)429083799);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)923348390 ^ (long)923348448);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1296338241 ^ (long)-1296338388);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-2098536197 ^ (long)-2098536216);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-262522687 ^ (long)-262522755);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)817070175 ^ (long)817070202);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1891893398 ^ (long)1891893411);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)2062100364 ^ (long)2062100335);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1498895079 ^ (long)-1498895101);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)68739420 ^ (long)68739501);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-952958900 ^ (long)-952958803);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-790876087 ^ (long)-790876157);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)782855554 ^ (long)782855575);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-318938139 ^ (long)-318938281);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1317494921 ^ (long)-1317494869);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-636477567 ^ (long)-636477473);
                    if (!3H.\u200b) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)674301611 ^ (long)674301554);
                    if (!3H.\u200b) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-2097154259 ^ (long)-2097154144);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1167962475 ^ (long)1167962516)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1558616400 ^ (long)1558603439)) >>> (int)((long)-430493984 ^ (long)-430493976)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)927531581 ^ (long)927531581);
            if (!3H.\u200b) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1174850254 ^ (long)-1174850256);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1926913942 ^ (long)-1926913943) | var5_6 << (int)((long)-2046701602 ^ (long)-2046701605)) ^ var3_4[var7_8]) & (int)((long)795595691 ^ (long)795595604);
                    if (3H.\u200b) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1822555243 ^ (long)-1822555242) | var6_7 << (int)((long)-1472614229 ^ (long)-1472614226)) ^ var3_4[var7_8]) & (int)((long)2008360480 ^ (long)2008360671);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3H.e[var2_3] = new String(var3_4).intern();
        }
        return 3H.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u200b;
                if (bl || bl) break block2;
                this.2N.3();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 3H() {
        block3: {
            block2: {
                boolean bl = \u200b;
                super(3H.b((int)((long)1185928500 ^ (long)-1185908897), (int)((long)250975826 ^ (long)250971356)) /* "Kill Aura" */, 3H.b((int)((long)-1677730646 ^ (long)1677754041), (int)((long)-405264433 ^ (long)-405256099)) /* "Attacks other entities" */);
                String[] stringArray = new String[(int)((long)-1613842573 ^ (long)-1613842569)];
                stringArray[(int)((long)-1308184512 ^ (long)-1308184512)] = 3H.b((int)((long)-1652319773 ^ (long)1652308915), (int)((long)-613344749 ^ (long)613343646)) /* "Distance" */;
                stringArray[(int)((long)598055587 ^ (long)598055586)] = 3H.b((int)((long)-121945706 ^ (long)121955277), (int)((long)-1417680076 ^ (long)1417691560)) /* "Health" */;
                stringArray[(int)((long)1875153258 ^ (long)1875153256)] = 3H.b((int)((long)-1511153263 ^ (long)1511130111), (int)((long)1737508694 ^ (long)-1737491229)) /* "Crosshair" */;
                stringArray[(int)((long)108952883 ^ (long)108952880)] = 3H.b((int)((long)985393731 ^ (long)-985380808), (int)((long)-100679372 ^ (long)-100677896)) /* "Smart" */;
                String[] stringArray2 = stringArray;
                34H h2 = (34H)((34H)((34H)this.0().5(3H.b((int)((long)868877046 ^ (long)-868900640), (int)((long)1800749848 ^ (long)-1800756609)) /* "Priority" */)).7(3H.b((int)((long)-1971055740 ^ (long)1971040766), (int)((long)1723473061 ^ (long)-1723485271)) /* "priority" */)).1(3H.b((int)((long)2132357793 ^ (long)-2132373277), (int)((long)2006900288 ^ (long)2006906618)) /* "How targets are prioritized" */);
                ((34H)((34H)((34H)this.0().5(3H.b((int)((long)868877046 ^ (long)-868900640), (int)((long)1800749848 ^ (long)-1800756609)) /* "Priority" */)).7(3H.b((int)((long)-1971055740 ^ (long)1971040766), (int)((long)1723473061 ^ (long)-1723485271)) /* "priority" */)).1(3H.b((int)((long)2132357793 ^ (long)-2132373277), (int)((long)2006900288 ^ (long)2006906618)) /* "How targets are prioritized" */)).3 = stringArray2;
                this.2d = (11)h2.5();
                Boolean bl2 = Boolean.TRUE;
                34X x3 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)1664705191 ^ (long)-1664696136), (int)((long)-1114559902 ^ (long)-1114557858)) /* "Walls" */)).7(3H.b((int)((long)1644331736 ^ (long)-1644355420), (int)((long)-2009936735 ^ (long)2009929978)) /* "walls" */)).1(3H.b((int)((long)2070484835 ^ (long)-2070498031), (int)((long)624316614 ^ (long)624327307)) /* "Attack through walls" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)1664705191 ^ (long)-1664696136), (int)((long)-1114559902 ^ (long)-1114557858)) /* "Walls" */)).7(3H.b((int)((long)1644331736 ^ (long)-1644355420), (int)((long)-2009936735 ^ (long)2009929978)) /* "walls" */)).1(3H.b((int)((long)2070484835 ^ (long)-2070498031), (int)((long)624316614 ^ (long)624327307)) /* "Attack through walls" */)).7 = bl2;
                this.2w = (1P)x3.5();
                Boolean bl3 = Boolean.TRUE;
                34X x4 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)-1930807684 ^ (long)1930794015), (int)((long)-523851229 ^ (long)-523854303)) /* "RayTrace" */)).7(3H.b((int)((long)-1013183178 ^ (long)1013165886), (int)((long)2144594977 ^ (long)2144579391)) /* "raytrace" */)).1(3H.b((int)((long)-1742063772 ^ (long)1742050578), (int)((long)-861978472 ^ (long)861992939)) /* "Ray traces to the entity to see if they collide" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)-1930807684 ^ (long)1930794015), (int)((long)-523851229 ^ (long)-523854303)) /* "RayTrace" */)).7(3H.b((int)((long)-1013183178 ^ (long)1013165886), (int)((long)2144594977 ^ (long)2144579391)) /* "raytrace" */)).1(3H.b((int)((long)-1742063772 ^ (long)1742050578), (int)((long)-861978472 ^ (long)861992939)) /* "Ray traces to the entity to see if they collide" */)).7 = bl3;
                this.2J = (1P)x4.5();
                Boolean bl4 = Boolean.FALSE;
                34X x5 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)1225180712 ^ (long)-1225169798), (int)((long)1670027688 ^ (long)-1670037062)) /* "Immune" */)).7(3H.b((int)((long)-577144473 ^ (long)577166082), (int)((long)-1579770521 ^ (long)-1579777207)) /* "immune" */)).1(3H.b((int)((long)-1670030916 ^ (long)1670052817), (int)((long)762306668 ^ (long)-762305295)) /* "Checks if the target is immune to damage" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)1225180712 ^ (long)-1225169798), (int)((long)1670027688 ^ (long)-1670037062)) /* "Immune" */)).7(3H.b((int)((long)-577144473 ^ (long)577166082), (int)((long)-1579770521 ^ (long)-1579777207)) /* "immune" */)).1(3H.b((int)((long)-1670030916 ^ (long)1670052817), (int)((long)762306668 ^ (long)-762305295)) /* "Checks if the target is immune to damage" */)).7 = bl4;
                this.2M = (1P)x5.5();
                Boolean bl5 = Boolean.FALSE;
                34X x6 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)-1164231057 ^ (long)1164221449), (int)((long)184834057 ^ (long)-184827844)) /* "TPS Sync" */)).7(3H.b((int)((long)-1841011947 ^ (long)1841021212), (int)((long)1576478296 ^ (long)1576484810)) /* "tps" */)).1(3H.b((int)((long)853754382 ^ (long)-853745537), (int)((long)-214497956 ^ (long)214472618)) /* "Synchronizes hit delay with the TPS of the server" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)-1164231057 ^ (long)1164221449), (int)((long)184834057 ^ (long)-184827844)) /* "TPS Sync" */)).7(3H.b((int)((long)-1841011947 ^ (long)1841021212), (int)((long)1576478296 ^ (long)1576484810)) /* "tps" */)).1(3H.b((int)((long)853754382 ^ (long)-853745537), (int)((long)-214497956 ^ (long)214472618)) /* "Synchronizes hit delay with the TPS of the server" */)).7 = bl5;
                this.0 = (1P)x6.5();
                Boolean bl6 = Boolean.TRUE;
                34X x7 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)2035446922 ^ (long)-2035427681), (int)((long)309962754 ^ (long)309963476)) /* "Block" */)).7(3H.b((int)((long)1172933007 ^ (long)-1172952125), (int)((long)-226731521 ^ (long)-226732134)) /* "block" */)).1(3H.b((int)((long)302554236 ^ (long)-302563813), (int)((long)-462355890 ^ (long)462334967)) /* "Automatically blocks to reduce damage taken" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)2035446922 ^ (long)-2035427681), (int)((long)309962754 ^ (long)309963476)) /* "Block" */)).7(3H.b((int)((long)1172933007 ^ (long)-1172952125), (int)((long)-226731521 ^ (long)-226732134)) /* "block" */)).1(3H.b((int)((long)302554236 ^ (long)-302563813), (int)((long)-462355890 ^ (long)462334967)) /* "Automatically blocks to reduce damage taken" */)).7 = bl6;
                this.2K = (1P)x7.5();
                Boolean bl7 = Boolean.TRUE;
                34X x8 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)-1909643111 ^ (long)1909623435), (int)((long)92384164 ^ (long)92384728)) /* "Safe" */)).7(3H.b((int)((long)-573260083 ^ (long)573250736), (int)((long)851827674 ^ (long)851814468)) /* "safe" */)).1(3H.b((int)((long)276485826 ^ (long)-276466532), (int)((long)-635091529 ^ (long)-635088883)) /* "Automatically disables aura when you respawn" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)-1909643111 ^ (long)1909623435), (int)((long)92384164 ^ (long)92384728)) /* "Safe" */)).7(3H.b((int)((long)-573260083 ^ (long)573250736), (int)((long)851827674 ^ (long)851814468)) /* "safe" */)).1(3H.b((int)((long)276485826 ^ (long)-276466532), (int)((long)-635091529 ^ (long)-635088883)) /* "Automatically disables aura when you respawn" */)).7 = bl7;
                this.5 = (1P)x8.5();
                Boolean bl8 = Boolean.FALSE;
                34X x9 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)-590146630 ^ (long)590131705), (int)((long)-1476518718 ^ (long)1476503283)) /* "NoSwing" */)).7(3H.b((int)((long)859911461 ^ (long)-859924623), (int)((long)550641636 ^ (long)-550643496)) /* "noswing" */)).1(3H.b((int)((long)1177773459 ^ (long)-1177761793), (int)((long)-1667836917 ^ (long)-1667836808)) /* "Disables your hand from swinging (Client-Sided)" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)-590146630 ^ (long)590131705), (int)((long)-1476518718 ^ (long)1476503283)) /* "NoSwing" */)).7(3H.b((int)((long)859911461 ^ (long)-859924623), (int)((long)550641636 ^ (long)-550643496)) /* "noswing" */)).1(3H.b((int)((long)1177773459 ^ (long)-1177761793), (int)((long)-1667836917 ^ (long)-1667836808)) /* "Disables your hand from swinging (Client-Sided)" */)).7 = bl8;
                this.2A = (1P)x9.5();
                Boolean bl9 = Boolean.FALSE;
                34X x10 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)1244493399 ^ (long)-1244474327), (int)((long)-1676733653 ^ (long)-1676709899)) /* "Lock View" */)).7(3H.b((int)((long)571560912 ^ (long)-571543142), (int)((long)434769316 ^ (long)434781294)) /* "lockview" */)).1(3H.b((int)((long)107975314 ^ (long)-107990825), (int)((long)13187066 ^ (long)13187778)) /* "Locks the client angles to the server angles" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)1244493399 ^ (long)-1244474327), (int)((long)-1676733653 ^ (long)-1676709899)) /* "Lock View" */)).7(3H.b((int)((long)571560912 ^ (long)-571543142), (int)((long)434769316 ^ (long)434781294)) /* "lockview" */)).1(3H.b((int)((long)107975314 ^ (long)-107990825), (int)((long)13187066 ^ (long)13187778)) /* "Locks the client angles to the server angles" */)).7 = bl9;
                this.2g = (1P)x10.5();
                Boolean bl10 = Boolean.FALSE;
                34X x11 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)-1481111303 ^ (long)1481091756), (int)((long)765919299 ^ (long)-765949337)) /* "Teammates" */)).7(3H.b((int)((long)1870592014 ^ (long)-1870570889), (int)((long)-1567423914 ^ (long)1567414289)) /* "team" */)).1(3H.b((int)((long)789514954 ^ (long)-789534512), (int)((long)-331407729 ^ (long)331382847)) /* "Target teammates" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)-1481111303 ^ (long)1481091756), (int)((long)765919299 ^ (long)-765949337)) /* "Teammates" */)).7(3H.b((int)((long)1870592014 ^ (long)-1870570889), (int)((long)-1567423914 ^ (long)1567414289)) /* "team" */)).1(3H.b((int)((long)789514954 ^ (long)-789534512), (int)((long)-331407729 ^ (long)331382847)) /* "Target teammates" */)).7 = bl10;
                this.2a = (1P)x11.5();
                Boolean bl11 = Boolean.FALSE;
                34X x12 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)1501365237 ^ (long)-1501388387), (int)((long)653827138 ^ (long)-653834025)) /* "Invisible" */)).7(3H.b((int)((long)30353488 ^ (long)-30373347), (int)((long)111972531 ^ (long)111970627)) /* "invis" */)).1(3H.b((int)((long)1110290704 ^ (long)-1110306040), (int)((long)2037360216 ^ (long)-2037366018)) /* "Target invisible entities" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)1501365237 ^ (long)-1501388387), (int)((long)653827138 ^ (long)-653834025)) /* "Invisible" */)).7(3H.b((int)((long)30353488 ^ (long)-30373347), (int)((long)111972531 ^ (long)111970627)) /* "invis" */)).1(3H.b((int)((long)1110290704 ^ (long)-1110306040), (int)((long)2037360216 ^ (long)-2037366018)) /* "Target invisible entities" */)).7 = bl11;
                this.2H = (1P)x12.5();
                Boolean bl12 = Boolean.FALSE;
                34X x13 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)790811076 ^ (long)-790793341), (int)((long)-1325080490 ^ (long)1325084981)) /* "Sleeping" */)).7(3H.b((int)((long)-1239088043 ^ (long)1239066172), (int)((long)583575990 ^ (long)583569653)) /* "sleeping" */)).1(3H.b((int)((long)1709835096 ^ (long)-1709858484), (int)((long)1545837528 ^ (long)-1545839543)) /* "Target entities that are sleeping" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)790811076 ^ (long)-790793341), (int)((long)-1325080490 ^ (long)1325084981)) /* "Sleeping" */)).7(3H.b((int)((long)-1239088043 ^ (long)1239066172), (int)((long)583575990 ^ (long)583569653)) /* "sleeping" */)).1(3H.b((int)((long)1709835096 ^ (long)-1709858484), (int)((long)1545837528 ^ (long)-1545839543)) /* "Target entities that are sleeping" */)).7 = bl12;
                this.2s = (1P)x13.5();
                Boolean bl13 = Boolean.FALSE;
                34X x14 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)259778992 ^ (long)-259765332), (int)((long)-992195183 ^ (long)992188644)) /* "Friends" */)).7(3H.b((int)((long)-443828885 ^ (long)443815736), (int)((long)1292144010 ^ (long)1292146235)) /* "friends" */)).1(3H.b((int)((long)-66716500 ^ (long)66739923), (int)((long)-1277078628 ^ (long)-1277070735)) /* "Target entities that are tagged as a friend" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)259778992 ^ (long)-259765332), (int)((long)-992195183 ^ (long)992188644)) /* "Friends" */)).7(3H.b((int)((long)-443828885 ^ (long)443815736), (int)((long)1292144010 ^ (long)1292146235)) /* "friends" */)).1(3H.b((int)((long)-66716500 ^ (long)66739923), (int)((long)-1277078628 ^ (long)-1277070735)) /* "Target entities that are tagged as a friend" */)).7 = bl13;
                this.2z = (1P)x14.5();
                Boolean bl14 = Boolean.TRUE;
                34X x15 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)1918770003 ^ (long)-1918781163), (int)((long)-520187904 ^ (long)520190746)) /* "Player" */)).7(3H.b((int)((long)1926019830 ^ (long)-1926031209), (int)((long)1477871753 ^ (long)-1477871117)) /* "player" */)).1(3H.b((int)((long)-416005629 ^ (long)416014455), (int)((long)774455960 ^ (long)-774463627)) /* "Target player entities" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)1918770003 ^ (long)-1918781163), (int)((long)-520187904 ^ (long)520190746)) /* "Player" */)).7(3H.b((int)((long)1926019830 ^ (long)-1926031209), (int)((long)1477871753 ^ (long)-1477871117)) /* "player" */)).1(3H.b((int)((long)-416005629 ^ (long)416014455), (int)((long)774455960 ^ (long)-774463627)) /* "Target player entities" */)).7 = bl14;
                this.1 = (1P)x15.5();
                Boolean bl15 = Boolean.TRUE;
                34X x16 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)-1206104690 ^ (long)1206120443), (int)((long)1852844858 ^ (long)-1852841923)) /* "Hostile" */)).7(3H.b((int)((long)358049791 ^ (long)-358038096), (int)((long)260844955 ^ (long)260838835)) /* "hostile" */)).1(3H.b((int)((long)-1636214347 ^ (long)1636236250), (int)((long)1130335491 ^ (long)1130340743)) /* "Target hostile entities" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)-1206104690 ^ (long)1206120443), (int)((long)1852844858 ^ (long)-1852841923)) /* "Hostile" */)).7(3H.b((int)((long)358049791 ^ (long)-358038096), (int)((long)260844955 ^ (long)260838835)) /* "hostile" */)).1(3H.b((int)((long)-1636214347 ^ (long)1636236250), (int)((long)1130335491 ^ (long)1130340743)) /* "Target hostile entities" */)).7 = bl15;
                this.2T = (1P)x16.5();
                Boolean bl16 = Boolean.TRUE;
                34X x17 = (34X)((34X)((34X)this.4().5(3H.b((int)((long)-1723682063 ^ (long)1723666599), (int)((long)-465906854 ^ (long)465918542)) /* "Passive" */)).7(3H.b((int)((long)1885352971 ^ (long)-1885366677), (int)((long)688420802 ^ (long)688390645)) /* "passive" */)).1(3H.b((int)((long)-72209567 ^ (long)72190321), (int)((long)1795271629 ^ (long)1795267600)) /* "Target passive entities" */);
                ((34X)((34X)((34X)this.4().5(3H.b((int)((long)-1723682063 ^ (long)1723666599), (int)((long)-465906854 ^ (long)465918542)) /* "Passive" */)).7(3H.b((int)((long)1885352971 ^ (long)-1885366677), (int)((long)688420802 ^ (long)688390645)) /* "passive" */)).1(3H.b((int)((long)-72209567 ^ (long)72190321), (int)((long)1795271629 ^ (long)1795267600)) /* "Target passive entities" */)).7 = bl16;
                this.9 = (1P)x17.5();
                Float f = Float.valueOf(12.0f);
                34e e2 = ((34e)((34e)((34e)this.9().5(3H.b((int)((long)-2020538263 ^ (long)2020518514), (int)((long)-610261850 ^ (long)610265887)) /* "APS" */)).7(3H.b((int)((long)1602435774 ^ (long)-1602447110), (int)((long)-1351379151 ^ (long)1351370587)) /* "speed" */)).1(3H.b((int)((long)-1607803176 ^ (long)1607826633), (int)((long)73664949 ^ (long)-73664609)) /* "Amount of attacks that are inflicted each second" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(20.0f));
                ((34e)((34e)((34e)this.9().5(3H.b((int)((long)-2020538263 ^ (long)2020518514), (int)((long)-610261850 ^ (long)610265887)) /* "APS" */)).7(3H.b((int)((long)1602435774 ^ (long)-1602447110), (int)((long)-1351379151 ^ (long)1351370587)) /* "speed" */)).1(3H.b((int)((long)-1607803176 ^ (long)1607826633), (int)((long)73664949 ^ (long)-73664609)) /* "Amount of attacks that are inflicted each second" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(20.0f)).7 = f;
                this.23 = (1A)e2.5();
                Float f2 = Float.valueOf(0.0f);
                34e e3 = ((34e)((34e)((34e)this.9().5(3H.b((int)((long)-1857494443 ^ (long)1857503234), (int)((long)-1929388035 ^ (long)1929405188)) /* "APS Deviation" */)).7(3H.b((int)((long)-2042109550 ^ (long)2042119107), (int)((long)-400002489 ^ (long)400020168)) /* "speed_deviation" */)).1(3H.b((int)((long)1292322027 ^ (long)-1292310880), (int)((long)-323417777 ^ (long)-323401552)) /* "The deviation amount from the base APS" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(5.0f));
                ((34e)((34e)((34e)this.9().5(3H.b((int)((long)-1857494443 ^ (long)1857503234), (int)((long)-1929388035 ^ (long)1929405188)) /* "APS Deviation" */)).7(3H.b((int)((long)-2042109550 ^ (long)2042119107), (int)((long)-400002489 ^ (long)400020168)) /* "speed_deviation" */)).1(3H.b((int)((long)1292322027 ^ (long)-1292310880), (int)((long)-323417777 ^ (long)-323401552)) /* "The deviation amount from the base APS" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(5.0f)).7 = f2;
                this.6 = (1A)e3.5();
                Double d2 = 4.25;
                34e e4 = ((34e)((34e)((34e)this.7().5(3H.b((int)((long)-62537317 ^ (long)62546923), (int)((long)494657811 ^ (long)-494644839)) /* "Range" */)).7(3H.b((int)((long)752165740 ^ (long)-752189178), (int)((long)-210767048 ^ (long)-210790422)) /* "range" */)).1(3H.b((int)((long)-1980751418 ^ (long)1980728283), (int)((long)-114199783 ^ (long)114197276)) /* "Distance that targets will be attacked from" */)).3(2.0).2(6.0);
                ((34e)((34e)((34e)this.7().5(3H.b((int)((long)-62537317 ^ (long)62546923), (int)((long)494657811 ^ (long)-494644839)) /* "Range" */)).7(3H.b((int)((long)752165740 ^ (long)-752189178), (int)((long)-210767048 ^ (long)-210790422)) /* "range" */)).1(3H.b((int)((long)-1980751418 ^ (long)1980728283), (int)((long)-114199783 ^ (long)114197276)) /* "Distance that targets will be attacked from" */)).3(2.0).2(6.0).7 = d2;
                this.8 = (1K)e4.5();
                Float f3 = Float.valueOf(360.0f);
                34e e5 = ((34e)((34e)((34e)this.9().5(3H.b((int)((long)540638494 ^ (long)-540614826), (int)((long)-1967906550 ^ (long)1967902476)) /* "FOV" */)).7(3H.b((int)((long)-919281610 ^ (long)919290488), (int)((long)512789510 ^ (long)512818580)) /* "fov" */)).1(3H.b((int)((long)-1434776481 ^ (long)1434758721), (int)((long)1415033409 ^ (long)-1415045802)) /* "FOV that entities must be in to be targeted" */)).3(Float.valueOf(10.0f)).2(Float.valueOf(360.0f));
                ((34e)((34e)((34e)this.9().5(3H.b((int)((long)540638494 ^ (long)-540614826), (int)((long)-1967906550 ^ (long)1967902476)) /* "FOV" */)).7(3H.b((int)((long)-919281610 ^ (long)919290488), (int)((long)512789510 ^ (long)512818580)) /* "fov" */)).1(3H.b((int)((long)-1434776481 ^ (long)1434758721), (int)((long)1415033409 ^ (long)-1415045802)) /* "FOV that entities must be in to be targeted" */)).3(Float.valueOf(10.0f)).2(Float.valueOf(360.0f)).7 = f3;
                this.2C = (1A)e5.5();
                Double d3 = 0.0;
                34e e6 = ((34e)((34e)((34e)this.7().5(3H.b((int)((long)-504913910 ^ (long)504889885), (int)((long)1705113743 ^ (long)1705110529)) /* "Random Yaw" */)).7(3H.b((int)((long)-2037185942 ^ (long)2037162002), (int)((long)-850315532 ^ (long)-850303010)) /* "ryaw" */)).1(3H.b((int)((long)140420448 ^ (long)-140441795), (int)((long)1340359753 ^ (long)1340353720)) /* "Random yaw value added onto the regular angles" */)).3(0.0).2(30.0);
                ((34e)((34e)((34e)this.7().5(3H.b((int)((long)-504913910 ^ (long)504889885), (int)((long)1705113743 ^ (long)1705110529)) /* "Random Yaw" */)).7(3H.b((int)((long)-2037185942 ^ (long)2037162002), (int)((long)-850315532 ^ (long)-850303010)) /* "ryaw" */)).1(3H.b((int)((long)140420448 ^ (long)-140441795), (int)((long)1340359753 ^ (long)1340353720)) /* "Random yaw value added onto the regular angles" */)).3(0.0).2(30.0).7 = d3;
                this.2l = (1K)e6.5();
                Double d4 = 0.0;
                34e e7 = ((34e)((34e)((34e)this.7().5(3H.b((int)((long)1094467143 ^ (long)-1094476773), (int)((long)163719314 ^ (long)163715604)) /* "Random Pitch" */)).7(3H.b((int)((long)-2105650915 ^ (long)2105668473), (int)((long)1578102755 ^ (long)1578105712)) /* "rpitch" */)).1(3H.b((int)((long)-1885202946 ^ (long)1885190055), (int)((long)-1426750856 ^ (long)1426746351)) /* "Random pitch value added onto the regular angles" */)).3(0.0).2(30.0);
                ((34e)((34e)((34e)this.7().5(3H.b((int)((long)1094467143 ^ (long)-1094476773), (int)((long)163719314 ^ (long)163715604)) /* "Random Pitch" */)).7(3H.b((int)((long)-2105650915 ^ (long)2105668473), (int)((long)1578102755 ^ (long)1578105712)) /* "rpitch" */)).1(3H.b((int)((long)-1885202946 ^ (long)1885190055), (int)((long)-1426750856 ^ (long)1426746351)) /* "Random pitch value added onto the regular angles" */)).3(0.0).2(30.0).7 = d4;
                this.7 = (1K)e7.5();
                Integer n = (int)((long)1088261148 ^ (long)1088261148);
                34e e8 = ((34e)((34e)((34e)this.1().5(3H.b((int)((long)1946455426 ^ (long)-1946472509), (int)((long)-1226414689 ^ (long)-1226437506)) /* "Alive Ticks" */)).7(3H.b((int)((long)-792637769 ^ (long)792652974), (int)((long)1449344019 ^ (long)1449338439)) /* "ticks" */)).1(3H.b((int)((long)-1468293912 ^ (long)1468284594), (int)((long)552282066 ^ (long)-552280719)) /* "Choose how many game ticks an entity has to be alive for it to be targeted" */)).3((int)((long)458144404 ^ (long)458144404)).2((int)((long)-1873403837 ^ (long)-1873403657));
                ((34e)((34e)((34e)this.1().5(3H.b((int)((long)1946455426 ^ (long)-1946472509), (int)((long)-1226414689 ^ (long)-1226437506)) /* "Alive Ticks" */)).7(3H.b((int)((long)-792637769 ^ (long)792652974), (int)((long)1449344019 ^ (long)1449338439)) /* "ticks" */)).1(3H.b((int)((long)-1468293912 ^ (long)1468284594), (int)((long)552282066 ^ (long)-552280719)) /* "Choose how many game ticks an entity has to be alive for it to be targeted" */)).3((int)((long)458144404 ^ (long)458144404)).2((int)((long)-1873403837 ^ (long)-1873403657)).7 = n;
                this.4 = (1z)e8.5();
                Double d5 = 1.0;
                34e e9 = ((34e)((34e)((34e)this.7().5(3H.b((int)((long)-285193244 ^ (long)285206948), (int)((long)1058138378 ^ (long)1058143549)) /* "Hit Chance" */)).7(3H.b((int)((long)-3001011 ^ (long)2987780), (int)((long)-570381309 ^ (long)-570362873)) /* "hmr" */)).1(3H.b((int)((long)-1342311557 ^ (long)1342329124), (int)((long)-626736162 ^ (long)626735017)) /* "The chance, as a decimal, of swings being successfully hit\\n1 = always\\n0 = never" */)).3(0.0).2(1.0);
                ((34e)((34e)((34e)this.7().5(3H.b((int)((long)-285193244 ^ (long)285206948), (int)((long)1058138378 ^ (long)1058143549)) /* "Hit Chance" */)).7(3H.b((int)((long)-3001011 ^ (long)2987780), (int)((long)-570381309 ^ (long)-570362873)) /* "hmr" */)).1(3H.b((int)((long)-1342311557 ^ (long)1342329124), (int)((long)-626736162 ^ (long)626735017)) /* "The chance, as a decimal, of swings being successfully hit\\n1 = always\\n0 = never" */)).3(0.0).2(1.0).7 = d5;
                this.2Z = (1K)e9.5();
                this.22 = (int)((long)1627502425 ^ (long)1627502425);
                this.2L = new Listener(x2 -> {
                    boolean bl = \u200b;
                    if (bl || bl) return;
                    if (3H.3.s.dW()) {
                        if (bl || bl) return;
                        return;
                    }
                    if (bl) return;
                    if (5z.4().1z.7(0F.class).3()) {
                        if (bl || bl) return;
                        return;
                    }
                    if (bl) return;
                    switch (33.8[x2.7.ordinal()]) {
                        case 1: {
                            if (bl) return;
                            ((9p)((Object)this.2())).4((4X)x2);
                            if (bl || bl) return;
                            if (this.22) {
                                if (bl || bl) return;
                                this.2N.5(this.2K.2);
                                if (bl || bl) return;
                                4X x3 = x2;
                                x3.6(x3.8.6 + (float)((Math.random() - 0.5) * this.2l.1)).2(x2.8.3 + (float)((Math.random() - 0.5) * this.7.1));
                                if (bl || bl) return;
                                if (!this.2g.2) break;
                                if (bl || bl) return;
                                3H.3.s.p = x2.8.6;
                                if (bl || bl) return;
                                3H.3.s.q = x2.8.3;
                                if (bl) return;
                                return;
                            }
                            if (bl) return;
                            this.2N.3();
                            if (bl || bl) return;
                            return;
                        }
                        case 2: {
                            if (bl) return;
                            ((9p)((Object)this.2())).0();
                            if (bl) return;
                            break;
                        }
                    }
                    if (!bl) return;
                }, new Predicate[(int)((long)-932597599 ^ (long)-932597599)]);
                Predicate[] predicateArray = new Predicate[(int)((long)1628094086 ^ (long)1628094085)];
                Class[] classArray = new Class[(int)((long)1961214575 ^ (long)1961214574)];
                classArray[(int)((long)1869511825 ^ (long)1869511825)] = rd.class;
                predicateArray[(int)((long)-2058863523 ^ (long)-2058863523)] = new 34s(classArray);
                predicateArray[(int)((long)-1356093598 ^ (long)-1356093597)] = new 3s5(bjx.class);
                predicateArray[(int)((long)1256363773 ^ (long)1256363775)] = i -> {
                    boolean bl = \u200b;
                    if (bl || bl) return true;
                    if (i.2 == EventState.PRE) {
                        if (bl) return true;
                        return (int)((long)383077029 ^ (long)383077028) != 0;
                    }
                    if (!bl) return (int)((long)-83757799 ^ (long)-83757799) != 0;
                    return true;
                };
                this.2y = new Listener(i -> {
                    boolean bl;
                    block14: {
                        block13: {
                            block12: {
                                block11: {
                                    bl = \u200b;
                                    if (bl || bl) return;
                                    if (!(3H.3.s.b(aot.a).b() instanceof bnf)) break block11;
                                    if (bl) return;
                                    if (3H.3.s.b(aot.b).b() instanceof bmv) break block12;
                                    if (bl) return;
                                }
                                if (bl) return;
                                return;
                            }
                            if (bl) return;
                            if (!this.22) break block13;
                            if (bl) return;
                            if (this.2K.2) break block14;
                            if (bl) return;
                        }
                        if (bl) return;
                        return;
                    }
                    if (bl) return;
                    i.cancel();
                    if (!bl && !bl) return;
                }, predicateArray);
                this.2 = new Listener(sx -> {
                    block4: {
                        block2: {
                            boolean bl;
                            block3: {
                                bl = \u200b;
                                if (bl || bl) break block2;
                                if (!this.5.2) break block3;
                                if (bl) break block2;
                                this.1((boolean)((long)-899588567 ^ (long)-899588567));
                                if (bl) break block2;
                            }
                            if (!bl) break block4;
                        }
                        return;
                    }
                }, new Predicate[(int)((long)-451597087 ^ (long)-451597087)]);
                7m[] mArray = new 7m[(int)((long)-1177068404 ^ (long)-1177068407)];
                mArray[(int)((long)-313163758 ^ (long)-313163758)] = new 7f(this);
                mArray[(int)((long)-1901676471 ^ (long)-1901676472)] = new 7H(this);
                mArray[(int)((long)1440855134 ^ (long)1440855132)] = new 7S(this);
                mArray[(int)((long)-278729799 ^ (long)-278729798)] = new 7X(this);
                mArray[(int)((long)1646292121 ^ (long)1646292125)] = new 7E(this);
                this.5(mArray);
                if (bl || bl) break block2;
                this.2N = (8F)new 64(this).3();
                if (bl || bl) break block2;
                9i[] iArray = new 9i[(int)((long)-446917908 ^ (long)-446917912)];
                iArray[(int)((long)-1234235597 ^ (long)-1234235597)] = 94.3(this);
                iArray[(int)((long)972620490 ^ (long)972620491)] = new 2z(5r.a, aqa2 -> {
                    boolean bl = \u200b;
                    if (bl || bl) return true;
                    if (aqa2.K >= this.4.4) {
                        if (bl) return true;
                        return (int)((long)-1356539089 ^ (long)-1356539090) != 0;
                    }
                    if (!bl) return (int)((long)-536327171 ^ (long)-536327171) != 0;
                    return true;
                });
                iArray[(int)((long)-946559675 ^ (long)-946559673)] = new 2z(5r.a, aqa2 -> {
                    float f;
                    boolean bl;
                    block14: {
                        block13: {
                            bl = \u200b;
                            if (bl || bl) return true;
                            if (!this.2M.2) break block13;
                            if (bl) return true;
                            if (aqa2 instanceof aqm) break block14;
                            if (bl) return true;
                        }
                        if (bl) return true;
                        return (int)((long)-2102255579 ^ (long)-2102255580) != 0;
                    }
                    if (bl) return true;
                    float f2 = -(20.0f - 5_.a.b);
                    if (bl || bl) {
                        return true;
                    }
                    aqm aqm2 = (aqm)aqa2;
                    if (this.0.2) {
                        f = f2;
                        if (\u200b) {
                            throw null;
                        }
                    } else {
                        f = 0.0f;
                    }
                    if (94.1(aqm2, f)) return (int)((long)-2137635856 ^ (long)-2137635856) != 0;
                    return (int)((long)1354692350 ^ (long)1354692351) != 0;
                });
                iArray[(int)((long)-514900264 ^ (long)-514900261)] = new 2z(5r.a, aqa2 -> {
                    int n;
                    boolean bl = \u200b;
                    if (bl || bl) return true;
                    if (!this.2J.2) {
                        if (bl || bl) return true;
                        return (int)((long)1617477776 ^ (long)1617477777) != 0;
                    }
                    if (bl) {
                        return true;
                    }
                    9V v = 66.1(aqa2);
                    float f = v.6;
                    float f2 = v.3;
                    if (this.2w.2) {
                        n = (int)((long)-292893202 ^ (long)-292893202);
                        if (\u200b) {
                            throw null;
                        }
                    } else {
                        n = (int)((long)-703562038 ^ (long)-703562040);
                    }
                    if ((v = 34c.5(f, f2, n | (int)((long)-1139341308 ^ (long)-1139341307) | (int)((long)-1499726634 ^ (long)-1499726638))).c() != dcl.a.c || ((dck)v).a() != aqa2) return (int)((long)1263059066 ^ (long)1263059066) != 0;
                    return (int)((long)376321054 ^ (long)376321055) != 0;
                });
                this.2e = new 4t(iArray);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }
}

