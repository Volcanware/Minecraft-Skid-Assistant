/* ==========================================================================
 * MODULE: GhostHand
 * CATEGORY (inferred): Player
 * DESCRIPTION: Reach blocks through walls
 * OBFUSCATED CLASS: net.impactclient.0s
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  buo
 *  bup
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.3X;
import net.impactclient.49;
import net.impactclient.4f;
import net.impactclient.9j;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0s
extends 3X
implements 49 {
    public buo 8;
    @EventHandler
    private final Listener<4f> 1;
    private static final String[] d;
    @EventHandler
    private final Listener<9j> 5;
    public static final boolean \u2004\u200c;
    private static final String[] e;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0s.\u2004\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)155330037 ^ (long)155349135)) & (int)((long)2021048621 ^ (long)2021015250);
            if (var9_2) ** GOTO lbl-1000
            if (0s.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0s.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)340179851 ^ (long)340179851)] & (int)((long)1002629323 ^ (long)1002629172)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)769272746 ^ (long)769272802);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1589317945 ^ (long)-1589318104);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1486016569 ^ (long)-1486016726);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-539975809 ^ (long)-539975709);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-2033830822 ^ (long)-2033830736);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1663883838 ^ (long)1663884026);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)643218887 ^ (long)643218762);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-253131947 ^ (long)-253131872);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-666252671 ^ (long)-666252545);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1084067295 ^ (long)1084067140);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1070085068 ^ (long)-1070084915);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)873727863 ^ (long)873727866);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)393048888 ^ (long)393049062);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1361247811 ^ (long)1361247998);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1117946357 ^ (long)-1117946356);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)487362463 ^ (long)487362441);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-134577341 ^ (long)-134577404);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1592438036 ^ (long)-1592438030);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-630570156 ^ (long)-630570188);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-280807435 ^ (long)-280807639);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)861627823 ^ (long)861627870);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)2114722678 ^ (long)2114722777);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1633017994 ^ (long)-1633018043);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-758564097 ^ (long)-758564350);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)612493769 ^ (long)612493713);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1720541430 ^ (long)-1720541240);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1105222937 ^ (long)-1105222965);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)2075776038 ^ (long)2075776081);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)22911669 ^ (long)22911736);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1940029470 ^ (long)-1940029609);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1150086482 ^ (long)-1150086557);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1708655237 ^ (long)-1708655196);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1301230878 ^ (long)-1301230902);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-817961227 ^ (long)-817961232);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1551531462 ^ (long)1551531464);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1846645842 ^ (long)1846645820);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1227647503 ^ (long)1227647731);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)741487674 ^ (long)741487676);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-288361651 ^ (long)-288361545);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-802165482 ^ (long)-802165447);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-857754348 ^ (long)-857754170);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1767074520 ^ (long)1767074402);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1590113480 ^ (long)-1590113432);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1809528555 ^ (long)-1809528444);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1160400055 ^ (long)1160399951);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1134493877 ^ (long)1134493779);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1099076350 ^ (long)1099076350);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1880280146 ^ (long)1880280286);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1850849757 ^ (long)1850849733);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)631843828 ^ (long)631843694);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1216177838 ^ (long)1216177811);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-872344129 ^ (long)-872344128);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1245543889 ^ (long)1245543786);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1668118428 ^ (long)-1668118338);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1287865579 ^ (long)1287865504);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1881799007 ^ (long)-1881799102);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)652159377 ^ (long)652159267);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1507010189 ^ (long)1507010117);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-215999879 ^ (long)-215999893);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)155415540 ^ (long)155415328);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-429851637 ^ (long)-429851395);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)797121573 ^ (long)797121540);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)561293038 ^ (long)561292882);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1052208883 ^ (long)-1052208674);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)512986536 ^ (long)512986480);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)98919601 ^ (long)98919542);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1097000854 ^ (long)1097000873);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-705995952 ^ (long)-705995784);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-375508720 ^ (long)-375508492);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-412714486 ^ (long)-412714433);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1544609134 ^ (long)-1544609235);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1549924599 ^ (long)1549924518);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1254547406 ^ (long)1254547343);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)269600207 ^ (long)269600004);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1498860730 ^ (long)1498860697);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1194320533 ^ (long)-1194320408);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-657270147 ^ (long)-657270252);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1596127454 ^ (long)1596127337);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1579098243 ^ (long)-1579098221);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1974777646 ^ (long)1974777611);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-693147643 ^ (long)-693147535);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1782972073 ^ (long)-1782971977);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-422557677 ^ (long)-422557670);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1286951312 ^ (long)1286951405);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1501288615 ^ (long)1501288651);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)2075648347 ^ (long)2075648398);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1737808225 ^ (long)-1737808199);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1410710164 ^ (long)-1410710157);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1404717384 ^ (long)-1404717442);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-923240689 ^ (long)-923240668);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)477021280 ^ (long)477021426);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-995958931 ^ (long)-995958851);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1971722523 ^ (long)1971722565);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-567990192 ^ (long)-567990025);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1065980773 ^ (long)-1065980712);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)77120436 ^ (long)77120349);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1699911722 ^ (long)1699911683);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-983969415 ^ (long)-983969354);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-270421494 ^ (long)-270421355);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-454499868 ^ (long)-454499842);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-969860139 ^ (long)-969860314);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)640331614 ^ (long)640331580);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)355073807 ^ (long)355073867);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-198974687 ^ (long)-198974537);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-9199404 ^ (long)-9199573);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1635016510 ^ (long)1635016692);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-657596503 ^ (long)-657596476);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1881241736 ^ (long)-1881241639);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-150365533 ^ (long)-150365691);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-835983470 ^ (long)-835983487);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-181631726 ^ (long)-181631672);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1830553813 ^ (long)1830553837);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1818480126 ^ (long)-1818479991);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-2109446521 ^ (long)-2109446602);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-717252547 ^ (long)-717252430);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)646762534 ^ (long)646762726);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1392359284 ^ (long)1392359422);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)332999946 ^ (long)333000151);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)270412282 ^ (long)270412108);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)93206558 ^ (long)93206568);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1657321578 ^ (long)1657321641);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1694045713 ^ (long)1694045942);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1746502350 ^ (long)1746502314);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1942921414 ^ (long)1942921377);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-262069278 ^ (long)-262069267);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1943309158 ^ (long)-1943309205);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1661539325 ^ (long)-1661539277);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1208147813 ^ (long)-1208147906);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-820569672 ^ (long)-820569830);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1543449690 ^ (long)-1543449708);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1059411347 ^ (long)1059411295);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1222857788 ^ (long)-1222857930);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1040354612 ^ (long)-1040354740);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1686726709 ^ (long)-1686726759);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1331892947 ^ (long)1331892785);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1679618692 ^ (long)1679618586);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)824872831 ^ (long)824872753);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)2000889708 ^ (long)2000889799);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1502790312 ^ (long)-1502790335);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-244992343 ^ (long)-244992368);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-544547544 ^ (long)-544547552);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1743825378 ^ (long)1743825407);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1944545121 ^ (long)1944545270);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1744817848 ^ (long)-1744817816);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-899157923 ^ (long)-899157917);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)149220574 ^ (long)149220510);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1377625742 ^ (long)-1377625604);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-855049394 ^ (long)-855049301);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1687789762 ^ (long)-1687789676);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1529498336 ^ (long)-1529498366);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1832187301 ^ (long)-1832187198);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-419175304 ^ (long)-419175366);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-2084826858 ^ (long)-2084826779);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)329421444 ^ (long)329421515);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1712682348 ^ (long)1712682460);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1327534429 ^ (long)-1327534378);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)39367675 ^ (long)39367559);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1342077744 ^ (long)-1342077786);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)205279929 ^ (long)205279744);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)341033734 ^ (long)341033817);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)236444416 ^ (long)236444427);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-17947994 ^ (long)-17948020);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-982241339 ^ (long)-982241443);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1878774031 ^ (long)-1878774143);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1124255653 ^ (long)-1124255729);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-410814489 ^ (long)-410814518);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1548771411 ^ (long)1548771506);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)914021063 ^ (long)914021107);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)245004082 ^ (long)245004067);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-423204669 ^ (long)-423204765);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)509605897 ^ (long)509605970);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-438359790 ^ (long)-438359794);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1428982739 ^ (long)-1428982662);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1258538759 ^ (long)1258538860);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-286194610 ^ (long)-286194469);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)171526534 ^ (long)171526608);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1745825339 ^ (long)1745825470);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-725374077 ^ (long)-725373973);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)943857231 ^ (long)943857247);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-328274073 ^ (long)-328274124);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-406439093 ^ (long)-406439012);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1925076375 ^ (long)-1925076433);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1815662731 ^ (long)-1815662684);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1460868656 ^ (long)1460868772);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1310752614 ^ (long)-1310752625);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1653655033 ^ (long)-1653654818);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-2104700439 ^ (long)-2104700551);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)828332002 ^ (long)828332022);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-126179250 ^ (long)-126179326);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)723918830 ^ (long)723918748);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-536181906 ^ (long)-536181966);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-533324570 ^ (long)-533324776);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-326534095 ^ (long)-326534011);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1462340455 ^ (long)-1462340446);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1622583234 ^ (long)-1622583099);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-299127743 ^ (long)-299127718);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)160309951 ^ (long)160310005);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1601156336 ^ (long)1601156308);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)152457595 ^ (long)152457721);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)873999800 ^ (long)873999857);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)433387415 ^ (long)433387512);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)25839087 ^ (long)25838999);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-685121137 ^ (long)-685121099);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-2146674480 ^ (long)-2146674468);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1608825565 ^ (long)1608825531);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)880411396 ^ (long)880411519);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1129278798 ^ (long)-1129278910);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1597296700 ^ (long)1597296651);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-865476291 ^ (long)-865476326);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)985213936 ^ (long)985213845);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1357448001 ^ (long)1357448172);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1679619663 ^ (long)-1679619792);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1865154056 ^ (long)1865154219);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1797001468 ^ (long)1797001277);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1362140369 ^ (long)1362140180);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1563814540 ^ (long)-1563814643);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1595151969 ^ (long)-1595152095);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1619406796 ^ (long)-1619406763);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1521762227 ^ (long)-1521762191);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-123850424 ^ (long)-123850367);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1955197482 ^ (long)1955197661);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1080762066 ^ (long)-1080762076);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1989884284 ^ (long)1989884304);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)801010807 ^ (long)801010928);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1806310673 ^ (long)1806310805);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1620197306 ^ (long)-1620197305);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1417712480 ^ (long)-1417712422);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1141622281 ^ (long)1141622471);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)316393282 ^ (long)316393243);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)252542742 ^ (long)252542894);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1964595955 ^ (long)1964595739);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-103530159 ^ (long)-103530113);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1304358301 ^ (long)-1304358297);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)111200843 ^ (long)111200962);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-709215353 ^ (long)-709215473);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1021754932 ^ (long)-1021755113);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)922097605 ^ (long)922097515);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-650041060 ^ (long)-650040856);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)573079065 ^ (long)573079199);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)2081616737 ^ (long)2081616850);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-885802321 ^ (long)-885802485);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1436526328 ^ (long)-1436526326);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1560048801 ^ (long)1560048884);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)844174464 ^ (long)844174355);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1519674129 ^ (long)-1519674364);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1489119326 ^ (long)-1489119288);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1450374429 ^ (long)-1450374530);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1368270549 ^ (long)1368270530);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1095083044 ^ (long)-1095083111);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1589932546 ^ (long)1589932639);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)2061826143 ^ (long)2061826291);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1923554301 ^ (long)-1923554134);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1632114801 ^ (long)-1632114754);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-2012166089 ^ (long)-2012166060);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1233625173 ^ (long)1233625174);
                    if (!0s.\u2004\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-925046533 ^ (long)-925046739);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1326162626 ^ (long)-1326162495)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-314888185 ^ (long)-314847240)) >>> (int)((long)2044874878 ^ (long)2044874870)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1000652988 ^ (long)1000652988);
            if (!0s.\u2004\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1168371160 ^ (long)1168371162);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1473542995 ^ (long)-1473542994) | var5_6 << (int)((long)-1679222351 ^ (long)-1679222348)) ^ var3_4[var7_8]) & (int)((long)-1000365664 ^ (long)-1000365729);
                    if (0s.\u2004\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1302706207 ^ (long)1302706204) | var6_7 << (int)((long)1519128366 ^ (long)1519128363)) ^ var3_4[var7_8]) & (int)((long)-700285518 ^ (long)-700285619);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0s.e[var2_3] = new String(var3_4).intern();
        }
        return 0s.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 0s.\u2004\u200c;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)-733806503 ^ (long)-733806502)];
            if (var7) break block16;
            var3_2 = (int)((long)-1346383101 ^ (long)-1346383101);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\ub43d\u9c99\u8f56\u87f7\ub446\u9cf5\u8f3f\u8778\ub465\u9ccc\u8f87\u8761\ub4ba\u9c7c\u8f39\u87e9\ub424\u9c7f\u8f49\u871d\ub4f3\u9c5a\u8f79\u879a\ub44d\u9c20\u8ffa\u8745\ub48b\u9c92\u8f0e\u8715\ub47f\u9ce9\u8f38\u8782\ub4ce\u9c4d\u8f07\u87bd\ub40a\u9c73\u8f2a", 855151177);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)1308549046 ^ (long)1308549036);
            if (var7) break block16;
            var0_6 = (int)((long)148878507 ^ (long)-148878508);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)535888595 ^ (long)-535888596);
                if (0s.\u2004\u200c) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!0s.\u2004\u200c) continue block8;
                            throw null;
                        }
                        0s.d = var5_1;
                        0s.e = new String[(int)((long)-1066541546 ^ (long)-1066541547)];
                        if (!0s.\u2004\u200c) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)-1461515757 ^ (long)-1461515757);
                v5 = (int)((long)-6287349 ^ (long)-6287299);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)271034872 ^ (long)271034873)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1878353728 ^ (long)-1878353721)) {
                                case 0: {
                                    v12 = (int)((long)2110766365 ^ (long)2110766463);
                                    if (!0s.\u2004\u200c) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)-1391875498 ^ (long)-1391875490);
                                    if (!0s.\u2004\u200c) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)868818599 ^ (long)868818603);
                                    if (!0s.\u2004\u200c) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)334055001 ^ (long)334054994);
                                    if (!0s.\u2004\u200c) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)1435279692 ^ (long)1435279661);
                                    if (!0s.\u2004\u200c) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)-1193017988 ^ (long)-1193018056);
                                    if (!0s.\u2004\u200c) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-830506488 ^ (long)-830506468);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!0s.\u2004\u200c);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!0s.\u2004\u200c) ** continue;
                throw null;
            }
        }
    }

    public 0s() {
        boolean bl = \u2004\u200c;
        super(0s.b((int)((long)652066111 ^ (long)652077127), (int)((long)1631428977 ^ (long)-1631437980)) /* "GhostHand" */, 0s.b((int)((long)913016701 ^ (long)913035783), (int)((long)43639654 ^ (long)43623460)) /* "Reach blocks through walls" */);
        this.8 = bup.bR;
        this.1 = new Listener(f -> {
            block3: {
                block2: {
                    boolean bl = \u2004\u200c;
                    if (bl || bl) break block2;
                    2R.1(this, 0s.b((int)((long)-1378908215 ^ (long)-1378889038), (int)((long)1911557303 ^ (long)1911568782)) /* "suffix" */, this.8.g().getString());
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)628719567 ^ (long)628719567)]);
        this.5 = new Listener(j -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2004\u200c;
                        if (bl || bl) break block2;
                        if (j.6 == this.8) break block3;
                        if (bl || bl) break block2;
                        j.cancel();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-85891441 ^ (long)-85891441)]);
    }
}

