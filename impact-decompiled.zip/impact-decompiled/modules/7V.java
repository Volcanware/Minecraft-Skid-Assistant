/* ==========================================================================
 * MODULE: Search
 * CATEGORY (inferred): Render
 * DESCRIPTION: Highlights targetted blocks with a bounding box
 * OBFUSCATED CLASS: net.impactclient.7V
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  baritone.api.BaritoneAPI
 *  baritone.api.IBaritone
 *  buo
 *  com.mojang.blaze3d.systems.RenderSystem
 *  fx
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  org.lwjgl.opengl.GL11
 *  pw.knx.feather.structures.Color
 *  pw.knx.feather.structures.VBO
 */
package net.impactclient;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1A;
import net.impactclient.1P;
import net.impactclient.1R;
import net.impactclient.1z;
import net.impactclient.2R;
import net.impactclient.2c;
import net.impactclient.2n;
import net.impactclient.2o;
import net.impactclient.2r;
import net.impactclient.2w$6X;
import net.impactclient.34E;
import net.impactclient.34J;
import net.impactclient.34L;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.4L;
import net.impactclient.5K;
import net.impactclient.5z;
import net.impactclient.7Y;
import net.impactclient.8H;
import net.impactclient.8S;
import net.impactclient.8_;
import net.impactclient.8h;
import net.impactclient.9V;
import net.impactclient.9b;
import org.lwjgl.opengl.GL11;
import pw.knx.feather.structures.Color;
import pw.knx.feather.structures.VBO;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7V
extends 3X
implements 8h {
    private VBO 9;
    private List<fx> 8;
    private 1A 3V;
    public static final boolean \u2003\u200a\u2003\u2008\u2000\u200a\u2007;
    @EventHandler
    private final Listener<2r> 5;
    private 1P 3Z;
    private 1z 6;
    private 1P 3K;
    private static final String[] e;
    private 1P 7;
    private 1P 3z;
    private 1R 1;
    private VBO 4;
    private List<buo> 3D;
    private 1z 3B;
    private VBO 3U;
    private 8H 0;
    private 8_ 36;
    private static final String[] d;
    @EventHandler
    private final Listener<2o> 2;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-2106137498 ^ (long)2106153734)) & (int)((long)1184664757 ^ (long)1184658250);
            if (var9_2) ** GOTO lbl-1000
            if (7V.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7V.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1838317771 ^ (long)-1838317771)] & (int)((long)-1731310654 ^ (long)-1731310787)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)934356986 ^ (long)934356881);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-225356746 ^ (long)-225356757);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-658659241 ^ (long)-658659114);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1945206028 ^ (long)1945206142);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1845777424 ^ (long)1845777568);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-179341417 ^ (long)-179341510);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)227837532 ^ (long)227837678);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1097507953 ^ (long)1097507887);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1009870389 ^ (long)1009870371);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)645186158 ^ (long)645186120);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1993935059 ^ (long)1993934924);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)164236558 ^ (long)164236770);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)163671784 ^ (long)163671739);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-38029319 ^ (long)-38029413);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1380005330 ^ (long)-1380005184);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-866673677 ^ (long)-866673839);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)707810309 ^ (long)707810512);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1853547358 ^ (long)-1853547473);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1974221300 ^ (long)-1974221131);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1249145814 ^ (long)1249145635);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-572394405 ^ (long)-572394404);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-701681834 ^ (long)-701681855);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-815984664 ^ (long)-815984753);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1013199971 ^ (long)-1013200067);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)785434593 ^ (long)785434623);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1138131550 ^ (long)1138131544);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1961256660 ^ (long)-1961256458);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)227318482 ^ (long)227318463);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-224192091 ^ (long)-224192141);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-2011670525 ^ (long)-2011670490);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)514088300 ^ (long)514088439);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1573508452 ^ (long)1573508363);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1623571178 ^ (long)1623570946);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)202851493 ^ (long)202851561);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1460188512 ^ (long)-1460188487);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)840381342 ^ (long)840381318);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1938884501 ^ (long)-1938884578);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1739861103 ^ (long)-1739861206);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-156324671 ^ (long)-156324713);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1384350593 ^ (long)-1384350611);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1051171759 ^ (long)-1051171603);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1133323382 ^ (long)1133323518);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1941139089 ^ (long)1941139085);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)756542830 ^ (long)756542745);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)823346089 ^ (long)823346086);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1207531131 ^ (long)-1207531125);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-181072480 ^ (long)-181072419);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1677688962 ^ (long)-1677688860);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)2007764328 ^ (long)2007764332);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1889578351 ^ (long)-1889578315);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1688361006 ^ (long)-1688361015);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1160801125 ^ (long)-1160801164);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1100920896 ^ (long)1100920876);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1035529510 ^ (long)-1035529488);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1827125704 ^ (long)-1827125576);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-2771025 ^ (long)-2770994);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-837282980 ^ (long)-837282985);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1528418008 ^ (long)-1528418033);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)965025668 ^ (long)965025731);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)441385526 ^ (long)441385619);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-148358725 ^ (long)-148358718);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1784576131 ^ (long)1784576173);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-959824834 ^ (long)-959824816);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1562519762 ^ (long)-1562519567);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1976240012 ^ (long)-1976240042);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1464910410 ^ (long)-1464910512);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1778667501 ^ (long)-1778667502);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1930413866 ^ (long)-1930413956);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1615590153 ^ (long)1615590333);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1257826954 ^ (long)-1257826934);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1272480822 ^ (long)-1272480816);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)576067564 ^ (long)576067576);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)2018851181 ^ (long)2018851160);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1912060399 ^ (long)-1912060333);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1656387229 ^ (long)1656387269);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1817751061 ^ (long)-1817751148);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)859184803 ^ (long)859184867);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1930013536 ^ (long)-1930013546);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)755562776 ^ (long)755562773);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-673711258 ^ (long)-673711168);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1270629170 ^ (long)1270629297);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1609902974 ^ (long)-1609903099);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)385397613 ^ (long)385397608);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-988492613 ^ (long)-988492572);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-601757145 ^ (long)-601756990);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1896581854 ^ (long)1896581669);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)588057762 ^ (long)588057730);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)2026952351 ^ (long)2026952358);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-414165251 ^ (long)-414165490);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1195775190 ^ (long)1195775157);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-727851634 ^ (long)-727851532);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1460774754 ^ (long)-1460774831);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1031413719 ^ (long)-1031413583);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1680401560 ^ (long)1680401528);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1704837346 ^ (long)1704837291);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-2012300489 ^ (long)-2012300446);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)367018381 ^ (long)367018259);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)2025659434 ^ (long)2025659566);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)956823615 ^ (long)956823675);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)216703069 ^ (long)216703090);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-180359892 ^ (long)-180359791);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-140837911 ^ (long)-140838119);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1359077745 ^ (long)1359077765);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-994943309 ^ (long)-994943248);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1617639970 ^ (long)1617640048);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)306738215 ^ (long)306738403);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-892891841 ^ (long)-892891734);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1643420354 ^ (long)-1643420248);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-835050930 ^ (long)-835051002);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1419160816 ^ (long)1419160795);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1867624228 ^ (long)-1867624422);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)296762313 ^ (long)296762363);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-183982885 ^ (long)-183982868);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)579024559 ^ (long)579024560);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-957217747 ^ (long)-957217643);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1637812105 ^ (long)1637812181);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1159984769 ^ (long)1159984755);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1871008693 ^ (long)-1871008579);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1809407232 ^ (long)-1809407223);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-212780370 ^ (long)-212780432);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1442298834 ^ (long)-1442298651);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)907458607 ^ (long)907458714);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)203400402 ^ (long)203400335);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)462251378 ^ (long)462251386);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1301550444 ^ (long)1301550577);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1108081088 ^ (long)1108080920);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-287073406 ^ (long)-287073509);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1138156334 ^ (long)1138156362);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)160360864 ^ (long)160360924);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1314531816 ^ (long)1314531673);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-752960487 ^ (long)-752960331);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1643757207 ^ (long)1643757191);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1897057143 ^ (long)1897057074);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)160731208 ^ (long)160731227);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1642804911 ^ (long)1642804871);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)123212328 ^ (long)123212313);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-367040950 ^ (long)-367040855);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)239183553 ^ (long)239183361);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)674102632 ^ (long)674102542);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)21707936 ^ (long)21707924);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1866483644 ^ (long)-1866483560);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)938597880 ^ (long)938597831);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)243802864 ^ (long)243802794);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1425142171 ^ (long)-1425142250);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-311751460 ^ (long)-311751544);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-812940347 ^ (long)-812940505);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-673249380 ^ (long)-673249318);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1317004395 ^ (long)-1317004315);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-559464260 ^ (long)-559464425);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)245622459 ^ (long)245622303);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1243241577 ^ (long)1243241711);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)698498553 ^ (long)698498500);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1946951817 ^ (long)-1946951683);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1470071838 ^ (long)-1470071895);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-887195548 ^ (long)-887195627);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-2034634860 ^ (long)-2034634813);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)300629854 ^ (long)300629924);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1224160064 ^ (long)1224160052);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1276132807 ^ (long)-1276132682);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1440805348 ^ (long)-1440805139);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)841943099 ^ (long)841943223);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)353675137 ^ (long)353675012);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)424728172 ^ (long)424728259);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-182625028 ^ (long)-182625256);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1954978186 ^ (long)1954978176);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1211972595 ^ (long)-1211972594);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-2117814054 ^ (long)-2117814249);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-902376416 ^ (long)-902376247);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1441685146 ^ (long)1441685117);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1614591869 ^ (long)-1614591920);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-580262422 ^ (long)-580262401);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1238054433 ^ (long)-1238054627);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-846418642 ^ (long)-846418441);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)351446247 ^ (long)351446046);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1093971165 ^ (long)-1093971130);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1613185651 ^ (long)-1613185750);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-723641104 ^ (long)-723641337);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1304499230 ^ (long)-1304499405);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-361136922 ^ (long)-361136950);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)126763571 ^ (long)126763664);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)362540189 ^ (long)362540243);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1045748115 ^ (long)-1045748192);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-275592272 ^ (long)-275592207);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)2100830070 ^ (long)2100829974);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1571048741 ^ (long)-1571048714);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1310144197 ^ (long)1310144251);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1363270405 ^ (long)-1363270566);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-536052366 ^ (long)-536052397);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1063483182 ^ (long)-1063483336);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1665423891 ^ (long)-1665424112);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)250124110 ^ (long)250124253);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)545303989 ^ (long)545303845);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1969563749 ^ (long)-1969563825);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-920835287 ^ (long)-920835099);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-443579194 ^ (long)-443579385);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-344829352 ^ (long)-344829210);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1692797510 ^ (long)-1692797500);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1213603530 ^ (long)1213603568);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)964386752 ^ (long)964386728);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1534485960 ^ (long)-1534485763);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1023918488 ^ (long)1023918362);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1489885949 ^ (long)-1489885862);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1780728402 ^ (long)-1780728480);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1474064673 ^ (long)1474064688);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1477801713 ^ (long)1477801531);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1356430958 ^ (long)-1356430909);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)159762736 ^ (long)159762873);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1879217874 ^ (long)1879217821);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-144449761 ^ (long)-144449656);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1197351289 ^ (long)-1197351291);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1834253252 ^ (long)1834253165);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)33638367 ^ (long)33638167);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1301189131 ^ (long)1301189168);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1758049074 ^ (long)-1758049074);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1524230366 ^ (long)-1524230171);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-223866482 ^ (long)-223866553);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1235447407 ^ (long)-1235447526);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)675030946 ^ (long)675030805);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-2066037829 ^ (long)-2066037896);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)670687358 ^ (long)670687379);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1288024935 ^ (long)-1288024927);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)969896699 ^ (long)969896533);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)347513691 ^ (long)347513837);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1756193011 ^ (long)-1756192794);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1034347251 ^ (long)1034347054);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)746116565 ^ (long)746116525);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)238084472 ^ (long)238084486);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)616681917 ^ (long)616681749);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1575809896 ^ (long)1575809929);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1284723563 ^ (long)1284723603);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)297729925 ^ (long)297729973);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-299691458 ^ (long)-299691282);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-740249575 ^ (long)-740249434);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)2074585684 ^ (long)2074585831);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1501129923 ^ (long)1501129752);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)958556994 ^ (long)958556980);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1846926586 ^ (long)-1846926481);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1600406290 ^ (long)-1600406404);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)117107009 ^ (long)117106955);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)247631054 ^ (long)247630897);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1148712201 ^ (long)1148712327);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)996132144 ^ (long)996132203);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)901047895 ^ (long)901047924);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)151962586 ^ (long)151962601);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1901469749 ^ (long)-1901469791);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-245585439 ^ (long)-245585610);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-376534541 ^ (long)-376534686);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)271707355 ^ (long)271707378);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)2083237232 ^ (long)2083237244);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1139682391 ^ (long)1139682348);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1913832955 ^ (long)-1913832769);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1192689148 ^ (long)-1192688938);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1734106355 ^ (long)1734106223);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1448965889 ^ (long)-1448965969);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)28478374 ^ (long)28478362);
                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)969332691 ^ (long)969332551);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)433568985 ^ (long)433568806)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1389420979 ^ (long)1389370956)) >>> (int)((long)1532308414 ^ (long)1532308406)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-876468610 ^ (long)-876468610);
            if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)101604664 ^ (long)101604666);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1169985553 ^ (long)-1169985556) | var5_6 << (int)((long)1918157142 ^ (long)1918157139)) ^ var3_4[var7_8]) & (int)((long)1328291457 ^ (long)1328291454);
                    if (7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)830899788 ^ (long)830899791) | var6_7 << (int)((long)1917369210 ^ (long)1917369215)) ^ var3_4[var7_8]) & (int)((long)387357919 ^ (long)387357728);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7V.e[var2_3] = new String(var3_4).intern();
        }
        return 7V.e[var2_3];
    }

    public 7V() {
        boolean bl = \u2003\u200a\u2003\u2008\u2000\u200a\u2007;
        super(7V.b((int)((long)-207517397 ^ (long)207500869), (int)((long)1252569580 ^ (long)1252582896)) /* "Search" */, 7V.b((int)((long)-23515321 ^ (long)23498804), (int)((long)606647549 ^ (long)-606660407)) /* "Highlights targetted blocks with a bounding box" */);
        Object object2 = Color.fromRGB((int)((int)((long)194906204 ^ (long)194906204)), (int)((int)((long)1358468708 ^ (long)1358468763)), (int)((int)((long)395590246 ^ (long)395590297)));
        34J j2 = (34E)((34E)((34E)this.0().5(7V.b((int)((long)1482412209 ^ (long)-1482395695), (int)((long)1432788300 ^ (long)1432782488)) /* "Color" */)).7(7V.b((int)((long)401190153 ^ (long)-401206664), (int)((long)-936056760 ^ (long)936069926)) /* "color" */)).1(7V.b((int)((long)626975916 ^ (long)-626959397), (int)((long)585846455 ^ (long)585837445)) /* "The selection bounding box color" */);
        ((34E)((34E)((34E)this.0().5(7V.b((int)((long)1482412209 ^ (long)-1482395695), (int)((long)1432788300 ^ (long)1432782488)) /* "Color" */)).7(7V.b((int)((long)401190153 ^ (long)-401206664), (int)((long)-936056760 ^ (long)936069926)) /* "color" */)).1(7V.b((int)((long)626975916 ^ (long)-626959397), (int)((long)585846455 ^ (long)585837445)) /* "The selection bounding box color" */)).7 = object2;
        this.1 = (1R)j2.5();
        object2 = (int)((long)-1365253521 ^ (long)-1365253753);
        j2 = ((34e)((34e)((34e)this.1().5(7V.b((int)((long)1439532706 ^ (long)-1439548981), (int)((long)-8703557 ^ (long)-8710156)) /* "Max Blocks" */)).7(7V.b((int)((long)-770689021 ^ (long)770672486), (int)((long)366601638 ^ (long)-366603175)) /* "max" */)).1(7V.b((int)((long)-1733417714 ^ (long)1733401204), (int)((long)-1917064969 ^ (long)-1917075038)) /* "The maximum amount of blocks to target" */)).3((int)((long)-580113306 ^ (long)-580113006)).2((int)((long)481265835 ^ (long)481276467));
        ((34e)((34e)((34e)this.1().5(7V.b((int)((long)1439532706 ^ (long)-1439548981), (int)((long)-8703557 ^ (long)-8710156)) /* "Max Blocks" */)).7(7V.b((int)((long)-770689021 ^ (long)770672486), (int)((long)366601638 ^ (long)-366603175)) /* "max" */)).1(7V.b((int)((long)-1733417714 ^ (long)1733401204), (int)((long)-1917064969 ^ (long)-1917075038)) /* "The maximum amount of blocks to target" */)).3((int)((long)-580113306 ^ (long)-580113006)).2((int)((long)481265835 ^ (long)481276467)).7 = object2;
        this.3B = (1z)((34e)j2).5();
        object2 = (int)((long)-1978244262 ^ (long)-1978244942);
        j2 = ((34e)((34e)((34e)this.1().5(7V.b((int)((long)1690790642 ^ (long)-1690774119), (int)((long)-1192083893 ^ (long)-1192095121)) /* "Refresh Rate" */)).7(7V.b((int)((long)-1160507410 ^ (long)1160491166), (int)((long)383970792 ^ (long)-383949256)) /* "rate" */)).1(7V.b((int)((long)-1237446027 ^ (long)1237429504), (int)((long)1469903417 ^ (long)1469892882)) /* "The rate in which the target search blocks are queried" */)).3((int)((long)-1095909715 ^ (long)-1095909801)).2((int)((long)1421563731 ^ (long)1421565163));
        ((34e)((34e)((34e)this.1().5(7V.b((int)((long)1690790642 ^ (long)-1690774119), (int)((long)-1192083893 ^ (long)-1192095121)) /* "Refresh Rate" */)).7(7V.b((int)((long)-1160507410 ^ (long)1160491166), (int)((long)383970792 ^ (long)-383949256)) /* "rate" */)).1(7V.b((int)((long)-1237446027 ^ (long)1237429504), (int)((long)1469903417 ^ (long)1469892882)) /* "The rate in which the target search blocks are queried" */)).3((int)((long)-1095909715 ^ (long)-1095909801)).2((int)((long)1421563731 ^ (long)1421565163)).7 = object2;
        this.6 = (1z)((34e)j2).5();
        object2 = Float.valueOf(1.0f);
        j2 = ((34e)((34e)((34e)this.9().5(7V.b((int)((long)1591757614 ^ (long)-1591741368), (int)((long)2037775035 ^ (long)-2037746113)) /* "Width" */)).7(7V.b((int)((long)-1254221620 ^ (long)1254205348), (int)((long)1693341445 ^ (long)1693350969)) /* "width" */)).1(7V.b((int)((long)1045044222 ^ (long)-1045060463), (int)((long)353548609 ^ (long)353554604)) /* "The thickness of the outline box lines" */)).3(Float.valueOf(0.01f)).2(Float.valueOf(3.0f));
        ((34e)((34e)((34e)this.9().5(7V.b((int)((long)1591757614 ^ (long)-1591741368), (int)((long)2037775035 ^ (long)-2037746113)) /* "Width" */)).7(7V.b((int)((long)-1254221620 ^ (long)1254205348), (int)((long)1693341445 ^ (long)1693350969)) /* "width" */)).1(7V.b((int)((long)1045044222 ^ (long)-1045060463), (int)((long)353548609 ^ (long)353554604)) /* "The thickness of the outline box lines" */)).3(Float.valueOf(0.01f)).2(Float.valueOf(3.0f)).7 = object2;
        this.3V = (1A)((34e)j2).5();
        object2 = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7V.b((int)((long)1815772601 ^ (long)-1815756075), (int)((long)2024153736 ^ (long)-2024154299)) /* "Smooth Lines" */)).7(7V.b((int)((long)1319764747 ^ (long)-1319781274), (int)((long)121305441 ^ (long)-121302584)) /* "smooth" */)).1(7V.b((int)((long)-520353088 ^ (long)520336807), (int)((long)-1695418518 ^ (long)-1695422579)) /* "Render the outline boxes with line smoothing enabled" */);
        ((34X)((34X)((34X)this.4().5(7V.b((int)((long)1815772601 ^ (long)-1815756075), (int)((long)2024153736 ^ (long)-2024154299)) /* "Smooth Lines" */)).7(7V.b((int)((long)1319764747 ^ (long)-1319781274), (int)((long)121305441 ^ (long)-121302584)) /* "smooth" */)).1(7V.b((int)((long)-520353088 ^ (long)520336807), (int)((long)-1695418518 ^ (long)-1695422579)) /* "Render the outline boxes with line smoothing enabled" */)).7 = object2;
        this.3z = (1P)((34X)j2).5();
        object2 = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7V.b((int)((long)-880540539 ^ (long)880524285), (int)((long)-1235442824 ^ (long)-1235434224)) /* "Fill" */)).7(7V.b((int)((long)-1402281685 ^ (long)1402297938), (int)((long)1480890068 ^ (long)1480886300)) /* "fill" */)).1(7V.b((int)((long)1575815725 ^ (long)-1575832249), (int)((long)-2109230229 ^ (long)2109236449)) /* "Draws a filled box instead of a wireframe" */);
        ((34X)((34X)((34X)this.4().5(7V.b((int)((long)-880540539 ^ (long)880524285), (int)((long)-1235442824 ^ (long)-1235434224)) /* "Fill" */)).7(7V.b((int)((long)-1402281685 ^ (long)1402297938), (int)((long)1480890068 ^ (long)1480886300)) /* "fill" */)).1(7V.b((int)((long)1575815725 ^ (long)-1575832249), (int)((long)-2109230229 ^ (long)2109236449)) /* "Draws a filled box instead of a wireframe" */)).7 = object2;
        this.3K = (1P)((34X)j2).5();
        object2 = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7V.b((int)((long)1455362631 ^ (long)-1455379151), (int)((long)688698153 ^ (long)-688707524)) /* "Shader" */)).7(7V.b((int)((long)-434703026 ^ (long)434719279), (int)((long)906599034 ^ (long)-906616483)) /* "shader" */)).1(7V.b((int)((long)-738690174 ^ (long)738706656), (int)((long)620838126 ^ (long)620831937)) /* "Utilizes geometry shaders to render the selection boxes" */);
        ((34X)((34X)((34X)this.4().5(7V.b((int)((long)1455362631 ^ (long)-1455379151), (int)((long)688698153 ^ (long)-688707524)) /* "Shader" */)).7(7V.b((int)((long)-434703026 ^ (long)434719279), (int)((long)906599034 ^ (long)-906616483)) /* "shader" */)).1(7V.b((int)((long)-738690174 ^ (long)738706656), (int)((long)620838126 ^ (long)620831937)) /* "Utilizes geometry shaders to render the selection boxes" */)).7 = object2;
        this.3Z = (1P)((34X)j2).5();
        object2 = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7V.b((int)((long)808227386 ^ (long)-808243890), (int)((long)-719351464 ^ (long)719343761)) /* "Tracers" */)).7(7V.b((int)((long)-146742589 ^ (long)146759089), (int)((long)-1674437878 ^ (long)-1674426357)) /* "tracers" */)).1(7V.b((int)((long)1596064122 ^ (long)-1596080610), (int)((long)1469432 ^ (long)-1462463)) /* "Draw tracers to the blocks" */);
        ((34X)((34X)((34X)this.4().5(7V.b((int)((long)808227386 ^ (long)-808243890), (int)((long)-719351464 ^ (long)719343761)) /* "Tracers" */)).7(7V.b((int)((long)-146742589 ^ (long)146759089), (int)((long)-1674437878 ^ (long)-1674426357)) /* "tracers" */)).1(7V.b((int)((long)1596064122 ^ (long)-1596080610), (int)((long)1469432 ^ (long)-1462463)) /* "Draw tracers to the blocks" */)).7 = object2;
        this.7 = (1P)((34X)j2).5();
        this.2 = new Listener(object -> {
            block18: {
                int n;
                VBO vBO;
                float f;
                block20: {
                    block14: {
                        boolean bl;
                        block19: {
                            block17: {
                                block16: {
                                    block15: {
                                        bl = \u2003\u200a\u2003\u2008\u2000\u200a\u2007;
                                        if (bl || bl) break block14;
                                        if (!this.0.8(this.6.4)) break block15;
                                        if (bl || bl) break block14;
                                        this.3D.clear();
                                        if (bl || bl) break block14;
                                        this.3D.addAll(5z.4().13);
                                        if (bl || bl) break block14;
                                        5z.4().5.execute(() -> {
                                            block3: {
                                                block2: {
                                                    boolean bl = \u2003\u200a\u2003\u2008\u2000\u200a\u2007;
                                                    if (bl || bl) break block2;
                                                    IBaritone iBaritone = BaritoneAPI.getProvider().getPrimaryBaritone();
                                                    if (bl || bl) break block2;
                                                    List list = BaritoneAPI.getProvider().getWorldScanner().scanChunkRadius(iBaritone.getPlayerContext(), this.3D, this.3B.4, (int)((long)1477012270 ^ (long)-1477012271), 7V.3.k.b);
                                                    if (bl || bl) break block2;
                                                    this.8.clear();
                                                    if (bl || bl) break block2;
                                                    this.8.addAll(list);
                                                    if (!bl && !bl) break block3;
                                                }
                                                return;
                                            }
                                        });
                                        if (bl || bl) break block14;
                                        this.0.0();
                                        if (bl) break block14;
                                    }
                                    if (bl) break block14;
                                    RenderSystem.pushMatrix();
                                    if (bl || bl) break block14;
                                    RenderSystem.lineWidth((float)this.3V.9);
                                    if (bl || bl) break block14;
                                    object = 34L.5(this.1.2());
                                    if (bl || bl) break block14;
                                    2R.1(this, 7V.b((int)((long)1798920564 ^ (long)-1798904297), (int)((long)-651951800 ^ (long)651948518)) /* "suffix" */, String.valueOf(this.8.size()));
                                    if (bl || bl) break block14;
                                    9b.6((boolean)((long)402969681 ^ (long)402969680));
                                    if (bl || bl) break block14;
                                    if (this.36 != null) break block16;
                                    if (bl || bl) break block14;
                                    this.3Z.3(Boolean.FALSE);
                                    if (bl) break block14;
                                }
                                if (bl) break block14;
                                if (!this.3Z.2) break block17;
                                if (bl || bl) break block14;
                                Object object2 = object[(int)((long)-1635148397 ^ (long)-1635148399)];
                                Object object3 = object[(int)((long)167755448 ^ (long)167755449)];
                                Object object4 = object[(int)((long)-803443707 ^ (long)-803443707)];
                                object = this.36;
                                this.36.7 = (float)object4;
                                if (bl || bl) break block14;
                                ((8_)object).2 = (float)object3;
                                if (bl || bl) break block14;
                                ((8_)object).1 = (float)object2;
                                if (bl || bl) break block14;
                                ((8_)object).0 = 0.1f;
                                if (bl || bl) break block14;
                                this.36.9();
                                if (bl || bl) break block14;
                                7V v = this;
                                v.8(v.3U, (int)((long)950354394 ^ (long)950354394));
                                if (bl || bl) break block14;
                                8_.6();
                                if (bl) break block14;
                                if (\u2003\u200a\u2003\u2008\u2000\u200a\u2007) {
                                    throw null;
                                }
                                break block18;
                            }
                            if (bl) break block14;
                            if (this.3z.2) break block19;
                            if (bl || bl) break block14;
                            GL11.glDisable((int)((int)((long)-456589285 ^ (long)-456586437)));
                            if (bl) break block14;
                        }
                        if (!bl) break block20;
                    }
                    return;
                }
                Object object5 = object[(int)((long)-526247247 ^ (long)-526247247)];
                Object object6 = object[(int)((long)-1365358340 ^ (long)-1365358339)];
                Object object7 = object[(int)((long)1377624266 ^ (long)1377624264)];
                if (this.3K.2) {
                    f = 0.3f;
                    if (\u2003\u200a\u2003\u2008\u2000\u200a\u2007) {
                        throw null;
                    }
                } else {
                    f = 1.0f;
                }
                RenderSystem.color4f((float)object5, (float)object6, (float)object7, (float)f);
                7V v = this;
                if (v.3K.2) {
                    vBO = this.9;
                    if (\u2003\u200a\u2003\u2008\u2000\u200a\u2007) {
                        throw null;
                    }
                } else {
                    vBO = this.4;
                }
                if (this.3K.2) {
                    n = (int)((long)1047957192 ^ (long)1047957199);
                    if (\u2003\u200a\u2003\u2008\u2000\u200a\u2007) {
                        throw null;
                    }
                } else {
                    n = (int)((long)34451046 ^ (long)34451047);
                }
                v.8(vBO, n);
            }
            9b.6((boolean)((long)1676166415 ^ (long)1676166415));
            RenderSystem.lineWidth((float)1.0f);
            RenderSystem.popMatrix();
        }, new Predicate[(int)((long)150247675 ^ (long)150247675)]);
        this.5 = new Listener(sp2 -> {
            boolean bl = \u2003\u200a\u2003\u2008\u2000\u200a\u2007;
            if (bl || bl) return;
            if (!this.7.2) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            9b.6((boolean)((long)1326723509 ^ (long)1326723508));
            if (bl || bl) return;
            4L[] lArray = new 4L[(int)((long)881702891 ^ (long)881702889)];
            lArray[(int)((long)494524898 ^ (long)494524898)] = 4L.c;
            lArray[(int)((long)-685505642 ^ (long)-685505641)] = 4L.a;
            9b.3(lArray);
            if (bl || bl) return;
            RenderSystem.lineWidth((float)this.3V.9);
            if (bl || bl) return;
            if (!this.3z.2) {
                if (bl || bl) return;
                GL11.glDisable((int)((int)((long)-1999235513 ^ (long)-1999233689)));
                if (bl) return;
            }
            if (bl) return;
            7Y y = 5z.4().1z.7(7Y.class);
            if (bl || bl) return;
            this.8.forEach(object -> {
                block4: {
                    block2: {
                        boolean bl;
                        block3: {
                            bl = \u2003\u200a\u2003\u2008\u2000\u200a\u2007;
                            if (bl || bl) break block2;
                            Color color = this.1.2;
                            8S s = new 8S((double)object.u() + 0.5, (double)object.v() + 0.5, (double)object.w() + 0.5);
                            float f = (float)7Y.3.aD().k() / 2.0f;
                            9V v = y.0_;
                            y.0_.6 = f;
                            if (bl || bl) break block2;
                            v.3 = (float)7Y.3.aD().l() / 2.0f;
                            if (bl || bl) break block2;
                            8S s2 = 5K.8(2n.5(s));
                            if (s2 == null) break block3;
                            if (bl || bl) break block2;
                            y.5(s2);
                            if (bl || bl) break block2;
                            int n = 9b.2(color.getHex());
                            if (bl || bl) break block2;
                            9b.5.setColor(n).addVertex(y.0_.6, y.0_.3, 0.0f).setColor(color).addVertex((float)s2.9, (float)s2.1, 0.0f);
                            if (bl || bl) break block2;
                            9b.5.draw((int)((long)-290669651 ^ (long)-290669650));
                            if (bl) break block2;
                        }
                        if (!bl) break block4;
                    }
                    return;
                }
            });
            if (bl || bl) return;
            9b.3();
            if (bl || bl) return;
            9b.6((boolean)((long)2031372292 ^ (long)2031372292));
            if (!bl && !bl) return;
        }, new Predicate[(int)((long)-664915286 ^ (long)-664915286)]);
        this.4 = new VBO();
        float[] fArray = new float[(int)((long)-1010986863 ^ (long)-1010986791)];
        fArray[(int)((long)-62893422 ^ (long)-62893422)] = 0.0f;
        fArray[(int)((long)-1463621998 ^ (long)-1463621997)] = 0.0f;
        fArray[(int)((long)-1691020410 ^ (long)-1691020412)] = 0.0f;
        fArray[(int)((long)19234439 ^ (long)19234436)] = 0.0f;
        fArray[(int)((long)1316986270 ^ (long)1316986266)] = 0.0f;
        fArray[(int)((long)2143669624 ^ (long)2143669629)] = 1.0f;
        fArray[(int)((long)-1919914529 ^ (long)-1919914535)] = 0.0f;
        fArray[(int)((long)1148942188 ^ (long)1148942187)] = 0.0f;
        fArray[(int)((long)-1807781981 ^ (long)-1807781973)] = 1.0f;
        fArray[(int)((long)458555256 ^ (long)458555249)] = 1.0f;
        fArray[(int)((long)-3589791 ^ (long)-3589781)] = 0.0f;
        fArray[(int)((long)1216942713 ^ (long)1216942706)] = 1.0f;
        fArray[(int)((long)-105113768 ^ (long)-105113772)] = 1.0f;
        fArray[(int)((long)1896557191 ^ (long)1896557194)] = 0.0f;
        fArray[(int)((long)1431599699 ^ (long)1431599709)] = 1.0f;
        fArray[(int)((long)177535103 ^ (long)177535088)] = 1.0f;
        fArray[(int)((long)157599849 ^ (long)157599865)] = 0.0f;
        fArray[(int)((long)-284363889 ^ (long)-284363874)] = 0.0f;
        fArray[(int)((long)1091272775 ^ (long)1091272789)] = 1.0f;
        fArray[(int)((long)-198397102 ^ (long)-198397119)] = 0.0f;
        fArray[(int)((long)-113843444 ^ (long)-113843432)] = 0.0f;
        fArray[(int)((long)355709994 ^ (long)355710015)] = 0.0f;
        fArray[(int)((long)-1634126491 ^ (long)-1634126477)] = 0.0f;
        fArray[(int)((long)989089045 ^ (long)989089026)] = 0.0f;
        fArray[(int)((long)-391564833 ^ (long)-391564857)] = 0.0f;
        fArray[(int)((long)1221612297 ^ (long)1221612304)] = 1.0f;
        fArray[(int)((long)-602726009 ^ (long)-602725987)] = 0.0f;
        fArray[(int)((long)-752927335 ^ (long)-752927358)] = 0.0f;
        fArray[(int)((long)549269640 ^ (long)549269652)] = 1.0f;
        fArray[(int)((long)-1895323519 ^ (long)-1895323492)] = 1.0f;
        fArray[(int)((long)15425176 ^ (long)15425158)] = 0.0f;
        fArray[(int)((long)-57236037 ^ (long)-57236060)] = 1.0f;
        fArray[(int)((long)-445721577 ^ (long)-445721545)] = 1.0f;
        fArray[(int)((long)1472720222 ^ (long)1472720255)] = 1.0f;
        fArray[(int)((long)-1675375648 ^ (long)-1675375678)] = 1.0f;
        fArray[(int)((long)-1742911052 ^ (long)-1742911081)] = 1.0f;
        fArray[(int)((long)-874478159 ^ (long)-874478187)] = 1.0f;
        fArray[(int)((long)1412485706 ^ (long)1412485743)] = 1.0f;
        fArray[(int)((long)-1383178438 ^ (long)-1383178468)] = 1.0f;
        fArray[(int)((long)-384417185 ^ (long)-384417160)] = 1.0f;
        fArray[(int)((long)-1721100813 ^ (long)-1721100837)] = 1.0f;
        fArray[(int)((long)-1706874410 ^ (long)-1706874369)] = 0.0f;
        fArray[(int)((long)521374120 ^ (long)521374082)] = 1.0f;
        fArray[(int)((long)-1517391789 ^ (long)-1517391752)] = 1.0f;
        fArray[(int)((long)293719292 ^ (long)293719248)] = 0.0f;
        fArray[(int)((long)-1204695687 ^ (long)-1204695724)] = 0.0f;
        fArray[(int)((long)736982040 ^ (long)736982070)] = 1.0f;
        fArray[(int)((long)282577641 ^ (long)282577606)] = 0.0f;
        fArray[(int)((long)1072538602 ^ (long)1072538586)] = 0.0f;
        fArray[(int)((long)452406515 ^ (long)452406466)] = 0.0f;
        fArray[(int)((long)-248111159 ^ (long)-248111109)] = 0.0f;
        fArray[(int)((long)1712191950 ^ (long)1712191997)] = 0.0f;
        fArray[(int)((long)-2039707340 ^ (long)-2039707392)] = 1.0f;
        fArray[(int)((long)-1069888374 ^ (long)-1069888321)] = 0.0f;
        fArray[(int)((long)-1559123121 ^ (long)-1559123079)] = 0.0f;
        fArray[(int)((long)486254810 ^ (long)486254829)] = 0.0f;
        fArray[(int)((long)399432954 ^ (long)399432898)] = 1.0f;
        fArray[(int)((long)673139544 ^ (long)673139553)] = 0.0f;
        fArray[(int)((long)763059669 ^ (long)763059695)] = 1.0f;
        fArray[(int)((long)-1621509866 ^ (long)-1621509843)] = 1.0f;
        fArray[(int)((long)-653333312 ^ (long)-653333252)] = 1.0f;
        fArray[(int)((long)-166052384 ^ (long)-166052387)] = 0.0f;
        fArray[(int)((long)665946503 ^ (long)665946553)] = 1.0f;
        fArray[(int)((long)-1562023523 ^ (long)-1562023518)] = 1.0f;
        fArray[(int)((long)-1838128257 ^ (long)-1838128321)] = 1.0f;
        fArray[(int)((long)1255377455 ^ (long)1255377518)] = 1.0f;
        fArray[(int)((long)-1904647832 ^ (long)-1904647894)] = 1.0f;
        fArray[(int)((long)-2043122460 ^ (long)-2043122521)] = 0.0f;
        fArray[(int)((long)-1182252315 ^ (long)-1182252383)] = 0.0f;
        fArray[(int)((long)-174049927 ^ (long)-174049988)] = 1.0f;
        fArray[(int)((long)-826014675 ^ (long)-826014613)] = 1.0f;
        fArray[(int)((long)-804428595 ^ (long)-804428662)] = 0.0f;
        this.4.compile(fArray);
        this.9 = new VBO();
        float[] fArray2 = new float[(int)((long)-815294972 ^ (long)-815294900)];
        fArray2[(int)((long)-1742792931 ^ (long)-1742792931)] = 0.0f;
        fArray2[(int)((long)-806702628 ^ (long)-806702627)] = 0.0f;
        fArray2[(int)((long)367040951 ^ (long)367040949)] = 0.0f;
        fArray2[(int)((long)-2062611314 ^ (long)-2062611315)] = 0.0f;
        fArray2[(int)((long)-1513228086 ^ (long)-1513228082)] = 1.0f;
        fArray2[(int)((long)-1374421962 ^ (long)-1374421965)] = 0.0f;
        fArray2[(int)((long)1615542293 ^ (long)1615542291)] = 1.0f;
        fArray2[(int)((long)-1222762057 ^ (long)-1222762064)] = 1.0f;
        fArray2[(int)((long)1112383488 ^ (long)1112383496)] = 0.0f;
        fArray2[(int)((long)424791004 ^ (long)424790997)] = 1.0f;
        fArray2[(int)((long)-20396195 ^ (long)-20396201)] = 0.0f;
        fArray2[(int)((long)429073135 ^ (long)429073124)] = 0.0f;
        fArray2[(int)((long)-984205793 ^ (long)-984205805)] = 1.0f;
        fArray2[(int)((long)1756079655 ^ (long)1756079658)] = 0.0f;
        fArray2[(int)((long)381951153 ^ (long)381951167)] = 1.0f;
        fArray2[(int)((long)785994019 ^ (long)785994028)] = 1.0f;
        fArray2[(int)((long)-173667238 ^ (long)-173667254)] = 1.0f;
        fArray2[(int)((long)-768175391 ^ (long)-768175376)] = 1.0f;
        fArray2[(int)((long)1774354300 ^ (long)1774354286)] = 0.0f;
        fArray2[(int)((long)949047308 ^ (long)949047327)] = 1.0f;
        fArray2[(int)((long)-201073254 ^ (long)-201073266)] = 1.0f;
        fArray2[(int)((long)135549614 ^ (long)135549627)] = 0.0f;
        fArray2[(int)((long)1363190979 ^ (long)1363190997)] = 0.0f;
        fArray2[(int)((long)-1588435371 ^ (long)-1588435390)] = 1.0f;
        fArray2[(int)((long)-1431952988 ^ (long)-1431952964)] = 0.0f;
        fArray2[(int)((long)-171720108 ^ (long)-171720115)] = 0.0f;
        fArray2[(int)((long)559753295 ^ (long)559753301)] = 1.0f;
        fArray2[(int)((long)1810644457 ^ (long)1810644466)] = 0.0f;
        fArray2[(int)((long)1761773337 ^ (long)1761773317)] = 1.0f;
        fArray2[(int)((long)266371112 ^ (long)266371125)] = 1.0f;
        fArray2[(int)((long)-316494910 ^ (long)-316494884)] = 0.0f;
        fArray2[(int)((long)1754182384 ^ (long)1754182383)] = 1.0f;
        fArray2[(int)((long)-1296396638 ^ (long)-1296396670)] = 0.0f;
        fArray2[(int)((long)1535541224 ^ (long)1535541193)] = 0.0f;
        fArray2[(int)((long)-2020193697 ^ (long)-2020193667)] = 0.0f;
        fArray2[(int)((long)1914876828 ^ (long)1914876863)] = 0.0f;
        fArray2[(int)((long)2144673434 ^ (long)2144673470)] = 1.0f;
        fArray2[(int)((long)1113250298 ^ (long)1113250271)] = 0.0f;
        fArray2[(int)((long)1065908476 ^ (long)1065908442)] = 0.0f;
        fArray2[(int)((long)-162970592 ^ (long)-162970617)] = 1.0f;
        fArray2[(int)((long)246874320 ^ (long)246874360)] = 1.0f;
        fArray2[(int)((long)1774243598 ^ (long)1774243623)] = 0.0f;
        fArray2[(int)((long)779957788 ^ (long)779957814)] = 1.0f;
        fArray2[(int)((long)-344699528 ^ (long)-344699565)] = 1.0f;
        fArray2[(int)((long)-690530164 ^ (long)-690530144)] = 1.0f;
        fArray2[(int)((long)-318681643 ^ (long)-318681608)] = 1.0f;
        fArray2[(int)((long)-1733827987 ^ (long)-1733828029)] = 0.0f;
        fArray2[(int)((long)257829559 ^ (long)257829528)] = 1.0f;
        fArray2[(int)((long)1763279075 ^ (long)1763279059)] = 0.0f;
        fArray2[(int)((long)-905617372 ^ (long)-905617387)] = 0.0f;
        fArray2[(int)((long)1841225627 ^ (long)1841225641)] = 0.0f;
        fArray2[(int)((long)-920797290 ^ (long)-920797275)] = 1.0f;
        fArray2[(int)((long)893477520 ^ (long)893477540)] = 0.0f;
        fArray2[(int)((long)-1050069381 ^ (long)-1050069426)] = 0.0f;
        fArray2[(int)((long)-42653102 ^ (long)-42653084)] = 1.0f;
        fArray2[(int)((long)-727210118 ^ (long)-727210163)] = 0.0f;
        fArray2[(int)((long)-1130844851 ^ (long)-1130844811)] = 1.0f;
        fArray2[(int)((long)-472653263 ^ (long)-472653304)] = 0.0f;
        fArray2[(int)((long)-209284173 ^ (long)-209284215)] = 0.0f;
        fArray2[(int)((long)1918491154 ^ (long)1918491177)] = 1.0f;
        fArray2[(int)((long)1988425400 ^ (long)1988425348)] = 0.0f;
        fArray2[(int)((long)-970914487 ^ (long)-970914444)] = 1.0f;
        fArray2[(int)((long)-644237651 ^ (long)-644237677)] = 1.0f;
        fArray2[(int)((long)33057801 ^ (long)33057846)] = 1.0f;
        fArray2[(int)((long)-744656004 ^ (long)-744656068)] = 1.0f;
        fArray2[(int)((long)-770897242 ^ (long)-770897177)] = 1.0f;
        fArray2[(int)((long)323783430 ^ (long)323783492)] = 1.0f;
        fArray2[(int)((long)-1532764895 ^ (long)-1532764830)] = 1.0f;
        fArray2[(int)((long)-984195119 ^ (long)-984195179)] = 0.0f;
        fArray2[(int)((long)-84142319 ^ (long)-84142252)] = 0.0f;
        fArray2[(int)((long)817330481 ^ (long)817330551)] = 1.0f;
        fArray2[(int)((long)-1299902879 ^ (long)-1299902938)] = 0.0f;
        this.9.compile(fArray2);
        this.3U = new VBO();
        float[] fArray3 = new float[(int)((long)-811863169 ^ (long)-811863172)];
        fArray3[(int)((long)-1819475639 ^ (long)-1819475639)] = 0.0f;
        fArray3[(int)((long)-257097280 ^ (long)-257097279)] = 0.0f;
        fArray3[(int)((long)1075364453 ^ (long)1075364455)] = 0.0f;
        this.3U.compile(fArray3);
        this.3D = new CopyOnWriteArrayList<buo>();
        this.8 = new CopyOnWriteArrayList<fx>();
        this.0 = new 8H();
        try {
            this.36 = new 8_();
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-1325630854 ^ (long)-1325630879)];
            if (var7) break block23;
            var3_2 = (int)((long)633542553 ^ (long)633542553);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u6763\u4eb2\u5d77\u555d\u677f\u4e5b\u5d0b\u552e\u670c\u4e47\u5de6\u553e\u67e8\u4ea7\u5d87\u551a\u67e9\u4e60\u5dce\u55aa\u67a1\u4e5c\u5d12\u552c\u67a4\u4e08\u5dd0\u55e2\u674d\u4ec2\u5d77\u5516\u6787\u4e5c\u5d82\u5526\u67db\u4efd\u5d28\u559a\u67a0\u4ebb\u5d45\u554e\u6775\u4e6a\u5d00\u5550\u67d7\u4ea2\u5dea\u552d\u671a\u4e36\u5da1\u55e0\u6774\u4e83\u5df1\u557d\u678e\u4e67\u5d00\u55a8\u675a\u4ec0\u5de3\u5550\u67d9\u4e79\u5d17\u552c\u67d0\u4e48\u5da0\u552f\u6792\u4e05\u5da3\u550d\u671b\u4e65\u5d96\u5560\u6761\u4e39\u5d93\u55f6\u674b\u4e55\u5d51\u55f5\u67cd\u4e71\u5d69\u5527\u6768\u4e9e\u5ded\u5529\u67db\u4e57\u5d42\u551d\u673b\u4e06\u5d44\u5572\u67a8\u4e8a\u5de7\u55ba\u67eb\u4e0d\u5d29\u55af\u6707\u4e3d\u5d12\u55c9\u6734\u4e95\u5d45\u5511\u670c\u4e5a\u5dd4\u55ab\u67e5\u4ee7\u5d5f\u5514\u6765\u4e2b\u5d89\u5507\u6724\u4e8a\u5da1\u5550\u6737\u4e14\u5d9d\u55f3\u6771\u4eff\u5d67\u55fb\u6768\u4ed6\u5d23\u5593\u6790\u4eb1\u5d22\u556a\u678b\u4ed3\u5d5d\u555b\u6726\u4e48\u5d96\u55c7\u6746\u4e58\u5dec\u55a7\u6771\u4e47\u5de1\u553f\u6756\u4e25\u5d0a\u552f\u6776\u4e84\u5d08\u5545\u6704\u4ec9\u5d68\u5551\u676e\u4e9a\u5d44\u5506\u6714\u4e5e\u5df5\u5565\u67e2\u4ee9\u5d3b\u55f5\u670c\u4e65\u5daa\u559f\u678c\u4e5f\u5de7\u5526\u67f5\u4ef3\u5d9a\u5503\u67fc\u4e24\u5dbb\u5591\u6739\u4ee4\u5de1\u55cd\u6754\u4eb0\u5dd8\u55c9\u67b1\u4e71\u5d28\u554a\u67d3\u4e0f\u5d0a\u55e7\u6775\u4e3d\u5d89\u5581\u6732\u4ee7\u5d5f\u5576\u67c1\u4e51\u5da6\u5506\u6793\u4eec\u5dcb\u553b\u674d\u4e7c\u5d45\u555c\u6706\u4e55\u5d47\u552a\u67ab\u4e2a\u5d18\u55d8\u67cc\u4e5b\u5d7a\u5576\u6706\u4ef6\u5da1\u55c6\u67f9\u4e77\u5dfd\u552d\u6775\u4e16\u5d8a\u55d6\u6769\u4e15\u5d10\u5527\u67d0\u4e77\u5d84\u55cb\u673e\u4ec6\u5ddb\u55ff\u67c1\u4e58\u5ded\u55df\u675a\u4ecf\u5d97\u553a\u673d\u4ef6\u5dad\u55ed\u676c\u4e11\u5dfe\u55e8\u676e\u4edc\u5d41\u5531\u67ba\u4e50\u5d43\u55c4\u67da\u4ed2\u5d81\u5541\u6752\u4eb5\u5d46\u551e\u67b6\u4e45\u5d4b\u55eb\u6731\u4e25\u5d6e\u5575\u6770\u4e95\u5de0\u553e\u6735\u4ea3\u5df9\u550e\u6738\u4e98\u5d21\u551a\u6742\u4e5b\u5db0\u55ec\u6724\u4e0c\u5d72\u55ef\u67fa\u4e55\u5d42\u55ce\u67a3\u4e8c\u5df1\u55ac\u679f\u4e65\u5d1d\u551d\u6782\u4e45\u5d0c\u5566\u67cb\u4ea3\u5d89\u55f2\u6759\u4e4f\u5d09\u5578\u67e5\u4e57\u5d46\u5589\u674b\u4e93\u5df4\u5531\u67c6\u4e7e\u5d77\u550d\u67fd\u4e07\u5d38\u5530\u6767\u4eac\u5db7\u55ca\u6747\u4e90\u5dc3\u558a\u67da\u4e93\u5dfc\u5526\u673f\u4edb\u5dc3\u5563\u6703\u4e31\u5d79\u5548\u6707\u4e79\u5dbc\u5591\u67f2\u4e6e\u5de0\u551d\u6717\u4e15\u5dbe\u5520\u678e\u4ec6\u5d1c\u557d\u6711\u4ebb\u5dff\u5559\u6758\u4e39\u5ddb\u55f1\u677f\u4e77\u5d13\u5551\u6740\u4e5b\u5d96\u5575\u679b\u4e2c\u5d14\u5553\u67ff\u4ee3\u5d86\u55bf\u671a\u4e43\u5d6a\u559e\u67df\u4eb1\u5d1a\u55b6\u67d4\u4ed5\u5d9b\u552c\u67d4\u4ec3\u5db4\u55ac\u6779\u4ef1\u5d7f\u5538\u6717\u4ecf\u5dfb\u5517\u6785\u4e9b\u5d72\u55e6\u6752\u4e59\u5d97\u55f8\u6701\u4eb4", -2060238604);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-8545701 ^ (long)-8545698);
            if (var7) break block23;
            var0_6 = (int)((long)1146030111 ^ (long)-1146030112);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-509456140 ^ (long)-509456161);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1051643277 ^ (long)1051643276);
                    if (7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\uff67\ud6a2\uc5d3\ucd3f\ufff2\ud6d5\uc53f\ucddc\uff88\ud694\uc599\ucd08\uff8c\ud65e\uc559\ucd25\uff77\ud689\uc5a1\ucde1\uffc8\ud668\uc5d1\ucd40\uff2f\ud60d\uc591\ucd49\uffce\ud64e\uc5b1\ucdc9\uff01\ud688\uc54d\ucd87\uff59\ud6ad\uc5a3\ucd1f\uffc5\ud6ff\uc5be", -1366632193);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)432205213 ^ (long)432205209);
                            var0_6 = (int)((long)1622493955 ^ (long)-1622493956);
                            while (true) {
                                v0 = (int)((long)-1711996453 ^ (long)-1711996418);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-893242875 ^ (long)-893242875);
                                if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) ** continue;
                                throw null;
                            }
                            7V.d = var5_1;
                            7V.e = new String[(int)((long)-1202510006 ^ (long)-1202509999)];
                            if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-884590047 ^ (long)-884590047);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1851345034 ^ (long)-1851345033)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1648414069 ^ (long)-1648414068)) {
                                case 0: {
                                    v15 = (int)((long)-79923774 ^ (long)-79923801);
                                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1243257397 ^ (long)-1243257448);
                                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1805409470 ^ (long)1805409466);
                                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1122157078 ^ (long)-1122157130);
                                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1049984395 ^ (long)1049984432);
                                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)753349359 ^ (long)753349368);
                                    if (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)525316792 ^ (long)525316744);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7V.\u2003\u200a\u2003\u2008\u2000\u200a\u2007);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 8(VBO vBO, int n) {
        block3: {
            block2: {
                boolean bl = \u2003\u200a\u2003\u2008\u2000\u200a\u2007;
                if (bl || bl) break block2;
                2c c2 = (2c)3.ac();
                if (bl || bl) break block2;
                this.8.forEach(fx2 -> {
                    block3: {
                        block2: {
                            boolean bl = \u2003\u200a\u2003\u2008\u2000\u200a\u2007;
                            if (bl || bl) break block2;
                            RenderSystem.pushMatrix();
                            if (bl || bl) break block2;
                            RenderSystem.translated((double)((double)fx2.u() - c2.getRenderPosX()), (double)((double)fx2.v() - c2.getRenderPosY()), (double)((double)fx2.w() - c2.getRenderPosZ()));
                            if (bl || bl) break block2;
                            vBO.bind().draw(n).unbind();
                            if (bl || bl) break block2;
                            RenderSystem.popMatrix();
                            if (!bl && !bl) break block3;
                        }
                        return;
                    }
                });
                if (!bl && !bl) break block3;
            }
            return;
        }
    }
}

