/* ==========================================================================
 * MODULE: Flight
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Allows you to fly
 * OBFUSCATED CLASS: net.impactclient.07
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqa
 *  dwu
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  st$a
 */
package net.impactclient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.14;
import net.impactclient.15;
import net.impactclient.1P;
import net.impactclient.1a;
import net.impactclient.1b;
import net.impactclient.1k;
import net.impactclient.1p;
import net.impactclient.1s;
import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.34X;
import net.impactclient.3X;
import net.impactclient.3d;
import net.impactclient.3e;
import net.impactclient.3sx;
import net.impactclient.4X;
import net.impactclient.7F;
import net.impactclient.7m;
import net.impactclient.8H;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 07
extends 3X
implements 34B {
    @EventHandler
    private final Listener<3sx> 1;
    private static final String[] e;
    private 1P 5;
    public static final boolean \u2006\u2002\u2008\u2003;
    private final 8H 0;
    private static final String[] d;
    private final List<st.a> 2;
    @EventHandler
    private final Listener<4X> 8;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 07.\u2006\u2002\u2008\u2003;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)18294236 ^ (long)18288859)) & (int)((long)-441335756 ^ (long)-441368629);
            if (var9_2) ** GOTO lbl-1000
            if (07.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 07.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-485806476 ^ (long)-485806476)] & (int)((long)1701776353 ^ (long)1701776158)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-356180066 ^ (long)-356179970);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)697118863 ^ (long)697118763);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1008822519 ^ (long)-1008822451);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)414751547 ^ (long)414751658);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)880784982 ^ (long)880785112);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1319357862 ^ (long)-1319357733);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1373994030 ^ (long)1373994073);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1384506849 ^ (long)-1384506841);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)489777699 ^ (long)489777793);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)978011060 ^ (long)978010881);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)657430488 ^ (long)657430385);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-366197844 ^ (long)-366197875);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1724393520 ^ (long)1724393569);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)438870406 ^ (long)438870276);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-58759349 ^ (long)-58759403);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)653760791 ^ (long)653760874);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)231762523 ^ (long)231762601);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1856593388 ^ (long)1856593253);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)650260203 ^ (long)650260083);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1620786843 ^ (long)-1620786922);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)519025159 ^ (long)519025197);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-794550691 ^ (long)-794550659);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-694293635 ^ (long)-694293651);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)429724639 ^ (long)429724565);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-658235831 ^ (long)-658235746);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-2035819496 ^ (long)-2035819320);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-36885723 ^ (long)-36885683);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)738440618 ^ (long)738440465);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1256752670 ^ (long)-1256752881);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1252087306 ^ (long)-1252087412);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1990618044 ^ (long)1990617856);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1486205414 ^ (long)1486205296);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)543009327 ^ (long)543009524);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)567206967 ^ (long)567206939);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-166942581 ^ (long)-166942641);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)935104459 ^ (long)935104472);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1666050248 ^ (long)-1666050206);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-829310557 ^ (long)-829310712);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)81407071 ^ (long)81407116);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-592842843 ^ (long)-592842943);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-912756454 ^ (long)-912756378);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1086654461 ^ (long)1086654284);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1272357885 ^ (long)-1272357667);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-739235982 ^ (long)-739236060);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1301994110 ^ (long)-1301994224);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1503053757 ^ (long)1503053733);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1776790699 ^ (long)-1776790575);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1662443769 ^ (long)1662443667);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1680192961 ^ (long)-1680192963);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)313020012 ^ (long)313019953);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-915000175 ^ (long)-915000258);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1215854935 ^ (long)1215855035);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)251746056 ^ (long)251746268);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1122029868 ^ (long)1122029933);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1834568367 ^ (long)-1834568386);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-377853122 ^ (long)-377853104);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-810973221 ^ (long)-810973201);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-604542930 ^ (long)-604542975);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-84148975 ^ (long)-84148988);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)872146544 ^ (long)872146545);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-375932665 ^ (long)-375932585);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-926013388 ^ (long)-926013333);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1445882311 ^ (long)-1445882341);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-39738741 ^ (long)-39738808);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-2095214261 ^ (long)-2095214331);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1108855807 ^ (long)-1108855735);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1032605346 ^ (long)-1032605300);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1784697201 ^ (long)1784697096);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-933873541 ^ (long)-933873410);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1501982226 ^ (long)1501982449);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1851296412 ^ (long)-1851296370);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)2077993099 ^ (long)2077993209);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)878554236 ^ (long)878554172);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-616420464 ^ (long)-616420414);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)3458279 ^ (long)3458298);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1205445524 ^ (long)1205445481);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1956756960 ^ (long)1956756767);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)2135996207 ^ (long)2135996306);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)98202377 ^ (long)98202489);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1910009376 ^ (long)-1910009354);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-75296044 ^ (long)-75296226);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1669295467 ^ (long)-1669295394);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-278574995 ^ (long)-278575104);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-100817174 ^ (long)-100817217);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1081820530 ^ (long)-1081820564);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)613856572 ^ (long)613856535);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-614411660 ^ (long)-614411752);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1598345266 ^ (long)1598345305);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1093246484 ^ (long)-1093246486);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)529207095 ^ (long)529207071);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1638485955 ^ (long)1638485844);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1584562773 ^ (long)-1584562849);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1875435902 ^ (long)1875435821);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-357352963 ^ (long)-357353040);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-547301341 ^ (long)-547301358);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1328657954 ^ (long)-1328657985);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)788501676 ^ (long)788501733);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)102685079 ^ (long)102685155);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1601400014 ^ (long)1601399891);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1192616760 ^ (long)-1192616763);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1998424818 ^ (long)-1998424621);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-794833171 ^ (long)-794833270);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-2003594142 ^ (long)-2003594026);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-24088629 ^ (long)-24088690);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1709581700 ^ (long)1709581669);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1658502151 ^ (long)1658502262);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1389075209 ^ (long)1389075239);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1186612406 ^ (long)-1186612279);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1955677122 ^ (long)1955676979);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)573936463 ^ (long)573936516);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)852922360 ^ (long)852922120);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1742849080 ^ (long)1742849214);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1102093065 ^ (long)-1102093104);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-928215683 ^ (long)-928215736);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1721409717 ^ (long)1721409671);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)365157909 ^ (long)365158046);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1616379427 ^ (long)-1616379526);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)90501295 ^ (long)90501267);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)890115010 ^ (long)890115018);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)406628383 ^ (long)406628399);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)851778654 ^ (long)851778792);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1124111987 ^ (long)1124111919);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)211682355 ^ (long)211682546);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1711113923 ^ (long)1711113910);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-871391814 ^ (long)-871391754);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1534319359 ^ (long)1534319129);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)330350577 ^ (long)330350581);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-581538913 ^ (long)-581538869);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-818370283 ^ (long)-818370128);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1766579083 ^ (long)1766579098);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1734503877 ^ (long)1734503700);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)65217309 ^ (long)65217493);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1295067552 ^ (long)1295067392);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-691775576 ^ (long)-691775658);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1065539820 ^ (long)1065539611);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1726872315 ^ (long)1726872132);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1783279092 ^ (long)-1783278875);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-592785792 ^ (long)-592785882);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-672881534 ^ (long)-672881624);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1393767014 ^ (long)1393766928);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-812133236 ^ (long)-812133311);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)76791469 ^ (long)76791346);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1829792206 ^ (long)1829792176);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1248378694 ^ (long)1248378716);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)896075422 ^ (long)896075286);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)472125579 ^ (long)472125683);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)561721397 ^ (long)561721474);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-618575779 ^ (long)-618575804);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)908250087 ^ (long)908249945);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)26004249 ^ (long)26004266);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1111882207 ^ (long)1111882036);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)707029694 ^ (long)707029585);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1256053953 ^ (long)1256054008);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-40874169 ^ (long)-40874224);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-54867212 ^ (long)-54867386);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)2071798686 ^ (long)2071798677);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)229728110 ^ (long)229728242);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1559605071 ^ (long)1559605064);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)106064827 ^ (long)106064797);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)213631106 ^ (long)213631134);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1586328517 ^ (long)-1586328478);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1194073226 ^ (long)1194073292);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-660112369 ^ (long)-660112176);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1506083803 ^ (long)-1506083699);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1054603529 ^ (long)1054603565);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1816301040 ^ (long)-1816301026);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1146722560 ^ (long)1146722805);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-478082882 ^ (long)-478083036);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)150836792 ^ (long)150836973);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)942942524 ^ (long)942942623);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1600992853 ^ (long)1600992908);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1014320417 ^ (long)-1014320527);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)755881420 ^ (long)755881283);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1199301916 ^ (long)1199302112);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1077415178 ^ (long)1077415411);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)309955624 ^ (long)309955773);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1115048275 ^ (long)-1115048214);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1027307634 ^ (long)-1027307597);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1500023255 ^ (long)1500023067);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1701234854 ^ (long)1701234788);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)848442977 ^ (long)848443009);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1405925972 ^ (long)-1405925994);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)2007934046 ^ (long)2007934163);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)853980892 ^ (long)853980899);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-441623361 ^ (long)-441623465);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-506943816 ^ (long)-506943837);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-739078924 ^ (long)-739078985);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1830681784 ^ (long)-1830681608);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)510882885 ^ (long)510883071);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1121987241 ^ (long)-1121987234);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-732776526 ^ (long)-732776588);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1998715774 ^ (long)-1998715816);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1469659331 ^ (long)-1469659203);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-797233753 ^ (long)-797233691);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1022950116 ^ (long)-1022949916);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-9908160 ^ (long)-9908045);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1332107410 ^ (long)-1332107411);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1351690284 ^ (long)-1351690422);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-2068120276 ^ (long)-2068120161);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1940880089 ^ (long)1940879945);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)64897048 ^ (long)64897240);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-32141457 ^ (long)-32141502);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)20609763 ^ (long)20609757);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1423906803 ^ (long)1423906785);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1603365824 ^ (long)1603365660);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1422845302 ^ (long)-1422845282);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1812117440 ^ (long)1812117272);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1220917270 ^ (long)-1220917468);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1158714221 ^ (long)1158714361);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1937620844 ^ (long)-1937620753);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)715013969 ^ (long)715014070);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1105638546 ^ (long)1105638587);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)110409771 ^ (long)110409949);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1770790107 ^ (long)1770790107);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-889644348 ^ (long)-889644449);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-501859153 ^ (long)-501859175);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1021598227 ^ (long)-1021598258);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-486110326 ^ (long)-486110395);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1641918568 ^ (long)1641918567);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1325340955 ^ (long)-1325340992);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1384821233 ^ (long)-1384821146);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1287972772 ^ (long)-1287972761);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1544693740 ^ (long)-1544693743);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)764085188 ^ (long)764085159);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1412477483 ^ (long)1412477587);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1001680319 ^ (long)1001680347);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)960001769 ^ (long)960001782);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)189820780 ^ (long)189820681);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1881975233 ^ (long)1881975115);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-956401271 ^ (long)-956401368);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1191601223 ^ (long)1191601355);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-100956642 ^ (long)-100956548);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)309893604 ^ (long)309893567);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1434853309 ^ (long)1434853339);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-217802165 ^ (long)-217802148);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1487490053 ^ (long)-1487490124);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-2025454483 ^ (long)-2025454424);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1615987934 ^ (long)1615987749);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1606474045 ^ (long)1606474200);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-224582499 ^ (long)-224582581);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)2052365776 ^ (long)2052365591);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1374726038 ^ (long)-1374726051);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1044457313 ^ (long)-1044457448);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1431722989 ^ (long)1431722898);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-539415523 ^ (long)-539415309);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)2005470684 ^ (long)2005470543);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1003819144 ^ (long)-1003819150);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1886076038 ^ (long)-1886076032);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)611301110 ^ (long)611301038);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)3743484 ^ (long)3743333);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-354932074 ^ (long)-354932165);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-668456474 ^ (long)-668456657);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1123677427 ^ (long)1123677421);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1536349220 ^ (long)1536349224);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1841120844 ^ (long)-1841121011);
                    if (!07.\u2006\u2002\u2008\u2003) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1169468874 ^ (long)-1169468774);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1745433849 ^ (long)-1745433608)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1672652898 ^ (long)-1672632223)) >>> (int)((long)-257535524 ^ (long)-257535532)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-2005100398 ^ (long)-2005100398);
            if (!07.\u2006\u2002\u2008\u2003) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-103164188 ^ (long)-103164186);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1715950520 ^ (long)1715950523) | var5_6 << (int)((long)1090002046 ^ (long)1090002043)) ^ var3_4[var7_8]) & (int)((long)1283781165 ^ (long)1283781330);
                    if (07.\u2006\u2002\u2008\u2003) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1052064701 ^ (long)1052064702) | var6_7 << (int)((long)-961003864 ^ (long)-961003859)) ^ var3_4[var7_8]) & (int)((long)1467743413 ^ (long)1467743306);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            07.e[var2_3] = new String(var3_4).intern();
        }
        return 07.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 07.\u2006\u2002\u2008\u2003;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)714138243 ^ (long)714138246)];
            if (var7) break block23;
            var3_2 = (int)((long)776122031 ^ (long)776122031);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u08d5\u2057\u3301\u3b65\u08ff\u2095\u331d\u3b69\u089b\u200c\u3317\u3baf\u08e6\u2069\u33ae\u3bc8\u08b4\u2030\u33e5\u3b81\u0846\u20f8\u3350\u3ba5\u0859\u2005\u336a\u3bb5\u081b\u2047\u3372\u3b84\u0892\u2030\u3359\u3ba0\u08e6\u20f8\u33b9\u3bbe\u0847\u204b\u3301\u3b8e\u0888\u20e7\u33fc\u3b8c\u0822\u2049\u337f\u3b4c\u0848\u2011\u3348\u3be1\u0820\u20f5\u332a\u3b7a\u0824", -1299370364);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1700370303 ^ (long)1700370297);
            if (var7) break block23;
            var0_6 = (int)((long)1001116310 ^ (long)-1001116311);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1485367030 ^ (long)1485366982);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1764443863 ^ (long)1764443862);
                    if (07.\u2006\u2002\u2008\u2003) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!07.\u2006\u2002\u2008\u2003) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u533b\u7bc0\u680b\u60d2\u530a\u7bb8\u684e\u60b4\u5333\u7b47\u68d0\u609f\u53e5\u7b8b\u68c0\u6085\u5381\u7ba8\u6846\u60b7\u539d\u7b72\u6803\u6026\u536f\u7b00", -96897775);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-831935156 ^ (long)-831935164);
                            var0_6 = (int)((long)-785932579 ^ (long)785932578);
                            while (true) {
                                v0 = (int)((long)-1402087942 ^ (long)-1402088024);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1045885519 ^ (long)-1045885519);
                                if (!07.\u2006\u2002\u2008\u2003) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!07.\u2006\u2002\u2008\u2003) ** continue;
                                throw null;
                            }
                            07.d = var5_1;
                            07.e = new String[(int)((long)-556238941 ^ (long)-556238938)];
                            if (!07.\u2006\u2002\u2008\u2003) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1310160555 ^ (long)1310160555);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)306690461 ^ (long)306690460)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1803956394 ^ (long)-1803956399)) {
                                case 0: {
                                    v15 = (int)((long)-1675757295 ^ (long)-1675757276);
                                    if (!07.\u2006\u2002\u2008\u2003) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-639956142 ^ (long)-639956163);
                                    if (!07.\u2006\u2002\u2008\u2003) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1829147651 ^ (long)1829147656);
                                    if (!07.\u2006\u2002\u2008\u2003) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-32629861 ^ (long)-32629847);
                                    if (!07.\u2006\u2002\u2008\u2003) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1070864467 ^ (long)-1070864488);
                                    if (!07.\u2006\u2002\u2008\u2003) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1813244119 ^ (long)1813244132);
                                    if (!07.\u2006\u2002\u2008\u2003) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-580024964 ^ (long)-580025016);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!07.\u2006\u2002\u2008\u2003);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public 07() {
        boolean bl = \u2006\u2002\u2008\u2003;
        super(07.b((int)((long)-682557520 ^ (long)-682571081), (int)((long)-1999756620 ^ (long)1999744210)) /* "Flight" */, 07.b((int)((long)436256926 ^ (long)436270493), (int)((long)1184394422 ^ (long)1184379556)) /* "Allows you to fly" */);
        this.5 = (1P)((34X)((34X)((34X)this.4().5(07.b((int)((long)-1236791411 ^ (long)-1236780408), (int)((long)-1378786836 ^ (long)1378802564)) /* "Anti Kick" */)).7(07.b((int)((long)1332434769 ^ (long)1332437589), (int)((long)1206362241 ^ (long)1206357922)) /* "antikick" */)).1(07.b((int)((long)102415937 ^ (long)102402887), (int)((long)939420073 ^ (long)-939402365)) /* "Prevents vanilla from kicking you for flying" */)).5();
        this.0 = new 8H();
        this.2 = new ArrayList<st.a>();
        this.1 = new Listener(sx -> {
            block3: {
                block2: {
                    boolean bl = \u2006\u2002\u2008\u2003;
                    if (bl || bl) break block2;
                    this.0.0();
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)71791675 ^ (long)71791675)]);
        this.8 = new Listener(x2 -> {
            block16: {
                double d2;
                double d3;
                String[] stringArray;
                block15: {
                    double d4;
                    boolean bl = \u2006\u2002\u2008\u2003;
                    if (bl) return;
                    stringArray = 3e.5();
                    if (bl || bl) return;
                    if (3d.3(this)) {
                        if (bl || bl) return;
                        return;
                    }
                    if (bl) return;
                    if (07.3.s.ao()) {
                        if (bl || bl) return;
                        this.0.0();
                        if (bl) return;
                    }
                    if (bl) return;
                    if (!this.5.2) return;
                    if (bl) return;
                    if (!this.0.8(0x1D0926297C7B4B53L ^ 0x1D0926297C7B58DBL)) return;
                    if (bl || bl) return;
                    this.0.0();
                    if (bl || bl) return;
                    x2 = 07.3.s;
                    if (bl || bl) return;
                    int n = (int)((long)1144448943 ^ (long)1144448943);
                    if (bl) return;
                    if (bl) return;
                    double d5 = d4 = x2.cc().b;
                    if (bl) return;
                    do {
                        if (bl) return;
                        if (!(d5 > 0.0)) break;
                        if (bl || bl) return;
                        if (stringArray != null) return;
                        if (bl) return;
                        4X x3 = x2;
                        if (((aqa)x2).l.b((aqa)x3, x3.cc().d(0.0, (double)(-n), 0.0).g(0.0625)).count() > (0xC4C705B4194749F5L ^ 0xC4C705B4194749F5L)) {
                            if (bl || bl) return;
                            if (d5 == d4) {
                                if (bl) {
                                    return;
                                }
                                d3 = 0.0;
                                if (\u2006\u2002\u2008\u2003) {
                                    throw null;
                                }
                                break block15;
                            }
                            double d6 = d5;
                            d3 = d4 - d5 - 1.0 + (d6 - (double)((int)d6));
                            if (\u2006\u2002\u2008\u2003) {
                                throw null;
                            }
                            break block15;
                        }
                        d5 -= 1.0;
                        ++n;
                    } while (stringArray == null);
                    d3 = d2 = -1.0;
                }
                if (d3 <= 0.0) {
                    return;
                }
                this.2.clear();
                for (double d7 = 0.0; d7 < d2 + 8.0; d7 += 8.0) {
                    double d8 = Math.min(d7, d2);
                    this.2.add(new st.a(07.3.s.cD(), 07.3.s.cE() - d8, 07.3.s.cH(), (boolean)((long)-588714321 ^ (long)-588714321)));
                    if (stringArray == null) {
                        if (d8 == d2) break;
                        if (stringArray == null) continue;
                        break;
                    }
                    break block16;
                }
                this.2.forEach(arg_0 -> ((dwu)07.3.s.e).a(arg_0));
                this.2.remove(this.2.size() - (int)((long)222220363 ^ (long)222220362));
                Collections.reverse(this.2);
            }
            this.2.forEach(arg_0 -> ((dwu)07.3.s.e).a(arg_0));
        }, (byte)((long)-2063486243 ^ (long)-2063486241), new Predicate[(int)((long)1939251181 ^ (long)1939251181)]);
        7m[] mArray = new 7m[(int)((long)-856791995 ^ (long)-856791987)];
        mArray[(int)((long)-2043977480 ^ (long)-2043977480)] = new 15(this);
        mArray[(int)((long)-2062632727 ^ (long)-2062632728)] = new 1b(this);
        mArray[(int)((long)1126441666 ^ (long)1126441664)] = new 7F(this);
        mArray[(int)((long)-596737996 ^ (long)-596737993)] = new 14(this);
        mArray[(int)((long)-484937337 ^ (long)-484937341)] = new 1a(this);
        mArray[(int)((long)1029927844 ^ (long)1029927841)] = new 1s(this);
        mArray[(int)((long)-1704021666 ^ (long)-1704021672)] = new 1p(this);
        mArray[(int)((long)1788004937 ^ (long)1788004942)] = new 1k(this);
        this.5(mArray);
        if (bl || bl) {
            return;
        }
    }
}

