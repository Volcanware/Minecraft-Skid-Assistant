/* ==========================================================================
 * MODULE: Storage ESP
 * CATEGORY (inferred): Render
 * DESCRIPTION: Draws boxes around storage containers
 * OBFUSCATED CLASS: net.impactclient.7T
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqa
 *  bcp
 *  bhq
 *  bhs
 *  bht
 *  brc
 *  buo
 *  bup
 *  bve
 *  ccj
 *  ccn
 *  ccs
 *  ccv
 *  ccw
 *  ccy
 *  cde
 *  cdn
 *  ceh
 *  cez
 *  cfj
 *  com.mojang.blaze3d.systems.RenderSystem
 *  dci
 *  dcn
 *  dde
 *  ddh
 *  fx
 *  gr
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  pw.knx.feather.structures.Color
 */
package net.impactclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.lang.invoke.LambdaMetafactory;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1A;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.1R;
import net.impactclient.2_;
import net.impactclient.2c;
import net.impactclient.2n;
import net.impactclient.2o;
import net.impactclient.2w$6X;
import net.impactclient.34E;
import net.impactclient.34J;
import net.impactclient.34L;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.5K;
import net.impactclient.8S;
import net.impactclient.8h;
import net.impactclient.94;
import pw.knx.feather.structures.Color;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7T
extends 3X
implements 8h {
    private 1R 4;
    private 1P 5U;
    private 1R 52;
    private 1R 5g;
    private 1P 59;
    private 1K 2;
    private 1P 7;
    private 1P 5h;
    private static final dci 0;
    @EventHandler
    private final Listener<2o> 5t;
    private 1R 5G;
    private 1P 8;
    private 1R 5x;
    private 1R 5M;
    private 1P 5N;
    private 1P 5B;
    private 1P 5f;
    private 1R 5p;
    private static final dci 56;
    private static final dci 5s;
    public static final boolean \u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
    private 1P 6;
    private 1R 5R;
    private static final String[] d;
    private 1P 5K;
    private 1R 5Z;
    private static final dci 5H;
    private 1P 5z;
    private static final dci 5_;
    private 1A 1;
    private 1R 5X;
    private 1P 5a;
    private 1P 5;
    private 1P 9;
    private 1R 5d;
    private static final String[] e;

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static boolean 3(fx fx2) {
        int n;
        boolean bl;
        block3: {
            bl = \u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
            if (bl) return true;
            int n2 = (int)((long)465883982 ^ (long)-465883981);
            String[] stringArray = 3e.5();
            if (bl) return true;
            do {
                block5: {
                    block4: {
                        if (bl) return true;
                        if (n2 > (int)((long)1684646348 ^ (long)1684646351)) break block3;
                        if (bl) return true;
                        if (bl) return true;
                        n = (int)((long)1422309341 ^ (long)-1422309344);
                        if (stringArray != null) return n != 0;
                        int n3 = n;
                        if (bl) return true;
                        do {
                            if (bl) return true;
                            if (n3 > (int)((long)2081956821 ^ (long)2081956822)) break block4;
                            if (bl) return true;
                            if (bl) return true;
                            if (stringArray != null) break block5;
                            if (bl) return true;
                            if (7T.3.r.d_(new fx(fx2.u() + n2, fx2.v(), fx2.w() + n3)).b() == bup.bP) {
                                if (bl) return true;
                                if (bl) return true;
                                return (int)((long)-850495978 ^ (long)-850495977) != 0;
                            }
                            if (bl) return true;
                            ++n3;
                            if (bl) return true;
                        } while (stringArray == null);
                        if (bl) return true;
                    }
                    if (bl) return true;
                    ++n2;
                    if (bl) return true;
                }
                if (bl) return true;
            } while (stringArray == null);
            if (bl) return true;
        }
        if (bl) return true;
        n = (int)((long)-747706917 ^ (long)-747706917);
        return n != 0;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private /* synthetic */ void 5(2c var1_1, ccj var2_2) {
        block22: {
            block21: {
                var5_3 = 7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
                if (var5_3 || var5_3) lbl-1000:
                // 5 sources

                {
                    return;
                }
                var4_4 = var2_2;
                var3_5 = this;
                if (var5_3 || var5_3) ** GOTO lbl-1000
                if (!(var4_4 instanceof ccn)) ** GOTO lbl-1000
                if (var5_3 || var5_3) ** GOTO lbl-1000
                if (!(var4_4 instanceof cdn)) break block21;
                if (var5_3 || var5_3) ** GOTO lbl-1000
                if (!var3_5.5h.2) ** GOTO lbl-1000
                ** while (var5_3 || var5_3)
lbl14:
                // 1 sources

                v0 /* !! */  = Optional.of(var3_5.52.2);
                if (7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                    throw null;
                }
                break block22;
            }
            if (var3_5.5f.2) {
                v0 /* !! */  = Optional.of(var3_5.5p.2);
                if (7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                    throw null;
                }
            } else if (var4_4 instanceof ccv && var3_5.5z.2) {
                v0 /* !! */  = Optional.of(var3_5.5X.2);
                if (7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                    throw null;
                }
            } else if (var4_4 instanceof ccs && var3_5.5N.2) {
                v0 /* !! */  = Optional.of(var3_5.5Z.2);
                if (7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                    throw null;
                }
            } else if (var4_4 instanceof ccw && var3_5.8.2) {
                v0 /* !! */  = Optional.of(var3_5.5x.2);
                if (7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                    throw null;
                }
            } else if (var4_4 instanceof ccy && var3_5.5.2) {
                v0 /* !! */  = Optional.of(var3_5.5G.2);
                if (7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                    throw null;
                }
            } else if (var4_4 instanceof cde && var3_5.59.2) {
                v0 /* !! */  = Optional.of(var3_5.4.2);
                if (7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                    throw null;
                }
            } else {
                v0 /* !! */  = Optional.empty();
            }
        }
        v0 /* !! */ .map((Function<Color, Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, getHex(), (Lpw/knx/feather/structures/Color;)Ljava/lang/Integer;)()).ifPresent((Consumer<Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, 4(ccj net.impactclient.2c java.lang.Integer ), (Ljava/lang/Integer;)V)((7T)this, (ccj)var2_2, (2c)var1_1));
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 4(ccj ccj2, 2c c2, Integer object) {
        dci dci2;
        float f;
        float f2;
        block17: {
            boolean bl;
            block16: {
                bl = \u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
                if (bl || bl) return;
                double d2 = Math.sqrt(3.aa().e(new dcn((double)ccj2.o().u() + 0.5, (double)ccj2.o().v() + 0.5, (double)ccj2.o().w() + 0.5)));
                if (bl || bl) return;
                object = 34L.5((Integer)object);
                if (bl || bl) return;
                f2 = this.5(90.0f, d2) / 255.0f;
                if (bl || bl) return;
                f = this.5(255.0f, d2) / 255.0f;
                if (bl || bl) return;
                dci2 = 5s;
                if (bl || bl) return;
                if (ccj2 instanceof ccn) break block16;
                if (bl) return;
                if (!(ccj2 instanceof ccv)) break block17;
                if (bl) return;
            }
            if (bl) return;
            dci2 = 56;
            if (bl || bl) return;
            if (ccj2 instanceof ccn) {
                cez cez2;
                cez cez3;
                if (bl || bl) return;
                if (this.5K.2) {
                    if (bl) return;
                    if (7T.3(ccj2.o())) {
                        if (bl || bl) return;
                        return;
                    }
                }
                if (bl) return;
                ceh ceh2 = ((ccn)ccj2).p();
                if (ceh2.b((cfj)bve.c)) {
                    if (bl) {
                        return;
                    }
                    cez3 = (cez)ceh2.c((cfj)bve.c);
                    if (\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                        throw null;
                    }
                } else {
                    cez3 = cez2 = cez.a;
                }
                if (cez3 == cez.b) {
                    return;
                }
                if (cez2 == cez.c) {
                    gr gr2 = bve.h((ceh)ceh2).p();
                    fx fx2 = ccj2.o().a(gr2);
                    ceh ceh3 = 7T.3.r.d_(fx2);
                    dci2 = dde.a((ddh)ceh2.j((brc)7T.3.r, ccj2.o()), (ddh)ceh3.j((brc)7T.3.r, fx2).a((double)gr2.u(), (double)gr2.v(), (double)gr2.w())).a();
                }
            }
        }
        double d3 = (double)ccj2.o().u() - c2.getRenderPosX();
        double d4 = (double)ccj2.o().v() - c2.getRenderPosY();
        double d5 = (double)ccj2.o().w() - c2.getRenderPosZ();
        dci2 = dci2.d(d3, d4, d5);
        2n.8(dci2, 34L.0((float)object[(int)((long)1305044745 ^ (long)1305044745)], (float)object[(int)((long)269191703 ^ (long)269191702)], (float)object[(int)((long)-27368220 ^ (long)-27368218)], f2));
        2n.3(dci2, 34L.0((float)object[(int)((long)-1382550558 ^ (long)-1382550558)], (float)object[(int)((long)-267768054 ^ (long)-267768053)], (float)object[(int)((long)-1189279197 ^ (long)-1189279199)], f), this.1.9);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)1195009851 ^ (long)1195009795)];
            if (var7) break block25;
            var3_2 = (int)((long)-183724930 ^ (long)-183724930);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\u7cad\u55c5\u4699\u4ec8\u7cf6\u55b6\u462a\u4ea7\u7c62\u55ba\u46c6\u4e55\u7c44\u552b\u46aa\u4eda\u7cea\u5542\u4654\u4e5c\u7c5d\u5505\u4615\u4ee9\u7cfe\u5586\u46ad\u4ef3\u7c0d\u5573\u4680\u4ec6\u7c6b\u55f3\u4657\u4ea2\u7c12\u55f4\u467b\u4e1b\u7c15\u5520\u46d6\u4ed2\u7c32\u55a2\u4634\u4e95\u7cd7\u55ee\u465c\u4e3a\u7c7a\u55f1\u4604\u4e57\u7cfa\u5572\u4643\u4eaf\u7cd9\u5578\u46d9\u4e02\u7ce1\u55ff\u4649\u4e64\u7cfa\u551c\u4653\u4eb2\u7cd7\u559f\u4605\u4e2f\u7cdb\u55b0\u46e4\u4e6e\u7caf\u5588\u4652\u4e90\u7cda\u5596\u465f\u4e8d\u7c2e\u5586\u466b\u4e2f\u7cd8\u55c6\u4637\u4ea8\u7c23\u55ba\u4690\u4e26\u7c35\u558a\u4629\u4e55\u7c02\u55f8\u46b9\u4e04\u7c4f\u5580\u46d8\u4e6a\u7c37\u5589\u4684\u4e02\u7c67\u5544\u4632\u4e31\u7cab\u5522\u461c\u4ef5\u7c32\u5546\u46f4\u4ed9\u7cbd\u552e\u467d\u4e0f\u7c54\u55f5\u46a2\u4e95\u7cd4\u55d3\u46b2\u4e4d\u7ca0\u55d7\u4663\u4e9f\u7c52\u55e2\u4673\u4e30\u7c44\u5516\u46bc\u4e31\u7cd5\u558f\u461c\u4e20\u7c80\u5550\u46a2\u4ea6\u7ca4\u556d\u4658\u4e63\u7c23\u5541\u4670\u4e86\u7caf\u5525\u46e0\u4ee8\u7c5c\u558a\u46f0\u4e28\u7c2f\u5500\u4629\u4e74\u7cfb\u5509\u4691\u4e79\u7c12\u5544\u4626\u4e3e\u7c75\u55df\u46a1\u4e30\u7cff\u5523\u46db\u4ed6\u7cf2\u55f9\u464b\u4ece\u7c63\u5584\u46dc\u4e3a\u7c6d\u551c\u463f\u4ebc\u7c95\u5513\u464e\u4e7b\u7c77\u55ca\u46f7\u4ed0\u7cfb\u5514\u467f\u4e45\u7c7f\u55a0\u4630\u4ec9\u7c77\u555b\u46bb\u4eb9\u7caa\u55bb\u4625\u4e71\u7cf1\u555a\u46cf\u4ec6\u7ce9\u5513\u460b\u4ea8\u7cd1\u559d\u469a\u4e37\u7c4c\u5502\u46a6\u4e1b\u7c5d\u5585\u46dd\u4e78\u7cb7\u556a\u4648\u4ef0\u7c8f\u558e\u46f9\u4ee4\u7c06\u55c1\u463f\u4e30\u7c72\u557a\u468a\u4e3b\u7cd1\u55d3\u4635\u4eab\u7cdd\u5564\u4602\u4e80\u7c9f\u556d\u46b5\u4ebf\u7c82\u55e9\u4649\u4ee3\u7c7b\u5556\u46c0\u4e0c\u7c07\u551d\u4688\u4e38\u7cfc\u553e\u46b3\u4e16\u7c71\u5592\u4618\u4e6a\u7cf3\u55b4\u46c9\u4e86\u7c80\u5562\u460f\u4e9f\u7c75\u5567\u46d3\u4e0a\u7c92\u55fc\u4643\u4ee4\u7cd7\u55f5\u46ab\u4ef0\u7c31\u5569\u462b\u4e3f\u7c02\u5556\u4657\u4eda\u7c85\u5574\u4620\u4e10\u7ced\u55b3\u46ac\u4e82\u7cd9\u5558\u46b1\u4e2b\u7c17\u55f4\u464d\u4e17\u7cff\u5547\u46e6\u4e61\u7cd9\u5522\u463b\u4e88\u7cf0\u5566\u4625\u4eb7\u7cd6\u55da\u46a7\u4e9e\u7ce2\u557c\u4660\u4ed4\u7ce3\u557c\u46f6\u4e21\u7c28\u553e\u4629\u4eb7\u7ce0\u5559\u46e8\u4e5a\u7c3a\u5505\u46cc\u4eb9\u7c31\u55d3\u46f6\u4e4f\u7c8d\u553f\u46cd\u4e09\u7c77\u555b\u46ed\u4e55\u7c44\u5526\u46f8\u4ec2\u7c4a\u5559\u4639\u4ee8\u7c65\u55c9\u4612\u4e31\u7c6e\u5516\u4680\u4e73\u7ca1\u554c\u4697\u4e1d\u7c7d\u55bb\u4642\u4e19\u7c48\u5522\u46c2\u4e96\u7c3e\u5502\u46d0\u4e0b\u7cec\u559f\u4650\u4e1d\u7c8d\u558e\u46a5\u4e7f\u7c15\u551a\u46b7\u4e0f\u7cb6\u5561\u46b7\u4ea4\u7c9d\u5511\u460a\u4e38\u7ca0\u55b6\u4674\u4e9c\u7c11\u5579\u46d8\u4ecd\u7c8f\u558f\u46d2\u4ea2\u7cce\u5543\u46b9\u4e20\u7c2c\u55cf\u462b\u4e69\u7c7f\u5504\u46a0\u4e60\u7c67\u5553\u462b\u4e6a\u7c7d\u556e\u46eb\u4e22\u7c22\u55b3\u4668\u4e06\u7cc8\u556f\u46ed\u4e9c\u7c9a\u55dd\u46d4\u4eb8\u7cbe\u55a2\u4674\u4e0e\u7cf4\u55b4\u46fd\u4e46\u7c7f\u559e\u4653\u4ead\u7c20\u5505\u4679\u4e48\u7ccf\u5578\u46ec\u4e5b\u7c94\u55d4\u4693\u4ea3\u7c4a\u55d5\u46d5\u4eb7\u7c60\u5549\u464b\u4ed9\u7c42\u557c\u4679\u4e76\u7c06\u55c9\u4610\u4ef4\u7c4c\u55d5\u464f\u4e2c\u7cc7\u5580\u4624\u4e88\u7cce\u557e\u466d\u4e2d\u7c0a\u5520\u46aa\u4e26\u7c8f\u550d\u4659\u4ee3\u7c42\u5551\u465c\u4e84\u7c2a\u5565\u4650\u4ee0\u7c4a\u5592\u4629\u4e1e\u7c79\u553b\u4650\u4e74\u7c04\u55be\u469b\u4e8d\u7c0b\u5571\u46d6\u4e1c\u7ccb\u5557\u46e7\u4ea2\u7ce7\u559f\u4652\u4e63\u7c50\u5545\u4645\u4e5d\u7cc6\u5544\u46a3\u4e65\u7c28\u55d3\u46d4\u4e4d\u7c7c\u55a8\u4651\u4ea2\u7cd9\u55ce\u468d\u4e4a\u7cb6\u55e5\u4648\u4e15\u7c14\u552f\u4606\u4e6a\u7c89\u5599\u46f9\u4e30\u7c02\u5560\u46a0\u4e78\u7cd6\u55ec\u4691\u4e9b\u7c0c\u55ef\u46a7\u4e9f\u7c49\u5576\u4651\u4e3c\u7c23\u554d\u465c\u4e98\u7cfd\u55e0\u46c8\u4ed6\u7cf9\u5514\u46ba\u4e41\u7c2b\u553a\u467e\u4e2e\u7cb2\u5545\u46bb\u4ef0\u7cbc\u55c1\u46b3\u4e47\u7ce7\u550f\u467b\u4e2b\u7c59\u5546\u4660\u4ef3\u7cea\u551c\u4658\u4eee\u7cdc\u55ae\u462d\u4e4d\u7c50\u5516\u468b\u4ef5\u7c96\u55d2\u4654\u4e52\u7cf3\u5567\u466a\u4e42\u7cec\u55bd\u4688\u4efb\u7c51\u55f8\u464a\u4e66\u7c00\u558c\u46c7\u4e45\u7c09\u55eb\u4639\u4e31\u7ce5\u5571\u46dc\u4e64\u7c04\u5553\u46fa\u4e03\u7cd0\u5578\u46f7\u4e61\u7cfe\u552d\u4614\u4e79\u7cfe\u5532\u468f\u4e4b\u7ccb\u5552\u46ee\u4ef8\u7c52\u5507\u46a7\u4e8e\u7cf4\u55d0\u4655\u4ecd\u7cd1\u55db\u468e\u4ed0\u7cf0\u5580\u4694\u4ef1\u7c8d\u5567\u46fa\u4e93\u7c25\u553b\u46eb\u4e97\u7c08\u55e8\u464e\u4e5c\u7c5a\u55d6\u46d1\u4e82\u7cd2\u55ed\u464b\u4ec6\u7cc1\u55a0\u468d\u4e7e\u7cdc\u555a\u4686\u4ea3\u7cc4\u55db\u46de\u4e27\u7c4f\u55f5\u46ae\u4e79\u7cc7\u55f0\u461e\u4e6d\u7cdd\u554f\u46b4\u4eef\u7c28\u5581\u4689\u4ebb\u7c4e\u5563\u46f9\u4e0e\u7c8e\u55c1\u468c\u4e6b\u7c3e\u55f0\u46ae\u4eaf\u7c64\u5553\u46f9\u4ef4\u7c94\u5586\u467f\u4ebe\u7cef\u55d6\u4650\u4e3b\u7cc1\u55fe\u46c7\u4e09\u7ce6", -1242604555);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)1674642901 ^ (long)1674642884);
            if (var7) break block25;
            var0_6 = (int)((long)851239647 ^ (long)-851239648);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)-1605313004 ^ (long)-1605313012);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)-1990184623 ^ (long)1990184622);
                        if (7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\u6fab\u465d\u5565\u5dea\u6fe1\u46a5\u5564\u5d1c\u6fee\u461c\u55ba\u5d7e\u6fc4\u4628\u55e6\u5d4b\u6ff8\u46a4\u55e0\u5dfc\u6f64\u4671\u5539\u5d91\u6fe4\u463d\u5597\u5d64\u6fe7\u46b4\u5566\u5d6e\u6ff1\u4697\u5536\u5dac\u6fcb\u4677\u55b2\u5dbd\u6fe1\u4621\u55e9\u5d53\u6f89\u46c8\u5558\u5db6\u6f74\u4668\u554a\u5d19\u6f3e\u4678\u5593\u5d4f\u6ffa\u466b\u551c\u5d5c\u6f00\u4699\u5536\u5d62\u6f0d\u46ac\u555f\u5dee\u6f34\u4669\u551a\u5d03\u6f72\u46fb\u552e\u5d2e\u6f92\u466a\u5510\u5d16\u6fdb\u46da\u55a5\u5d44\u6f87\u46ca\u550c\u5dac\u6f39\u4682\u5541\u5db4\u6fcb\u4632\u559b\u5d83\u6f7e", 1318471918);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)1051401777 ^ (long)1051401728);
                                var0_6 = (int)((long)440491073 ^ (long)-440491074);
                                while (true) {
                                    v0 = (int)((long)-1308089985 ^ (long)-1308090102);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)-1771239401 ^ (long)-1771239401);
                                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) ** continue;
                                    throw null;
                                }
                                7T.d = var5_1;
                                7T.e = new String[(int)((long)-244042569 ^ (long)-244042609)];
                                if (7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)-1483321792 ^ (long)-1483321792);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)347769126 ^ (long)347769127)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-696259079 ^ (long)-696259074)) {
                                    case 0: {
                                        v15 = (int)((long)-2068215046 ^ (long)-2068215162);
                                        if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)59199478 ^ (long)59199394);
                                        if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)-1647414289 ^ (long)-1647414358);
                                        if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)-1687690322 ^ (long)-1687690276);
                                        if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)2080319111 ^ (long)2080319170);
                                        if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)-1980792518 ^ (long)-1980792554);
                                        if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)-963720829 ^ (long)-963720807);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                7T.5s = new dci(0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
                7T.56 = buo.a((double)1.0, (double)0.0, (double)1.0, (double)15.0, (double)14.0, (double)15.0).a();
                7T.0 = new dci(-0.325, 0.325, -0.325, 0.325, 1.025, 0.325);
                7T.5_ = new dci(-0.375, 0.05, -0.375, 0.375, 0.79625, 0.375);
                7T.5H = new dci(-0.375, 0.28, -0.375, 0.375, 1.03, 0.375);
                break;
            }
        }
    }

    public 7T() {
        boolean bl = \u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
        super(7T.b((int)((long)2046320105 ^ (long)-2046310189), (int)((long)-1462602879 ^ (long)-1462621919)) /* "Storage ESP" */, 7T.b((int)((long)1931712865 ^ (long)-1931735944), (int)((long)-426063688 ^ (long)426075625)) /* "Draws boxes around storage containers" */);
        Comparable<Boolean> comparable = Boolean.TRUE;
        34J j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)-1372683811 ^ (long)1372656882), (int)((long)1994044401 ^ (long)1994039982)) /* "Chest" */)).7(7T.b((int)((long)861509268 ^ (long)-861535341), (int)((long)-1984559205 ^ (long)-1984537589)) /* "chest" */)).1(7T.b((int)((long)-369548822 ^ (long)369538301), (int)((long)585932239 ^ (long)-585927760)) /* "Highlight Chests" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)-1372683811 ^ (long)1372656882), (int)((long)1994044401 ^ (long)1994039982)) /* "Chest" */)).7(7T.b((int)((long)861509268 ^ (long)-861535341), (int)((long)-1984559205 ^ (long)-1984537589)) /* "chest" */)).1(7T.b((int)((long)-369548822 ^ (long)369538301), (int)((long)585932239 ^ (long)-585927760)) /* "Highlight Chests" */)).7 = comparable;
        this.5f = (1P)j2.5();
        comparable = Color.fromHex((int)((int)((long)-666116654 ^ (long)662236845)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)-1142359625 ^ (long)1142385821), (int)((long)190597678 ^ (long)190611133)))).7(7T.b((int)((long)655588129 ^ (long)-655561195), (int)((long)1950994341 ^ (long)1950999091)) /* "color" */)).1(7T.b((int)((long)907286059 ^ (long)-907312344), (int)((long)-231436251 ^ (long)-231435550)) /* "The highlight color" */);
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)-1142359625 ^ (long)1142385821), (int)((long)190597678 ^ (long)190611133)))).7(7T.b((int)((long)655588129 ^ (long)-655561195), (int)((long)1950994341 ^ (long)1950999091)) /* "color" */)).1(7T.b((int)((long)907286059 ^ (long)-907312344), (int)((long)-231436251 ^ (long)-231435550)) /* "The highlight color" */)).7 = comparable;
        this.5p = (1R)((34E)((34E)j2).3(this.5f)).5();
        comparable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)1579692889 ^ (long)-1579702712), (int)((long)1618212488 ^ (long)1618208670)) /* "Ignore Dungeons" */)).7(7T.b((int)((long)-1280876115 ^ (long)1280898224), (int)((long)-1842750536 ^ (long)-1842753150)) /* "dungeons" */)).1(7T.b((int)((long)-874794183 ^ (long)874784312), (int)((long)-472812598 ^ (long)472818005)) /* "Don't highlight chests that are near mob spawners" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)1579692889 ^ (long)-1579702712), (int)((long)1618212488 ^ (long)1618208670)) /* "Ignore Dungeons" */)).7(7T.b((int)((long)-1280876115 ^ (long)1280898224), (int)((long)-1842750536 ^ (long)-1842753150)) /* "dungeons" */)).1(7T.b((int)((long)-874794183 ^ (long)874784312), (int)((long)-472812598 ^ (long)472818005)) /* "Don't highlight chests that are near mob spawners" */)).7 = comparable;
        this.5K = (1P)((34X)j2.3(this.5f)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)1653470898 ^ (long)-1653447791), (int)((long)1804485695 ^ (long)-1804496777)) /* "Trapped Chest" */)).7(7T.b((int)((long)-1240613594 ^ (long)1240606768), (int)((long)-12251281 ^ (long)-12237416)) /* "chestTrapped" */)).1(7T.b((int)((long)1197901467 ^ (long)-1197927513), (int)((long)1697626389 ^ (long)1697638884)) /* "Highlight Trapped Chests" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)1653470898 ^ (long)-1653447791), (int)((long)1804485695 ^ (long)-1804496777)) /* "Trapped Chest" */)).7(7T.b((int)((long)-1240613594 ^ (long)1240606768), (int)((long)-12251281 ^ (long)-12237416)) /* "chestTrapped" */)).1(7T.b((int)((long)1197901467 ^ (long)-1197927513), (int)((long)1697626389 ^ (long)1697638884)) /* "Highlight Trapped Chests" */)).7 = comparable;
        this.5h = (1P)((34X)j2).5();
        comparable = Color.fromHex((int)((int)((long)-960112777 ^ (long)964092996)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)826577564 ^ (long)-826603595), (int)((long)-1153316027 ^ (long)1153305256)) /* "Color" */)).7(7T.b((int)((long)1270367622 ^ (long)-1270361927), (int)((long)-135190381 ^ (long)-135171585)))).1(7T.b((int)((long)1702846746 ^ (long)-1702824951), (int)((long)-1110222528 ^ (long)1110230576)));
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)826577564 ^ (long)-826603595), (int)((long)-1153316027 ^ (long)1153305256)) /* "Color" */)).7(7T.b((int)((long)1270367622 ^ (long)-1270361927), (int)((long)-135190381 ^ (long)-135171585)))).1(7T.b((int)((long)1702846746 ^ (long)-1702824951), (int)((long)-1110222528 ^ (long)1110230576)))).7 = comparable;
        this.52 = (1R)((34E)((34E)j2).3(this.5h)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)-1797389478 ^ (long)1797363311), (int)((long)1569390743 ^ (long)-1569417604)) /* "Ender Chest" */)).7(7T.b((int)((long)-472343907 ^ (long)472321981), (int)((long)-1608733833 ^ (long)1608721337)) /* "chestEnder" */)).1(7T.b((int)((long)1305871335 ^ (long)-1305897229), (int)((long)-373821374 ^ (long)373829541)) /* "Highlight Ender Chests" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)-1797389478 ^ (long)1797363311), (int)((long)1569390743 ^ (long)-1569417604)) /* "Ender Chest" */)).7(7T.b((int)((long)-472343907 ^ (long)472321981), (int)((long)-1608733833 ^ (long)1608721337)) /* "chestEnder" */)).1(7T.b((int)((long)1305871335 ^ (long)-1305897229), (int)((long)-373821374 ^ (long)373829541)) /* "Highlight Ender Chests" */)).7 = comparable;
        this.5z = (1P)((34X)j2).5();
        comparable = Color.fromHex((int)((int)((long)750270184 ^ (long)-754239977)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)1569894612 ^ (long)-1569905155), (int)((long)1606157821 ^ (long)-1606171632)) /* "Color" */)).7(7T.b((int)((long)1707651017 ^ (long)-1707656458), (int)((long)-2047960712 ^ (long)-2047950828)))).1(7T.b((int)((long)1794531414 ^ (long)-1794509499), (int)((long)-1040765073 ^ (long)1040756767)));
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)1569894612 ^ (long)-1569905155), (int)((long)1606157821 ^ (long)-1606171632)) /* "Color" */)).7(7T.b((int)((long)1707651017 ^ (long)-1707656458), (int)((long)-2047960712 ^ (long)-2047950828)))).1(7T.b((int)((long)1794531414 ^ (long)-1794509499), (int)((long)-1040765073 ^ (long)1040756767)))).7 = comparable;
        this.5X = (1R)((34E)((34E)j2).3(this.5z)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)-2093820836 ^ (long)2093826401), (int)((long)1404990857 ^ (long)1404982057)) /* "Dispenser" */)).7(7T.b((int)((long)1789137149 ^ (long)-1789164082), (int)((long)-852782665 ^ (long)-852758503)) /* "dispenser" */)).1(7T.b((int)((long)-388517494 ^ (long)388506770), (int)((long)-1411935692 ^ (long)-1411936664)) /* "Highlight Dispensers" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)-2093820836 ^ (long)2093826401), (int)((long)1404990857 ^ (long)1404982057)) /* "Dispenser" */)).7(7T.b((int)((long)1789137149 ^ (long)-1789164082), (int)((long)-852782665 ^ (long)-852758503)) /* "dispenser" */)).1(7T.b((int)((long)-388517494 ^ (long)388506770), (int)((long)-1411935692 ^ (long)-1411936664)) /* "Highlight Dispensers" */)).7 = comparable;
        this.5N = (1P)((34X)j2).5();
        comparable = Color.fromHex((int)((int)((long)1314208301 ^ (long)-1324392329)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)922982674 ^ (long)-923005893), (int)((long)900210168 ^ (long)-900211691)) /* "Color" */)).7(7T.b((int)((long)-1735563020 ^ (long)1735589323), (int)((long)1268754526 ^ (long)1268773170)))).1(7T.b((int)((long)1005024334 ^ (long)-1005002403), (int)((long)613832535 ^ (long)-613824473)));
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)922982674 ^ (long)-923005893), (int)((long)900210168 ^ (long)-900211691)) /* "Color" */)).7(7T.b((int)((long)-1735563020 ^ (long)1735589323), (int)((long)1268754526 ^ (long)1268773170)))).1(7T.b((int)((long)1005024334 ^ (long)-1005002403), (int)((long)613832535 ^ (long)-613824473)))).7 = comparable;
        this.5Z = (1R)((34E)((34E)j2).3(this.5N)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)-1559777986 ^ (long)1559771157), (int)((long)-616742375 ^ (long)-616746573)) /* "Furnace" */)).7(7T.b((int)((long)185120860 ^ (long)-185127580), (int)((long)524353542 ^ (long)-524377885)) /* "furnace" */)).1(7T.b((int)((long)-1191254731 ^ (long)1191276576), (int)((long)-525092570 ^ (long)525093743)) /* "Highlight Furnaces" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)-1559777986 ^ (long)1559771157), (int)((long)-616742375 ^ (long)-616746573)) /* "Furnace" */)).7(7T.b((int)((long)185120860 ^ (long)-185127580), (int)((long)524353542 ^ (long)-524377885)) /* "furnace" */)).1(7T.b((int)((long)-1191254731 ^ (long)1191276576), (int)((long)-525092570 ^ (long)525093743)) /* "Highlight Furnaces" */)).7 = comparable;
        this.8 = (1P)((34X)j2).5();
        comparable = Color.fromHex((int)((int)((long)271612008 ^ (long)-278257102)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)1018206 ^ (long)-1041289), (int)((long)1130679088 ^ (long)-1130689827)) /* "Color" */)).7(7T.b((int)((long)-815158923 ^ (long)815152202), (int)((long)-1938884700 ^ (long)-1938903352)))).1(7T.b((int)((long)503591278 ^ (long)-503602051), (int)((long)-1852387583 ^ (long)1852395633)));
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)1018206 ^ (long)-1041289), (int)((long)1130679088 ^ (long)-1130689827)) /* "Color" */)).7(7T.b((int)((long)-815158923 ^ (long)815152202), (int)((long)-1938884700 ^ (long)-1938903352)))).1(7T.b((int)((long)503591278 ^ (long)-503602051), (int)((long)-1852387583 ^ (long)1852395633)))).7 = comparable;
        this.5x = (1R)((34E)((34E)j2).3(this.8)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)-1944242903 ^ (long)1944231960), (int)((long)340141496 ^ (long)-340152436)) /* "Hopper" */)).7(7T.b((int)((long)241612927 ^ (long)-241619624), (int)((long)-960034708 ^ (long)-960015776)) /* "hopper" */)).1(7T.b((int)((long)941445834 ^ (long)-941438979), (int)((long)759983475 ^ (long)-759957435)) /* "Highlight Hoppers" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)-1944242903 ^ (long)1944231960), (int)((long)340141496 ^ (long)-340152436)) /* "Hopper" */)).7(7T.b((int)((long)241612927 ^ (long)-241619624), (int)((long)-960034708 ^ (long)-960015776)) /* "hopper" */)).1(7T.b((int)((long)941445834 ^ (long)-941438979), (int)((long)759983475 ^ (long)-759957435)) /* "Highlight Hoppers" */)).7 = comparable;
        this.5 = (1P)((34X)j2).5();
        comparable = Color.fromHex((int)((int)((long)538805991 ^ (long)-548938563)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)-62643696 ^ (long)62633785), (int)((long)-993588384 ^ (long)993577613)) /* "Color" */)).7(7T.b((int)((long)-263626647 ^ (long)263648598), (int)((long)920480073 ^ (long)920465445)))).1(7T.b((int)((long)1582884740 ^ (long)-1582861673), (int)((long)1727567196 ^ (long)-1727591892)));
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)-62643696 ^ (long)62633785), (int)((long)-993588384 ^ (long)993577613)) /* "Color" */)).7(7T.b((int)((long)-263626647 ^ (long)263648598), (int)((long)920480073 ^ (long)920465445)))).1(7T.b((int)((long)1582884740 ^ (long)-1582861673), (int)((long)1727567196 ^ (long)-1727591892)))).7 = comparable;
        this.5G = (1R)((34E)((34E)j2).3(this.5)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)762686468 ^ (long)-762693354), (int)((long)-2077119232 ^ (long)2077123817)) /* "Shulker Box" */)).7(7T.b((int)((long)147878691 ^ (long)-147855816), (int)((long)1797261794 ^ (long)-1797264012)) /* "shulkerBox" */)).1(7T.b((int)((long)1624740911 ^ (long)-1624768208), (int)((long)699992237 ^ (long)700002675)) /* "Highlight Shulker Boxes" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)762686468 ^ (long)-762693354), (int)((long)-2077119232 ^ (long)2077123817)) /* "Shulker Box" */)).7(7T.b((int)((long)147878691 ^ (long)-147855816), (int)((long)1797261794 ^ (long)-1797264012)) /* "shulkerBox" */)).1(7T.b((int)((long)1624740911 ^ (long)-1624768208), (int)((long)699992237 ^ (long)700002675)) /* "Highlight Shulker Boxes" */)).7 = comparable;
        this.59 = (1P)((34X)j2).5();
        comparable = Color.fromHex((int)((int)((long)-1726588760 ^ (long)1723402438)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)1562681481 ^ (long)-1562692192), (int)((long)947149213 ^ (long)-947152784)) /* "Color" */)).7(7T.b((int)((long)-175058165 ^ (long)175064628), (int)((long)1469308621 ^ (long)1469286305)))).1(7T.b((int)((long)-945838316 ^ (long)945828359), (int)((long)-741415506 ^ (long)741440222)));
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)1562681481 ^ (long)-1562692192), (int)((long)947149213 ^ (long)-947152784)) /* "Color" */)).7(7T.b((int)((long)-175058165 ^ (long)175064628), (int)((long)1469308621 ^ (long)1469286305)))).1(7T.b((int)((long)-945838316 ^ (long)945828359), (int)((long)-741415506 ^ (long)741440222)))).7 = comparable;
        this.4 = (1R)((34E)((34E)j2).3(this.59)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)-1359162837 ^ (long)1359169326), (int)((long)-1229049097 ^ (long)-1229041939)) /* "Minecart Chest" */)).7(7T.b((int)((long)-90494186 ^ (long)90488376), (int)((long)-1427879145 ^ (long)-1427887984)) /* "minecartChest" */)).1(7T.b((int)((long)-1176848228 ^ (long)1176841612), (int)((long)-470558543 ^ (long)-470571007)) /* "Highlight Minecart Chests" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)-1359162837 ^ (long)1359169326), (int)((long)-1229049097 ^ (long)-1229041939)) /* "Minecart Chest" */)).7(7T.b((int)((long)-90494186 ^ (long)90488376), (int)((long)-1427879145 ^ (long)-1427887984)) /* "minecartChest" */)).1(7T.b((int)((long)-1176848228 ^ (long)1176841612), (int)((long)-470558543 ^ (long)-470571007)) /* "Highlight Minecart Chests" */)).7 = comparable;
        this.5B = (1P)((34X)j2).5();
        comparable = Color.fromHex((int)((int)((long)-1150432286 ^ (long)1147074717)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)1133921967 ^ (long)-1133915258), (int)((long)-530177842 ^ (long)530178339)) /* "Color" */)).7(7T.b((int)((long)1633021386 ^ (long)-1632995083), (int)((long)-17295871 ^ (long)-17281171)))).1(7T.b((int)((long)1330275621 ^ (long)-1330253770), (int)((long)-2039791301 ^ (long)2039799371)));
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)1133921967 ^ (long)-1133915258), (int)((long)-530177842 ^ (long)530178339)) /* "Color" */)).7(7T.b((int)((long)1633021386 ^ (long)-1632995083), (int)((long)-17295871 ^ (long)-17281171)))).1(7T.b((int)((long)1330275621 ^ (long)-1330253770), (int)((long)-2039791301 ^ (long)2039799371)))).7 = comparable;
        this.5d = (1R)((34E)((34E)j2).3(this.5B)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)331074437 ^ (long)-331063635), (int)((long)-161076045 ^ (long)161082624)) /* "Minecart Furnace" */)).7(7T.b((int)((long)-90431273 ^ (long)90420693), (int)((long)-1680622424 ^ (long)-1680631464)) /* "minecartFurnace" */)).1(7T.b((int)((long)1616542638 ^ (long)-1616515426), (int)((long)1624844774 ^ (long)-1624845694)) /* "Highlight Minecart Furnaces" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)331074437 ^ (long)-331063635), (int)((long)-161076045 ^ (long)161082624)) /* "Minecart Furnace" */)).7(7T.b((int)((long)-90431273 ^ (long)90420693), (int)((long)-1680622424 ^ (long)-1680631464)) /* "minecartFurnace" */)).1(7T.b((int)((long)1616542638 ^ (long)-1616515426), (int)((long)1624844774 ^ (long)-1624845694)) /* "Highlight Minecart Furnaces" */)).7 = comparable;
        this.7 = (1P)((34X)j2).5();
        comparable = Color.fromHex((int)((int)((long)-1961366807 ^ (long)1951248563)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)-2042822152 ^ (long)2042795217), (int)((long)1191749934 ^ (long)-1191745341)) /* "Color" */)).7(7T.b((int)((long)-285299323 ^ (long)285292730), (int)((long)-753044456 ^ (long)-753062540)))).1(7T.b((int)((long)-2103273206 ^ (long)2103249945), (int)((long)264995397 ^ (long)-265020107)));
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)-2042822152 ^ (long)2042795217), (int)((long)1191749934 ^ (long)-1191745341)) /* "Color" */)).7(7T.b((int)((long)-285299323 ^ (long)285292730), (int)((long)-753044456 ^ (long)-753062540)))).1(7T.b((int)((long)-2103273206 ^ (long)2103249945), (int)((long)264995397 ^ (long)-265020107)))).7 = comparable;
        this.5R = (1R)((34E)((34E)j2).3(this.7)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)1959285061 ^ (long)-1959279549), (int)((long)-466036972 ^ (long)466040693)) /* "Minecart Hopper" */)).7(7T.b((int)((long)1000952031 ^ (long)-1000946202), (int)((long)-2066210284 ^ (long)2066199132)) /* "minecartHopper" */)).1(7T.b((int)((long)-808023956 ^ (long)808000850), (int)((long)-1333557743 ^ (long)1333532528)) /* "Highlight Minecart Hoppers" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)1959285061 ^ (long)-1959279549), (int)((long)-466036972 ^ (long)466040693)) /* "Minecart Hopper" */)).7(7T.b((int)((long)1000952031 ^ (long)-1000946202), (int)((long)-2066210284 ^ (long)2066199132)) /* "minecartHopper" */)).1(7T.b((int)((long)-808023956 ^ (long)808000850), (int)((long)-1333557743 ^ (long)1333532528)) /* "Highlight Minecart Hoppers" */)).7 = comparable;
        this.5a = (1P)((34X)j2).5();
        comparable = Color.fromHex((int)((int)((long)-464040974 ^ (long)453841320)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)-1034818119 ^ (long)1034844304), (int)((long)325347481 ^ (long)-325342860)) /* "Color" */)).7(7T.b((int)((long)-1723578265 ^ (long)1723587928), (int)((long)-1717478460 ^ (long)-1717501272)))).1(7T.b((int)((long)-756994597 ^ (long)756988104), (int)((long)223576588 ^ (long)-223601284)));
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)-1034818119 ^ (long)1034844304), (int)((long)325347481 ^ (long)-325342860)) /* "Color" */)).7(7T.b((int)((long)-1723578265 ^ (long)1723587928), (int)((long)-1717478460 ^ (long)-1717501272)))).1(7T.b((int)((long)-756994597 ^ (long)756988104), (int)((long)223576588 ^ (long)-223601284)))).7 = comparable;
        this.5M = (1R)((34E)((34E)j2).3(this.5a)).5();
        comparable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)-2045266631 ^ (long)2045255682), (int)((long)1032662825 ^ (long)-1032663678)) /* "Item Frame" */)).7(7T.b((int)((long)-344767407 ^ (long)344772979), (int)((long)526755066 ^ (long)526774389)) /* "itemFrame" */)).1(7T.b((int)((long)1383212368 ^ (long)-1383223172), (int)((long)-946653930 ^ (long)-946634803)) /* "Highlight Item Frames" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)-2045266631 ^ (long)2045255682), (int)((long)1032662825 ^ (long)-1032663678)) /* "Item Frame" */)).7(7T.b((int)((long)-344767407 ^ (long)344772979), (int)((long)526755066 ^ (long)526774389)) /* "itemFrame" */)).1(7T.b((int)((long)1383212368 ^ (long)-1383223172), (int)((long)-946653930 ^ (long)-946634803)) /* "Highlight Item Frames" */)).7 = comparable;
        this.9 = (1P)((34X)j2).5();
        comparable = Color.fromHex((int)((int)((long)667402699 ^ (long)-670343513)));
        j2 = (34E)((34E)((34E)this.0().5(7T.b((int)((long)1514720983 ^ (long)-1514710018), (int)((long)1160779445 ^ (long)-1160784040)) /* "Color" */)).7(7T.b((int)((long)-652163453 ^ (long)652170172), (int)((long)-2114271516 ^ (long)-2114281592)))).1(7T.b((int)((long)-1578966460 ^ (long)1578989399), (int)((long)599292606 ^ (long)-599267890)));
        ((34E)((34E)((34E)this.0().5(7T.b((int)((long)1514720983 ^ (long)-1514710018), (int)((long)1160779445 ^ (long)-1160784040)) /* "Color" */)).7(7T.b((int)((long)-652163453 ^ (long)652170172), (int)((long)-2114271516 ^ (long)-2114281592)))).1(7T.b((int)((long)-1578966460 ^ (long)1578989399), (int)((long)599292606 ^ (long)-599267890)))).7 = comparable;
        this.5g = (1R)((34E)((34E)j2).3(this.9)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)-2051197516 ^ (long)2051186862), (int)((long)-2031801406 ^ (long)-2031791661)) /* "Has Item" */)).7(7T.b((int)((long)1853948578 ^ (long)-1853974640), (int)((long)1322109572 ^ (long)-1322118485)) /* "hasItem" */)).1(7T.b((int)((long)-1770127628 ^ (long)1770154996), (int)((long)1076580545 ^ (long)-1076583150)) /* "Only highlight the frame if it contains an item" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)-2051197516 ^ (long)2051186862), (int)((long)-2031801406 ^ (long)-2031791661)) /* "Has Item" */)).7(7T.b((int)((long)1853948578 ^ (long)-1853974640), (int)((long)1322109572 ^ (long)-1322118485)) /* "hasItem" */)).1(7T.b((int)((long)-1770127628 ^ (long)1770154996), (int)((long)1076580545 ^ (long)-1076583150)) /* "Only highlight the frame if it contains an item" */)).7 = comparable;
        this.6 = (1P)((34X)((34X)j2).3(this.9)).5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7T.b((int)((long)-1719068100 ^ (long)1719045920), (int)((long)-1233489363 ^ (long)1233517150)) /* "Fade" */)).7(7T.b((int)((long)-1806143043 ^ (long)1806165145), (int)((long)1752775179 ^ (long)-1752783820)) /* "fade" */)).1(7T.b((int)((long)1921461888 ^ (long)-1921467516), (int)((long)-525101822 ^ (long)525077145)) /* "Makes the esp box fade depending on distance" */);
        ((34X)((34X)((34X)this.4().5(7T.b((int)((long)-1719068100 ^ (long)1719045920), (int)((long)-1233489363 ^ (long)1233517150)) /* "Fade" */)).7(7T.b((int)((long)-1806143043 ^ (long)1806165145), (int)((long)1752775179 ^ (long)-1752783820)) /* "fade" */)).1(7T.b((int)((long)1921461888 ^ (long)-1921467516), (int)((long)-525101822 ^ (long)525077145)) /* "Makes the esp box fade depending on distance" */)).7 = comparable;
        this.5U = (1P)((34X)j2).5();
        comparable = 20.0;
        j2 = ((34e)((34e)((34e)this.7().5(7T.b((int)((long)-334714218 ^ (long)334708656), (int)((long)425504508 ^ (long)425498846)) /* "Fade Distance" */)).7(7T.b((int)((long)-173410499 ^ (long)173433368), (int)((long)-1054985929 ^ (long)1054975445)) /* "distance" */)).1(7T.b((int)((long)702307019 ^ (long)-702296086), (int)((long)1719844499 ^ (long)-1719837220)) /* "Distance that the fade starts at" */)).3(5.0).2(30.0);
        ((34e)((34e)((34e)this.7().5(7T.b((int)((long)-334714218 ^ (long)334708656), (int)((long)425504508 ^ (long)425498846)) /* "Fade Distance" */)).7(7T.b((int)((long)-173410499 ^ (long)173433368), (int)((long)-1054985929 ^ (long)1054975445)) /* "distance" */)).1(7T.b((int)((long)702307019 ^ (long)-702296086), (int)((long)1719844499 ^ (long)-1719837220)) /* "Distance that the fade starts at" */)).3(5.0).2(30.0).7 = comparable;
        this.2 = (1K)((34e)j2).5();
        comparable = Float.valueOf(1.0f);
        j2 = ((34e)((34e)((34e)this.9().5(7T.b((int)((long)827339376 ^ (long)-827349155), (int)((long)-1885125871 ^ (long)-1885128847)) /* "Line Width" */)).7(7T.b((int)((long)-937910290 ^ (long)937888496), (int)((long)-248432939 ^ (long)-248420804)) /* "width" */)).1(7T.b((int)((long)1146423500 ^ (long)-1146446342), (int)((long)1067704251 ^ (long)-1067711374)) /* "Outline line width for the Box" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(3.0f));
        ((34e)((34e)((34e)this.9().5(7T.b((int)((long)827339376 ^ (long)-827349155), (int)((long)-1885125871 ^ (long)-1885128847)) /* "Line Width" */)).7(7T.b((int)((long)-937910290 ^ (long)937888496), (int)((long)-248432939 ^ (long)-248420804)) /* "width" */)).1(7T.b((int)((long)1146423500 ^ (long)-1146446342), (int)((long)1067704251 ^ (long)-1067711374)) /* "Outline line width for the Box" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(3.0f)).7 = comparable;
        this.1 = (1A)((34e)j2).5();
        this.5t = new Listener(o -> {
            block3: {
                block2: {
                    boolean bl = \u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
                    if (bl || bl) break block2;
                    2c c2 = (2c)3.ac();
                    if (bl || bl) break block2;
                    7T.3.r.j.stream().filter(ccj::n).forEach(arg_0 -> this.5(c2, arg_0));
                    if (bl || bl) break block2;
                    7T.3.r.b().forEach(aqa2 -> {
                        Optional<Object> optional;
                        block17: {
                            7T t;
                            aqa aqa3;
                            block15: {
                                block16: {
                                    block14: {
                                        boolean bl = \u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
                                        if (bl || bl) break block14;
                                        aqa3 = aqa2;
                                        t = this;
                                        if (bl || bl) break block14;
                                        if (!(aqa3 instanceof bhq)) break block15;
                                        if (bl || bl) break block14;
                                        if (!t.5B.2) break block15;
                                        if (!bl && !bl) break block16;
                                    }
                                    return;
                                }
                                optional = Optional.of(t.5d.2);
                                if (\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                                    throw null;
                                }
                                break block17;
                            }
                            if (aqa3 instanceof bht && t.5a.2) {
                                optional = Optional.of(t.5M.2);
                                if (\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                                    throw null;
                                }
                            } else if (aqa3 instanceof bhs && t.7.2) {
                                optional = Optional.of(t.5R.2);
                                if (\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                                    throw null;
                                }
                            } else if (aqa3 instanceof bcp && t.9.2) {
                                optional = Optional.of(t.5g.2);
                                if (\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                                    throw null;
                                }
                            } else {
                                optional = Optional.empty();
                            }
                        }
                        optional.map(Color::getHex).ifPresent(object2 -> {
                            boolean bl = \u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
                            if (bl || bl) return;
                            dci dci2 = null;
                            if (bl) return;
                            if (bl) return;
                            if (aqa2 instanceof bhq) {
                                if (bl || bl) return;
                                dci2 = 0;
                                if (bl) return;
                            }
                            if (bl) return;
                            if (aqa2 instanceof bht) {
                                if (bl || bl) return;
                                dci2 = 5_;
                                if (bl) return;
                            }
                            if (bl) return;
                            if (aqa2 instanceof bhs) {
                                if (bl || bl) return;
                                dci2 = 5H;
                                if (bl) return;
                            }
                            if (bl) return;
                            if (aqa2 instanceof bcp) {
                                if (bl || bl) return;
                                dci2 = aqa2.cc().d(-aqa2.cD(), -aqa2.cE(), -aqa2.cH());
                                if (bl || bl) return;
                                bcp bcp2 = (bcp)aqa2;
                                if (bl || bl) return;
                                if (this.6.2) {
                                    if (bl) return;
                                    if (bcp2.o().a()) {
                                        if (bl || bl) return;
                                        return;
                                    }
                                }
                            }
                            if (bl) return;
                            if (dci2 == null) {
                                if (bl || bl) return;
                                return;
                            }
                            if (bl) return;
                            double d2 = 3.aa().g(aqa2);
                            if (bl || bl) return;
                            object2 = 34L.5((Integer)object2);
                            if (bl || bl) return;
                            float f = this.5(90.0f, d2) / 255.0f;
                            if (bl || bl) return;
                            float f2 = this.5(255.0f, d2) / 255.0f;
                            if (bl || bl) return;
                            o = 94.8(aqa2, ((2_)o).3());
                            double d3 = ((8S)object).9;
                            if (bl || bl) return;
                            double d4 = ((8S)object).1;
                            if (bl || bl) return;
                            double d5 = ((8S)object).2;
                            if (bl || bl) return;
                            dci2 = dci2.d(d3, d4, d5);
                            if (bl || bl) return;
                            RenderSystem.pushMatrix();
                            if (bl || bl) return;
                            float f3 = -aqa2.p;
                            if (bl || bl) return;
                            if (aqa2 instanceof bcp) {
                                if (bl || bl) return;
                                f3 = 0.0f;
                                if (bl) return;
                            }
                            if (bl) return;
                            net.impactclient.5K.8(f3, d3, d4, d5);
                            if (bl || bl) return;
                            2n.8(dci2, 34L.0((float)object2[(int)((long)1016751174 ^ (long)1016751174)], (float)object2[(int)((long)1445991724 ^ (long)1445991725)], (float)object2[(int)((long)734573262 ^ (long)734573260)], f));
                            if (bl || bl) return;
                            2n.3(dci2, 34L.0((float)object2[(int)((long)-400954920 ^ (long)-400954920)], (float)object2[(int)((long)1351114827 ^ (long)1351114826)], (float)object2[(int)((long)-1438060806 ^ (long)-1438060808)], f2), 1.0f);
                            if (bl || bl) return;
                            RenderSystem.popMatrix();
                            if (!bl && !bl) return;
                        });
                    });
                    if (bl || bl) break block2;
                    net.impactclient.5K.6((int)((long)58324059 ^ (long)-58324060));
                    if (!bl && !bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)-1157513155 ^ (long)-1157513155)]);
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)846715947 ^ (long)-846706404)) & (int)((long)1366777440 ^ (long)1366794655);
            if (var9_2) ** GOTO lbl-1000
            if (7T.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7T.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)984746828 ^ (long)984746828)] & (int)((long)168902131 ^ (long)168901900)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1462221609 ^ (long)-1462221717);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)212474419 ^ (long)212474453);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1628026411 ^ (long)-1628026425);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1553374051 ^ (long)1553374160);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)424268991 ^ (long)424269052);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-70041322 ^ (long)-70041253);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1879647558 ^ (long)-1879647561);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1235158511 ^ (long)1235158405);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1461871591 ^ (long)1461871491);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1166973733 ^ (long)1166973949);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1228588205 ^ (long)1228588248);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)782201256 ^ (long)782201249);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1563635825 ^ (long)-1563635750);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1240472160 ^ (long)-1240472214);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1875802160 ^ (long)-1875802117);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1543822809 ^ (long)-1543822596);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1441131507 ^ (long)-1441131363);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1332933937 ^ (long)1332934118);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)2105732037 ^ (long)2105732056);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1811995821 ^ (long)1811995729);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1093258896 ^ (long)-1093258856);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)515836973 ^ (long)515837172);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-375170393 ^ (long)-375170480);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)565151357 ^ (long)565151457);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1493186718 ^ (long)-1493186786);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1344642077 ^ (long)-1344642184);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-379980007 ^ (long)-379979835);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)808386694 ^ (long)808386767);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1389022175 ^ (long)1389022201);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1193399248 ^ (long)1193399269);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-986524739 ^ (long)-986524842);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1898205232 ^ (long)1898205267);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1936176629 ^ (long)1936176398);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-2007669070 ^ (long)-2007669119);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1227875324 ^ (long)-1227875094);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1125280241 ^ (long)1125280083);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-285667594 ^ (long)-285667792);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)638209482 ^ (long)638209511);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-717983471 ^ (long)-717983401);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1930213830 ^ (long)1930213874);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1156579665 ^ (long)-1156579732);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)513720052 ^ (long)513719867);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1986128024 ^ (long)1986128060);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1163601682 ^ (long)-1163601684);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)564277122 ^ (long)564277099);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1674965622 ^ (long)-1674965741);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)451210713 ^ (long)451210693);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1026724647 ^ (long)-1026724718);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-2136471474 ^ (long)-2136471426);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1029369864 ^ (long)1029369996);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-724754677 ^ (long)-724754675);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-430610632 ^ (long)-430610610);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)523029540 ^ (long)523029626);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)116425020 ^ (long)116424961);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)453069280 ^ (long)453069303);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1089898518 ^ (long)1089898560);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1262355997 ^ (long)-1262356105);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1953230134 ^ (long)1953230287);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1835286967 ^ (long)-1835286901);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1773852747 ^ (long)1773852743);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)285096915 ^ (long)285096773);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1773263761 ^ (long)-1773263771);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-476945903 ^ (long)-476945749);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1069313609 ^ (long)-1069313588);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1490103996 ^ (long)1490104015);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1913671617 ^ (long)-1913671561);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1416060158 ^ (long)-1416060141);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)507201892 ^ (long)507201960);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1702941514 ^ (long)-1702941690);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1110894339 ^ (long)-1110894364);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1448279586 ^ (long)1448279728);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1142019370 ^ (long)1142019447);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1814626029 ^ (long)-1814625938);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)2048548533 ^ (long)2048548427);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-2130669454 ^ (long)-2130669440);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1291794478 ^ (long)-1291794568);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)569741812 ^ (long)569741747);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1275070339 ^ (long)1275070457);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1128890856 ^ (long)-1128890681);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1632003039 ^ (long)1632003020);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-498863309 ^ (long)-498863299);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1925676405 ^ (long)-1925676494);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1880243931 ^ (long)-1880243721);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)642101846 ^ (long)642101767);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1235302350 ^ (long)1235302246);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1899462931 ^ (long)-1899462956);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)546660644 ^ (long)546660836);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1398053498 ^ (long)1398053589);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-410821391 ^ (long)-410821600);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1128975711 ^ (long)-1128975682);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1302282336 ^ (long)1302282435);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-92924393 ^ (long)-92924331);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1303576059 ^ (long)-1303575920);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1856592918 ^ (long)-1856592968);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-372157805 ^ (long)-372157900);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1020459158 ^ (long)1020459192);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-323121705 ^ (long)-323121685);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-502945273 ^ (long)-502945037);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1321361025 ^ (long)-1321360928);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-138399304 ^ (long)-138399376);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)851713807 ^ (long)851713972);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1950271665 ^ (long)1950271695);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)490200049 ^ (long)490199851);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)307757701 ^ (long)307757700);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-939907646 ^ (long)-939907818);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)293157853 ^ (long)293157718);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-2031173560 ^ (long)-2031173378);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-447484582 ^ (long)-447484669);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1278637185 ^ (long)1278637179);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1411090507 ^ (long)1411090641);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-568228966 ^ (long)-568229077);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-2134850860 ^ (long)-2134850973);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)627198701 ^ (long)627198567);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1255715421 ^ (long)1255715375);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-2126490645 ^ (long)-2126490778);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1273921860 ^ (long)-1273922046);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1817989229 ^ (long)1817989124);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-94594941 ^ (long)-94594954);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1582335445 ^ (long)-1582335242);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1781919164 ^ (long)1781919039);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-979206147 ^ (long)-979206150);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-399379451 ^ (long)-399379343);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1027008860 ^ (long)1027009017);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1879695572 ^ (long)1879695554);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)183018824 ^ (long)183018921);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)618866647 ^ (long)618866679);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-912364093 ^ (long)-912364190);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-2077161395 ^ (long)-2077161299);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1118500464 ^ (long)-1118500607);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1969597942 ^ (long)-1969597871);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1368395678 ^ (long)-1368395709);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1139763920 ^ (long)-1139763936);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1607022404 ^ (long)1607022416);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-335352636 ^ (long)-335352677);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-524389376 ^ (long)-524389322);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)610648109 ^ (long)610648210);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1815307484 ^ (long)1815307411);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-164910778 ^ (long)-164910775);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1686122506 ^ (long)-1686122633);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1169806603 ^ (long)-1169806702);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1933257297 ^ (long)-1933257250);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1261918138 ^ (long)-1261918180);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1143490336 ^ (long)-1143490350);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1386958037 ^ (long)1386957854);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-903049670 ^ (long)-903049671);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1801545557 ^ (long)-1801545525);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1546760776 ^ (long)1546760918);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1554328773 ^ (long)1554328677);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)982273636 ^ (long)982273771);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1069504395 ^ (long)1069504326);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1022528256 ^ (long)-1022528214);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1382175877 ^ (long)1382175757);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)874482742 ^ (long)874482868);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1168249090 ^ (long)-1168249170);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1685814159 ^ (long)-1685814172);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1266925077 ^ (long)-1266925099);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)2079125950 ^ (long)2079125997);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1720687702 ^ (long)-1720687796);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1692827687 ^ (long)1692827892);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)657044311 ^ (long)657044411);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1509464430 ^ (long)1509464432);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)313795782 ^ (long)313795766);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1708798097 ^ (long)-1708798105);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-123271957 ^ (long)-123272045);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1224775446 ^ (long)-1224775578);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1462491174 ^ (long)-1462491163);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1495642365 ^ (long)1495642360);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1397727224 ^ (long)1397727014);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)785489757 ^ (long)785489820);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-338813950 ^ (long)-338813711);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1528479620 ^ (long)-1528479676);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1074176378 ^ (long)-1074176462);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)2020251917 ^ (long)2020251927);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)535421431 ^ (long)535421436);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-72333818 ^ (long)-72333752);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1924979379 ^ (long)1924979275);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)267135629 ^ (long)267135681);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1580328748 ^ (long)-1580328719);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)659671440 ^ (long)659671529);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1309397288 ^ (long)1309397405);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-706314199 ^ (long)-706314060);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1117340384 ^ (long)-1117340242);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1405009503 ^ (long)-1405009610);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-2009944508 ^ (long)-2009944343);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-304836496 ^ (long)-304836394);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-2000769866 ^ (long)-2000769966);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-250571947 ^ (long)-250571998);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1281320961 ^ (long)-1281321132);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1455946072 ^ (long)1455946041);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-67321021 ^ (long)-67320854);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-362687476 ^ (long)-362687311);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1484030575 ^ (long)-1484030477);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1246162016 ^ (long)-1246162137);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1616664704 ^ (long)-1616664603);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-105236533 ^ (long)-105236703);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1353683964 ^ (long)-1353683928);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)771252710 ^ (long)771252485);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)646977625 ^ (long)646977601);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-615161480 ^ (long)-615161458);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)941574157 ^ (long)941574217);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)56227108 ^ (long)56227078);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1791066570 ^ (long)1791066577);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1019874157 ^ (long)1019874302);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1324383712 ^ (long)-1324383665);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-259302109 ^ (long)-259302132);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1653956685 ^ (long)1653956714);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)2133766826 ^ (long)2133766728);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1904744608 ^ (long)-1904744571);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)198723894 ^ (long)198724095);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)2129960289 ^ (long)2129960420);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)576852734 ^ (long)576852627);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1632949250 ^ (long)1632949320);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-565039585 ^ (long)-565039376);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1349918676 ^ (long)1349918480);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)807398054 ^ (long)807398142);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)823350102 ^ (long)823350125);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1775671669 ^ (long)1775671728);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-992881379 ^ (long)-992881366);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1853541981 ^ (long)-1853541939);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1645939229 ^ (long)-1645939357);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1457956461 ^ (long)-1457956597);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1869362210 ^ (long)-1869362274);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-20343827 ^ (long)-20344029);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1828148526 ^ (long)1828148731);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1440510515 ^ (long)-1440510603);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)291925504 ^ (long)291925668);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-2001529395 ^ (long)-2001529473);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1688471031 ^ (long)1688470966);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1829169584 ^ (long)-1829169643);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)519703863 ^ (long)519703880);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1663090882 ^ (long)-1663090737);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1236481672 ^ (long)-1236481633);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-2137880618 ^ (long)-2137880622);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1312765475 ^ (long)1312765458);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-388315769 ^ (long)-388315903);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1191733368 ^ (long)1191733489);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-472912394 ^ (long)-472912470);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1547388531 ^ (long)1547388581);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)242514174 ^ (long)242513966);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)104087986 ^ (long)104087963);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)2969435 ^ (long)2969464);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1530683598 ^ (long)1530683554);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1219790737 ^ (long)-1219790763);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1677782570 ^ (long)-1677782741);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1989418296 ^ (long)-1989418333);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1387337934 ^ (long)1387337958);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1706196868 ^ (long)1706196972);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1106857858 ^ (long)-1106857837);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)229828534 ^ (long)229828378);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)209021655 ^ (long)209021655);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)140284464 ^ (long)140284574);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-404690164 ^ (long)-404690085);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1059136865 ^ (long)1059136821);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-854813269 ^ (long)-854813332);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)187943090 ^ (long)187942989);
                    if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-971514588 ^ (long)-971514412);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)744437170 ^ (long)744437069)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)2115171396 ^ (long)2115111867)) >>> (int)((long)1372634524 ^ (long)1372634516)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-420596366 ^ (long)-420596366);
            if (!7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)743523078 ^ (long)743523076);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1305404859 ^ (long)1305404856) | var5_6 << (int)((long)1558908935 ^ (long)1558908930)) ^ var3_4[var7_8]) & (int)((long)1779715383 ^ (long)1779715528);
                    if (7T.\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1292268384 ^ (long)-1292268381) | var6_7 << (int)((long)1912401233 ^ (long)1912401236)) ^ var3_4[var7_8]) & (int)((long)1624916733 ^ (long)1624916482);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7T.e[var2_3] = new String(var3_4).intern();
        }
        return 7T.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    private float 5(float f, double d2) {
        double d3;
        boolean bl = \u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d;
        if (bl || bl) return 0.0f;
        if (this.5U.2) {
            if (bl) return 0.0f;
            if (d2 <= this.2.1) {
                if (bl) {
                    return 0.0f;
                }
                d3 = (double)f * (d2 / this.2.1);
                if (!\u200c\u200f\u200b\u200e\u2009\u200f\u200d\u200d) return (float)d3;
                throw null;
            }
        }
        d3 = f;
        return (float)d3;
    }
}

