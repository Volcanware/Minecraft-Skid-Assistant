/* ==========================================================================
 * MODULE: Enchant Color
 * CATEGORY (inferred): Render
 * DESCRIPTION: Customize the color of enchantments
 * OBFUSCATED CLASS: net.impactclient.79
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.1R;
import net.impactclient.2w$6X;
import net.impactclient.34E;
import net.impactclient.34N;
import net.impactclient.34X;
import net.impactclient.3X;
import net.impactclient.4S;
import net.impactclient.8h;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 79
extends 3X
implements 8h {
    private static final String[] d;
    public static final boolean \u2006\u200f\u2001;
    private 1P 3;
    private 1R 9;
    @EventHandler
    private final Listener<34N> 0;
    private static final String[] e;
    private 1P 8;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 79.\u2006\u200f\u2001;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-659400121 ^ (long)-659400116)];
            if (var7) break block23;
            var3_2 = (int)((long)124168362 ^ (long)124168362);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u252b\u0c5a\u1fe8\u179f\u2537\u0c2a\u1f19\u1716\u250d\u0c76\u1f6f\u177f\u25ad\u0cc3\u1f9a\u17f1\u25f3\u0cac\u1fd4\u170e\u254a\u0c0f\u1f36\u17b3\u25ac\u0c75\u1f05\u17be\u25c1\u0c68\u1f92\u17f5\u2532\u0ccb\u1f90\u175f\u253a\u0cc0\u1f62\u17a9\u25af\u0c18\u1f13\u17ac\u253f\u0c7d\u1fd2\u17cb\u252f\u0ca5\u1fd8\u17a9\u25b6\u0cda\u1f24\u175a\u25ad\u0c76\u1f03\u1720\u25ba\u0c77\u1fb3\u1782\u2598\u0c9a\u1f32\u1717\u2555\u0c9a\u1f26\u1764\u25f5\u0cb7\u1f04\u1770\u2537\u0ca2\u1fdd\u17aa\u2531\u0c77\u1f1f\u1726\u2528\u0cca\u1f2c\u171f\u256a\u0ccf\u1f6e\u1792\u2528\u0c77\u1fc2\u1759\u25f5\u0c5f\u1fbe\u1739\u25f3\u0c8d\u1f24\u17e2\u25a9\u0cfb\u1f5d\u17c0\u2584\u0cea\u1f51\u1702\u25ac\u0c63\u1fba\u1765\u25fa\u0cd8\u1f5f\u17ec\u25f7\u0cbf\u1f9e\u17ba\u2529\u0c8b\u1f3b\u171c\u2525\u0c9d\u1f68\u17d0\u25fc\u0c97\u1fcc\u171f\u258e\u0c05\u1f94\u17b1\u255e", -1876753701);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)174247407 ^ (long)174247362);
            if (var7) break block23;
            var0_6 = (int)((long)746600107 ^ (long)-746600108);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1977602266 ^ (long)1977602199);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)928066105 ^ (long)-928066106);
                    if (79.\u2006\u200f\u2001) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!79.\u2006\u200f\u2001) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ue072\uc988\uda9a\ud29c\ue020\uc913\udaaa\ud26e\ue023\uc9e4\udaa8\ud273\ue01f\uc9fb\udaf4\ud20a\ue002\uc9b8\uda44\ud284\ue030\uc914\uda4d\ud283\ue035\uc91a\uda39\ud231\ue0af\uc9f0\udaaa\ud284\ue016\uc9ac\uda3b\ud2ef\ue0fc\uc91a\uda18\ud2f3\ue008\uc922\uda30\ud2cc\ue054\uc9ec\uda5c\ud242\ue031\uc9d5", 717801311);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)891292896 ^ (long)891292876);
                            var0_6 = (int)((long)1475590317 ^ (long)-1475590318);
                            while (true) {
                                v0 = (int)((long)-801771631 ^ (long)-801771587);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)457792754 ^ (long)457792754);
                                if (!79.\u2006\u200f\u2001) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!79.\u2006\u200f\u2001) ** continue;
                                throw null;
                            }
                            79.d = var5_1;
                            79.e = new String[(int)((long)-2051236345 ^ (long)-2051236340)];
                            if (!79.\u2006\u200f\u2001) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1822708672 ^ (long)-1822708672);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)2137058339 ^ (long)2137058338)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-323579055 ^ (long)-323579050)) {
                                case 0: {
                                    v15 = (int)((long)518864858 ^ (long)518864874);
                                    if (!79.\u2006\u200f\u2001) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)737253261 ^ (long)737253277);
                                    if (!79.\u2006\u200f\u2001) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1258382148 ^ (long)1258382192);
                                    if (!79.\u2006\u200f\u2001) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-912006139 ^ (long)-912006069);
                                    if (!79.\u2006\u200f\u2001) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)904828538 ^ (long)904828511);
                                    if (!79.\u2006\u200f\u2001) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1379947458 ^ (long)1379947502);
                                    if (!79.\u2006\u200f\u2001) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-38051859 ^ (long)-38051846);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!79.\u2006\u200f\u2001);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    public 79() {
        boolean bl = \u2006\u200f\u2001;
        super(79.b((int)((long)-1427763081 ^ (long)1427761138), (int)((long)528723203 ^ (long)528717078)) /* "Enchant Color" */, 79.b((int)((long)-728242229 ^ (long)728240202), (int)((long)433236864 ^ (long)-433231230)) /* "Customize the color of enchantments" */);
        this.9 = (1R)((34E)((34E)((34E)this.0().5(79.b((int)((long)1216081134 ^ (long)-1216079008), (int)((long)-1249844994 ^ (long)1249853502)) /* "Color" */)).7(79.b((int)((long)-1223374415 ^ (long)1223376433), (int)((long)905323849 ^ (long)905335039)) /* "color" */)).1(79.b((int)((long)-650343598 ^ (long)650345685), (int)((long)706831452 ^ (long)-706821107)) /* "The glint color" */)).5();
        Boolean bl2 = Boolean.TRUE;
        34X x2 = (34X)((34X)((34X)this.4().5(79.b((int)((long)-200687981 ^ (long)200689937), (int)((long)2035534413 ^ (long)-2035545666)) /* "Items" */)).7(79.b((int)((long)1741879915 ^ (long)-1741877784), (int)((long)766666727 ^ (long)766664616)) /* "items" */)).1(79.b((int)((long)585883807 ^ (long)-585885936), (int)((long)563369012 ^ (long)-563372499)) /* "Makes item enchantments have a rainbow color" */);
        ((34X)((34X)((34X)this.4().5(79.b((int)((long)-200687981 ^ (long)200689937), (int)((long)2035534413 ^ (long)-2035545666)) /* "Items" */)).7(79.b((int)((long)1741879915 ^ (long)-1741877784), (int)((long)766666727 ^ (long)766664616)) /* "items" */)).1(79.b((int)((long)585883807 ^ (long)-585885936), (int)((long)563369012 ^ (long)-563372499)) /* "Makes item enchantments have a rainbow color" */)).7 = bl2;
        this.3 = (1P)x2.5();
        bl2 = Boolean.TRUE;
        x2 = (34X)((34X)((34X)this.4().5(79.b((int)((long)2065277701 ^ (long)-2065279863), (int)((long)1984931854 ^ (long)1984932190)) /* "Armor" */)).7(79.b((int)((long)-490913316 ^ (long)490911320), (int)((long)1330351169 ^ (long)-1330362731)) /* "armor" */)).1(79.b((int)((long)-1646748285 ^ (long)1646750213), (int)((long)-302265544 ^ (long)-302261262)) /* "Makes armor enchantments have a rainbow color" */);
        ((34X)((34X)((34X)this.4().5(79.b((int)((long)2065277701 ^ (long)-2065279863), (int)((long)1984931854 ^ (long)1984932190)) /* "Armor" */)).7(79.b((int)((long)-490913316 ^ (long)490911320), (int)((long)1330351169 ^ (long)-1330362731)) /* "armor" */)).1(79.b((int)((long)-1646748285 ^ (long)1646750213), (int)((long)-302265544 ^ (long)-302261262)) /* "Makes armor enchantments have a rainbow color" */)).7 = bl2;
        this.8 = (1P)x2.5();
        this.0 = new Listener(n -> {
            block6: {
                block2: {
                    boolean bl;
                    block5: {
                        block4: {
                            block3: {
                                bl = \u2006\u200f\u2001;
                                if (bl || bl) break block2;
                                if (n.7 != 4S.b) break block3;
                                if (bl) break block2;
                                if (this.3.2) break block4;
                                if (bl) break block2;
                            }
                            if (bl) break block2;
                            if (n.7 != 4S.a) break block5;
                            if (bl) break block2;
                            if (!this.8.2) break block5;
                            if (bl) break block2;
                        }
                        if (bl) break block2;
                        n.1 = this.9.2.getHex();
                        if (bl) break block2;
                    }
                    if (!bl) break block6;
                }
                return;
            }
        }, new Predicate[(int)((long)-1815316458 ^ (long)-1815316458)]);
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 79.\u2006\u200f\u2001;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-38081133 ^ (long)38083093)) & (int)((long)-1549579946 ^ (long)-1549551959);
            if (var9_2) ** GOTO lbl-1000
            if (79.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 79.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)920226446 ^ (long)920226446)] & (int)((long)1936115023 ^ (long)1936115120)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1431131879 ^ (long)1431131704);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1732762776 ^ (long)-1732762842);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1103597583 ^ (long)-1103597755);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1693044282 ^ (long)-1693044454);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1069323007 ^ (long)1069322850);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1411689030 ^ (long)-1411689077);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)521433190 ^ (long)521433199);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1822435277 ^ (long)1822435086);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)458407454 ^ (long)458407512);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-903336829 ^ (long)-903336886);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1995251207 ^ (long)-1995251221);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-544408686 ^ (long)-544408713);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1635537676 ^ (long)-1635537830);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)2217784 ^ (long)2217944);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1522813898 ^ (long)-1522813786);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1582710690 ^ (long)-1582710586);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-495690984 ^ (long)-495690785);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-957591848 ^ (long)-957591947);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1714836594 ^ (long)1714836586);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)2055522965 ^ (long)2055523050);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1802535664 ^ (long)-1802535445);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-214095221 ^ (long)-214095244);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)588371840 ^ (long)588371853);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1220749421 ^ (long)-1220749382);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1336665020 ^ (long)-1336665065);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-494772906 ^ (long)-494772991);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-911686781 ^ (long)-911686698);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-69028505 ^ (long)-69028417);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)430389326 ^ (long)430389346);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-28557011 ^ (long)-28556864);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1857527462 ^ (long)-1857527474);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1360474579 ^ (long)1360474515);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1660268961 ^ (long)1660269040);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-935508292 ^ (long)-935508465);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1271655778 ^ (long)1271655909);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)889676125 ^ (long)889676039);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-380051787 ^ (long)-380051800);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-925921154 ^ (long)-925921124);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-2116629041 ^ (long)-2116629100);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1454423825 ^ (long)-1454424053);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)167321173 ^ (long)167321301);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1314521448 ^ (long)-1314521515);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)331811444 ^ (long)331811331);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-402564083 ^ (long)-402563875);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-978577630 ^ (long)-978577619);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1848485315 ^ (long)1848485237);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)509166323 ^ (long)509166268);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)547101277 ^ (long)547101259);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1251245666 ^ (long)1251245652);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1059782113 ^ (long)1059782059);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)967114101 ^ (long)967114124);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)967249964 ^ (long)967249985);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1261782756 ^ (long)1261782782);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1743756781 ^ (long)1743756767);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-2105891167 ^ (long)-2105891276);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-799724693 ^ (long)-799724566);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1393589025 ^ (long)-1393589036);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-575708267 ^ (long)-575708293);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-167050089 ^ (long)-167050239);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1923478701 ^ (long)1923478663);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1857811936 ^ (long)-1857811725);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1756618096 ^ (long)-1756618082);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1269138031 ^ (long)-1269137947);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)596083162 ^ (long)596083069);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1617814155 ^ (long)-1617814131);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1692975781 ^ (long)1692975686);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1020540329 ^ (long)-1020540264);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1932305798 ^ (long)1932305767);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)493435138 ^ (long)493435332);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-815000086 ^ (long)-815000077);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1206940321 ^ (long)-1206940265);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)780832824 ^ (long)780833012);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)858530402 ^ (long)858530394);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-681155427 ^ (long)-681155562);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1095402577 ^ (long)1095402623);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)733043871 ^ (long)733043797);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)747695233 ^ (long)747695245);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1081871791 ^ (long)-1081871648);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1858111568 ^ (long)-1858111631);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)270912687 ^ (long)270912653);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1440181819 ^ (long)-1440181961);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-672252290 ^ (long)-672252179);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)995531240 ^ (long)995531156);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-187944720 ^ (long)-187944791);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1305660805 ^ (long)1305660770);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)538940686 ^ (long)538940806);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)882674654 ^ (long)882674542);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1795194088 ^ (long)-1795193967);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1882587741 ^ (long)1882587808);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)739027257 ^ (long)739027335);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-385446104 ^ (long)-385445961);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1779452280 ^ (long)-1779452318);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)489692395 ^ (long)489692235);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1962149340 ^ (long)-1962149312);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1451953181 ^ (long)1451953214);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1269100788 ^ (long)-1269100663);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-279442380 ^ (long)-279442182);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1269148587 ^ (long)1269148555);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1391448710 ^ (long)-1391448707);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-534445678 ^ (long)-534445745);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1344415938 ^ (long)1344415902);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1154768762 ^ (long)-1154768828);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)600484510 ^ (long)600484516);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)725472432 ^ (long)725472457);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1951412600 ^ (long)1951412706);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1738765965 ^ (long)1738766034);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)84226893 ^ (long)84226898);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1798534042 ^ (long)1798533922);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)2116604336 ^ (long)2116604341);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1291888724 ^ (long)-1291888778);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1594928909 ^ (long)1594928908);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)914663276 ^ (long)914663213);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)179566376 ^ (long)179566399);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-660984638 ^ (long)-660984678);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-750136255 ^ (long)-750136082);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-505664306 ^ (long)-505664293);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)740700138 ^ (long)740699909);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)810652595 ^ (long)810652517);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1438096149 ^ (long)1438096169);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-983139422 ^ (long)-983139416);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-641430591 ^ (long)-641430685);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)793094746 ^ (long)793094712);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)793271483 ^ (long)793271543);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)541552639 ^ (long)541552571);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1325195899 ^ (long)-1325195870);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1581262748 ^ (long)-1581262671);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1599463338 ^ (long)1599463325);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)633026561 ^ (long)633026793);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1572153028 ^ (long)-1572152921);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1103212908 ^ (long)1103212906);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1520423590 ^ (long)1520423506);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-949196918 ^ (long)-949196938);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1501891366 ^ (long)1501891463);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1626704445 ^ (long)-1626704474);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1384943449 ^ (long)1384943423);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1174166884 ^ (long)-1174166921);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)487015800 ^ (long)487015913);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1769732590 ^ (long)-1769732483);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1699899721 ^ (long)-1699899732);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-75682263 ^ (long)-75682173);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1725436591 ^ (long)-1725436555);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-449292250 ^ (long)-449292209);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)946188621 ^ (long)946188606);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-827764902 ^ (long)-827764958);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1398946063 ^ (long)-1398946303);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1853402076 ^ (long)-1853402083);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1459234998 ^ (long)1459234842);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)163964792 ^ (long)163964748);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1068403048 ^ (long)1068403182);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-39781627 ^ (long)-39781417);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-67384113 ^ (long)-67384255);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)801684032 ^ (long)801684185);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1390716641 ^ (long)1390716625);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1228054468 ^ (long)-1228054502);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1124317717 ^ (long)-1124317736);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)679515547 ^ (long)679515448);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1699934965 ^ (long)-1699934868);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1552605502 ^ (long)1552605546);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)947045706 ^ (long)947045770);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)2076695589 ^ (long)2076695597);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)398440102 ^ (long)398440117);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1667929322 ^ (long)1667929339);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)2061175992 ^ (long)2061175866);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)449769670 ^ (long)449769562);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1293333215 ^ (long)1293333171);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)650298977 ^ (long)650298911);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-328090799 ^ (long)-328090667);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)2003866130 ^ (long)2003866169);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1807306045 ^ (long)-1807306071);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)542613568 ^ (long)542613690);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1300331061 ^ (long)1300331166);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1253439148 ^ (long)1253439105);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1659372244 ^ (long)-1659372187);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1453554907 ^ (long)-1453554769);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1736470008 ^ (long)1736469949);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1104452942 ^ (long)1104453105);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1545189249 ^ (long)1545189238);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1020055618 ^ (long)1020055609);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)108517059 ^ (long)108516942);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-2133249283 ^ (long)-2133249378);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-2028943558 ^ (long)-2028943469);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1774259638 ^ (long)-1774259583);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-395355972 ^ (long)-395355998);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)77747798 ^ (long)77747949);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1266509048 ^ (long)1266508911);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)865778054 ^ (long)865778016);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1253834132 ^ (long)-1253834087);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1220337407 ^ (long)-1220337226);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-231268461 ^ (long)-231268378);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1510897367 ^ (long)1510897161);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-479104597 ^ (long)-479104599);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)228718830 ^ (long)228718599);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-423159729 ^ (long)-423159729);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-530671710 ^ (long)-530671842);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)506013662 ^ (long)506013562);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1097522921 ^ (long)-1097522875);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-134952421 ^ (long)-134952254);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-827746365 ^ (long)-827746438);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)862059992 ^ (long)862059882);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-253582656 ^ (long)-253582704);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-261161026 ^ (long)-261161054);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)367698157 ^ (long)367698128);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1425639967 ^ (long)-1425640144);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1491567974 ^ (long)-1491567975);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-660254078 ^ (long)-660253968);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-736417287 ^ (long)-736417327);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-713060452 ^ (long)-713060406);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)904992783 ^ (long)904992980);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-533107952 ^ (long)-533107798);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1803491040 ^ (long)-1803491036);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-287000836 ^ (long)-287000893);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-949266815 ^ (long)-949266692);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-73246169 ^ (long)-73245994);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1511681229 ^ (long)-1511681075);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)584369086 ^ (long)584368923);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1608187322 ^ (long)-1608187293);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1251032648 ^ (long)-1251032626);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1840597016 ^ (long)-1840597126);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1260831855 ^ (long)1260831928);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-2076972226 ^ (long)-2076972209);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)823796299 ^ (long)823796447);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1371622454 ^ (long)-1371622421);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)668118391 ^ (long)668118345);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-2046322885 ^ (long)-2046322787);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1591163330 ^ (long)1591163305);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-73436143 ^ (long)-73436017);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1988893559 ^ (long)1988893642);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1887913245 ^ (long)-1887913256);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1786286471 ^ (long)1786286543);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)114766578 ^ (long)114766512);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-270915695 ^ (long)-270915715);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1094511622 ^ (long)-1094511687);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1412150910 ^ (long)-1412150843);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-229193725 ^ (long)-229193619);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1969755000 ^ (long)-1969755010);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)2040144955 ^ (long)2040144979);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)509636376 ^ (long)509636450);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1506313889 ^ (long)1506313737);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)481146990 ^ (long)481146895);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-2126723366 ^ (long)-2126723499);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)465559696 ^ (long)465559636);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1153028250 ^ (long)1153028346);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)800105843 ^ (long)800105926);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-476291272 ^ (long)-476291092);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1213964098 ^ (long)-1213964149);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-775421104 ^ (long)-775421155);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1823211411 ^ (long)-1823211491);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1490918137 ^ (long)-1490917900);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1777356490 ^ (long)1777356506);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)2078510585 ^ (long)2078510458);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-702276658 ^ (long)-702276798);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-730881299 ^ (long)-730881342);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-475347631 ^ (long)-475347697);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1516563774 ^ (long)-1516563809);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)2114647332 ^ (long)2114647407);
                    if (!79.\u2006\u200f\u2001) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1535829541 ^ (long)1535829728);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1848183414 ^ (long)-1848183435)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)391867651 ^ (long)391877372)) >>> (int)((long)556726100 ^ (long)556726108)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-755780707 ^ (long)-755780707);
            if (!79.\u2006\u200f\u2001) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)172996131 ^ (long)172996129);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1944246732 ^ (long)-1944246729) | var5_6 << (int)((long)1605884334 ^ (long)1605884331)) ^ var3_4[var7_8]) & (int)((long)1165682152 ^ (long)1165681943);
                    if (79.\u2006\u200f\u2001) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-807415116 ^ (long)-807415113) | var6_7 << (int)((long)74890913 ^ (long)74890916)) ^ var3_4[var7_8]) & (int)((long)983799347 ^ (long)983799500);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            79.e[var2_3] = new String(var3_4).intern();
        }
        return 79.e[var2_3];
    }
}

