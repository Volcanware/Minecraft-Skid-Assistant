/* ==========================================================================
 * MODULE: Trajectories
 * CATEGORY (inferred): Render
 * DESCRIPTION: Displays where your items will land
 * OBFUSCATED CLASS: net.impactclient.76
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  afv
 *  aqa
 *  aqd
 *  bkm
 *  blc
 *  blj
 *  blk
 *  blx
 *  bmb
 *  bmn
 *  bmz
 *  bnc
 *  bnm
 *  bpu
 *  brf
 *  brf$a
 *  brf$b
 *  com.mojang.blaze3d.systems.RenderSystem
 *  dci
 *  dcj
 *  dck
 *  dcl$a
 *  dcn
 *  dem$j
 *  dem$r
 *  dzm
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  org.lwjgl.opengl.GL11
 *  pw.knx.feather.structures.Color
 */
package net.impactclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Optional;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1A;
import net.impactclient.1P;
import net.impactclient.1R;
import net.impactclient.2_;
import net.impactclient.2c;
import net.impactclient.2n;
import net.impactclient.2o;
import net.impactclient.2w$6X;
import net.impactclient.34E;
import net.impactclient.34J;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.5K;
import net.impactclient.65;
import net.impactclient.8h;
import org.lwjgl.opengl.GL11;
import pw.knx.feather.structures.Color;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 76
extends 3X
implements 8h {
    private static final String[] d;
    public static final boolean \u2008\u2004\u2000\u2002\u2000\u2001\u2007;
    private 1P 0;
    @EventHandler
    private final Listener<2o> 8;
    private 1R 6;
    private static final String[] e;
    private 1P 1;
    private 1A 4;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1707400589 ^ (long)1707407852)) & (int)((long)-496274060 ^ (long)-496268661);
            if (var9_2) ** GOTO lbl-1000
            if (76.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 76.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-629699973 ^ (long)-629699973)] & (int)((long)2086249756 ^ (long)2086249955)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)945794206 ^ (long)945794049);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)835606380 ^ (long)835606471);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)24062751 ^ (long)24062912);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1598015119 ^ (long)1598015153);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1655586650 ^ (long)1655586808);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-677004699 ^ (long)-677004689);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1659539450 ^ (long)1659539406);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1917887167 ^ (long)1917887143);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1535084057 ^ (long)1535084176);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)423735742 ^ (long)423735598);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1227879106 ^ (long)-1227879143);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1401519838 ^ (long)1401519818);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)438788493 ^ (long)438788589);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1443444870 ^ (long)1443444756);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)292056247 ^ (long)292056278);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-876917449 ^ (long)-876917398);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1553965280 ^ (long)1553965292);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)2095513680 ^ (long)2095513711);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1762855207 ^ (long)1762855390);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1754219263 ^ (long)-1754219205);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-221519568 ^ (long)-221519398);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1883286743 ^ (long)-1883286618);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1031920622 ^ (long)-1031920443);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1589064192 ^ (long)1589064400);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)478524553 ^ (long)478524615);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)2041601851 ^ (long)2041602007);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1735830861 ^ (long)-1735831028);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-499532521 ^ (long)-499532423);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)8496420 ^ (long)8496405);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1225018759 ^ (long)-1225018756);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-374620652 ^ (long)-374620478);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1348997455 ^ (long)1348997545);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)611975631 ^ (long)611975480);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)556502532 ^ (long)556502763);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-61922019 ^ (long)-61921947);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1108980424 ^ (long)-1108980406);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1399315934 ^ (long)1399315908);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-2045485475 ^ (long)-2045485524);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1024613536 ^ (long)-1024613483);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-162513625 ^ (long)-162513438);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1247333285 ^ (long)1247333254);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1724411233 ^ (long)-1724411263);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)58635393 ^ (long)58635433);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)751720583 ^ (long)751720640);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)539598433 ^ (long)539598373);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)2053454901 ^ (long)2053454848);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1079811773 ^ (long)-1079811821);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)76569122 ^ (long)76569137);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1580587800 ^ (long)-1580587972);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)883984890 ^ (long)883984740);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)968042954 ^ (long)968042868);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)664315938 ^ (long)664316129);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)102356214 ^ (long)102356047);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-680173278 ^ (long)-680173280);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)2112666644 ^ (long)2112666769);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-942627532 ^ (long)-942627333);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-757116966 ^ (long)-757117151);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-942983693 ^ (long)-942983759);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)353776382 ^ (long)353776227);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1801102436 ^ (long)1801102531);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1833013710 ^ (long)1833013729);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1678195479 ^ (long)-1678195558);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1781713777 ^ (long)1781713699);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1759896655 ^ (long)1759896763);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1759568914 ^ (long)1759569021);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-687586185 ^ (long)-687586097);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)745878799 ^ (long)745878945);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)665319836 ^ (long)665319770);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-109546129 ^ (long)-109546174);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1196218035 ^ (long)-1196217865);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-2055203810 ^ (long)-2055203831);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1474545726 ^ (long)1474545789);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1183199477 ^ (long)1183199473);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)793039478 ^ (long)793039469);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-904580542 ^ (long)-904580408);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1132063779 ^ (long)1132063770);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-578268086 ^ (long)-578267914);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1264404675 ^ (long)-1264404513);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1071177946 ^ (long)1071177939);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-966631095 ^ (long)-966631083);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)614552395 ^ (long)614552369);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1387965288 ^ (long)-1387965230);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1869724528 ^ (long)-1869724527);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1214381835 ^ (long)-1214381890);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-144033426 ^ (long)-144033373);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)777498658 ^ (long)777498636);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)432797281 ^ (long)432797205);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)175276932 ^ (long)175277000);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)641832939 ^ (long)641832833);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1225519659 ^ (long)1225519757);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-727452922 ^ (long)-727452886);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-253538227 ^ (long)-253538254);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1325022485 ^ (long)1325022641);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)158009439 ^ (long)158009384);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)861484039 ^ (long)861484278);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1948314376 ^ (long)-1948314589);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)968824744 ^ (long)968824814);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)643377479 ^ (long)643377619);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-844197531 ^ (long)-844197600);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1051501878 ^ (long)-1051502000);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1720475396 ^ (long)-1720475434);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)506226879 ^ (long)506226703);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-669118650 ^ (long)-669118498);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1872765076 ^ (long)1872765149);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1511344950 ^ (long)-1511344983);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)754325677 ^ (long)754325640);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1263254 ^ (long)-1263162);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)218101985 ^ (long)218101871);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1371924166 ^ (long)1371924222);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-179090244 ^ (long)-179090230);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)760154408 ^ (long)760154492);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1776015213 ^ (long)-1776015295);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-402707858 ^ (long)-402707741);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)421000374 ^ (long)421000359);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)429897765 ^ (long)429897926);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1225190818 ^ (long)-1225190826);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1612405889 ^ (long)1612405853);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1142108016 ^ (long)-1142107922);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1559153372 ^ (long)-1559153225);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)780998339 ^ (long)780998370);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1094430626 ^ (long)-1094430498);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-730471557 ^ (long)-730471489);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1144399696 ^ (long)-1144399683);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)2053004701 ^ (long)2053004776);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-638275048 ^ (long)-638274971);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-224904576 ^ (long)-224904452);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-563176540 ^ (long)-563176643);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)604351072 ^ (long)604351171);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)656470345 ^ (long)656470405);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-490802974 ^ (long)-490803047);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1418730943 ^ (long)-1418730862);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1903581904 ^ (long)-1903581907);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)624747743 ^ (long)624747737);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-483738248 ^ (long)-483738171);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-555984203 ^ (long)-555984175);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1034496920 ^ (long)1034496931);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1203268167 ^ (long)-1203268255);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1643668942 ^ (long)1643668853);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1297931790 ^ (long)1297931913);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-576086475 ^ (long)-576086320);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1342187185 ^ (long)1342187100);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1008924460 ^ (long)-1008924619);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-37478073 ^ (long)-37478100);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)593086124 ^ (long)593085999);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1593260791 ^ (long)-1593260640);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1733548566 ^ (long)-1733548774);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1154490896 ^ (long)1154491041);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)244646964 ^ (long)244647015);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1519368908 ^ (long)1519368956);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-25947335 ^ (long)-25947242);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1242365567 ^ (long)-1242365623);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1911768280 ^ (long)1911768106);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-738147185 ^ (long)-738147098);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1601238480 ^ (long)1601238516);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1348641273 ^ (long)1348641259);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)334156157 ^ (long)334156116);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)790316014 ^ (long)790315916);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-776979389 ^ (long)-776979409);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-915413466 ^ (long)-915413459);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)305602003 ^ (long)305601935);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1124912114 ^ (long)1124911912);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1761690086 ^ (long)-1761690086);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)540731893 ^ (long)540731747);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-650210921 ^ (long)-650210972);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-99291511 ^ (long)-99291437);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1247096482 ^ (long)-1247096408);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1205703001 ^ (long)1205702929);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1766670633 ^ (long)1766670613);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-205556306 ^ (long)-205556469);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1492372934 ^ (long)1492372817);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)2026349403 ^ (long)2026349558);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1449896014 ^ (long)-1449895969);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-2131701768 ^ (long)-2131701988);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1109637534 ^ (long)-1109637475);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)131553444 ^ (long)131553405);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1929976728 ^ (long)1929976789);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)449493183 ^ (long)449493049);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1850928409 ^ (long)1850928601);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-635167068 ^ (long)-635167126);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-101841113 ^ (long)-101841003);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)2014889798 ^ (long)2014889879);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)2038912886 ^ (long)2038912848);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1821061260 ^ (long)1821061232);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-988545317 ^ (long)-988545323);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1631537660 ^ (long)1631537504);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1105605547 ^ (long)1105605610);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-631537462 ^ (long)-631537628);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1085502882 ^ (long)-1085502817);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1482204465 ^ (long)-1482204595);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1550014035 ^ (long)1550014032);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-993432795 ^ (long)-993432755);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1254230163 ^ (long)1254230164);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1063840438 ^ (long)1063840351);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1561110268 ^ (long)1561110136);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-920578600 ^ (long)-920578702);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1398172420 ^ (long)1398172622);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1454332110 ^ (long)1454332157);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)720099552 ^ (long)720099412);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1931295970 ^ (long)-1931295880);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1558464835 ^ (long)-1558464853);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1171401827 ^ (long)-1171401824);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1458786174 ^ (long)-1458786110);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1481129276 ^ (long)1481129412);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)202069570 ^ (long)202069674);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)503864362 ^ (long)503864557);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1531603606 ^ (long)1531603599);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)352550926 ^ (long)352550972);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1281613183 ^ (long)1281613151);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-2111441780 ^ (long)-2111441807);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1689039448 ^ (long)-1689039432);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1263946964 ^ (long)-1263946835);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)417539958 ^ (long)417539886);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1457083493 ^ (long)1457083440);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1401886246 ^ (long)-1401886356);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)219513750 ^ (long)219513637);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-487520869 ^ (long)-487521008);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)264102054 ^ (long)264101934);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-810402968 ^ (long)-810402823);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-11212911 ^ (long)-11212890);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1249632090 ^ (long)1249632207);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-422930122 ^ (long)-422930065);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1159716539 ^ (long)-1159716493);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)469473352 ^ (long)469473437);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1396557676 ^ (long)-1396557791);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-94728280 ^ (long)-94728397);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1868256952 ^ (long)-1868257002);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-852805080 ^ (long)-852804895);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)871691382 ^ (long)871691435);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1393939885 ^ (long)-1393939726);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)193508518 ^ (long)0xB88B484);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1931752723 ^ (long)1931752776);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1803274566 ^ (long)-1803274726);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-669395338 ^ (long)-669395316);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1817193928 ^ (long)-1817193881);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1963566677 ^ (long)-1963566784);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1400452535 ^ (long)1400452383);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-973224265 ^ (long)-973224389);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-263022795 ^ (long)-263022768);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-2105121815 ^ (long)-2105121818);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1018081165 ^ (long)-1018081270);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)2059945714 ^ (long)2059945709);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1797135491 ^ (long)1797135572);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)2036936481 ^ (long)2036936671);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)2033878213 ^ (long)2033878030);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1657858746 ^ (long)-1657858575);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)876772409 ^ (long)876772446);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1220018760 ^ (long)-1220018842);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)403347540 ^ (long)403347606);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1878248512 ^ (long)1878248615);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1208202423 ^ (long)1208202396);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-3060642 ^ (long)-3060690);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)92112255 ^ (long)92112169);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1876187297 ^ (long)-1876187376);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1430483327 ^ (long)1430483359);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1859743278 ^ (long)-1859743289);
                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1394664198 ^ (long)1394664279);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)224555569 ^ (long)224555726)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1331967779 ^ (long)-1332005086)) >>> (int)((long)-1917103347 ^ (long)-1917103355)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1916233287 ^ (long)-1916233287);
            if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1726657273 ^ (long)1726657275);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1841815991 ^ (long)-1841815990) | var5_6 << (int)((long)1147083282 ^ (long)1147083287)) ^ var3_4[var7_8]) & (int)((long)-435579132 ^ (long)-435578885);
                    if (76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-644661285 ^ (long)-644661288) | var6_7 << (int)((long)463131824 ^ (long)463131829)) ^ var3_4[var7_8]) & (int)((long)482286997 ^ (long)482286954);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            76.e[var2_3] = new String(var3_4).intern();
        }
        return 76.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1722951233 ^ (long)1722951247)];
            if (var7) break block23;
            var3_2 = (int)((long)-1825597451 ^ (long)-1825597451);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ua469\u8d02\u9e90\u96e2\ua46e\u8dd4\u9e95\u96ab\ua4f8\u8d6f\u9e19\u96b1\ua481\u8df2\u9ee9\u9606\ua44f\u8dfc\u9e01\u96a6\ua469\u8d85\u9e09\u96a2\ua470\u8d26\u9e53\u96df\ua4d1\u8d67\u9eb7\u96bc\ua440\u8deb\u9eb9\u9639\ua431\u8dcc\u9e1a\u9611\ua4a4\u8d2f\u9eed\u9673\ua4c5\u8dd4\u9e3c\u96b1\ua48e\u8d17\u9e2c\u96ba\ua4f7\u8d6b\u9e16\u9654\ua476\u8d78\u9eb6\u9628\ua4e0\u8d46\u9ec1\u9684\ua4e3\u8d0e\u9e98\u965c\ua46a\u8d04\u9e03\u96fa\ua486\u8df1\u9e72\u9699\ua439\u8d96\u9ef8\u9605\ua449\u8dfa\u9e3d\u96bc\ua48f\u8d14\u9e10\u9675\ua49d\u8d42\u9ed1\u9625\ua472\u8dee\u9e8d\u9632\ua4f9\u8d05\u9ea9\u9659\ua48e\u8d73\u9e7e\u9625\ua4b2\u8d7e\u9ebd\u967c\ua44f\u8d6d\u9e50\u9644\ua49a\u8d35\u9eff\u96f5\ua498\u8d62\u9ec5\u9639\ua458\u8d9e\u9e3b\u96f3\ua4a6\u8d22\u9edc\u96b9\ua48e\u8ddf\u9e42\u965f\ua4de\u8d43\u9e66\u9661\ua43b\u8d0f\u9ef9\u963e\ua4f5\u8d7a\u9e74\u9653\ua444\u8d0c\u9e4b\u9629\ua442\u8dd7\u9eb6\u96a4\ua411\u8d3d\u9ea9\u960e\ua494\u8da5\u9e79\u9617\ua480\u8da1\u9ec9\u96df\ua462\u8d30\u9ece\u9663\ua495\u8dd4\u9e25\u9663\ua454\u8dab\u9e9f\u969a\ua43e\u8d0f\u9e1c\u9647\ua40e\u8de6\u9e2e\u96ec\ua408\u8dd6\u9eff\u9693\ua4d5\u8dec\u9e88\u96df\ua457\u8d2f\u9e8f\u966a\ua4ba\u8d76\u9ea4\u961d\ua4f5\u8d93\u9e80\u9668\ua4a2\u8db2\u9ef1\u9649\ua487\u8db7\u9eae\u96b1\ua455\u8db5\u9e8b\u9699\ua44b\u8daa\u9eb2\u9603", -1493269640);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)693791974 ^ (long)693791971);
            if (var7) break block23;
            var0_6 = (int)((long)1585850294 ^ (long)-1585850295);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1021604861 ^ (long)-1021604756);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-2055335007 ^ (long)2055335006);
                    if (76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u9359\uba6a\ua995\ua1d9\u9333\uba19\ua906\ua1ce\u933b\uba86\ua9c9\ua1fb\u9334\uba76\ua916\ua14c\u939a\uba69\ua9ba\ua108\u933d\uba28\ua9ea\ua137\u93ed\uba55\ua927\ua13e\u93f5\ubaf6\ua924\ua143\u93c0\uba4f\ua971\ua16f\u9353\uba78\ua9c5\ua10b\u9381\uba0c", 1429255183);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-280045186 ^ (long)-280045193);
                            var0_6 = (int)((long)368529985 ^ (long)-368529986);
                            while (true) {
                                v0 = (int)((long)704545334 ^ (long)704545298);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)946137066 ^ (long)946137066);
                                if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) ** continue;
                                throw null;
                            }
                            76.d = var5_1;
                            76.e = new String[(int)((long)-438859063 ^ (long)-438859065)];
                            if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1524972590 ^ (long)1524972590);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1822666068 ^ (long)-1822666067)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-213139604 ^ (long)-213139605)) {
                                case 0: {
                                    v15 = (int)((long)-391316998 ^ (long)-391317061);
                                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1273854496 ^ (long)-1273854531);
                                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1573104286 ^ (long)-1573104369);
                                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1090543024 ^ (long)-1090543000);
                                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1618968233 ^ (long)1618968240);
                                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-973086996 ^ (long)-973087074);
                                    if (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-2125653375 ^ (long)-2125653260);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!76.\u2008\u2004\u2000\u2002\u2000\u2001\u2007);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static afv<aqa, dcn> 6(dcn dcn2, dcn dcn3, boolean bl) {
        dcn dcn4;
        aqa aqa2;
        block17: {
            boolean bl2 = \u2008\u2004\u2000\u2002\u2000\u2001\u2007;
            if (!bl2 && !bl2) {
                Object object = dcn3.d(dcn2);
                if (!bl2 && !bl2) {
                    double d2 = dcn2.d;
                    double d3 = dcn2.c;
                    double d4 = dcn2.b;
                    object = 76.3.r.a(null, new dci(d4 - 0.25, d3, d2 - 0.25, d4 + 0.25, d3 + 0.5, d2 + 0.5).b(((dcn)object).b, ((dcn)object).c, ((dcn)object).d).g(1.0), aqd.a.and(aqd.g).and(aqa::aT));
                    if (!bl2 && !bl2) {
                        double d5 = 0.0;
                        if (bl2) return null;
                        if (!bl2) {
                            aqa2 = null;
                            if (bl2) return null;
                            if (!bl2) {
                                dcn4 = null;
                                if (bl2) return null;
                                if (!bl2) {
                                    object = object.iterator();
                                    if (!bl2) {
                                        while (!bl2) {
                                            if (object.hasNext()) {
                                                if (bl2) break;
                                                aqa aqa3 = (aqa)object.next();
                                                if (aqa3 == 76.3.s) {
                                                    if (bl2) break;
                                                    if (bl) {
                                                        if (bl2) break;
                                                    }
                                                } else {
                                                    if (bl2) break;
                                                    Optional optional = aqa3.cc().g(0.3).b(dcn2, dcn3);
                                                    if (optional.isPresent()) {
                                                        if (bl2 || bl2) break;
                                                        double d6 = dcn2.g((dcn)optional.get());
                                                        if (!(d6 < d5)) {
                                                            if (bl2) break;
                                                            if (d5 == 0.0) {
                                                                if (bl2) break;
                                                            }
                                                        } else {
                                                            if (bl2) break;
                                                            aqa2 = aqa3;
                                                            if (bl2 || bl2) break;
                                                            d5 = d6;
                                                            if (bl2 || bl2) break;
                                                            dcn4 = (dcn)optional.get();
                                                            if (bl2) break;
                                                        }
                                                    }
                                                }
                                                if (bl2) break;
                                                if (!\u2008\u2004\u2000\u2002\u2000\u2001\u2007) continue;
                                                throw null;
                                            }
                                            if (bl2) break;
                                            if (aqa2 == null) {
                                                if (bl2) break;
                                                return null;
                                            }
                                            if (!bl2) break block17;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return null;
        }
        return new afv(aqa2, dcn4);
    }

    public 76() {
        boolean bl = \u2008\u2004\u2000\u2002\u2000\u2001\u2007;
        super(76.b((int)((long)-1780857901 ^ (long)-1780848716), (int)((long)1025318506 ^ (long)1025316075)) /* "Trajectories" */, 76.b((int)((long)-1565590404 ^ (long)-1565599721), (int)((long)1843352760 ^ (long)1843350393)) /* "Displays where your items will land" */);
        this.0 = (1P)((34X)((34X)((34X)this.4().5(76.b((int)((long)287022043 ^ (long)287031230), (int)((long)2144651688 ^ (long)-2144650426)) /* "Entities" */)).7(76.b((int)((long)-1583167051 ^ (long)-1583157802), (int)((long)-2009822531 ^ (long)2009813679)) /* "entities" */)).1(76.b((int)((long)1754049818 ^ (long)1754040696), (int)((long)-703623066 ^ (long)703602512)) /* "Stop when an entity is hit" */)).5();
        Comparable<Boolean> comparable = Boolean.FALSE;
        34J j2 = (34X)((34X)((34X)this.4().5(76.b((int)((long)-685122746 ^ (long)-685113556), (int)((long)-1727739897 ^ (long)1727755475)) /* "Centered" */)).7(76.b((int)((long)1776985656 ^ (long)1776976469), (int)((long)-327483350 ^ (long)327469948)) /* "centered2" */)).1(76.b((int)((long)807507601 ^ (long)807514872), (int)((long)1964489981 ^ (long)-1964494214)) /* "Draw a more accurate tracer that doesn't start from the item" */);
        ((34X)((34X)((34X)this.4().5(76.b((int)((long)-685122746 ^ (long)-685113556), (int)((long)-1727739897 ^ (long)1727755475)) /* "Centered" */)).7(76.b((int)((long)1776985656 ^ (long)1776976469), (int)((long)-327483350 ^ (long)327469948)) /* "centered2" */)).1(76.b((int)((long)807507601 ^ (long)807514872), (int)((long)1964489981 ^ (long)-1964494214)) /* "Draw a more accurate tracer that doesn't start from the item" */)).7 = comparable;
        this.1 = (1P)j2.5();
        comparable = Color.fromRGB((float)1.0f, (float)0.5f, (float)0.0f);
        j2 = (34E)((34E)((34E)this.0().5(76.b((int)((long)426365777 ^ (long)426374961), (int)((long)-330024553 ^ (long)330029919)) /* "Color" */)).7(76.b((int)((long)116745929 ^ (long)116736685), (int)((long)2080334015 ^ (long)2080309664)) /* "color" */)).1(76.b((int)((long)1491758902 ^ (long)1491749712), (int)((long)-441045882 ^ (long)-441029668)) /* "The color of the trajectory line" */);
        ((34E)((34E)((34E)this.0().5(76.b((int)((long)426365777 ^ (long)426374961), (int)((long)-330024553 ^ (long)330029919)) /* "Color" */)).7(76.b((int)((long)116745929 ^ (long)116736685), (int)((long)2080334015 ^ (long)2080309664)) /* "color" */)).1(76.b((int)((long)1491758902 ^ (long)1491749712), (int)((long)-441045882 ^ (long)-441029668)) /* "The color of the trajectory line" */)).7 = comparable;
        this.6 = (1R)((34E)j2).5();
        comparable = Float.valueOf(1.8f);
        j2 = ((34e)((34e)((34e)this.9().5(76.b((int)((long)821083093 ^ (long)821075892), (int)((long)-1542715960 ^ (long)-1542699820)) /* "Width" */)).7(76.b((int)((long)-1221784965 ^ (long)-1221775853), (int)((long)-476042264 ^ (long)476040447)) /* "width" */)).1(76.b((int)((long)-3505306 ^ (long)-3496182), (int)((long)-234219080 ^ (long)234218145)) /* "The width of the trajectory line" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(4.0f));
        ((34e)((34e)((34e)this.9().5(76.b((int)((long)821083093 ^ (long)821075892), (int)((long)-1542715960 ^ (long)-1542699820)) /* "Width" */)).7(76.b((int)((long)-1221784965 ^ (long)-1221775853), (int)((long)-476042264 ^ (long)476040447)) /* "width" */)).1(76.b((int)((long)-3505306 ^ (long)-3496182), (int)((long)-234219080 ^ (long)234218145)) /* "The width of the trajectory line" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(4.0f)).7 = comparable;
        this.4 = (1A)((34e)j2).5();
        this.8 = new Listener(sp2 -> {
            double d2;
            76 var1_2;
            double d3;
            double d4;
            float f;
            blx blx2;
            Object object;
            String[] stringArray;
            block65: {
                double d5;
                float f2;
                float f3;
                float f4;
                boolean bl = \u2008\u2004\u2000\u2002\u2000\u2001\u2007;
                if (bl) return;
                stringArray = 3e.5();
                if (bl || bl) return;
                dzm dzm2 = 76.3.s;
                object = dzm2.dD();
                blx2 = object.b();
                if (!(blx2 instanceof bkm)) {
                    if (bl) return;
                    if (!(blx2 instanceof bmz)) {
                        if (bl) return;
                        if (!(blx2 instanceof blc)) {
                            if (bl) return;
                            if (!(blx2 instanceof blj)) {
                                if (bl) return;
                                if (!(blx2 instanceof bnc)) {
                                    if (bl) return;
                                    if (!(blx2 instanceof bnm)) {
                                        if (bl) return;
                                        if (!(blx2 instanceof blk)) {
                                            if (bl || bl) return;
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (bl) return;
                boolean bl2 = object.b() instanceof bkm;
                if (bl || bl) {
                    return;
                }
                double d6 = dzm2.D + (dzm2.cD() - dzm2.D) * (double)((2_)sp2).3();
                if (this.1.2) {
                    f4 = 0.0f;
                    if (\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
                    }
                } else {
                    f4 = afm.b((float)((float)Math.toRadians(dzm2.p))) * 0.16f;
                }
                double d7 = d6 - (double)f4;
                double d8 = dzm2.E + (dzm2.cE() - dzm2.E) * (double)((2_)sp2).3() + (double)dzm2.ce() - 0.1;
                double d9 = dzm2.F + (dzm2.cH() - dzm2.F) * (double)((2_)sp2).3();
                if (this.1.2) {
                    f3 = 0.0f;
                    if (\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
                    }
                } else {
                    f3 = afm.a((float)((float)Math.toRadians(dzm2.p))) * 0.16f;
                }
                double d10 = d9 - (double)f3;
                float f5 = (float)Math.toRadians(dzm2.p);
                float f6 = (float)Math.toRadians(dzm2.q);
                float f7 = -afm.a((float)f5) * afm.b((float)f6);
                if (blx2 instanceof bmn || blx2 instanceof blk) {
                    f2 = (float)Math.toRadians(-20.0);
                    if (\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
                    }
                } else {
                    f2 = 0.0f;
                }
                float f8 = -afm.a((float)(f6 + f2));
                f5 = afm.b((float)f5) * afm.b((float)f6);
                float f9 = f7;
                float f10 = f8;
                float f11 = f5;
                double d11 = Math.sqrt(f9 * f9 + f10 * f10 + f11 * f11);
                f7 = (float)((double)f7 / d11);
                f8 = (float)((double)f8 / d11);
                f5 = (float)((double)f5 / d11);
                if (bl2) {
                    float f12;
                    float f13 = (float)((int)((long)-41888642 ^ (long)-41824962) - dzm2.dZ()) / 20.0f;
                    f13 = (f13 * f13 + f13 * 2.0f) / 3.0f;
                    if (f12 > 1.0f) {
                        f13 = 1.0f;
                    }
                    if (f13 <= 0.1f) {
                        f13 = 1.0f;
                    }
                    f = f13 * 3.0f;
                    if (\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
                    }
                } else if (blx2 instanceof bnm) {
                    f = 2.5f + (float)bpu.g((bmb)object) * 0.5f;
                    if (\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
                    }
                } else if (blx2 instanceof bmn) {
                    f = 0.5f;
                    if (\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
                    }
                } else if (blx2 instanceof blk) {
                    f = 0.7f;
                    if (\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
                    }
                } else {
                    f = 1.5f;
                }
                f7 *= f;
                f8 *= f;
                f5 *= f;
                if (bl2 || blx2 instanceof bmn) {
                    d5 = 0.05;
                    if (\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
                    }
                } else if (blx2 instanceof blk) {
                    d5 = 0.07;
                    if (\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                        throw null;
                    }
                } else {
                    d5 = 0.03;
                }
                double d12 = d5;
                f = ((2_)sp2).3();
                double d13 = d12;
                double d14 = f5;
                double d15 = f8;
                double d16 = f7;
                d4 = d10;
                d3 = d8;
                double d17 = d7;
                var1_2 = this;
                RenderSystem.pushMatrix();
                GL11.glEnable((int)((int)((long)-1737318291 ^ (long)-1737315507)));
                RenderSystem.blendFunc((dem.r)dem.r.l, (dem.j)dem.j.j);
                RenderSystem.enableBlend();
                RenderSystem.disableTexture();
                RenderSystem.disableDepthTest();
                GL11.glEnable((int)((int)((long)-1836919085 ^ (long)-1836951986)));
                RenderSystem.depthMask((boolean)((long)-1076302197 ^ (long)-1076302197));
                RenderSystem.lineWidth((float)var1_2.4.9);
                object = (2c)3.ac();
                5K.6(var1_2.6.2.getHex());
                GL11.glBegin((int)((int)((long)1133390596 ^ (long)1133390599)));
                blx2 = null;
                for (int i = (int)((long)-1439335467 ^ (long)-1439335467); i < (int)((long)545715976 ^ (long)545715424); d14 *= 0.99, d15 -= d13, ++i) {
                    GL11.glVertex3d((double)(d17 - object.getRenderPosX()), (double)(d3 - object.getRenderPosY()), (double)(d4 - object.getRenderPosZ()));
                    double d18 = d17;
                    double d19 = d3;
                    double d20 = d4;
                    d17 += d16;
                    d3 += d15;
                    d2 = d4 + d14;
                    if (stringArray == null) {
                        d4 = d2;
                        dcn dcn2 = new dcn(d18, d19, d20);
                        dcn dcn3 = new dcn(d17, d3, d4);
                        if (var1_2.0.2) {
                            afv<aqa, dcn> afv2;
                            int n;
                            if (i >= (int)((long)82922002 ^ (long)82922007)) {
                                n = (int)((long)1155959584 ^ (long)1155959585);
                                if (\u2008\u2004\u2000\u2002\u2000\u2001\u2007) {
                                    throw null;
                                }
                            } else {
                                n = (int)((long)774051427 ^ (long)774051427);
                            }
                            if ((afv2 = 76.6(dcn2, dcn3, n != 0)) != null) {
                                blx2 = new dck((aqa)afv2.a());
                                d17 = ((dcn)afv2.b()).b;
                                d3 = ((dcn)afv2.b()).c;
                                d4 = ((dcn)afv2.b()).d;
                                if (!\u2008\u2004\u2000\u2002\u2000\u2001\u2007) break;
                                throw null;
                            }
                        }
                        if ((blx2 = 76.3.r.a(new brf(dcn2, dcn3, brf.a.a, brf.b.a, (aqa)76.3.s))).c() == dcl.a.b) {
                            d17 = blx2.e().b;
                            d3 = blx2.e().c;
                            d4 = blx2.e().d;
                            if (stringArray == null) break;
                        }
                        d16 *= 0.99;
                        d15 *= 0.99;
                        if (stringArray == null) continue;
                    }
                    break block65;
                }
                d2 = d17 - object.getRenderPosX();
            }
            double d21 = d2;
            double d22 = d3 - object.getRenderPosY();
            double d23 = d4 - object.getRenderPosZ();
            GL11.glVertex3d((double)d21, (double)d22, (double)d23);
            if (blx2.c() == dcl.a.b) {
                object = (dcj)blx2;
                switch (65.4[object.b().ordinal()]) {
                    case 1: 
                    case 2: {
                        GL11.glVertex3d((double)d21, (double)d22, (double)d23);
                        GL11.glVertex3d((double)d21, (double)(d22 - 0.55), (double)d23);
                        GL11.glVertex3d((double)d21, (double)d22, (double)(d23 - 0.55));
                        GL11.glVertex3d((double)d21, (double)d22, (double)(d23 + 0.55));
                        GL11.glVertex3d((double)d21, (double)(d22 + 0.55), (double)d23);
                        GL11.glVertex3d((double)d21, (double)(d22 - 0.55), (double)d23);
                        GL11.glVertex3d((double)d21, (double)d22, (double)(d23 + 0.55));
                        GL11.glVertex3d((double)d21, (double)d22, (double)(d23 - 0.55));
                        GL11.glVertex3d((double)d21, (double)(d22 + 0.55), (double)d23);
                        if (stringArray == null) break;
                    }
                    case 3: 
                    case 4: {
                        GL11.glVertex3d((double)d21, (double)d22, (double)d23);
                        GL11.glVertex3d((double)(d21 - 0.55), (double)d22, (double)d23);
                        GL11.glVertex3d((double)d21, (double)(d22 - 0.55), (double)d23);
                        GL11.glVertex3d((double)d21, (double)(d22 + 0.55), (double)d23);
                        GL11.glVertex3d((double)(d21 + 0.55), (double)d22, (double)d23);
                        GL11.glVertex3d((double)(d21 - 0.55), (double)d22, (double)d23);
                        GL11.glVertex3d((double)d21, (double)(d22 + 0.55), (double)d23);
                        GL11.glVertex3d((double)d21, (double)(d22 - 0.55), (double)d23);
                        GL11.glVertex3d((double)(d21 + 0.55), (double)d22, (double)d23);
                        if (stringArray == null) break;
                    }
                    case 5: 
                    case 6: {
                        GL11.glVertex3d((double)d21, (double)d22, (double)d23);
                        GL11.glVertex3d((double)(d21 - 0.55), (double)d22, (double)d23);
                        GL11.glVertex3d((double)d21, (double)d22, (double)(d23 - 0.55));
                        GL11.glVertex3d((double)d21, (double)d22, (double)(d23 + 0.55));
                        GL11.glVertex3d((double)(d21 + 0.55), (double)d22, (double)d23);
                        GL11.glVertex3d((double)(d21 - 0.55), (double)d22, (double)d23);
                        GL11.glVertex3d((double)d21, (double)d22, (double)(d23 + 0.55));
                        GL11.glVertex3d((double)d21, (double)d22, (double)(d23 - 0.55));
                        GL11.glVertex3d((double)(d21 + 0.55), (double)d22, (double)d23);
                        break;
                    }
                }
            }
            GL11.glEnd();
            if (blx2.c() == dcl.a.c) {
                2n.4(((dck)blx2).a(), var1_2.6.2.getHex(), (boolean)((long)1608592473 ^ (long)1608592473), f);
            }
            RenderSystem.disableBlend();
            RenderSystem.enableTexture();
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask((boolean)((long)789319600 ^ (long)789319601));
            GL11.glDisable((int)((int)((long)1699425086 ^ (long)1699457955)));
            GL11.glDisable((int)((int)((long)452304768 ^ (long)452301984)));
            RenderSystem.popMatrix();
        }, new Predicate[(int)((long)1263786402 ^ (long)1263786402)]);
    }
}

