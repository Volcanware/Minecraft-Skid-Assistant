/* ==========================================================================
 * MODULE: No Rotate
 * CATEGORY (inferred): Misc
 * DESCRIPTION: Discards Server Rotation Packets
 * OBFUSCATED CLASS: net.impactclient.7I
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  qk
 *  qk$a
 *  st$b
 */
package net.impactclient;

import java.util.Set;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import me.zero.clarinet.hook.mixin.accessor.AccessorCPlayerPacket;
import me.zero.clarinet.hook.mixin.accessor.AccessorSPlayerPositionLookPacket;
import net.impactclient.2w$6X;
import net.impactclient.34R;
import net.impactclient.34k;
import net.impactclient.34s;
import net.impactclient.3C;
import net.impactclient.3X;
import net.impactclient.3i;
import net.impactclient.3u;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7I
extends 3X
implements 34R {
    private Float 9;
    private static final String[] d;
    private Float 1;
    public static final boolean \u200e\u2005\u200c\u2005\u2008\u200d\u2004;
    @EventHandler
    private final Listener<3i> 0;
    @EventHandler
    private final Listener<3C> 6;
    private static final String[] e;

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)756539626 ^ (long)756539624)];
            if (var7) break block16;
            var3_2 = (int)((long)279364168 ^ (long)279364168);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u2775\u0e39\u1df8\u15d0\u2708\u0efe\u1d38\u15f5\u27a7\u0e70\u1daf\u1516\u2765\u0ea7\u1d52\u1564\u2767\u0e02\u1d72\u157d\u2774\u0e81\u1d5e\u1531\u27f9\u0e7e\u1da0\u15a3\u2724\u0e1f\u1dd0\u1563\u2707\u0e50\u1de7\u15f9\u2708\u0e3b\u1d01\u15d9\u277d\u0ec3", 1049755897);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)-205593272 ^ (long)-205593279);
            if (var7) break block16;
            var0_6 = (int)((long)-198955624 ^ (long)198955623);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)1171007524 ^ (long)-1171007525);
                if (7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) continue block8;
                            throw null;
                        }
                        7I.d = var5_1;
                        7I.e = new String[(int)((long)1206950303 ^ (long)1206950301)];
                        if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)1357605884 ^ (long)1357605884);
                v5 = (int)((long)1133185716 ^ (long)1133185721);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)390268182 ^ (long)390268183)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1843358036 ^ (long)-1843358037)) {
                                case 0: {
                                    v12 = (int)((long)2133403738 ^ (long)2133403727);
                                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)1007437289 ^ (long)1007437222);
                                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-186227020 ^ (long)-186226949);
                                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)1312866577 ^ (long)1312866625);
                                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)727394042 ^ (long)727393933);
                                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)-259270004 ^ (long)-259269899);
                                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-1936420033 ^ (long)-1936420073);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) ** continue;
                throw null;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1568206961 ^ (long)1568181166)) & (int)((long)-554681071 ^ (long)-554646802);
            if (var9_2) ** GOTO lbl-1000
            if (7I.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7I.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1837178836 ^ (long)1837178836)] & (int)((long)349497935 ^ (long)349498032)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)502071025 ^ (long)502070961);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1857311104 ^ (long)-1857310997);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1762644113 ^ (long)-1762644156);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1706239076 ^ (long)-1706239168);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1990902985 ^ (long)1990902796);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-38946496 ^ (long)-38946476);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1892534004 ^ (long)-1892533999);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)180908669 ^ (long)180908753);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1790106486 ^ (long)1790106623);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1387783884 ^ (long)1387783685);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-368264904 ^ (long)-368264854);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1523562317 ^ (long)-1523562362);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-353890603 ^ (long)-353890662);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1352292541 ^ (long)-1352292550);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1504340514 ^ (long)1504340574);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1221765966 ^ (long)1221766026);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-61807330 ^ (long)-61807213);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1159489109 ^ (long)1159489262);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1277676174 ^ (long)1277676038);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)387986849 ^ (long)387986770);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-44607656 ^ (long)-44607558);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1066649797 ^ (long)1066649854);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1601991315 ^ (long)1601991418);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1725562330 ^ (long)-1725562121);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1652993142 ^ (long)-1652993267);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1931392336 ^ (long)1931392349);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1352610407 ^ (long)1352610325);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1185930363 ^ (long)-1185930405);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-2061376297 ^ (long)-2061376356);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1761953405 ^ (long)-1761953356);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-48740504 ^ (long)-48740554);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1023967736 ^ (long)-1023967713);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-355827523 ^ (long)-355827597);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1119208592 ^ (long)1119208626);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)802656088 ^ (long)802656080);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)79030455 ^ (long)79030289);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)137190254 ^ (long)137190288);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-170740464 ^ (long)-170740378);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1728151512 ^ (long)-1728151347);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-764316756 ^ (long)-764316742);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1156235164 ^ (long)-1156235023);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1036131224 ^ (long)1036131237);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1180975376 ^ (long)-1180975478);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1624040066 ^ (long)-1624040191);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1295110158 ^ (long)1295110353);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)126451540 ^ (long)126451678);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)2121234322 ^ (long)2121234178);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-832418714 ^ (long)-832418590);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-2012637355 ^ (long)-2012637267);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)433627213 ^ (long)433627297);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-2142820480 ^ (long)-2142820602);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1597295797 ^ (long)1597295631);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)225679138 ^ (long)225679149);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1460615828 ^ (long)-1460615829);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1511426265 ^ (long)-1511426080);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1982592573 ^ (long)1982592712);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1215669658 ^ (long)1215669709);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)557534515 ^ (long)557534621);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-447318191 ^ (long)-447318260);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1460217282 ^ (long)-1460217234);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1628060892 ^ (long)-1628060739);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1651878937 ^ (long)1651879117);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1155155640 ^ (long)-1155155498);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1278825270 ^ (long)-1278825305);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-2025632990 ^ (long)-2025632774);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1442908810 ^ (long)1442908748);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)376310526 ^ (long)376310501);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-2057997719 ^ (long)-2057997682);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1481697969 ^ (long)-1481698023);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)738512739 ^ (long)738512866);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)377302684 ^ (long)377302707);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)354185187 ^ (long)354185212);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)593893568 ^ (long)593893528);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-255449905 ^ (long)-255449903);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1852390069 ^ (long)1852390084);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1209796050 ^ (long)-1209795983);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)934971971 ^ (long)934972124);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1324516386 ^ (long)-1324516499);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)301209050 ^ (long)301208897);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)2054917523 ^ (long)2054917377);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)2037785586 ^ (long)2037785550);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1779107865 ^ (long)-1779107898);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1903396093 ^ (long)1903395991);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)399008284 ^ (long)399008278);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1059537002 ^ (long)1059537050);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1842412225 ^ (long)-1842412193);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)751102965 ^ (long)751102917);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1176138522 ^ (long)-1176138666);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1058492001 ^ (long)1058492086);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1578411199 ^ (long)1578411095);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)510588663 ^ (long)510588477);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-2095975761 ^ (long)-2095975699);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)888244031 ^ (long)888244062);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-834587292 ^ (long)-834587266);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1326017660 ^ (long)-1326017762);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1355985094 ^ (long)1355985141);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1816282089 ^ (long)1816281936);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1059401403 ^ (long)-1059401438);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)428759074 ^ (long)428759207);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)270564209 ^ (long)270564216);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-439076453 ^ (long)-439076543);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1969074605 ^ (long)1969074583);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)687237577 ^ (long)687237387);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1955479684 ^ (long)1955479653);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1939118333 ^ (long)1939118144);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-541283600 ^ (long)-541283616);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)2048845120 ^ (long)2048845170);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1020769417 ^ (long)-1020769308);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1581524819 ^ (long)-1581524895);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-509233714 ^ (long)-509233718);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)313697954 ^ (long)313697964);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1699175995 ^ (long)1699176080);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)449547338 ^ (long)449547512);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1489921470 ^ (long)1489921494);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)587434884 ^ (long)587434845);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)22226388 ^ (long)22226216);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-34950192 ^ (long)-34950278);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1973913409 ^ (long)-1973913489);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)253040177 ^ (long)253040344);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)942635053 ^ (long)942635140);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1220107775 ^ (long)-1220107538);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)971791938 ^ (long)971791959);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)2019718346 ^ (long)2019718275);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-379151206 ^ (long)-379151129);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)370620713 ^ (long)370620842);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-859899715 ^ (long)-859899793);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-910109751 ^ (long)-910109711);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1898195688 ^ (long)1898195572);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-43620668 ^ (long)-43620822);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-349331979 ^ (long)-349332147);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)894604953 ^ (long)894604997);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-116879000 ^ (long)-116879060);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-381199166 ^ (long)-381199345);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-758970600 ^ (long)-758970429);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)402687689 ^ (long)402687721);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)329930561 ^ (long)329930740);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)106019297 ^ (long)106019093);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1416679732 ^ (long)1416679724);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1483028652 ^ (long)1483028637);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-418533008 ^ (long)-418532943);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-994387422 ^ (long)-994387378);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-6194628 ^ (long)-6194505);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-567586268 ^ (long)-567586199);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1209680002 ^ (long)1209679872);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-2087538267 ^ (long)-2087538230);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1187705557 ^ (long)1187705579);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)492465391 ^ (long)492465354);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-746651347 ^ (long)-746651293);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1323217948 ^ (long)-1323217970);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1417486704 ^ (long)-1417486841);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)343147559 ^ (long)343147664);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1094748285 ^ (long)1094748381);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-210904263 ^ (long)-210904099);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1305606617 ^ (long)-1305606435);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-617077899 ^ (long)-617077850);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1739676516 ^ (long)-1739676653);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1563458977 ^ (long)-1563458820);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-188348326 ^ (long)-188348245);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1673309293 ^ (long)-1673309360);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)655888488 ^ (long)655888398);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-810605980 ^ (long)-810605927);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-411431191 ^ (long)-411431263);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1148785818 ^ (long)1148785881);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1093892966 ^ (long)1093893098);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1906339452 ^ (long)-1906339361);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1691973065 ^ (long)1691973066);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1490577328 ^ (long)-1490577161);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1910961188 ^ (long)-1910961258);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-86440459 ^ (long)-86440457);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1274302992 ^ (long)-1274303084);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)585888064 ^ (long)585888244);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1628651431 ^ (long)1628651289);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)912005355 ^ (long)912005278);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1225265544 ^ (long)-1225265426);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1872183395 ^ (long)1872183383);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)338179516 ^ (long)338179414);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-745995948 ^ (long)-745996032);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)12400069 ^ (long)12399888);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-661667841 ^ (long)-661667986);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1787422087 ^ (long)1787422076);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1437945603 ^ (long)-1437945722);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1235753503 ^ (long)-1235753585);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1526649432 ^ (long)-1526649600);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)498279217 ^ (long)498279345);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1528611260 ^ (long)1528611178);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1536396678 ^ (long)1536396622);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1081957877 ^ (long)-1081957877);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-806993280 ^ (long)-806993394);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-316668890 ^ (long)-316668798);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)816524084 ^ (long)816524255);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-518234554 ^ (long)-518234402);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1597730897 ^ (long)-1597730986);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1302844486 ^ (long)-1302844466);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1471314264 ^ (long)1471314273);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1205033953 ^ (long)1205033971);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1807043308 ^ (long)1807043185);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-830984558 ^ (long)-830984524);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-117432411 ^ (long)-117432336);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1855811615 ^ (long)-1855811587);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1807122164 ^ (long)-1807122103);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1538935148 ^ (long)1538935082);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-246865345 ^ (long)-246865164);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-32947962 ^ (long)-32947792);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1446082300 ^ (long)1446082099);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1858895464 ^ (long)-1858895555);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1212802117 ^ (long)1212802107);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1732779070 ^ (long)1732779047);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1931312025 ^ (long)1931312024);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1809165193 ^ (long)-1809165217);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)907716474 ^ (long)907716395);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)381640164 ^ (long)381640021);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-325905272 ^ (long)-325905367);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)788267230 ^ (long)788267011);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1892803062 ^ (long)-1892802836);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1417631386 ^ (long)1417631322);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)2115747068 ^ (long)2115746956);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1985974473 ^ (long)-1985974379);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-114147982 ^ (long)-114148010);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)406105512 ^ (long)406105439);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1704064281 ^ (long)-1704064287);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1006991938 ^ (long)-1006991947);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)920607351 ^ (long)920607280);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)215917770 ^ (long)215917669);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)862401784 ^ (long)862401690);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-769292760 ^ (long)-769292600);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1827986831 ^ (long)1827986894);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1752672109 ^ (long)-1752672054);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1890486204 ^ (long)-1890486166);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1187380391 ^ (long)1187380309);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-486395404 ^ (long)-486395637);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1954883870 ^ (long)1954884093);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-408314600 ^ (long)-408314513);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1302350437 ^ (long)-1302350553);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)997226711 ^ (long)997226637);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-982256331 ^ (long)-982256348);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-632486006 ^ (long)-632485963);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-929160273 ^ (long)-929160312);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1438570038 ^ (long)-1438570180);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1805385066 ^ (long)1805385017);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)909449335 ^ (long)909449220);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1273373492 ^ (long)1273373527);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-537132404 ^ (long)-537132352);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1734684195 ^ (long)-1734684175);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)468157838 ^ (long)468157731);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)233680874 ^ (long)233680835);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1002015520 ^ (long)1002015539);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-153086117 ^ (long)-153086099);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1277742071 ^ (long)1277742036);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1890041839 ^ (long)1890041738);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-279188407 ^ (long)-279188316);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1179344697 ^ (long)-1179344776);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)746810625 ^ (long)746810773);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-859262180 ^ (long)-859262159);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-622375355 ^ (long)-622375351);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1934389229 ^ (long)1934389141);
                    if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-543045837 ^ (long)-543045834);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1073644301 ^ (long)-1073644532)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)2001819829 ^ (long)2001839946)) >>> (int)((long)-472901164 ^ (long)-472901156)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)2135355841 ^ (long)2135355841);
            if (!7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1886288049 ^ (long)-1886288051);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1702231324 ^ (long)-1702231321) | var5_6 << (int)((long)682281125 ^ (long)682281120)) ^ var3_4[var7_8]) & (int)((long)980808185 ^ (long)980807942);
                    if (7I.\u200e\u2005\u200c\u2005\u2008\u200d\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1760485717 ^ (long)1760485718) | var6_7 << (int)((long)-1485901024 ^ (long)-1485901019)) ^ var3_4[var7_8]) & (int)((long)1136909497 ^ (long)1136909382);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7I.e[var2_3] = new String(var3_4).intern();
        }
        return 7I.e[var2_3];
    }

    public 7I() {
        boolean bl = \u200e\u2005\u200c\u2005\u2008\u200d\u2004;
        super(7I.b((int)((long)-717211714 ^ (long)-717206431), (int)((long)-1491601858 ^ (long)-1491631157)) /* "No Rotate" */, 7I.b((int)((long)883583480 ^ (long)883560998), (int)((long)-547856887 ^ (long)547866458)) /* "Discards Server Rotation Packets" */);
        Predicate[] predicateArray = new Predicate[(int)((long)-1747561830 ^ (long)-1747561829)];
        Class[] classArray = new Class[(int)((long)-227746666 ^ (long)-227746665)];
        classArray[(int)((long)-1023954754 ^ (long)-1023954754)] = qk.class;
        predicateArray[(int)((long)-1823183500 ^ (long)-1823183500)] = new 34s(classArray);
        this.0 = new Listener(i -> {
            boolean bl = \u200e\u2005\u200c\u2005\u2008\u200d\u2004;
            if (bl || bl) return;
            if (i.2 != EventState.PRE) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            Object object = (qk)i.7;
            Set set = object.h();
            if (bl || bl) return;
            this.1 = Float.valueOf(object.e());
            if (bl || bl) return;
            this.9 = Float.valueOf(object.f());
            if (bl || bl) return;
            if (set.contains(qk.a.d)) {
                if (bl || bl) return;
                this.1 = Float.valueOf(this.1.floatValue() + 7I.3.s.p);
                if (bl) return;
            }
            if (bl) return;
            if (set.contains(qk.a.e)) {
                if (bl || bl) return;
                this.9 = Float.valueOf(this.9.floatValue() + 7I.3.s.q);
                if (bl) return;
            }
            if (bl) return;
            set.removeIf(a2 -> {
                boolean bl = \u200e\u2005\u200c\u2005\u2008\u200d\u2004;
                if (bl || bl) return true;
                if (a2.ordinal() > (int)((long)-345322749 ^ (long)-345322751)) {
                    if (bl) return true;
                    return (int)((long)360973859 ^ (long)360973858) != 0;
                }
                if (!bl) return (int)((long)-850690137 ^ (long)-850690137) != 0;
                return true;
            });
            if (bl || bl) return;
            object = (AccessorSPlayerPositionLookPacket)i.7;
            object.setYaw(7I.3.s.p);
            if (bl || bl) return;
            object.setPitch(7I.3.s.q);
            if (!bl && !bl) return;
        }, predicateArray);
        Predicate[] predicateArray2 = new Predicate[(int)((long)-366477237 ^ (long)-366477238)];
        Class[] classArray2 = new Class[(int)((long)1331317071 ^ (long)1331317070)];
        classArray2[(int)((long)-792859667 ^ (long)-792859667)] = st.b.class;
        predicateArray2[(int)((long)-1147783438 ^ (long)-1147783438)] = new 34k(classArray2);
        this.6 = new Listener(object -> {
            block5: {
                block2: {
                    boolean bl;
                    block4: {
                        block3: {
                            bl = \u200e\u2005\u200c\u2005\u2008\u200d\u2004;
                            if (bl || bl) break block2;
                            object = (AccessorCPlayerPacket)((3u)((Object)((Object)object))).7;
                            if (bl || bl) break block2;
                            if (this.1 == null) break block3;
                            if (bl || bl) break block2;
                            object.setYaw(this.1.floatValue());
                            if (bl || bl) break block2;
                            this.1 = null;
                            if (bl) break block2;
                        }
                        if (bl) break block2;
                        if (this.9 == null) break block4;
                        if (bl || bl) break block2;
                        object.setPitch(this.9.floatValue());
                        if (bl || bl) break block2;
                        this.9 = null;
                        if (bl) break block2;
                    }
                    if (!bl) break block5;
                }
                return;
            }
        }, predicateArray2);
    }
}

