/* ==========================================================================
 * MODULE: Ignite
 * CATEGORY (inferred): Combat
 * DESCRIPTION: Lights players around you on fire if you have flint n' steel on your hotbar
 * OBFUSCATED CLASS: net.impactclient.0k
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aot
 *  aqm
 *  baritone.api.utils.Rotation
 *  baritone.api.utils.RotationUtils
 *  blq
 *  bmb
 *  btr
 *  dcj
 *  dcl
 *  dcl$a
 *  dcn
 *  dzm
 *  fx
 *  gc
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  oj
 *  tj
 *  tq
 *  ts
 */
package net.impactclient;

import baritone.api.utils.Rotation;
import baritone.api.utils.RotationUtils;
import clientapi.load.mixin.7.2;
import java.lang.invoke.LambdaMetafactory;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1A;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.34J;
import net.impactclient.34L;
import net.impactclient.34X;
import net.impactclient.34c;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.49;
import net.impactclient.4X;
import net.impactclient.4t;
import net.impactclient.66;
import net.impactclient.6b;
import net.impactclient.8H;
import net.impactclient.94;
import net.impactclient.9V;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0k
extends 3X
implements 49 {
    private 8H 7;
    private 4t 1;
    private 1P 9X;
    private 1K 5;
    private float 4;
    private 1P 0;
    private static final String[] e;
    @EventHandler
    private final Listener<4X> 93;
    private float 9;
    private 1P 9B;
    private 1P 6;
    private 1P 9d;
    private boolean 2;
    private List<aqm> 8;
    private 1P 9F;
    private 1P 91;
    public static final boolean \u2005\u2008\u2003\u2009;
    private 1A 9I;
    private 1P 9M;
    private static final String[] d;
    private int 9a;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0k.\u2005\u2008\u2003\u2009;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-185119899 ^ (long)185127096)) & (int)((long)327008526 ^ (long)326975217);
            if (var9_2) ** GOTO lbl-1000
            if (0k.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0k.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-654404843 ^ (long)-654404843)] & (int)((long)-2054233865 ^ (long)-2054234104)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)72582092 ^ (long)72582113);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1108624309 ^ (long)1108624135);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-362069027 ^ (long)-362069164);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-354761195 ^ (long)-354761156);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1944912323 ^ (long)1944912134);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)192264096 ^ (long)192264060);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1233048425 ^ (long)-1233048493);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-233025317 ^ (long)-233025367);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-288598687 ^ (long)-288598711);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-475266396 ^ (long)-475266412);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)798011287 ^ (long)798011210);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1264458849 ^ (long)-1264458925);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1018209542 ^ (long)-1018209710);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-478428494 ^ (long)-478428566);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)911393073 ^ (long)911393043);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1721418929 ^ (long)1721418953);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-373922307 ^ (long)-373922353);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1404162877 ^ (long)1404162925);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-838775334 ^ (long)-838775381);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)869652567 ^ (long)869652699);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-374590391 ^ (long)-374590449);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)2015988654 ^ (long)2015988520);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)593846038 ^ (long)593846121);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1699552020 ^ (long)1699552170);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1413258517 ^ (long)-1413258630);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1594284989 ^ (long)-1594284881);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1398604684 ^ (long)-1398604577);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1777495011 ^ (long)-1777494820);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1839541712 ^ (long)-1839541628);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1587048400 ^ (long)1587048392);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1115751765 ^ (long)1115751693);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)689439496 ^ (long)689439708);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-406631361 ^ (long)-406631278);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1309502136 ^ (long)1309502041);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1744574115 ^ (long)1744574101);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)605480092 ^ (long)605479966);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)892985471 ^ (long)892985460);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1348765867 ^ (long)1348765949);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1709097609 ^ (long)-1709097489);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)162810531 ^ (long)162810538);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-469444524 ^ (long)-469444460);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1033425926 ^ (long)-1033426159);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1321429089 ^ (long)1321429036);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-663185337 ^ (long)-663185285);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)572444278 ^ (long)572444245);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1935754414 ^ (long)-1935754365);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1029715492 ^ (long)-1029715536);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1654581532 ^ (long)1654581591);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-290073060 ^ (long)-290072897);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-865447412 ^ (long)-865447202);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-146790285 ^ (long)-146790314);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)592375151 ^ (long)592375295);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-392630732 ^ (long)-392630605);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1570010106 ^ (long)1570009859);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)2045301646 ^ (long)2045301643);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1885056225 ^ (long)-1885056065);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)200140067 ^ (long)200140185);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-621319604 ^ (long)-621319581);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1548763150 ^ (long)1548763307);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1352444341 ^ (long)-1352444221);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1731451044 ^ (long)1731451098);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)132407775 ^ (long)132407577);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1383713200 ^ (long)1383713047);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1198502913 ^ (long)-1198503118);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1802945538 ^ (long)-1802945704);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-174102514 ^ (long)-174102423);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1665929164 ^ (long)-1665929077);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1720641129 ^ (long)-1720641161);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)377866163 ^ (long)377866137);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)2050367355 ^ (long)2050367360);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-2105840506 ^ (long)-2105840472);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1555995272 ^ (long)-1555995364);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-734222168 ^ (long)-734222257);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-477657891 ^ (long)-477657936);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-484587768 ^ (long)-484587674);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)988743847 ^ (long)988743918);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)250158151 ^ (long)250158166);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-495940836 ^ (long)-495940713);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-947459938 ^ (long)-947460079);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1810169255 ^ (long)-1810169249);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-670208867 ^ (long)-670208923);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-330306169 ^ (long)-330306104);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1146422791 ^ (long)1146422971);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-838619464 ^ (long)-838619630);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1901704319 ^ (long)1901704307);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1168062587 ^ (long)1168062702);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-612148772 ^ (long)-612148962);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1529378214 ^ (long)-1529378098);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-633218824 ^ (long)-633219054);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1774549723 ^ (long)1774549537);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-2094120138 ^ (long)-2094119959);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1616372452 ^ (long)-1616372231);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1167812645 ^ (long)1167812854);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-290943006 ^ (long)-290942980);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)221598466 ^ (long)221598527);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1162973077 ^ (long)-1162972990);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)2013141514 ^ (long)2013141725);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)507625759 ^ (long)507625784);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)796219960 ^ (long)796220074);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1866517715 ^ (long)-1866517676);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)120898623 ^ (long)120898633);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)233889476 ^ (long)233889287);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1117770437 ^ (long)-1117770271);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1604387182 ^ (long)-1604387179);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)211835760 ^ (long)211835860);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-2088654778 ^ (long)-2088654755);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1241106958 ^ (long)-1241107045);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-146247685 ^ (long)-146247681);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1459320499 ^ (long)1459320518);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-249948953 ^ (long)-249949058);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-238307713 ^ (long)-238307632);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)124701444 ^ (long)124701529);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-723071986 ^ (long)-723071918);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)729366244 ^ (long)729366190);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1879513251 ^ (long)-1879513112);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)864957148 ^ (long)864957099);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1387046230 ^ (long)-1387046236);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-607492997 ^ (long)-607493061);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-19883014 ^ (long)-19883253);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-132960370 ^ (long)-132960297);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1027486082 ^ (long)1027486036);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1289443163 ^ (long)1289443115);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)347181301 ^ (long)347181230);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)291092607 ^ (long)291092524);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-344503657 ^ (long)-344503788);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1511751911 ^ (long)1511751800);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1081027977 ^ (long)1081028085);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1834314483 ^ (long)-1834314246);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1491984931 ^ (long)1491984968);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-716229542 ^ (long)-716229568);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1975855973 ^ (long)-1975856048);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1820487159 ^ (long)1820486921);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-238510811 ^ (long)-238510832);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1240825558 ^ (long)1240825350);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)691103195 ^ (long)691103129);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1193106211 ^ (long)1193106349);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)780005893 ^ (long)780006113);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)505782564 ^ (long)505782745);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)2061492920 ^ (long)2061492907);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1363354800 ^ (long)1363354677);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1755203600 ^ (long)1755203745);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-643490155 ^ (long)-643490289);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)482012763 ^ (long)482012828);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1068103520 ^ (long)1068103486);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1059152933 ^ (long)-1059153009);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1895502546 ^ (long)-1895502452);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-508966845 ^ (long)-508966747);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-362506648 ^ (long)-362506695);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)879940640 ^ (long)879940712);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)12991398 ^ (long)12991280);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1882760313 ^ (long)-1882760359);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-658614162 ^ (long)-658614150);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1754087549 ^ (long)1754087654);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-986017733 ^ (long)-986017702);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)705839932 ^ (long)705839876);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-844734785 ^ (long)-844734747);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-79238149 ^ (long)-79238380);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1009049163 ^ (long)-1009049273);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)412368280 ^ (long)412368168);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-2004710338 ^ (long)-2004710340);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1468292837 ^ (long)1468292822);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)2095202 ^ (long)2095252);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1942935801 ^ (long)1942935653);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1518374359 ^ (long)1518374390);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-2101498137 ^ (long)-2101498164);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1989776457 ^ (long)-1989776586);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-283328821 ^ (long)-283328962);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-329864636 ^ (long)-329864620);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1207357516 ^ (long)1207357659);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-516986511 ^ (long)-516986460);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1025726660 ^ (long)-1025726574);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)11570918 ^ (long)11570751);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)74232613 ^ (long)74232613);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1874941817 ^ (long)-1874941757);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1442496338 ^ (long)1442496463);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-865176900 ^ (long)-865176877);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-149264433 ^ (long)-149264483);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1327912992 ^ (long)1327913154);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)212654147 ^ (long)212654128);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-461609156 ^ (long)-461609084);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1232991454 ^ (long)-1232991281);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-841394642 ^ (long)-841394613);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)864218782 ^ (long)864218736);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1956948197 ^ (long)1956948139);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1114318226 ^ (long)-1114318293);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1371755216 ^ (long)-1371755219);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-2060052581 ^ (long)-2060052709);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)876425533 ^ (long)876425719);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1447314243 ^ (long)-1447314210);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1784573778 ^ (long)-1784573835);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1999406776 ^ (long)-1999406777);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-955392519 ^ (long)-955392762);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1280873487 ^ (long)-1280873528);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)10904673 ^ (long)10904645);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1832878039 ^ (long)1832877974);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1425820861 ^ (long)1425820904);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1954699475 ^ (long)1954699449);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1489812502 ^ (long)1489812513);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)890758790 ^ (long)890758816);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1133214295 ^ (long)-1133214331);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1331475203 ^ (long)-1331475299);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1065106508 ^ (long)-1065106555);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1480214958 ^ (long)-1480214935);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)372110054 ^ (long)372109944);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1777273604 ^ (long)1777273618);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1110557435 ^ (long)-1110557382);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1049978225 ^ (long)1049978235);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1533366772 ^ (long)-1533366759);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-670453821 ^ (long)-670453918);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1449655392 ^ (long)1449655351);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)527322689 ^ (long)527322677);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1529915858 ^ (long)1529915745);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1049350081 ^ (long)-1049349966);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1806499123 ^ (long)-1806499118);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1876816228 ^ (long)1876816153);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1953453816 ^ (long)1953453735);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-451032704 ^ (long)-451032602);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-743425806 ^ (long)-743426046);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-567636524 ^ (long)-567636656);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)726903941 ^ (long)726903823);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1135872077 ^ (long)1135872078);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1374269174 ^ (long)1374269068);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-611317061 ^ (long)-611317081);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)24689822 ^ (long)24689804);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1463795155 ^ (long)-1463794983);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)58221235 ^ (long)58221136);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1576599779 ^ (long)1576599646);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1687704538 ^ (long)-1687704343);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1300033754 ^ (long)-1300033654);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1086203086 ^ (long)-1086203073);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)390428294 ^ (long)390428357);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-665376524 ^ (long)-665376584);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)918044005 ^ (long)918044150);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-74555562 ^ (long)-74555496);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)602784687 ^ (long)602784534);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-678213560 ^ (long)-678213377);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1027215067 ^ (long)1027215042);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1921557976 ^ (long)1921557986);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1305701058 ^ (long)-1305701066);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1392744429 ^ (long)-1392744344);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1769668455 ^ (long)1769668367);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1384371473 ^ (long)1384371672);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)116818629 ^ (long)116818547);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1585079532 ^ (long)1585079301);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1043358478 ^ (long)1043358694);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-2094502004 ^ (long)-2094501960);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)728581539 ^ (long)728581471);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-6302897 ^ (long)-6302888);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1340841712 ^ (long)1340841528);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)791295079 ^ (long)791294981);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)542897266 ^ (long)542897228);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1474237503 ^ (long)1474237471);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1186067215 ^ (long)1186067452);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)289171648 ^ (long)289171591);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-397893211 ^ (long)-397893212);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1150734024 ^ (long)1150733939);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)464676886 ^ (long)464677097)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-584477116 ^ (long)-584488517)) >>> (int)((long)1821828005 ^ (long)1821828013)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1988496765 ^ (long)1988496765);
            if (!0k.\u2005\u2008\u2003\u2009) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-926552092 ^ (long)-926552090);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1620495316 ^ (long)1620495319) | var5_6 << (int)((long)406286321 ^ (long)406286324)) ^ var3_4[var7_8]) & (int)((long)-1319335384 ^ (long)-1319335209);
                    if (0k.\u2005\u2008\u2003\u2009) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)760573472 ^ (long)760573475) | var6_7 << (int)((long)1194041452 ^ (long)1194041449)) ^ var3_4[var7_8]) & (int)((long)351742800 ^ (long)351742895);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0k.e[var2_3] = new String(var3_4).intern();
        }
        return 0k.e[var2_3];
    }

    public 0k() {
        boolean bl = \u2005\u2008\u2003\u2009;
        super(0k.b((int)((long)593200816 ^ (long)-593224349), (int)((long)-82442643 ^ (long)82416264)) /* "Ignite" */, 0k.b((int)((long)-1526377450 ^ (long)1526386624), (int)((long)-1545342805 ^ (long)1545345404)) /* "Lights players around you on fire if you have flint n' steel on your hotbar" */);
        Comparable<Boolean> comparable = Boolean.TRUE;
        34J j2 = (34X)((34X)((34X)this.4().5(0k.b((int)((long)69573554 ^ (long)-69599123), (int)((long)-901567870 ^ (long)901567810)) /* "Swing" */)).7(0k.b((int)((long)-245289278 ^ (long)245282052), (int)((long)-543139233 ^ (long)-543138885)) /* "swing" */)).1(0k.b((int)((long)-250846138 ^ (long)250871711), (int)((long)1323741112 ^ (long)1323743600)) /* "Whether or not you swing your arm when you place blocks" */);
        ((34X)((34X)((34X)this.4().5(0k.b((int)((long)69573554 ^ (long)-69599123), (int)((long)-901567870 ^ (long)901567810)) /* "Swing" */)).7(0k.b((int)((long)-245289278 ^ (long)245282052), (int)((long)-543139233 ^ (long)-543138885)) /* "swing" */)).1(0k.b((int)((long)-250846138 ^ (long)250871711), (int)((long)1323741112 ^ (long)1323743600)) /* "Whether or not you swing your arm when you place blocks" */)).7 = comparable;
        this.9M = (1P)j2.5();
        comparable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0k.b((int)((long)-877999612 ^ (long)878006744), (int)((long)403648541 ^ (long)403651280)) /* "Teammates" */)).7(0k.b((int)((long)-1391664235 ^ (long)1391687757), (int)((long)1301326755 ^ (long)-1301334669)) /* "team" */)).1(0k.b((int)((long)980506424 ^ (long)-980497167), (int)((long)1983902021 ^ (long)1983897527)) /* "Target teammates" */);
        ((34X)((34X)((34X)this.4().5(0k.b((int)((long)-877999612 ^ (long)878006744), (int)((long)403648541 ^ (long)403651280)) /* "Teammates" */)).7(0k.b((int)((long)-1391664235 ^ (long)1391687757), (int)((long)1301326755 ^ (long)-1301334669)) /* "team" */)).1(0k.b((int)((long)980506424 ^ (long)-980497167), (int)((long)1983902021 ^ (long)1983897527)) /* "Target teammates" */)).7 = comparable;
        this.91 = (1P)j2.5();
        comparable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0k.b((int)((long)1375253874 ^ (long)-1375261012), (int)((long)409095227 ^ (long)409080380)) /* "Invisible" */)).7(0k.b((int)((long)-1908720159 ^ (long)1908712994), (int)((long)386550251 ^ (long)386551376)) /* "invis" */)).1(0k.b((int)((long)-327177154 ^ (long)327170042), (int)((long)102422297 ^ (long)-102407261)) /* "Target invisible entities" */);
        ((34X)((34X)((34X)this.4().5(0k.b((int)((long)1375253874 ^ (long)-1375261012), (int)((long)409095227 ^ (long)409080380)) /* "Invisible" */)).7(0k.b((int)((long)-1908720159 ^ (long)1908712994), (int)((long)386550251 ^ (long)386551376)) /* "invis" */)).1(0k.b((int)((long)-327177154 ^ (long)327170042), (int)((long)102422297 ^ (long)-102407261)) /* "Target invisible entities" */)).7 = comparable;
        this.6 = (1P)j2.5();
        comparable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0k.b((int)((long)-1625124676 ^ (long)1625099120), (int)((long)-711118066 ^ (long)711101555)) /* "Sleeping" */)).7(0k.b((int)((long)1486556365 ^ (long)-1486579961), (int)((long)-213614191 ^ (long)-213600131)) /* "sleeping" */)).1(0k.b((int)((long)1184707058 ^ (long)-1184716238), (int)((long)-478143085 ^ (long)-478140797)) /* "Target entities that are sleeping" */);
        ((34X)((34X)((34X)this.4().5(0k.b((int)((long)-1625124676 ^ (long)1625099120), (int)((long)-711118066 ^ (long)711101555)) /* "Sleeping" */)).7(0k.b((int)((long)1486556365 ^ (long)-1486579961), (int)((long)-213614191 ^ (long)-213600131)) /* "sleeping" */)).1(0k.b((int)((long)1184707058 ^ (long)-1184716238), (int)((long)-478143085 ^ (long)-478140797)) /* "Target entities that are sleeping" */)).7 = comparable;
        this.9B = (1P)j2.5();
        comparable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0k.b((int)((long)1660961375 ^ (long)-1660954211), (int)((long)-1118710334 ^ (long)-1118725126)) /* "Friends" */)).7(0k.b((int)((long)-1334836788 ^ (long)1334811149), (int)((long)-2049191766 ^ (long)-2049206237)) /* "friends" */)).1(0k.b((int)((long)1368075254 ^ (long)-1368084423), (int)((long)924916831 ^ (long)924917953)) /* "Target entities that are tagged as a friend" */);
        ((34X)((34X)((34X)this.4().5(0k.b((int)((long)1660961375 ^ (long)-1660954211), (int)((long)-1118710334 ^ (long)-1118725126)) /* "Friends" */)).7(0k.b((int)((long)-1334836788 ^ (long)1334811149), (int)((long)-2049191766 ^ (long)-2049206237)) /* "friends" */)).1(0k.b((int)((long)1368075254 ^ (long)-1368084423), (int)((long)924916831 ^ (long)924917953)) /* "Target entities that are tagged as a friend" */)).7 = comparable;
        this.9X = (1P)j2.5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(0k.b((int)((long)-1256971506 ^ (long)1256962268), (int)((long)726680795 ^ (long)-726689554)) /* "Player" */)).7(0k.b((int)((long)-1217144678 ^ (long)1217151809), (int)((long)1659041751 ^ (long)-1659042617)) /* "player" */)).1(0k.b((int)((long)133757808 ^ (long)-133734216), (int)((long)-755618016 ^ (long)755607025)) /* "Target player entities" */);
        ((34X)((34X)((34X)this.4().5(0k.b((int)((long)-1256971506 ^ (long)1256962268), (int)((long)726680795 ^ (long)-726689554)) /* "Player" */)).7(0k.b((int)((long)-1217144678 ^ (long)1217151809), (int)((long)1659041751 ^ (long)-1659042617)) /* "player" */)).1(0k.b((int)((long)133757808 ^ (long)-133734216), (int)((long)-755618016 ^ (long)755607025)) /* "Target player entities" */)).7 = comparable;
        this.0 = (1P)j2.5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(0k.b((int)((long)918105268 ^ (long)-918112411), (int)((long)-1123429932 ^ (long)1123426022)) /* "Hostile" */)).7(0k.b((int)((long)189171222 ^ (long)-189194805), (int)((long)-1135165352 ^ (long)1135159896)) /* "hostile" */)).1(0k.b((int)((long)-1296064809 ^ (long)1296041218), (int)((long)-1447371796 ^ (long)1447377733)) /* "Target hostile entities" */);
        ((34X)((34X)((34X)this.4().5(0k.b((int)((long)918105268 ^ (long)-918112411), (int)((long)-1123429932 ^ (long)1123426022)) /* "Hostile" */)).7(0k.b((int)((long)189171222 ^ (long)-189194805), (int)((long)-1135165352 ^ (long)1135159896)) /* "hostile" */)).1(0k.b((int)((long)-1296064809 ^ (long)1296041218), (int)((long)-1447371796 ^ (long)1447377733)) /* "Target hostile entities" */)).7 = comparable;
        this.9d = (1P)j2.5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(0k.b((int)((long)-780919032 ^ (long)780895427), (int)((long)-1146220180 ^ (long)1146194286)) /* "Passive" */)).7(0k.b((int)((long)1602232489 ^ (long)-1602241708), (int)((long)654802667 ^ (long)-654785688)) /* "passive" */)).1(0k.b((int)((long)-1917483973 ^ (long)1917460449), (int)((long)-633861757 ^ (long)633841944)) /* "Target passive entities" */);
        ((34X)((34X)((34X)this.4().5(0k.b((int)((long)-780919032 ^ (long)780895427), (int)((long)-1146220180 ^ (long)1146194286)) /* "Passive" */)).7(0k.b((int)((long)1602232489 ^ (long)-1602241708), (int)((long)654802667 ^ (long)-654785688)) /* "passive" */)).1(0k.b((int)((long)-1917483973 ^ (long)1917460449), (int)((long)-633861757 ^ (long)633841944)) /* "Target passive entities" */)).7 = comparable;
        this.9F = (1P)j2.5();
        comparable = 3.0;
        j2 = ((34e)((34e)((34e)this.7().5(0k.b((int)((long)-288406722 ^ (long)288413930), (int)((long)-90063501 ^ (long)90052523)) /* "Range" */)).7(0k.b((int)((long)-138810504 ^ (long)138834111), (int)((long)2067771048 ^ (long)2067774550)) /* "range" */)).1(0k.b((int)((long)1093199618 ^ (long)-1093174059), (int)((long)587042883 ^ (long)-587049099)) /* "Distance that targets will be attacked from" */)).3(2.0).2(6.0);
        ((34e)((34e)((34e)this.7().5(0k.b((int)((long)-288406722 ^ (long)288413930), (int)((long)-90063501 ^ (long)90052523)) /* "Range" */)).7(0k.b((int)((long)-138810504 ^ (long)138834111), (int)((long)2067771048 ^ (long)2067774550)) /* "range" */)).1(0k.b((int)((long)1093199618 ^ (long)-1093174059), (int)((long)587042883 ^ (long)-587049099)) /* "Distance that targets will be attacked from" */)).3(2.0).2(6.0).7 = comparable;
        this.5 = (1K)((34e)j2).5();
        comparable = Float.valueOf(360.0f);
        j2 = ((34e)((34e)((34e)this.9().5(0k.b((int)((long)-2087962356 ^ (long)2087953116), (int)((long)-863325862 ^ (long)-863315138)) /* "FOV" */)).7(0k.b((int)((long)385662152 ^ (long)-385669363), (int)((long)906443632 ^ (long)906434644)) /* "fov" */)).1(0k.b((int)((long)2054909572 ^ (long)-2054884023), (int)((long)263913477 ^ (long)-263943188)) /* "FOV that entities must be in to be targeted" */)).3(Float.valueOf(10.0f)).2(Float.valueOf(360.0f));
        ((34e)((34e)((34e)this.9().5(0k.b((int)((long)-2087962356 ^ (long)2087953116), (int)((long)-863325862 ^ (long)-863315138)) /* "FOV" */)).7(0k.b((int)((long)385662152 ^ (long)-385669363), (int)((long)906443632 ^ (long)906434644)) /* "fov" */)).1(0k.b((int)((long)2054909572 ^ (long)-2054884023), (int)((long)263913477 ^ (long)-263943188)) /* "FOV that entities must be in to be targeted" */)).3(Float.valueOf(10.0f)).2(Float.valueOf(360.0f)).7 = comparable;
        this.9I = (1A)((34e)j2).5();
        this.7 = new 8H();
        this.93 = new Listener(this::7, new Predicate[(int)((long)1905590537 ^ (long)1905590537)]);
        2R.1(this, 0k.b((int)((long)1778493419 ^ (long)-1778500571), (int)((long)-1948157672 ^ (long)-1948168159)) /* "imprem" */, Boolean.TRUE);
        this.1 = 94.0(this);
    }

    /*
     * Unable to fully structure code
     */
    private /* synthetic */ void 7(4X var1_1) {
        block24: {
            block22: {
                block23: {
                    var6_2 = 0k.\u2005\u2008\u2003\u2009;
                    if (var6_2) lbl-1000:
                    // 5 sources

                    {
                        return;
                    }
                    var3_3 = (int)((long)238042455 ^ (long)238042455);
                    var2_5 = 3e.5();
                    if (var6_2) ** GOTO lbl-1000
                    do {
                        if (var6_2) ** GOTO lbl-1000
                        if (var3_3 >= (int)((long)1660356603 ^ (long)1660356594)) break;
                        if (var6_2 || var6_2) ** GOTO lbl-1000
                        v0 = ((bmb)0k.3.s.bm.a.get(var3_3)).b() instanceof blq;
                        if (var2_5 != null) break block22;
                        if (v0 != 0) {
                            if (!var6_2 && !var6_2) ** break;
                            ** continue;
                            v1 = var3_3;
                            if (0k.\u2005\u2008\u2003\u2009) {
                                throw null;
                            }
                            break block23;
                        }
                        ++var3_3;
                    } while (var2_5 == null);
                    v1 = (int)((long)1984655489 ^ (long)-1984655490);
                }
                v0 = var3_3 = v1;
            }
            if (v0 < 0) {
                return;
            }
            v2 = new 4t[(int)((long)-271866065 ^ (long)-271866066)];
            v2[(int)((long)-963057993 ^ (long)-963057993)] = this.1;
            this.8 = 94.6(this.5.1, this.9I.9, v2).6();
            if (this.8.size() <= 0) {
                return;
            }
            if (this.9a < 0 || this.9a >= this.8.size()) {
                this.9a = (int)((long)-404488051 ^ (long)-404488051);
            }
            if ((var4_6 = this.8.get(this.9a)) == null) break block24;
            var5_7 = 0k.3.r.d_((fx)(var4_6 = new fx(var4_6.cA())));
            if (!(var5_7.b() instanceof btr)) {
                if (!var5_7.q()) {
                    RotationUtils.reachable((dzm)0k.3.s, (fx)var4_6, (double)0k.3.q.c()).ifPresent((Consumer<Rotation>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, 5(fx net.impactclient.4X baritone.api.utils.Rotation ), (Lbaritone/api/utils/Rotation;)V)((0k)this, (fx)var4_6, (4X)var1_1));
                }
                return;
            }
            if (this.2) {
                34L.1();
                this.2 = (int)((long)-1028536349 ^ (long)-1028536349);
            }
            var4_6 = var4_6.c();
            switch (6b.9[var1_1.7.ordinal()]) {
                case 1: {
                    0k.3.s.e.a((oj)new tj(var3_3));
                    this.9 = (float)66.4();
                    this.4 = (float)66.4();
                    var3_4 = 66.3(66.5((fx)var4_6).7(this.9, 1.0, this.4));
                    var1_1.6(var3_4.6).2(var3_4.3);
                    if (!0k.\u2005\u2008\u2003\u2009) break;
                    throw null;
                }
                case 2: {
                    0k.3.s.e.a((oj)new ts(aot.a, new dcj(new dcn((double)this.9, 1.0, (double)this.4), gc.b, (fx)var4_6, (boolean)((long)31699002 ^ (long)31699002))));
                    if (!this.9M.2) ** GOTO lbl61
                    0k.3.s.a(aot.a);
                    if (var2_5 == null) ** GOTO lbl62
lbl61:
                    // 2 sources

                    0k.3.s.e.a((oj)new tq(aot.a));
lbl62:
                    // 2 sources

                    0k.3.s.e.a((oj)new tj(0k.3.s.bm.d));
                }
            }
        }
        if (this.7.4(4.0f)) {
            if ((this.9a += (int)((long)1947988404 ^ (long)1947988405)) >= this.8.size() - (int)((long)-888304077 ^ (long)-888304078)) {
                this.9a = (int)((long)190863643 ^ (long)190863643);
            }
            this.7.0();
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0k.\u2005\u2008\u2003\u2009;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-878184228 ^ (long)-878184195)];
            if (var7) break block23;
            var3_2 = (int)((long)1440336535 ^ (long)1440336535);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\uce77\ue6be\uf52a\ufd49\uce77\ue6b5\uf5a4\ufd63\uce0b\ue623\uf50c\ufda8\ucee7\ue6be\uf523\ufdab\uce9e\ue607\uf5f0\ufd49\uce14\ue6d3\uf56f\ufd63\ucefa\ue656\uf59b\ufd68\ucefe\ue62a\uf5cb\ufd39\uce41\ue635\uf548\ufd9b\uce8b\ue66f\uf51e\ufd1d\uce37\ue67b\uf54e\ufd46\uce26\ue69c\uf54d\ufd82\uce7a\ue6e0\uf5d6\ufd57\uce3e\ue648\uf5ff\ufd29\uce7b\ue61c\uf529\ufd12\uce24\ue6c2\uf58d\ufdf5\uceb6\ue6e5\uf538\ufdcf\uce53\ue684\uf56d\ufde4\uce09\ue640\uf5a8\ufded\ucec6\ue625\uf542\ufdd3\uce8c\ue658\uf5d5\ufdf4\uce81\ue6c5\uf577\ufd32\uced8\ue606\uf590\ufd01\uced3\ue689\uf518\ufd42\ucef7\ue64d\uf5a3\ufde2\uce1a\ue615\uf591\ufdff\ucec4\ue6d8\uf50f\ufd8b\uceeb\ue6ca\uf5c3\ufd2b\uce0b\ue617\uf5c8\ufd05\ucef0\ue63f\uf586\ufd32\uce5c\ue6c2\uf5cd\ufd93\ucefd\ue615\uf523\ufd03\uce92\ue647\uf5c5\ufd78\uceb2\ue6ac\uf5e6\ufdfc\uce67\ue6ed\uf5b8\ufd5a\ucea7\ue6d4\uf56c\ufd4f\uce01\ue66d\uf566\ufd66\uce88\ue607\uf500\ufd43\uce2c\ue64f\uf58d\ufd41\uce87\ue63f\uf59d\ufdbf\uce89\ue669\uf574\ufdbf\uced2\ue650\uf5d3\ufdf2\uce21\ue690\uf553\ufd01\uceb8\ue607\uf580\ufd70\uce49\ue6e5\uf5b8\ufd8e\uceaf\ue6ff\uf5f6\ufdba\uceee\ue66a\uf5a7\ufd75\uce8b\ue63f\uf583\ufd95\uce69\ue6ca\uf501\ufdb4\uce3c\ue6f0\uf52f\ufd21\uce44\ue6fb\uf5f8\ufd3b\ucea6\ue67b\uf565\ufd56\uce97\ue6cf\uf5af\ufdb2\uce9b\ue64f\uf596\ufdc3\ucede\ue657\uf55c\ufd69\uced7\ue69f\uf590\ufdc7\uce7c\ue65c\uf5f9\ufd07\uceec\ue616\uf502\ufd72\uce27\ue658\uf52f\ufd1d\ucef2\ue66a\uf5d0\ufd0d\ucef2\ue6b1\uf5e2\ufd73\uce2e\ue6fb\uf5a4\ufd58\uceb4\ue6b5\uf55d\ufd4a\uce72\ue64c\uf50f\ufdff\ucec0\ue6b4\uf555\ufd5b\uce05\ue6ef\uf581\ufd0b\uce99\ue630\uf5d5\ufd95\uce0b\ue645\uf5d3\ufdef\ucec0\ue66b\uf58a\ufd6d\uce26\ue65a\uf524\ufdd5\uceb6\ue626\uf59c\ufd69\uce54\ue6a7\uf580\ufd6c\uce13\ue6a8\uf5be\ufd9f\uce46\ue6d8\uf518\ufd00\uce09\ue621\uf57c\ufd6f\ucee1\ue629\uf51f\ufdaa\uce61\ue6de\uf50a\ufdf8\uce39\ue63f\uf5b1\ufd07\uce31\ue65b\uf52e\ufd23\uce99\ue6c8\uf5d6\ufd98\uceec\ue648\uf545\ufdf2\ucee6\ue6dc\uf558\ufdf6\ucee1\ue637\uf5a1\ufd67\uce25\ue63b\uf58a\ufd49\ucebc\ue6a5\uf529\ufd43\uce42\ue637\uf575\ufd8c\uce41\ue60a\uf51a\ufd39\uce45\ue6ae\uf5df\ufd1a\uce08\ue651\uf535\ufd6a\uce31\ue6fb\uf5c9\ufd45\uce8c\ue6e2\uf5f7\ufd40\uce19\ue6cf\uf563\ufdbb\uce10\ue671\uf510\ufd38\uce03\ue69a\uf5b3\ufdf8\uce9c\ue67a\uf569\ufd3b\uced6\ue628\uf52c\ufd7b\uce18\ue69a\uf52f\ufdb9\ucef8\ue6f9\uf59a\ufd6d\uce22\ue6f6\uf549\ufde8\ucee0\ue681\uf518\ufdfd\uce85\ue691\uf5c7\ufd4a\ucee3\ue612\uf5b5\ufd9a\uce40\ue674\uf59f\ufd1e\ucef9\ue67c\uf585\ufd6b\uce59\ue64b\uf548\ufd1b\uce50\ue6d9\uf508\ufdf5\uce85\ue608\uf55f\ufd3b\uce5e\ue62d\uf5b8\ufdbb\uce52\ue6e2\uf5ac\ufd17\uce9f\ue68a\uf542\ufd93\ucecf\ue6fa\uf516\ufd06\uce84\ue605\uf5f7\ufd32\uce8d\ue675\uf50b\ufdaa\ucea3\ue60a\uf578\ufdec\uce2d\ue614\uf5d2\ufd4d\ucea9\ue6bb\uf51d\ufdc1\uce47\ue6fe\uf507\ufd59\ucefa\ue69d\uf5b0\ufd89\ucea3\ue67b\uf51e\ufd73\uceab\ue6a9\uf570\ufd77\uce92\ue6f7\uf5e2\ufd40\ucebd\ue644\uf5c8\ufd84\ucee6\ue68e\uf591\ufd8e\ucec9\ue6bc\uf5f5\ufdba\uced9\ue697\uf51b\ufdbe\uce13\ue6b9\uf550\ufd77\ucecb\ue6e4\uf587\ufd20\ucee4\ue628\uf5f3\ufd13\uceed\ue66a\uf55c\ufd9e\uceec\ue68c\uf5a0\ufdbe\ucefa\ue6ae\uf530\ufd77\ucece\ue6c9\uf52d\ufd5a\uce3f\ue638\uf56e\ufdff\uce96\ue631\uf5b0\ufd26\uce64\ue6d5\uf5f8\ufd9d\uce84\ue606\uf5d2\ufd1f\uce07\ue6c6\uf51b\ufdd6\uce09\ue6f2\uf52e\ufdf6", -18487125);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1765213213 ^ (long)1765213210);
            if (var7) break block23;
            var0_6 = (int)((long)763667431 ^ (long)-763667432);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1051354464 ^ (long)1051354374);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1593920437 ^ (long)-1593920438);
                    if (0k.\u2005\u2008\u2003\u2009) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0k.\u2005\u2008\u2003\u2009) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u02a3\u2a99\u39e1\u31a2\u02f0\u2a53\u3905\u310b\u02f1\u2a4a\u3941\u31bf\u02ba\u2a36\u39bd", 840574157);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)779424249 ^ (long)779424254);
                            var0_6 = (int)((long)-1031396908 ^ (long)1031396907);
                            while (true) {
                                v0 = (int)((long)1703184240 ^ (long)1703184212);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1380151465 ^ (long)1380151465);
                                if (!0k.\u2005\u2008\u2003\u2009) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0k.\u2005\u2008\u2003\u2009) ** continue;
                                throw null;
                            }
                            0k.d = var5_1;
                            0k.e = new String[(int)((long)536965354 ^ (long)536965323)];
                            if (!0k.\u2005\u2008\u2003\u2009) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1166339091 ^ (long)-1166339091);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1499184127 ^ (long)1499184126)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1966463658 ^ (long)1966463661)) {
                                case 0: {
                                    v15 = (int)((long)-1586173741 ^ (long)-1586173754);
                                    if (!0k.\u2005\u2008\u2003\u2009) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-2000676250 ^ (long)-2000676263);
                                    if (!0k.\u2005\u2008\u2003\u2009) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1406557198 ^ (long)1406557267);
                                    if (!0k.\u2005\u2008\u2003\u2009) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)2139956468 ^ (long)2139956475);
                                    if (!0k.\u2005\u2008\u2003\u2009) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1823736318 ^ (long)1823736246);
                                    if (!0k.\u2005\u2008\u2003\u2009) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-759624689 ^ (long)-759624703);
                                    if (!0k.\u2005\u2008\u2003\u2009) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-347003517 ^ (long)-347003444);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0k.\u2005\u2008\u2003\u2009);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 5(fx fx2, 4X x, Rotation object) {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2005\u2008\u2003\u2009;
                    if (bl || bl) break block2;
                    9V v = 66.7(((2)0k.3.s).getRotations(), new 9V(object.getYaw(), object.getPitch()));
                    dcl dcl2 = 34c.5(v.6, v.3, (int)((long)507053480 ^ (long)507053450));
                    if (dcl2.c() != dcl.a.b) break block3;
                    if (bl || bl) break block2;
                    dcl2 = (dcj)dcl2;
                    if (bl || bl) break block2;
                    if (!fx2.equals((Object)dcl2.a())) break block3;
                    if (bl || bl) break block2;
                    34L.4(fx2, dcl2.b(), (boolean)((long)-1184761183 ^ (long)-1184761184));
                    if (bl || bl) break block2;
                    this.2 = (int)((long)-626063997 ^ (long)-626063998);
                    if (bl || bl) break block2;
                    x.6(v.6).2(v.3);
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }
}

