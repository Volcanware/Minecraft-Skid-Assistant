/* ==========================================================================
 * MODULE: Anti Aim
 * CATEGORY (inferred): Combat
 * DESCRIPTION: Makes your head move around
 * OBFUSCATED CLASS: net.impactclient.0C
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1m;
import net.impactclient.2w$6X;
import net.impactclient.34f;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3s0;
import net.impactclient.4X;
import net.impactclient.5j;
import net.impactclient.61;
import net.impactclient.6a;
import net.impactclient.9V;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0C
extends 3X
implements 3s0 {
    private static final String[] d;
    @EventHandler
    private final Listener<4X> 9;
    private 1m<61> 4;
    public static final boolean \u200c\u2009;
    private 1m<6a> 1;
    private final 9V 6;
    private static final String[] e;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0C.\u200c\u2009;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)339107591 ^ (long)339107599)];
            if (var7) break block23;
            var3_2 = (int)((long)2112036699 ^ (long)2112036699);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u9cec\ub413\ua7ba\uaf33\u9c3b\ub4f6\ua7c5\uaf25\u9c7f\ub43f\ua7cb\uafd7\u9c59\ub4fb\ua790\uaf8b\u9ce4\ub426\ua7e8\uaf3f\u9c98\ub49a\ua77a\uaf7f\u9c02\ub402\ua745\uaf72\u9cc4\ub4c9\ua71e\uaf67\u9c48\ub41c\ua741\uafe9\u9c7a\ub408\ua7ea\uaff4\u9c95\ub4c7\ua7c9\uafa9\u9c2e\ub4c7\ua768\uafd9\u9c0d\ub470\ua722\uafa4\u9c53\ub44d\ua78f\uaff0\u9c8c\ub4d3\ua70a\uaf40\u9c96\ub41a\ua7c1\uafb2\u9c41\ub46d\ua778\uaf62\u9c83\ub497\ua763\uafce\u9cc5\ub4e5\ua75f\uaf61\u9cf7\ub40d\ua718\uaf0f\u9cb8\ub4c1\ua74c\uaf81\u9c9e\ub498\ua74c\uaf85\u9ca7", -1498957130);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-69530971 ^ (long)-69530946);
            if (var7) break block23;
            var0_6 = (int)((long)1134950690 ^ (long)-1134950691);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)43662402 ^ (long)43662341);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1290738222 ^ (long)-1290738223);
                    if (0C.\u200c\u2009) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0C.\u200c\u2009) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u0f93\u272b\u34c8\u3cd9\u0fd5\u2748\u343e\u3cb2\u0f9f\u2767\u340e\u3ce8", 1426598307);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1658733136 ^ (long)-1658733128);
                            var0_6 = (int)((long)-1286603962 ^ (long)1286603961);
                            while (true) {
                                v0 = (int)((long)-251258844 ^ (long)-251258859);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1952057752 ^ (long)1952057752);
                                if (!0C.\u200c\u2009) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0C.\u200c\u2009) ** continue;
                                throw null;
                            }
                            0C.d = var5_1;
                            0C.e = new String[(int)((long)-1161285679 ^ (long)-1161285671)];
                            if (!0C.\u200c\u2009) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1169282679 ^ (long)-1169282679);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-260901416 ^ (long)-260901415)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1418197113 ^ (long)-1418197120)) {
                                case 0: {
                                    v15 = (int)((long)-511864942 ^ (long)-511864848);
                                    if (!0C.\u200c\u2009) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)366260509 ^ (long)366260501);
                                    if (!0C.\u200c\u2009) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-324690620 ^ (long)-324690627);
                                    if (!0C.\u200c\u2009) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)363072532 ^ (long)363072599);
                                    if (!0C.\u200c\u2009) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1304232466 ^ (long)1304232546);
                                    if (!0C.\u200c\u2009) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-528803190 ^ (long)-528803131);
                                    if (!0C.\u200c\u2009) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-942624797 ^ (long)-942624842);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0C.\u200c\u2009);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0C.\u200c\u2009;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)329275448 ^ (long)329257291)) & (int)((long)1298766371 ^ (long)1298752988);
            if (var9_2) ** GOTO lbl-1000
            if (0C.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0C.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)789172680 ^ (long)789172680)] & (int)((long)-1444624299 ^ (long)-1444624214)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1018386870 ^ (long)1018386867);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1750242641 ^ (long)-1750242779);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1200307999 ^ (long)1200308169);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)655578893 ^ (long)655579007);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1012086509 ^ (long)1012086425);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)245613396 ^ (long)245613458);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-581221485 ^ (long)-581221422);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1693985303 ^ (long)1693985344);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)903322538 ^ (long)903322519);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1253825912 ^ (long)1253825901);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1531061799 ^ (long)-1531061848);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-234801724 ^ (long)-234801721);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)771556976 ^ (long)771556949);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-377685232 ^ (long)-377685038);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)905412089 ^ (long)905411928);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1479714704 ^ (long)-1479714658);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)416688686 ^ (long)416688762);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1289564949 ^ (long)1289565181);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-601670976 ^ (long)-601671064);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)725568811 ^ (long)725568809);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1528242310 ^ (long)-1528242258);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)864681934 ^ (long)864681966);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1249321774 ^ (long)-1249321977);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1656594654 ^ (long)-1656594565);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)727354693 ^ (long)727354782);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-2131853043 ^ (long)-2131853001);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-749645627 ^ (long)-749645775);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-2022658324 ^ (long)-2022658381);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1613663457 ^ (long)1613663462);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-2067155160 ^ (long)-2067154985);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1408128714 ^ (long)-1408128730);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1232903430 ^ (long)1232903530);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)2019064611 ^ (long)2019064763);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-866279364 ^ (long)-866279358);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1031068093 ^ (long)1031068068);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)106937247 ^ (long)106937309);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1499345611 ^ (long)-1499345631);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-2013552 ^ (long)-2013662);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1757778067 ^ (long)-1757778075);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1633979792 ^ (long)1633979812);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1353676210 ^ (long)-1353676137);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)2011330080 ^ (long)2011330193);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)2025861770 ^ (long)2025861782);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1596119204 ^ (long)1596119257);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1099639053 ^ (long)1099639274);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1669529934 ^ (long)1669530081);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)2045321622 ^ (long)2045321706);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)46490513 ^ (long)46490517);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1346099875 ^ (long)1346099930);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)642759780 ^ (long)642759876);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1117543752 ^ (long)1117543885);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-108155747 ^ (long)-108155753);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)2021058542 ^ (long)2021058553);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-448550156 ^ (long)-448550253);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-266548953 ^ (long)-266548792);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-124190240 ^ (long)-124190379);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1222493202 ^ (long)1222493209);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1792186879 ^ (long)-1792186818);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)901195449 ^ (long)901195503);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1001710752 ^ (long)1001710637);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)484486347 ^ (long)484486189);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-158886361 ^ (long)-158886367);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1702578436 ^ (long)-1702578443);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1866208876 ^ (long)-1866208975);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1176777687 ^ (long)-1176777578);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-520951827 ^ (long)-520951973);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-183329702 ^ (long)-183329674);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-910310766 ^ (long)-910310816);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)328970695 ^ (long)328970734);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1321907645 ^ (long)-1321907600);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-581870720 ^ (long)-581870833);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1217160615 ^ (long)1217160529);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-534187736 ^ (long)-534187678);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1708420109 ^ (long)1708420143);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1524999376 ^ (long)1524999260);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1831025925 ^ (long)-1831026081);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-68054008 ^ (long)-68053776);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1134496061 ^ (long)1134496234);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1760250955 ^ (long)1760251048);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)2138112056 ^ (long)2138112143);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1040424413 ^ (long)1040424247);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1179489108 ^ (long)-1179489258);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1377106377 ^ (long)-1377106320);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)54332618 ^ (long)54332518);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1949439893 ^ (long)-1949439754);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)123473773 ^ (long)123473862);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1961736726 ^ (long)1961736813);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1764841404 ^ (long)-1764841341);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1732577712 ^ (long)-1732577744);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1858417883 ^ (long)1858417910);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-906303915 ^ (long)-906303992);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)21387695 ^ (long)21387772);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-180852381 ^ (long)-180852322);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1859522832 ^ (long)-1859522885);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)2010544146 ^ (long)2010544366);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1814205915 ^ (long)-1814205706);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)298028071 ^ (long)298028150);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)905896473 ^ (long)905896561);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)596755746 ^ (long)596755722);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)541640744 ^ (long)541640763);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1947498542 ^ (long)1947498497);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-793145395 ^ (long)-793145506);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-969721415 ^ (long)-969721386);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1397525317 ^ (long)1397525301);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1938441486 ^ (long)-1938441720);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)676027922 ^ (long)676028115);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-279446268 ^ (long)-279446029);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-487906881 ^ (long)-487907002);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-984985798 ^ (long)-984985761);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-386551056 ^ (long)-386551084);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-132507145 ^ (long)-132507256);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1898697292 ^ (long)1898697374);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1216899072 ^ (long)-1216898914);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)58965706 ^ (long)58965759);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-575717184 ^ (long)-575717342);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1346063285 ^ (long)-1346063238);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1326534048 ^ (long)1326534017);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-492381254 ^ (long)-492381400);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)384889825 ^ (long)384889692);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1616801408 ^ (long)1616801423);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1537469492 ^ (long)-1537469636);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-585999517 ^ (long)-585999437);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)979060932 ^ (long)979060768);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1495474788 ^ (long)-1495474743);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1378045295 ^ (long)-1378045224);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1742149162 ^ (long)-1742149213);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1856308925 ^ (long)1856308898);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-220437256 ^ (long)-220437483);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)17700535 ^ (long)17700368);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1824250820 ^ (long)-1824250805);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-2042212736 ^ (long)-2042212707);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1769154128 ^ (long)1769154224);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)893953354 ^ (long)893953417);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)250117832 ^ (long)250117819);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-377662031 ^ (long)-377662082);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)159914768 ^ (long)159914970);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-99132645 ^ (long)-99132434);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1347545901 ^ (long)-1347545971);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1310196671 ^ (long)-1310196495);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)2137288280 ^ (long)2137288252);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-874517736 ^ (long)-874517551);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1004009639 ^ (long)1004009641);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-818138965 ^ (long)-818138927);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)806319769 ^ (long)806319686);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1797332304 ^ (long)1797332478);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1100521115 ^ (long)-1100521154);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)217673228 ^ (long)217673366);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1717655475 ^ (long)1717655351);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)910649886 ^ (long)910650013);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-55708633 ^ (long)-55708543);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-2038985677 ^ (long)-2038985694);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-962352350 ^ (long)-962352327);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1335098154 ^ (long)-1335098357);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-278374865 ^ (long)-278374714);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-720042140 ^ (long)-720042006);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)2089157384 ^ (long)2089157593);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1661480222 ^ (long)1661480371);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-356379645 ^ (long)-356379612);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1423974112 ^ (long)1423973977);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-500126213 ^ (long)-500126375);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1586575344 ^ (long)1586575280);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)2014635436 ^ (long)2014635364);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1988444492 ^ (long)1988444552);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-818305827 ^ (long)-818305929);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-344679027 ^ (long)-344679001);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1270433785 ^ (long)-1270433601);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1282312275 ^ (long)-1282312396);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1162993809 ^ (long)-1162993676);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1014848380 ^ (long)1014848346);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1264664305 ^ (long)-1264664107);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1220650659 ^ (long)1220650559);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1784382233 ^ (long)1784382254);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1135255666 ^ (long)1135255656);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-2006216068 ^ (long)-2006216142);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1410444122 ^ (long)1410444237);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)909230686 ^ (long)909230674);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1238312321 ^ (long)1238312376);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1195077671 ^ (long)-1195077838);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1708141718 ^ (long)-1708141786);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-378699451 ^ (long)-378699437);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1471793795 ^ (long)1471793824);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)503202502 ^ (long)503202469);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-18708524 ^ (long)-18708668);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)568214969 ^ (long)568214855);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)2143329911 ^ (long)2143329977);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1351166797 ^ (long)1351166966);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1502018821 ^ (long)-1502018949);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)657414421 ^ (long)657414486);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1274390379 ^ (long)-1274390389);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1864630139 ^ (long)1864630269);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1401300838 ^ (long)1401300952);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1076623744 ^ (long)-1076623635);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1786075811 ^ (long)1786075708);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1201963421 ^ (long)-1201963507);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)402178331 ^ (long)402178471);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1971842708 ^ (long)1971842764);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-2028859860 ^ (long)-2028859683);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1726438176 ^ (long)1726438230);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-232119169 ^ (long)-232119076);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-646301238 ^ (long)-646301433);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1715644626 ^ (long)-1715644485);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1304660558 ^ (long)-1304660557);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)596193085 ^ (long)596193195);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)965363767 ^ (long)965363959);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)564939818 ^ (long)564939974);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1735097100 ^ (long)1735097279);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-451505754 ^ (long)-451505870);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)799594230 ^ (long)799594189);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1275982023 ^ (long)1275981903);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)784768956 ^ (long)784768868);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1242308714 ^ (long)-1242308763);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)443702699 ^ (long)443702562);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1052002717 ^ (long)1052002779);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1136750010 ^ (long)1136750018);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-456368203 ^ (long)-456368143);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)16435445 ^ (long)16435292);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-879910803 ^ (long)-879910695);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-179583718 ^ (long)-179583649);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1008890129 ^ (long)-1008890348);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-467858433 ^ (long)-467858515);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)824471192 ^ (long)824471283);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1798803955 ^ (long)1798803768);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1580165579 ^ (long)-1580165449);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)996443083 ^ (long)996443012);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)593690917 ^ (long)593690948);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1833808677 ^ (long)-1833808701);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)305808950 ^ (long)305808976);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1361806836 ^ (long)-1361806707);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)31873334 ^ (long)31873388);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)624918372 ^ (long)624918358);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-769627118 ^ (long)-769627046);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-580110130 ^ (long)-580110172);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1687011849 ^ (long)1687011908);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1153027808 ^ (long)-1153027669);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-553295209 ^ (long)-553295191);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1087378658 ^ (long)-1087378635);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)2120999403 ^ (long)2120999221);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)351518844 ^ (long)351518741);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-253054571 ^ (long)-253054568);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1387319256 ^ (long)1387319286);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-989891178 ^ (long)-989891084);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-519180522 ^ (long)-519180409);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-202265283 ^ (long)-202265331);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-471344738 ^ (long)-471344702);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-531905556 ^ (long)-531905760);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)250173256 ^ (long)250173208);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1924820915 ^ (long)1924820897);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-152442885 ^ (long)-152443110);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1506473681 ^ (long)-1506473705);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1233872945 ^ (long)-1233872945);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1644482397 ^ (long)1644482401);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1370787659 ^ (long)1370787709);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)867509430 ^ (long)867509331);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1353649244 ^ (long)1353649280);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-2088880179 ^ (long)-2088880376);
                    if (!0C.\u200c\u2009) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1636335579 ^ (long)1636335452);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1883646745 ^ (long)-1883646952)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-524503717 ^ (long)-524531036)) >>> (int)((long)680633145 ^ (long)680633137)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1978480001 ^ (long)-1978480001);
            if (!0C.\u200c\u2009) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1556429553 ^ (long)-1556429555);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1558081823 ^ (long)-1558081822) | var5_6 << (int)((long)1100293923 ^ (long)1100293926)) ^ var3_4[var7_8]) & (int)((long)-851796081 ^ (long)-851796112);
                    if (0C.\u200c\u2009) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-2113653967 ^ (long)-2113653966) | var6_7 << (int)((long)496849304 ^ (long)496849309)) ^ var3_4[var7_8]) & (int)((long)1881304902 ^ (long)1881305017);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0C.e[var2_3] = new String(var3_4).intern();
        }
        return 0C.e[var2_3];
    }

    public 0C() {
        boolean bl = \u200c\u2009;
        super(0C.b((int)((long)-545974860 ^ (long)-545956671), (int)((long)-167891476 ^ (long)-167878922)) /* "Anti Aim" */, 0C.b((int)((long)1983520597 ^ (long)1983534630), (int)((long)182269905 ^ (long)-182266339)) /* "Makes your head move around" */);
        this.4 = (1m)((34f)((34f)((34f)this.2(61.class).5(0C.b((int)((long)-65121571 ^ (long)-65135703), (int)((long)948011074 ^ (long)948029746)) /* "Yaw" */)).7(0C.b((int)((long)-1906590491 ^ (long)-1906575980), (int)((long)1288437546 ^ (long)1288429476)) /* "yaw" */)).1(0C.b((int)((long)1767706558 ^ (long)1767720648), (int)((long)1831983725 ^ (long)-1831966446)) /* "The yaw anti aim type" */)).5();
        this.1 = (1m)((34f)((34f)((34f)this.2(6a.class).5(0C.b((int)((long)-23438239 ^ (long)-23456493), (int)((long)-1718685212 ^ (long)1718688726)) /* "Pitch" */)).7(0C.b((int)((long)154519698 ^ (long)154501605), (int)((long)836649558 ^ (long)836636503)) /* "pitch" */)).1(0C.b((int)((long)91111310 ^ (long)91125502), (int)((long)439533572 ^ (long)-439529344)) /* "The pitch anti aim type" */)).5();
        this.6 = new 9V();
        this.9 = new Listener(x2 -> {
            boolean bl = \u200c\u2009;
            if (bl) return;
            String[] stringArray = 3e.5();
            if (bl) return;
            if (bl) return;
            switch (5j.7[((61)((Object)((Object)this.4.0()))).ordinal()]) {
                case 1: {
                    if (bl) return;
                    this.6.6 = 0C.3.s.p;
                    if (bl) return;
                    if (bl) return;
                    if (stringArray == null) break;
                    if (bl) return;
                }
                case 2: {
                    if (bl) return;
                    this.6.6 = 0C.3.s.p - 180.0f;
                    if (bl) return;
                    if (bl) return;
                    if (stringArray == null) break;
                    if (bl) return;
                }
                case 3: {
                    float f;
                    if (bl) return;
                    if (0C.3.s.K % (int)((long)-1507741279 ^ (long)-1507741259) >= (int)((long)564897682 ^ (long)564897688)) {
                        f = 0C.3.s.p;
                        if (\u200c\u2009) {
                            throw null;
                        }
                    } else {
                        f = this.6.6 = 0C.3.s.p - 180.0f;
                    }
                    if (stringArray == null) break;
                }
                case 4: {
                    float f;
                    if (0C.3.s.K % (int)((long)-19395530 ^ (long)-19395532) == 0) {
                        f = 0C.3.s.p;
                        if (\u200c\u2009) {
                            throw null;
                        }
                    } else {
                        f = this.6.6 = 0C.3.s.p - 180.0f;
                    }
                    if (stringArray == null) break;
                }
                case 5: {
                    this.6.6 += 10.0f;
                    if (stringArray == null) break;
                }
                case 6: {
                    this.6.6 += 20.0f;
                    if (stringArray == null) break;
                }
                case 7: {
                    this.6.6 = this.6.6 - (float)Math.random() * 360.0f + 180.0f;
                    break;
                }
            }
            switch (5j.4[((6a)((Object)((Object)this.1.0()))).ordinal()]) {
                case 1: {
                    this.6.3 = 0C.3.s.q;
                    if (stringArray == null) break;
                }
                case 2: {
                    this.6.3 = -90.0f;
                    if (stringArray == null) break;
                }
                case 3: {
                    this.6.3 = 90.0f;
                    if (stringArray == null) break;
                }
                case 4: {
                    this.6.3 = (float)Math.random() * 180.0f - 90.0f;
                    break;
                }
            }
            x2.6(this.6.6).2(this.6.3);
        }, (byte)((long)738708500 ^ (long)738708501), new Predicate[(int)((long)835932712 ^ (long)835932712)]);
    }
}

