/* ==========================================================================
 * MODULE: Elytra+
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Eases elytra
 * OBFUSCATED CLASS: net.impactclient.0A
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqa
 *  aqf
 *  bld
 *  blm
 *  bmb
 *  bmd
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  oj
 *  org.apache.logging.log4j.Level
 *  ta
 *  ta$a
 */
package net.impactclient;

import java.lang.invoke.LambdaMetafactory;
import java.util.List;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.2w;
import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.34X;
import net.impactclient.3X;
import net.impactclient.4f;
import net.impactclient.4s;
import net.impactclient.5y;
import net.impactclient.5z;
import net.impactclient.7m;
import net.impactclient.7o;
import net.impactclient.7r;
import net.impactclient.8H;
import net.impactclient.9N;
import org.apache.logging.log4j.Level;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0A
extends 3X
implements 34B {
    public double 8;
    private 1P 4;
    private final 9N<Integer> 1;
    @EventHandler
    private final Listener<4f> 5;
    private 8H 7;
    private static final String[] e;
    public static final boolean \u2001\u2007\u2003\u2004;
    private 8H 2;
    private 1P 6;
    private static final 2w<bmb> 0;
    private static final String[] d;

    private static /* synthetic */ boolean 0(bmb bmb2) {
        boolean bl = \u2001\u2007\u2003\u2004;
        if (bl || bl) {
            return true;
        }
        return bmb2.b() instanceof blm;
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0A.\u2001\u2007\u2003\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-231100011 ^ (long)231092053)) & (int)((long)809164625 ^ (long)809115822);
            if (var9_2) ** GOTO lbl-1000
            if (0A.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0A.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1230779247 ^ (long)-1230779247)] & (int)((long)-718954253 ^ (long)-718954484)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1983687442 ^ (long)-1983687673);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1253898534 ^ (long)1253898636);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1588244644 ^ (long)-1588244625);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)2124531006 ^ (long)2124531183);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-518070375 ^ (long)-518070363);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)176611340 ^ (long)176611453);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1690893612 ^ (long)-1690893656);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)682579962 ^ (long)682579903);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1211523108 ^ (long)-1211523244);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-968653591 ^ (long)-968653687);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1171949567 ^ (long)1171949367);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1031075243 ^ (long)-1031075145);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1880228711 ^ (long)1880228820);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1427132975 ^ (long)-1427132931);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)991870758 ^ (long)991870813);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1103510985 ^ (long)1103510973);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)271515385 ^ (long)271515184);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-825749440 ^ (long)-825749390);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-2006274473 ^ (long)-2006274540);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)543874430 ^ (long)543874359);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-757503424 ^ (long)-757503279);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-839016247 ^ (long)-839016258);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)409414363 ^ (long)409414366);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1433402500 ^ (long)1433402416);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1345130267 ^ (long)-1345130371);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1543782202 ^ (long)1543782154);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-345103566 ^ (long)-345103462);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1811973165 ^ (long)1811973162);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1478454714 ^ (long)-1478454681);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)861071508 ^ (long)861071572);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-940416359 ^ (long)-940416340);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)458455941 ^ (long)458455965);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1071699693 ^ (long)1071699483);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-873977250 ^ (long)-873977299);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1393055741 ^ (long)-1393055583);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1099523479 ^ (long)-1099523550);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1356182341 ^ (long)-1356182494);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)875462990 ^ (long)875462940);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)820673442 ^ (long)820673454);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1705423391 ^ (long)1705423484);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1531443331 ^ (long)1531443420);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-672381079 ^ (long)-672381075);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-2126283250 ^ (long)-2126283046);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-2014678521 ^ (long)-2014678341);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)2115003729 ^ (long)2115003859);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-303487232 ^ (long)-303487069);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-798657083 ^ (long)-798657214);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1719656470 ^ (long)-1719656518);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1591304047 ^ (long)1591304144);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1196806400 ^ (long)1196806655);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1061663346 ^ (long)-1061663434);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1168968015 ^ (long)-1168968001);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-127947942 ^ (long)-127947891);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1712899747 ^ (long)-1712899706);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1804868356 ^ (long)-1804868363);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1027178217 ^ (long)1027178020);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)546372997 ^ (long)546373005);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-726706923 ^ (long)-726706747);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-837913544 ^ (long)-837913402);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)261715528 ^ (long)261715667);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1959202802 ^ (long)1959202725);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)165908029 ^ (long)165908108);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)322700216 ^ (long)322700267);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1334428040 ^ (long)1334428042);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1524152601 ^ (long)-1524152645);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)244281701 ^ (long)244281724);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1571464790 ^ (long)-1571464945);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)812999473 ^ (long)812999665);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1698302014 ^ (long)-1698301982);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-216262216 ^ (long)-216262201);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1151676879 ^ (long)1151676843);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-751738999 ^ (long)-751739019);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)2049585304 ^ (long)2049585310);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1286772764 ^ (long)-1286772898);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-260244707 ^ (long)-260244613);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1889718293 ^ (long)1889718487);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-902859946 ^ (long)-902859876);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)2133254647 ^ (long)2133254558);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-692386690 ^ (long)-692386589);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1644641738 ^ (long)-1644641589);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1964983493 ^ (long)1964983510);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-221138764 ^ (long)-221138750);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1257467193 ^ (long)-1257467194);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-941614577 ^ (long)-941614552);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1252471790 ^ (long)-1252471667);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)761542096 ^ (long)761541901);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1480847869 ^ (long)-1480847629);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1133842237 ^ (long)1133842387);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1553418213 ^ (long)1553418123);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1471250917 ^ (long)1471250717);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1128402958 ^ (long)1128403158);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1020967037 ^ (long)-1020967056);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-885904623 ^ (long)-885904548);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1455070066 ^ (long)1455069991);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1530267453 ^ (long)1530267580);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)930294474 ^ (long)930294388);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)197599525 ^ (long)197599500);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1717451525 ^ (long)1717451691);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1951011708 ^ (long)-1951011632);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1584050683 ^ (long)-1584050527);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1375094818 ^ (long)1375094928);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)303236141 ^ (long)303236162);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)249420757 ^ (long)249420783);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1463793593 ^ (long)1463793530);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)2005645955 ^ (long)2005645882);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1666963994 ^ (long)-1666964144);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1545645865 ^ (long)1545645913);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1268749932 ^ (long)1268749936);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-212496222 ^ (long)-212496132);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-632511474 ^ (long)-632511320);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)613471179 ^ (long)613471176);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)2028468141 ^ (long)2028468103);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)246600656 ^ (long)246600514);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-2141629155 ^ (long)-2141628973);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-325306718 ^ (long)-325306849);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-153628749 ^ (long)-153628798);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1393216060 ^ (long)-1393216183);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1851838322 ^ (long)1851838218);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)936163686 ^ (long)936163646);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-548952694 ^ (long)-548952752);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1975157315 ^ (long)1975157487);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1216926730 ^ (long)-1216926861);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1899124947 ^ (long)1899124825);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-43646355 ^ (long)-43646385);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1026467268 ^ (long)-1026467244);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-821328492 ^ (long)-821328620);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1461333307 ^ (long)-1461333281);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-942896712 ^ (long)-942896842);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-197878910 ^ (long)-197878959);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)744133835 ^ (long)744133650);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1758976717 ^ (long)1758976696);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)2053504507 ^ (long)2053504439);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1745046419 ^ (long)1745046375);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)126583438 ^ (long)126583427);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1769803247 ^ (long)-1769803200);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)150208302 ^ (long)150208424);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-229091189 ^ (long)-229091155);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-158047491 ^ (long)-158047697);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)935965498 ^ (long)935965622);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-70641352 ^ (long)-70641192);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1890028695 ^ (long)-1890028617);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)251213860 ^ (long)251213984);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1316570001 ^ (long)1316570095);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1430144161 ^ (long)1430144186);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)352580972 ^ (long)352581103);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1318693169 ^ (long)-1318693136);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1761095841 ^ (long)-1761095915);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1983516762 ^ (long)1983516859);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1418868775 ^ (long)-1418868745);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1746158115 ^ (long)1746158311);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1162656371 ^ (long)1162656428);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)462432834 ^ (long)462432803);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1829682065 ^ (long)-1829682126);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)310732263 ^ (long)310732197);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)447786019 ^ (long)447785984);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-590325730 ^ (long)-590325759);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-408185696 ^ (long)-408185786);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-972558175 ^ (long)-972558153);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1817329366 ^ (long)1817329210);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)2079432336 ^ (long)2079432312);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)251082016 ^ (long)251082183);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)232253842 ^ (long)232253881);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)844569754 ^ (long)844569820);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-495434052 ^ (long)-495434047);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1588494772 ^ (long)-1588494777);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1045602520 ^ (long)1045602359);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1153618404 ^ (long)-1153618358);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1403783448 ^ (long)-1403783669);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-115551127 ^ (long)-115551067);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1044773912 ^ (long)1044773977);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1468516625 ^ (long)1468516652);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-465761854 ^ (long)-465762025);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-906798419 ^ (long)-906798403);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-240171198 ^ (long)-240171098);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)785305928 ^ (long)785306104);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1269660370 ^ (long)1269660341);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)252738208 ^ (long)252738276);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1601660392 ^ (long)-1601660410);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-967174332 ^ (long)-967174317);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)2001906669 ^ (long)2001906687);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)229374740 ^ (long)229374750);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)787943221 ^ (long)787943328);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1281324800 ^ (long)-1281324743);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)790283336 ^ (long)790283459);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-915376297 ^ (long)-915376262);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1973626626 ^ (long)1973626676);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-191403206 ^ (long)-191403177);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)2014248532 ^ (long)2014248462);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-262001895 ^ (long)-262001704);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-574167604 ^ (long)-574167801);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)2134332322 ^ (long)2134332231);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1526198424 ^ (long)1526198359);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-453161896 ^ (long)-453161790);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-927006326 ^ (long)-927006299);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1945573663 ^ (long)1945573771);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1425466116 ^ (long)-1425466174);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1790256913 ^ (long)1790257012);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-995792070 ^ (long)-995791985);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1462018709 ^ (long)1462018613);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1116883105 ^ (long)-1116883163);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-94859929 ^ (long)-94859832);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)919516175 ^ (long)919516313);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-682486861 ^ (long)-682486847);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-379674126 ^ (long)-379674179);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1207388188 ^ (long)1207388168);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-929429795 ^ (long)-929429892);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-866514623 ^ (long)-866514478);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1301716535 ^ (long)1301716536);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1737978278 ^ (long)-1737978211);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1278407955 ^ (long)-1278408169);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1087040780 ^ (long)1087040864);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1526508105 ^ (long)1526508191);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1323720703 ^ (long)-1323720505);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-758021160 ^ (long)-758021265);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-84006141 ^ (long)-84006039);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)597519942 ^ (long)597519917);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1474518296 ^ (long)-1474518296);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1087548522 ^ (long)1087548482);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-156409433 ^ (long)-156409572);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)925508883 ^ (long)925509044);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1551078051 ^ (long)1551078106);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-235254059 ^ (long)-235254115);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-754989913 ^ (long)-754989924);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1146357285 ^ (long)1146357390);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1555521803 ^ (long)1555521852);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)300805101 ^ (long)300805116);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-456494614 ^ (long)-456494712);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1199464241 ^ (long)-1199464214);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)84322316 ^ (long)84322450);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-437189686 ^ (long)-437189756);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1762344039 ^ (long)-1762343998);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1548907784 ^ (long)1548907924);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)881961360 ^ (long)881961323);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1434310030 ^ (long)1434309889);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1812264842 ^ (long)-1812264828);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1022876789 ^ (long)-1022876900);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)203417054 ^ (long)203417082);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-606326064 ^ (long)-606326147);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1846500224 ^ (long)-1846500168);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1403352676 ^ (long)-1403352703);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)399982378 ^ (long)399982557);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1249855361 ^ (long)1249855340);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)22116171 ^ (long)22116256);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-998929582 ^ (long)-998929653);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1350087355 ^ (long)-1350087296);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1889520733 ^ (long)1889520845);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1619523301 ^ (long)-1619523236);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1903714652 ^ (long)1903714773);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1052847893 ^ (long)1052848108);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-347116095 ^ (long)-347116076);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1577624778 ^ (long)-1577624673);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1945900930 ^ (long)-1945900982);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)695034650 ^ (long)695034863);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-728441883 ^ (long)-728442097);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-981850236 ^ (long)-981850251);
                    if (!0A.\u2001\u2007\u2003\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-153091177 ^ (long)-153091253);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1952866127 ^ (long)1952866224)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-81062432 ^ (long)-81008097)) >>> (int)((long)1294552012 ^ (long)1294552004)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1572304419 ^ (long)-1572304419);
            if (!0A.\u2001\u2007\u2003\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1661861725 ^ (long)-1661861727);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1816834167 ^ (long)-1816834166) | var5_6 << (int)((long)-46735225 ^ (long)-46735230)) ^ var3_4[var7_8]) & (int)((long)-1701747700 ^ (long)-1701747469);
                    if (0A.\u2001\u2007\u2003\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)251466341 ^ (long)251466342) | var6_7 << (int)((long)1605363766 ^ (long)1605363763)) ^ var3_4[var7_8]) & (int)((long)-1926544141 ^ (long)-1926544372);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0A.e[var2_3] = new String(var3_4).intern();
        }
        return 0A.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public 0A() {
        boolean bl = \u2001\u2007\u2003\u2004;
        super(0A.b((int)((long)-315257261 ^ (long)315232411), (int)((long)-102675387 ^ (long)-102668158)) /* "Elytra+" */, 0A.b((int)((long)149175489 ^ (long)-149184000), (int)((long)276411735 ^ (long)-276421558)) /* "Eases elytra" */);
        Boolean bl2 = Boolean.FALSE;
        34X x2 = (34X)((34X)((34X)this.4().5(0A.b((int)((long)-241402090 ^ (long)241426901), (int)((long)-55886206 ^ (long)-55884721)) /* "Auto Boost" */)).7(0A.b((int)((long)728997196 ^ (long)-729021562), (int)((long)-1160684601 ^ (long)1160702216)) /* "autoboost" */)).1(0A.b((int)((long)1394824827 ^ (long)-1394816837), (int)((long)452730098 ^ (long)-452732173)) /* "Automatically uses fireworks at a specific elevation" */);
        ((34X)((34X)((34X)this.4().5(0A.b((int)((long)-241402090 ^ (long)241426901), (int)((long)-55886206 ^ (long)-55884721)) /* "Auto Boost" */)).7(0A.b((int)((long)728997196 ^ (long)-729021562), (int)((long)-1160684601 ^ (long)1160702216)) /* "autoboost" */)).1(0A.b((int)((long)1394824827 ^ (long)-1394816837), (int)((long)452730098 ^ (long)-452732173)) /* "Automatically uses fireworks at a specific elevation" */)).7 = bl2;
        this.6 = (1P)x2.5();
        bl2 = Boolean.TRUE;
        x2 = (34X)((34X)((34X)this.4().5(0A.b((int)((long)1238024015 ^ (long)-1238031992), (int)((long)723625738 ^ (long)-723648425)) /* "Takeoff" */)).7(0A.b((int)((long)1685027910 ^ (long)-1685003644), (int)((long)115259464 ^ (long)-115251042)) /* "takeoff" */)).1(0A.b((int)((long)-325034088 ^ (long)325042526), (int)((long)448331688 ^ (long)-448331043)) /* "Eases taking off with the elytra" */);
        ((34X)((34X)((34X)this.4().5(0A.b((int)((long)1238024015 ^ (long)-1238031992), (int)((long)723625738 ^ (long)-723648425)) /* "Takeoff" */)).7(0A.b((int)((long)1685027910 ^ (long)-1685003644), (int)((long)115259464 ^ (long)-115251042)) /* "takeoff" */)).1(0A.b((int)((long)-325034088 ^ (long)325042526), (int)((long)448331688 ^ (long)-448331043)) /* "Eases taking off with the elytra" */)).7 = bl2;
        this.4 = (1P)x2.5();
        this.1 = 4s.6();
        this.2 = new 8H();
        this.7 = new 8H();
        this.5 = new Listener(f -> {
            boolean bl = \u2001\u2007\u2003\u2004;
            if (bl || bl) return;
            f = 0A.3.s.b(aqf.e);
            if (f.b() != bmd.qo) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            if (this.6.2) {
                if (bl) return;
                if (this.7.8(0x60AC1BCA586B9F42L ^ 0x60AC1BCA586B9686L)) {
                    if (bl) return;
                    if ((double)0A.3.s.cz() < this.8) {
                        if (bl || bl) return;
                        this.7.0();
                        if (bl || bl) return;
                        int n = 0.0((List<bmb>)0A.3.s.bm.a);
                        if (n < 0) {
                            if (bl || bl) return;
                            return;
                        }
                        if (bl) return;
                        this.1.accept(n);
                        if (bl || bl) return;
                        9.clickMouse((int)((long)1017281643 ^ (long)1017281642));
                        if (bl || bl) return;
                        this.1.8();
                        if (bl) return;
                    }
                }
            }
            if (bl) return;
            if (this.4.2) {
                if (bl) return;
                if (0A.3.s.f.g) {
                    if (bl) return;
                    if (bld.d((bmb)f)) {
                        if (bl || bl) return;
                        if (this.2.8(0xFC2E98096BA59938L ^ 0xFC2E98096BA59AD0L)) {
                            if (bl || bl) return;
                            0A.3.s.o((boolean)((long)1983955918 ^ (long)1983955918));
                            if (bl || bl) return;
                            0A.3.s.g((boolean)((long)-485855926 ^ (long)-485855925));
                            if (bl || bl) return;
                            0A.3.s.dK();
                            if (bl || bl) return;
                            this.2.0();
                            if (bl) return;
                        }
                        if (bl) return;
                        0A.3.s.e.a((oj)new ta((aqa)0A.3.s, ta.a.i));
                        if (bl) return;
                    }
                }
            }
            if (!bl) return;
        }, new Predicate[(int)((long)-43680616 ^ (long)-43680616)]);
        7m[] mArray = new 7m[(int)((long)247891330 ^ (long)247891328)];
        mArray[(int)((long)819494437 ^ (long)819494437)] = new 7r(this);
        mArray[(int)((long)-508446153 ^ (long)-508446154)] = new 7o(this);
        this.5(mArray);
        if (bl) return;
        try {
            if (bl) return;
            this.8 = Double.valueOf(5z.4().1G.5(0A.b((int)((long)-932920476 ^ (long)932928929), (int)((long)219391934 ^ (long)219392090)) /* "elytraheight" */, 0A.b((int)((long)-1773763168 ^ (long)1773738857), (int)((long)-1417733923 ^ (long)-1417716674)) /* "200" */));
            if (bl || bl) return;
            return;
        }
        catch (NumberFormatException numberFormatException) {
            if (bl || bl) return;
            5z.9.log(Level.WARN, 0A.b((int)((long)-635845739 ^ (long)635854161), (int)((long)-667391498 ^ (long)667411853)) /* "Unable to load the ElytraPlus height config option!" */);
            if (bl || bl) return;
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var9 = 0A.\u2001\u2007\u2003\u2004;
                if (!var9) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)-69531375 ^ (long)-69531366)];
            if (var9) break block25;
            var3_2 = (int)((long)-1619770800 ^ (long)-1619770800);
            if (var9) break block25;
            var2_3 = 2w$6X.KAOZ("\u36fd\u1eb2\u0d24\u0560\u362a\u1e06\u0da9\u05c9\u36bd\u1e19\u0db0\u0544\u367d\u1e92\u0d47\u056b\u3649\u1ee4\u0d60\u056b\u3680\u1efd\u0db9\u0594\u366c\u1e5a\u0d0e\u05ba\u36b5\u1e20\u0d60\u05eb\u36ae\u1e90\u0db3\u056b\u361f\u1e75\u0d27\u0581\u363a\u1e22\u0de8\u0540\u364a\u1e43\u0d7e\u054c\u36c2\u1ee5\u0d45\u05f6\u3654\u1efe\u0d9e\u0521\u3606\u1e69\u0d43\u05eb\u3672\u1ec6\u0d5d\u057e\u3609\u1ecb\u0dc4\u059f\u3616\u1e3c\u0d0b\u05a4\u3644\u1ec6\u0d5a\u05e3\u3649\u1e2f\u0d53\u05a9\u36e0\u1e18\u0d65\u0595\u366b\u1ee7\u0df7\u0502\u36c2\u1e42\u0d79\u0537\u36c0\u1ea6\u0d44\u05b8\u36fa\u1e7e\u0de1\u058f\u36b1\u1eb8\u0dcd\u0514\u36c6\u1e11\u0d87\u05d9\u36cb\u1e47\u0db5\u0545\u3658\u1e72\u0d78\u055b\u36b3\u1e44\u0db2\u051a\u36fb\u1e0d\u0d60\u0568\u3654\u1e00\u0d18\u05e0\u3676\u1efd\u0dfe\u050f\u363b\u1eaf\u0d86\u0538\u3654\u1e7c\u0d3a\u055f\u362f\u1eec\u0d14\u0577\u36f8\u1ee9\u0d37\u0593\u3620\u1eec\u0de9\u0505\u36bc\u1e6f\u0d59\u0588\u3683\u1e1c\u0d69\u05c7\u36b8\u1ef8\u0dfe\u0545\u36cf\u1e47\u0df5\u05b7\u36ca\u1ef2\u0d2d\u05a9\u36a5\u1e7c\u0d4f\u058c\u36b6\u1e02\u0dad\u05bb\u368e\u1e0b\u0dd7\u05b7\u3610\u1e46\u0d4e\u05e7\u3695\u1ec3\u0dd7\u0549\u365b\u1eb8\u0d9a\u0575\u363b\u1e62", 1215303781);
            var4_4 = var2_3.length();
            if (var9) break block25;
            var1_5 = (int)((long)937551450 ^ (long)937551470);
            if (var9) break block25;
            var0_6 = (int)((long)-1468874600 ^ (long)1468874599);
            if (var9) break block25;
            block11: while (!var9) {
                block22: {
                    block21: {
                        v0 = (int)((long)-617979822 ^ (long)-617979781);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)1399804230 ^ (long)-1399804231);
                        if (0A.\u2001\u2007\u2003\u2004) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!0A.\u2001\u2007\u2003\u2004) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\u8d7d\ua5ac\ub63d\ube03\u8d07\ua580\ub60f\ube76\u8d10\ua59a\ub64b\ubedf\u8dde", -1316574261);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)1433373582 ^ (long)1433373581);
                                var0_6 = (int)((long)-572545114 ^ (long)572545113);
                                while (true) {
                                    v0 = (int)((long)354886885 ^ (long)354886799);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)-598070087 ^ (long)-598070087);
                                    if (!0A.\u2001\u2007\u2003\u2004) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!0A.\u2001\u2007\u2003\u2004) ** continue;
                                    throw null;
                                }
                                0A.d = var5_1;
                                0A.e = new String[(int)((long)1786223295 ^ (long)1786223284)];
                                if (0A.\u2001\u2007\u2003\u2004) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)-793470545 ^ (long)-793470545);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)1556537291 ^ (long)1556537290)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)2124570010 ^ (long)2124570013)) {
                                    case 0: {
                                        v15 = (int)((long)-2021587485 ^ (long)-2021587527);
                                        if (!0A.\u2001\u2007\u2003\u2004) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)-649449912 ^ (long)-649449930);
                                        if (!0A.\u2001\u2007\u2003\u2004) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)1363026603 ^ (long)1363026609);
                                        if (!0A.\u2001\u2007\u2003\u2004) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)410763030 ^ (long)410763114);
                                        if (!0A.\u2001\u2007\u2003\u2004) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)-2066235711 ^ (long)-2066235659);
                                        if (!0A.\u2001\u2007\u2003\u2004) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)1163624213 ^ (long)1163624231);
                                        if (!0A.\u2001\u2007\u2003\u2004) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)-771874500 ^ (long)-771874507);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!0A.\u2001\u2007\u2003\u2004);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                v17 = new Predicate[(int)((long)1651148242 ^ (long)1651148243)];
                v17[(int)((long)-1425355638 ^ (long)-1425355638)] = (Predicate<bmb>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, 0(bmb ), (Lbmb;)Z)();
                var8_8 = v17;
                var7_9 = new 5y<T>();
                new 5y<T>().1 = var8_8;
                0A.0 = var7_9.7();
                break;
            }
        }
    }
}

