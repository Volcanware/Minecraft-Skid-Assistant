/* ==========================================================================
 * MODULE: Radar
 * CATEGORY (inferred): Render
 * DESCRIPTION: Displays a radar that reveals the location of entities
 * OBFUSCATED CLASS: net.impactclient.7W
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  aqa
 *  baritone.api.BaritoneAPI
 *  baritone.api.Settings
 *  baritone.api.behavior.IPathingBehavior
 *  baritone.api.pathing.calc.IPath
 *  baritone.api.pathing.calc.IPathFinder
 *  baritone.api.pathing.goals.GoalXZ
 *  baritone.api.pathing.path.IPathExecutor
 *  baritone.api.utils.interfaces.IGoalRenderPos
 *  bfw
 *  com.mojang.blaze3d.systems.RenderSystem
 *  dem
 *  dfm
 *  dku
 *  fx
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  org.lwjgl.opengl.GL11
 *  pw.knx.feather.tessellate.Tessellator
 */
package net.impactclient;

import baritone.api.BaritoneAPI;
import baritone.api.Settings;
import baritone.api.behavior.IPathingBehavior;
import baritone.api.pathing.calc.IPath;
import baritone.api.pathing.calc.IPathFinder;
import baritone.api.pathing.goals.GoalXZ;
import baritone.api.pathing.path.IPathExecutor;
import baritone.api.utils.interfaces.IGoalRenderPos;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.11;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.1z;
import net.impactclient.2R;
import net.impactclient.2q;
import net.impactclient.2w$6X;
import net.impactclient.345;
import net.impactclient.34H;
import net.impactclient.34J;
import net.impactclient.34L;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.3d;
import net.impactclient.3e;
import net.impactclient.4L;
import net.impactclient.5K;
import net.impactclient.8h;
import net.impactclient.9b;
import org.lwjgl.opengl.GL11;
import pw.knx.feather.tessellate.Tessellator;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7W
extends 3X
implements 8h {
    public static final boolean \u2000\u2003\u2005;
    private 1P 5;
    @EventHandler
    private final Listener<2q> 8F;
    private 1K 4;
    private 1P 1;
    private 1P 89;
    private 1P 9;
    private 1z 0;
    private 1P 2;
    private 1z 8f;
    private 1P 8B;
    private 11 6;
    private 1P 8;
    public 1z 7;
    private static final String[] d;
    private static final String[] e;

    public 7W() {
        boolean bl = \u2000\u2003\u2005;
        super(7W.b((int)((long)-1543691528 ^ (long)1543695756), (int)((long)1532154117 ^ (long)-1532155191)) /* "Radar" */, 7W.b((int)((long)-1550826744 ^ (long)1550814320), (int)((long)-1239903088 ^ (long)1239883207)) /* "Displays a radar that reveals the location of entities" */);
        String[] stringArray = new String[(int)((long)1086025516 ^ (long)1086025518)];
        stringArray[(int)((long)-1224135634 ^ (long)-1224135634)] = 7W.b((int)((long)-717899571 ^ (long)717911968), (int)((long)-885155074 ^ (long)885144924));
        stringArray[(int)((long)44010882 ^ (long)44010883)] = 7W.b((int)((long)162677176 ^ (long)-162689327), (int)((long)715622050 ^ (long)-715636173)) /* "Dynamic" */;
        Object object = stringArray;
        34J j2 = (34H)((34H)((34H)this.0().5(7W.b((int)((long)-910506218 ^ (long)910493795), (int)((long)-319387035 ^ (long)-319360090)) /* "Mode" */)).7(7W.b((int)((long)-932882281 ^ (long)932878301), (int)((long)-304478014 ^ (long)-304461197)) /* "mode" */)).1(7W.b((int)((long)230889778 ^ (long)-230893954), (int)((long)2104744290 ^ (long)2104736180)) /* "The Radar Style" */);
        ((34H)((34H)((34H)this.0().5(7W.b((int)((long)-910506218 ^ (long)910493795), (int)((long)-319387035 ^ (long)-319360090)) /* "Mode" */)).7(7W.b((int)((long)-932882281 ^ (long)932878301), (int)((long)-304478014 ^ (long)-304461197)) /* "mode" */)).1(7W.b((int)((long)230889778 ^ (long)-230893954), (int)((long)2104744290 ^ (long)2104736180)) /* "The Radar Style" */)).3 = object;
        this.6 = (11)j2.5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7W.b((int)((long)1663698624 ^ (long)-1663710814), (int)((long)1954810095 ^ (long)-1954810980)) /* "Path" */)).7(7W.b((int)((long)-1274486054 ^ (long)1274490275), (int)((long)-1022399655 ^ (long)-1022406933)) /* "path" */)).1(7W.b((int)((long)-807358598 ^ (long)807362573), (int)((long)1690487587 ^ (long)1690491532)) /* "Draws Baritone's current path" */);
        ((34X)((34X)((34X)this.4().5(7W.b((int)((long)1663698624 ^ (long)-1663710814), (int)((long)1954810095 ^ (long)-1954810980)) /* "Path" */)).7(7W.b((int)((long)-1274486054 ^ (long)1274490275), (int)((long)-1022399655 ^ (long)-1022406933)) /* "path" */)).1(7W.b((int)((long)-807358598 ^ (long)807362573), (int)((long)1690487587 ^ (long)1690491532)) /* "Draws Baritone's current path" */)).7 = object;
        this.9 = (1P)((34X)j2).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7W.b((int)((long)-1578359519 ^ (long)1578363471), (int)((long)183066126 ^ (long)183047960)) /* "Stipple" */)).7(7W.b((int)((long)712488232 ^ (long)-712476057), (int)((long)-901499831 ^ (long)-901499584)) /* "stipple" */)).1(7W.b((int)((long)111799724 ^ (long)-111795483), (int)((long)-440068107 ^ (long)440072013)) /* "Whether or not to stipple the path line" */);
        ((34X)((34X)((34X)this.4().5(7W.b((int)((long)-1578359519 ^ (long)1578363471), (int)((long)183066126 ^ (long)183047960)) /* "Stipple" */)).7(7W.b((int)((long)712488232 ^ (long)-712476057), (int)((long)-901499831 ^ (long)-901499584)) /* "stipple" */)).1(7W.b((int)((long)111799724 ^ (long)-111795483), (int)((long)-440068107 ^ (long)440072013)) /* "Whether or not to stipple the path line" */)).7 = object;
        this.2 = (1P)((34X)((34X)j2).3(this.9)).5();
        this.0 = (1z)((34e)((34e)((34e)((34e)this.1().5(7W.b((int)((long)-1538297914 ^ (long)1538302091), (int)((long)2027944104 ^ (long)-2027917796)) /* "Stipple Length" */)).7(7W.b((int)((long)1828172023 ^ (long)-1828159607), (int)((long)246749846 ^ (long)246750563)) /* "stippleLength" */)).1(7W.b((int)((long)-2131298409 ^ (long)2131310801), (int)((long)753668555 ^ (long)753695157)) /* "The length of each line segment when stipple is enabled" */)).3((int)((long)-1257323259 ^ (long)-1257323257)).2((int)((long)-1448548170 ^ (long)-1448548167)).3(this.9)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7W.b((int)((long)200599524 ^ (long)-200595298), (int)((long)114302834 ^ (long)114302433)) /* "Invisible" */)).7(7W.b((int)((long)1550218661 ^ (long)-1550206250), (int)((long)266371689 ^ (long)-266375680)) /* "invis" */)).1(7W.b((int)((long)-963728397 ^ (long)963732636), (int)((long)-1891146915 ^ (long)1891151674)) /* "Target invisible entities" */);
        ((34X)((34X)((34X)this.4().5(7W.b((int)((long)200599524 ^ (long)-200595298), (int)((long)114302834 ^ (long)114302433)) /* "Invisible" */)).7(7W.b((int)((long)1550218661 ^ (long)-1550206250), (int)((long)266371689 ^ (long)-266375680)) /* "invis" */)).1(7W.b((int)((long)-963728397 ^ (long)963732636), (int)((long)-1891146915 ^ (long)1891151674)) /* "Target invisible entities" */)).7 = object;
        this.5 = (1P)((34X)j2).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7W.b((int)((long)382954889 ^ (long)-382950713), (int)((long)2108859081 ^ (long)-2108858827)) /* "Sleeping" */)).7(7W.b((int)((long)1185972363 ^ (long)-1185984531), (int)((long)2124770894 ^ (long)2124743344)) /* "sleeping" */)).1(7W.b((int)((long)-199808364 ^ (long)199812578), (int)((long)-1221450914 ^ (long)1221447837)) /* "Target entities that are sleeping" */);
        ((34X)((34X)((34X)this.4().5(7W.b((int)((long)382954889 ^ (long)-382950713), (int)((long)2108859081 ^ (long)-2108858827)) /* "Sleeping" */)).7(7W.b((int)((long)1185972363 ^ (long)-1185984531), (int)((long)2124770894 ^ (long)2124743344)) /* "sleeping" */)).1(7W.b((int)((long)-199808364 ^ (long)199812578), (int)((long)-1221450914 ^ (long)1221447837)) /* "Target entities that are sleeping" */)).7 = object;
        this.8 = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7W.b((int)((long)1497637192 ^ (long)-1497633245), (int)((long)-248525208 ^ (long)248542495)) /* "Player" */)).7(7W.b((int)((long)529032857 ^ (long)-529028616), (int)((long)-739256696 ^ (long)-739269624)) /* "player" */)).1(7W.b((int)((long)879270508 ^ (long)-879274713), (int)((long)372717330 ^ (long)-372712098)) /* "Target player entities" */);
        ((34X)((34X)((34X)this.4().5(7W.b((int)((long)1497637192 ^ (long)-1497633245), (int)((long)-248525208 ^ (long)248542495)) /* "Player" */)).7(7W.b((int)((long)529032857 ^ (long)-529028616), (int)((long)-739256696 ^ (long)-739269624)) /* "player" */)).1(7W.b((int)((long)879270508 ^ (long)-879274713), (int)((long)372717330 ^ (long)-372712098)) /* "Target player entities" */)).7 = object;
        this.89 = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7W.b((int)((long)1550506909 ^ (long)-1550510879), (int)((long)1958053027 ^ (long)-1958065714)) /* "Hostile" */)).7(7W.b((int)((long)444931374 ^ (long)-444935595), (int)((long)1579877380 ^ (long)-1579901212)) /* "hostile" */)).1(7W.b((int)((long)-2072985158 ^ (long)2072973053), (int)((long)211337624 ^ (long)211334096)) /* "Target hostile entities" */);
        ((34X)((34X)((34X)this.4().5(7W.b((int)((long)1550506909 ^ (long)-1550510879), (int)((long)1958053027 ^ (long)-1958065714)) /* "Hostile" */)).7(7W.b((int)((long)444931374 ^ (long)-444935595), (int)((long)1579877380 ^ (long)-1579901212)) /* "hostile" */)).1(7W.b((int)((long)-2072985158 ^ (long)2072973053), (int)((long)211337624 ^ (long)211334096)) /* "Target hostile entities" */)).7 = object;
        this.8B = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7W.b((int)((long)713300844 ^ (long)-713305069), (int)((long)-18502985 ^ (long)18498147)) /* "Passive" */)).7(7W.b((int)((long)2075874862 ^ (long)-2075879093), (int)((long)-283209843 ^ (long)-283205803)) /* "passive" */)).1(7W.b((int)((long)-2115322092 ^ (long)2115334259), (int)((long)-1127489119 ^ (long)-1127502703)) /* "Target passive entities" */);
        ((34X)((34X)((34X)this.4().5(7W.b((int)((long)713300844 ^ (long)-713305069), (int)((long)-18502985 ^ (long)18498147)) /* "Passive" */)).7(7W.b((int)((long)2075874862 ^ (long)-2075879093), (int)((long)-283209843 ^ (long)-283205803)) /* "passive" */)).1(7W.b((int)((long)-2115322092 ^ (long)2115334259), (int)((long)-1127489119 ^ (long)-1127502703)) /* "Target passive entities" */)).7 = object;
        this.1 = (1P)((34X)j2).5();
        object = (int)((long)1707035416 ^ (long)1707035475);
        j2 = ((34e)((34e)((34e)this.1().5(7W.b((int)((long)-1405671125 ^ (long)1405675107), (int)((long)-1174392272 ^ (long)1174392022)) /* "Opacity" */)).7(7W.b((int)((long)1042782928 ^ (long)-1042786896), (int)((long)1034049107 ^ (long)-1034057851)) /* "opacity" */)).1(7W.b((int)((long)1717290537 ^ (long)-1717302963), (int)((long)-1598630328 ^ (long)1598634458)) /* "The transparency of the Radar" */)).3((int)((long)744468906 ^ (long)744468915)).2((int)((long)-1785168782 ^ (long)-1785168874));
        ((34e)((34e)((34e)this.1().5(7W.b((int)((long)-1405671125 ^ (long)1405675107), (int)((long)-1174392272 ^ (long)1174392022)) /* "Opacity" */)).7(7W.b((int)((long)1042782928 ^ (long)-1042786896), (int)((long)1034049107 ^ (long)-1034057851)) /* "opacity" */)).1(7W.b((int)((long)1717290537 ^ (long)-1717302963), (int)((long)-1598630328 ^ (long)1598634458)) /* "The transparency of the Radar" */)).3((int)((long)744468906 ^ (long)744468915)).2((int)((long)-1785168782 ^ (long)-1785168874)).7 = object;
        this.8f = (1z)((34e)j2).5();
        object = (int)((long)-1918030134 ^ (long)-1918030162);
        j2 = ((34e)((34e)((34e)this.1().5(7W.b((int)((long)-255992749 ^ (long)255988526), (int)((long)-1368798486 ^ (long)-1368811394)) /* "Size" */)).7(7W.b((int)((long)-1729341180 ^ (long)1729336935), (int)((long)-652283744 ^ (long)652280365)) /* "size" */)).1(7W.b((int)((long)567894786 ^ (long)-567890830), (int)((long)737960879 ^ (long)-737953608)) /* "The size of the radar" */)).3((int)((long)1681624586 ^ (long)1681624641)).2((int)((long)1867621108 ^ (long)1867621001));
        ((34e)((34e)((34e)this.1().5(7W.b((int)((long)-255992749 ^ (long)255988526), (int)((long)-1368798486 ^ (long)-1368811394)) /* "Size" */)).7(7W.b((int)((long)-1729341180 ^ (long)1729336935), (int)((long)-652283744 ^ (long)652280365)) /* "size" */)).1(7W.b((int)((long)567894786 ^ (long)-567890830), (int)((long)737960879 ^ (long)-737953608)) /* "The size of the radar" */)).3((int)((long)1681624586 ^ (long)1681624641)).2((int)((long)1867621108 ^ (long)1867621001)).7 = object;
        this.7 = (1z)((34e)j2).5();
        object = 1.0;
        j2 = ((34e)((34e)((34e)this.7().5(7W.b((int)((long)1908555783 ^ (long)-1908568209), (int)((long)299853130 ^ (long)-299854157)) /* "Blip Size" */)).7(7W.b((int)((long)-1277379204 ^ (long)1277391374), (int)((long)-2089381161 ^ (long)2089380666)) /* "blip" */)).1(7W.b((int)((long)-1127433667 ^ (long)1127445836), (int)((long)-1120365279 ^ (long)-1120356933)) /* "The size of entity blips on the radar" */)).3(0.1).2(2.0);
        ((34e)((34e)((34e)this.7().5(7W.b((int)((long)1908555783 ^ (long)-1908568209), (int)((long)299853130 ^ (long)-299854157)) /* "Blip Size" */)).7(7W.b((int)((long)-1277379204 ^ (long)1277391374), (int)((long)-2089381161 ^ (long)2089380666)) /* "blip" */)).1(7W.b((int)((long)-1127433667 ^ (long)1127445836), (int)((long)-1120365279 ^ (long)-1120356933)) /* "The size of entity blips on the radar" */)).3(0.1).2(2.0).7 = object;
        this.4 = (1K)((34e)j2).5();
        this.8F = new Listener(q -> {
            block25: {
                int n;
                block23: {
                    float f;
                    Object object;
                    int n2;
                    int n3;
                    int n4;
                    Tessellator tessellator;
                    String[] stringArray;
                    block26: {
                        Settings settings;
                        IPathingBehavior iPathingBehavior;
                        block31: {
                            double d2;
                            double d3;
                            block33: {
                                block32: {
                                    float f2;
                                    block30: {
                                        block28: {
                                            block29: {
                                                block24: {
                                                    boolean bl;
                                                    block27: {
                                                        bl = \u2000\u2003\u2005;
                                                        if (bl) break block24;
                                                        String[] stringArray2 = 3e.5();
                                                        2R.1(this, 7W.b((int)((long)633763877 ^ (long)-633751735), (int)((long)-1376737692 ^ (long)1376717099)) /* "suffix" */, this.6.0());
                                                        stringArray = stringArray2;
                                                        if (bl || bl) break block24;
                                                        if (7W.3.k.aJ) break block25;
                                                        if (bl || bl) break block24;
                                                        tessellator = 9b.5;
                                                        if (bl || bl) break block24;
                                                        n4 = (int)((double)this.7.4 * 0.425);
                                                        if (bl || bl) break block24;
                                                        n3 = (int)((long)-756004308 ^ (long)-756004312) + this.7.4 / (int)((long)-2004869798 ^ (long)-2004869800);
                                                        if (bl || bl) break block24;
                                                        n2 = (int)((long)-1065958126 ^ (long)-1065958122) + this.7.4 / (int)((long)-536226149 ^ (long)-536226151);
                                                        if (bl || bl) break block24;
                                                        int n5 = (int)((double)this.8f.4 * 2.55);
                                                        if (bl || bl) break block24;
                                                        9b.5(4.0f, 4.0f, (int)((long)-1978788028 ^ (long)-1978788032) + this.7.4, (int)((long)-257581776 ^ (long)-257581772) + this.7.4, 1.0f, 34L.3((int)((long)1589495139 ^ (long)1589495139), (int)((long)2083259133 ^ (long)2083259133), (int)((long)1118293664 ^ (long)1118293664), n5), 34L.3((int)((long)-1267879031 ^ (long)-1267879018), (int)((long)-655210969 ^ (long)-655210952), (int)((long)869233088 ^ (long)869233119), n5));
                                                        if (bl || bl) break block24;
                                                        dem.Q();
                                                        if (bl || bl) break block24;
                                                        9b.6((boolean)((long)-520074693 ^ (long)-520074694));
                                                        if (bl || bl) break block24;
                                                        4L[] lArray = new 4L[(int)((long)1073462814 ^ (long)1073462815)];
                                                        lArray[(int)((long)2025782898 ^ (long)2025782898)] = 4L.c;
                                                        9b.3(lArray);
                                                        if (bl || bl) break block24;
                                                        7W.3.r.b().forEach(arg_0 -> this.8((int)((long)57075030 ^ (long)57075026), (int)((long)0x1C11444C ^ (long)470893640), n3, n2, arg_0));
                                                        if (bl || bl) break block24;
                                                        dem.d((float)1.0f);
                                                        if (bl || bl) break block24;
                                                        if (!this.9.2) break block26;
                                                        if (bl || bl) break block24;
                                                        iPathingBehavior = BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior();
                                                        if (bl || bl) break block24;
                                                        dem.Q();
                                                        if (bl || bl) break block24;
                                                        if (!this.2.2) break block27;
                                                        if (bl || bl) break block24;
                                                        GL11.glEnable((int)((int)((long)1511408094 ^ (long)1511410426)));
                                                        if (bl || bl) break block24;
                                                        GL11.glLineStipple((int)this.0.4, (short)((long)-910959795 ^ (long)910979559));
                                                        if (bl) break block24;
                                                    }
                                                    if (bl) break block24;
                                                    if (((String)this.6.0()).equals(7W.b((int)((long)918444493 ^ (long)-918448473), (int)((long)912896872 ^ (long)-912892346)) /* "Static" */)) break block28;
                                                    if (!bl) break block29;
                                                }
                                                return;
                                            }
                                            f2 = -7W.3.aa().p;
                                            if (\u2000\u2003\u2005) {
                                                throw null;
                                            }
                                            break block30;
                                        }
                                        f2 = -180.0f;
                                    }
                                    5K.6(f2, n3, n2);
                                    settings = BaritoneAPI.getSettings();
                                    if (3d.8()) {
                                        IPathExecutor iPathExecutor;
                                        object = iPathingBehavior.getCurrent();
                                        if (object != null && object.getPath() != null) {
                                            this.8(object.getPath(), (int)((long)673234303 ^ (long)673234299), (int)((long)1229400182 ^ (long)1229400178), (Color)settings.colorCurrentPath.value);
                                        }
                                        if ((iPathExecutor = iPathingBehavior.getNext()) != null && iPathExecutor.getPath() != null) {
                                            this.8(iPathExecutor.getPath(), (int)((long)-290776060 ^ (long)-290776064), (int)((long)-1655057096 ^ (long)-1655057092), (Color)settings.colorNextPath.value);
                                        }
                                    }
                                    if (!((object = iPathingBehavior.getGoal()) instanceof IGoalRenderPos) && !(object instanceof GoalXZ)) break block31;
                                    if (!(object instanceof IGoalRenderPos)) break block32;
                                    IGoalRenderPos iGoalRenderPos = (IGoalRenderPos)object;
                                    d3 = 3.aa().cD() - (double)iGoalRenderPos.getGoalPos().u() - 0.5;
                                    d2 = 3.aa().cH() - (double)iGoalRenderPos.getGoalPos().w() - 0.5;
                                    if (stringArray == null) break block33;
                                }
                                d3 = 3.aa().cD() - (double)((GoalXZ)object).getX() - 0.5;
                                d2 = 3.aa().cH() - (double)((GoalXZ)object).getZ() - 0.5;
                            }
                            if (this.3(d3, d2)) {
                                float f3;
                                double d4 = d3 + 4.0 + (double)((float)this.7.4 / 2.0f);
                                double d5 = d2 + 4.0 + (double)((float)this.7.4 / 2.0f);
                                if (!((String)this.6.0()).equals(7W.b((int)((long)810799613 ^ (long)-810803561), (int)((long)1344616231 ^ (long)-1344611831)) /* "Static" */)) {
                                    f3 = 7W.3.aa().p + 180.0f;
                                    if (\u2000\u2003\u2005) {
                                        throw null;
                                    }
                                } else {
                                    f3 = 0.0f;
                                }
                                5K.6(f3 + 180.0f, d4, d5);
                                object = (Color)settings.colorGoalBox.value;
                                dem.d((float)((float)((Color)object).getRed() / 255.0f), (float)((float)((Color)object).getGreen() / 255.0f), (float)((float)((Color)object).getBlue() / 255.0f), (float)1.0f);
                                this.5(d4, d5);
                            }
                        }
                        iPathingBehavior.getInProgress().ifPresent(arg_0 -> this.9((int)((long)1038577394 ^ (long)1038577398), (int)((long)-1672966773 ^ (long)-1672966769), settings, arg_0));
                        if (this.2.2) {
                            GL11.glDisable((int)((int)((long)-71723378 ^ (long)-71721558)));
                        }
                        dem.R();
                    }
                    RenderSystem.color3f((float)1.0f, (float)1.0f, (float)1.0f);
                    dem.Q();
                    if (((String)this.6.0()).equals(7W.b((int)((long)490956452 ^ (long)-490952242), (int)((long)-27150592 ^ (long)27154990)) /* "Static" */)) {
                        f = 7W.3.aa().p;
                        if (\u2000\u2003\u2005) {
                            throw null;
                        }
                    } else {
                        f = 180.0f;
                    }
                    5K.6(f, n3, n2);
                    tessellator.addVertex((float)n3, (float)(n2 + (int)((long)-843353979 ^ (long)-843353978)), 0.0f).addVertex((float)n3 + 1.5f, (float)(n2 - (int)((long)-1514044959 ^ (long)-1514044958)), 0.0f).addVertex((float)n3 - 1.5f, (float)(n2 - (int)((long)-455280724 ^ (long)-455280721)), 0.0f).draw((int)((long)1020152539 ^ (long)1020152530));
                    dem.R();
                    dem.Q();
                    dem.K();
                    String[] stringArray3 = new String[(int)((long)-1665846877 ^ (long)-1665846873)];
                    stringArray3[(int)((long)796531478 ^ (long)796531478)] = 2w$6X.KAOZ("\u9ce6", 1467923332);
                    stringArray3[(int)((long)-1586397920 ^ (long)-1586397919)] = 2w$6X.KAOZ("\u77c1", 1590579368);
                    stringArray3[(int)((long)10813303 ^ (long)10813301)] = 2w$6X.KAOZ("\u823b", 903193924);
                    stringArray3[(int)((long)-11814785 ^ (long)-11814788)] = 2w$6X.KAOZ("\u6778", -861585405);
                    String[] stringArray4 = stringArray3;
                    for (int i = (int)((long)-719449739 ^ (long)-719449739); i < (int)((long)-1187061510 ^ (long)-1187061506); ++i) {
                        object = stringArray4[i];
                        double d6 = (float)(i - (int)((long)-1609508414 ^ (long)-1609508413)) * 90.0f;
                        n = ((String)this.6.0()).equals(7W.b((int)((long)-1722867427 ^ (long)1722871415), (int)((long)-2105380798 ^ (long)2105384300)) /* "Static" */) ? 1 : 0;
                        if (stringArray == null) {
                            if (n == 0) {
                                d6 = d6 - (double)7W.3.aa().p - 180.0;
                            }
                            dku dku2 = 7W.3.g;
                            dfm dfm2 = q.8();
                            float f4 = (float)n3 + (float)n4 * afm.b((float)((float)Math.toRadians(d6)));
                            float f5 = (float)n2 + (float)n4 * afm.a((float)((float)Math.toRadians(d6)));
                            7W.3.g.getClass();
                            dku2.a(dfm2, (String)object, f4, f5 - 4.5f, (int)((long)-1520534563 ^ (long)1520534562));
                            if (stringArray == null) continue;
                        }
                        break block23;
                    }
                    dem.R();
                    9b.3();
                    n = (int)((long)-1406288814 ^ (long)-1406288814);
                }
                9b.6(n != 0);
                dem.R();
            }
        }, new Predicate[(int)((long)-1639450267 ^ (long)-1639450267)]);
    }

    /*
     * Unable to fully structure code
     */
    private /* synthetic */ void 8(int var1_1, int var2_2, int var3_3, int var4_4, aqa var5_5) {
        block26: {
            block24: {
                block25: {
                    block21: {
                        block23: {
                            block22: {
                                block20: {
                                    var14_6 = 7W.\u2000\u2003\u2005;
                                    if (var14_6 || var14_6) lbl-1000:
                                    // 12 sources

                                    {
                                        return;
                                    }
                                    var7_7 = var5_5;
                                    var6_8 = this;
                                    if (var14_6 || var14_6) ** GOTO lbl-1000
                                    if (var7_7 instanceof 345) ** GOTO lbl-1000
                                    if (var14_6 || var14_6) ** GOTO lbl-1000
                                    if (var7_7 == 7W.3.aa()) ** GOTO lbl-1000
                                    if (var14_6 || var14_6) ** GOTO lbl-1000
                                    if (!var7_7.bF()) break block20;
                                    if (var14_6) ** GOTO lbl-1000
                                    if (!var6_8.5.2) ** GOTO lbl-1000
                                    if (var14_6) ** GOTO lbl-1000
                                }
                                if (var14_6) ** GOTO lbl-1000
                                if (!(var7_7 instanceof bfw)) break block21;
                                if (var14_6 || var14_6) ** GOTO lbl-1000
                                if (!var6_8.89.2) ** GOTO lbl-1000
                                if (var14_6 || var14_6) ** GOTO lbl-1000
                                if (!((bfw)var7_7).em()) break block22;
                                if (var14_6) ** GOTO lbl-1000
                                if (!var6_8.8.2) break block23;
                                if (var14_6) ** GOTO lbl-1000
                            }
                            if (!var14_6) ** break;
                            ** while (true)
                            v0 = (int)((long)614800914 ^ (long)614800915);
                            if (7W.\u2000\u2003\u2005) {
                                throw null;
                            }
                            break block24;
                        }
                        v0 = (int)((long)-2096287095 ^ (long)-2096287095);
                        if (7W.\u2000\u2003\u2005) {
                            throw null;
                        }
                        break block24;
                    }
                    if (!34L.6(var7_7)) break block25;
                    if (!var6_8.8B.2) ** GOTO lbl-1000
                    v0 = (int)((long)-80529539 ^ (long)-80529540);
                    if (7W.\u2000\u2003\u2005) {
                        throw null;
                    }
                    break block24;
                }
                if (34L.7(var7_7) && var6_8.1.2) {
                    v0 = (int)((long)-1907746956 ^ (long)-1907746955);
                    if (7W.\u2000\u2003\u2005) {
                        throw null;
                    }
                } else lbl-1000:
                // 6 sources

                {
                    v0 = (int)((long)-498985928 ^ (long)-498985928);
                }
            }
            if (v0 == 0 || !this.3(var6_9 = 7W.3.aa().cD() - var5_5.cD(), var8_10 = 7W.3.aa().cH() - var5_5.cH())) break block26;
            dem.Q();
            var10_11 = var6_9 + (double)var1_1 + (double)((float)this.7.4 / 2.0f);
            var12_12 = var8_10 + (double)var2_2 + (double)((float)this.7.4 / 2.0f);
            if (!((String)this.6.0()).equals(7W.b((int)((long)-215559260 ^ (long)215555278), (int)((long)-1562307324 ^ (long)1562310698)) /* "Static" */)) {
                v1 = -7W.3.aa().p;
                if (7W.\u2000\u2003\u2005) {
                    throw null;
                }
            } else {
                v1 = -180.0f;
            }
            5K.6(v1, var3_3, var4_4);
            if (!((String)this.6.0()).equals(7W.b((int)((long)-222985084 ^ (long)222972910), (int)((long)1732205888 ^ (long)-1732202386)) /* "Static" */)) {
                v2 = 7W.3.aa().p + 180.0f;
                if (7W.\u2000\u2003\u2005) {
                    throw null;
                }
            } else {
                v2 = 0.0f;
            }
            5K.6(v2 + 180.0f, var10_11, var12_12);
            if (var5_5 instanceof bfw) ** GOTO lbl-1000
            if (34L.6(var5_5)) {
                RenderSystem.color3f((float)1.0f, (float)0.5f, (float)0.5f);
                if (7W.\u2000\u2003\u2005) {
                    throw null;
                }
            } else if (34L.7(var5_5)) {
                RenderSystem.color3f((float)0.5f, (float)1.0f, (float)0.5f);
                if (7W.\u2000\u2003\u2005) {
                    throw null;
                }
            } else lbl-1000:
            // 2 sources

            {
                RenderSystem.color3f((float)1.0f, (float)1.0f, (float)1.0f);
            }
            this.5(var10_11, var12_12);
            dem.R();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean 3(double d2, double d3) {
        boolean bl = \u2000\u2003\u2005;
        if (bl || bl) return true;
        double d4 = d2;
        double d5 = d3;
        if (Math.sqrt(d4 * d4 + d5 * d5) <= (double)this.7.4 / 2.0 - (double)this.7.4 / 50.0) {
            if (bl) return true;
            return (int)((long)658944676 ^ (long)658944677) != 0;
        }
        if (!bl) return (int)((long)-1550624922 ^ (long)-1550624922) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 5(double d2, double d3) {
        block3: {
            block2: {
                boolean bl = \u2000\u2003\u2005;
                if (bl || bl) break block2;
                GL11.glBegin((int)((int)((long)1214683217 ^ (long)1214683224)));
                if (bl || bl) break block2;
                GL11.glVertex2d((double)d2, (double)(d3 + this.4.1));
                if (bl || bl) break block2;
                GL11.glVertex2d((double)(d2 + this.4.1), (double)d3);
                if (bl || bl) break block2;
                GL11.glVertex2d((double)d2, (double)(d3 - this.4.1));
                if (bl || bl) break block2;
                GL11.glVertex2d((double)(d2 - this.4.1), (double)d3);
                if (bl || bl) break block2;
                GL11.glEnd();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7W.\u2000\u2003\u2005;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)450169525 ^ (long)450169503)];
            if (var7) break block23;
            var3_2 = (int)((long)1465590760 ^ (long)1465590760);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u47de\u6ea9\u7d04\u7586\u4775\u6e74\u7d66\u75e8\u4752\u6e17\u7d69\u75f1\u47b5\u6e77\u7d8c\u7517\u470e\u6efe\u7df6\u75bb\u474e\u6e7a\u7d4f\u75bf\u470d\u6e07\u7d80\u758e\u47a3\u6e50\u7d26\u75de\u47a4\u6e9f\u7df7\u757d\u47a0\u6e4e\u7dbc\u75c8\u471a\u6e8b\u7db3\u7562\u47af\u6ea2\u7d7b\u75f7\u4708\u6e73\u7dd6\u75d9\u473f\u6e14\u7d83\u75fd\u4770\u6eaa\u7d6b\u75d2\u47f4\u6e90\u7d1a\u7546\u4705\u6e05\u7daf\u755e\u47c1\u6e87\u7d66\u75f6\u4707\u6ef2\u7dcd\u7550\u47b6\u6e98\u7da6\u75f9\u47d0\u6efc\u7ded\u7522\u47c5\u6e52\u7d7b\u7503\u470b\u6e01\u7d2d\u75c7\u47d8\u6e6b\u7df3\u7593\u47f0\u6ee9\u7d9c\u753a\u4726\u6e9a\u7d36\u75a1\u47bf\u6e50\u7db7\u756f\u47c5\u6eb2\u7d89\u75da\u4701\u6ecc\u7d17\u7569\u47f0\u6e5a\u7d5f\u75c7\u47bd\u6e18\u7deb\u7546\u47b0\u6e56\u7d97\u750a\u47fd\u6e40\u7d7b\u75e5\u4770\u6e10\u7dec\u7526\u47fd\u6e03\u7d91\u75cf\u4767\u6e6c\u7d82\u7525\u4709\u6e87\u7de2\u752b\u478a\u6e36\u7d81\u75cb\u4787\u6e79\u7d28\u75f5\u4764\u6e0c\u7d64\u7599\u471b\u6e02\u7d16\u75e8\u4788\u6ef3\u7d7d\u7554\u471a\u6ec9\u7ddf\u756d\u4734\u6e4f\u7db5\u75fc\u4786\u6e02\u7d2b\u75f3\u4790\u6eda\u7dda\u759c\u4722\u6e16\u7d17\u75ba\u47bc\u6e9e\u7de8\u7541\u4711\u6e4a\u7d3d\u75f1\u47ff\u6e9e\u7d7a\u7591\u4758\u6e98\u7d14\u7556\u47da\u6e9d\u7da7\u7533\u4792\u6e1b\u7d8c\u7518\u4779\u6e3b\u7d18\u7503\u4793\u6e6d\u7df4\u755d\u471b\u6e4d\u7d10\u75f4\u47a3\u6e20\u7df5\u7532\u472a\u6ee6\u7d1d\u7528\u47c0\u6ebe\u7d10\u7558\u4738\u6ea3\u7df4\u7549\u4760\u6eda\u7d87\u751d\u47bf\u6ee0\u7d42\u75ff\u476e\u6e9c\u7d0e\u75a0\u47a5\u6e02\u7d73\u754a\u47b2\u6e78\u7de8\u752d\u4706\u6ef0\u7d92\u75ac\u471d\u6ec9\u7dcf\u757b\u471c\u6e4c\u7d7a\u7541\u4756\u6e44\u7d95\u75e8\u4745\u6ed2\u7dcc\u756f\u4791\u6e2e\u7d6e\u75f5\u47f3\u6eea\u7dfb\u7541\u473d\u6eec\u7d2d\u757a\u47d8\u6edc\u7df3\u7565\u47e5\u6e38\u7d8e\u75f4\u479e\u6e05\u7d9f\u75fd\u47cf\u6ef8\u7d48\u752b\u47a5\u6e7a\u7d81\u75a2\u473d\u6e14\u7d76\u7519\u47cf\u6ea8\u7d3f\u75fe\u47a0\u6e36\u7d98\u7551\u4734\u6ea9\u7d30\u75a4\u4702\u6eb9\u7dab\u75f4\u4774\u6e8a\u7dce\u7516\u4747\u6e49\u7d2d\u7581\u478c\u6eab\u7dfb\u75cb\u4722\u6ef5\u7d76\u7504\u4785\u6e73\u7d69\u7521\u4719\u6e69\u7da9\u751a\u474e\u6e13\u7d81\u7589\u4714\u6e9f\u7d98\u75f5\u47e4\u6e43\u7d54\u75c0\u4719\u6eb1\u7d2f\u754f\u4778\u6ee8\u7d90\u759e\u471b\u6e46\u7ddb\u75dd\u478b\u6eae\u7dfe\u757b\u475c\u6e71\u7d42\u7523\u477d\u6ef4\u7d95\u756e\u47a0\u6e5f\u7d2f\u7566\u4739\u6e29\u7d8b\u75d5\u4763\u6eca\u7d36\u7529\u47e3\u6eee\u7d55\u75a6\u47c9\u6ead\u7da0\u7562\u470b\u6eec\u7da1\u75e8\u47bd\u6e27\u7d5e\u75ce\u47d9\u6edb\u7d22\u75e2\u479f\u6e84\u7dc0\u7544\u470a\u6ef9\u7d13\u7570\u474a\u6e4a\u7d8d\u7571\u47bb\u6e5c\u7d0e\u759d\u47dc\u6ed1\u7d16\u75f6\u4732\u6eb0\u7dbd\u75a5\u4742\u6e10\u7d80\u75fe\u47f3\u6ed8\u7d4a\u7567\u4713\u6e1f\u7dcd\u75a5\u47f6\u6ef7\u7d4c\u7501\u4774\u6ec4\u7d13\u75ff\u4759\u6e81\u7df4\u7583\u476b\u6ed4\u7da5\u7531\u47e4\u6e49\u7dca\u7528\u4733\u6e94\u7d81\u7521\u47a1\u6eae\u7d2e\u75e7\u4748\u6e42\u7d2a\u755b\u47dd\u6e22\u7d81\u75a4\u47ad\u6ea5\u7dd0\u7533\u4783\u6efd\u7d87\u754e\u4768\u6e5f\u7de8\u7515\u47fb\u6e9a\u7d82\u7566\u4794\u6e25\u7d72\u752f\u4788\u6eaa\u7da2\u75b4\u47a6\u6e60\u7d38\u7502\u4725\u6e25\u7de3\u754c\u470f\u6e77\u7dd8\u7576\u47b5\u6e63\u7d47\u756c\u4765\u6eb6\u7deb\u75b5\u47f3\u6e5c\u7de3\u75a9\u477c\u6e3e\u7d10\u7532\u4792\u6ed1\u7dea\u759f\u47c5\u6e5b\u7d1f\u759d\u4749\u6ece", -420519888);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-200435194 ^ (long)-200435199);
            if (var7) break block23;
            var0_6 = (int)((long)-1186254227 ^ (long)1186254226);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1464077977 ^ (long)-1464078033);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-907060683 ^ (long)907060682);
                    if (7W.\u2000\u2003\u2005) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7W.\u2000\u2003\u2005) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u676c\u4ea3\u5d94\u5525\u67db\u4e7e\u5d0a\u5526\u676e\u4e24\u5dc7\u550c\u672a\u4e7c\u5d09\u555c\u6783\u4edf\u5d19\u550c\u673a\u4e2c\u5d34\u5560\u6746\u4eaa\u5d88\u55cb\u67d6\u4e24\u5dc5\u5513\u67d9\u4eb5\u5d39\u55fa\u6736\u4e8c\u5d46\u5567\u67d2\u4e87\u5dcb\u557d\u67b0\u4e7e\u5d07\u5555\u67cc\u4ec2\u5d63\u55ff\u6737\u4e53\u5d59\u55ba\u6756\u4e24\u5dc4\u55ba\u672d\u4e33\u5db2\u55b3\u67e5\u4e63\u5d9a\u559a\u6755\u4e2d\u5de8\u559f\u675f\u4e3f\u5d67\u5597\u6795\u4e4f\u5dd7", 1990738028);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)2005753919 ^ (long)2005753864);
                            var0_6 = (int)((long)-126211983 ^ (long)126211982);
                            while (true) {
                                v0 = (int)((long)950064052 ^ (long)950064008);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1724921404 ^ (long)-1724921404);
                                if (!7W.\u2000\u2003\u2005) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7W.\u2000\u2003\u2005) ** continue;
                                throw null;
                            }
                            7W.d = var5_1;
                            7W.e = new String[(int)((long)-854710959 ^ (long)-854710917)];
                            if (!7W.\u2000\u2003\u2005) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1776314452 ^ (long)1776314452);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)617612938 ^ (long)617612939)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)413594489 ^ (long)413594494)) {
                                case 0: {
                                    v15 = (int)((long)1221471566 ^ (long)1221471560);
                                    if (!7W.\u2000\u2003\u2005) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1203980192 ^ (long)1203980222);
                                    if (!7W.\u2000\u2003\u2005) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1234567692 ^ (long)-1234567684);
                                    if (!7W.\u2000\u2003\u2005) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1338104261 ^ (long)-1338104254);
                                    if (!7W.\u2000\u2003\u2005) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-366217765 ^ (long)-366217738);
                                    if (!7W.\u2000\u2003\u2005) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)808127807 ^ (long)808127808);
                                    if (!7W.\u2000\u2003\u2005) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1536811609 ^ (long)1536811624);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7W.\u2000\u2003\u2005);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7W.\u2000\u2003\u2005;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1697120777 ^ (long)-1697133209)) & (int)((long)605911137 ^ (long)605915038);
            if (var9_2) ** GOTO lbl-1000
            if (7W.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7W.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-2038234642 ^ (long)-2038234642)] & (int)((long)724262553 ^ (long)724262502)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-289523903 ^ (long)-289523886);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1814223270 ^ (long)-1814223171);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1014875364 ^ (long)1014875281);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1260921793 ^ (long)-1260921726);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1273382830 ^ (long)1273382807);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-522019178 ^ (long)-522019214);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-136144291 ^ (long)-136144342);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1455032593 ^ (long)-1455032776);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1987296604 ^ (long)1987296605);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)556714104 ^ (long)556714129);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)2115771863 ^ (long)2115771893);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1385759667 ^ (long)-1385759727);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-2131034978 ^ (long)-2131034946);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1932518812 ^ (long)1932518871);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)92100265 ^ (long)92100294);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1533174267 ^ (long)-1533174258);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)59974414 ^ (long)59974401);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1455458458 ^ (long)-1455458403);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-2101170444 ^ (long)-2101170462);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1570244959 ^ (long)1570244977);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-104515133 ^ (long)-104515080);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-968202822 ^ (long)-968202782);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)171493313 ^ (long)171493373);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1457411483 ^ (long)-1457411470);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)735084730 ^ (long)735084598);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)915225855 ^ (long)915225656);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-756628739 ^ (long)-756628989);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-820655374 ^ (long)-820655439);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-887383947 ^ (long)-887384015);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1471464215 ^ (long)1471464382);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1032962705 ^ (long)-1032962691);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-2035667521 ^ (long)-2035667691);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1476066329 ^ (long)1476066458);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1818104503 ^ (long)1818104341);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1177153531 ^ (long)-1177153390);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)20063401 ^ (long)20063432);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)633172791 ^ (long)633172813);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1756426649 ^ (long)1756426603);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1953037674 ^ (long)1953037586);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1111140686 ^ (long)1111140680);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1574014847 ^ (long)1574014791);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1239473840 ^ (long)-1239473795);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1750062512 ^ (long)-1750062468);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1514902939 ^ (long)-1514902913);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-795362836 ^ (long)-795363012);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)839793650 ^ (long)839793533);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1940110669 ^ (long)1940110757);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1499403082 ^ (long)-1499403186);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)231099335 ^ (long)231099389);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)168415349 ^ (long)168415383);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)272953001 ^ (long)272952945);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1774724875 ^ (long)1774725095);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1694277131 ^ (long)-1694277275);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1875289145 ^ (long)-1875289184);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)2115330364 ^ (long)2115330420);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1506610409 ^ (long)-1506610399);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)2028998233 ^ (long)2028998202);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)140114301 ^ (long)140114234);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1734912701 ^ (long)-1734912738);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-7639172 ^ (long)-7639256);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1150878361 ^ (long)1150878361);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-745874278 ^ (long)-745874232);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1346205048 ^ (long)1346205024);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1984435117 ^ (long)1984434993);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)798941989 ^ (long)798941990);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-289234707 ^ (long)-289234921);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1253487231 ^ (long)-1253487132);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1339583552 ^ (long)1339583583);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-946800005 ^ (long)-946800048);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1493603974 ^ (long)-1493603970);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1366018563 ^ (long)-1366018731);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1953631185 ^ (long)1953630992);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1656325338 ^ (long)1656325135);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1140150354 ^ (long)-1140150381);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)561112321 ^ (long)561112464);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1352838119 ^ (long)-1352837931);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1049858073 ^ (long)1049858090);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)809170631 ^ (long)809170603);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)965731452 ^ (long)965731507);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)753447793 ^ (long)753447828);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1235865709 ^ (long)-1235865671);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-790406537 ^ (long)-790406445);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-458589691 ^ (long)-458589604);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)507339141 ^ (long)507339245);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1354699859 ^ (long)-1354699801);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-16670617 ^ (long)-16670489);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-2079277875 ^ (long)-2079277920);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)733187755 ^ (long)733187777);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1183713303 ^ (long)1183713514);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1924973387 ^ (long)-1924973460);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)9121214 ^ (long)9121179);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1397074094 ^ (long)-1397073950);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)270653927 ^ (long)270653812);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)884844810 ^ (long)884844891);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1251720167 ^ (long)-1251720185);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)383887010 ^ (long)383886941);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1205871533 ^ (long)-1205871451);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-985687658 ^ (long)-985687794);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)430802512 ^ (long)430802491);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1020985407 ^ (long)-1020985376);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1033718717 ^ (long)1033718783);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)2079775295 ^ (long)2079775313);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1585740456 ^ (long)1585740530);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1204001221 ^ (long)1204001124);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-259190042 ^ (long)-259190145);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1767257279 ^ (long)1767257145);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1734889673 ^ (long)1734889702);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)474061508 ^ (long)474061390);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-911233555 ^ (long)-911233608);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1801117092 ^ (long)1801117153);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)2131820827 ^ (long)2131820841);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)257874569 ^ (long)257874621);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)771608410 ^ (long)771608503);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1036341097 ^ (long)1036341193);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)437343999 ^ (long)437343764);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)2002560438 ^ (long)2002560456);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-374456068 ^ (long)-374456141);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)544828750 ^ (long)544828784);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1084101117 ^ (long)1084101069);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1511495646 ^ (long)1511495671);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)2034437641 ^ (long)2034437652);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-823729613 ^ (long)-823729465);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1205837779 ^ (long)1205837621);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-654159661 ^ (long)-654159674);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1141656851 ^ (long)-1141656857);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-2065687928 ^ (long)-2065687853);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-485853374 ^ (long)-485853362);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-172926965 ^ (long)-172926779);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)2114573714 ^ (long)2114573645);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1344143420 ^ (long)-1344143483);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1619762233 ^ (long)-1619762230);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)474798455 ^ (long)474798508);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1564944543 ^ (long)-1564944430);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)859549542 ^ (long)859549591);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-899965813 ^ (long)-899965937);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)129546439 ^ (long)129546267);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1773534030 ^ (long)-1773534058);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1879593266 ^ (long)-1879593351);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)428922050 ^ (long)428922046);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)712553431 ^ (long)712553288);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1473337836 ^ (long)1473337819);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-952101378 ^ (long)-952101562);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1612555540 ^ (long)1612555719);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-156399464 ^ (long)-156399538);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1910680028 ^ (long)1910680063);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1155120982 ^ (long)-1155120965);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1270480187 ^ (long)1270480229);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-2039218434 ^ (long)-2039218630);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-648954462 ^ (long)-648954389);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)2100652355 ^ (long)2100652445);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1008575955 ^ (long)1008575828);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1253843197 ^ (long)-1253843009);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1266429787 ^ (long)1266429876);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1261151896 ^ (long)-1261151827);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-2131900372 ^ (long)-2131900222);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1622306816 ^ (long)1622306966);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)199380937 ^ (long)199380848);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1877002858 ^ (long)1877002979);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-38781277 ^ (long)-38781411);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1016355556 ^ (long)-1016355398);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)863622867 ^ (long)863622754);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-531294800 ^ (long)-531294895);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)256422288 ^ (long)256422174);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1358087721 ^ (long)-1358087902);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-673680336 ^ (long)-673680295);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)754981789 ^ (long)754981718);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1708809624 ^ (long)1708809546);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)2003795913 ^ (long)2003795820);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1949136013 ^ (long)1949135894);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-143397576 ^ (long)-143397516);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)12370870 ^ (long)12370825);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1996419697 ^ (long)1996419827);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-638105279 ^ (long)-638105140);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1857795518 ^ (long)-1857795469);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1206893105 ^ (long)1206893304);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1193977914 ^ (long)-1193978075);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1667300900 ^ (long)1667300881);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-984299934 ^ (long)-984300010);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1291215497 ^ (long)-1291215430);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1013993620 ^ (long)-1013993564);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1712680862 ^ (long)1712680802);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1534564857 ^ (long)1534564736);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1004998896 ^ (long)1004998889);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)739900327 ^ (long)739900181);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1873960357 ^ (long)-1873960365);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1634941114 ^ (long)-1634940989);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-2102367222 ^ (long)-2102367108);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)503788890 ^ (long)503788939);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)819432477 ^ (long)819432468);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)2054772273 ^ (long)2054772261);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-987460327 ^ (long)-987460103);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-553098804 ^ (long)-553098831);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)16185027 ^ (long)16184884);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)985285215 ^ (long)985285314);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-26792450 ^ (long)-26792464);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1938373056 ^ (long)-1938373086);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1415016542 ^ (long)1415016467);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1263147422 ^ (long)1263147464);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-979885588 ^ (long)-979885684);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)748649051 ^ (long)748649184);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1406531499 ^ (long)1406531357);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)534185912 ^ (long)534185735);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-897199551 ^ (long)-897199526);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-426832368 ^ (long)-426832205);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-90708742 ^ (long)-90708935);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)479048463 ^ (long)479048649);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1229785420 ^ (long)-1229785365);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1871204334 ^ (long)1871204165);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-131419900 ^ (long)-131419786);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1636745426 ^ (long)-1636745400);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1477292432 ^ (long)1477292325);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)879654573 ^ (long)879654620);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1097305478 ^ (long)1097305544);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)883179780 ^ (long)883179800);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1844246647 ^ (long)-1844246745);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-2146473622 ^ (long)-2146473702);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1256103759 ^ (long)1256103784);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-535902897 ^ (long)-535902945);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)665134373 ^ (long)665134437);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1738557709 ^ (long)1738557927);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1140141736 ^ (long)1140141659);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1775111493 ^ (long)1775111533);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)548713521 ^ (long)548713635);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1334641630 ^ (long)-1334641409);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1261444569 ^ (long)-1261444480);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-480893192 ^ (long)-480893269);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1356098252 ^ (long)1356098062);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1800557834 ^ (long)1800558032);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)2002661637 ^ (long)2002661754);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)2079482919 ^ (long)2079483037);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)82183761 ^ (long)82183877);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-286366193 ^ (long)-286365962);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-935767879 ^ (long)-935768044);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1655388760 ^ (long)-1655388887);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1313624670 ^ (long)1313624665);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1561479573 ^ (long)-1561479435);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-485970676 ^ (long)-485970556);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-484731504 ^ (long)-484731520);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1814425175 ^ (long)-1814425172);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1766632201 ^ (long)1766632339);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1214138990 ^ (long)-1214138890);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)939228441 ^ (long)939228598);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1644483253 ^ (long)-1644483189);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)30213914 ^ (long)30214096);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-286482938 ^ (long)-286482863);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1881193090 ^ (long)-1881192981);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)2049898482 ^ (long)2049898361);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-651710820 ^ (long)-651710745);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-159431945 ^ (long)-159432060);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)729348240 ^ (long)729348310);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1107478749 ^ (long)1107478641);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1491317836 ^ (long)-1491317920);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)444390110 ^ (long)444390136);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1280934683 ^ (long)-1280934681);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-961781347 ^ (long)-961781395);
                    if (!7W.\u2000\u2003\u2005) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1811177412 ^ (long)-1811177336);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-165632741 ^ (long)-165632540)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)2107917427 ^ (long)2107947916)) >>> (int)((long)-1801618686 ^ (long)-1801618678)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1946385743 ^ (long)-1946385743);
            if (!7W.\u2000\u2003\u2005) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-736627142 ^ (long)-736627144);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1804806056 ^ (long)-1804806053) | var5_6 << (int)((long)3716575 ^ (long)3716570)) ^ var3_4[var7_8]) & (int)((long)-1143113276 ^ (long)-1143113413);
                    if (7W.\u2000\u2003\u2005) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-2049247312 ^ (long)-2049247309) | var6_7 << (int)((long)980348015 ^ (long)980348010)) ^ var3_4[var7_8]) & (int)((long)250683919 ^ (long)250684144);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7W.e[var2_3] = new String(var3_4).intern();
        }
        return 7W.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void 8(IPath iPath, int n, int n2, Color color) {
        boolean bl = \u2000\u2003\u2005;
        if (bl) return;
        if (bl) return;
        GL11.glBegin((int)((int)((long)-1773712917 ^ (long)-1773712920)));
        if (bl) return;
        if (bl) return;
        int n3 = (int)((long)-787711479 ^ (long)-787711479);
        if (bl) return;
        do {
            float f;
            if (bl) return;
            if (n3 >= iPath.length()) {
                GL11.glEnd();
                return;
            }
            if (bl) return;
            if (bl) return;
            fx fx2 = (fx)iPath.positions().get(n3);
            if (bl) return;
            if (bl) return;
            double d2 = 3.aa().cD() - (double)fx2.u();
            if (bl) return;
            if (bl) return;
            double d3 = 3.aa().cH() - (double)fx2.w();
            if (bl) return;
            if (bl) return;
            float f2 = (float)color.getRed() / 255.0f;
            float f3 = (float)color.getGreen() / 255.0f;
            float f4 = (float)color.getBlue() / 255.0f;
            if (this.3(d2, d3)) {
                f = 1.0f;
                if (\u2000\u2003\u2005) {
                    throw null;
                }
            } else {
                f = 0.0f;
            }
            dem.d((float)f2, (float)f3, (float)f4, (float)f);
            double d4 = d2 + (double)n;
            double d5 = d3 + (double)n2;
            GL11.glVertex2d((double)(d4 + (double)((float)this.7.4 / 2.0f)), (double)(d5 + (double)((float)this.7.4 / 2.0f)));
            ++n3;
        } while (!\u2000\u2003\u2005);
        throw null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 9(int n, int n2, Settings settings, IPathFinder iPathFinder) {
        block3: {
            block2: {
                boolean bl = \u2000\u2003\u2005;
                if (bl || bl) break block2;
                iPathFinder.bestPathSoFar().ifPresent(iPath2 -> {
                    block3: {
                        block2: {
                            boolean bl = \u2000\u2003\u2005;
                            if (bl || bl) break block2;
                            this.8((IPath)iPath2, n, n2, (Color)settings.colorBestPathSoFar.value);
                            if (bl || bl) break block2;
                            iPathFinder.pathToMostRecentNodeConsidered().ifPresent(iPath -> {
                                block3: {
                                    block2: {
                                        boolean bl = \u2000\u2003\u2005;
                                        if (bl || bl) break block2;
                                        this.8((IPath)iPath, n, n2, (Color)settings.colorMostRecentConsidered.value);
                                        if (!bl && !bl) break block3;
                                    }
                                    return;
                                }
                            });
                            if (!bl && !bl) break block3;
                        }
                        return;
                    }
                });
                if (!bl && !bl) break block3;
            }
            return;
        }
    }
}

