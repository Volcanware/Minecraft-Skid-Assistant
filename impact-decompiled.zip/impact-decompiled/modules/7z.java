/* ==========================================================================
 * MODULE: Timer
 * CATEGORY (inferred): Player
 * DESCRIPTION: Change the Client-Sided TPS
 * OBFUSCATED CLASS: net.impactclient.7z
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import clientapi.load.mixin.7.9;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1A;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.4f;
import net.impactclient.5L;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7z
extends 3X
implements 5L {
    public static final boolean \u2006\u200e\u2009\u2005\u200b\u200a;
    @EventHandler
    private final Listener<4f> 5;
    private static final String[] d;
    private 1A 8;
    private static final String[] e;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u2006\u200e\u2009\u2005\u200b\u200a;
                if (bl || bl) break block2;
                ((9)9.getTimer()).setSpeed(1.0f);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7z.\u2006\u200e\u2009\u2005\u200b\u200a;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)426288659 ^ (long)426288661)];
            if (var7) break block23;
            var3_2 = (int)((long)-2093292794 ^ (long)-2093292794);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u8d95\ua4f0\ub796\ubf58\u8d4c\ua494\ub769\ubf9a\u8d2b\ua46f\ub7c5\ubfde\u8dc1\ua41f\ub7a1\ubf8e\u8d42\ua477\ub7f0\ubf33\u8dad\ua497\ub7d6\ubfdd\u8d26\ua413\ub7dd\ubfe9\u8dbe\ua432\ub7c2\ubfb6\u8d2f\ua45d\ub79e\ubf43\u8d85\ua478\ub774\ubf04\u8d76\ua4fc\ub709\ubfe2\u8d24\ua40e\ub755\ubfe0\u8d3a\ua4de\ub7b4\ubfe2\u8daf\ua47f\ub7ca\ubf0b\u8d9b\ua46d\ub71e\ubf9e\u8dda\ua442\ub7c2\ubf39", 753248814);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1498443979 ^ (long)1498443984);
            if (var7) break block23;
            var0_6 = (int)((long)-335759581 ^ (long)335759580);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1339064228 ^ (long)1339064246);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1396367263 ^ (long)-1396367264);
                    if (7z.\u2006\u200e\u2009\u2005\u200b\u200a) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ue69e\ucff9\udc72\ud49a\ue635\ucfc7\udc82\ud41d\ue6d9\ucf71\udcb8\ud476\ue618\ucf52\udcba\ud419", 1898823944);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-103984597 ^ (long)-103984607);
                            var0_6 = (int)((long)1929658322 ^ (long)-1929658323);
                            while (true) {
                                v0 = (int)((long)60385263 ^ (long)60385272);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)248844311 ^ (long)248844311);
                                if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) ** continue;
                                throw null;
                            }
                            7z.d = var5_1;
                            7z.e = new String[(int)((long)-852574788 ^ (long)-852574790)];
                            if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1395157732 ^ (long)1395157732);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-864114783 ^ (long)-864114784)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1794625375 ^ (long)-1794625370)) {
                                case 0: {
                                    v15 = (int)((long)-343844515 ^ (long)-343844511);
                                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-885923109 ^ (long)-885923174);
                                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1195140184 ^ (long)1195140182);
                                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-261060515 ^ (long)-261060489);
                                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1856591369 ^ (long)1856591422);
                                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-454642370 ^ (long)-454642424);
                                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-709050054 ^ (long)-709050000);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7z.\u2006\u200e\u2009\u2005\u200b\u200a);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7z.\u2006\u200e\u2009\u2005\u200b\u200a;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1716048136 ^ (long)-1716045763)) & (int)((long)-2061408193 ^ (long)-2061396032);
            if (var9_2) ** GOTO lbl-1000
            if (7z.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7z.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-141230781 ^ (long)-141230781)] & (int)((long)-2020185168 ^ (long)-2020185265)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1413844418 ^ (long)-1413844452);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1401287898 ^ (long)-1401287746);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)64416812 ^ (long)64416877);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-2100731394 ^ (long)-2100731446);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-291842300 ^ (long)-291842188);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1376116310 ^ (long)1376116478);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)181853860 ^ (long)181853750);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-649507019 ^ (long)-649506978);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1139805902 ^ (long)1139805920);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-519580218 ^ (long)-519580276);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)320596457 ^ (long)320596237);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1438677216 ^ (long)1438677195);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1579673088 ^ (long)1579673112);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1617301955 ^ (long)1617301964);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1079913659 ^ (long)-1079913679);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)328822184 ^ (long)328822106);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)80019910 ^ (long)80019965);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-839857892 ^ (long)-839857713);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)975449750 ^ (long)975449699);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)559974444 ^ (long)559974432);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1842537518 ^ (long)1842537538);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1445152562 ^ (long)-1445152529);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)173152075 ^ (long)173152049);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)2068872940 ^ (long)2068872796);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-506423291 ^ (long)-506423079);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-510583032 ^ (long)-510583001);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1422819508 ^ (long)-1422819562);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1163250145 ^ (long)1163250152);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1538612020 ^ (long)-1538612205);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)947941166 ^ (long)947941256);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1523080635 ^ (long)1523080462);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)522530259 ^ (long)522530206);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-2097144396 ^ (long)-2097144478);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-543319192 ^ (long)-543319183);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-2090241987 ^ (long)-2090241814);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1365270728 ^ (long)1365270539);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1326235339 ^ (long)1326235236);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)933778279 ^ (long)933778314);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1573713212 ^ (long)1573713314);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-391041728 ^ (long)-391041650);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-261368813 ^ (long)-261368827);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)2098923592 ^ (long)2098923547);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1559435434 ^ (long)1559435307);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1085850401 ^ (long)1085850489);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-587680847 ^ (long)-587680995);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)474796147 ^ (long)474796191);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)874118657 ^ (long)874118855);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1720386749 ^ (long)1720386748);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)2047533845 ^ (long)2047533899);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1496764472 ^ (long)1496764648);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1085783737 ^ (long)1085783604);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1855162912 ^ (long)-1855162974);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1136643303 ^ (long)-1136643247);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1947879665 ^ (long)-1947879664);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1765472432 ^ (long)-1765472501);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-67165965 ^ (long)-67166170);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)285002202 ^ (long)285002067);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1853147924 ^ (long)-1853147970);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)272996043 ^ (long)272996056);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)324154169 ^ (long)324154202);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1552365816 ^ (long)-1552365712);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1110798400 ^ (long)1110798489);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-167278659 ^ (long)-167278606);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1461294098 ^ (long)-1461294150);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)517539492 ^ (long)517539504);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1853441344 ^ (long)1853441289);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)514403186 ^ (long)514403189);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1831067630 ^ (long)1831067490);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1340538914 ^ (long)-1340539106);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1525309286 ^ (long)1525309402);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1358577153 ^ (long)-1358577272);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-160766744 ^ (long)-160766966);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1311762740 ^ (long)-1311762921);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-957938908 ^ (long)-957938845);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1712527611 ^ (long)1712527571);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)382254268 ^ (long)382254130);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)640665528 ^ (long)640665598);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)2088864285 ^ (long)2088864431);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)2055937499 ^ (long)2055937397);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1988592170 ^ (long)-1988592208);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1553130285 ^ (long)-1553130247);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1593791571 ^ (long)-1593791661);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-2051020141 ^ (long)-2051020226);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1425970531 ^ (long)1425970664);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1608518593 ^ (long)1608518492);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1577932483 ^ (long)1577932436);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1416743570 ^ (long)1416743460);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1385801277 ^ (long)-1385801229);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1502863206 ^ (long)1502863159);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1677905939 ^ (long)1677906142);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1768211379 ^ (long)1768211373);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1094596758 ^ (long)-1094596780);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1187871069 ^ (long)-1187871069);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)497503113 ^ (long)497503196);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1333621094 ^ (long)1333621057);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1447468735 ^ (long)-1447468762);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1327729575 ^ (long)1327729492);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1281824356 ^ (long)1281824273);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1404840772 ^ (long)1404840908);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-88577300 ^ (long)-88577297);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-548079391 ^ (long)-548079610);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-245494230 ^ (long)-245494028);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1875271080 ^ (long)-1875270919);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-950468631 ^ (long)-950468653);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-2020592539 ^ (long)-2020592603);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1094538581 ^ (long)-1094538686);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1019041549 ^ (long)1019041724);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)413663693 ^ (long)413663713);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1354275731 ^ (long)1354275612);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)300872355 ^ (long)300872365);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1112507939 ^ (long)1112508067);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1446405031 ^ (long)-1446404882);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1189097902 ^ (long)1189097873);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1312464538 ^ (long)-1312464443);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1825792538 ^ (long)1825792720);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)488844385 ^ (long)488844541);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1815088860 ^ (long)-1815088717);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)751548661 ^ (long)751548593);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1079211197 ^ (long)1079211219);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-133330914 ^ (long)-133330757);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1775759005 ^ (long)-1775758978);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1464430719 ^ (long)-1464430593);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1396820795 ^ (long)1396820760);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)613702344 ^ (long)613702276);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1991013264 ^ (long)1991013126);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1600333083 ^ (long)-1600333288);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)945222310 ^ (long)945222390);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1897467686 ^ (long)1897467856);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-760177690 ^ (long)-760177897);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1468168018 ^ (long)1468168064);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-129948308 ^ (long)-129948332);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1028805621 ^ (long)-1028805480);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-60766302 ^ (long)-60766294);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1533099600 ^ (long)-1533099598);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1601473059 ^ (long)1601473244);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)226762463 ^ (long)226762275);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1455559500 ^ (long)1455559656);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)444084393 ^ (long)444084268);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1794429635 ^ (long)-1794429562);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-444402894 ^ (long)-444402913);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-221872340 ^ (long)-221872315);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-868186489 ^ (long)-868186378);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1985235285 ^ (long)1985235227);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-790610536 ^ (long)-790610670);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1580600274 ^ (long)-1580600219);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1367458418 ^ (long)1367458441);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1923799474 ^ (long)1923799341);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-681867476 ^ (long)-681867409);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-487882174 ^ (long)-487882047);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-360532488 ^ (long)-360532627);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)863485083 ^ (long)863485078);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1443912773 ^ (long)1443912845);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)922713482 ^ (long)922713499);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1053878543 ^ (long)1053878617);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-60313953 ^ (long)-60313876);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)147525908 ^ (long)147525949);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-466730258 ^ (long)-466730349);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1683975291 ^ (long)-1683975177);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)2095626411 ^ (long)2095626396);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1182670905 ^ (long)-1182671011);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)884891211 ^ (long)884891384);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1035997366 ^ (long)1035997406);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1646282260 ^ (long)1646282349);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1222110579 ^ (long)1222110528);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)593854203 ^ (long)593853973);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-196565671 ^ (long)-196565659);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)13917759 ^ (long)13917792);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-458733023 ^ (long)-458732981);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)862996678 ^ (long)862996698);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)418226325 ^ (long)418226226);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-77577874 ^ (long)-77577787);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)929427865 ^ (long)929427958);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-605754047 ^ (long)-605753927);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1181210855 ^ (long)1181210675);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)382780911 ^ (long)382780725);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-916270028 ^ (long)-916269860);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)961359627 ^ (long)961359796);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1352332700 ^ (long)-1352332687);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)430954424 ^ (long)430954460);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1998750065 ^ (long)1998750156);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1610515650 ^ (long)1610515673);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1045329453 ^ (long)-1045329561);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1253635617 ^ (long)-1253635761);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1507384782 ^ (long)-1507384632);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1328876276 ^ (long)-1328876173);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)2069601432 ^ (long)2069601449);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1532961818 ^ (long)1532961854);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)951309249 ^ (long)951309265);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)155888008 ^ (long)155888058);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1581095744 ^ (long)-1581095726);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1537805676 ^ (long)1537805674);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)669023437 ^ (long)669023233);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1638675650 ^ (long)-1638675485);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-31593399 ^ (long)-31593342);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-316511065 ^ (long)-316511103);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1637363154 ^ (long)-1637363115);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1256748128 ^ (long)-1256748263);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)2069202171 ^ (long)2069201949);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1995833811 ^ (long)1995833654);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1951454821 ^ (long)-1951454730);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1856849765 ^ (long)1856849728);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1258229218 ^ (long)-1258229017);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1727557227 ^ (long)-1727557259);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)564491577 ^ (long)564491566);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1468926838 ^ (long)-1468926968);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1131329096 ^ (long)1131329100);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)198056189 ^ (long)198056184);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-616803518 ^ (long)-616803465);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)931638783 ^ (long)931638757);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1194958626 ^ (long)-1194958806);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1857922879 ^ (long)1857922868);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-565371435 ^ (long)-565371565);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)596860284 ^ (long)596860339);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1498780071 ^ (long)1498780154);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-622985503 ^ (long)-622985599);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1484985524 ^ (long)-1484985397);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1130642842 ^ (long)1130642886);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1163534734 ^ (long)-1163534718);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)26295765 ^ (long)26295606);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)755665364 ^ (long)755665157);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-232303889 ^ (long)-232304010);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)13144018 ^ (long)13144043);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-527161339 ^ (long)-527161150);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-562291550 ^ (long)-562291582);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1055320266 ^ (long)-1055320082);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-869514214 ^ (long)-869514098);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-456966897 ^ (long)-456966806);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1120467324 ^ (long)-1120467227);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-865925549 ^ (long)-865925447);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)630913071 ^ (long)630913259);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1984804735 ^ (long)1984804831);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1408895469 ^ (long)-1408895402);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)431647155 ^ (long)431647118);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1859190827 ^ (long)1859190959);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1758655707 ^ (long)-1758655542);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1077242879 ^ (long)-1077242869);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)296269088 ^ (long)296269282);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)931831783 ^ (long)931831645);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1310454867 ^ (long)1310455034);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1446069953 ^ (long)-1446069914);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-294077465 ^ (long)-294077541);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1026979783 ^ (long)1026979711);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1161644618 ^ (long)-1161644672);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)935166555 ^ (long)935166656);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1710437506 ^ (long)1710437475);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1017315596 ^ (long)1017315741);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-432410358 ^ (long)-432410208);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1616369816 ^ (long)-1616369761);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1496571962 ^ (long)-1496572157);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1511525862 ^ (long)-1511525677);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1560196828 ^ (long)1560196778);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)597487040 ^ (long)597487010);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1600674265 ^ (long)-1600674151);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-331224537 ^ (long)-331224346);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-920764837 ^ (long)-920764752);
                    if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1198358404 ^ (long)-1198358306);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)933369141 ^ (long)933369290)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-640930840 ^ (long)-640887785)) >>> (int)((long)-809480761 ^ (long)-809480753)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-969999204 ^ (long)-969999204);
            if (!7z.\u2006\u200e\u2009\u2005\u200b\u200a) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1770914841 ^ (long)-1770914843);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1632950407 ^ (long)-1632950406) | var5_6 << (int)((long)372875603 ^ (long)372875606)) ^ var3_4[var7_8]) & (int)((long)1154927187 ^ (long)1154927276);
                    if (7z.\u2006\u200e\u2009\u2005\u200b\u200a) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-849796164 ^ (long)-849796161) | var6_7 << (int)((long)203641478 ^ (long)203641475)) ^ var3_4[var7_8]) & (int)((long)1998829951 ^ (long)1998829952);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7z.e[var2_3] = new String(var3_4).intern();
        }
        return 7z.e[var2_3];
    }

    public 7z() {
        boolean bl = \u2006\u200e\u2009\u2005\u200b\u200a;
        super(7z.b((int)((long)1608563106 ^ (long)-1608560491), (int)((long)-725789581 ^ (long)-725794179)) /* "Timer" */, 7z.b((int)((long)852857392 ^ (long)-852854011), (int)((long)-448939694 ^ (long)-448948690)) /* "Change the Client-Sided TPS" */);
        Float f2 = Float.valueOf(2.0f);
        34e e = ((34e)((34e)((34e)this.9().5(7z.b((int)((long)295263059 ^ (long)-295259550), (int)((long)-1374451258 ^ (long)1374435379)) /* "Multiplier" */)).7(7z.b((int)((long)1847621110 ^ (long)-1847616314), (int)((long)-936658019 ^ (long)936658935)) /* "speed" */)).1(7z.b((int)((long)-22923369 ^ (long)22929057), (int)((long)942639692 ^ (long)942639636)) /* "The Game TPS Multiplier" */)).3(Float.valueOf(0.1f)).2(Float.valueOf(10.0f));
        ((34e)((34e)((34e)this.9().5(7z.b((int)((long)295263059 ^ (long)-295259550), (int)((long)-1374451258 ^ (long)1374435379)) /* "Multiplier" */)).7(7z.b((int)((long)1847621110 ^ (long)-1847616314), (int)((long)-936658019 ^ (long)936658935)) /* "speed" */)).1(7z.b((int)((long)-22923369 ^ (long)22929057), (int)((long)942639692 ^ (long)942639636)) /* "The Game TPS Multiplier" */)).3(Float.valueOf(0.1f)).2(Float.valueOf(10.0f)).7 = f2;
        this.8 = (1A)e.5();
        this.5 = new Listener(f -> {
            block3: {
                block2: {
                    boolean bl = \u2006\u200e\u2009\u2005\u200b\u200a;
                    if (bl || bl) break block2;
                    2R.1(this, 7z.b((int)((long)-521961359 ^ (long)521955653), (int)((long)835766421 ^ (long)835748783)) /* "suffix" */, String.valueOf(this.8.9));
                    if (bl || bl) break block2;
                    ((9)9.getTimer()).setSpeed(this.8.9);
                    if (!bl && !bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)784791438 ^ (long)784791438)]);
    }
}

