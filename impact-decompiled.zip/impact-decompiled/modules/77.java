/* ==========================================================================
 * MODULE: Weather
 * CATEGORY (inferred): Render
 * DESCRIPTION: Control the weather
 * OBFUSCATED CLASS: net.impactclient.77
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dwt
 *  dwt$a
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  pq
 *  pq$a
 */
package net.impactclient;

import java.util.Arrays;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.34X;
import net.impactclient.34k;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3i;
import net.impactclient.3sh;
import net.impactclient.3sx;
import net.impactclient.58;
import net.impactclient.5L;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 77
extends 3X
implements 5L {
    @EventHandler
    private final Listener<3sh> 4;
    public static final boolean \u2003\u200a;
    private static final String[] d;
    private 58 9;
    private 1P 8;
    private static final String[] e;
    @EventHandler
    private final Listener<3sx> 0;
    private 1P 5;
    @EventHandler
    private final Listener<3i> 1;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 77.\u2003\u200a;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-285713428 ^ (long)-285713440)];
            if (var7) break block23;
            var3_2 = (int)((long)-1386469803 ^ (long)-1386469803);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ua8f1\u81a3\u92dd\u9a46\ua870\u8111\u92b1\u9ad9\ua834\u81ce\u92af\u9a16\ua850\u8148\u927f\u9a6b\ua8a5\u81e8\u92d2\u9a62\ua8d0\u818d\u92e2\u9a9d\ua89b\u8170\u929e\u9acc\ua8e5\u81fa\u92ab\u9adb\ua8c2\u81b6\u92b9\u9af8\ua873\u817d\u929c\u9a2a\ua861\u815f\u92b9\u9aa3\ua8b9\u8116\u92c5\u9a47\ua84a\u81f2\u929b\u9a2b\ua80b\u81e8\u9292\u9ad6\ua881\u8167\u928e\u9a31\ua8cf\u816b\u92a2\u9a88\ua8e8\u815d\u921f\u9a51\ua836\u8127\u9237\u9ad6\ua8ca\u81a6\u9270\u9ab8\ua859\u816c\u92c4\u9a1a\ua823\u81f1\u92d8\u9ac2\ua80e\u8150\u924e\u9ab8\ua821\u81fd\u9228\u9a57\ua878\u8144\u9252\u9a50\ua87a\u81b2\u92df\u9a7e\ua82e\u814f\u92f7\u9ac0\ua872\u8187\u9215\u9a98\ua8dd\u8144\u9219\u9a97\ua88d\u8131\u925c\u9af0\ua83c\u811b\u9281\u9aab\ua82e\u8166\u92f0\u9a22\ua82f\u8176\u9213\u9ace\ua860\u81fa\u9211\u9a45\ua803\u81e9\u925e\u9ae0\ua89f\u81a6\u92b7\u9aa1\ua841\u814b", -385511669);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-901100020 ^ (long)-901100021);
            if (var7) break block23;
            var0_6 = (int)((long)1556743967 ^ (long)-1556743968);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-309691610 ^ (long)-309691567);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-2086337818 ^ (long)2086337817);
                    if (77.\u2003\u200a) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!77.\u2003\u200a) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u60e9\u4973\u5a30\u5257\u60ea\u49d7\u5ad2\u52ba\u6015\u4951\u5a3d\u522e\u60d5", -1451669634);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)655237920 ^ (long)655237927);
                            var0_6 = (int)((long)1742006440 ^ (long)-1742006441);
                            while (true) {
                                v0 = (int)((long)-366201600 ^ (long)-366201515);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)532612898 ^ (long)532612898);
                                if (!77.\u2003\u200a) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!77.\u2003\u200a) ** continue;
                                throw null;
                            }
                            77.d = var5_1;
                            77.e = new String[(int)((long)2054243182 ^ (long)2054243170)];
                            if (!77.\u2003\u200a) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1380093653 ^ (long)1380093653);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-706889085 ^ (long)-706889086)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)86937463 ^ (long)86937456)) {
                                case 0: {
                                    v15 = (int)((long)1400683914 ^ (long)1400683911);
                                    if (!77.\u2003\u200a) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-2031246173 ^ (long)-2031246184);
                                    if (!77.\u2003\u200a) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)2059156637 ^ (long)2059156631);
                                    if (!77.\u2003\u200a) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1887782039 ^ (long)1887782094);
                                    if (!77.\u2003\u200a) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1580837975 ^ (long)-1580837931);
                                    if (!77.\u2003\u200a) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)158741848 ^ (long)158741774);
                                    if (!77.\u2003\u200a) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)740112851 ^ (long)740112830);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!77.\u2003\u200a);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 77.\u2003\u200a;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1314846686 ^ (long)-1314846291)) & (int)((long)-1841214514 ^ (long)-1841187791);
            if (var9_2) ** GOTO lbl-1000
            if (77.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 77.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1910666189 ^ (long)-1910666189)] & (int)((long)1308908296 ^ (long)1308908535)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1334674752 ^ (long)1334674936);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1918372591 ^ (long)-1918372496);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1491565450 ^ (long)1491565325);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1067615722 ^ (long)1067615561);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)969567840 ^ (long)969567890);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1840425902 ^ (long)1840425893);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-399234796 ^ (long)-399234602);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-499394443 ^ (long)-499394305);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1264198064 ^ (long)1264198053);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1520179701 ^ (long)-1520179704);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1901016585 ^ (long)-1901016655);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1446701711 ^ (long)1446701747);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1687764384 ^ (long)1687764260);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)2001562192 ^ (long)2001562204);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)90066135 ^ (long)90066127);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-213874176 ^ (long)-213873925);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1415935081 ^ (long)1415935156);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1102145240 ^ (long)1102145196);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)55923352 ^ (long)55923319);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1871355222 ^ (long)-1871355152);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-238434708 ^ (long)-238434671);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)718194030 ^ (long)718193974);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)2003486407 ^ (long)2003486371);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-430766536 ^ (long)-430766352);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)516398553 ^ (long)516398473);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-762804567 ^ (long)-762804504);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1171628011 ^ (long)-1171627845);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-749165383 ^ (long)-749165547);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-2030875666 ^ (long)-2030875821);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1743084185 ^ (long)1743084235);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1255090580 ^ (long)-1255090614);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1485797203 ^ (long)-1485797313);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-53473061 ^ (long)-53473256);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1434812469 ^ (long)-1434812551);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1837272430 ^ (long)1837272347);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-834582960 ^ (long)-834582823);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1389874948 ^ (long)1389875083);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1455111943 ^ (long)-1455112125);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1538086758 ^ (long)1538086673);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)634515747 ^ (long)634515861);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-2121286022 ^ (long)-2121286036);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-2074471078 ^ (long)-2074471162);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-517849715 ^ (long)-517849796);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1766948497 ^ (long)1766948459);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)731582119 ^ (long)731582071);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-708477970 ^ (long)-708478205);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1650494073 ^ (long)-1650494182);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-220548085 ^ (long)-220547977);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-692485291 ^ (long)-692485314);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)82692147 ^ (long)82692260);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)688989216 ^ (long)688989425);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-851212699 ^ (long)-851212621);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-819345918 ^ (long)-819345750);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)94271225 ^ (long)94270994);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-275033702 ^ (long)-275033661);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1525491239 ^ (long)1525491321);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1801140467 ^ (long)1801140449);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1615147350 ^ (long)1615147395);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)664784108 ^ (long)664784002);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1102290358 ^ (long)-1102290242);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-2027511449 ^ (long)-2027511486);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1373714090 ^ (long)-1373713923);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-826274768 ^ (long)-826274699);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)2038409805 ^ (long)2038409945);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-604578897 ^ (long)-604579002);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)327645835 ^ (long)327645850);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-306698565 ^ (long)-306698522);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)261841966 ^ (long)261842013);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-309857191 ^ (long)-309857199);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)485743750 ^ (long)485743689);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1914541725 ^ (long)1914541805);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1753172127 ^ (long)-1753172196);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1259609364 ^ (long)1259609395);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)967055179 ^ (long)967055110);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-2072819797 ^ (long)-2072819760);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)563819489 ^ (long)563819450);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1352386773 ^ (long)-1352386603);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-268365746 ^ (long)-268365822);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-2034282714 ^ (long)-2034282550);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1503154855 ^ (long)-1503154752);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)314271950 ^ (long)314271852);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)674023493 ^ (long)674023519);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1711612261 ^ (long)-1711612412);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-2080000825 ^ (long)-2080001012);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-698633811 ^ (long)-698633852);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)123751789 ^ (long)123751740);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1502451402 ^ (long)-1502451272);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-862960023 ^ (long)-862959951);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1729668163 ^ (long)-1729668269);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1434703396 ^ (long)-1434703416);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)2017632080 ^ (long)2017632103);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-458335804 ^ (long)-458335929);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-727496114 ^ (long)-727496054);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)546180503 ^ (long)546180463);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-193863924 ^ (long)-193863922);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-556463192 ^ (long)-556463338);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-719824434 ^ (long)-719824623);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)942382651 ^ (long)942382843);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1540911771 ^ (long)-1540911857);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1521648130 ^ (long)1521648253);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1426393475 ^ (long)1426393512);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1910682142 ^ (long)1910682186);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)805217764 ^ (long)805217557);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1358845352 ^ (long)1358845390);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1546576113 ^ (long)1546575878);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1565402183 ^ (long)1565402232);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1501192070 ^ (long)-1501191967);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)69471197 ^ (long)69471057);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-649207815 ^ (long)-649208011);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)2047089704 ^ (long)2047089739);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-612734402 ^ (long)-612734322);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-250161756 ^ (long)-250161785);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1095936762 ^ (long)1095936607);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1468637306 ^ (long)1468637235);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1243617860 ^ (long)1243617946);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1798501881 ^ (long)1798501736);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1517987538 ^ (long)-1517987402);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)771607801 ^ (long)771607771);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1469594145 ^ (long)-1469594126);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1936628650 ^ (long)-1936628571);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-393398330 ^ (long)-393398311);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1635331939 ^ (long)1635331841);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1444137546 ^ (long)1444137503);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)907494716 ^ (long)907494767);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-657088548 ^ (long)-657088687);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-300225746 ^ (long)-300225686);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-682232395 ^ (long)-682232555);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1909681636 ^ (long)1909681658);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)628469953 ^ (long)628469894);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1955420577 ^ (long)-1955420442);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-213957564 ^ (long)-213957455);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1034736916 ^ (long)-1034737141);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1752696417 ^ (long)-1752696385);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)2089473529 ^ (long)2089473297);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1114600082 ^ (long)-1114599952);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-2079677538 ^ (long)-2079677496);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-815985843 ^ (long)-815985794);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)63373476 ^ (long)63373368);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-483151900 ^ (long)-483152127);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-146306048 ^ (long)-146306001);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1522164485 ^ (long)1522164505);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1863218181 ^ (long)1863218379);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1001831400 ^ (long)1001831303);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1085328848 ^ (long)-1085328737);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-958818688 ^ (long)-958818684);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1018709259 ^ (long)1018709450);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1327217523 ^ (long)-1327217551);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)359238834 ^ (long)359238733);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1797026704 ^ (long)-1797026698);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-563141654 ^ (long)-563141718);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1688196590 ^ (long)-1688196520);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1509120060 ^ (long)1509120004);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-783746496 ^ (long)-783746444);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)967686081 ^ (long)967686064);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-553835086 ^ (long)-553835060);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1989723991 ^ (long)1989724029);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1383421929 ^ (long)1383421823);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1522850423 ^ (long)-1522850469);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-923974036 ^ (long)-923973911);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1936241219 ^ (long)1936241290);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1671780998 ^ (long)-1671781041);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)990134844 ^ (long)990134844);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)637083953 ^ (long)637084037);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1305679882 ^ (long)1305679965);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1383725877 ^ (long)-1383725882);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)694282733 ^ (long)694282659);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1848336819 ^ (long)1848336663);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1981554626 ^ (long)1981554439);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1480575690 ^ (long)-1480575537);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1804062591 ^ (long)1804062477);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1226105287 ^ (long)1226105329);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-16519260 ^ (long)-16519375);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-677359632 ^ (long)-677359656);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-70147589 ^ (long)-70147733);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-605164728 ^ (long)-605164755);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1529644691 ^ (long)-1529644696);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)474786707 ^ (long)474786598);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-2017079040 ^ (long)-2017078886);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)2138381066 ^ (long)2138381192);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1171841730 ^ (long)-1171841651);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)17803118 ^ (long)17803172);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-557054104 ^ (long)-557054140);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-454990854 ^ (long)-454991034);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)2002196570 ^ (long)2002196621);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1275548989 ^ (long)1275549082);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1765884510 ^ (long)1765884604);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1655108547 ^ (long)1655108492);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1520519716 ^ (long)-1520519910);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-688445556 ^ (long)-688445489);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)778686075 ^ (long)778685980);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)894298596 ^ (long)894298586);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1486491112 ^ (long)-1486490943);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1822743918 ^ (long)-1822744023);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)342840117 ^ (long)342840259);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1879153673 ^ (long)1879153672);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1576037048 ^ (long)-1576037007);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)62245966 ^ (long)62245953);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-747550645 ^ (long)-747550614);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-308763699 ^ (long)-308763724);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-2118431889 ^ (long)-2118431915);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)744547521 ^ (long)744547535);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-561291778 ^ (long)-561291906);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1991684495 ^ (long)-1991684510);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)474363523 ^ (long)474363612);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-694669779 ^ (long)-694669739);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-891064806 ^ (long)-891064792);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)740646704 ^ (long)740646748);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)7491862 ^ (long)7491853);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1492886199 ^ (long)-1492886261);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)696512317 ^ (long)696512411);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1410235938 ^ (long)-1410236135);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1536919526 ^ (long)-1536919406);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1179295035 ^ (long)1179295208);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)894307541 ^ (long)894307579);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)493249152 ^ (long)493249274);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1616563085 ^ (long)1616563051);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)770760270 ^ (long)770760279);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)390256241 ^ (long)390256277);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-909982298 ^ (long)-909982282);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1315567312 ^ (long)1315567341);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1580137506 ^ (long)-1580137516);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1023279130 ^ (long)1023279287);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1430223760 ^ (long)1430223674);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1877581668 ^ (long)-1877581675);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-862041996 ^ (long)-862041980);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1139572013 ^ (long)-1139572160);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1522316082 ^ (long)1522316153);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1912332593 ^ (long)1912332696);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-410330811 ^ (long)-410330763);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)307546831 ^ (long)307546840);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-110891541 ^ (long)-110891568);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1723352037 ^ (long)-1723351857);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-333626486 ^ (long)-333626430);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1755928010 ^ (long)-1755927978);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-790096291 ^ (long)-790096201);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-2145626093 ^ (long)-2145625869);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1064704440 ^ (long)1064704356);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1666325798 ^ (long)-1666325762);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1557714578 ^ (long)1557714683);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-801593332 ^ (long)-801593209);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1202370423 ^ (long)-1202370545);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-338015845 ^ (long)-338015964);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-518279892 ^ (long)-518279729);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1785576599 ^ (long)1785576698);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1969381667 ^ (long)-1969381707);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-953338825 ^ (long)-953338643);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-358952780 ^ (long)-358952939);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1168577940 ^ (long)1168577871);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1369988986 ^ (long)-1369988880);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1672014975 ^ (long)-1672015028);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1407609264 ^ (long)-1407609113);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1692640804 ^ (long)-1692640963);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1126658073 ^ (long)-1126658202);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1736052083 ^ (long)1736052084);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)331024519 ^ (long)331024538);
                    if (!77.\u2003\u200a) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1095732935 ^ (long)1095732982);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)215112836 ^ (long)215112827)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)2015687876 ^ (long)2015628091)) >>> (int)((long)-413786115 ^ (long)-413786123)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)2011355517 ^ (long)2011355517);
            if (!77.\u2003\u200a) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1223662872 ^ (long)-1223662870);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)78810962 ^ (long)78810961) | var5_6 << (int)((long)1972235523 ^ (long)1972235526)) ^ var3_4[var7_8]) & (int)((long)1762310579 ^ (long)1762310476);
                    if (77.\u2003\u200a) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1887114728 ^ (long)-1887114725) | var6_7 << (int)((long)-250108175 ^ (long)-250108172)) ^ var3_4[var7_8]) & (int)((long)1865204734 ^ (long)1865204481);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            77.e[var2_3] = new String(var3_4).intern();
        }
        return 77.e[var2_3];
    }

    public 77() {
        boolean bl = \u2003\u200a;
        super(77.b((int)((long)634871446 ^ (long)-634871569), (int)((long)-2027665887 ^ (long)2027663084)) /* "Weather" */, 77.b((int)((long)-3501034 ^ (long)3500644), (int)((long)1510831866 ^ (long)-1510806867)) /* "Control the weather" */);
        this.5 = (1P)((34X)((34X)((34X)this.4().5(77.b((int)((long)-1066532868 ^ (long)1066533256), (int)((long)-933826066 ^ (long)933836367)) /* "Rain" */)).7(77.b((int)((long)112760591 ^ (long)-112760459), (int)((long)335643263 ^ (long)-335653395)) /* "rain" */)).1(77.b((int)((long)-479621581 ^ (long)479621189), (int)((long)1634769330 ^ (long)1634782128)) /* "Choose whether or not rain is falling" */)).5();
        this.8 = (1P)((34X)((34X)((34X)this.4().5(77.b((int)((long)2027021389 ^ (long)-2027021766), (int)((long)-470553394 ^ (long)470554735)))).7(77.b((int)((long)-1569125579 ^ (long)1569125702), (int)((long)-163745176 ^ (long)-163761284)) /* "thunder" */)).1(77.b((int)((long)-112745733 ^ (long)112745614), (int)((long)-236333553 ^ (long)-236340689)) /* "Choose whether or not there is thunder" */)).5();
        this.4 = new Listener(sh -> {
            float f;
            float f2;
            int n;
            String string;
            boolean bl = \u2003\u200a;
            if (bl || bl) return;
            if (77.3.r == null) {
                if (bl || bl) return;
                this.9 = null;
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            if (sh.5 != EventState.PRE) {
                if (bl || bl) return;
                return;
            }
            if (bl) {
                return;
            }
            String string2 = 77.b((int)((long)-1609187609 ^ (long)1609187478), (int)((long)1874674882 ^ (long)-1874669091)) /* "suffix" */;
            if (this.8.2) {
                string = 77.b((int)((long)-573128272 ^ (long)573128640), (int)((long)559842635 ^ (long)559870472)) /* "Thunder" */;
                if (\u2003\u200a) {
                    throw null;
                }
            } else if (this.5.2) {
                string = 77.b((int)((long)-2115449182 ^ (long)2115449049), (int)((long)1563746993 ^ (long)1563723339));
                if (\u2003\u200a) {
                    throw null;
                }
            } else {
                string = 77.b((int)((long)-1155698987 ^ (long)1155698861), (int)((long)-631624804 ^ (long)-631622772)) /* "Clear" */;
            }
            2R.1(this, string2, string);
            if (this.9 == null) {
                this.9 = new 58(77.3.r.w().k(), 77.3.r.d(1.0f), 77.3.r.b(1.0f));
            }
            dwt.a a2 = 77.3.r.w();
            if (this.5.2 || this.8.2) {
                n = (int)((long)1255204047 ^ (long)1255204046);
                if (\u2003\u200a) {
                    throw null;
                }
            } else {
                n = (int)((long)606798097 ^ (long)606798097);
            }
            a2.b(n != 0);
            dwt dwt2 = 77.3.r;
            if (this.5.2 || this.8.2) {
                f2 = 1.0f;
                if (\u2003\u200a) {
                    throw null;
                }
            } else {
                f2 = 0.0f;
            }
            dwt2.e(f2);
            dwt dwt3 = 77.3.r;
            if (this.8.2) {
                f = 1.0f;
                if (\u2003\u200a) {
                    throw null;
                }
            } else {
                f = 0.0f;
            }
            dwt3.c(f);
        }, new Predicate[(int)((long)1142373903 ^ (long)1142373903)]);
        this.0 = new Listener(sx -> {
            block3: {
                block2: {
                    boolean bl = \u2003\u200a;
                    if (bl || bl) break block2;
                    this.9 = null;
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)-1682614406 ^ (long)-1682614406)]);
        Predicate[] predicateArray = new Predicate[(int)((long)-1813410492 ^ (long)-1813410491)];
        Class[] classArray = new Class[(int)((long)-1356106747 ^ (long)-1356106748)];
        classArray[(int)((long)630852703 ^ (long)630852703)] = pq.class;
        predicateArray[(int)((long)1161751179 ^ (long)1161751179)] = new 34k(classArray);
        this.1 = new Listener(i -> {
            boolean bl = \u2003\u200a;
            if (bl) return;
            String[] stringArray = 3e.5();
            if (bl || bl) return;
            if (i.2 != EventState.PRE) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            pq pq2 = (pq)i.7;
            if (bl || bl) return;
            if (this.9 == null) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            pq.a[] aArray = new pq.a[(int)((long)-2075305013 ^ (long)-2075305017)];
            aArray[(int)((long)859411597 ^ (long)859411597)] = pq.a;
            aArray[(int)((long)946801757 ^ (long)946801756)] = pq.b;
            aArray[(int)((long)1959792096 ^ (long)1959792098)] = pq.c;
            aArray[(int)((long)571130380 ^ (long)571130383)] = pq.d;
            aArray[(int)((long)164801452 ^ (long)164801448)] = pq.e;
            aArray[(int)((long)1865863478 ^ (long)1865863475)] = pq.f;
            aArray[(int)((long)1748273583 ^ (long)1748273577)] = pq.g;
            aArray[(int)((long)-1779302906 ^ (long)-1779302911)] = pq.h;
            aArray[(int)((long)878291689 ^ (long)878291681)] = pq.i;
            aArray[(int)((long)-1270440793 ^ (long)-1270440786)] = pq.j;
            aArray[(int)((long)307636913 ^ (long)307636923)] = pq.k;
            aArray[(int)((long)900423513 ^ (long)900423506)] = pq.l;
            switch (Arrays.asList(aArray).indexOf(pq2.b())) {
                case 1: {
                    if (bl) return;
                    this.9.2 = (int)((long)1814307998 ^ (long)1814307999);
                    if (bl || bl) return;
                    this.9.0 = 0.0f;
                    if (bl || bl) return;
                    if (stringArray == null) break;
                    if (bl) return;
                }
                case 2: {
                    if (bl) return;
                    this.9.2 = (int)((long)-1609813728 ^ (long)-1609813728);
                    if (bl || bl) return;
                    this.9.0 = 1.0f;
                    if (bl || bl) return;
                    if (stringArray == null) break;
                    if (bl) return;
                }
                case 7: {
                    if (bl) return;
                    this.9.0 = pq2.c();
                    if (bl || bl) return;
                    if (stringArray == null) break;
                    if (bl) return;
                }
                case 8: {
                    if (bl) return;
                    this.9.9 = pq2.c();
                    if (bl || bl) return;
                    if (stringArray == null) break;
                    if (bl) return;
                }
                default: {
                    if (bl) return;
                    return;
                }
            }
            if (bl) return;
            i.cancel();
            if (!bl && !bl) return;
        }, predicateArray);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2003\u200a;
                    if (bl || bl) break block2;
                    if (77.3.r == null) break block3;
                    if (bl || bl) break block2;
                    dwt dwt2 = 77.3.r;
                    58 var1_3 = this.9;
                    if (bl || bl) break block2;
                    dwt2.w().b(var1_3.2);
                    if (bl || bl) break block2;
                    dwt2.e(var1_3.0);
                    if (bl || bl) break block2;
                    dwt2.c(var1_3.9);
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }
}

