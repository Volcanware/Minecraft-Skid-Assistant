/* ==========================================================================
 * MODULE: Breaker
 * CATEGORY (inferred): Player
 * DESCRIPTION: Break nearby minigame respawn blocks
 * OBFUSCATED CLASS: net.impactclient.05
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  ccj
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.2w$6X;
import net.impactclient.34X;
import net.impactclient.3X;
import net.impactclient.4M;
import net.impactclient.4X;
import net.impactclient.66;
import net.impactclient.8S;
import net.impactclient.9V;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 05
extends 3X
implements 4M {
    private 1P 4;
    private static final String[] e;
    private 1P 0;
    @EventHandler
    private final Listener<4X> 7;
    private List<8S> 8;
    private 8S 5;
    private static final String[] d;
    private 1P 6;
    public static final boolean \u2007\u2002\u200d\u200a\u2000;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 05.\u2007\u2002\u200d\u200a\u2000;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-832583185 ^ (long)-832583196)];
            if (var7) break block23;
            var3_2 = (int)((long)-226587508 ^ (long)-226587508);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ub976\u910b\u8234\u8a45\ub9a8\u9151\u82af\u8a89\ub9ef\u91fa\u8237\u8a69\ub93d\u9183\u82ac\u8aab\ub9d2\u9125\u82bf\u8afd\ub92b\u910d\u8272\u8a63\ub9a3\u91e8\u8284\u8aba\ub90c\u911b\u8227\u8ae2\ub901\u9111\u8201\u8a87\ub986\u9145\u8268\u8a11\ub9d7\u91e3\u820c\u8a04\ub9ca\u9162\u8257\u8ae2\ub99c\u91cc\u8207\u8a05\ub950\u91ea\u827d\u8aa8\ub95c\u9135\u82a4\u8a17\ub92f\u91f4\u822b\u8a1e\ub9db\u91ef\u820c\u8a5c\ub9ef\u915d\u822c\u8a53\ub989\u91b3\u82a8\u8acf\ub942\u9131\u82c6\u8a51\ub937\u918c\u82ae\u8a81\ub953\u91d5\u8248\u8af2\ub9cb\u91f3\u826d\u8ad8\ub952\u9157\u82f3\u8ab0\ub9a5\u91e8\u8266\u8a3c\ub983\u9150\u82c6\u8a3e\ub9aa\u9136\u82d0\u8af8\ub95b\u91ac\u82c0\u8a6a\ub91f\u9195\u820c\u8ac0\ub988\u91de\u821f\u8a75\ub988\u9160\u8264\u8a9b\ub949\u91ee", 536190908);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)894497399 ^ (long)894497395);
            if (var7) break block23;
            var0_6 = (int)((long)1658889346 ^ (long)-1658889347);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1491934202 ^ (long)-1491934109);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)842053907 ^ (long)-842053908);
                    if (05.\u2007\u2002\u200d\u200a\u2000) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!05.\u2007\u2002\u200d\u200a\u2000) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ud071\uf8e0\ueb52\ue358\ud091\uf8f9\ueb27\ue338\ud055\uf8ad\uebfb\ue3fa\ud0f8\uf815\ueb7b\ue3c6\ud040\uf8d1\ueb36\ue39b\ud02b\uf80d\ueb46\ue309\ud069\uf82a", -834472316);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)873930541 ^ (long)873930559);
                            var0_6 = (int)((long)1043576002 ^ (long)-1043576003);
                            while (true) {
                                v0 = (int)((long)-1068429182 ^ (long)-1068429167);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1419736700 ^ (long)1419736700);
                                if (!05.\u2007\u2002\u200d\u200a\u2000) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!05.\u2007\u2002\u200d\u200a\u2000) ** continue;
                                throw null;
                            }
                            05.d = var5_1;
                            05.e = new String[(int)((long)1209290110 ^ (long)1209290101)];
                            if (!05.\u2007\u2002\u200d\u200a\u2000) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-567124053 ^ (long)-567124053);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)2025912287 ^ (long)2025912286)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-155245041 ^ (long)-155245048)) {
                                case 0: {
                                    v15 = (int)((long)-1611638869 ^ (long)-1611638851);
                                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1269799008 ^ (long)-1269798979);
                                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1333558617 ^ (long)-1333558656);
                                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-343875381 ^ (long)-343875360);
                                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1835742962 ^ (long)-1835742863);
                                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)745739160 ^ (long)745739158);
                                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-71418582 ^ (long)-71418546);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!05.\u2007\u2002\u200d\u200a\u2000);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    private static /* synthetic */ double 9(8S s, 8S s2) {
        boolean bl = \u2007\u2002\u200d\u200a\u2000;
        if (bl || bl) {
            return 0.0;
        }
        return s2.4(s);
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 0(4X x2, 8S s) {
        block3: {
            block2: {
                boolean bl = \u2007\u2002\u200d\u200a\u2000;
                if (bl || bl) break block2;
                9V v = 66.3(s);
                if (bl || bl) break block2;
                x2.6(v.6).2(v.3);
                if (bl || bl) break block2;
                this.5 = s;
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 05.\u2007\u2002\u200d\u200a\u2000;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1412446360 ^ (long)-1412447202)) & (int)((long)795070198 ^ (long)795029769);
            if (var9_2) ** GOTO lbl-1000
            if (05.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 05.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)199004112 ^ (long)199004112)] & (int)((long)1761544322 ^ (long)1761544317)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1932419629 ^ (long)-1932419779);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1751988946 ^ (long)1751988913);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)2057544174 ^ (long)2057543953);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-125384855 ^ (long)-125384732);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1441315673 ^ (long)1441315816);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-419941148 ^ (long)-419941216);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)856748070 ^ (long)856748103);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1437475073 ^ (long)-1437475240);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1429212739 ^ (long)1429212913);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)279335069 ^ (long)279335017);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)709232064 ^ (long)709232058);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1900988374 ^ (long)-1900988361);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1346169987 ^ (long)-1346170072);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1628974882 ^ (long)-1628975084);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1953059833 ^ (long)1953059599);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)577618811 ^ (long)577618891);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1626618576 ^ (long)1626618552);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1078033510 ^ (long)1078033505);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1418916328 ^ (long)-1418916325);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1774228412 ^ (long)1774228293);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)308073901 ^ (long)308073903);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1048408503 ^ (long)-1048408418);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)345190473 ^ (long)345190564);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)248210255 ^ (long)248210200);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-2049545815 ^ (long)-2049545876);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1869725431 ^ (long)-1869725293);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-403927986 ^ (long)-403927900);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-724122818 ^ (long)-724122718);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-981340940 ^ (long)-981340946);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)37078945 ^ (long)37079007);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-2113781767 ^ (long)-2113781799);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-2118089247 ^ (long)-2118089330);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-154517411 ^ (long)-154517482);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)235627949 ^ (long)235627785);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-56244465 ^ (long)-56244258);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-441777201 ^ (long)-441777346);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1015974077 ^ (long)1015973915);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)885732145 ^ (long)885732148);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-849840275 ^ (long)-849840356);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)758316106 ^ (long)758316209);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1556142176 ^ (long)1556142264);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1645846346 ^ (long)-1645846381);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-586421465 ^ (long)-586421388);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-773978902 ^ (long)-773978960);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)469327660 ^ (long)469327864);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)895373652 ^ (long)895373601);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1339411862 ^ (long)1339411865);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1257123279 ^ (long)1257123297);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1741213034 ^ (long)-1741213112);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1595697778 ^ (long)-1595697875);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1580469631 ^ (long)1580469664);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)36948066 ^ (long)36947976);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-633436848 ^ (long)-633436823);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1141382567 ^ (long)1141382619);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)2025020870 ^ (long)2025020805);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-371567613 ^ (long)-371567613);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1767922307 ^ (long)-1767922355);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-781150343 ^ (long)-781150287);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-44385569 ^ (long)-44385648);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1008734654 ^ (long)1008734468);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1541489303 ^ (long)1541489345);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)237075123 ^ (long)237075109);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-2098797553 ^ (long)-2098797318);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1505679376 ^ (long)1505679557);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-312443043 ^ (long)-312443079);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1269620871 ^ (long)-1269620920);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1570251847 ^ (long)-1570251985);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-2133810309 ^ (long)-2133810264);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-127643890 ^ (long)-127643833);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-2139059582 ^ (long)-2139059614);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)14750727 ^ (long)14750868);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-206823875 ^ (long)-206823913);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)656573210 ^ (long)656573317);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1516788914 ^ (long)1516788761);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1094888476 ^ (long)1094888617);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)2112148590 ^ (long)2112148636);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1854670189 ^ (long)-1854670262);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1143144923 ^ (long)-1143144884);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)158876486 ^ (long)158876480);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-423047689 ^ (long)-423047815);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-966064525 ^ (long)-966064385);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)325151973 ^ (long)325151825);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1891003293 ^ (long)1891003357);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-486265270 ^ (long)-486265259);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1665247707 ^ (long)1665247563);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1173617006 ^ (long)1173616947);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)461453041 ^ (long)461452893);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1111997445 ^ (long)-1111997591);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1266613290 ^ (long)-1266613395);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)418318033 ^ (long)418317867);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-692094769 ^ (long)-692094907);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1391060600 ^ (long)-1391060697);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1914651905 ^ (long)-1914652048);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1346497206 ^ (long)-1346497269);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1623650722 ^ (long)1623650694);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)361702171 ^ (long)361702192);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-793729416 ^ (long)-793729501);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1821439106 ^ (long)-1821438983);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)158404581 ^ (long)158404590);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)39594998 ^ (long)39594847);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)931223373 ^ (long)931223539);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)994442674 ^ (long)994442662);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1752282143 ^ (long)1752282155);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)777417665 ^ (long)777417552);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1040633519 ^ (long)1040633444);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1703497360 ^ (long)1703497461);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-736714192 ^ (long)-736713986);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1241927633 ^ (long)-1241927507);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)886076217 ^ (long)886076410);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-944732423 ^ (long)-944732492);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)836155865 ^ (long)836155833);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1047780303 ^ (long)-1047780295);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-590017027 ^ (long)-590017037);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)569383578 ^ (long)569383518);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1495504187 ^ (long)1495504131);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1396945021 ^ (long)-1396944942);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-242848918 ^ (long)-242848857);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-603236460 ^ (long)-603236408);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1980165444 ^ (long)1980165524);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-2071118513 ^ (long)-2071118346);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1272845251 ^ (long)-1272845094);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-803549189 ^ (long)-803549364);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-318349724 ^ (long)-318349752);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)120069608 ^ (long)120069486);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1324207186 ^ (long)1324207180);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1725954580 ^ (long)1725954601);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)2051333411 ^ (long)2051333377);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1951350677 ^ (long)-1951350712);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)709376287 ^ (long)709376274);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1357670737 ^ (long)1357670683);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-304735848 ^ (long)-304735887);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-99773656 ^ (long)-99773596);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-849259163 ^ (long)-849259130);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-25720776 ^ (long)-25720714);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)62417815 ^ (long)62417784);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-2007363943 ^ (long)-2007363866);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-885952583 ^ (long)-885952556);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-505435169 ^ (long)-505435293);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-520548715 ^ (long)-520548843);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1826732342 ^ (long)-1826732466);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1887582146 ^ (long)-1887582048);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)275166950 ^ (long)275166756);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-84063459 ^ (long)-84063446);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1180945441 ^ (long)-1180945538);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-2028206479 ^ (long)-2028206352);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)490647099 ^ (long)490647174);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1821898102 ^ (long)1821898103);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-426581696 ^ (long)-426581736);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-434945011 ^ (long)-434944819);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1707727362 ^ (long)-1707727524);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-602537000 ^ (long)-602537152);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1083376094 ^ (long)1083375904);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)443911007 ^ (long)443911064);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1037571101 ^ (long)1037571145);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-900516419 ^ (long)-900516452);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-131003116 ^ (long)-131003096);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)689102726 ^ (long)689102766);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1754709664 ^ (long)-1754709591);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1082292194 ^ (long)1082291982);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1971295091 ^ (long)-1971295042);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1519494872 ^ (long)1519494816);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1712863483 ^ (long)1712863381);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1018213510 ^ (long)-1018213556);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-2013423204 ^ (long)-2013423179);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1327002103 ^ (long)1327001935);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1131388677 ^ (long)-1131388798);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1722563327 ^ (long)-1722563234);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1560816887 ^ (long)1560816795);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1561790414 ^ (long)1561790216);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-730662949 ^ (long)-730663168);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1692338852 ^ (long)1692338698);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-935226822 ^ (long)-935226872);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-135331565 ^ (long)-135331487);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)2084064719 ^ (long)2084064699);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-236606891 ^ (long)-236606865);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1261376596 ^ (long)1261376689);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)38278707 ^ (long)38278664);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1240091398 ^ (long)-1240091507);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1036422990 ^ (long)1036423060);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)775223512 ^ (long)775223486);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1211844593 ^ (long)1211844468);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-78973397 ^ (long)-78973226);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1241962534 ^ (long)1241962649);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)518030974 ^ (long)518030985);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1680285588 ^ (long)1680285469);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1274137978 ^ (long)1274137954);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1790425046 ^ (long)-1790425056);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)201909737 ^ (long)201909505);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1240372873 ^ (long)-1240372882);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1444352707 ^ (long)-1444352600);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)627870430 ^ (long)627870451);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-241283358 ^ (long)-241283466);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1056903546 ^ (long)-1056903645);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1087973113 ^ (long)-1087973055);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)234855139 ^ (long)234855032);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-2030405657 ^ (long)-2030405695);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-996506692 ^ (long)-996506743);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1594333118 ^ (long)1594332989);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)2000596226 ^ (long)2000596383);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)628161833 ^ (long)628161946);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1547751160 ^ (long)1547750920);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)2074915599 ^ (long)2074915616);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1561416377 ^ (long)1561416350);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)817683307 ^ (long)817683321);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)993301371 ^ (long)993301310);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)452743378 ^ (long)452743295);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1146017873 ^ (long)-1146017795);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-583309160 ^ (long)-583309094);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-102723232 ^ (long)-102723194);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1168305761 ^ (long)1168305682);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1835731780 ^ (long)1835731762);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1693282808 ^ (long)-1693282580);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1290034919 ^ (long)-1290034923);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1053797027 ^ (long)-1053796992);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1999909565 ^ (long)1999909621);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1862178227 ^ (long)-1862178132);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1267925127 ^ (long)1267925115);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-508894982 ^ (long)-508895062);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1363977972 ^ (long)1363977860);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)596455081 ^ (long)596455002);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1833518935 ^ (long)-1833519000);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)44583559 ^ (long)44583469);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1114293145 ^ (long)-1114293039);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-523556378 ^ (long)-523556382);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)761576360 ^ (long)761576394);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-2831880 ^ (long)-2832076);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)439366316 ^ (long)439366228);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-409373780 ^ (long)-409373710);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)215445803 ^ (long)215445816);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1765596864 ^ (long)1765596761);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1467953136 ^ (long)-1467952954);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1074329255 ^ (long)-1074329166);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)176677961 ^ (long)176678037);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1749493520 ^ (long)1749493511);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1421495438 ^ (long)-1421495454);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1480650392 ^ (long)1480650371);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1516751397 ^ (long)1516751534);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-100171156 ^ (long)-100171241);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-338111891 ^ (long)-338111771);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-702313620 ^ (long)-702313524);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)977183453 ^ (long)977183306);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-532684158 ^ (long)-532684069);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-171684957 ^ (long)-171684942);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1410236028 ^ (long)1410236078);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1436120486 ^ (long)-1436120427);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-113531933 ^ (long)-113531940);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1619584036 ^ (long)1619584089);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)2139415335 ^ (long)2139415321);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1653367119 ^ (long)-1653367123);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-332351032 ^ (long)-332351057);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-2055529347 ^ (long)-2055529259);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-958862863 ^ (long)-958862950);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-875207884 ^ (long)-875207903);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)866460788 ^ (long)866460723);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1914671468 ^ (long)1914671461);
                    if (!05.\u2007\u2002\u200d\u200a\u2000) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)263610471 ^ (long)263610501);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-394717858 ^ (long)-394717791)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1693702138 ^ (long)-1693657095)) >>> (int)((long)-1956647788 ^ (long)-1956647780)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1312853419 ^ (long)-1312853419);
            if (!05.\u2007\u2002\u200d\u200a\u2000) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1703900536 ^ (long)-1703900534);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1495286808 ^ (long)1495286811) | var5_6 << (int)((long)-1630232133 ^ (long)-1630232130)) ^ var3_4[var7_8]) & (int)((long)657969754 ^ (long)657969829);
                    if (05.\u2007\u2002\u200d\u200a\u2000) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1011762233 ^ (long)-1011762236) | var6_7 << (int)((long)1339049967 ^ (long)1339049962)) ^ var3_4[var7_8]) & (int)((long)-627793419 ^ (long)-627793654);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            05.e[var2_3] = new String(var3_4).intern();
        }
        return 05.e[var2_3];
    }

    public 05() {
        boolean bl = \u2007\u2002\u200d\u200a\u2000;
        super(05.b((int)((long)1787021582 ^ (long)1787021938), (int)((long)-243605805 ^ (long)243600223)) /* "Breaker" */, 05.b((int)((long)768548483 ^ (long)768548339), (int)((long)1427266186 ^ (long)1427269021)) /* "Break nearby minigame respawn blocks" */);
        Boolean bl2 = Boolean.TRUE;
        34X x2 = (34X)((34X)((34X)this.4().5(05.b((int)((long)-397209034 ^ (long)-397209280), (int)((long)-98148137 ^ (long)-98168608)) /* "Beds" */)).7(05.b((int)((long)1357773380 ^ (long)1357773111), (int)((long)137499104 ^ (long)-137525132)) /* "beds" */)).1(05.b((int)((long)1961532841 ^ (long)1961533148), (int)((long)1366383570 ^ (long)-1366365884)) /* "Break nearby beds" */);
        ((34X)((34X)((34X)this.4().5(05.b((int)((long)-397209034 ^ (long)-397209280), (int)((long)-98148137 ^ (long)-98168608)) /* "Beds" */)).7(05.b((int)((long)1357773380 ^ (long)1357773111), (int)((long)137499104 ^ (long)-137525132)) /* "beds" */)).1(05.b((int)((long)1961532841 ^ (long)1961533148), (int)((long)1366383570 ^ (long)-1366365884)) /* "Break nearby beds" */)).7 = bl2;
        this.4 = (1P)x2.5();
        bl2 = Boolean.TRUE;
        x2 = (34X)((34X)((34X)this.4().5(05.b((int)((long)1826433791 ^ (long)1826433421), (int)((long)-1236787656 ^ (long)1236772201)) /* "Cakes" */)).7(05.b((int)((long)1343558961 ^ (long)1343559247), (int)((long)-169406044 ^ (long)169395298)) /* "cakes" */)).1(05.b((int)((long)-923920739 ^ (long)-923920926), (int)((long)1329765660 ^ (long)-1329763627)) /* "Break nearby cakes" */);
        ((34X)((34X)((34X)this.4().5(05.b((int)((long)1826433791 ^ (long)1826433421), (int)((long)-1236787656 ^ (long)1236772201)) /* "Cakes" */)).7(05.b((int)((long)1343558961 ^ (long)1343559247), (int)((long)-169406044 ^ (long)169395298)) /* "cakes" */)).1(05.b((int)((long)-923920739 ^ (long)-923920926), (int)((long)1329765660 ^ (long)-1329763627)) /* "Break nearby cakes" */)).7 = bl2;
        this.0 = (1P)x2.5();
        bl2 = Boolean.TRUE;
        x2 = (34X)((34X)((34X)this.4().5(05.b((int)((long)422921462 ^ (long)422922119), (int)((long)-1763930106 ^ (long)-1763914519)) /* "Swing" */)).7(05.b((int)((long)632902302 ^ (long)632902122), (int)((long)-1748017540 ^ (long)1748016271)) /* "swing" */)).1(05.b((int)((long)-2143974921 ^ (long)-2143974784), (int)((long)-509441112 ^ (long)509420236)) /* "Swings the player's arm when breaking" */);
        ((34X)((34X)((34X)this.4().5(05.b((int)((long)422921462 ^ (long)422922119), (int)((long)-1763930106 ^ (long)-1763914519)) /* "Swing" */)).7(05.b((int)((long)632902302 ^ (long)632902122), (int)((long)-1748017540 ^ (long)1748016271)) /* "swing" */)).1(05.b((int)((long)-2143974921 ^ (long)-2143974784), (int)((long)-509441112 ^ (long)509420236)) /* "Swings the player's arm when breaking" */)).7 = bl2;
        this.6 = (1P)x2.5();
        this.7 = new Listener(var1_1 -> {
            /*
             * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
             * 
             * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [7[DOLOOP]], but top level block is 8[WHILELOOP]
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
             *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
             *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1050)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
             *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
             *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
             *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
             *     at org.benf.cfr.reader.Main.main(Main.java:54)
             */
            throw new IllegalStateException("Decompilation failed");
        }, new Predicate[(int)((long)-1545450927 ^ (long)-1545450927)]);
        this.8 = new ArrayList<8S>();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ boolean 8(8S s, 8S s2) {
        boolean bl = \u2007\u2002\u200d\u200a\u2000;
        if (bl || bl) return true;
        if (s2.4(s) > 4.25) {
            if (bl) return true;
            return (int)((long)904797645 ^ (long)904797644) != 0;
        }
        if (!bl) return (int)((long)891400237 ^ (long)891400237) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 9(ccj ccj2) {
        block3: {
            block2: {
                boolean bl = \u2007\u2002\u200d\u200a\u2000;
                if (bl || bl) break block2;
                this.8.add(66.5(ccj2.o()).7(0.5, 0.2, 0.5));
                if (!bl) break block3;
            }
            return;
        }
    }
}

