/* ==========================================================================
 * MODULE: Chest Stealer
 * CATEGORY (inferred): Player
 * DESCRIPTION: Automatically Steals items from Chests
 * OBFUSCATED CLASS: net.impactclient.74
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  bfw
 *  bij
 *  bik
 *  bjr
 *  djz
 *  dpz
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.11;
import net.impactclient.1P;
import net.impactclient.1z;
import net.impactclient.2w$6X;
import net.impactclient.34H;
import net.impactclient.34J;
import net.impactclient.34R;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.5p;
import net.impactclient.5z;
import net.impactclient.6k;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 74
extends 3X
implements 34R {
    public static final boolean \u2007\u2003\u2004\u2003;
    private 11 5;
    private static final String[] e;
    @EventHandler
    private final Listener<6k> 0;
    private 1P 2;
    private 1P 8;
    private static final String[] d;
    private 1P 6;
    private 1z 7;

    public 74() {
        boolean bl = \u2007\u2003\u2004\u2003;
        super(74.b((int)((long)1701437308 ^ (long)-1701416496), (int)((long)214797831 ^ (long)214811543)) /* "Chest Stealer" */, 74.b((int)((long)-1254565149 ^ (long)1254585416), (int)((long)-1043756821 ^ (long)-1043727934)) /* "Automatically Steals items from Chests" */);
        String[] stringArray = new String[(int)((long)479066270 ^ (long)479066268)];
        stringArray[(int)((long)-456865860 ^ (long)-456865860)] = 74.b((int)((long)290084675 ^ (long)-290063895), (int)((long)-1005678474 ^ (long)-1005651630)) /* "Shift" */;
        stringArray[(int)((long)-1182302945 ^ (long)-1182302946)] = 74.b((int)((long)1618235723 ^ (long)-1618214936), (int)((long)-13684304 ^ (long)-13666093)) /* "Pickup" */;
        Object object = stringArray;
        34J j2 = (34H)((34H)((34H)this.0().5(74.b((int)((long)-1105259003 ^ (long)1105246386), (int)((long)-1280812691 ^ (long)1280814683)) /* "Mode" */)).7(74.b((int)((long)2020467990 ^ (long)-2020455513), (int)((long)-959562789 ^ (long)-959557834)) /* "mode" */)).1(74.b((int)((long)-1654268383 ^ (long)1654288516), (int)((long)1977411453 ^ (long)1977400348)) /* "The method that is used to transfer chest contents" */);
        ((34H)((34H)((34H)this.0().5(74.b((int)((long)-1105259003 ^ (long)1105246386), (int)((long)-1280812691 ^ (long)1280814683)) /* "Mode" */)).7(74.b((int)((long)2020467990 ^ (long)-2020455513), (int)((long)-959562789 ^ (long)-959557834)) /* "mode" */)).1(74.b((int)((long)-1654268383 ^ (long)1654288516), (int)((long)1977411453 ^ (long)1977400348)) /* "The method that is used to transfer chest contents" */)).3 = object;
        this.5 = (11)j2.5();
        object = (int)((long)-263658323 ^ (long)-263658409);
        j2 = ((34e)((34e)((34e)this.1().5(74.b((int)((long)1212267377 ^ (long)-1212279344), (int)((long)-1559765822 ^ (long)1559785736)) /* "Delay" */)).7(74.b((int)((long)-1500099834 ^ (long)1500112299), (int)((long)1133467323 ^ (long)-1133458403)) /* "delay" */)).1(74.b((int)((long)-1221019231 ^ (long)1221007122), (int)((long)1498409650 ^ (long)1498405836)) /* "The delay between each item being stolen in Milliseconds" */)).3((int)((long)-1527514706 ^ (long)-1527514706)).2((int)((long)260403374 ^ (long)260403546));
        ((34e)((34e)((34e)this.1().5(74.b((int)((long)1212267377 ^ (long)-1212279344), (int)((long)-1559765822 ^ (long)1559785736)) /* "Delay" */)).7(74.b((int)((long)-1500099834 ^ (long)1500112299), (int)((long)1133467323 ^ (long)-1133458403)) /* "delay" */)).1(74.b((int)((long)-1221019231 ^ (long)1221007122), (int)((long)1498409650 ^ (long)1498405836)) /* "The delay between each item being stolen in Milliseconds" */)).3((int)((long)-1527514706 ^ (long)-1527514706)).2((int)((long)260403374 ^ (long)260403546)).7 = object;
        this.7 = (1z)((34e)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(74.b((int)((long)49294523 ^ (long)-49315307), (int)((long)820019737 ^ (long)-820034113)) /* "Auto Steal" */)).7(74.b((int)((long)1924474456 ^ (long)-1924495126), (int)((long)1292217670 ^ (long)-1292226202)) /* "auto" */)).1(74.b((int)((long)967556840 ^ (long)-967569337), (int)((long)1343130291 ^ (long)1343139143)) /* "Automatically steal when chests are opened" */);
        ((34X)((34X)((34X)this.4().5(74.b((int)((long)49294523 ^ (long)-49315307), (int)((long)820019737 ^ (long)-820034113)) /* "Auto Steal" */)).7(74.b((int)((long)1924474456 ^ (long)-1924495126), (int)((long)1292217670 ^ (long)-1292226202)) /* "auto" */)).1(74.b((int)((long)967556840 ^ (long)-967569337), (int)((long)1343130291 ^ (long)1343139143)) /* "Automatically steal when chests are opened" */)).7 = object;
        this.2 = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(74.b((int)((long)-1271686011 ^ (long)1271673379), (int)((long)1713190224 ^ (long)1713200000)) /* "Auto Close" */)).7(74.b((int)((long)-1122718233 ^ (long)1122698051), (int)((long)159021169 ^ (long)-159018624)) /* "autoclose" */)).1(74.b((int)((long)-249781988 ^ (long)249761726), (int)((long)1336996618 ^ (long)-1336989028)) /* "Automatically close the chest GUI when no items remain" */);
        ((34X)((34X)((34X)this.4().5(74.b((int)((long)-1271686011 ^ (long)1271673379), (int)((long)1713190224 ^ (long)1713200000)) /* "Auto Close" */)).7(74.b((int)((long)-1122718233 ^ (long)1122698051), (int)((long)159021169 ^ (long)-159018624)) /* "autoclose" */)).1(74.b((int)((long)-249781988 ^ (long)249761726), (int)((long)1336996618 ^ (long)-1336989028)) /* "Automatically close the chest GUI when no items remain" */)).7 = object;
        this.6 = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(74.b((int)((long)-214784880 ^ (long)214764087), (int)((long)-1428349112 ^ (long)-1428341458)) /* "Smart" */)).7(74.b((int)((long)1501066044 ^ (long)-1501045355), (int)((long)-418384649 ^ (long)418412139)) /* "smart" */)).1(74.b((int)((long)-1645785906 ^ (long)1645797998), (int)((long)1704267854 ^ (long)1704269193)) /* "Tries to prevent taking items from not-chest containers" */);
        ((34X)((34X)((34X)this.4().5(74.b((int)((long)-214784880 ^ (long)214764087), (int)((long)-1428349112 ^ (long)-1428341458)) /* "Smart" */)).7(74.b((int)((long)1501066044 ^ (long)-1501045355), (int)((long)-418384649 ^ (long)418412139)) /* "smart" */)).1(74.b((int)((long)-1645785906 ^ (long)1645797998), (int)((long)1704267854 ^ (long)1704269193)) /* "Tries to prevent taking items from not-chest containers" */)).7 = object;
        this.8 = (1P)((34X)j2).5();
        this.0 = new Listener(k2 -> {
            boolean bl;
            block10: {
                block9: {
                    bl = \u2007\u2003\u2004\u2003;
                    if (bl || bl) return;
                    if (74.3.s == null) break block9;
                    if (bl) return;
                    if (!(k2.4 instanceof dpz)) break block9;
                    if (bl) return;
                    if (k2.1 == EventState.POST) break block10;
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            if (this.2.2) {
                if (bl || bl) return;
                this.4((dpz)k2.4);
                if (bl) return;
            }
            if (!bl) return;
        }, new Predicate[(int)((long)-1258691684 ^ (long)-1258691684)]);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 74.\u2007\u2003\u2004\u2003;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)621168442 ^ (long)621168431)];
            if (var7) break block23;
            var3_2 = (int)((long)234430028 ^ (long)234430028);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u3aa0\u13c9(\u083f\u3a2b\u1336\u00cc\u0852\u3af7\u1357\u0003\u0862\u3a0a\u132d\u0014\u08b5\u3a89\u1399o\u0869\u3ad7\u136c[\u0888\u3a9b\u138c\u00ec\u089c\u3a8b\u13e01\u089f\u3a3e\u133e\u0001\u086b\u3adf\u13d0\u00c3\u08e3\u3a2e\u13be\u00f8\u08a2\u3a3a\u13f1\u00f5\u08b7\u3ac6\u1369a\u0869\u3ad9\u13edy\u0862\u3a34\u13f1+\u08be\u3a12\u13e3\u0016\u08bc\u3a4c\u1373n\u08b9\u3a88\u1356\u00a3\u08ba\u3a17\u1319[\u0879\u3a73\u13ddq\u08bf\u3aed\u138e\u001a\u08e5\u3aee\u137e\u00e7\u089c\u3a23\u138f\u00ae\u0817\u3a55\u13c8)\u083e\u3ac5\u13cb\u00c6\u0806\u3a49\u1336[\u0879\u3ae2\u13f8\u00ba\u0899\u3a3e\u138c\u00a0\u08a5\u3a07\u1361\u00d4\u088f\u3a97\u1347\u0088\u08ae\u3a52\u137eR\u088b\u3aca\u130a\u0004\u08da\u3aed\u13ec\u0080\u0878\u3a23\u13f7\u00c1\u08fd\u3a8b\u138f\n\u0873\u3a74\u136aZ\u0893\u3a6c\u13acn\u0891\u3a36\u134b\u00c2\u08e2\u3a90\u13b7Y\u08f6\u3a84\u134d\u008e\u08d2\u3a30\u13d8\u00c9\u08eb\u3afe\u13ad\u00eb\u08ad\u3a70\u1397|\u08c5\u3ad3\u1307\u00a0\u0888\u3aa7\u13a2\u00bd\u0817\u3af5\u13f8S\u0897\u3ae3\u1393\u00c3\u08ab\u3a65\u131d\r\u0887\u3a53\u13e5V\u0821\u3a07\u136dP\u082e\u3a2f\u13c0\u0001\u0823\u3a13\u139c\u008a\u08b2\u3a1e\u1306\u00b3\u0880\u3a77\u134b\u00d4\u0818\u3ac5\u13bf\u00e1\u0845\u3acd\u1331\u00a8\u0843\u3a87\u1349.\u088c\u3aac\u133f\u00b2\u08ab\u3a29\u139b\u00d9\u08fd\u3a8e\u13dd\u0085\u08b0\u3a43\u134c\u00b4\u08bc\u3af7\u13dd\u00ff\u081f\u3ab9\u139f\u00cc\u08d5\u3a40\u1354\u00b6\u08f2\u3a9b\u135e\u00a7\u08a4\u3a9e\u1343\u00cb\u08f5\u3aba\u13fa3\u086a\u3a3d\u1368\u008d\u0833\u3aa0\u1372@\u0897\u3a5e\u1325\u0011\u080b\u3a4f\u1359\u00fc\u0845\u3a14\u1312l\u0898\u3ac1\u1342S\u08bb\u3a42\u1386\u00b0\u08dd\u3a72\u13ef\u00e0\u08f2\u3a39\u134c\u00f0\u08bf\u3a7a\u13ea\u00b2\u0898\u3a0e\u1396\u00ec\u08c0\u3a16\u13e3$\u085f\u3a2e\u130f\"\u0883\u3adb\u13090\u081e\u3aef\u1359\u0084\u086a\u3a0e\u13d6-\u08ed\u3abf\u13de\u00ca\u0825\u3acc\u13adK\u0836\u3a16\u131a\u00b3\u084b\u3a20\u1352\u00fc\u0844\u3a5a\u1398\u00e9\u08d3\u3aaf\u1398\u008f\u0827\u3a1c\u13e8\u009a\u0823\u3a4d\u1358z\u08c3\u3a26\u1393\u0098\u0833\u3a10\u1342\u0099\u08bb\u3ab6\u1382\u009d\u082a\u3aa3\u13cd\u009f\u08dd\u3a2f\u1334\u00bd\u0805\u3a54\u13dee\u08a5\u3ac3\u13b1\u00fe\u080c\u3a36\u13b8;\u088a\u3a0f\u133e@\u0809", -1636885169);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)193975281 ^ (long)193975287);
            if (var7) break block23;
            var0_6 = (int)((long)-993066998 ^ (long)993066997);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-471424253 ^ (long)-471424138);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)729588939 ^ (long)-729588940);
                    if (74.\u2007\u2003\u2004\u2003) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!74.\u2007\u2003\u2004\u2003) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u20d6\u090d\u1ae9\u12c9\u201b\u0936\u1af8\u1273\u20f3\u0987", -902821989);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-2059686471 ^ (long)-2059686468);
                            var0_6 = (int)((long)-2082972383 ^ (long)2082972382);
                            while (true) {
                                v0 = (int)((long)1766095896 ^ (long)1766095940);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)240003983 ^ (long)240003983);
                                if (!74.\u2007\u2003\u2004\u2003) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!74.\u2007\u2003\u2004\u2003) ** continue;
                                throw null;
                            }
                            74.d = var5_1;
                            74.e = new String[(int)((long)1753916595 ^ (long)1753916582)];
                            if (!74.\u2007\u2003\u2004\u2003) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1324895119 ^ (long)-1324895119);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-767522053 ^ (long)-767522054)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1635859288 ^ (long)-1635859281)) {
                                case 0: {
                                    v15 = (int)((long)1330569075 ^ (long)1330568999);
                                    if (!74.\u2007\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1027366299 ^ (long)1027366357);
                                    if (!74.\u2007\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-598207575 ^ (long)-598207537);
                                    if (!74.\u2007\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1721650688 ^ (long)1721650793);
                                    if (!74.\u2007\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-513178535 ^ (long)-513178621);
                                    if (!74.\u2007\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1135617694 ^ (long)1135617784);
                                    if (!74.\u2007\u2003\u2004\u2003) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)773913510 ^ (long)773913556);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!74.\u2007\u2003\u2004\u2003);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 74.\u2007\u2003\u2004\u2003;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-504286535 ^ (long)504273946)) & (int)((long)247774332 ^ (long)247743363);
            if (var9_2) ** GOTO lbl-1000
            if (74.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 74.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-174324508 ^ (long)-174324508)] & (int)((long)-396634618 ^ (long)-396634375)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1046932431 ^ (long)-1046932229);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-388227311 ^ (long)-388227274);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)2033856884 ^ (long)2033856869);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1961446523 ^ (long)-1961446615);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-39591146 ^ (long)-39591064);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1073166266 ^ (long)-1073166140);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1117515013 ^ (long)-1117515118);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)351412013 ^ (long)351412132);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)184753905 ^ (long)184753690);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1792637614 ^ (long)1792637642);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1058827203 ^ (long)1058827038);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)193123315 ^ (long)193123204);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1617112244 ^ (long)1617112280);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1973604138 ^ (long)-1973604345);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)524491845 ^ (long)524491920);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)257749861 ^ (long)257749898);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)83069185 ^ (long)83069268);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)644709937 ^ (long)644709896);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1651430121 ^ (long)-1651429977);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1924516977 ^ (long)1924517048);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1411000927 ^ (long)-1411000996);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1401048646 ^ (long)1401048799);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1704223753 ^ (long)1704223989);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-819758160 ^ (long)-819758327);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1548949821 ^ (long)-1548949938);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1533600162 ^ (long)-1533600139);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)670752418 ^ (long)670752325);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)157938880 ^ (long)157938779);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1017218290 ^ (long)-1017218230);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1390698170 ^ (long)-1390698124);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-281616188 ^ (long)-281616253);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1059304155 ^ (long)-1059303954);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1449922303 ^ (long)-1449922202);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1581991778 ^ (long)1581991704);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1770849792 ^ (long)1770849921);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)2074656011 ^ (long)2074656023);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1216357333 ^ (long)1216357125);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)270031994 ^ (long)270032031);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1367413359 ^ (long)1367413257);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-48088659 ^ (long)-48088594);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-2141417543 ^ (long)-2141417701);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1293101660 ^ (long)-1293101740);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)68293805 ^ (long)68293819);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)580358396 ^ (long)580358265);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1237875009 ^ (long)-1237875188);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1829830528 ^ (long)-1829830453);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)229513458 ^ (long)229513416);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1086839833 ^ (long)1086840020);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)288780185 ^ (long)288780209);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1521647222 ^ (long)-1521647360);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1453653825 ^ (long)-1453654002);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-443548797 ^ (long)-443548912);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)519185218 ^ (long)519185374);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-326823416 ^ (long)-326823362);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1448199044 ^ (long)-1448199019);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1812368740 ^ (long)1812368845);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-833852851 ^ (long)-833852806);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-70320032 ^ (long)-70320109);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)332488978 ^ (long)332489194);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-723998353 ^ (long)-723998285);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1343794913 ^ (long)1343794888);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1005568017 ^ (long)1005568022);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1290878288 ^ (long)-1290878216);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-276057802 ^ (long)-276057619);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1281502985 ^ (long)1281502985);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1029759054 ^ (long)-1029759119);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-39488162 ^ (long)-39488134);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-714185392 ^ (long)-714185309);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-2097632349 ^ (long)-2097632484);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-282854078 ^ (long)-282854082);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1138340699 ^ (long)-1138340618);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)215830048 ^ (long)215830022);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1420247548 ^ (long)-1420247312);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-237081184 ^ (long)-237081110);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1444826252 ^ (long)-1444826201);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1031558598 ^ (long)-1031558635);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1967646317 ^ (long)1967646413);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1065822239 ^ (long)1065822395);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-459879713 ^ (long)-459879904);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)81594764 ^ (long)81594809);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)2110574040 ^ (long)2110573961);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)2116734887 ^ (long)2116734726);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1369187426 ^ (long)-1369187512);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)66547011 ^ (long)66547015);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1972339767 ^ (long)-1972339749);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1255233760 ^ (long)1255233712);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-213181342 ^ (long)-213181334);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)113566874 ^ (long)113566967);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)614162816 ^ (long)614162837);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1629984603 ^ (long)1629984668);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-938009434 ^ (long)-938009517);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)323583966 ^ (long)323583848);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-101096953 ^ (long)-101096895);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)85231644 ^ (long)85231743);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)141987689 ^ (long)141987647);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1510107582 ^ (long)-1510107609);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1554821839 ^ (long)-1554821837);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)106998562 ^ (long)106998732);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)2087771458 ^ (long)2087771507);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1399429318 ^ (long)1399429183);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-853703217 ^ (long)-853703371);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)649434520 ^ (long)649434392);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1053093993 ^ (long)1053093890);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)2068132967 ^ (long)2068133014);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1429337208 ^ (long)1429337232);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)679650795 ^ (long)679650656);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-164055481 ^ (long)-164055334);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1110886899 ^ (long)-1110886789);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)89653646 ^ (long)89653686);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-84747903 ^ (long)-84747870);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1770509592 ^ (long)1770509759);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)843829818 ^ (long)843829813);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)820269597 ^ (long)820269648);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1646311345 ^ (long)-1646311323);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1305652208 ^ (long)-1305652207);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1794618201 ^ (long)-1794618194);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-264478367 ^ (long)-264478445);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1032984848 ^ (long)-1032984851);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1621150669 ^ (long)1621150591);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-91884417 ^ (long)-91884496);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)972344560 ^ (long)972344491);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-2131306026 ^ (long)-2131306103);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-38465658 ^ (long)-38465685);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1140901910 ^ (long)1140902133);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)945880699 ^ (long)945880576);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1393446330 ^ (long)1393446198);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-380730466 ^ (long)-380730573);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1386779615 ^ (long)1386779513);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)628085853 ^ (long)628085993);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1481984708 ^ (long)-1481984651);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1091087204 ^ (long)-1091087131);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1777004917 ^ (long)-1777004822);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-589237651 ^ (long)-589237644);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)808682711 ^ (long)808682540);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-389090165 ^ (long)-389090220);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1758238070 ^ (long)1758238036);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1617668278 ^ (long)1617668291);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1294876081 ^ (long)-1294875952);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1900745075 ^ (long)1900745190);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-175000672 ^ (long)-175000596);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1449313393 ^ (long)-1449313296);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-205346013 ^ (long)-205346010);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1817892918 ^ (long)1817893020);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1667222379 ^ (long)-1667222309);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)394859068 ^ (long)394859037);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1844079963 ^ (long)1844080077);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-898333713 ^ (long)-898333726);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1372951484 ^ (long)-1372951447);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)347415922 ^ (long)347415928);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)896145929 ^ (long)896146045);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)17650151 ^ (long)17650035);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-107334537 ^ (long)-107334624);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-132437909 ^ (long)-132437961);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-168806796 ^ (long)-168806802);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-483883758 ^ (long)-483883646);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1028458276 ^ (long)1028458396);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-632843380 ^ (long)-632843369);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1266667755 ^ (long)-1266667730);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1769356030 ^ (long)1769356029);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-581550357 ^ (long)-581550369);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)2000278766 ^ (long)2000278731);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1360222261 ^ (long)-1360222259);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-185955001 ^ (long)-185955053);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1997884506 ^ (long)-1997884424);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)2051985173 ^ (long)2051985253);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-573319669 ^ (long)-573319641);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-3422666 ^ (long)-3422482);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-917272214 ^ (long)-917272195);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1576028272 ^ (long)-1576028294);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-421967889 ^ (long)-421967982);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)60996365 ^ (long)60996535);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)11113119 ^ (long)0xA99222);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1031015975 ^ (long)1031016144);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)407747657 ^ (long)407747617);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-707366988 ^ (long)-707366971);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1000315220 ^ (long)-1000315314);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1070632874 ^ (long)-1070632817);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1127642774 ^ (long)1127642628);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)21242519 ^ (long)21242481);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)446800998 ^ (long)446800956);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-791959275 ^ (long)-791959106);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-307225614 ^ (long)-307225704);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1869571093 ^ (long)-1869571150);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1814390224 ^ (long)1814390240);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-428879257 ^ (long)-428879240);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1778508699 ^ (long)1778508573);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)376530692 ^ (long)376530891);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-289040357 ^ (long)-289040151);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)981421415 ^ (long)981421558);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1525776241 ^ (long)-1525776233);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-253391904 ^ (long)-253392029);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1431253792 ^ (long)-1431253937);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1955476013 ^ (long)-1955476207);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)402472600 ^ (long)402472695);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)102659228 ^ (long)102659160);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1397411178 ^ (long)-1397411160);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1215142808 ^ (long)1215142853);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-300745874 ^ (long)-300745751);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1293516084 ^ (long)1293516234);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-937157654 ^ (long)-937157850);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-2141037798 ^ (long)-2141037692);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1953464211 ^ (long)-1953464195);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1675035236 ^ (long)-1675035303);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)237219276 ^ (long)237219295);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)437039648 ^ (long)437039820);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)2007819469 ^ (long)2007819404);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1032867741 ^ (long)1032867715);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)2025826205 ^ (long)2025826139);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-404904395 ^ (long)-404904440);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)109390360 ^ (long)109390525);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1277383037 ^ (long)-1277383017);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1854675125 ^ (long)1854675067);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)2024280903 ^ (long)2024281009);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)425474480 ^ (long)425474504);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1586808221 ^ (long)1586808189);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-573696328 ^ (long)-573696404);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1577568013 ^ (long)-1577568132);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-874674222 ^ (long)-874674327);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1252363416 ^ (long)-1252363290);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-755183263 ^ (long)-755183137);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)569342832 ^ (long)569342954);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-455336246 ^ (long)-455336321);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1842623640 ^ (long)-1842623541);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1483693785 ^ (long)-1483693648);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)721808485 ^ (long)721808391);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1517849530 ^ (long)-1517849594);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1580965062 ^ (long)1580965113);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1784781005 ^ (long)-1784780873);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-732672006 ^ (long)-732672216);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1522211677 ^ (long)1522211709);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-338694456 ^ (long)-338694647);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1851331492 ^ (long)-1851331388);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-87571523 ^ (long)-87571464);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1299763885 ^ (long)-1299763717);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-333306257 ^ (long)-333306271);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1079144983 ^ (long)-1079145208);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-353763201 ^ (long)-353763247);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1503611113 ^ (long)1503611057);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)319269348 ^ (long)319269228);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1584425945 ^ (long)1584425941);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)735697367 ^ (long)735697273);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)2145030107 ^ (long)2145030041);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)199289112 ^ (long)199289206);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-502377078 ^ (long)-502377031);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-944627232 ^ (long)-944627328);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)564206504 ^ (long)564206440);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-701332754 ^ (long)-701332954);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1310105097 ^ (long)-1310105312);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1164045420 ^ (long)1164045531);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-265602563 ^ (long)-265602623);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1770739768 ^ (long)1770739942);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1984172382 ^ (long)1984172300);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1547852253 ^ (long)1547852129);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1110931298 ^ (long)-1110931388);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-881074259 ^ (long)-881074359);
                    if (!74.\u2007\u2003\u2004\u2003) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1604456693 ^ (long)-1604456704);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1719215466 ^ (long)-1719215511)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)2015402741 ^ (long)2015388938)) >>> (int)((long)2053067090 ^ (long)2053067098)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)2011941716 ^ (long)2011941716);
            if (!74.\u2007\u2003\u2004\u2003) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-243288489 ^ (long)-243288491);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1407823205 ^ (long)1407823206) | var5_6 << (int)((long)1338540799 ^ (long)1338540794)) ^ var3_4[var7_8]) & (int)((long)1942856842 ^ (long)1942856821);
                    if (74.\u2007\u2003\u2004\u2003) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1958836589 ^ (long)1958836590) | var6_7 << (int)((long)-1142151840 ^ (long)-1142151835)) ^ var3_4[var7_8]) & (int)((long)143996034 ^ (long)143996029);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            74.e[var2_3] = new String(var3_4).intern();
        }
        return 74.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 4(dpz dpz2) {
        block3: {
            block2: {
                boolean bl = \u2007\u2003\u2004\u2003;
                if (bl || bl) break block2;
                5z.4().5.execute(() -> {
                    boolean bl = \u2007\u2003\u2004\u2003;
                    if (bl) return;
                    bij bij2 = (bij)dpz2.h();
                    int n = bij2.e().Z_();
                    String[] stringArray = 3e.5();
                    if (bl || bl) return;
                    if (this.8.2) {
                        if (bl) return;
                        if (n != (int)((long)-1376246860 ^ (long)-1376246865)) {
                            if (bl) return;
                            if (n != (int)((long)16779423 ^ (long)16779433)) {
                                if (bl || bl) return;
                                return;
                            }
                        }
                    }
                    if (bl) return;
                    if (bij2.a.stream().allMatch(bjr::f)) {
                        if (bl) return;
                        if (this.6.2) {
                            if (bl || bl) return;
                            3.execute(() -> {
                                block3: {
                                    block2: {
                                        boolean bl = \u2007\u2003\u2004\u2003;
                                        if (bl || bl) break block2;
                                        74.3.s.m();
                                        if (!bl) break block3;
                                    }
                                    return;
                                }
                            });
                            if (bl || bl) return;
                            return;
                        }
                    }
                    block8: do {
                        if (bl) return;
                        int n2 = (int)((long)-538391961 ^ (long)-538391961);
                        if (bl) return;
                        if (bl) return;
                        int n3 = (int)((long)875828498 ^ (long)875828498);
                        if (bl) return;
                        while (!bl) {
                            block33: {
                                block34: {
                                    djz djz2;
                                    block32: {
                                        block31: {
                                            if (n3 >= n) break block31;
                                            if (bl || bl) return;
                                            djz2 = 3;
                                            if (stringArray == null) {
                                                if (djz2.y != dpz2) {
                                                    if (bl || bl) return;
                                                    return;
                                                }
                                                if (bl) return;
                                                bjr bjr3 = (bjr)bij2.a.get(n3);
                                                if (bjr3.f()) {
                                                    if (bl || bl) return;
                                                    String string = ((String)this.5.0()).toLowerCase();
                                                    if (bl) return;
                                                    n3 = (int)((long)-379915160 ^ (long)379915159);
                                                    if (bl) return;
                                                    switch (string.hashCode()) {
                                                        case 109407362: {
                                                            if (bl) return;
                                                            if (!string.equals(74.b((int)((long)-775570416 ^ (long)775557792), (int)((long)-1903540802 ^ (long)1903534177)) /* "shift" */)) break;
                                                            if (bl) return;
                                                            n3 = (int)((long)245455207 ^ (long)245455207);
                                                            if (bl) return;
                                                            if (stringArray == null) break;
                                                            if (bl) return;
                                                        }
                                                        case -988476804: {
                                                            if (bl) return;
                                                            if (!string.equals(74.b((int)((long)930064282 ^ (long)-930084558), (int)((long)1365553359 ^ (long)1365572575)) /* "pickup" */)) break;
                                                            if (bl) return;
                                                            n3 = (int)((long)-1595772847 ^ (long)-1595772848);
                                                            if (bl) return;
                                                            break;
                                                        }
                                                    }
                                                    if (bl) return;
                                                    switch (n3) {
                                                        case 0: {
                                                            if (bl) return;
                                                            74.3.q.a(bij2.b, bjr3.d, (int)((long)-772410024 ^ (long)-772410024), bik.b, (bfw)74.3.s);
                                                            if (bl || bl) return;
                                                            if (stringArray == null) break;
                                                            if (bl) return;
                                                        }
                                                        case 1: {
                                                            if (bl) return;
                                                            string = 74.3.s.bo.a.stream().filter(bjr2 -> {
                                                                boolean bl = \u2007\u2003\u2004\u2003;
                                                                if (bl || bl) return true;
                                                                if (bjr2.d >= (int)((long)1583860765 ^ (long)1583860756)) {
                                                                    if (bl) return true;
                                                                    if (!bjr2.f()) {
                                                                        if (bl) return true;
                                                                        return (int)((long)1074678403 ^ (long)1074678402) != 0;
                                                                    }
                                                                }
                                                                if (!bl) return (int)((long)601861300 ^ (long)601861300) != 0;
                                                                return true;
                                                            }).findFirst().orElse(null);
                                                            if (string == null) break;
                                                            if (bl || bl) return;
                                                            74.3.q.a(bij2.b, bjr3.d, (int)((long)1443560987 ^ (long)1443560987), bik.a, (bfw)74.3.s);
                                                            if (bl || bl) return;
                                                            5p.8(this.7.4);
                                                            if (bl || bl) return;
                                                            74.3.q.a(bij2.b, ((bjr)string).d + n - (int)((long)1248281004 ^ (long)1248280997), (int)((long)-1482858190 ^ (long)-1482858190), bik.a, (bfw)74.3.s);
                                                            if (bl) return;
                                                            break;
                                                        }
                                                    }
                                                    if (bl) return;
                                                    5p.8(this.7.4);
                                                    if (bl || bl) return;
                                                    n2 = (int)((long)-488954446 ^ (long)-488954445);
                                                    if (bl) return;
                                                    if (bl) return;
                                                    if (stringArray != null) {
                                                        if (bl) return;
                                                    }
                                                } else {
                                                    if (bl) return;
                                                    ++n3;
                                                    if (bl) return;
                                                    if (stringArray == null) continue;
                                                    if (bl) return;
                                                }
                                            }
                                            break block32;
                                        }
                                        if (bl) return;
                                        if (n2 != 0) break block33;
                                        if (bl || bl) return;
                                        if (!this.6.2) break block34;
                                        if (bl || bl) return;
                                        djz2 = 3;
                                    }
                                    djz2.execute(() -> {
                                        block3: {
                                            block2: {
                                                boolean bl = \u2007\u2003\u2004\u2003;
                                                if (bl || bl) break block2;
                                                74.3.s.m();
                                                if (!bl) break block3;
                                            }
                                            return;
                                        }
                                    });
                                    if (bl || bl) return;
                                    return;
                                }
                                if (bl) return;
                                5p.8(0xFDC3C5509F23B7B2L ^ 0xFDC3C5509F23B7B8L);
                                if (bl) return;
                            }
                            if (!bl) continue block8;
                        }
                        return;
                    } while (!\u2007\u2003\u2004\u2003);
                    throw null;
                });
                if (!bl && !bl) break block3;
            }
            return;
        }
    }
}

