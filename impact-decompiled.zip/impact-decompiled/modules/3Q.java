/* ==========================================================================
 * MODULE: Auto Totem
 * CATEGORY (inferred): Combat
 * DESCRIPTION: Revives you after death if you have a totem
 * OBFUSCATED CLASS: net.impactclient.3Q
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  bik
 *  bmb
 *  bmd
 *  gj
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.List;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.2R;
import net.impactclient.2w;
import net.impactclient.2w$6X;
import net.impactclient.34J;
import net.impactclient.34X;
import net.impactclient.3X;
import net.impactclient.4f;
import net.impactclient.56;
import net.impactclient.5p;
import net.impactclient.5y;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3Q
extends 3X
implements 56 {
    public static final boolean \u200f\u2007\u2003;
    private static final String[] e;
    private boolean 6;
    private 1P 7;
    private float 1;
    private final 2w<bmb> 5;
    private static final String[] d;
    private int 2;
    @EventHandler
    private final Listener<4f> 9;
    private 1P 4;

    /*
     * Enabled aggressive block sorting
     */
    private void 7() {
        block3: {
            block2: {
                boolean bl = \u200f\u2007\u2003;
                if (bl || bl) break block2;
                5p.4(this.2, bik.a);
                if (bl || bl) break block2;
                5p.4((int)((long)442562878 ^ (long)442562835), bik.a);
                if (bl || bl) break block2;
                5p.4(this.2, bik.a);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 3Q.\u200f\u2007\u2003;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)832130130 ^ (long)832130139)];
            if (var7) break block23;
            var3_2 = (int)((long)-60507050 ^ (long)-60507050);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ueebc\uc611\ud56f\udd4d\uee65\uc632\ud5ae\udd6e\ueee5\uc6ce\ud5d0\uddc7\ueee5\uc634\ud5c1\udd05\ueecd\uc66a\ud570\udde2\ueed1\uc62c\ud5c0\udd50\ueecd\uc62e\ud558\udd4e\ueed4\uc6b9\ud560\udde2\ueec0\uc6ce\ud5a7\uddff\uee36\uc6b5\ud594\udd04\uee84\uc668\ud54c\udd8a\ueeb7\uc6c1\ud57d\udd43\uee33\uc604\ud5e4\uddeb\uee2f\uc6a2\ud509\udd4c\uee5b\uc6f3\ud5c4\udd8e\uee09\uc686\ud5d7\uddb9\ueec6\uc66d\ud5d6\udd86\ueee5\uc64d\ud5e4\udd27\ueebd\uc69d\ud5f0\udddb\uee09\uc625\ud540\uddbe\uee77\uc647\ud518\udd19\uee4d\uc6fc\ud5a8\udde6\ueead\uc688\ud59a\udd10\ueec0\uc66a\ud502\uddbb\uee7a\uc6c4\ud512\udd48\uee94\uc6d8\ud56d\udd6f\uee6e\uc6a5\ud52f\udd03\uee15\uc63a\ud5c2\udd38\uee8c\uc64f\ud544\udd03\ueeae\uc6c6\ud53b\uddea\ueeef\uc65b\ud597\udd4c\uee8c\uc6bb\ud542\udd65\ueed8\uc6f9\ud505\udd4d\ueef6\uc638\ud54d\udd46\uee5e\uc68d\ud52e\udd01\uee7f\uc642\ud5f6\uddc3\ueef1\uc6f8\ud593\uddb0\ueea6\uc677\ud562\udd65\uee18\uc6f9\ud5f8\uddd4\uee96\uc61e\ud5b6", -264517536);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)444955008 ^ (long)444955018);
            if (var7) break block23;
            var0_6 = (int)((long)1572373586 ^ (long)-1572373587);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1723995992 ^ (long)-1723996021);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1290045963 ^ (long)1290045962);
                    if (3Q.\u200f\u2007\u2003) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3Q.\u200f\u2007\u2003) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\uc4cd\uec5c\uff07\uf780\uc427\ueca6\uffd1\uf78c\uc47f\uec88\uff88\uf7d0\uc470\uec6e\uff35\uf734\uc4ee\uec30\uff38\uf749\uc4c3\uec68\uff15\uf7c6\uc43e\uec6d\ufff8\uf783\uc42b\uec2e\uff0d\uf7b6\uc48c\uec6e\uff51\uf728\uc452\uec56\uffc3\uf727\uc419\uec2b\uff79\uf726\uc472\uecd4\uff60\uf781\uc411\uecac\uffa8\uf724\uc489\uec1b\uff1e\uf75e\uc4f3\uecb4\uffda\uf7e4\uc47f\uec05\uff0f\uf7d0\uc43d\uec11\uff31\uf7bf\uc4d0", 1799938748);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)38528596 ^ (long)38528618);
                            var0_6 = (int)((long)-371762891 ^ (long)371762890);
                            while (true) {
                                v0 = (int)((long)1653918688 ^ (long)1653918637);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-2074123491 ^ (long)-2074123491);
                                if (!3Q.\u200f\u2007\u2003) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3Q.\u200f\u2007\u2003) ** continue;
                                throw null;
                            }
                            3Q.d = var5_1;
                            3Q.e = new String[(int)((long)-1029217795 ^ (long)-1029217804)];
                            if (!3Q.\u200f\u2007\u2003) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-132736512 ^ (long)-132736512);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)355633867 ^ (long)355633866)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)626742145 ^ (long)626742150)) {
                                case 0: {
                                    v15 = (int)((long)-1349284085 ^ (long)-1349284040);
                                    if (!3Q.\u200f\u2007\u2003) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)2012542721 ^ (long)2012542720);
                                    if (!3Q.\u200f\u2007\u2003) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1703868434 ^ (long)-1703868506);
                                    if (!3Q.\u200f\u2007\u2003) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-2024997969 ^ (long)-2024998005);
                                    if (!3Q.\u200f\u2007\u2003) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-708904696 ^ (long)-708904604);
                                    if (!3Q.\u200f\u2007\u2003) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-662129879 ^ (long)-662129830);
                                    if (!3Q.\u200f\u2007\u2003) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-21224643 ^ (long)-21224654);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!3Q.\u200f\u2007\u2003);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    public 3Q() {
        boolean bl = \u200f\u2007\u2003;
        super(3Q.b((int)((long)-832749254 ^ (long)832762853), (int)((long)-146384593 ^ (long)146386592)) /* "Auto Totem" */, 3Q.b((int)((long)-302880439 ^ (long)302898067), (int)((long)-1104211043 ^ (long)1104185623)) /* "Revives you after death if you have a totem" */);
        Predicate[] predicateArray = Boolean.TRUE;
        Object object = (34X)((34X)((34X)this.4().5(3Q.b((int)((long)616891441 ^ (long)-616909076), (int)((long)894996446 ^ (long)-895023537)) /* "Counter" */)).7(3Q.b((int)((long)1792078432 ^ (long)-1792065348), (int)((long)-950946510 ^ (long)-950956228)) /* "counter" */)).1(3Q.b((int)((long)-1557232858 ^ (long)1557213694), (int)((long)975540022 ^ (long)-975550968)) /* "Displays the amount of totems that you have in the module list" */);
        ((34X)((34X)((34X)this.4().5(3Q.b((int)((long)616891441 ^ (long)-616909076), (int)((long)894996446 ^ (long)-895023537)) /* "Counter" */)).7(3Q.b((int)((long)1792078432 ^ (long)-1792065348), (int)((long)-950946510 ^ (long)-950956228)) /* "counter" */)).1(3Q.b((int)((long)-1557232858 ^ (long)1557213694), (int)((long)975540022 ^ (long)-975550968)) /* "Displays the amount of totems that you have in the module list" */)).7 = predicateArray;
        this.7 = (1P)((34J)object).5();
        this.4 = (1P)((34X)((34X)((34X)this.4().5(3Q.b((int)((long)599789947 ^ (long)-599809115), (int)((long)-88436785 ^ (long)-88409355)) /* "Smart" */)).7(3Q.b((int)((long)-56822159 ^ (long)56837290), (int)((long)-1355462119 ^ (long)-1355473783)) /* "notsosmart" */)).1(3Q.b((int)((long)-236192019 ^ (long)236211252), (int)((long)-1890611952 ^ (long)1890607085)) /* "Only switches to the totem when you're at risk of death, slightly buggy" */)).5();
        Predicate[] predicateArray2 = new Predicate[(int)((long)1180810461 ^ (long)1180810460)];
        predicateArray2[(int)((long)-417755626 ^ (long)-417755626)] = bmb2 -> {
            boolean bl = \u200f\u2007\u2003;
            if (bl || bl) return true;
            if (bmb2.b() == bmd.qu) {
                if (bl) return true;
                return (int)((long)-1037975711 ^ (long)-1037975712) != 0;
            }
            if (!bl) return (int)((long)-156490916 ^ (long)-156490916) != 0;
            return true;
        };
        predicateArray = predicateArray2;
        object = new 5y();
        new 5y().1 = predicateArray;
        this.5 = ((5y)object).7();
        this.9 = new Listener(f -> {
            int n;
            int n2;
            int n3;
            int n4;
            int n5;
            String string;
            boolean bl = \u200f\u2007\u2003;
            if (bl || bl) {
                return;
            }
            String string2 = 3Q.b((int)((long)-413739221 ^ (long)413754876), (int)((long)-1221180595 ^ (long)-1221181220)) /* "suffix" */;
            if (this.7.2) {
                string = String.valueOf(this.5.8((List<bmb>)3Q.3.s.bo.b()).stream().mapToInt(bmb::E).sum());
                if (\u200f\u2007\u2003) {
                    throw null;
                }
            } else {
                string = null;
            }
            2R.1(this, string2, string);
            if (3Q.3.s.bo != 3Q.3.s.bp) {
                return;
            }
            f = 3Q.3.s.dE().b();
            if (this.4.2 && this.6 && 3Q.3.s.dk() != this.1 && f != bmd.qu) {
                this.7();
            }
            this.1 = 3Q.3.s.dk();
            if (f == bmd.qu) {
                return;
            }
            if (3Q.3.s.C - 3.0f >= (float)((int)3Q.3.s.dk() + (int)((long)-57331052 ^ (long)-57331051))) {
                n5 = (int)((long)-1336778052 ^ (long)-1336778051);
                if (\u200f\u2007\u2003) {
                    throw null;
                }
            } else {
                n5 = n4 = (int)((long)2056270167 ^ (long)2056270167);
            }
            if (!this.4.2 || n4 != 0) {
                n3 = (int)((long)-1718050671 ^ (long)-1718050672);
                if (\u200f\u2007\u2003) {
                    throw null;
                }
            } else {
                this.6 = (int)((long)-2060242838 ^ (long)-2060242838);
                n3 = this.6 ? 1 : 0;
            }
            if (!this.6) {
                return;
            }
            gj gj2 = 3Q.3.s.bo.b();
            bmb bmb2 = this.5.3((List<bmb>)gj2);
            if (bmb2 == null) {
                n2 = (int)((long)-728010225 ^ (long)728010224);
                if (\u200f\u2007\u2003) {
                    throw null;
                }
            } else {
                n2 = n = gj2.indexOf(bmb2);
            }
            if (n2 < 0) {
                return;
            }
            this.2 = n;
            this.7();
        }, new Predicate[(int)((long)-864484836 ^ (long)-864484836)]);
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 3Q.\u200f\u2007\u2003;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1355187463 ^ (long)1355204646)) & (int)((long)-631628550 ^ (long)-631577851);
            if (var9_2) ** GOTO lbl-1000
            if (3Q.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3Q.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)413005120 ^ (long)413005120)] & (int)((long)161732176 ^ (long)161732271)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)449393807 ^ (long)449393805);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)728101658 ^ (long)728101635);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1127221790 ^ (long)-1127221939);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)2044329656 ^ (long)2044329674);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)954247074 ^ (long)954246962);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1861534800 ^ (long)1861534845);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1195646595 ^ (long)1195646642);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-715560037 ^ (long)-715560048);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-793212371 ^ (long)-793212266);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1786848782 ^ (long)-1786848927);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1236425736 ^ (long)1236425928);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)338788947 ^ (long)338789111);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1479280343 ^ (long)1479280144);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-2136617725 ^ (long)-2136617625);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1824600345 ^ (long)-1824600472);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-582566438 ^ (long)-582566644);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-288107273 ^ (long)-288107495);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)588781380 ^ (long)588781556);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1159524122 ^ (long)-1159524118);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-20772332 ^ (long)-20772126);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)704785675 ^ (long)704785788);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-852700360 ^ (long)-852700264);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1833833894 ^ (long)1833833732);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)2039448062 ^ (long)2039448041);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1238383800 ^ (long)-1238383691);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1595735961 ^ (long)1595735986);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)814084961 ^ (long)814084912);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1736722648 ^ (long)1736722588);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1476751670 ^ (long)1476751634);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)855713897 ^ (long)855713817);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)707638547 ^ (long)707638660);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)633563298 ^ (long)633563316);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1415049589 ^ (long)1415049596);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-668986881 ^ (long)-668986913);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-963620337 ^ (long)-963620207);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1408722836 ^ (long)1408722900);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1659095182 ^ (long)1659095097);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1049799565 ^ (long)1049799530);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-373024931 ^ (long)-373024895);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)2132909928 ^ (long)2132909873);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-591604191 ^ (long)-591604174);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-644117701 ^ (long)-644117636);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)2082442213 ^ (long)2082442199);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-951000133 ^ (long)-951000286);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1357813819 ^ (long)-1357813921);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)39354363 ^ (long)39354250);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1495468328 ^ (long)1495468433);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1571612454 ^ (long)1571612577);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1230291429 ^ (long)1230291201);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)2039495265 ^ (long)2039495172);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1301494237 ^ (long)-1301494241);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)760085772 ^ (long)760085903);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1991908293 ^ (long)1991908161);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-218414244 ^ (long)-218414122);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)803759530 ^ (long)803759582);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-491714856 ^ (long)-491714963);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)387691539 ^ (long)387691689);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1714108191 ^ (long)1714108240);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)681628690 ^ (long)681628674);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1617491637 ^ (long)1617491711);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)624097415 ^ (long)624097423);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1745186365 ^ (long)-1745186449);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1164517576 ^ (long)-1164517541);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-368053075 ^ (long)-368053173);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)626263592 ^ (long)626263751);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)632735570 ^ (long)632735588);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)801217554 ^ (long)801217723);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)58627670 ^ (long)58627723);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)605037991 ^ (long)605037970);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1648265824 ^ (long)-1648265917);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)509741826 ^ (long)509741878);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1457059213 ^ (long)1457059192);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)2060056076 ^ (long)2060056279);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)249816512 ^ (long)249816401);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1823259565 ^ (long)-1823259555);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1692207259 ^ (long)-1692207184);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1559428704 ^ (long)1559428703);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1584465968 ^ (long)-1584466115);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1438346799 ^ (long)1438346909);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-94242452 ^ (long)-94242359);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)716973113 ^ (long)716973221);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)317671546 ^ (long)317671607);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-470527583 ^ (long)-470527537);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)2085887169 ^ (long)2085887095);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-230054000 ^ (long)-230053937);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)291039642 ^ (long)291039641);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)591912408 ^ (long)591912273);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-538819093 ^ (long)-538819226);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)810069622 ^ (long)810069622);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1056203403 ^ (long)-1056203428);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1537348723 ^ (long)-1537348682);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-14065371 ^ (long)-14065163);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)705046184 ^ (long)705046237);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1872047085 ^ (long)1872046982);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1984686894 ^ (long)1984686898);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1219022024 ^ (long)-1219022020);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1412977297 ^ (long)1412977302);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1370896188 ^ (long)-1370896246);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-799803035 ^ (long)-799802990);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)265772681 ^ (long)265772789);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-441331265 ^ (long)-441331392);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1543056433 ^ (long)-1543056418);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-201969213 ^ (long)-201969237);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1491869639 ^ (long)-1491869518);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-363082045 ^ (long)-363082012);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1814284607 ^ (long)-1814284781);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-790739185 ^ (long)-790738957);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)989315311 ^ (long)989315166);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1201994195 ^ (long)-1201993993);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)573327129 ^ (long)573327186);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1096029662 ^ (long)1096029623);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1546537904 ^ (long)-1546537839);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1165759476 ^ (long)1165759277);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)629172522 ^ (long)629172489);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1958453322 ^ (long)-1958453336);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)795719914 ^ (long)795719680);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-879158170 ^ (long)-879158263);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1347366393 ^ (long)1347366271);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1100394998 ^ (long)-1100394977);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1568332839 ^ (long)1568333026);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)618650509 ^ (long)618650582);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1644975592 ^ (long)1644975451);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)531126631 ^ (long)531126558);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)411650718 ^ (long)411650736);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1773929514 ^ (long)-1773929608);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1925391857 ^ (long)1925391627);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1932426687 ^ (long)1932426731);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)748957107 ^ (long)748956955);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1567228914 ^ (long)-1567228682);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1493824231 ^ (long)1493824036);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1495362291 ^ (long)-1495362211);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-393301878 ^ (long)-393301865);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1287975983 ^ (long)-1287976062);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1072030313 ^ (long)-1072030319);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1353673459 ^ (long)-1353673417);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1580574296 ^ (long)-1580574399);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1756592390 ^ (long)1756592637);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1589557710 ^ (long)1589557659);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1862691335 ^ (long)1862691534);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-885887375 ^ (long)-885887352);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1148465074 ^ (long)1148464960);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1582422047 ^ (long)-1582422073);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-351571675 ^ (long)-351571522);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-561674712 ^ (long)-561674731);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1033699713 ^ (long)1033699603);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1091887225 ^ (long)-1091887204);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-944245170 ^ (long)-944245095);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1238284214 ^ (long)-1238284068);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1856500144 ^ (long)-1856500120);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1508136145 ^ (long)1508136133);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1042924980 ^ (long)1042924886);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)314011887 ^ (long)314011837);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1015735631 ^ (long)1015735558);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-196728919 ^ (long)-196728970);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-732485657 ^ (long)-732485886);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1277972825 ^ (long)-1277972916);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)896679167 ^ (long)896678965);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1839865690 ^ (long)1839865764);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)827436128 ^ (long)827436159);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)389514340 ^ (long)389514416);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)962085949 ^ (long)962086018);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-734223200 ^ (long)-734223336);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1773384779 ^ (long)-1773384816);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)514406230 ^ (long)514406265);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-695847205 ^ (long)-695847237);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)527495768 ^ (long)527495685);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)86990239 ^ (long)86990082);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-2109736367 ^ (long)-2109736393);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)2084379914 ^ (long)2084380023);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1785117346 ^ (long)1785117359);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)2021790801 ^ (long)2021790740);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1525617337 ^ (long)-1525617371);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1550724152 ^ (long)1550724171);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1102411360 ^ (long)-1102411273);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)735242441 ^ (long)735242340);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-172078673 ^ (long)-172078648);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-573593018 ^ (long)-573592961);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1988628276 ^ (long)-1988628300);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)2048094967 ^ (long)2048094847);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1244716538 ^ (long)1244716379);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)822011357 ^ (long)822011217);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-2023808130 ^ (long)-2023808140);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-402807696 ^ (long)-402807604);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1522975069 ^ (long)1522975109);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1569982123 ^ (long)-1569982197);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)509933920 ^ (long)509933995);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-2132826750 ^ (long)-2132826749);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-2026105111 ^ (long)-2026105336);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1945585443 ^ (long)1945585427);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-2076024334 ^ (long)-2076024522);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1889480972 ^ (long)-1889481064);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)673364883 ^ (long)673364789);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)476345816 ^ (long)476345708);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)311879869 ^ (long)311879753);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)605341081 ^ (long)605341014);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)81166682 ^ (long)81166833);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-619039904 ^ (long)-619039872);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)659219703 ^ (long)659219536);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1921552576 ^ (long)-1921552632);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-818527621 ^ (long)-818527689);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1230063697 ^ (long)-1230063746);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-12241818 ^ (long)-12241796);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1449473041 ^ (long)1449473111);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-376986736 ^ (long)-376986670);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)2098834738 ^ (long)2098834730);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1775262130 ^ (long)1775262163);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1311863880 ^ (long)1311863842);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1516424318 ^ (long)-1516424195);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-968740721 ^ (long)-968740814);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-706063390 ^ (long)-706063524);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-270859512 ^ (long)-270859364);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-286652348 ^ (long)-286652235);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-243688305 ^ (long)-243688375);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1556714751 ^ (long)1556714511);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)2032647632 ^ (long)2032647581);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)701981902 ^ (long)701981877);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-116281002 ^ (long)-116280836);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)351135942 ^ (long)351135833);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-2000200013 ^ (long)-2000200138);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1558925486 ^ (long)1558925408);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-448593321 ^ (long)-448593290);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-168963230 ^ (long)-168963102);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-17065666 ^ (long)-17065518);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1620413447 ^ (long)1620413448);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1340900381 ^ (long)-1340900459);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-904187188 ^ (long)-904187315);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1794748332 ^ (long)1794748206);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-462203491 ^ (long)-462203421);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)118783406 ^ (long)118783264);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)635564880 ^ (long)635564812);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1730730788 ^ (long)1730730876);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1917794213 ^ (long)-1917794189);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)741054086 ^ (long)741054030);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1131332049 ^ (long)-1131331988);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1428500418 ^ (long)1428500372);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)348463050 ^ (long)348462930);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1829143051 ^ (long)-1829143253);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)2129708116 ^ (long)2129708053);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)859122378 ^ (long)859122320);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1144930148 ^ (long)1144930135);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-875270649 ^ (long)-875270608);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1203677358 ^ (long)1203677243);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1298200333 ^ (long)1298200542);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)998965693 ^ (long)998965582);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-688116622 ^ (long)-688116560);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1306001910 ^ (long)1306001864);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)328295976 ^ (long)328295938);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1271163478 ^ (long)1271163436);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1582365214 ^ (long)-1582365209);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1392637490 ^ (long)-1392637533);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-220402393 ^ (long)-220402427);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)336886229 ^ (long)336886265);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1294986140 ^ (long)-1294986100);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1809443942 ^ (long)1809444037);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-185601433 ^ (long)-185601365);
                    if (!3Q.\u200f\u2007\u2003) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-843278162 ^ (long)-843278148);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1054525724 ^ (long)1054525923)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)2096146035 ^ (long)2096126348)) >>> (int)((long)-372931225 ^ (long)-372931217)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-2020548627 ^ (long)-2020548627);
            if (!3Q.\u200f\u2007\u2003) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1464589206 ^ (long)1464589204);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1357821956 ^ (long)1357821959) | var5_6 << (int)((long)2077502705 ^ (long)2077502708)) ^ var3_4[var7_8]) & (int)((long)-1857989736 ^ (long)-1857989785);
                    if (3Q.\u200f\u2007\u2003) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)355262419 ^ (long)355262416) | var6_7 << (int)((long)952219245 ^ (long)952219240)) ^ var3_4[var7_8]) & (int)((long)-937398480 ^ (long)-937398321);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3Q.e[var2_3] = new String(var3_4).intern();
        }
        return 3Q.e[var2_3];
    }
}

