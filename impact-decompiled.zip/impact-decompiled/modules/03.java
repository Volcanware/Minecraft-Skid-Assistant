/* ==========================================================================
 * MODULE: Auto Disconnect
 * CATEGORY (inferred): Player
 * DESCRIPTION: Automatically disconnects when your health is under an amount
 * OBFUSCATED CLASS: net.impactclient.03
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dnx
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1z;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.3s0;
import net.impactclient.3sh;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 03
extends 3X
implements 3s0 {
    private int 6;
    private 1z 7;
    public int 4;
    public boolean 9;
    @EventHandler
    private final Listener<3sh> 1;
    private static final String[] d;
    private static final String[] e;
    @EventHandler
    private final Listener<3sh> 2;
    public static final boolean \u2002\u2002;
    private double 8;

    /*
     * Enabled aggressive block sorting
     */
    public final void 6() {
        block3: {
            block2: {
                boolean bl = \u2002\u2002;
                if (bl || bl) break block2;
                this.9 = (int)((long)1665713286 ^ (long)1665713287);
                if (bl || bl) break block2;
                this.4 = Math.round(03.3.s.dk());
                if (bl || bl) break block2;
                03.3.r.S();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 03.\u2002\u2002;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-840641915 ^ (long)-840641917)];
            if (var7) break block23;
            var3_2 = (int)((long)-777119675 ^ (long)-777119675);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u43cf\u6bae\u7820\u70d8\u43df\u6b51\u7877\u70ba\u437c\u6b72\u7837\u7056\u43ce\u6b8e\u784b\u705c\u437c\u6b25\u7885\u709a\u4389\u6b16\u78cc\u7004\u437b\u6b18\u780c\u707a\u4338\u6bfe\u7843\u700b\u4350\u6bc8\u7877\u70f7\u439c\u6b2f\u7845\u7021\u4340\u6b24\u7845\u70c4\u43d9\u6b51\u78b5\u70b5\u43c7\u6b1b\u7844\u7069\u4329\u6baf\u786d\u70df\u4314\u6b10\u7892\u70f7\u43fa\u6b50\u78ac\u7051\u43ce\u6ba7\u7839\u70d4\u43cb\u6b70\u7874\u70e8\u430e\u6b56\u7882\u705b\u438a\u6b23\u7821\u7016\u43d7\u6b4a\u7811\u70bd\u4316\u6b14\u78e9\u707f\u4397\u6bf3\u7882\u70aa\u43dd\u6bb7\u780b\u7000\u43df\u6b79\u78aa\u706f\u4324\u6bdd\u7840\u7063\u43c8\u6b3a\u7892\u708e\u435c\u6bd4\u787a\u7035", 131819007);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-978995145 ^ (long)-978995151);
            if (var7) break block23;
            var0_6 = (int)((long)-680869752 ^ (long)680869751);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1621624582 ^ (long)1621624662);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1198743661 ^ (long)1198743660);
                    if (03.\u2002\u2002) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!03.\u2002\u2002) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\uee12\uc688\ud5af\udd6b\ueebb\uc613\ud5bd\uddbc\uee44\uc6c4\ud54e\udd41\ueee4", 1702348814);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1013631919 ^ (long)-1013631913);
                            var0_6 = (int)((long)-847416915 ^ (long)847416914);
                            while (true) {
                                v0 = (int)((long)161809661 ^ (long)161809545);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-597483715 ^ (long)-597483715);
                                if (!03.\u2002\u2002) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!03.\u2002\u2002) ** continue;
                                throw null;
                            }
                            03.d = var5_1;
                            03.e = new String[(int)((long)-1812540406 ^ (long)-1812540404)];
                            if (!03.\u2002\u2002) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1753088153 ^ (long)1753088153);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-513112328 ^ (long)-513112327)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1735376046 ^ (long)1735376041)) {
                                case 0: {
                                    v15 = (int)((long)-1462861391 ^ (long)-1462861396);
                                    if (!03.\u2002\u2002) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)33504794 ^ (long)33504875);
                                    if (!03.\u2002\u2002) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)855569700 ^ (long)855569780);
                                    if (!03.\u2002\u2002) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)991136792 ^ (long)991136816);
                                    if (!03.\u2002\u2002) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)376638393 ^ (long)376638354);
                                    if (!03.\u2002\u2002) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)679825826 ^ (long)679825839);
                                    if (!03.\u2002\u2002) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)274294070 ^ (long)274294120);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!03.\u2002\u2002);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 03.\u2002\u2002;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1976619473 ^ (long)1976604447)) & (int)((long)-75223572 ^ (long)-75181549);
            if (var9_2) ** GOTO lbl-1000
            if (03.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 03.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1878475028 ^ (long)1878475028)] & (int)((long)-971780324 ^ (long)-971780125)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1925016570 ^ (long)-1925016399);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-2059945773 ^ (long)-2059945771);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1744300416 ^ (long)-1744300343);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1347983506 ^ (long)-1347983506);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-650717792 ^ (long)-650717919);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1263786419 ^ (long)-1263786260);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1175370661 ^ (long)1175370501);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-883491571 ^ (long)-883491485);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)990167546 ^ (long)990167348);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1022269008 ^ (long)1022269047);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-778622212 ^ (long)-778622281);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)453657999 ^ (long)453657995);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1734510196 ^ (long)1734510150);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1180495722 ^ (long)1180495681);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-572693360 ^ (long)-572693447);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-607558183 ^ (long)-607558194);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-404236212 ^ (long)-404236096);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1791606980 ^ (long)-1791606840);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1569709411 ^ (long)-1569709432);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-2643745 ^ (long)-2643849);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1539062171 ^ (long)1539062061);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1002093411 ^ (long)-1002093562);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-429799741 ^ (long)-429799828);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1054143566 ^ (long)1054143545);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1947422264 ^ (long)1947422283);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1174250340 ^ (long)1174250240);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1112635485 ^ (long)1112635505);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1504835924 ^ (long)-1504836088);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1294466458 ^ (long)-1294466335);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)686879412 ^ (long)686879340);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-920931495 ^ (long)-920931554);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-658520198 ^ (long)-658520138);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1402970636 ^ (long)-1402970855);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-455168299 ^ (long)-455168293);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)794258664 ^ (long)794258659);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1534291695 ^ (long)-1534291646);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1220107731 ^ (long)-1220107659);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-154518017 ^ (long)-154518190);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1307530486 ^ (long)1307530407);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)50653680 ^ (long)50653509);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)799928058 ^ (long)799927946);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-652585564 ^ (long)-652585690);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1550103692 ^ (long)-1550103770);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1180224166 ^ (long)1180224122);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-298311858 ^ (long)-298311730);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1045328107 ^ (long)-1045328117);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-466592571 ^ (long)-466592663);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)294995417 ^ (long)294995408);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1854385368 ^ (long)-1854385284);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)105539007 ^ (long)105538848);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)998281734 ^ (long)998281777);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1783933397 ^ (long)1783933290);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)399265965 ^ (long)399266025);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1406317577 ^ (long)1406317699);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)2020515575 ^ (long)2020515427);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1055638457 ^ (long)1055638417);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1833070624 ^ (long)-1833070837);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1659934947 ^ (long)1659934846);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)282091588 ^ (long)282091608);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1001104225 ^ (long)-1001104150);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)51126023 ^ (long)51126038);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)733094602 ^ (long)733094408);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1473983723 ^ (long)-1473983513);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1563832998 ^ (long)-1563832868);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1295409674 ^ (long)1295409801);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-818349697 ^ (long)-818349722);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1856957436 ^ (long)-1856957369);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)421745740 ^ (long)421745754);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1722165452 ^ (long)-1722165294);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)2036239735 ^ (long)2036239752);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1165085759 ^ (long)-1165085705);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)870635608 ^ (long)870635681);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1120261474 ^ (long)-1120261525);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)484571467 ^ (long)484571476);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1447380442 ^ (long)1447380449);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1015935724 ^ (long)1015935732);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-442069573 ^ (long)-442069745);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)911534915 ^ (long)911534949);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)939424979 ^ (long)939424776);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-143326475 ^ (long)-143326495);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1697266607 ^ (long)-1697266671);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)2117948510 ^ (long)2117948575);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)331752238 ^ (long)331752308);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1530003945 ^ (long)1530003832);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)563182747 ^ (long)563182774);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1601835898 ^ (long)1601835997);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-136346069 ^ (long)-136345901);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-243073120 ^ (long)-243073225);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1979319327 ^ (long)-1979319317);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1312817227 ^ (long)-1312817339);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)594910468 ^ (long)594910663);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-844928041 ^ (long)-844928090);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1835935433 ^ (long)1835935392);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-690986983 ^ (long)-690986830);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1931407667 ^ (long)-1931407773);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-164840150 ^ (long)-164839967);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-328509180 ^ (long)-328509066);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-805519400 ^ (long)-805519395);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1989411255 ^ (long)1989411280);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1355705386 ^ (long)-1355705402);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1798877050 ^ (long)1798877056);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-5707360 ^ (long)-5707331);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)574394810 ^ (long)574394671);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-316312080 ^ (long)-316312203);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)213252646 ^ (long)213252814);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-111678629 ^ (long)-111678603);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1524994017 ^ (long)-1524993911);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-586918536 ^ (long)-586918644);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1624466926 ^ (long)1624466839);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-959829910 ^ (long)-959829833);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-848630331 ^ (long)-848630396);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1988103916 ^ (long)1988103689);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1777399547 ^ (long)1777399540);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-52483112 ^ (long)-52483224);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)540347705 ^ (long)540347691);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)830142123 ^ (long)830142204);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)4042124 ^ (long)4042126);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1758212608 ^ (long)1758212731);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)506661667 ^ (long)506661884);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1163515451 ^ (long)1163515501);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1922869300 ^ (long)1922869304);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-283006358 ^ (long)-283006236);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)2135198346 ^ (long)2135198382);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1675369783 ^ (long)1675369970);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)387917450 ^ (long)387917368);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1810961102 ^ (long)1810961067);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)535478913 ^ (long)535478886);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1132968251 ^ (long)1132968372);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1173859537 ^ (long)-1173859386);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1792300424 ^ (long)-1792300509);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1347446539 ^ (long)1347446641);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)964486049 ^ (long)964486034);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-294399364 ^ (long)-294399402);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-62924751 ^ (long)-62924746);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-699293336 ^ (long)-699293281);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1097114160 ^ (long)1097114352);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1380092368 ^ (long)-1380092346);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)553471280 ^ (long)553471246);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1489323982 ^ (long)1489323944);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-2047849705 ^ (long)-2047849532);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1813893005 ^ (long)1813892967);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1394555927 ^ (long)1394555946);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1244754869 ^ (long)-1244754813);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1454563916 ^ (long)1454563941);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)464214104 ^ (long)464214269);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)664980067 ^ (long)664980080);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)726878459 ^ (long)726878306);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1807953224 ^ (long)-1807953348);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1005568212 ^ (long)1005568183);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1060561874 ^ (long)-1060561839);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1361865369 ^ (long)1361865253);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-752691815 ^ (long)-752691959);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)356423612 ^ (long)356423537);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1320056508 ^ (long)-1320056361);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1666755394 ^ (long)-1666755427);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)566198771 ^ (long)566198592);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)88325081 ^ (long)88325019);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-424965025 ^ (long)-424965052);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)763684535 ^ (long)763684454);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1775990715 ^ (long)-1775990640);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)289191539 ^ (long)289191594);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1913523228 ^ (long)-1913523385);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)2034026340 ^ (long)2034026411);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)2128354382 ^ (long)2128354559);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1477795225 ^ (long)-1477795145);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-177929845 ^ (long)-177929754);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1185853678 ^ (long)1185853677);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)954566751 ^ (long)954566762);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)280018983 ^ (long)280019016);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-2027827403 ^ (long)-2027827283);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1782087574 ^ (long)-1782087470);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-196881229 ^ (long)-196881315);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-2061703491 ^ (long)-2061703551);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1667824568 ^ (long)-1667824531);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1510720558 ^ (long)1510720542);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-334138195 ^ (long)-334138136);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)275026515 ^ (long)275026608);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1072765903 ^ (long)-1072765952);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1613693727 ^ (long)-1613693934);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1678129568 ^ (long)1678129451);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)387601909 ^ (long)387601689);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-738232493 ^ (long)-738232344);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)500562010 ^ (long)500562135);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)2010645973 ^ (long)2010645899);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1673891152 ^ (long)-1673891286);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1816615214 ^ (long)-1816615187);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-116288277 ^ (long)-116288490);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1221449340 ^ (long)1221449268);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1676541663 ^ (long)1676541502);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1343621421 ^ (long)1343621401);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)592990353 ^ (long)592990221);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-740345756 ^ (long)-740345832);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1335847713 ^ (long)1335847832);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1651115190 ^ (long)1651115258);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1026019346 ^ (long)-1026019572);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-868882739 ^ (long)-868882913);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)206344780 ^ (long)206344813);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1946461308 ^ (long)1946461428);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1781879911 ^ (long)1781879813);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-296597314 ^ (long)-296597400);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)544586535 ^ (long)544586503);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1777175344 ^ (long)-1777175500);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)2047471266 ^ (long)2047471358);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1530453074 ^ (long)1530453064);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1842317733 ^ (long)1842317666);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1720141416 ^ (long)1720141312);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-302936108 ^ (long)-302936074);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-951650783 ^ (long)-951650692);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)341000493 ^ (long)341000524);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)30183600 ^ (long)30183489);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1902203534 ^ (long)1902203601);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1745726950 ^ (long)-1745726873);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-2015409372 ^ (long)-2015409367);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)420089873 ^ (long)420089943);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1304186708 ^ (long)1304186878);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1756422416 ^ (long)1756422417);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1009816261 ^ (long)1009816081);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-766535650 ^ (long)-766535520);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)661549356 ^ (long)661549436);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)809053538 ^ (long)809053680);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-2076011355 ^ (long)-2076011301);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1494285209 ^ (long)1494285281);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1844736468 ^ (long)-1844736278);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)162118631 ^ (long)162118446);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1689161679 ^ (long)-1689161506);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)208941354 ^ (long)208941408);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)24592928 ^ (long)24592972);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-405012868 ^ (long)-405012747);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)281474620 ^ (long)281474762);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1139613142 ^ (long)-1139612946);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-140650757 ^ (long)-140650981);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1496311129 ^ (long)1496311187);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1957884584 ^ (long)1957884437);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)2096010893 ^ (long)2096010885);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1564084449 ^ (long)1564084404);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-250541459 ^ (long)-250541562);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1773600391 ^ (long)-1773600447);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-39538828 ^ (long)-39538801);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-2043962068 ^ (long)-2043962042);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-595696630 ^ (long)-595696569);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)628689459 ^ (long)628689645);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1413708735 ^ (long)-1413708786);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1452224305 ^ (long)-1452224267);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1955159085 ^ (long)1955159117);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-806334262 ^ (long)-806334412);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)366515773 ^ (long)366515905);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)633139190 ^ (long)633139119);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-668983368 ^ (long)-668983401);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1983740374 ^ (long)1983740232);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1023017099 ^ (long)1023017052);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)320053824 ^ (long)320053774);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1648278820 ^ (long)-1648278918);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1759713397 ^ (long)1759713495);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)273506750 ^ (long)273506660);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1150838826 ^ (long)-1150838932);
                    if (!03.\u2002\u2002) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1824059592 ^ (long)1824059633);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1390860468 ^ (long)-1390860365)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)2089009831 ^ (long)2088975704)) >>> (int)((long)-967259578 ^ (long)-967259570)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1917981668 ^ (long)-1917981668);
            if (!03.\u2002\u2002) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)2090653817 ^ (long)2090653819);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)951121042 ^ (long)951121041) | var5_6 << (int)((long)610053063 ^ (long)610053058)) ^ var3_4[var7_8]) & (int)((long)673721556 ^ (long)673721387);
                    if (03.\u2002\u2002) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1777563262 ^ (long)1777563261) | var6_7 << (int)((long)-1430955342 ^ (long)-1430955337)) ^ var3_4[var7_8]) & (int)((long)-303592557 ^ (long)-303592596);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            03.e[var2_3] = new String(var3_4).intern();
        }
        return 03.e[var2_3];
    }

    public 03() {
        boolean bl = \u2002\u2002;
        super(03.b((int)((long)-1763729068 ^ (long)-1763711079), (int)((long)2036461534 ^ (long)2036462676)) /* "Auto Disconnect" */, 03.b((int)((long)-529874517 ^ (long)-529889436), (int)((long)941154636 ^ (long)-941146848)) /* "Automatically disconnects when your health is under an amount" */);
        this.9 = (int)((long)1754654344 ^ (long)1754654344);
        this.7 = (1z)((34e)((34e)((34e)this.1().5(03.b((int)((long)99447376 ^ (long)99431582), (int)((long)-1954996614 ^ (long)-1955002354)) /* "Health" */)).7(03.b((int)((long)-2127339171 ^ (long)-2127353962), (int)((long)1381444692 ^ (long)1381440970)) /* "health" */)).1(03.b((int)((long)1820972126 ^ (long)1820955282), (int)((long)-343463245 ^ (long)343458048)) /* "The health to disconnect at" */)).3((int)((long)-1178138222 ^ (long)-1178138221)).2((int)((long)-349132470 ^ (long)-349132455)).5();
        this.1 = new Listener(sh -> {
            block3: {
                block2: {
                    boolean bl = \u2002\u2002;
                    if (bl || bl) break block2;
                    2R.1(this, 03.b((int)((long)534965315 ^ (long)534948489), (int)((long)796974551 ^ (long)796983099)) /* "suffix" */, String.valueOf(this.7.4));
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)-275248263 ^ (long)-275248263)]);
        this.2 = new Listener(sh -> {
            boolean bl;
            block30: {
                block29: {
                    block28: {
                        block27: {
                            block26: {
                                block25: {
                                    bl = \u2002\u2002;
                                    if (bl || bl) return;
                                    if (sh.5 != EventState.POST) break block25;
                                    if (bl) return;
                                    if (03.3.s == null) break block25;
                                    if (bl) return;
                                    if (!03.3.s.aX()) break block25;
                                    if (bl) return;
                                    if (!(03.3.y instanceof dnx)) break block26;
                                    if (bl) return;
                                }
                                if (bl) return;
                                return;
                            }
                            if (bl) return;
                            if (03.3.r == null) break block27;
                            if (bl) return;
                            if (03.3.s == null) break block27;
                            if (bl) return;
                            if (!3.G()) break block28;
                            if (bl) return;
                            if (3.H().n()) break block28;
                            if (bl) return;
                        }
                        if (bl) return;
                        this.8 = 0.0;
                        if (bl || bl) return;
                        this.6 = (int)((long)-1882498897 ^ (long)-1882498897);
                        if (bl || bl) return;
                        return;
                    }
                    if (bl) return;
                    if (03.3.s.b_()) break block29;
                    if (bl) return;
                    if (!03.3.s.a_()) break block30;
                    if (bl) return;
                }
                if (bl) return;
                this.3();
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            if (this.6 > 0) {
                if (bl) return;
                if (this.8 != 0.0) {
                    if (bl) return;
                    if (this.8 > (double)03.3.s.dk()) {
                        if (bl) return;
                        if (03.3.s.dk() <= (float)this.7.4) {
                            if (bl || bl) return;
                            this.6();
                            if (bl) return;
                        }
                    }
                }
            }
            if (bl) return;
            this.3();
            if (!bl && !bl) return;
        }, new Predicate[(int)((long)-149812236 ^ (long)-149812236)]);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 3() {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2002\u2002;
                    if (bl || bl) break block2;
                    this.6 += (int)((long)1665409680 ^ (long)1665409681);
                    if (bl || bl) break block2;
                    if (03.3.s.K >= (int)((long)1723808642 ^ (long)1723808648)) break block3;
                    if (bl) break block2;
                    this.8 = 03.3.s.dk();
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }
}

