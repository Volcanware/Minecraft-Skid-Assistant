/* ==========================================================================
 * MODULE: Skin Blinker
 * CATEGORY (inferred): Misc
 * DESCRIPTION: Causes your Jacket Layer to blink
 * OBFUSCATED CLASS: net.impactclient.7g
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  bfx
 *  com.google.common.collect.ImmutableList
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import com.google.common.collect.ImmutableList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.11;
import net.impactclient.1P;
import net.impactclient.1z;
import net.impactclient.2w$6X;
import net.impactclient.34H;
import net.impactclient.34J;
import net.impactclient.34R;
import net.impactclient.34X;
import net.impactclient.34Y;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.3sh;
import net.impactclient.8H;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7g
extends 3X
implements 34R {
    private final Random 62;
    private static final String[] d;
    public static final boolean \u2002\u2000\u2008\u200b\u2007;
    private Set<bfx> 0;
    private boolean 9;
    private 1P 2;
    @EventHandler
    private final Listener<3sh> 6b;
    private 1P 5;
    private 1z 1;
    private 1P 6;
    private final 8H 4;
    private 11 6Q;
    private 1P 8;
    private 1P 6I;
    private 1P 6v;
    private 1P 7;
    private static final String[] e;
    private static final List<bfx> 6W;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7g.\u2002\u2000\u2008\u200b\u2007;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1926856336 ^ (long)1926835659)) & (int)((long)-21604074 ^ (long)-21584151);
            if (var9_2) ** GOTO lbl-1000
            if (7g.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7g.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1272610801 ^ (long)-1272610801)] & (int)((long)-2068307920 ^ (long)-2068307761)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)783431940 ^ (long)783432134);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)86958657 ^ (long)86958802);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1833562510 ^ (long)1833562528);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1854763433 ^ (long)-1854763273);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1192138892 ^ (long)1192138955);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-2085972064 ^ (long)-2085972133);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-2143576791 ^ (long)-2143576656);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1657491576 ^ (long)1657491536);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-2046382978 ^ (long)-2046382890);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-804940449 ^ (long)-804940432);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)677862382 ^ (long)677862345);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-290228951 ^ (long)-290228955);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-540439037 ^ (long)-540439027);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-703758098 ^ (long)-703758139);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1319771575 ^ (long)-1319771457);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1467978357 ^ (long)-1467978427);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1152409891 ^ (long)-1152409909);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-2006167739 ^ (long)-2006167785);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1967805854 ^ (long)1967805811);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-746465664 ^ (long)-746465710);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)731018010 ^ (long)731017995);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-721619455 ^ (long)-721619327);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1335560020 ^ (long)-1335560046);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1632433769 ^ (long)1632433886);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1778860324 ^ (long)1778860308);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-246721387 ^ (long)-246721498);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1987772469 ^ (long)-1987772556);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1645706817 ^ (long)-1645706844);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)518421085 ^ (long)518421002);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)109950340 ^ (long)109950288);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1449753017 ^ (long)-1449752915);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1529283826 ^ (long)1529283787);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)801121142 ^ (long)801121236);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)453883294 ^ (long)453883271);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)805739412 ^ (long)805739279);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1617281819 ^ (long)1617281900);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-279880308 ^ (long)-279880432);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-717755297 ^ (long)-717755184);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)752207857 ^ (long)752207734);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)345917265 ^ (long)345917430);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)930473736 ^ (long)930473897);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-401304740 ^ (long)-401304671);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1819301339 ^ (long)-1819301318);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1946084718 ^ (long)-1946084654);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)980958327 ^ (long)980958283);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-119513305 ^ (long)-119513260);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)847388981 ^ (long)847389019);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1858737164 ^ (long)1858737213);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1378684854 ^ (long)-1378684800);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1660551166 ^ (long)-1660551053);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1897348360 ^ (long)1897348603);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-572662078 ^ (long)-572662028);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1959890399 ^ (long)-1959890365);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-933116935 ^ (long)-933117008);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1811941299 ^ (long)-1811941143);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)743132301 ^ (long)743132234);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)652673416 ^ (long)652673394);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1626049732 ^ (long)-1626049699);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)555260050 ^ (long)555260146);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1343750344 ^ (long)1343750317);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)273911217 ^ (long)273911253);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-606393299 ^ (long)-606393321);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-514754790 ^ (long)-514754718);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1999558919 ^ (long)-1999559126);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-229748475 ^ (long)-229748396);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1726933335 ^ (long)-1726933261);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-75565655 ^ (long)-75565681);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1739863834 ^ (long)-1739863883);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)2141956444 ^ (long)2141956430);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1646524973 ^ (long)-1646525073);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)134289712 ^ (long)134289865);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-2114344933 ^ (long)-2114344777);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-874184343 ^ (long)-874184201);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)0x19D9D191 ^ (long)433705332);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1931272471 ^ (long)1931272605);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1565408479 ^ (long)1565408259);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)784587894 ^ (long)784587976);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1155511072 ^ (long)1155511150);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-171996137 ^ (long)-171996141);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)111514379 ^ (long)111514532);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-317031915 ^ (long)-317031931);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-249261621 ^ (long)-249261675);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1306833813 ^ (long)1306833756);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1245695960 ^ (long)-1245695747);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1060226493 ^ (long)1060226331);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)2091447581 ^ (long)2091447719);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)2091798239 ^ (long)2091798185);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-630549324 ^ (long)-630549287);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)2041304501 ^ (long)2041304413);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1690839095 ^ (long)-1690839237);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1092618575 ^ (long)1092618621);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1583103397 ^ (long)-1583103333);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1551657478 ^ (long)1551657604);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)912024772 ^ (long)912024808);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)254292871 ^ (long)254292933);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-49082609 ^ (long)-49082428);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-309817159 ^ (long)-309817340);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1108767020 ^ (long)1108767039);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1739662949 ^ (long)1739663055);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)2017598917 ^ (long)2017598769);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-2071965393 ^ (long)-2071965393);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1568525858 ^ (long)1568525978);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1215092069 ^ (long)-1215092000);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1867508058 ^ (long)-1867508205);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)859219416 ^ (long)859219377);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)617709159 ^ (long)617709286);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1958349012 ^ (long)-1958349043);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1782904085 ^ (long)-1782904262);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-995925941 ^ (long)-995925930);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-22792305 ^ (long)-22792278);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-549190156 ^ (long)-549190300);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)767259418 ^ (long)767259486);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)332381006 ^ (long)332380993);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-186098851 ^ (long)-186098766);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1295620833 ^ (long)-1295620798);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)961920041 ^ (long)961920066);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)531971951 ^ (long)531972044);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1264378735 ^ (long)-1264378780);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1941674103 ^ (long)1941674097);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-696073567 ^ (long)-696073623);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-714982304 ^ (long)-714982388);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1011614391 ^ (long)-1011614291);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1731172586 ^ (long)1731172544);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-384113704 ^ (long)-384113750);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1618224206 ^ (long)-1618224203);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1197619780 ^ (long)-1197619932);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1565556524 ^ (long)-1565556692);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1446876529 ^ (long)1446876609);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-2108385833 ^ (long)-2108385804);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-2207476 ^ (long)-2207268);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1700298465 ^ (long)-1700298390);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-2065773911 ^ (long)-2065773866);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-417355872 ^ (long)-417355997);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-404672292 ^ (long)-404672393);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1950329551 ^ (long)-1950329414);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)888225219 ^ (long)888225158);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1118337386 ^ (long)1118337385);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1347497467 ^ (long)-1347497391);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1764168506 ^ (long)1764168507);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)2035894414 ^ (long)2035894292);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-356711634 ^ (long)-356711583);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-2052111436 ^ (long)-2052111601);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1487538120 ^ (long)1487538064);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1191210219 ^ (long)-1191210038);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1756555587 ^ (long)1756555592);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)261267553 ^ (long)261267542);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-211808390 ^ (long)-211808475);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-53386122 ^ (long)-53386162);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-2081323743 ^ (long)-2081323733);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)721108758 ^ (long)721108781);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1134462586 ^ (long)1134462512);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1303749554 ^ (long)1303749526);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1782492472 ^ (long)-1782492533);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1521535334 ^ (long)-1521535437);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1227977035 ^ (long)-1227977159);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-408070789 ^ (long)-408070821);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-51563255 ^ (long)-51563203);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-689542609 ^ (long)-689542654);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)575910357 ^ (long)575910305);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1911841989 ^ (long)1911841896);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1217196972 ^ (long)1217196918);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1638788266 ^ (long)-1638788257);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-320666105 ^ (long)-320666038);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1975935376 ^ (long)-1975935290);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1777092949 ^ (long)1777093073);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1572481419 ^ (long)-1572481389);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1510091124 ^ (long)1510091026);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1532862091 ^ (long)-1532862078);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-165988792 ^ (long)-165988864);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1621515013 ^ (long)1621515110);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)884320410 ^ (long)884320377);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)394225642 ^ (long)394225458);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)511589635 ^ (long)511589722);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)2035240738 ^ (long)2035240924);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1448389549 ^ (long)-1448389413);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-261435706 ^ (long)-261435846);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)734082015 ^ (long)734081867);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)355903356 ^ (long)355903328);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-2072585486 ^ (long)-2072585481);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1348541019 ^ (long)-1348541060);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1470204054 ^ (long)1470204052);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1085882929 ^ (long)-1085882988);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)2012448963 ^ (long)2012448932);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1892821993 ^ (long)1892821851);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-406899268 ^ (long)-406899374);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1030934964 ^ (long)-1030935040);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)346686743 ^ (long)346686856);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1052435377 ^ (long)-1052435431);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1381476899 ^ (long)-1381476939);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1584547020 ^ (long)1584546897);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1296986439 ^ (long)1296986490);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1215417884 ^ (long)1215417953);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1274764609 ^ (long)-1274764546);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)829847752 ^ (long)829847557);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-2053105816 ^ (long)-2053105748);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)971069366 ^ (long)971069358);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)661638277 ^ (long)661638163);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1702795723 ^ (long)1702795554);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1001784628 ^ (long)1001784653);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1550412605 ^ (long)1550412724);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)2128406898 ^ (long)2128406953);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1289077583 ^ (long)-1289077535);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1942960711 ^ (long)-1942960769);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)511261622 ^ (long)511261562);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)949767880 ^ (long)949767701);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)2027615075 ^ (long)2027615136);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1428429958 ^ (long)-1428429836);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)845022917 ^ (long)845022929);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1875327413 ^ (long)1875327288);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)570554072 ^ (long)570554093);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)828775516 ^ (long)828775505);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)121296858 ^ (long)121296698);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-439153166 ^ (long)-439153383);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-855431287 ^ (long)-855431329);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)901261176 ^ (long)901261118);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1053433685 ^ (long)-1053433739);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)2124585655 ^ (long)2124585558);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1625919468 ^ (long)1625919251);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)931294999 ^ (long)931295101);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)317424887 ^ (long)317424775);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-313193188 ^ (long)-313192962);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)994576580 ^ (long)994576470);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1922047937 ^ (long)-1922047750);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1461882016 ^ (long)-1461882039);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1500959046 ^ (long)1500959191);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)148539828 ^ (long)148539854);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1889081975 ^ (long)1889082082);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1546230740 ^ (long)1546230637);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1315941672 ^ (long)1315941839);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)999063461 ^ (long)999063396);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-992317579 ^ (long)-992317564);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1466160186 ^ (long)-1466160156);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-847732049 ^ (long)-847732182);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-527773138 ^ (long)-527773056);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1851084356 ^ (long)-1851084297);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-199810719 ^ (long)-199810608);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-431292030 ^ (long)-431292156);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1910919523 ^ (long)-1910919487);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1405869058 ^ (long)-1405869263);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)468887720 ^ (long)468887615);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)2073824283 ^ (long)2073824334);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-2139702315 ^ (long)-2139702294);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)531631526 ^ (long)531631363);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1599719784 ^ (long)1599719807);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-340622872 ^ (long)-340622851);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-316880991 ^ (long)-316880961);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-569100926 ^ (long)-569100971);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1598268700 ^ (long)1598268908);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-2042519535 ^ (long)-2042519441);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1363555574 ^ (long)1363555564);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)2039209518 ^ (long)2039209626);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-522085437 ^ (long)-522085392);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1960534944 ^ (long)1960534991);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1907321661 ^ (long)-1907321665);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1111095656 ^ (long)-1111095692);
                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1969874099 ^ (long)-1969874107);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1457804726 ^ (long)1457804617)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1713679458 ^ (long)1713656733)) >>> (int)((long)-1994722974 ^ (long)-1994722966)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1537105349 ^ (long)1537105349);
            if (!7g.\u2002\u2000\u2008\u200b\u2007) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1833031281 ^ (long)1833031283);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-773124817 ^ (long)-773124820) | var5_6 << (int)((long)1637342070 ^ (long)1637342067)) ^ var3_4[var7_8]) & (int)((long)1496782438 ^ (long)1496782489);
                    if (7g.\u2002\u2000\u2008\u200b\u2007) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)641990625 ^ (long)641990626) | var6_7 << (int)((long)549007486 ^ (long)549007483)) ^ var3_4[var7_8]) & (int)((long)-951391784 ^ (long)-951391961);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7g.e[var2_3] = new String(var3_4).intern();
        }
        return 7g.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 7g.\u2002\u2000\u2008\u200b\u2007;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)-1792789548 ^ (long)-1792789516)];
            if (var7) break block25;
            var3_2 = (int)((long)-286489915 ^ (long)-286489915);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\u2b12\u0241\u11f8\u19f7\u2b54\u0205\u1174\u19e1\u2bbb\u0239\u117f\u19bd\u2b24\u029a\u1145\u1920\u2bc8\u02c9\u11b8\u19cd\u2bf5\u0255\u11b8\u1947\u2b15\u022a\u11db\u1904\u2b91\u025d\u11a1\u19d9\u2b29\u026b\u11b4\u190f\u2bc6\u02a4\u116c\u194e\u2bab\u021c\u1144\u19bf\u2be2\u02ed\u11ad\u192f\u2b2b\u02d4\u1180\u195c\u2b69\u029d\u11f5\u191b\u2ba7\u02f2\u11ae\u19d7\u2b6b\u0272\u11d7\u19e9\u2b3b\u0219\u1135\u199b\u2b8d\u0264\u1114\u19b9\u2bab\u0230\u119d\u1926\u2bbf\u0270\u1169\u19d0\u2be1\u0285\u110d\u19c0\u2b20\u024f\u11c0\u19d7\u2b4d\u0298\u111c\u190d\u2b55\u02a3\u1198\u19e8\u2be4\u02b8\u11b7\u196b\u2b2f\u02b7\u1162\u1962\u2b8a\u027c\u11e5\u19ec\u2bf7\u02af\u115a\u19db\u2b15\u026c\u11b1\u19d1\u2b00\u023d\u112e\u1991\u2bc4\u025f\u11c7\u199b\u2bf5\u02ec\u116c\u19e2\u2bc4\u02ab\u11be\u199d\u2b02\u0241\u11dd\u19e2\u2be2\u02da\u11fc\u1943\u2be6\u027e\u1104\u1967\u2b99\u027d\u1169\u1926\u2b93\u024c\u11c8\u192e\u2bd8\u02e1\u1149\u1984\u2b02\u0287\u11e5\u19c5\u2b95\u02bf\u115a\u19d7\u2b47\u0254\u117e\u191e\u2b42\u023b\u1174\u19c6\u2bc1\u0226\u11d8\u19f2\u2b4f\u02c3\u1197\u1927\u2b6c\u02e8\u1141\u19bd\u2b18\u0292\u11b7\u1994\u2bd4\u029a\u11c5\u19e8\u2bc9\u027f\u118c\u19f1\u2b47\u023c\u11da\u191b\u2bac\u02c6\u11be\u19a4\u2b0e\u024e\u1146\u195d\u2b0e\u029b\u1175\u1910\u2be5\u0230\u1118\u1928\u2b5d\u0212\u11b8\u191e\u2b21\u02c4\u110a\u19b1\u2b49\u02a5\u111b\u1992\u2b8a\u0212\u11a7\u195a\u2b63\u0224\u112b\u192d\u2b50\u02b3\u117e\u1994\u2ba8\u0247\u1157\u19a6\u2bd4\u02bc\u11a5\u1952\u2b7d\u0274\u11b4\u199d\u2b66\u0245\u11d8\u1942\u2b69\u02b4\u1182\u1919\u2b24\u029d\u1194\u198b\u2b92\u0254\u1164\u192e\u2b39\u02ef\u1177\u1959\u2bf4\u0269\u114a\u195b\u2bc3\u02bb\u11e9\u19c5\u2b1e\u0228\u1156\u19b4\u2be8\u0266\u11ba\u1931\u2b6a\u02d3\u1112\u19a1\u2bb6\u0224\u1157\u1914\u2ba4\u02df\u1108\u19bb\u2b8f\u02f6\u1123\u1977\u2ba5\u02cf\u11a7\u19bc\u2b48\u0283\u11e0\u1977\u2b11\u0295\u114c\u19d5\u2b03\u0243\u112f\u19a8\u2b76\u020c\u11af\u193e\u2bca\u0236\u1127\u1993\u2be8\u0274\u11ee\u19d9\u2bc1\u0270\u11de\u197c\u2b6e\u02ba\u119f\u19a4\u2b10\u020b\u117a\u1959\u2b54\u0205\u112c\u196e\u2bdc\u0234\u1165\u19dc\u2b92\u020e\u11e8\u197c\u2b8f\u026e\u117d\u19b9\u2bf2\u0255\u1119\u19f6\u2b5c\u02e2\u11d4\u1925\u2b60\u023d\u1158\u19e3\u2b34\u022c\u113d\u196c\u2b6c\u02f8\u111d\u199e\u2be8\u0217\u113c\u1919\u2b72\u02b1\u11f4\u199c\u2b1d\u0271\u11fd\u19c3\u2b51\u02f8\u1113\u194e\u2b60\u0273\u11ff\u19ef\u2bb0\u0227\u11e3\u193c\u2b66\u0266\u1144\u198c\u2bfb\u020e\u1171\u191e\u2bb6\u0214\u110a\u19c4\u2b9e\u0266\u11e8\u19ac\u2b90\u0250\u119e\u1993\u2bb8\u0299\u1189\u19ec\u2b05\u0246\u11ce\u19ad\u2bec\u02b0\u1195\u19ac\u2ba5\u029b\u119b\u19b3\u2b46\u026f\u11da\u1917\u2b6e\u02b1\u11f8\u19cc\u2b5a\u02b5\u11df\u19a3\u2b34\u023f\u118d\u19c0\u2b51\u02df\u11e2\u19ae\u2b01\u0249\u1179\u194a\u2b64\u027b\u1139\u1948\u2b4c\u027e\u1110\u19c4\u2bfc\u0256\u1153\u1911\u2be2\u027f\u11c0\u19af\u2b96\u0234\u11df\u1958\u2bbd\u023e\u1127\u1937\u2b63\u02c3\u11b0\u19e3\u2b2c\u02cc\u1106\u199e\u2ba8\u02d0\u115e\u1951\u2bc6\u02fd\u11e2\u1977\u2bf4\u02d3\u1187\u1930\u2b33\u02c6\u11ad\u192e\u2bc4\u0267\u1190\u190a\u2b9a\u02f6\u1109\u19a4\u2b39\u0276\u11b9\u1917\u2b60\u0203\u1101\u191f\u2b94\u02a1\u11ef\u19ae\u2bf1\u027e\u11e8\u19b1\u2b01\u020c\u1163\u19bf\u2bae\u0287\u1114\u1983\u2be2\u02bd\u11fd\u1943\u2b5d\u0284\u11ad\u197d\u2bb7\u026d\u118f\u19ec\u2b1b\u0240\u11f0\u197a\u2b03\u021f\u11f1\u1981\u2b6e\u0275\u1179\u197d\u2b09\u0241\u111e\u1920\u2b70\u02bf\u1120\u19a2\u2bf2\u0261\u11d5", 1371802713);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)54447400 ^ (long)54447395);
            if (var7) break block25;
            var0_6 = (int)((long)313803616 ^ (long)-313803617);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)2116929547 ^ (long)2116929662);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)975278248 ^ (long)-975278249);
                        if (7g.\u2002\u2000\u2008\u200b\u2007) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!7g.\u2002\u2000\u2008\u200b\u2007) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\ubf3e\u965b\u856e\u8dea\ubf3c\u9685\u8557\u8d2a\ubfc8\u96b4\u85cd\u8d4a\ubf6b\u9605\u8511\u8d14\ubf16", -1662412717);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)-733486120 ^ (long)-733486124);
                                var0_6 = (int)((long)2103582608 ^ (long)-2103582609);
                                while (true) {
                                    v0 = (int)((long)-1726132667 ^ (long)-1726132684);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)44547447 ^ (long)44547447);
                                    if (!7g.\u2002\u2000\u2008\u200b\u2007) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!7g.\u2002\u2000\u2008\u200b\u2007) ** continue;
                                    throw null;
                                }
                                7g.d = var5_1;
                                7g.e = new String[(int)((long)-1906644163 ^ (long)-1906644195)];
                                if (7g.\u2002\u2000\u2008\u200b\u2007) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)-1506508301 ^ (long)-1506508301);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)431705561 ^ (long)431705560)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)18177200 ^ (long)18177207)) {
                                    case 0: {
                                        v15 = (int)((long)-2110421768 ^ (long)-2110421868);
                                        if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)-1347526773 ^ (long)-1347526736);
                                        if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)-1139657535 ^ (long)-1139657522);
                                        if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)378909274 ^ (long)378909186);
                                        if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)-2102512225 ^ (long)-2102512228);
                                        if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)-760665094 ^ (long)-760665189);
                                        if (!7g.\u2002\u2000\u2008\u200b\u2007) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)1877150459 ^ (long)1877150390);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!7g.\u2002\u2000\u2008\u200b\u2007);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                7g.6W = ImmutableList.copyOf((Object[])bfx.values());
                break;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        block3: {
            block2: {
                boolean bl = \u2002\u2000\u2008\u200b\u2007;
                if (bl || bl) break block2;
                this.0 = 7g.3.k.d();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 5(bfx bfx2) {
        boolean bl;
        block8: {
            block6: {
                block7: {
                    block5: {
                        boolean bl2 = \u2002\u2000\u2008\u200b\u2007;
                        if (bl2 || bl2) break block5;
                        if (!((String)this.6Q.0()).equalsIgnoreCase(7g.b((int)((long)2089342471 ^ (long)2089321803), (int)((long)-387010766 ^ (long)387012003)) /* "random" */)) break block6;
                        if (!bl2) break block7;
                    }
                    return;
                }
                bl = this.62.nextBoolean();
                if (\u2002\u2000\u2008\u200b\u2007) {
                    throw null;
                }
                break block8;
            }
            bl = this.9;
        }
        boolean bl3 = bl;
        7g.3.k.a(bfx2, bl3);
    }

    public 7g() {
        boolean bl = \u2002\u2000\u2008\u200b\u2007;
        super(7g.b((int)((long)-69976783 ^ (long)-69964191), (int)((long)-940905130 ^ (long)-940926356)) /* "Skin Blinker" */, 7g.b((int)((long)1078965301 ^ (long)1078978430), (int)((long)-1588862511 ^ (long)1588855796)) /* "Causes your Jacket Layer to blink" */);
        String[] stringArray = new String[(int)((long)-1602807836 ^ (long)-1602807834)];
        stringArray[(int)((long)1324810733 ^ (long)1324810733)] = 7g.b((int)((long)1305447931 ^ (long)1305468584), (int)((long)-1810040686 ^ (long)1810060272)) /* "Random" */;
        stringArray[(int)((long)2067000867 ^ (long)2067000866)] = 7g.b((int)((long)66258208 ^ (long)66279010), (int)((long)-1225879630 ^ (long)1225851813)) /* "Toggle" */;
        Object object = stringArray;
        34J j2 = (34H)((34H)((34H)this.0().5(7g.b((int)((long)-1999036778 ^ (long)-1999024687), (int)((long)-877015252 ^ (long)-877019029)) /* "Mode" */)).7(7g.b((int)((long)466858263 ^ (long)466870867), (int)((long)1020175901 ^ (long)1020182841)) /* "mode" */)).1(7g.b((int)((long)1329363554 ^ (long)1329342764), (int)((long)1109278526 ^ (long)1109292718)) /* "How model parts should behave each skin blinker tick" */);
        ((34H)((34H)((34H)this.0().5(7g.b((int)((long)-1999036778 ^ (long)-1999024687), (int)((long)-877015252 ^ (long)-877019029)) /* "Mode" */)).7(7g.b((int)((long)466858263 ^ (long)466870867), (int)((long)1020175901 ^ (long)1020182841)) /* "mode" */)).1(7g.b((int)((long)1329363554 ^ (long)1329342764), (int)((long)1109278526 ^ (long)1109292718)) /* "How model parts should behave each skin blinker tick" */)).3 = object;
        this.6Q = (11)j2.5();
        object = (int)((long)479848546 ^ (long)479848618);
        j2 = ((34e)((34e)((34e)this.1().5(7g.b((int)((long)-562364257 ^ (long)-562342946), (int)((long)1141592326 ^ (long)1141588223)) /* "Delay" */)).7(7g.b((int)((long)-1574590859 ^ (long)-1574570710), (int)((long)-1214590344 ^ (long)1214595178)) /* "delay" */)).1(7g.b((int)((long)-454487934 ^ (long)-454474795), (int)((long)2024454005 ^ (long)2024467262)) /* "The delay in between each blink" */)).3((int)((long)62816544 ^ (long)62816530)).2((int)((long)-530315194 ^ (long)-530314322));
        ((34e)((34e)((34e)this.1().5(7g.b((int)((long)-562364257 ^ (long)-562342946), (int)((long)1141592326 ^ (long)1141588223)) /* "Delay" */)).7(7g.b((int)((long)-1574590859 ^ (long)-1574570710), (int)((long)-1214590344 ^ (long)1214595178)) /* "delay" */)).1(7g.b((int)((long)-454487934 ^ (long)-454474795), (int)((long)2024454005 ^ (long)2024467262)) /* "The delay in between each blink" */)).3((int)((long)62816544 ^ (long)62816530)).2((int)((long)-530315194 ^ (long)-530314322)).7 = object;
        this.1 = (1z)((34e)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7g.b((int)((long)-1868487598 ^ (long)-1868466429), (int)((long)774125075 ^ (long)0x2E24422E)))).7(7g.b((int)((long)81458244 ^ (long)81438468), (int)((long)1728209994 ^ (long)-1728214990)) /* "hat" */)).1(7g.b((int)((long)-909598487 ^ (long)-909577296), (int)((long)2070795521 ^ (long)-2070805994)) /* "Whether or not to have the hat blink" */);
        ((34X)((34X)((34X)this.4().5(7g.b((int)((long)-1868487598 ^ (long)-1868466429), (int)((long)774125075 ^ (long)0x2E24422E)))).7(7g.b((int)((long)81458244 ^ (long)81438468), (int)((long)1728209994 ^ (long)-1728214990)) /* "hat" */)).1(7g.b((int)((long)-909598487 ^ (long)-909577296), (int)((long)2070795521 ^ (long)-2070805994)) /* "Whether or not to have the hat blink" */)).7 = object;
        this.8 = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7g.b((int)((long)-883467987 ^ (long)-883488133), (int)((long)-1119968496 ^ (long)-1119967758)) /* "Jacket" */)).7(7g.b((int)((long)1571244087 ^ (long)1571232634), (int)((long)-1885270298 ^ (long)1885248697)) /* "jacket" */)).1(7g.b((int)((long)-862698959 ^ (long)-862711433), (int)((long)845207476 ^ (long)845187366)) /* "Whether or not to have the jacket blink" */);
        ((34X)((34X)((34X)this.4().5(7g.b((int)((long)-883467987 ^ (long)-883488133), (int)((long)-1119968496 ^ (long)-1119967758)) /* "Jacket" */)).7(7g.b((int)((long)1571244087 ^ (long)1571232634), (int)((long)-1885270298 ^ (long)1885248697)) /* "jacket" */)).1(7g.b((int)((long)-862698959 ^ (long)-862711433), (int)((long)845207476 ^ (long)845187366)) /* "Whether or not to have the jacket blink" */)).7 = object;
        this.6v = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7g.b((int)((long)1850156964 ^ (long)1850176737), (int)((long)-622060133 ^ (long)-622043833)) /* "Right Sleeve" */)).7(7g.b((int)((long)-1654139718 ^ (long)-1654159384), (int)((long)-374498963 ^ (long)-374480132)) /* "right_sleeve" */)).1(7g.b((int)((long)-1786385941 ^ (long)-1786398018), (int)((long)-528228055 ^ (long)-528242057)) /* "Whether or not to have the right sleeve blink" */);
        ((34X)((34X)((34X)this.4().5(7g.b((int)((long)1850156964 ^ (long)1850176737), (int)((long)-622060133 ^ (long)-622043833)) /* "Right Sleeve" */)).7(7g.b((int)((long)-1654139718 ^ (long)-1654159384), (int)((long)-374498963 ^ (long)-374480132)) /* "right_sleeve" */)).1(7g.b((int)((long)-1786385941 ^ (long)-1786398018), (int)((long)-528228055 ^ (long)-528242057)) /* "Whether or not to have the right sleeve blink" */)).7 = object;
        this.6I = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7g.b((int)((long)82230537 ^ (long)82243154), (int)((long)-2046810168 ^ (long)-2046816902)) /* "Left Sleeve" */)).7(7g.b((int)((long)-1707393771 ^ (long)-1707381158), (int)((long)1814857171 ^ (long)-1814864403)) /* "left_sleeve" */)).1(7g.b((int)((long)-357503351 ^ (long)-357515823), (int)((long)-659172718 ^ (long)659183333)) /* "Whether or not to have the left sleeve blink" */);
        ((34X)((34X)((34X)this.4().5(7g.b((int)((long)82230537 ^ (long)82243154), (int)((long)-2046810168 ^ (long)-2046816902)) /* "Left Sleeve" */)).7(7g.b((int)((long)-1707393771 ^ (long)-1707381158), (int)((long)1814857171 ^ (long)-1814864403)) /* "left_sleeve" */)).1(7g.b((int)((long)-357503351 ^ (long)-357515823), (int)((long)-659172718 ^ (long)659183333)) /* "Whether or not to have the left sleeve blink" */)).7 = object;
        this.7 = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7g.b((int)((long)1300509662 ^ (long)1300521091), (int)((long)1218189349 ^ (long)1218184643)) /* "Right Leg" */)).7(7g.b((int)((long)-2113724504 ^ (long)-2113712927), (int)((long)-1020036483 ^ (long)1020050193)) /* "right_pants_leg" */)).1(7g.b((int)((long)-546101183 ^ (long)-546079969), (int)((long)788492428 ^ (long)788487169)) /* "Whether or not to have the right leg blink" */);
        ((34X)((34X)((34X)this.4().5(7g.b((int)((long)1300509662 ^ (long)1300521091), (int)((long)1218189349 ^ (long)1218184643)) /* "Right Leg" */)).7(7g.b((int)((long)-2113724504 ^ (long)-2113712927), (int)((long)-1020036483 ^ (long)1020050193)) /* "right_pants_leg" */)).1(7g.b((int)((long)-546101183 ^ (long)-546079969), (int)((long)788492428 ^ (long)788487169)) /* "Whether or not to have the right leg blink" */)).7 = object;
        this.5 = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7g.b((int)((long)607586237 ^ (long)607606007), (int)((long)-1410871736 ^ (long)1410867411)) /* "Left Leg" */)).7(7g.b((int)((long)112879796 ^ (long)112868343), (int)((long)15929278 ^ (long)-15950129)) /* "left_pants_leg" */)).1(7g.b((int)((long)-1607615386 ^ (long)-1607602374), (int)((long)-1202558790 ^ (long)-1202560251)) /* "Whether or not to have the left leg blink" */);
        ((34X)((34X)((34X)this.4().5(7g.b((int)((long)607586237 ^ (long)607606007), (int)((long)-1410871736 ^ (long)1410867411)) /* "Left Leg" */)).7(7g.b((int)((long)112879796 ^ (long)112868343), (int)((long)15929278 ^ (long)-15950129)) /* "left_pants_leg" */)).1(7g.b((int)((long)-1607615386 ^ (long)-1607602374), (int)((long)-1202558790 ^ (long)-1202560251)) /* "Whether or not to have the left leg blink" */)).7 = object;
        this.6 = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7g.b((int)((long)-45128541 ^ (long)-45139977), (int)((long)1662097430 ^ (long)1662114092)) /* "Cape" */)).7(7g.b((int)((long)807618468 ^ (long)807605484), (int)((long)452897138 ^ (long)452912307)) /* "cape" */)).1(7g.b((int)((long)1282269199 ^ (long)1282257749), (int)((long)1029608242 ^ (long)1029613509)) /* "Whether or not to have the cape blink" */);
        ((34X)((34X)((34X)this.4().5(7g.b((int)((long)-45128541 ^ (long)-45139977), (int)((long)1662097430 ^ (long)1662114092)) /* "Cape" */)).7(7g.b((int)((long)807618468 ^ (long)807605484), (int)((long)452897138 ^ (long)452912307)) /* "cape" */)).1(7g.b((int)((long)1282269199 ^ (long)1282257749), (int)((long)1029608242 ^ (long)1029613509)) /* "Whether or not to have the cape blink" */)).7 = object;
        this.2 = (1P)((34X)j2).5();
        this.4 = new 8H();
        this.62 = new Random();
        this.6b = new Listener(sh -> {
            int n;
            boolean bl;
            block14: {
                block13: {
                    bl = \u2002\u2000\u2008\u200b\u2007;
                    if (bl || bl) return;
                    if (7g.3.s == null) break block13;
                    if (bl) return;
                    if (sh.5 == EventState.PRE) break block14;
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            if (this.1.4 != (int)((long)-2027181053 ^ (long)-2027181007)) {
                if (bl) return;
                if (!this.4.8(this.1.4)) return;
                if (bl) return;
            }
            if (bl) {
                return;
            }
            if (!this.9) {
                n = (int)((long)1601903234 ^ (long)1601903235);
                if (\u2002\u2000\u2008\u200b\u2007) {
                    throw null;
                }
            } else {
                n = (int)((long)1438439192 ^ (long)1438439192);
            }
            this.9 = n;
            6W.stream().filter(this::8).forEach(this::5);
            this.4.0();
        }, new Predicate[(int)((long)884529773 ^ (long)884529773)]);
    }

    private boolean 8(bfx bfx2) {
        boolean bl = \u2002\u2000\u2008\u200b\u2007;
        if (bl || bl) {
            return true;
        }
        return ((34Y)this.9(bfx2.c())).3();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u2002\u2000\u2008\u200b\u2007;
                if (bl || bl) break block2;
                6W.forEach(bfx2 -> {
                    block3: {
                        block2: {
                            boolean bl = \u2002\u2000\u2008\u200b\u2007;
                            if (bl || bl) break block2;
                            7g.3.k.a(bfx2, this.0.contains(bfx2));
                            if (!bl) break block3;
                        }
                        return;
                    }
                });
                if (!bl && !bl) break block3;
            }
            return;
        }
    }
}

