/* ==========================================================================
 * MODULE: Anti Fire
 * CATEGORY (inferred): Player
 * DESCRIPTION: AntiFire, Only works on 1.8 servers
 * OBFUSCATED CLASS: net.impactclient.3o
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  oj
 *  st
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.2w$6X;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.49;
import net.impactclient.4f;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3o
extends 3X
implements 49 {
    @EventHandler
    private final Listener<4f> 8;
    public static final boolean \u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b;
    private static final String[] e;
    private static final String[] d;

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)-1267641424 ^ (long)-1267641422)];
            if (var7) break block16;
            var3_2 = (int)((long)-9689121 ^ (long)-9689121);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u27b5\u0fc4\u1c80\u1415\u278d\u0f2e\u1c88\u141d\u27df\u0f5c\u1c02\u146a\u27c4\u0f6f\u1cf8\u1498\u27ad\u0fda\u1caf\u14d0\u27c4\u0ff4\u1cde\u144f\u2784\u0f2d\u1c23\u14f3\u275b\u0f0e\u1c2f\u1439\u279d\u0f4c\u1ccc\u142e\u27ea\u0f43\u1c6b\u14e5\u2796\u0f1f\u1c5a\u14e6\u27b4", 2076770790);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)1173120556 ^ (long)1173120527);
            if (var7) break block16;
            var0_6 = (int)((long)-1869322998 ^ (long)1869322997);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)2117942096 ^ (long)-2117942097);
                if (3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) continue block8;
                            throw null;
                        }
                        3o.d = var5_1;
                        3o.e = new String[(int)((long)-1755137074 ^ (long)-1755137076)];
                        if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)2014777678 ^ (long)2014777678);
                v5 = (int)((long)-1124850606 ^ (long)-1124850676);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)474103238 ^ (long)474103239)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)2053480152 ^ (long)2053480159)) {
                                case 0: {
                                    v12 = (int)((long)1717120202 ^ (long)1717120234);
                                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)-320426697 ^ (long)-320426699);
                                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-1535145864 ^ (long)-1535145900);
                                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)-177774331 ^ (long)-177774247);
                                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)-22896838 ^ (long)-22896817);
                                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)488523784 ^ (long)488523804);
                                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-1864168003 ^ (long)-1864167979);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) ** continue;
                throw null;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)87635554 ^ (long)-87630646)) & (int)((long)-2012051030 ^ (long)-2012055979);
            if (var9_2) ** GOTO lbl-1000
            if (3o.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3o.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-998002460 ^ (long)-998002460)] & (int)((long)-346027821 ^ (long)-346027988)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)2124716496 ^ (long)2124716307);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-265705670 ^ (long)-265705693);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)457335425 ^ (long)457335520);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-614361219 ^ (long)-614361232);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1068985332 ^ (long)1068985180);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1893561097 ^ (long)1893561107);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)866462280 ^ (long)866462361);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1494920376 ^ (long)1494920439);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)225529820 ^ (long)225529825);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1585698745 ^ (long)-1585698583);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-955357666 ^ (long)-955357563);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1109920521 ^ (long)1109920559);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-31183319 ^ (long)-31183319);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)180771433 ^ (long)180771500);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-989495635 ^ (long)-989495780);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-232224772 ^ (long)-232224776);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1532728140 ^ (long)-1532728203);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-384905138 ^ (long)-384905208);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-109378243 ^ (long)-109378073);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)986273882 ^ (long)986273863);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)486245509 ^ (long)486245420);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1127482235 ^ (long)-1127482228);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1725091837 ^ (long)1725091720);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-612066356 ^ (long)-612066481);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1394716545 ^ (long)-1394716436);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)624224153 ^ (long)624224253);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1383079786 ^ (long)-1383079866);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-906912398 ^ (long)-906912473);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1333111168 ^ (long)-1333111188);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1718726844 ^ (long)1718726709);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1567945197 ^ (long)1567945084);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1982997098 ^ (long)-1982997206);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-832237724 ^ (long)-832237800);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-124242947 ^ (long)-124243114);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)611581881 ^ (long)611581705);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1824199482 ^ (long)1824199507);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)2120754407 ^ (long)2120754368);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1956046865 ^ (long)-1956046887);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-886573170 ^ (long)-886573127);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)2040266064 ^ (long)2040266127);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1467187302 ^ (long)1467187392);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)703426252 ^ (long)703426194);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1311542135 ^ (long)1311542192);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1646987807 ^ (long)1646987954);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)778269026 ^ (long)778269146);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-633050635 ^ (long)-633050651);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-2117552747 ^ (long)-2117552877);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1622158336 ^ (long)1622158471);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-618049579 ^ (long)-618049729);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1244781638 ^ (long)1244781700);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-2112897359 ^ (long)-2112897497);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-140994561 ^ (long)-140994811);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-55760634 ^ (long)-55760468);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)23060299 ^ (long)23060478);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-601423198 ^ (long)-601423146);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1950032150 ^ (long)-1950032227);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1685796761 ^ (long)1685796757);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1706788308 ^ (long)-1706788122);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)322203475 ^ (long)322203418);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)943784458 ^ (long)943784520);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1399143648 ^ (long)1399143610);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)322866186 ^ (long)322866315);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-201511404 ^ (long)-201511190);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-960629812 ^ (long)-960629930);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1220723397 ^ (long)1220723213);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)473863408 ^ (long)473863307);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-23325637 ^ (long)-23325501);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1208965865 ^ (long)1208965878);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1717441801 ^ (long)-1717442014);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1302479618 ^ (long)-1302479848);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1474962755 ^ (long)1474962831);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1126479912 ^ (long)-1126480003);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-262521296 ^ (long)-262521129);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)525520947 ^ (long)525520989);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1039360087 ^ (long)1039360179);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)267448420 ^ (long)0xFF0F00C);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)53187012 ^ (long)53186937);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1255795534 ^ (long)-1255795505);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-754408312 ^ (long)-754408230);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1697889263 ^ (long)-1697889275);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1750724621 ^ (long)-1750724644);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1393127437 ^ (long)1393127427);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)739931446 ^ (long)739931444);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1115455769 ^ (long)1115455805);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)554816551 ^ (long)554816744);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)520757381 ^ (long)520757481);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1616923606 ^ (long)-1616923556);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)718826983 ^ (long)718826998);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1858674909 ^ (long)1858674907);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1036889284 ^ (long)-1036889278);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1111792680 ^ (long)-1111792757);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)938152906 ^ (long)938152707);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-549627127 ^ (long)-549627005);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-69901949 ^ (long)-69901853);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-726400917 ^ (long)-726400898);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1465701791 ^ (long)1465701863);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)698480297 ^ (long)698480298);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1370133346 ^ (long)-1370133259);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1683445836 ^ (long)1683445961);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1442393713 ^ (long)1442393768);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1492005250 ^ (long)1492005265);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1440696269 ^ (long)1440696125);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1797021481 ^ (long)1797021473);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1041554916 ^ (long)-1041554702);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1524056646 ^ (long)1524056750);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)820520793 ^ (long)820520923);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1896275042 ^ (long)-1896275012);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-186300341 ^ (long)-186300342);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1226013431 ^ (long)-1226013405);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)132790955 ^ (long)132790805);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1847128647 ^ (long)1847128784);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-73344497 ^ (long)-73344502);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-832372932 ^ (long)-832372818);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1078612888 ^ (long)-1078612835);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)788683051 ^ (long)788683183);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1210557934 ^ (long)-1210557848);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)867139351 ^ (long)867139463);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1245224840 ^ (long)1245224912);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1570970038 ^ (long)1570969902);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-588002242 ^ (long)-588002158);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1209980479 ^ (long)1209980457);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)791619604 ^ (long)791619760);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-721616730 ^ (long)-721616850);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1715855120 ^ (long)-1715855316);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1980677230 ^ (long)-1980677263);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1275057652 ^ (long)1275057625);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1824512023 ^ (long)1824512117);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-859061147 ^ (long)-859061142);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-203867920 ^ (long)-203867984);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)696608336 ^ (long)696608420);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1319558836 ^ (long)1319558767);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-96601604 ^ (long)-96601669);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)87565551 ^ (long)87565388);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1245237327 ^ (long)1245237501);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1126312641 ^ (long)1126312625);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)2106186437 ^ (long)2106186462);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1321840004 ^ (long)1321840089);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-423014264 ^ (long)-423014324);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)770440272 ^ (long)770440379);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1436193127 ^ (long)-1436193151);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1899683520 ^ (long)-1899683535);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-320133311 ^ (long)-320133169);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1349247899 ^ (long)-1349247759);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1222436897 ^ (long)1222436934);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1035919243 ^ (long)1035919146);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)889940998 ^ (long)889941133);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-2056932998 ^ (long)-2056933071);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1609635894 ^ (long)1609635843);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)135187279 ^ (long)135187394);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-36429011 ^ (long)-36428816);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1640233228 ^ (long)1640233308);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)12820529 ^ (long)12820721);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)63889361 ^ (long)63889267);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1885545414 ^ (long)-1885545249);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-289910056 ^ (long)-289910038);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-50195884 ^ (long)-50195788);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-291058279 ^ (long)-291058312);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1754712736 ^ (long)1754712825);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-740935156 ^ (long)-740935075);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-2054862627 ^ (long)-2054862664);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1233909554 ^ (long)-1233909727);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1827184509 ^ (long)1827184478);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-174107897 ^ (long)-174107736);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1170018759 ^ (long)-1170018714);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)585208073 ^ (long)585208186);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1573489344 ^ (long)1573489385);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1407234755 ^ (long)1407234797);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1862630339 ^ (long)1862630236);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1535834036 ^ (long)1535834104);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)453438897 ^ (long)453438731);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1001023873 ^ (long)1001023957);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-734478193 ^ (long)-734478120);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1598753000 ^ (long)1598752803);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1104902121 ^ (long)-1104901983);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-692242424 ^ (long)-692242348);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1225657245 ^ (long)-1225657199);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)117983900 ^ (long)117983929);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)792332340 ^ (long)792332530);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)630611071 ^ (long)630610997);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)651261930 ^ (long)651261915);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1650231397 ^ (long)1650231374);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)376402373 ^ (long)376402425);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1639340992 ^ (long)1639340876);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)2089314543 ^ (long)2089314510);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-590460539 ^ (long)-590460433);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)410063947 ^ (long)410063910);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1067676612 ^ (long)1067676667);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1819952402 ^ (long)-1819952428);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1341699515 ^ (long)-1341699526);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1839470945 ^ (long)1839471046);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-670434436 ^ (long)-670434425);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1666134167 ^ (long)1666134027);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1270253895 ^ (long)1270253839);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1366325520 ^ (long)1366325679);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1063146278 ^ (long)-1063146311);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1973193917 ^ (long)-1973193827);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1724562567 ^ (long)-1724562464);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-241946738 ^ (long)-241946816);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1716581256 ^ (long)1716581211);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1728377240 ^ (long)-1728377133);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1985668473 ^ (long)1985668532);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-497305423 ^ (long)-497305464);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)785348945 ^ (long)785348995);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1462564081 ^ (long)-1462564000);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1281381704 ^ (long)-1281381792);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-83934092 ^ (long)-83934116);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1696036574 ^ (long)1696036478);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)327443549 ^ (long)327443684);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-230261262 ^ (long)-230261325);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-435244851 ^ (long)-435244811);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1576296763 ^ (long)-1576296886);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-495019480 ^ (long)-495019268);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1352879155 ^ (long)1352879236);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-646321661 ^ (long)-646321439);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1505468237 ^ (long)1505468203);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1585218621 ^ (long)1585218563);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-143671055 ^ (long)-143671045);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)55774804 ^ (long)55774850);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-170106179 ^ (long)-170106302);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-485275418 ^ (long)-485275627);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1545963270 ^ (long)1545963398);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1186614118 ^ (long)-1186614164);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)2635501 ^ (long)2635432);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)655562310 ^ (long)655562426);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-668325006 ^ (long)-668324989);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1282777134 ^ (long)-1282777147);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-897002905 ^ (long)-897002959);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)83472617 ^ (long)83472605);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-92566768 ^ (long)-92566709);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-199777849 ^ (long)-199777856);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-233628945 ^ (long)-233629023);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1874819007 ^ (long)1874818827);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1547094122 ^ (long)-1547094099);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1891746190 ^ (long)1891746238);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)2008543099 ^ (long)2008543106);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)667032119 ^ (long)667032256);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1888050113 ^ (long)-1888050157);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1183966535 ^ (long)-1183966528);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1890216909 ^ (long)-1890216848);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)908359913 ^ (long)908359853);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1026033579 ^ (long)1026033560);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1412485164 ^ (long)1412485371);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-2107735270 ^ (long)-2107735238);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1483427953 ^ (long)1483427996);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1417415639 ^ (long)1417415498);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1614205389 ^ (long)-1614205222);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1326803028 ^ (long)1326803014);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-601719754 ^ (long)-601719675);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)422278720 ^ (long)422278845);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)891665002 ^ (long)891664993);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1878741762 ^ (long)1878741788);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-163391292 ^ (long)-163391351);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1541484463 ^ (long)1541484337);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1100300662 ^ (long)-1100300650);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)124461534 ^ (long)124461387);
                    if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-862108230 ^ (long)-862108216);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)2045371246 ^ (long)2045371281)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1095560781 ^ (long)-1095504308)) >>> (int)((long)-236337357 ^ (long)-236337349)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1159323647 ^ (long)-1159323647);
            if (!3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1771494291 ^ (long)1771494289);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1740500316 ^ (long)1740500319) | var5_6 << (int)((long)1528158717 ^ (long)1528158712)) ^ var3_4[var7_8]) & (int)((long)-1778096314 ^ (long)-1778096199);
                    if (3o.\u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1831784870 ^ (long)1831784869) | var6_7 << (int)((long)1297481551 ^ (long)1297481546)) ^ var3_4[var7_8]) & (int)((long)-1808254541 ^ (long)-1808254644);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3o.e[var2_3] = new String(var3_4).intern();
        }
        return 3o.e[var2_3];
    }

    public 3o() {
        boolean bl = \u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b;
        super(3o.b((int)((long)-179386677 ^ (long)179383394), (int)((long)-1411978497 ^ (long)-1411999803)) /* "Anti Fire" */, 3o.b((int)((long)-1333261038 ^ (long)1333258170), (int)((long)-367729043 ^ (long)367732422)) /* "AntiFire, Only works on 1.8 servers" */);
        this.8 = new Listener(f -> {
            boolean bl;
            block4: {
                bl = \u2006\u2002\u200a\u200a\u200a\u2004\u200e\u2002\u200b;
                if (bl) return;
                String[] stringArray = 3e.5();
                if (bl) return;
                if (bl) return;
                if (!3o.3.s.bC.d) {
                    if (bl) return;
                    if (3o.3.s.ao()) {
                        if (bl) return;
                        if (3o.3.s.bq()) {
                            if (bl) return;
                            if (bl) return;
                            int n = (int)((long)-1661067561 ^ (long)-1661067561);
                            if (bl) return;
                            do {
                                if (bl) return;
                                if (n >= (int)((long)-1515666408 ^ (long)-1515666308)) break block4;
                                if (bl) return;
                                if (bl) return;
                                3o.3.s.e.a((oj)new st((boolean)((long)2115797547 ^ (long)2115797546)));
                                if (bl) return;
                                if (bl) return;
                                ++n;
                                if (bl) return;
                            } while (stringArray == null);
                            if (bl) return;
                        }
                    }
                }
            }
            if (bl) return;
        }, new Predicate[(int)((long)1115813469 ^ (long)1115813469)]);
    }
}

