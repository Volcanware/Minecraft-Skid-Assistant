/* ==========================================================================
 * MODULE: Auto Fish
 * CATEGORY (inferred): Player
 * DESCRIPTION: Automatically fishes for you, Useful when AFKing
 * OBFUSCATED CLASS: net.impactclient.0q
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  adq
 *  aot
 *  bfw
 *  bgi
 *  blp
 *  brx
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  rn
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.1m;
import net.impactclient.1z;
import net.impactclient.2w$6X;
import net.impactclient.34J;
import net.impactclient.34R;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.34f;
import net.impactclient.3X;
import net.impactclient.3i;
import net.impactclient.3sx;
import net.impactclient.4f;
import net.impactclient.5z;
import net.impactclient.8H;
import net.impactclient.8O;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0q
extends 3X
implements 34R {
    private final 8H 5;
    private 1z 7;
    private static final String[] d;
    @EventHandler
    private final Listener<4f> 9;
    private 1K 4;
    public static final boolean \u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
    private 1m<8O> 1;
    private 1K 0;
    @EventHandler
    private final Listener<3sx> 8;
    private final 8H 8P;
    private 1P 89;
    private static final String[] e;
    private boolean 6;
    @EventHandler
    Listener<3i> 2;

    /*
     * Enabled aggressive block sorting
     */
    private static boolean 4(bgi bgi2) {
        boolean bl;
        block8: {
            block7: {
                bl = \u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
                if (bl || bl) return true;
                if (bgi2.cC().b != 0.0) break block7;
                if (bl) return true;
                if (bgi2.cC().d == 0.0) break block8;
                if (bl) return true;
            }
            if (bl) return true;
            return (int)((long)1686265483 ^ (long)1686265482) != 0;
        }
        if (!bl) return (int)((long)-734836562 ^ (long)-734836562) != 0;
        return true;
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)546428055 ^ (long)-546415020)) & (int)((long)-32410096 ^ (long)-32405009);
            if (var9_2) ** GOTO lbl-1000
            if (0q.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0q.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1018736883 ^ (long)-1018736883)] & (int)((long)223634191 ^ (long)223634416)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1029810607 ^ (long)1029810583);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1465567724 ^ (long)-1465567514);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-2056388436 ^ (long)-2056388458);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-401379831 ^ (long)-401379832);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)230885091 ^ (long)230884874);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-514458966 ^ (long)-514459123);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1686153635 ^ (long)1686153656);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)2027845047 ^ (long)2027845093);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1883574045 ^ (long)1883574238);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1576487427 ^ (long)1576487470);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-498937918 ^ (long)-498938068);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-871440356 ^ (long)-871440149);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)873699005 ^ (long)873698995);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1632011875 ^ (long)-1632012007);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)609827437 ^ (long)609827457);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)707470137 ^ (long)707470163);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-287222278 ^ (long)-287222369);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1198854200 ^ (long)-1198854174);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)812941299 ^ (long)812941070);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-371962757 ^ (long)-371962695);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)817016885 ^ (long)817016874);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1360898312 ^ (long)1360898447);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1121319764 ^ (long)1121319852);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)2111399144 ^ (long)2111398925);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1436716717 ^ (long)-1436716789);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1430672636 ^ (long)1430672542);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-574661335 ^ (long)-574661206);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1457102519 ^ (long)1457102586);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)722042001 ^ (long)722042003);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)722266832 ^ (long)722266738);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-115585779 ^ (long)-115585709);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1846639803 ^ (long)1846639645);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-2107349494 ^ (long)-2107349319);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)362402109 ^ (long)362402134);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-368305269 ^ (long)-368305339);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1647225806 ^ (long)1647225784);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1498095579 ^ (long)-1498095581);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1849640585 ^ (long)1849640615);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-101107625 ^ (long)-101107516);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1390023502 ^ (long)-1390023505);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1915625082 ^ (long)-1915625074);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1281052868 ^ (long)-1281052764);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1844643316 ^ (long)1844643195);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)709338971 ^ (long)709339014);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1882439188 ^ (long)-1882439269);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1523095218 ^ (long)1523095270);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-873202827 ^ (long)-873202811);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1856541329 ^ (long)1856541388);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-714083606 ^ (long)-714083743);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1601456748 ^ (long)1601456655);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1077639035 ^ (long)-1077639112);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-122915414 ^ (long)-122915375);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-826058701 ^ (long)-826058701);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)685082983 ^ (long)685082921);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1919851522 ^ (long)-1919851697);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-2130354331 ^ (long)-2130354299);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1702602556 ^ (long)-1702602750);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1066489154 ^ (long)-1066489184);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1248786351 ^ (long)-1248786364);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1357671790 ^ (long)1357671733);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)179056191 ^ (long)179056229);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1967428079 ^ (long)-1967427949);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-692589129 ^ (long)-692589254);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-990495795 ^ (long)-990495895);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1548444837 ^ (long)1548444758);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-134596406 ^ (long)-134596603);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)145410439 ^ (long)145410313);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-814592683 ^ (long)-814592719);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1398764888 ^ (long)1398764884);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-2018188648 ^ (long)-2018188685);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1901672115 ^ (long)1901672038);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1146386126 ^ (long)1146386018);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-755982585 ^ (long)-755982405);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1473591997 ^ (long)1473591848);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-106213199 ^ (long)-106213350);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1813178437 ^ (long)1813178387);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-466083173 ^ (long)-466083207);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1263632002 ^ (long)1263632008);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1649176762 ^ (long)-1649176697);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-192066030 ^ (long)-192065961);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1971448730 ^ (long)-1971448680);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-929015264 ^ (long)-929015150);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-201924024 ^ (long)-201923903);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1157815867 ^ (long)1157815951);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1394190337 ^ (long)-1394190403);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)2109114327 ^ (long)2109114307);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)145490663 ^ (long)145490658);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-793927909 ^ (long)-793927690);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-2102056253 ^ (long)-2102056375);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1949256177 ^ (long)1949255957);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1066269152 ^ (long)1066268976);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1663929529 ^ (long)-1663929411);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1066934658 ^ (long)-1066934696);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)429833119 ^ (long)429833024);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-327138631 ^ (long)-327138763);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)942235257 ^ (long)942235148);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-173072527 ^ (long)-173072451);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-309268459 ^ (long)-309268446);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1966465967 ^ (long)-1966465950);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-213733993 ^ (long)-213734112);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1011146652 ^ (long)1011146508);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1629627018 ^ (long)-1629627043);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1744038852 ^ (long)1744038872);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1547843293 ^ (long)-1547843250);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-2102139475 ^ (long)-2102139440);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1640485899 ^ (long)-1640485907);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)374526711 ^ (long)374526558);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1770132804 ^ (long)1770132837);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-207194068 ^ (long)-207193959);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)264000731 ^ (long)264000663);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)76411873 ^ (long)76411690);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)693974039 ^ (long)693974078);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1182737764 ^ (long)-1182737850);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1261877901 ^ (long)1261877797);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-917875162 ^ (long)-917875112);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1485210615 ^ (long)1485210495);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1585258059 ^ (long)1585258145);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)2132328795 ^ (long)2132328733);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1231617319 ^ (long)1231617371);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)2110562538 ^ (long)2110562510);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-705106166 ^ (long)-705105966);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1071995639 ^ (long)1071995571);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1625524575 ^ (long)1625524589);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1318210398 ^ (long)-1318210380);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-102259280 ^ (long)-102259310);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1330950083 ^ (long)1330949943);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1037168310 ^ (long)-1037168357);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)711178068 ^ (long)711178191);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)762464786 ^ (long)762464974);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-464123666 ^ (long)-464123746);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)790107913 ^ (long)790108053);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1748656302 ^ (long)1748656174);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1406949944 ^ (long)-1406949968);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)2144317788 ^ (long)2144317731);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)356083991 ^ (long)356084070);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1622931524 ^ (long)-1622931629);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1785463740 ^ (long)-1785463721);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1979558422 ^ (long)-1979558443);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-790754365 ^ (long)-790754321);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-338054208 ^ (long)-338054147);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)2026753074 ^ (long)2026753180);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)524666290 ^ (long)524666122);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1627718581 ^ (long)-1627718512);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-487662196 ^ (long)-487662241);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)148193217 ^ (long)148193277);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1484951489 ^ (long)1484951510);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-292135950 ^ (long)-292136088);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1571261809 ^ (long)1571261758);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1261976213 ^ (long)-1261976308);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)749352163 ^ (long)749352150);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)572904378 ^ (long)572904192);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1845228937 ^ (long)-1845228841);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)538605948 ^ (long)538605955);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1187084424 ^ (long)-1187084344);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-641571484 ^ (long)-641571532);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-185909225 ^ (long)-185909204);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)342199330 ^ (long)342199347);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1116834914 ^ (long)-1116835048);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1102447484 ^ (long)1102447517);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)443863663 ^ (long)443863722);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)340974868 ^ (long)340974861);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-417426438 ^ (long)-417426511);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-37744746 ^ (long)-37744673);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1893599841 ^ (long)1893599948);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1905354090 ^ (long)1905354063);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)113728111 ^ (long)113728021);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1557465421 ^ (long)1557465563);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-710271034 ^ (long)-710271098);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1701572805 ^ (long)1701572761);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)2060290392 ^ (long)2060290315);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)442558712 ^ (long)442558679);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)356694808 ^ (long)356694890);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1871968979 ^ (long)1871969011);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)19962066 ^ (long)19961859);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)700535333 ^ (long)700535533);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1307426028 ^ (long)-1307425816);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1084427206 ^ (long)-1084427037);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)328415614 ^ (long)328415531);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)2055089712 ^ (long)2055089833);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1759995505 ^ (long)-1759995527);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)772736216 ^ (long)772736099);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1288208697 ^ (long)-1288208655);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)928399965 ^ (long)928399923);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-784163712 ^ (long)-784163697);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1138188700 ^ (long)-1138188749);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-665522667 ^ (long)-665522670);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1662649887 ^ (long)-1662649976);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1300856481 ^ (long)1300856380);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1262433932 ^ (long)-1262434003);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1077918869 ^ (long)-1077918969);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1203253631 ^ (long)1203253705);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-122794432 ^ (long)-122794271);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1650266634 ^ (long)-1650266730);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)786966519 ^ (long)786966452);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1659623408 ^ (long)1659623299);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-174300012 ^ (long)-174300028);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1944050212 ^ (long)-1944050253);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)205790092 ^ (long)205790102);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)639526509 ^ (long)639526655);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1859907293 ^ (long)1859907130);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1248569686 ^ (long)1248569732);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-2041159287 ^ (long)-2041159312);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1783919455 ^ (long)1783919612);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1892392697 ^ (long)1892392474);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-388655243 ^ (long)-388655134);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1250201597 ^ (long)-1250201583);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1808589287 ^ (long)-1808589203);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1400528034 ^ (long)1400528041);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-879550533 ^ (long)-879550470);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1283602680 ^ (long)-1283602683);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)99305090 ^ (long)99305081);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)0x4442D222 ^ (long)1145230070);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)769209452 ^ (long)769209587);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-808228208 ^ (long)-808228145);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1608662838 ^ (long)-1608662929);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1165250973 ^ (long)-1165251061);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)983828058 ^ (long)983828078);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1429380174 ^ (long)1429380248);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1310157513 ^ (long)-1310157402);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)0x66696986 ^ (long)0x66696929);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-108590964 ^ (long)-108591035);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-207054041 ^ (long)-207053901);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-841336392 ^ (long)-841336432);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1263752251 ^ (long)-1263752324);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1173446345 ^ (long)1173446392);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-890704313 ^ (long)-890704265);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)824743634 ^ (long)824743532);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1429164055 ^ (long)-1429164082);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-2053297203 ^ (long)-2053297408);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)289863022 ^ (long)289862920);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-637033684 ^ (long)-637033710);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)656789620 ^ (long)656789749);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-369199267 ^ (long)-369199206);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1319878995 ^ (long)-1319879161);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)984025007 ^ (long)984025061);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1226828153 ^ (long)1226828032);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1539043616 ^ (long)-1539043711);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)794313198 ^ (long)794313165);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-644555708 ^ (long)-644555764);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1044942800 ^ (long)-1044942667);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-983834231 ^ (long)-983834192);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-408557611 ^ (long)-408557807);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-672730661 ^ (long)-672730853);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1276285546 ^ (long)1276285600);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-225424751 ^ (long)-225424777);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)124620459 ^ (long)124620450);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1831706261 ^ (long)1831706257);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1366516714 ^ (long)-1366516536);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1784998009 ^ (long)-1784997952);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-2050224122 ^ (long)-2050223976);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)2089951437 ^ (long)2089951346);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1888463280 ^ (long)1888463283);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)395325020 ^ (long)395325067);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1886482879 ^ (long)1886482762);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-994527949 ^ (long)-994527781);
                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-658557849 ^ (long)-658557802);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1601473883 ^ (long)-1601473958)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1337660577 ^ (long)-1337715552)) >>> (int)((long)-444160983 ^ (long)-444160991)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1392744678 ^ (long)1392744678);
            if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1307759420 ^ (long)-1307759418);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)803788790 ^ (long)803788789) | var5_6 << (int)((long)-1549197867 ^ (long)-1549197872)) ^ var3_4[var7_8]) & (int)((long)203574359 ^ (long)203574440);
                    if (0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1531256397 ^ (long)-1531256400) | var6_7 << (int)((long)-1365858639 ^ (long)-1365858636)) ^ var3_4[var7_8]) & (int)((long)-165580059 ^ (long)-165580262);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0q.e[var2_3] = new String(var3_4).intern();
        }
        return 0q.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 0() {
        boolean bl = \u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
        if (bl || bl) return;
        if (0q.3.s == null) {
            if (bl || bl) return;
            return;
        }
        if (bl) return;
        this.8P.0();
        if (bl || bl) return;
        this.5.0();
        if (bl || bl) return;
        if (0q.3.s.dD().b() instanceof blp) {
            if (bl || bl) return;
            0q.3.q.a((bfw)0q.3.s, (brx)0q.3.r, aot.a);
            if (bl) return;
            return;
        }
        if (bl) return;
        if (0q.3.s.dE().b() instanceof blp) {
            if (bl || bl) return;
            0q.3.q.a((bfw)0q.3.s, (brx)0q.3.r, aot.b);
            if (bl) return;
        }
        if (!bl) return;
    }

    public 0q() {
        boolean bl = \u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
        super(0q.b((int)((long)-67541757 ^ (long)67563473), (int)((long)-1141911772 ^ (long)1141915543)) /* "Auto Fish" */, 0q.b((int)((long)-1288748842 ^ (long)1288751617), (int)((long)-1267098737 ^ (long)1267087568)) /* "Automatically fishes for you, Useful when AFKing" */);
        Object object = 8O.c;
        34J j2 = (34f)((34f)((34f)this.2(8O.class).5(0q.b((int)((long)626461379 ^ (long)-626491385), (int)((long)1851563564 ^ (long)-1851570958)) /* "Mode" */)).7(0q.b((int)((long)377456974 ^ (long)-377486461), (int)((long)2119559735 ^ (long)-2119551087)) /* "mode" */)).1(0q.b((int)((long)-1851607411 ^ (long)1851604042), (int)((long)-1535042985 ^ (long)-1535044785)) /* "The method used to detect fish bites" */);
        ((34f)((34f)((34f)this.2(8O.class).5(0q.b((int)((long)626461379 ^ (long)-626491385), (int)((long)1851563564 ^ (long)-1851570958)) /* "Mode" */)).7(0q.b((int)((long)377456974 ^ (long)-377486461), (int)((long)2119559735 ^ (long)-2119551087)) /* "mode" */)).1(0q.b((int)((long)-1851607411 ^ (long)1851604042), (int)((long)-1535042985 ^ (long)-1535044785)) /* "The method used to detect fish bites" */)).7 = object;
        this.1 = (1m)j2.5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0q.b((int)((long)1837354289 ^ (long)-1837348871), (int)((long)-2062617305 ^ (long)-2062623800)) /* "Auto Cast" */)).7(0q.b((int)((long)103859380 ^ (long)-103854494), (int)((long)-1925008779 ^ (long)-1925002839)) /* "autocast" */)).1(0q.b((int)((long)-132412754 ^ (long)132382827), (int)((long)77003047 ^ (long)76995959)) /* "Automatically casts your fishing rod" */);
        ((34X)((34X)((34X)this.4().5(0q.b((int)((long)1837354289 ^ (long)-1837348871), (int)((long)-2062617305 ^ (long)-2062623800)) /* "Auto Cast" */)).7(0q.b((int)((long)103859380 ^ (long)-103854494), (int)((long)-1925008779 ^ (long)-1925002839)) /* "autocast" */)).1(0q.b((int)((long)-132412754 ^ (long)132382827), (int)((long)77003047 ^ (long)76995959)) /* "Automatically casts your fishing rod" */)).7 = object;
        this.89 = (1P)((34X)j2).5();
        object = (int)((long)-1999975332 ^ (long)-1999975335);
        j2 = ((34e)((34e)((34e)this.1().5(0q.b((int)((long)-1916996072 ^ (long)1917025489), (int)((long)705062632 ^ (long)705048978)) /* "Auto Cast Delay" */)).7(0q.b((int)((long)-4099454 ^ (long)4126802), (int)((long)-122920426 ^ (long)122937803)) /* "acdelay" */)).1(0q.b((int)((long)169782364 ^ (long)-169793889), (int)((long)986976644 ^ (long)987004323)) /* "Time to wait before casting if not fishing (in seconds)" */)).3((int)((long)804183796 ^ (long)804183797)).2((int)((long)1763902032 ^ (long)1763902060));
        ((34e)((34e)((34e)this.1().5(0q.b((int)((long)-1916996072 ^ (long)1917025489), (int)((long)705062632 ^ (long)705048978)) /* "Auto Cast Delay" */)).7(0q.b((int)((long)-4099454 ^ (long)4126802), (int)((long)-122920426 ^ (long)122937803)) /* "acdelay" */)).1(0q.b((int)((long)169782364 ^ (long)-169793889), (int)((long)986976644 ^ (long)987004323)) /* "Time to wait before casting if not fishing (in seconds)" */)).3((int)((long)804183796 ^ (long)804183797)).2((int)((long)1763902032 ^ (long)1763902060)).7 = object;
        this.7 = (1z)((34e)((34e)j2).3(this.89)).5();
        object = 0.25;
        j2 = ((34e)((34e)((34e)this.7().5(0q.b((int)((long)-422309382 ^ (long)422288187), (int)((long)1026676807 ^ (long)-1026685827)) /* "Catch Delay" */)).7(0q.b((int)((long)-464730381 ^ (long)464735281), (int)((long)-263048883 ^ (long)-263037831)) /* "catchdelay" */)).1(0q.b((int)((long)867581125 ^ (long)-867584497), (int)((long)736811716 ^ (long)736799441)) /* "Time to wait before reeling-in after a bite (in seconds)" */)).3(0.0).2(2.0);
        ((34e)((34e)((34e)this.7().5(0q.b((int)((long)-422309382 ^ (long)422288187), (int)((long)1026676807 ^ (long)-1026685827)) /* "Catch Delay" */)).7(0q.b((int)((long)-464730381 ^ (long)464735281), (int)((long)-263048883 ^ (long)-263037831)) /* "catchdelay" */)).1(0q.b((int)((long)867581125 ^ (long)-867584497), (int)((long)736811716 ^ (long)736799441)) /* "Time to wait before reeling-in after a bite (in seconds)" */)).3(0.0).2(2.0).7 = object;
        this.0 = (1K)((34e)j2).5();
        object = 0.5;
        j2 = ((34e)((34e)((34e)this.7().5(0q.b((int)((long)651847177 ^ (long)-651825975), (int)((long)809203144 ^ (long)809182734)) /* "Recast Delay" */)).7(0q.b((int)((long)-90914421 ^ (long)90917709), (int)((long)1559326207 ^ (long)-1559324970)) /* "recastdelay" */)).1(0q.b((int)((long)-1739851932 ^ (long)1739881903), (int)((long)-1448000890 ^ (long)-1448016775)) /* "Time to wait before casting after a catch (in seconds)" */)).3(0.1).2(2.0);
        ((34e)((34e)((34e)this.7().5(0q.b((int)((long)651847177 ^ (long)-651825975), (int)((long)809203144 ^ (long)809182734)) /* "Recast Delay" */)).7(0q.b((int)((long)-90914421 ^ (long)90917709), (int)((long)1559326207 ^ (long)-1559324970)) /* "recastdelay" */)).1(0q.b((int)((long)-1739851932 ^ (long)1739881903), (int)((long)-1448000890 ^ (long)-1448016775)) /* "Time to wait before casting after a catch (in seconds)" */)).3(0.1).2(2.0).7 = object;
        this.4 = (1K)((34e)j2).5();
        this.8P = new 8H();
        this.5 = new 8H();
        this.6 = (int)((long)-1739374726 ^ (long)-1739374726);
        this.8 = new Listener(sx -> {
            block3: {
                block2: {
                    boolean bl = \u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
                    if (bl || bl) break block2;
                    this.8();
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)1163833478 ^ (long)1163833478)]);
        this.9 = new Listener(this::8, new Predicate[(int)((long)-234794510 ^ (long)-234794510)]);
        Predicate[] predicateArray = new Predicate[(int)((long)-1689732693 ^ (long)-1689732695)];
        predicateArray[(int)((long)1715692535 ^ (long)1715692535)] = i -> {
            boolean bl = \u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
            if (bl || bl) return true;
            if (i.7 instanceof rn) {
                if (bl) return true;
                if (adq.em.equals(((rn)i.7).b())) {
                    if (bl) return true;
                    return (int)((long)-168495672 ^ (long)-168495671) != 0;
                }
            }
            if (!bl) return (int)((long)1625684882 ^ (long)1625684882) != 0;
            return true;
        };
        predicateArray[(int)((long)1303649165 ^ (long)1303649164)] = i -> {
            boolean bl = \u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
            if (bl || bl) return true;
            if (i.2 == EventState.PRE) {
                if (bl) return true;
                return (int)((long)1848711308 ^ (long)1848711309) != 0;
            }
            if (!bl) return (int)((long)1589405463 ^ (long)1589405463) != 0;
            return true;
        };
        this.2 = new Listener(i -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
                        if (bl || bl) break block2;
                        bgi bgi2 = 0q.3.s.bI;
                        if (bl || bl) break block2;
                        i = (rn)i.7;
                        if (bl || bl) break block2;
                        5z.9.info(0q.b((int)((long)-393983832 ^ (long)393986660), (int)((long)524388158 ^ (long)-524390311)) /* "Heard a splash" */);
                        if (bl || bl) break block2;
                        if (this.6) break block3;
                        if (bl) break block2;
                        if (bgi2 == null) break block3;
                        if (bl) break block2;
                        if (0q.4(bgi2)) break block3;
                        if (bl || bl) break block2;
                        5z.9.info(0q.b((int)((long)1646026881 ^ (long)-1646007724), (int)((long)-1085084244 ^ (long)1085081606)) /* "Logged a splashy bite" */);
                        if (bl || bl) break block2;
                        8O.b.2();
                        if (bl || bl) break block2;
                        if (!(bgi2.h(i.d(), i.e(), i.f()) < 4.0)) break block3;
                        if (bl || bl) break block2;
                        8O.a.2();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, predicateArray);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        block3: {
            block2: {
                boolean bl = \u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
                if (bl || bl) break block2;
                this.8P.0();
                if (bl || bl) break block2;
                this.5.0();
                if (bl || bl) break block2;
                this.6 = (int)((long)-9093248 ^ (long)-9093248);
                if (bl || bl) break block2;
                8O.0();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private /* synthetic */ void 8(4f var1_1) {
        block11: {
            block10: {
                block8: {
                    block9: {
                        block6: {
                            block7: {
                                var4_2 = 0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
                                if (var4_2 || var4_2) lbl-1000:
                                // 27 sources

                                {
                                    return;
                                }
                                var1_1 /* !! */  = 0q.3.s.bI;
                                if (var4_2 || var4_2) ** GOTO lbl-1000
                                if (!this.6) break block6;
                                if (var4_2 || var4_2) ** GOTO lbl-1000
                                if (var1_1 /* !! */  != null) break block7;
                                if (var4_2) ** GOTO lbl-1000
                                if (!this.5.8(Math.round(this.4.1 * 1000.0))) break block7;
                                if (var4_2 || var4_2) ** GOTO lbl-1000
                                5z.9.info(0q.b((int)((long)957942432 ^ (long)-957972365), (int)((long)-1540349522 ^ (long)1540340622)) /* "Casting after catch" */);
                                if (var4_2 || var4_2) ** GOTO lbl-1000
                                this.6 = (int)((long)240781107 ^ (long)240781107);
                                if (var4_2 || var4_2) ** GOTO lbl-1000
                                this.0();
                                if (var4_2) ** GOTO lbl-1000
                            }
                            if (var4_2) ** GOTO lbl-1000
                            return;
                        }
                        if (var4_2) ** GOTO lbl-1000
                        if (var1_1 /* !! */  != null) break block8;
                        if (var4_2 || var4_2) ** GOTO lbl-1000
                        if (!this.89.2) break block9;
                        if (var4_2) ** GOTO lbl-1000
                        if (!this.8P.8(this.7.4 * (int)((long)1393032639 ^ (long)1393032791))) break block9;
                        if (var4_2 || var4_2) ** GOTO lbl-1000
                        5z.9.info(0q.b((int)((long)-993021876 ^ (long)993016450), (int)((long)-1312610702 ^ (long)-1312598227)) /* "AutoCasting" */);
                        if (var4_2 || var4_2) ** GOTO lbl-1000
                        this.6 = (int)((long)-961018218 ^ (long)-961018218);
                        if (var4_2 || var4_2) ** GOTO lbl-1000
                        this.0();
                        if (var4_2) ** GOTO lbl-1000
                    }
                    if (var4_2) ** GOTO lbl-1000
                    return;
                }
                if (var4_2) ** GOTO lbl-1000
                if (8O.c.0) break block10;
                if (var4_2) ** GOTO lbl-1000
                if (0q.4((bgi)var1_1 /* !! */ )) break block10;
                if (var4_2 || var4_2) ** GOTO lbl-1000
                if (!(var1_1 /* !! */ .cE() % 1.0 < 0.5)) break block10;
                if (var4_2 || var4_2) ** GOTO lbl-1000
                5z.9.info(0q.b((int)((long)-1308612083 ^ (long)1308598466), (int)((long)-2070890862 ^ (long)-2070880243)) /* "Logged a bouncy bite" */);
                if (var4_2 || var4_2) ** GOTO lbl-1000
                8O.c.2();
                if (var4_2) ** GOTO lbl-1000
            }
            if (var4_2) ** GOTO lbl-1000
            if (0q.4((bgi)var1_1 /* !! */ )) break block11;
            if (var4_2) ** GOTO lbl-1000
            var2_3 = Math.round(this.0.1 * 1000.0);
            var1_1 /* !! */  = (8O)this.1.8();
            if (!var1_1 /* !! */ .0) ** GOTO lbl-1000
            if (var4_2) ** GOTO lbl-1000
            if (var1_1 /* !! */ .7.8(var2_3)) {
                if (!var4_2) ** break;
                ** continue;
                v0 = (int)((long)-1956745408 ^ (long)-1956745407);
                if (0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) {
                    throw null;
                }
            } else lbl-1000:
            // 2 sources

            {
                v0 = (int)((long)1086920023 ^ (long)1086920023);
            }
            if (v0 != 0) {
                5z.9.info(0q.b((int)((long)299094079 ^ (long)-299083026), (int)((long)858388500 ^ (long)-858386653)) /* "Catching a bite" */);
                8O.0();
                this.6 = (int)((long)382484083 ^ (long)382484082);
                this.0();
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-268684044 ^ (long)-268684061)];
            if (var7) break block23;
            var3_2 = (int)((long)916781120 ^ (long)916781120);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ucd3d\ue50a\uf60a\ufeb1\ucd64\ue57f\uf6f9\ufeda\ucd2d\ue589\uf668\ufee2\ucdd7\ue573\uf6b8\ufeee\ucd6c\ue5b1\uf66c\ufebb\ucdda\ue5b8\uf603\ufedc\ucdea\ue580\uf603\ufe41\ucd42\ue5c7\uf632\ufeed\ucdc8\ue59e\uf685\ufea0\ucd1a\ue55a\uf652\ufed5\ucdff\ue52e\uf67f\ufeae\ucd7f\ue522\uf68d\ufe05\ucd0d\ue554\uf623\ufe19\ucd7c\ue57c\uf633\ufe52\ucdcb\ue53d\uf61c\ufe58\ucdd4\ue594\uf6a4\ufef9\ucddb\ue530\uf627\ufed3\ucdf4\ue5b2\uf68d\ufe2e\ucd20\ue553\uf646\ufe02\ucdbd\ue56c\uf620\ufe61\ucd04\ue5c0\uf615\ufe8e\ucd25\ue55b\uf619\ufee2\ucd5e\ue540\uf655\ufe7c\ucd05\ue5e7\uf605\ufe68\ucdc1\ue5b8\uf6b2\ufe59\ucd24\ue5bd\uf61b\ufec0\ucd8a\ue511\uf62b\ufe03\ucd24\ue59f\uf658\ufe84\ucdb7\ue586\uf67e\ufebb\ucd8c\ue5d7\uf670\ufe65\ucd17\ue52d\uf6c1\ufe73\ucdb0\ue5c0\uf609\ufe7e\ucdff\ue53b\uf6e9\ufeca\ucd6b\ue5aa\uf629\ufefe\ucd7a\ue5f6\uf6f9\ufe97\ucdd0\ue516\uf601\ufe2d\ucd6a\ue5bd\uf6d3\ufed1\ucd9e\ue50e\uf6e8\ufe73\ucdf9\ue502\uf6c0\ufe9a\ucdba\ue5b8\uf653\ufe93\ucd0e\ue5a1\uf689\ufedf\ucd1c\ue5b4\uf6df\ufe4a\ucddf\ue5ef\uf6ab\ufe04\ucda8\ue58c\uf691\ufe08\ucdaa\ue534\uf6a1\ufef8\ucd69\ue54c\uf61a\ufec1\ucd1c\ue51c\uf69f\ufe89\ucdf0\ue5cd\uf6c7\ufe84\ucd60\ue5d4\uf633\ufe6f\ucd03\ue526\uf60c\ufe90\ucda7\ue57a\uf695\ufe37\ucd37\ue537\uf6c1\ufe43\ucd69\ue5bf\uf690\ufef2\ucdb7\ue5f0\uf604\ufe7c\ucdd7\ue565\uf6fd\ufe4a\ucd27\ue586\uf6cc\ufed3\ucd4b\ue5bd\uf600\ufe06\ucd9a\ue59f\uf66f\ufe5f\ucd8b\ue527\uf689\ufee5\ucd35\ue508\uf658\ufebf\ucd65\ue562\uf64a\ufe60\ucdff\ue55c\uf62e\ufe3c\ucdcb\ue531\uf660\ufe6c\ucd8d\ue568\uf609\ufe04\ucd03\ue568\uf6e5\ufea3\ucd02\ue546\uf6dd\ufead\ucd26\ue58c\uf625\ufebf\ucd1d\ue581\uf6e7\ufe98\ucdce\ue511\uf614\ufe8d\ucd78\ue511\uf63f\ufeaa\ucd06\ue522\uf63f\ufed8\ucd61\ue58b\uf6c2\ufedf\ucdc1\ue5ca\uf664\ufe55\ucde2\ue5dc\uf623\ufeff\ucd4f\ue575\uf660\ufe9e\ucd73\ue521\uf635\ufed5\ucd46\ue5b0\uf68f\ufe27\ucda4\ue5f6\uf625\ufe40\ucd94\ue582\uf61b\ufe60\ucd1c\ue5fe\uf6d8\ufe2e\ucde0\ue5ae\uf653\ufe85\ucd71\ue5d1\uf6bc\ufe01\ucdde\ue589\uf6ea\ufeab\ucdc3\ue56d\uf6fe\ufe98\ucd17\ue5b0\uf692\ufea6\ucdcd\ue53b\uf66d\ufe14\ucd6d\ue582\uf612\ufe22\ucde7\ue5f7\uf6ac\ufe98\ucd48\ue534\uf602\ufe34\ucd39\ue5d5\uf622\ufedc\ucde6\ue52c\uf65a\ufe46\ucde9\ue5f6\uf63a\ufe28\ucdce\ue5c0\uf6c0\ufe1b\ucdc0\ue523\uf64e\ufe99\ucd4c\ue5be\uf6fb\ufed2\ucda1\ue553\uf6fa\ufeda\ucd98\ue51b\uf6e6\ufe58\ucd43\ue5e3\uf60d\ufe83\ucdf6\ue539\uf607\ufe0f\ucd20\ue5e1\uf6d8\ufe69\ucdab\ue55a\uf67d\ufe57\ucda3\ue50e\uf635\ufe3e\ucdf1\ue555\uf60b\ufe66\ucd05\ue5b1\uf699\ufef3\ucdc0\ue593\uf63a\ufe5f\ucdb7\ue520\uf6c1\ufebf\ucd79\ue5ab\uf689\ufe68\ucdb5\ue5b2\uf6b5\ufe33\ucde4\ue571\uf616\ufee5\ucdbc\ue50e\uf6c9\ufe0a\ucd1f\ue537\uf6d0\ufe63\ucd1e\ue5f4\uf6bd\ufe19\ucda3\ue5d2\uf61b\ufe70\ucd3f\ue5c4\uf6d1\ufe69\ucd54\ue57b\uf668\ufee9\ucd52\ue5b2\uf6c8\ufe7f\ucd05\ue5ee\uf6d1\ufecb\ucd8f\ue527\uf610\ufe4e\ucdfd\ue59a\uf6f5\ufee1", -102634599);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)252078364 ^ (long)252078379);
            if (var7) break block23;
            var0_6 = (int)((long)-954219378 ^ (long)954219377);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-25663131 ^ (long)-25663148);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1196066766 ^ (long)-1196066767);
                    if (0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u41ea\u6990\u7a67\u726a\u41ad\u6947\u7aea\u7223\u41a8\u69cf\u7abe\u72b4\u41d1\u69ea\u7ab5\u727b\u41e2\u69db\u7a61\u72e3\u4185\u698a\u7a01\u7286\u41be\u691f\u7ac3\u7259\u4181\u69a0", -173119536);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)371467795 ^ (long)371467803);
                            var0_6 = (int)((long)-1050198630 ^ (long)1050198629);
                            while (true) {
                                v0 = (int)((long)-2076013777 ^ (long)-2076013788);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1925495537 ^ (long)1925495537);
                                if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) ** continue;
                                throw null;
                            }
                            0q.d = var5_1;
                            0q.e = new String[(int)((long)-1639464407 ^ (long)-1639464386)];
                            if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-462821686 ^ (long)-462821686);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)2121928521 ^ (long)2121928520)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1478475758 ^ (long)1478475753)) {
                                case 0: {
                                    v15 = (int)((long)1465606418 ^ (long)1465606526);
                                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1599875006 ^ (long)-1599875035);
                                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1604779385 ^ (long)1604779343);
                                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1518832523 ^ (long)1518832639);
                                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-389607548 ^ (long)-389607455);
                                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1779367970 ^ (long)-1779368056);
                                    if (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)597908913 ^ (long)597908870);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0q.\u2009\u2009\u2000\u2007\u200f\u2006\u2001\u200c);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

