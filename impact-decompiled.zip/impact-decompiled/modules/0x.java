/* ==========================================================================
 * MODULE: Anti Vanish
 * CATEGORY (inferred): Misc
 * DESCRIPTION: Detects when staff members go into vanish
 * OBFUSCATED CLASS: net.impactclient.0x
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dwu
 *  k
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  nr
 *  qi
 */
package net.impactclient;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.2w$6X;
import net.impactclient.34s;
import net.impactclient.3X;
import net.impactclient.3i;
import net.impactclient.3s0;
import net.impactclient.3s6;
import net.impactclient.3sC;
import net.impactclient.3sh;
import net.impactclient.3sx;
import net.impactclient.5p;
import net.impactclient.9g;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0x
extends 3X
implements 3s0 {
    private final List<9g> 0;
    private final Map<UUID, String> 8;
    private static final String[] e;
    @EventHandler
    private final Listener<3sx> 2;
    public static final boolean \u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
    @EventHandler
    private final Listener<3i> 7;
    @EventHandler
    private final Listener<3sh> 1;
    private static final String[] d;

    private static /* synthetic */ boolean 2(UUID uUID, 9g g2) {
        boolean bl = \u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
        if (bl || bl) {
            return true;
        }
        return g2.5.equals(uUID);
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1880526347 ^ (long)1880536077)) & (int)((long)-1066519945 ^ (long)-1066480248);
            if (var9_2) ** GOTO lbl-1000
            if (0x.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0x.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1798390838 ^ (long)1798390838)] & (int)((long)-1571115062 ^ (long)-1571115211)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1682721114 ^ (long)-1682721101);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1774979696 ^ (long)1774979708);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1994094515 ^ (long)-1994094431);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1510584971 ^ (long)-1510584851);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1440494927 ^ (long)-1440494941);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1088166832 ^ (long)-1088166910);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-329784372 ^ (long)-329784431);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1703640231 ^ (long)1703640065);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-915159179 ^ (long)-915159292);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-187897063 ^ (long)-187896915);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1716093317 ^ (long)1716093277);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1429903908 ^ (long)1429903876);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-331977769 ^ (long)-331977875);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-2082540702 ^ (long)-2082540556);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)2034155386 ^ (long)2034155364);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-50933106 ^ (long)-50933243);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)108842739 ^ (long)108842647);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1630579077 ^ (long)1630578980);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)163190254 ^ (long)163190257);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-9727708 ^ (long)-9727599);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)233908390 ^ (long)233908289);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)927974886 ^ (long)927974802);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1318618624 ^ (long)-1318618387);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1698745273 ^ (long)1698745088);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-302390207 ^ (long)-302390196);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1321280221 ^ (long)-1321280247);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1739029738 ^ (long)-1739029517);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1924082774 ^ (long)-1924082712);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-588412282 ^ (long)-588412291);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)890790865 ^ (long)890790829);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-85303400 ^ (long)-85303474);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1314391310 ^ (long)-1314391309);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1130011218 ^ (long)1130011222);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1959208457 ^ (long)-1959208488);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-757241672 ^ (long)-757241692);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-691580502 ^ (long)-691580419);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)858288136 ^ (long)858288288);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-560824875 ^ (long)-560824859);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1634206226 ^ (long)1634206237);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-634309652 ^ (long)-634309728);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-220973329 ^ (long)-220973434);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)335761494 ^ (long)335761467);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-814039300 ^ (long)-814039428);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1116914196 ^ (long)-1116914187);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)851793387 ^ (long)851793263);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1167230976 ^ (long)1167231027);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-496734856 ^ (long)-496734880);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1050892089 ^ (long)-1050892283);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1664657154 ^ (long)-1664657338);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1086240650 ^ (long)-1086240683);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1490437183 ^ (long)1490437358);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1399102150 ^ (long)-1399102069);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-763191862 ^ (long)-763191916);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)372872432 ^ (long)372872335);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1264157117 ^ (long)1264157161);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)590499161 ^ (long)590499138);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-217878787 ^ (long)-217878978);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)5570636 ^ (long)5570676);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1497944917 ^ (long)-1497944915);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-2127127361 ^ (long)-2127127456);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)2064746850 ^ (long)2064746936);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)21386298 ^ (long)21386286);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)321475185 ^ (long)321475326);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1956374399 ^ (long)1956374427);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1129175928 ^ (long)1129176042);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)925966418 ^ (long)925966377);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)778708805 ^ (long)778708752);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-867856682 ^ (long)-867856670);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-130779732 ^ (long)-130779822);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1434607921 ^ (long)-1434607956);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)68937620 ^ (long)68937537);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)718236128 ^ (long)718235981);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-2015640547 ^ (long)-2015640457);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-721295424 ^ (long)-721295586);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)749301360 ^ (long)749301402);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1257690916 ^ (long)-1257690888);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1742035795 ^ (long)-1742035765);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-950971157 ^ (long)-950971305);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1060962717 ^ (long)-1060962649);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1436046378 ^ (long)1436046537);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-464378950 ^ (long)-464379097);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-5686031 ^ (long)-5686184);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1450790889 ^ (long)1450790793);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1403266131 ^ (long)-1403266224);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)2049826829 ^ (long)2049826920);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)136118492 ^ (long)136118379);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-145736333 ^ (long)-145736435);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1003982145 ^ (long)-1003982105);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1603924385 ^ (long)-1603924385);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1216613288 ^ (long)-1216613154);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1339246752 ^ (long)1339246819);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-2089694403 ^ (long)-2089694339);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1007401213 ^ (long)-1007401140);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1474432518 ^ (long)-1474432531);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)880190750 ^ (long)880190910);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1127622430 ^ (long)1127622472);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1069426347 ^ (long)-1069426321);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)877266542 ^ (long)877266527);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)2061116991 ^ (long)2061117168);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)473718044 ^ (long)473718231);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1700729087 ^ (long)-1700729018);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-306561405 ^ (long)-306561383);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-744120528 ^ (long)-744120451);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1015932859 ^ (long)-1015932795);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1140806107 ^ (long)1140805974);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1760363886 ^ (long)1760363865);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-512006279 ^ (long)-512006396);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-193066077 ^ (long)-193066118);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1656699747 ^ (long)1656699874);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)2108958481 ^ (long)2108958510);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1074684840 ^ (long)-1074684797);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1537621107 ^ (long)-1537621225);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)545728058 ^ (long)545728132);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)2129175790 ^ (long)2129175664);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1803287443 ^ (long)-1803287549);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1455940273 ^ (long)1455940292);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-431819373 ^ (long)-431819495);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-973853760 ^ (long)-973853951);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1324189631 ^ (long)1324189637);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1699326061 ^ (long)-1699326162);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)418085972 ^ (long)418086066);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1546303641 ^ (long)-1546303601);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1009692598 ^ (long)1009692634);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)417703903 ^ (long)417703724);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1196275600 ^ (long)1196275494);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)591072346 ^ (long)591072265);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1292900105 ^ (long)1292900194);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1782019933 ^ (long)1782019991);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1956458247 ^ (long)-1956458430);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1566692671 ^ (long)1566692718);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1076233977 ^ (long)-1076233891);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)62472383 ^ (long)62472446);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1588785800 ^ (long)1588785749);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1256587396 ^ (long)1256587500);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)984805408 ^ (long)984805557);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)517561948 ^ (long)517562059);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1394063276 ^ (long)-1394063199);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-413882632 ^ (long)-413882752);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1049702451 ^ (long)1049702550);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)902813700 ^ (long)902813910);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)441955975 ^ (long)441955981);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-622485162 ^ (long)-622485184);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)2086807697 ^ (long)2086807655);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)355945649 ^ (long)355945581);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1200413516 ^ (long)1200413641);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-857259197 ^ (long)-857259053);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-926089449 ^ (long)-926089401);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1386322798 ^ (long)-1386322834);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)682245474 ^ (long)682245553);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1322472567 ^ (long)1322472464);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-852710034 ^ (long)-852710002);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1220734523 ^ (long)-1220734662);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-830332088 ^ (long)-830331957);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1260209393 ^ (long)1260209326);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)546866880 ^ (long)546866887);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)705004856 ^ (long)705004961);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)738556899 ^ (long)738556877);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1847191420 ^ (long)1847191383);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)2012503143 ^ (long)2012503180);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1722190251 ^ (long)-1722190292);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-924955337 ^ (long)-924955391);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)398517473 ^ (long)398517357);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-299733526 ^ (long)-299733662);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-971121997 ^ (long)-971121925);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-645348342 ^ (long)-645348297);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-308875882 ^ (long)-308875788);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-661955686 ^ (long)-661955834);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)118775354 ^ (long)118775432);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)216169918 ^ (long)216169834);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1126546389 ^ (long)-1126546252);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1188683153 ^ (long)-1188683044);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1501114243 ^ (long)1501114276);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1437434925 ^ (long)1437435018);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)760509790 ^ (long)760509745);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1227577424 ^ (long)1227577540);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-2101062359 ^ (long)-2101062309);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1508038081 ^ (long)1508038045);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1563646253 ^ (long)1563646216);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)248671572 ^ (long)248671578);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1016893621 ^ (long)1016893490);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)2113275743 ^ (long)2113275889);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1277304636 ^ (long)1277304821);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1958213140 ^ (long)-1958213206);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1708318195 ^ (long)1708318171);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1907124225 ^ (long)1907124296);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1462502054 ^ (long)1462502125);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)458481663 ^ (long)458481499);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)799223394 ^ (long)799223474);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-469721917 ^ (long)-469721904);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1616081036 ^ (long)-1616080989);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-649748489 ^ (long)-649748610);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1527740032 ^ (long)-1527740141);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)98630595 ^ (long)98630445);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1257892163 ^ (long)-1257892289);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1490458231 ^ (long)-1490458344);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)82656440 ^ (long)82656498);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)315795282 ^ (long)315795310);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1879558067 ^ (long)1879557913);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1351235420 ^ (long)-1351235448);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)39045658 ^ (long)39045642);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1905874848 ^ (long)1905874899);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1334932002 ^ (long)1334932178);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1214542202 ^ (long)-1214542282);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1270985778 ^ (long)1270985783);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1261281563 ^ (long)1261281630);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-991715189 ^ (long)-991715200);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)887119043 ^ (long)887119074);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1744283276 ^ (long)1744283210);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-715310430 ^ (long)-715310491);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-623481215 ^ (long)-623481176);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-700442197 ^ (long)-700442266);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1947213444 ^ (long)-1947213353);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-2109706260 ^ (long)-2109706418);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1950923797 ^ (long)1950923931);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)2070639404 ^ (long)2070639406);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1734094509 ^ (long)-1734094421);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1261556826 ^ (long)1261556818);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-12495859 ^ (long)-12495694);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1279401118 ^ (long)-1279401198);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1401575002 ^ (long)1401575036);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1884297202 ^ (long)1884297164);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1238130217 ^ (long)-1238130414);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1258780054 ^ (long)-1258779919);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1692507052 ^ (long)-1692506976);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1543747520 ^ (long)1543747336);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-597899797 ^ (long)-597899822);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-445579614 ^ (long)-445579563);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-2070733664 ^ (long)-2070733647);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1038031453 ^ (long)-1038031535);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1410252548 ^ (long)-1410252545);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-2114486240 ^ (long)-2114486149);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1630321695 ^ (long)1630321904);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)783467030 ^ (long)783467233);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)859914872 ^ (long)859914905);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1846054087 ^ (long)-1846053925);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)22503170 ^ (long)22503284);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)2039524886 ^ (long)2039525095);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1998853869 ^ (long)-1998853855);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)690063560 ^ (long)690063364);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1516439284 ^ (long)-1516439051);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)824737263 ^ (long)824737045);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)749929616 ^ (long)749929650);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1516877856 ^ (long)-1516877916);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-261934933 ^ (long)-261934862);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-595957170 ^ (long)-595957177);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)544207130 ^ (long)544207316);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-610543429 ^ (long)-610543593);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)216065261 ^ (long)216065090);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)176965610 ^ (long)176965575);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1601302509 ^ (long)1601302350);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)692837460 ^ (long)692837449);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-420488976 ^ (long)-420489191);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)506491392 ^ (long)506491489);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-723063894 ^ (long)-723063919);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)976384244 ^ (long)976384186);
                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1444805942 ^ (long)1444805891);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1171461059 ^ (long)-1171460926)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1782378135 ^ (long)1782321512)) >>> (int)((long)-91383309 ^ (long)-91383301)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)544585821 ^ (long)544585821);
            if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-2109580461 ^ (long)-2109580463);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1265634022 ^ (long)-1265634023) | var5_6 << (int)((long)1130006067 ^ (long)1130006070)) ^ var3_4[var7_8]) & (int)((long)1413267615 ^ (long)1413267552);
                    if (0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)242731103 ^ (long)242731100) | var6_7 << (int)((long)1390653238 ^ (long)1390653235)) ^ var3_4[var7_8]) & (int)((long)-468382448 ^ (long)-468382225);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0x.e[var2_3] = new String(var3_4).intern();
        }
        return 0x.e[var2_3];
    }

    public 0x() {
        boolean bl = \u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
        super(0x.b((int)((long)-115486503 ^ (long)115479842), (int)((long)1606846209 ^ (long)1606874254)) /* "Anti Vanish" */, 0x.b((int)((long)73114064 ^ (long)-73112535), (int)((long)-191757104 ^ (long)191754895)) /* "Detects when staff members go into vanish" */);
        this.8 = new ConcurrentHashMap<UUID, String>();
        this.0 = new CopyOnWriteArrayList<9g>();
        Predicate[] predicateArray = new Predicate[(int)((long)1867459646 ^ (long)1867459647)];
        Class[] classArray = new Class[(int)((long)280086041 ^ (long)280086040)];
        classArray[(int)((long)-385185250 ^ (long)-385185250)] = qi.class;
        predicateArray[(int)((long)-1876327387 ^ (long)-1876327387)] = new 34s(classArray);
        this.7 = new Listener(i -> {
            boolean bl = \u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
            if (bl || bl) return;
            if (i.2 != EventState.POST) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            i = (qi)i.7;
            if (bl || bl) return;
            switch (3s6.7[i.c().ordinal()]) {
                case 1: {
                    if (bl) return;
                    i.b().forEach(b2 -> {
                        block3: {
                            block2: {
                                boolean bl = \u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
                                if (bl || bl) break block2;
                                this.8.putIfAbsent(b2.a().getId(), b2.a().getName());
                                if (!bl) break block3;
                            }
                            return;
                        }
                    });
                    if (bl || bl) return;
                    return;
                }
                case 2: {
                    if (bl) return;
                    i.b().forEach(object -> {
                        block8: {
                            String string;
                            String string2;
                            block9: {
                                block7: {
                                    boolean bl = \u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
                                    if (bl || bl) break block7;
                                    object = object.a().getId();
                                    if (bl || bl) break block7;
                                    if (3.w().a((UUID)object) != null) break block8;
                                    if (bl) break block7;
                                    if (!this.0.stream().noneMatch(arg_0 -> 0x.2((UUID)object, arg_0))) break block8;
                                    if (bl || bl) break block7;
                                    string2 = this.8.get(object);
                                    if (!bl && !bl) break block9;
                                }
                                return;
                            }
                            if (string2 == null) {
                                string = ((UUID)object).toString();
                                if (\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) {
                                    throw null;
                                }
                            } else {
                                string = string2;
                            }
                            object = new 9g(this, (UUID)object, string);
                            this.0.add((9g)object);
                            k[] kArray = new k[(int)((long)922009154 ^ (long)922009155)];
                            kArray[(int)((long)719078308 ^ (long)719078308)] = k.j;
                            object = kArray;
                            3sC sC = new 3sC().2(((9g)object).6, null, (k[])object);
                            k[] kArray2 = new k[(int)((long)1031563144 ^ (long)1031563145)];
                            kArray2[(int)((long)-447089079 ^ (long)-447089079)] = k.h;
                            object = kArray2;
                            5p.9((nr)sC.2((String)0x.b((int)((int)((long)-1444113649 ^ (long)1444108021)), (int)((int)((long)-13583405 ^ (long)-13595155))), null, (k[])object).7);
                        }
                    });
                    if (bl) return;
                    break;
                }
            }
            if (!bl) return;
        }, predicateArray);
        this.1 = new Listener(sh2 -> {
            dwu dwu2;
            boolean bl;
            block8: {
                block7: {
                    bl = \u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
                    if (bl || bl) return;
                    dwu2 = 3.w();
                    if (dwu2 == null) break block7;
                    if (bl) return;
                    if (sh2.5 == EventState.PRE) break block8;
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            this.0.forEach(g2 -> {
                block4: {
                    block2: {
                        boolean bl;
                        block3: {
                            bl = \u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
                            if (bl || bl) break block2;
                            if (dwu2.a(g2.5) == null) break block3;
                            if (bl || bl) break block2;
                            this.0.remove(g2);
                            if (bl || bl) break block2;
                            k[] kArray2 = new k[(int)((long)-1454791931 ^ (long)-1454791932)];
                            kArray2[(int)((long)-341491790 ^ (long)-341491790)] = k.j;
                            dwu2 = kArray2;
                            3sC sC = new 3sC().2(g2.6, null, (k)dwu2);
                            k[] kArray3 = new k[(int)((long)1139631045 ^ (long)1139631044)];
                            kArray3[(int)((long)850416203 ^ (long)850416203)] = k.h;
                            dwu2 = kArray3;
                            5p.9((nr)sC.2((String)0x.b((int)((int)((long)1049871090 ^ (long)-1049884918)), (int)((int)((long)-1650523589 ^ (long)-1650514501))), null, (k[])kArray).7);
                            if (bl) break block2;
                        }
                        if (!bl) break block4;
                    }
                    return;
                }
            });
            if (!bl && !bl) return;
        }, new Predicate[(int)((long)476476896 ^ (long)476476896)]);
        this.2 = new Listener(sx -> {
            block3: {
                block2: {
                    boolean bl = \u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
                    if (bl || bl) break block2;
                    this.0.clear();
                    if (bl || bl) break block2;
                    this.8.clear();
                    if (!bl && !bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)1421987743 ^ (long)1421987743)]);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-754588055 ^ (long)-754588051)];
            if (var7) break block23;
            var3_2 = (int)((long)-493443621 ^ (long)-493443621);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ud444\ufc3c\uefef\ue7cc\ud428\ufc4d\uef8c\ue726\ud476\ufccf\ueffa\ue726\ud454\ufc57\uefba\ue79e\ud42e\ufc37\uefc1\ue7fb\ud427\ufca0\uef31\ue7c4\ud445\ufc38\uef08\ue7ed\ud494\ufc84\uefb7\ue71f\ud495\ufc77\uef6a\ue798\ud40a\ufcc6\uefd2\ue779\ud4cd\ufccf\uef54\ue724\ud486\ufcab\uef6e\ue703\ud4ff\ufc09\uef7c\ue7e6\ud424\ufcf1\uef4a\ue70a\ud4a8\ufc53\ueffb\ue7f7\ud44f\ufc8c\uef98\ue796\ud4f2\ufc29\uefe2\ue71e\ud413\ufcf8\uef4a", -2015104508);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1349157289 ^ (long)-1349157302);
            if (var7) break block23;
            var0_6 = (int)((long)1898190114 ^ (long)-1898190115);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-632874021 ^ (long)-632874014);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-555524597 ^ (long)555524596);
                    if (0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u2648\u0e81\u1dd0\u15c5\u2671\u0ed2\u1d19\u156b\u267a\u0ed8\u1dc3\u1561\u260b\u0e36\u1da0\u15ba\u2634\u0e07\u1d5d\u1545\u2602\u0e24\u1d0f\u159c\u2690\u0e21\u1d61\u15e8\u264d\u0ef7\u1d28\u15d7\u26d9\u0ef8\u1d02\u1539\u26da\u0ec1\u1d5b", -1460731870);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)71149416 ^ (long)71149427);
                            var0_6 = (int)((long)-1456522205 ^ (long)1456522204);
                            while (true) {
                                v0 = (int)((long)-495013330 ^ (long)-495013332);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1050927291 ^ (long)1050927291);
                                if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) ** continue;
                                throw null;
                            }
                            0x.d = var5_1;
                            0x.e = new String[(int)((long)1220614550 ^ (long)1220614546)];
                            if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-730341093 ^ (long)-730341093);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-412692865 ^ (long)-412692866)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-7037405 ^ (long)-7037404)) {
                                case 0: {
                                    v15 = (int)((long)220394511 ^ (long)220394603);
                                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-525253332 ^ (long)-525253348);
                                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-2074674222 ^ (long)-2074674211);
                                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-284591393 ^ (long)-284591382);
                                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1503967141 ^ (long)-1503967142);
                                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)447218499 ^ (long)447218496);
                                    if (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1142079754 ^ (long)1142079817);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0x.\u2002\u200c\u200e\u200d\u2002\u200f\u200e\u2000\u2008);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }
}

