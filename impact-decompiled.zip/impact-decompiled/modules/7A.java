/* ==========================================================================
 * MODULE: Nuker
 * CATEGORY (inferred): Misc
 * DESCRIPTION: Destroys blocks around you
 * OBFUSCATED CLASS: net.impactclient.7A
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  buo
 *  bup
 *  dci
 *  dcj
 *  dcl$a
 *  fx
 *  gc
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  oj
 *  pw.knx.feather.structures.Color
 *  sz
 *  sz$a
 */
package net.impactclient;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.0o;
import net.impactclient.11;
import net.impactclient.1P;
import net.impactclient.1R;
import net.impactclient.1z;
import net.impactclient.2R;
import net.impactclient.2c;
import net.impactclient.2k;
import net.impactclient.2n;
import net.impactclient.2o;
import net.impactclient.2w$6X;
import net.impactclient.34E;
import net.impactclient.34H;
import net.impactclient.34J;
import net.impactclient.34L;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.4f;
import net.impactclient.5L;
import net.impactclient.5z;
import pw.knx.feather.structures.Color;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7A
extends 3X
implements 5L {
    public static final boolean \u2002\u2008\u2002\u200c\u200c\u2000\u2004;
    private List<fx> 8;
    private 1P 1;
    @EventHandler
    private final Listener<2o> 4;
    private 11 9D;
    private static final String[] e;
    private 1R 0;
    private 1P 5;
    private static final String[] d;
    @EventHandler
    private final Listener<4f> 6;
    private 1P 9p;
    private 1z 7;
    @EventHandler
    private final Listener<2k> 9f;
    private static final dci 9;
    private 1P 9g;
    private 11 2;

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)-1321331674 ^ (long)-1321331705)];
            if (var7) break block25;
            var3_2 = (int)((long)-109919143 ^ (long)-109919143);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\u6aeb\u43b3\u5076\u585d\u6a58\u43ae\u5089\u58e9\u6a1c\u4379\u506c\u5883\u6a8d\u431e\u50c7\u5805\u6a1e\u436b\u5045\u5898\u6a98\u437e\u50a9\u58b7\u6ab5\u434c\u50e5\u5898\u6ad5\u43bc\u50ef\u5857\u6aee\u4399\u5011\u581a\u6a2c\u4366\u5033\u589f\u6a1d\u4359\u50a6\u58ad\u6a25\u43e2\u50c3\u58ca\u6a70\u4391\u5002\u58fc\u6a8f\u4373\u50b1\u5824\u6a66\u4398\u506e\u587f\u6a23\u43c3\u5032\u583e\u6a18\u438a\u505e\u588c\u6a03\u4316\u50b7\u58ec\u6a3c\u4364\u50ae\u5825\u6a58\u4325\u5073\u5874\u6a31\u43c2\u502f\u5816\u6a40\u433c\u50f7\u58a4\u6a90\u4318\u50ae\u5886\u6a00\u4397\u508d\u5824\u6a9c\u43c0\u5031\u5897\u6ac4\u43d7\u502a\u58bb\u6ae7\u4385\u508b\u5873\u6a62\u43f4\u5015\u5836\u6afd\u4383\u50a1\u5851\u6a63\u436a\u5027\u5846\u6ae1\u4321\u5090\u5819\u6acc\u4371\u502b\u5809\u6aeb\u4382\u5008\u5862\u6a8b\u43c2\u503c\u587e\u6adf\u4321\u509f\u5858\u6a59\u4343\u5028\u58e5\u6a85\u43a2\u50c7\u5862\u6a0e\u438c\u5070\u5875\u6a1d\u4315\u5092\u58ba\u6ab7\u4319\u502e\u58c5\u6a18\u4324\u50d1\u5855\u6a33\u43b9\u50ca\u58e7\u6a98\u4396\u505e\u58bb\u6ae6\u4333\u507e\u58e9\u6a2d\u4318\u5017\u5842\u6a40\u43ba\u507f\u5894\u6aeb\u4309\u50d1\u58e9\u6a7a\u4359\u50aa\u5807\u6ae8\u4363\u50e2\u58a6\u6a4c\u438e\u50cc\u583b\u6ae9\u4352\u504a\u58c2\u6a99\u43d3\u50d2\u5856\u6afd\u439b\u507f\u585e\u6aad\u434d\u5088\u58dc\u6aa5\u43d9\u5068\u58fd\u6a1c\u432a\u50b1\u58ce\u6a62\u4333\u503c\u58f0\u6a31\u437e\u507f\u5849\u6a1e\u437e\u50a4\u5824\u6af6\u4318\u50f1\u5828\u6aa8\u43e5\u50ca\u5890\u6ae4\u4391\u5063\u58f8\u6a72\u4311\u50e2\u5850\u6a8d\u43ab\u50f8\u58b6\u6a3b\u4340\u50ee\u58c8\u6a5d\u4344\u50e4\u584e\u6a8d\u43c3\u50bf\u586a\u6a5f\u43a3\u50ba\u58d4\u6a63\u432a\u5030\u5895\u6a4f\u43f3\u5029\u5898\u6a30\u433d\u5077\u5847\u6afe\u43d2\u50d1\u58cb\u6a41\u4353\u50eb\u5843\u6aa3\u4343\u5006\u58f3\u6a1d\u437e\u5060\u58d0\u6a70\u430a\u5033\u58cf\u6aa8\u434e\u504f\u58c9\u6a2f\u4367\u5093\u5888\u6a2e\u4382\u50fb\u5833\u6a19\u4384\u50e7\u5845\u6ad5\u43e1\u50d0\u58da\u6a32\u43f4\u508f\u58e3\u6a80\u43f6\u5050\u5868\u6a6b\u43fb\u50a9\u5893\u6ae3\u432a\u5095\u585f\u6a14\u4365\u50eb\u584f\u6a95\u43bb\u50d5\u584a\u6a24\u43fa\u50c7\u5818\u6a1d\u432e\u50b2\u586e\u6acc\u4333\u5093\u58cb\u6ab6\u43ec\u50de\u589d\u6a00\u4325\u5015\u58ca\u6a07\u4381\u505f\u5881\u6a94\u430e\u50b1\u5888\u6a45\u4329\u500a\u580b\u6a89\u434d\u508b\u58a3\u6a1e\u43a8\u50f2\u5836\u6a72\u4386\u50b0\u58cc\u6a01\u43a1\u5082\u580c\u6a85\u4373\u50b9\u58ca\u6a1b\u43ba\u5071\u582d\u6a91\u4300\u50be\u58cd\u6a28\u4314\u5039\u586d\u6ae0\u43a1\u500e\u580d\u6a92\u43bc\u50f4\u58ca\u6a7a\u436e\u5020\u5872\u6abf\u43b8", -1388425971);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)1526478957 ^ (long)1526478952);
            if (var7) break block25;
            var0_6 = (int)((long)176574551 ^ (long)-176574552);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)-485493527 ^ (long)-485493534);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)-136799282 ^ (long)136799281);
                        if (7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\ub317\u9a62\u89b0\u816e\ub391\u9a5b\u89fc\u81f4\ub31f\u9aea\u89b7\u81a0\ub346\u9a90\u8959\u8196\ub36d\u9a7e\u89b0\u81e0\ub3a6\u9aa8\u8976\u81ea\ub34e\u9aa7\u896f\u8129\ub377\u9a95\u89b7\u81a5\ub38c\u9a98\u89fe\u8158\ub3ca\u9a9f\u892b\u8197\ub315\u9a1e\u898f\u812b\ub316\u9a43\u8962\u81f9\ub33d\u9a9b\u89a7\u817f", -79653693);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)711350643 ^ (long)711350633);
                                var0_6 = (int)((long)-282932425 ^ (long)282932424);
                                while (true) {
                                    v0 = (int)((long)1336699012 ^ (long)1336699132);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)679330465 ^ (long)679330465);
                                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) ** continue;
                                    throw null;
                                }
                                7A.d = var5_1;
                                7A.e = new String[(int)((long)1742426965 ^ (long)1742426996)];
                                if (7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)-1645472793 ^ (long)-1645472793);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)1208463717 ^ (long)1208463716)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-1095571830 ^ (long)-1095571827)) {
                                    case 0: {
                                        v15 = (int)((long)926966009 ^ (long)926965984);
                                        if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)1442236753 ^ (long)1442236773);
                                        if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)-505742227 ^ (long)-505742312);
                                        if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)-1330506434 ^ (long)-1330506465);
                                        if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)-1736858830 ^ (long)-1736858856);
                                        if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)320633700 ^ (long)320633630);
                                        if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)813310081 ^ (long)813310196);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                7A.9 = new dci(0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
                break;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 5(2c c2, fx fx2) {
        block3: {
            block2: {
                boolean bl = \u2002\u2008\u2002\u200c\u200c\u2000\u2004;
                if (bl || bl) break block2;
                2n.8(9.a(fx2).d(-c2.getRenderPosX(), -c2.getRenderPosY(), -c2.getRenderPosZ()), 34L.0(this.0.6(), this.0.4(), this.0.7(), 0.2f));
                if (!bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 4() {
        block3: {
            block2: {
                boolean bl = \u2002\u2008\u2002\u200c\u200c\u2000\u2004;
                if (bl || bl) break block2;
                this.8.forEach(fx2 -> {
                    block4: {
                        block2: {
                            boolean bl;
                            block3: {
                                bl = \u2002\u2008\u2002\u200c\u200c\u2000\u2004;
                                if (bl || bl) break block2;
                                if (7A.3.s.b_()) break block3;
                                if (bl) break block2;
                                if (!this.9p.2) break block3;
                                if (bl || bl) break block2;
                                int n = 5z.4().1z.7(0o.class).7((fx)fx2);
                                if (n <= 0) break block3;
                                if (bl || bl) break block2;
                                7A.3.s.bm.d = n;
                                if (bl) break block2;
                            }
                            if (bl) break block2;
                            7A.3.s.e.a((oj)new sz(sz.a.a, fx2, gc.c));
                            if (bl || bl) break block2;
                            7A.3.s.e.a((oj)new sz(sz.a.c, fx2, gc.c));
                            if (!bl && !bl) break block4;
                        }
                        return;
                    }
                });
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    public 7A() {
        boolean bl = \u2002\u2008\u2002\u200c\u200c\u2000\u2004;
        super(7A.b((int)((long)987728913 ^ (long)987756865), (int)((long)1285964080 ^ (long)-1285964676)) /* "Nuker" */, 7A.b((int)((long)1223513800 ^ (long)1223500679), (int)((long)-1914906408 ^ (long)-1914921517)) /* "Destroys blocks around you" */);
        String[] stringArray = new String[(int)((long)154885096 ^ (long)154885098)];
        stringArray[(int)((long)-864341771 ^ (long)-864341771)] = 7A.b((int)((long)-1847490036 ^ (long)-1847460016), (int)((long)1152443482 ^ (long)-1152440037)) /* "Proximity" */;
        stringArray[(int)((long)2107178813 ^ (long)2107178812)] = 7A.b((int)((long)157740855 ^ (long)157719141), (int)((long)1227635780 ^ (long)-1227627265));
        Color color = stringArray;
        34J j2 = (34H)((34H)((34H)this.0().5(7A.b((int)((long)941277656 ^ (long)941274269), (int)((long)-245553401 ^ (long)245556308)) /* "Origin" */)).7(7A.b((int)((long)-1533098695 ^ (long)-1533104020), (int)((long)-685149994 ^ (long)685175799)) /* "origin" */)).1(7A.b((int)((long)-569399108 ^ (long)-569385500), (int)((long)-159322514 ^ (long)-159332904)) /* "Change the target origin" */);
        ((34H)((34H)((34H)this.0().5(7A.b((int)((long)941277656 ^ (long)941274269), (int)((long)-245553401 ^ (long)245556308)) /* "Origin" */)).7(7A.b((int)((long)-1533098695 ^ (long)-1533104020), (int)((long)-685149994 ^ (long)685175799)) /* "origin" */)).1(7A.b((int)((long)-569399108 ^ (long)-569385500), (int)((long)-159322514 ^ (long)-159332904)) /* "Change the target origin" */)).3 = color;
        this.9D = (11)j2.5();
        String[] stringArray2 = new String[(int)((long)1801358023 ^ (long)1801358021)];
        stringArray2[(int)((long)1071839978 ^ (long)1071839978)] = 7A.b((int)((long)1299758719 ^ (long)1299761972), (int)((long)-1187790348 ^ (long)-1187781178)) /* "Normal" */;
        stringArray2[(int)((long)-1430757842 ^ (long)-1430757841)] = 7A.b((int)((long)835152227 ^ (long)835132477), (int)((long)1266946634 ^ (long)1266947276));
        color = stringArray2;
        j2 = (34H)((34H)((34H)this.0().5(7A.b((int)((long)909498366 ^ (long)909484722), (int)((long)81597265 ^ (long)81593761)) /* "Target" */)).7(7A.b((int)((long)1927919901 ^ (long)1927924819), (int)((long)155029518 ^ (long)155036576)) /* "target" */)).1(7A.b((int)((long)-1805646336 ^ (long)-1805618368), (int)((long)804094781 ^ (long)-804105717)) /* "The block area to target" */);
        ((34H)((34H)((34H)this.0().5(7A.b((int)((long)909498366 ^ (long)909484722), (int)((long)81597265 ^ (long)81593761)) /* "Target" */)).7(7A.b((int)((long)1927919901 ^ (long)1927924819), (int)((long)155029518 ^ (long)155036576)) /* "target" */)).1(7A.b((int)((long)-1805646336 ^ (long)-1805618368), (int)((long)804094781 ^ (long)-804105717)) /* "The block area to target" */)).3 = color;
        this.2 = (11)j2.5();
        color = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7A.b((int)((long)-1156013405 ^ (long)-1155999758), (int)((long)1352147300 ^ (long)1352151399)) /* "Auto Break" */)).7(7A.b((int)((long)-996769818 ^ (long)-996799826), (int)((long)-845650436 ^ (long)-845658689)) /* "autobreak" */)).1(7A.b((int)((long)1781141686 ^ (long)1781163499), (int)((long)-1044321313 ^ (long)-1044324493)) /* "Automatically break blocks. If off, click to break" */);
        ((34X)((34X)((34X)this.4().5(7A.b((int)((long)-1156013405 ^ (long)-1155999758), (int)((long)1352147300 ^ (long)1352151399)) /* "Auto Break" */)).7(7A.b((int)((long)-996769818 ^ (long)-996799826), (int)((long)-845650436 ^ (long)-845658689)) /* "autobreak" */)).1(7A.b((int)((long)1781141686 ^ (long)1781163499), (int)((long)-1044321313 ^ (long)-1044324493)) /* "Automatically break blocks. If off, click to break" */)).7 = color;
        this.5 = (1P)((34X)j2).5();
        this.9g = (1P)((34X)((34X)((34X)this.4().5(7A.b((int)((long)1805563637 ^ (long)1805566881), (int)((long)2142474446 ^ (long)-2142484490)) /* "Filter" */)).7(7A.b((int)((long)-1901751480 ^ (long)-1901730286), (int)((long)697052146 ^ (long)-697048530)) /* "filter" */)).1(7A.b((int)((long)-1529025316 ^ (long)-1529046653), (int)((long)-937870316 ^ (long)937864345)) /* "Filter nuker blocks to custom defined ones" */)).5();
        color = Integer.valueOf((int)((long)2033606 ^ (long)2033602));
        j2 = ((34e)((34e)((34e)this.1().5(7A.b((int)((long)-2027639369 ^ (long)-2027628308), (int)((long)894688331 ^ (long)-894679970)) /* "Radius" */)).7(7A.b((int)((long)-1168686545 ^ (long)-1168689304), (int)((long)153235807 ^ (long)153248014)) /* "radius" */)).1(7A.b((int)((long)739324247 ^ (long)739329028), (int)((long)-1070083035 ^ (long)-1070093852)) /* "The nuking radius" */)).3((int)((long)-968841296 ^ (long)-968841294)).2((int)((long)875588782 ^ (long)875588776));
        ((34e)((34e)((34e)this.1().5(7A.b((int)((long)-2027639369 ^ (long)-2027628308), (int)((long)894688331 ^ (long)-894679970)) /* "Radius" */)).7(7A.b((int)((long)-1168686545 ^ (long)-1168689304), (int)((long)153235807 ^ (long)153248014)) /* "radius" */)).1(7A.b((int)((long)739324247 ^ (long)739329028), (int)((long)-1070083035 ^ (long)-1070093852)) /* "The nuking radius" */)).3((int)((long)-968841296 ^ (long)-968841294)).2((int)((long)875588782 ^ (long)875588776)).7 = color;
        this.7 = (1z)((34e)j2).5();
        color = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7A.b((int)((long)1886951275 ^ (long)1886970429), (int)((long)357775770 ^ (long)-357771288)) /* "Auto Tool" */)).7(7A.b((int)((long)1878454436 ^ (long)1878427118), (int)((long)-55510645 ^ (long)-55517246)) /* "autotool" */)).1(7A.b((int)((long)1057856483 ^ (long)1057877690), (int)((long)-1492529407 ^ (long)-1492529721)) /* "Automatically use the best tool for breaking blocks" */);
        ((34X)((34X)((34X)this.4().5(7A.b((int)((long)1886951275 ^ (long)1886970429), (int)((long)357775770 ^ (long)-357771288)) /* "Auto Tool" */)).7(7A.b((int)((long)1878454436 ^ (long)1878427118), (int)((long)-55510645 ^ (long)-55517246)) /* "autotool" */)).1(7A.b((int)((long)1057856483 ^ (long)1057877690), (int)((long)-1492529407 ^ (long)-1492529721)) /* "Automatically use the best tool for breaking blocks" */)).7 = color;
        this.9p = (1P)((34X)j2).5();
        color = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7A.b((int)((long)-1778521988 ^ (long)-1778541250), (int)((long)-1384851994 ^ (long)1384844250)) /* "ESP" */)).7(7A.b((int)((long)995793279 ^ (long)995814440), (int)((long)925351482 ^ (long)925339365)) /* "esp" */)).1(7A.b((int)((long)587459036 ^ (long)587439256), (int)((long)592542786 ^ (long)-592540664)) /* "Shows blocks being targeted for nuking" */);
        ((34X)((34X)((34X)this.4().5(7A.b((int)((long)-1778521988 ^ (long)-1778541250), (int)((long)-1384851994 ^ (long)1384844250)) /* "ESP" */)).7(7A.b((int)((long)995793279 ^ (long)995814440), (int)((long)925351482 ^ (long)925339365)) /* "esp" */)).1(7A.b((int)((long)587459036 ^ (long)587439256), (int)((long)592542786 ^ (long)-592540664)) /* "Shows blocks being targeted for nuking" */)).7 = color;
        this.1 = (1P)((34X)j2).5();
        color = Color.fromRGB((int)((int)((long)1404361180 ^ (long)1404361180)), (int)((int)((long)485435793 ^ (long)485435793)), (int)((int)((long)1866597562 ^ (long)1866597562)));
        j2 = (34E)((34E)((34E)this.0().5(7A.b((int)((long)-1463281356 ^ (long)-1463260035), (int)((long)1355157222 ^ (long)1355175035)) /* "Color" */)).7(7A.b((int)((long)-1602241316 ^ (long)-1602238063), (int)((long)476115689 ^ (long)476101741)) /* "color" */)).1(7A.b((int)((long)2094775785 ^ (long)2094778521), (int)((long)-2082261600 ^ (long)2082243566)) /* "The block highlight color" */);
        ((34E)((34E)((34E)this.0().5(7A.b((int)((long)-1463281356 ^ (long)-1463260035), (int)((long)1355157222 ^ (long)1355175035)) /* "Color" */)).7(7A.b((int)((long)-1602241316 ^ (long)-1602238063), (int)((long)476115689 ^ (long)476101741)) /* "color" */)).1(7A.b((int)((long)2094775785 ^ (long)2094778521), (int)((long)-2082261600 ^ (long)2082243566)) /* "The block highlight color" */)).7 = color;
        this.0 = (1R)((34E)((34E)j2).3(this.1)).5();
        this.8 = new ArrayList<fx>();
        this.6 = new Listener(f -> {
            int n;
            block30: {
                int n2;
                int n3;
                int n4;
                int n5;
                int n6;
                int n7;
                String[] stringArray;
                boolean bl;
                block31: {
                    block32: {
                        bl = \u2002\u2008\u2002\u200c\u200c\u2000\u2004;
                        if (bl || bl) return;
                        2R.1(this, 7A.b((int)((long)1365425872 ^ (long)1365429137), (int)((long)505728425 ^ (long)-505717741)) /* "suffix" */, this.2.0());
                        if (bl) return;
                        String[] stringArray2 = 3e.5();
                        this.8.clear();
                        stringArray = stringArray2;
                        if (bl || bl) return;
                        n7 = ((String)this.9D.0()).equals(7A.b((int)((long)240080222 ^ (long)240066589), (int)((long)999341361 ^ (long)999341039)) /* "Mouse" */);
                        if (n7 == 0) break block31;
                        if (bl) return;
                        if (7A.3.v == null) break block32;
                        if (bl) return;
                        if (7A.3.v.c() == dcl.a.b) break block31;
                        if (bl) return;
                    }
                    if (bl) return;
                    return;
                }
                if (bl) return;
                if (n7 != 0) {
                    if (bl) {
                        return;
                    }
                    n6 = ((dcj)7A.3.v).a().u();
                    if (\u2002\u2008\u2002\u200c\u200c\u2000\u2004) {
                        throw null;
                    }
                } else {
                    n6 = n5 = (int)7A.3.s.cD();
                }
                if (n7 != 0) {
                    n4 = ((dcj)7A.3.v).a().v();
                    if (\u2002\u2008\u2002\u200c\u200c\u2000\u2004) {
                        throw null;
                    }
                } else {
                    n4 = n3 = (int)7A.3.s.cE();
                }
                if (n7 != 0) {
                    n2 = ((dcj)7A.3.v).a().w();
                    if (\u2002\u2008\u2002\u200c\u200c\u2000\u2004) {
                        throw null;
                    }
                } else {
                    n2 = (int)7A.3.s.cH();
                }
                n7 = n2;
                block0: for (int i = -this.7.4; i < this.7.4; ++i) {
                    n = this.7.4;
                    if (stringArray != null) break block30;
                    int n8 = n;
                    do {
                        int n9 = n8;
                        block2: while (true) {
                            int n10;
                            block35: {
                                block34: {
                                    block33: {
                                        if (!((String)this.2.0()).equals(7A.b((int)((long)-289555081 ^ (long)-289552335), (int)((long)716985393 ^ (long)-716970817)) /* "Flatten" */)) break block33;
                                        n10 = (int)((long)-2012378121 ^ (long)2012378120);
                                        if (stringArray != null) break block34;
                                        if (\u2002\u2008\u2002\u200c\u200c\u2000\u2004) {
                                            throw null;
                                        }
                                        break block35;
                                    }
                                    n10 = this.7.4;
                                }
                                n10 = -n10;
                            }
                            if (n9 <= n10) continue block0;
                            for (int i2 = -this.7.4; i2 < this.7.4; ++i2) {
                                int n11;
                                fx fx2 = new fx(n5 + i, n3 + n8, n7 + i2);
                                buo buo2 = 34L.7(fx2);
                                n9 = this.9g.2 ? 1 : 0;
                                if (stringArray != null) continue block2;
                                if (n9 != 0) {
                                    n11 = 5z.4().1B.4(buo2);
                                    if (\u2002\u2008\u2002\u200c\u200c\u2000\u2004) {
                                        throw null;
                                    }
                                } else if (buo2 != bup.a) {
                                    n11 = (int)((long)-1041502194 ^ (long)-1041502193);
                                    if (\u2002\u2008\u2002\u200c\u200c\u2000\u2004) {
                                        throw null;
                                    }
                                } else {
                                    n11 = (int)((long)-1830375293 ^ (long)-1830375293);
                                }
                                if (n11 == false) continue;
                                this.8.add(fx2);
                                if (stringArray == null) continue;
                            }
                            break;
                        }
                        --n8;
                    } while (stringArray == null);
                    if (stringArray == null) continue;
                }
                n = this.5.2 ? 1 : 0;
            }
            if (n == 0) return;
            this.4();
        }, new Predicate[(int)((long)2012384833 ^ (long)2012384833)]);
        this.9f = new Listener(k2 -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2002\u2008\u2002\u200c\u200c\u2000\u2004;
                        if (bl || bl) break block2;
                        if (k2.4 != (int)((long)-77707723 ^ (long)-77707724)) break block3;
                        if (bl) break block2;
                        if (k2.2 != 0) break block3;
                        if (bl) break block2;
                        if (this.5.2) break block3;
                        if (bl || bl) break block2;
                        this.4();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)1452852727 ^ (long)1452852727)]);
        this.4 = new Listener(object -> {
            boolean bl = \u2002\u2008\u2002\u200c\u200c\u2000\u2004;
            if (bl || bl) return;
            if (!this.1.2) {
                if (bl) return;
                return;
            }
            if (bl) return;
            object = (2c)3.ac();
            if (bl || bl) return;
            this.8.forEach(arg_0 -> this.5((2c)object, arg_0));
            if (!bl && !bl) return;
        }, new Predicate[(int)((long)-565000237 ^ (long)-565000237)]);
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-292636344 ^ (long)-292631528)) & (int)((long)-1695558323 ^ (long)-1695601998);
            if (var9_2) ** GOTO lbl-1000
            if (7A.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7A.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1936637388 ^ (long)1936637388)] & (int)((long)-1262597188 ^ (long)-1262597309)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-450751389 ^ (long)-450751433);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1228621028 ^ (long)1228620905);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1935908068 ^ (long)1935907970);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-501125579 ^ (long)-501125532);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-773684006 ^ (long)-773683977);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-987087752 ^ (long)-987087754);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)606583663 ^ (long)606583690);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-931183082 ^ (long)-931183083);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)334199615 ^ (long)334199738);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)2036912747 ^ (long)2036912853);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-646147648 ^ (long)-646147664);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)72853073 ^ (long)72853203);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1133887765 ^ (long)-1133887887);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1532325218 ^ (long)-1532325281);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1285012048 ^ (long)-1285012123);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-2046612905 ^ (long)-2046612935);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)777063970 ^ (long)777064048);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1380480899 ^ (long)1380480899);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)283146137 ^ (long)283146063);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1207414164 ^ (long)1207414077);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1667283953 ^ (long)-1667283786);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-401356392 ^ (long)-401356435);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-897042831 ^ (long)-897042917);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)671370730 ^ (long)671370643);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-757591084 ^ (long)-757591239);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1968226414 ^ (long)-1968226483);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-591950136 ^ (long)-591950190);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1700551076 ^ (long)-1700550922);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)607138102 ^ (long)607138264);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1015526873 ^ (long)-1015526743);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)3454616 ^ (long)3454680);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1716923884 ^ (long)-1716923831);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)188969422 ^ (long)188969467);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-82887920 ^ (long)-82887867);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1277079006 ^ (long)-1277078798);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-829627299 ^ (long)-829627140);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)572548302 ^ (long)572548186);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-2079715751 ^ (long)-2079715788);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)958540957 ^ (long)958541038);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)68867440 ^ (long)68867344);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1844534245 ^ (long)-1844534186);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1215273663 ^ (long)1215273718);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1515973640 ^ (long)1515973671);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-544422045 ^ (long)-544422103);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)2062720935 ^ (long)2062720930);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-323940094 ^ (long)-323940068);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1860131575 ^ (long)-1860131347);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1228087401 ^ (long)-1228087537);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1462479316 ^ (long)1462479292);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-543586806 ^ (long)-543586813);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)288123907 ^ (long)288124029);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1005353896 ^ (long)1005353936);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)201494182 ^ (long)201494089);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-396628379 ^ (long)-396628349);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-933866856 ^ (long)-933866983);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)705221089 ^ (long)705221100);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1896475612 ^ (long)-1896475629);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1486136089 ^ (long)-1486136104);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-2104814663 ^ (long)-2104814791);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1692951212 ^ (long)1692951163);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)541980133 ^ (long)541980003);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)954182197 ^ (long)954182329);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)515560202 ^ (long)515560390);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-794542139 ^ (long)-794542319);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1160887358 ^ (long)1160887508);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1708088321 ^ (long)-1708088479);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1432927561 ^ (long)-1432927700);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-317580887 ^ (long)-317580993);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1167046022 ^ (long)-1167046111);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-127491796 ^ (long)-127491735);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1218081760 ^ (long)-1218081573);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1989871257 ^ (long)1989871213);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1268712063 ^ (long)1268712181);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1937736841 ^ (long)1937736835);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)2100625724 ^ (long)2100625676);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-112232542 ^ (long)-112232468);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)118029597 ^ (long)118029820);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)509111098 ^ (long)509111174);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1565598019 ^ (long)1565598006);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-95071691 ^ (long)-95071606);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)134239691 ^ (long)134239704);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)10913546 ^ (long)10913602);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-2055899591 ^ (long)-2055899633);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)842508919 ^ (long)842508920);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1678652111 ^ (long)-1678651914);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-729581046 ^ (long)-729580870);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1763597720 ^ (long)1763597716);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)130911571 ^ (long)130911682);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)919254223 ^ (long)919254099);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)230965884 ^ (long)230966005);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)484564103 ^ (long)484564019);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)877626503 ^ (long)877626519);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-2000752280 ^ (long)-2000752306);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1378433015 ^ (long)-1378432954);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-279543098 ^ (long)-279543058);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)2044339976 ^ (long)2044340180);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1626762612 ^ (long)1626762633);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)814272266 ^ (long)814272355);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-162789558 ^ (long)-162789555);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-773124699 ^ (long)-773124711);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-2034072716 ^ (long)-2034072811);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-153178710 ^ (long)-153178847);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1700134979 ^ (long)1700134920);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)2052731175 ^ (long)2052731256);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)338307634 ^ (long)338307620);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1139615098 ^ (long)1139615230);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1718041293 ^ (long)-1718041141);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-422212398 ^ (long)-422212573);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-372223495 ^ (long)-372223590);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1902595123 ^ (long)-1902595300);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)770422692 ^ (long)770422738);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1121974902 ^ (long)-1121974994);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)380173293 ^ (long)380173166);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1779555213 ^ (long)-1779555292);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-184026091 ^ (long)-184026009);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)2145647155 ^ (long)2145647252);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)2136963833 ^ (long)2136963691);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-770481770 ^ (long)-770481798);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-354009229 ^ (long)-354009330);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1501673758 ^ (long)-1501673925);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)2122048824 ^ (long)2122048872);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-832116193 ^ (long)-832116204);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1765866836 ^ (long)-1765866928);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)938212506 ^ (long)938212538);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1468103710 ^ (long)1468103803);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-865500621 ^ (long)-865500502);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)2023439131 ^ (long)2023439238);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1208285395 ^ (long)1208285207);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)2043128122 ^ (long)2043128072);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1683989277 ^ (long)1683989255);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-879664081 ^ (long)-879664067);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-369135730 ^ (long)-369135627);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)2004219611 ^ (long)2004219416);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1105919895 ^ (long)1105919925);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1343533246 ^ (long)-1343533068);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1953977875 ^ (long)1953978033);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)2064186842 ^ (long)2064186673);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-219033784 ^ (long)-219033640);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)782255602 ^ (long)782255504);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1919993528 ^ (long)1919993472);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1318959573 ^ (long)1318959381);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)49361910 ^ (long)49361884);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1114372751 ^ (long)-1114372785);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-291183675 ^ (long)-291183662);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)2046251365 ^ (long)2046251469);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1767411379 ^ (long)1767411228);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1006217277 ^ (long)-1006217439);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1151467040 ^ (long)1151467022);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1304069035 ^ (long)-1304068964);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-333621012 ^ (long)-333621177);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-595478133 ^ (long)-595478232);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)2003230129 ^ (long)2003230137);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)582200317 ^ (long)582200193);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1110141186 ^ (long)-1110141311);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-2067666499 ^ (long)-2067666461);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-212872229 ^ (long)-212872445);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-527432728 ^ (long)-527432892);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1954891537 ^ (long)-1954891754);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1139348309 ^ (long)-1139348350);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1276143258 ^ (long)-1276143307);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)2101056462 ^ (long)2101056285);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1073832380 ^ (long)1073832420);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-620371008 ^ (long)-620370991);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1714823168 ^ (long)-1714823132);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-665132803 ^ (long)-665132992);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)2055979073 ^ (long)2055979130);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1076084108 ^ (long)1076084186);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1262187148 ^ (long)-1262187134);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-80679984 ^ (long)-80680170);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1553242478 ^ (long)1553242540);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1640009888 ^ (long)1640009946);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1127340485 ^ (long)1127340508);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1876868947 ^ (long)1876868945);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1011881538 ^ (long)1011881585);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)195572493 ^ (long)195572677);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1184751129 ^ (long)1184751335);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)386917954 ^ (long)386918136);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1786766028 ^ (long)1786765940);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1434879217 ^ (long)-1434879040);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-399377828 ^ (long)-399377864);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1309025064 ^ (long)1309025250);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1368439332 ^ (long)-1368439381);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1749554558 ^ (long)-1749554556);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)88879929 ^ (long)88880062);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1634056267 ^ (long)1634056432);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-40359202 ^ (long)-40359246);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1768390150 ^ (long)-1768390348);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1877995291 ^ (long)-1877995280);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-558042397 ^ (long)-558042517);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-924992658 ^ (long)-924992657);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1322737094 ^ (long)1322737118);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-884241605 ^ (long)-884241490);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1495240130 ^ (long)-1495240111);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-701980617 ^ (long)-701980527);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1042632730 ^ (long)-1042632893);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)985801269 ^ (long)985801454);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)620254762 ^ (long)620254785);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)2101331215 ^ (long)2101331421);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1859778217 ^ (long)1859778226);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)86077361 ^ (long)86077300);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1478029697 ^ (long)-1478029696);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1075260691 ^ (long)-1075260756);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-22816968 ^ (long)-22817019);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)959163718 ^ (long)959163893);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1785271870 ^ (long)1785271887);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1959601901 ^ (long)-1959601758);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)938995965 ^ (long)938995945);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)25800411 ^ (long)25800232);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1025715649 ^ (long)-1025715597);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-2133384356 ^ (long)-2133384261);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1299543138 ^ (long)1299543244);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)431584059 ^ (long)431584172);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-2068135613 ^ (long)-2068135472);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)506229990 ^ (long)506229782);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)2123671901 ^ (long)2123671812);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)2099777391 ^ (long)2099777414);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1267113918 ^ (long)1267113977);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-583979746 ^ (long)-583979715);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)603339518 ^ (long)603339317);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)2143575390 ^ (long)2143575402);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1271516968 ^ (long)-1271516958);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-380136941 ^ (long)-380136904);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-188345038 ^ (long)-188345067);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1194166824 ^ (long)1194166890);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)558058946 ^ (long)558058786);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-913039062 ^ (long)-913039050);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)32978298 ^ (long)32978394);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)238984935 ^ (long)238984765);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1304685767 ^ (long)1304685621);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1984191809 ^ (long)-1984191748);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)139452605 ^ (long)139452617);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1429262044 ^ (long)-1429262059);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-833882262 ^ (long)-833882314);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-2128190509 ^ (long)-2128190618);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-792607793 ^ (long)-792607792);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)531022770 ^ (long)531022664);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1544753890 ^ (long)1544753744);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1223469515 ^ (long)1223469484);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1889745714 ^ (long)1889745900);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)789587286 ^ (long)789587417);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1301588040 ^ (long)1301588139);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1544985593 ^ (long)1544985536);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1394885160 ^ (long)-1394885123);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1359758195 ^ (long)1359758316);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)309635921 ^ (long)309636006);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-741281262 ^ (long)-741281265);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-911217233 ^ (long)-911217173);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1752444830 ^ (long)1752444850);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1767817780 ^ (long)1767817749);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-192669223 ^ (long)-192669281);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1287059449 ^ (long)1287059278);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1071554935 ^ (long)1071554931);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-797709804 ^ (long)-797709639);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1781403850 ^ (long)1781403671);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1877361809 ^ (long)1877361756);
                    if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-682666520 ^ (long)-682666752);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1128576397 ^ (long)-1128576372)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1900757065 ^ (long)1900789686)) >>> (int)((long)-4696792 ^ (long)-4696800)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1729795382 ^ (long)1729795382);
            if (!7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-452160709 ^ (long)-452160711);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1694521335 ^ (long)1694521332) | var5_6 << (int)((long)122106032 ^ (long)122106037)) ^ var3_4[var7_8]) & (int)((long)-676350053 ^ (long)-676350108);
                    if (7A.\u2002\u2008\u2002\u200c\u200c\u2000\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1526313953 ^ (long)1526313954) | var6_7 << (int)((long)-1483593249 ^ (long)-1483593254)) ^ var3_4[var7_8]) & (int)((long)-36745744 ^ (long)-36745969);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7A.e[var2_3] = new String(var3_4).intern();
        }
        return 7A.e[var2_3];
    }
}

