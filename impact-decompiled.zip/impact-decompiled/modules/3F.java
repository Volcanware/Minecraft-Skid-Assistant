/* ==========================================================================
 * MODULE: Anti Hunger
 * CATEGORY (inferred): Player
 * DESCRIPTION: Reduces hunger loss
 * OBFUSCATED CLASS: net.impactclient.3F
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 */
package net.impactclient;

import net.impactclient.2w$6X;
import net.impactclient.3X;
import net.impactclient.49;
import net.impactclient.72;
import net.impactclient.7c;
import net.impactclient.7m;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3F
extends 3X
implements 49 {
    private static final String[] d;
    public static final boolean \u200b\u2001\u2009\u200a\u200b\u2001\u2009;
    private static final String[] e;

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)1192006158 ^ (long)1192006156)];
            if (var7) break block16;
            var3_2 = (int)((long)-872341941 ^ (long)-872341941);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u59b0\u7110\u6289\u6aa3\u59c5\u7185\u6270\u6a66\u596d\u715f\u628d\u6acf\u596b\u71d2\u6293\u6a8d\u59d7\u71f2\u621f\u6a4e\u5949\u71cd\u62fb\u6af6\u59fc\u7169\u623d\u6a7f\u5901\u7173\u6290", -962232547);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)1299583959 ^ (long)1299583964);
            if (var7) break block16;
            var0_6 = (int)((long)375687481 ^ (long)-375687482);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-362820764 ^ (long)362820763);
                if (3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) continue block8;
                            throw null;
                        }
                        3F.d = var5_1;
                        3F.e = new String[(int)((long)-1969131630 ^ (long)-1969131632)];
                        if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)-681767561 ^ (long)-681767561);
                v5 = (int)((long)22944692 ^ (long)22944680);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)-476209426 ^ (long)-476209425)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1589368750 ^ (long)1589368745)) {
                                case 0: {
                                    v12 = (int)((long)1631156694 ^ (long)1631156659);
                                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)1798959029 ^ (long)1798958977);
                                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-559683179 ^ (long)-559683108);
                                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)1299655833 ^ (long)1299655841);
                                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)-205202780 ^ (long)-205202773);
                                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)1810443152 ^ (long)1810443226);
                                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-625324390 ^ (long)-625324411);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) ** continue;
                throw null;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)614733851 ^ (long)614739717)) & (int)((long)-930889391 ^ (long)-930922834);
            if (var9_2) ** GOTO lbl-1000
            if (3F.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3F.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-878274719 ^ (long)-878274719)] & (int)((long)-1106006900 ^ (long)-1106006925)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)569148693 ^ (long)569148757);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)793388089 ^ (long)793388101);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-269296411 ^ (long)-269296442);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)5279878 ^ (long)5279906);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-918460795 ^ (long)-918460738);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1691380482 ^ (long)-1691380667);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)273658668 ^ (long)273658826);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-940095802 ^ (long)-940095807);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)2032648143 ^ (long)2032648047);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-269928780 ^ (long)-269928857);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1546925345 ^ (long)1546925562);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1683396639 ^ (long)1683396626);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-762215245 ^ (long)-762215282);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-366379311 ^ (long)-366379492);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-163305157 ^ (long)-163305062);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)92724431 ^ (long)92724295);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)478233414 ^ (long)478233577);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1529751353 ^ (long)1529751464);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-244629018 ^ (long)-244629245);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-815957142 ^ (long)-815957147);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1746238844 ^ (long)-1746238970);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1749609713 ^ (long)-1749609605);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1749076648 ^ (long)1749076699);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1278252794 ^ (long)-1278252751);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)165228667 ^ (long)165228650);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1056387309 ^ (long)1056387131);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-2058678385 ^ (long)-2058678401);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1543825880 ^ (long)-1543825853);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-687348729 ^ (long)-687348631);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-979525562 ^ (long)-979525500);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)322820637 ^ (long)322820863);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1663257566 ^ (long)-1663257385);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1695636326 ^ (long)-1695636413);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)203883150 ^ (long)203883158);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)736643306 ^ (long)736643262);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-335427909 ^ (long)-335428078);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1880614305 ^ (long)-1880614272);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)170937100 ^ (long)170937246);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1134536652 ^ (long)1134536690);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)125483144 ^ (long)125483074);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1713916804 ^ (long)1713916797);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1741952589 ^ (long)1741952529);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-189764421 ^ (long)-189764606);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)138680426 ^ (long)138680559);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)401757458 ^ (long)401757586);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)2071615606 ^ (long)2071615605);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-572944715 ^ (long)-572944880);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1154997346 ^ (long)-1154997299);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1220147662 ^ (long)1220147630);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-2115190149 ^ (long)-2115190218);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-894752146 ^ (long)-894752040);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1193423005 ^ (long)1193423042);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)18025341 ^ (long)18025306);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1873174070 ^ (long)1873174239);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)236982920 ^ (long)236982916);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)555443476 ^ (long)555443576);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)612007101 ^ (long)612006926);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-324015991 ^ (long)-324016123);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1028848960 ^ (long)-1028849101);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)0x444747B4 ^ (long)1145521928);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1713242747 ^ (long)-1713242841);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)2125480463 ^ (long)2125480466);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1812731033 ^ (long)-1812731108);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)746821811 ^ (long)746821735);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)70812796 ^ (long)70812691);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1349549325 ^ (long)-1349549500);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)820084834 ^ (long)820084807);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1822516548 ^ (long)1822516638);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1690083058 ^ (long)1690082826);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)2096429525 ^ (long)2096429559);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-570615421 ^ (long)-570615411);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-795901881 ^ (long)-795901725);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1791355514 ^ (long)-1791355481);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1637446939 ^ (long)-1637447096);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-2142580651 ^ (long)-2142580666);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1719347896 ^ (long)1719347863);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)2090900605 ^ (long)2090900508);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)930761720 ^ (long)930761558);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1235223320 ^ (long)1235223311);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1165099688 ^ (long)-1165099715);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1076473164 ^ (long)1076473116);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-516428531 ^ (long)-516428531);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)957364073 ^ (long)957364079);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)2117897008 ^ (long)2117897093);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)716253410 ^ (long)716253411);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1623424126 ^ (long)-1623424198);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1353111017 ^ (long)1353110951);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)211605000 ^ (long)211605222);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1266373658 ^ (long)1266373809);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1830912402 ^ (long)1830912383);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-5688187 ^ (long)-5688198);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-2131416242 ^ (long)-2131416245);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1350509679 ^ (long)-1350509689);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1879365416 ^ (long)1879365405);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-2133166088 ^ (long)-2133166270);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)2142064125 ^ (long)2142063988);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1738402792 ^ (long)-1738402713);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)815834765 ^ (long)815834654);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1459783174 ^ (long)-1459783237);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)479775532 ^ (long)479775500);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1732048534 ^ (long)1732048594);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-2105617777 ^ (long)-2105617902);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)213040386 ^ (long)213040456);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1588557082 ^ (long)-1588557288);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1839183186 ^ (long)1839183354);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-855620043 ^ (long)-855619981);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1788749886 ^ (long)1788749984);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)2141089904 ^ (long)2141089817);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1256076657 ^ (long)1256076769);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1894633166 ^ (long)1894633175);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-2060064075 ^ (long)-2060064096);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-803121656 ^ (long)-803121480);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-2000040386 ^ (long)-2000040208);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-494780176 ^ (long)-494780356);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)443238009 ^ (long)443238013);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)857345835 ^ (long)857345968);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)854647920 ^ (long)854647874);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1427404399 ^ (long)1427404534);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-58123014 ^ (long)-58123152);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)966585670 ^ (long)966585714);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1962491746 ^ (long)1962491818);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)2027798137 ^ (long)2027798019);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-892233536 ^ (long)-892233585);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1702649458 ^ (long)1702649531);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1020029598 ^ (long)-1020029531);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)2066857591 ^ (long)2066857612);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1614506941 ^ (long)1614506877);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1657461038 ^ (long)1657461119);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-738012860 ^ (long)-738012874);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-481254234 ^ (long)-481254295);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-2097990657 ^ (long)-2097990757);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)2086919665 ^ (long)2086919450);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1101195788 ^ (long)-1101195938);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1865847320 ^ (long)-1865847370);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1287503482 ^ (long)1287503504);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-64308766 ^ (long)-64308786);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-862475802 ^ (long)-862476009);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)966251431 ^ (long)966251364);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1844878359 ^ (long)1844878427);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1858853140 ^ (long)-1858853255);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-2129233375 ^ (long)-2129233207);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1786716917 ^ (long)1786716861);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)594286327 ^ (long)594286317);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1850513478 ^ (long)-1850513660);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1500219928 ^ (long)-1500219963);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-686890837 ^ (long)-686890963);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1385894035 ^ (long)-1385893963);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1244550371 ^ (long)-1244550366);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1748252547 ^ (long)-1748252487);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)102185200 ^ (long)102185176);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-406262436 ^ (long)-406262432);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1113841566 ^ (long)-1113841612);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-193934775 ^ (long)-193934836);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1222720821 ^ (long)-1222721010);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1385743278 ^ (long)-1385743317);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)976074731 ^ (long)976074707);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-978337703 ^ (long)-978337602);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1599017431 ^ (long)1599017468);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)996078085 ^ (long)996078183);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)2058625064 ^ (long)2058625078);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-365676904 ^ (long)-365676921);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)743314995 ^ (long)743314953);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-597131505 ^ (long)-597131384);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-613900337 ^ (long)-613900464);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1127859766 ^ (long)-1127859859);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-280751816 ^ (long)-280751759);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-339599476 ^ (long)-339599483);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1189632149 ^ (long)-1189632096);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-201014633 ^ (long)-201014578);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-482738479 ^ (long)-482738486);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)449862937 ^ (long)449862930);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1810235311 ^ (long)-1810235335);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1535079128 ^ (long)1535078956);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1637046837 ^ (long)-1637046947);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)696145712 ^ (long)696145841);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)443382924 ^ (long)443382883);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-65968719 ^ (long)-65968744);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1991391960 ^ (long)-1991391921);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1662018701 ^ (long)1662018583);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)914486980 ^ (long)914486863);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)936207222 ^ (long)936207150);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-507498648 ^ (long)-507498567);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1803945251 ^ (long)1803945289);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1026394571 ^ (long)1026394610);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-419165626 ^ (long)-419165628);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-876956784 ^ (long)-876956704);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1268370237 ^ (long)1268370319);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1565533024 ^ (long)1565533084);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1594935130 ^ (long)1594935055);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1631076281 ^ (long)1631076234);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1275658330 ^ (long)-1275658244);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)908417724 ^ (long)908417677);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)204018447 ^ (long)204018595);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)897421296 ^ (long)897421304);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1472127256 ^ (long)1472127236);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)697780892 ^ (long)697780781);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1414726204 ^ (long)1414726251);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-795091894 ^ (long)-795091735);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1365391465 ^ (long)-1365391427);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1459902865 ^ (long)-1459902798);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)407816280 ^ (long)407816330);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-586979868 ^ (long)-586979940);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)142300094 ^ (long)142299955);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-2033241176 ^ (long)-2033241130);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1168700107 ^ (long)1168699958);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1347153175 ^ (long)-1347153201);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-2100328987 ^ (long)-2100328969);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1689099647 ^ (long)-1689099556);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-976033755 ^ (long)-976033595);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)281598778 ^ (long)281598882);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-248137817 ^ (long)-248137811);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1062155629 ^ (long)1062155730);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)232756791 ^ (long)232756960);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-485636096 ^ (long)-485635898);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1135359453 ^ (long)1135359260);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)628526449 ^ (long)628526497);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-244591592 ^ (long)-244591526);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)131848437 ^ (long)131848323);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-2057220253 ^ (long)-2057220209);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)2040863580 ^ (long)2040863495);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-423177525 ^ (long)-423177649);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1854855878 ^ (long)-1854855717);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1276926957 ^ (long)1276926729);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)606904972 ^ (long)606904914);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-2143122402 ^ (long)-2143122392);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1882836361 ^ (long)1882836377);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1236894614 ^ (long)1236894677);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-485903706 ^ (long)-485903663);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1413677592 ^ (long)1413677723);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)449990516 ^ (long)449990409);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)102341037 ^ (long)102340899);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-738928683 ^ (long)-738928842);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)750257655 ^ (long)750257413);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-2068441216 ^ (long)-2068441134);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1470423396 ^ (long)-1470423494);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1764559631 ^ (long)1764559794);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1527225039 ^ (long)1527224889);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)237685063 ^ (long)237685034);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-999652168 ^ (long)-999652130);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1776008894 ^ (long)-1776008776);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-2083014748 ^ (long)-2083014764);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1692031066 ^ (long)1692031189);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1274751154 ^ (long)1274751225);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-391249267 ^ (long)-391249327);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1309247503 ^ (long)1309247596);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1335660879 ^ (long)-1335660897);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-131233571 ^ (long)-131233750);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1553744460 ^ (long)1553744592);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1350513259 ^ (long)1350513196);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1014808495 ^ (long)1014808507);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1754315734 ^ (long)1754315586);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1614302162 ^ (long)-1614302113);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1244271187 ^ (long)-1244271335);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-345992157 ^ (long)-345991946);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1786746026 ^ (long)-1786745919);
                    if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)638159661 ^ (long)638159704);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-169548635 ^ (long)-169548710)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1485350764 ^ (long)-1485330581)) >>> (int)((long)-1371706490 ^ (long)-1371706482)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1003392109 ^ (long)1003392109);
            if (!3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)852644822 ^ (long)852644820);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1863943884 ^ (long)-1863943881) | var5_6 << (int)((long)1817617742 ^ (long)1817617739)) ^ var3_4[var7_8]) & (int)((long)341532044 ^ (long)341532019);
                    if (3F.\u200b\u2001\u2009\u200a\u200b\u2001\u2009) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-262005685 ^ (long)-262005688) | var6_7 << (int)((long)944370877 ^ (long)944370872)) ^ var3_4[var7_8]) & (int)((long)1087974165 ^ (long)1087974378);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3F.e[var2_3] = new String(var3_4).intern();
        }
        return 3F.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public 3F() {
        boolean bl = \u200b\u2001\u2009\u200a\u200b\u2001\u2009;
        super(3F.b((int)((long)2094478873 ^ (long)2094465287), (int)((long)876901575 ^ (long)876897790)) /* "Anti Hunger" */, 3F.b((int)((long)968145991 ^ (long)968133464), (int)((long)1092345560 ^ (long)1092322871)) /* "Reduces hunger loss" */);
        7m[] mArray = new 7m[(int)((long)-1399480499 ^ (long)-1399480497)];
        mArray[(int)((long)778092645 ^ (long)778092645)] = new 72(this);
        mArray[(int)((long)-1519316895 ^ (long)-1519316896)] = new 7c(this);
        this.5(mArray);
        if (bl || bl) {
            return;
        }
    }
}

