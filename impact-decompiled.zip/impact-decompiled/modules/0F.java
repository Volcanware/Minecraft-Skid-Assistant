/* ==========================================================================
 * MODULE: Blink
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Lag Switch
 * OBFUSCATED CLASS: net.impactclient.0F
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  bfw
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  nd
 *  oj
 *  st
 */
package net.impactclient;

import clientapi.load.mixin.7.3;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.11;
import net.impactclient.1P;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.34H;
import net.impactclient.34I;
import net.impactclient.34R;
import net.impactclient.34X;
import net.impactclient.34s;
import net.impactclient.3C;
import net.impactclient.3X;
import net.impactclient.4f;
import net.impactclient.6C;
import net.impactclient.8j;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0F
extends 3X
implements 34R {
    private 11 0;
    public static final boolean \u200f\u200d\u2002;
    private long 1;
    private static final String[] d;
    private long 6;
    private 1P 4;
    private 34I 2;
    @EventHandler
    private final Listener<3C> 5;
    private List<oj> 8;
    @EventHandler
    private final Listener<8j> 9;
    private static final String[] e;
    @EventHandler
    private final Listener<4f> 7;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0F.\u200f\u200d\u2002;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1937142454 ^ (long)1937142456)];
            if (var7) break block23;
            var3_2 = (int)((long)1702354760 ^ (long)1702354760);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u71dd\u5992\u4afe\u42bd\u71bf\u59b7\u4ada\u4251\u71b2\u5970\u4a69\u426e\u71ba\u5903\u4acb\u4253\u716f\u59a4\u4a65\u426d\u711a\u59e4\u4a07\u42bc\u71b4\u5954\u4ab6\u428c\u715d\u59d2\u4a42\u4269\u7172\u5983\u4a70\u423a\u71cc\u59e9\u4adc\u42d2\u71fb\u595a\u4a52\u42ec\u71b7\u5912\u4afd\u4238\u7123\u5943\u4a01\u422e\u71d9\u598d\u4aec\u42f0\u7129\u596e\u4a17\u4273\u7108\u59c8\u4a4e\u42b2\u715b\u59c7\u4af2\u426a\u7151\u595e\u4a90\u4259\u71ca\u5988\u4a3e\u4295\u718f\u59be\u4abe\u4281\u71b7\u5999\u4a46\u422d\u7171\u590a\u4abd\u4230\u71d6\u5957\u4a42\u420f\u7128\u596b\u4a3b\u4238\u7180\u5911\u4ade\u424b\u710a\u5917\u4aa9\u4282\u71a6\u59c2", 1852528627);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-882459553 ^ (long)-882459561);
            if (var7) break block23;
            var0_6 = (int)((long)-158313694 ^ (long)158313693);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-950357625 ^ (long)-950357627);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1640448943 ^ (long)-1640448944);
                    if (0F.\u200f\u200d\u2002) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0F.\u200f\u200d\u2002) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("u\u2883\u3bf8\u3302\u008d\u2822\u3b94\u33d2b\u28d2\u3b71\u33f4\u00cc\u28ed\u3b34\u33ceH\u287a\u3bad\u335c\u00c7\u28f1\u3b2e\u3318\u0000\u2870\u3b65\u33d0~\u28dc\u3bfd\u338e\u001c\u2852\u3b45\u3321t\u28a9\u3b1e\u336e\u0004\u28ba\u3bad\u33f9\u00ea\u28f0\u3b5c\u3389\u00bf\u282e\u3bb0", -1716246804);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-375871739 ^ (long)-375871738);
                            var0_6 = (int)((long)977964494 ^ (long)-977964495);
                            while (true) {
                                v0 = (int)((long)-742359695 ^ (long)-742359724);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1905542837 ^ (long)-1905542837);
                                if (!0F.\u200f\u200d\u2002) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0F.\u200f\u200d\u2002) ** continue;
                                throw null;
                            }
                            0F.d = var5_1;
                            0F.e = new String[(int)((long)-1994089852 ^ (long)-1994089846)];
                            if (!0F.\u200f\u200d\u2002) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1019571286 ^ (long)-1019571286);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)2122306528 ^ (long)2122306529)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-375401688 ^ (long)-375401681)) {
                                case 0: {
                                    v15 = (int)((long)-827081231 ^ (long)-827081280);
                                    if (!0F.\u200f\u200d\u2002) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1969668960 ^ (long)1969668938);
                                    if (!0F.\u200f\u200d\u2002) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)376005249 ^ (long)376005369);
                                    if (!0F.\u200f\u200d\u2002) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-854184297 ^ (long)-854184211);
                                    if (!0F.\u200f\u200d\u2002) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-2087476343 ^ (long)-2087476300);
                                    if (!0F.\u200f\u200d\u2002) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1132318931 ^ (long)-1132318959);
                                    if (!0F.\u200f\u200d\u2002) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1229840907 ^ (long)-1229840936);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0F.\u200f\u200d\u2002);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u200f\u200d\u2002;
                    if (bl || bl) break block2;
                    if (0F.3.s == null) break block3;
                    if (bl) break block2;
                    if (0F.3.r == null) break block3;
                    if (bl) break block2;
                    if (3.w() == null) break block3;
                    if (bl || bl) break block2;
                    this.8.forEach(arg_0 -> ((nd)3.w().a()).a(arg_0));
                    if (bl || bl) break block2;
                    0F.3.r.d((int)((long)-88113218 ^ (long)475250121));
                    if (bl || bl) break block2;
                    this.2 = null;
                    if (bl || bl) break block2;
                    this.6 = 0x8C987C83AA617E03L ^ 0x8C987C83AA617E03L;
                    if (bl || bl) break block2;
                    if (!((String)this.0.0()).equals(0F.b((int)((long)1665023093 ^ (long)-1665031211), (int)((long)-1290401392 ^ (long)1290383410)) /* "All" */)) break block3;
                    if (bl || bl) break block2;
                    ((3)0F.3.s.e.a()).setSendPackets((boolean)((long)511311725 ^ (long)511311724));
                    if (bl) break block2;
                }
                if (bl) break block2;
                this.8.clear();
                if (!bl && !bl) break block4;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0F.\u200f\u200d\u2002;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-2068476281 ^ (long)2068451627)) & (int)((long)-158136971 ^ (long)-158074230);
            if (var9_2) ** GOTO lbl-1000
            if (0F.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0F.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1097230522 ^ (long)-1097230522)] & (int)((long)-84383819 ^ (long)-84383926)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1380709004 ^ (long)1380708903);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1944542006 ^ (long)-1944542040);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1238618210 ^ (long)-1238618281);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-36555797 ^ (long)-36555935);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1566353792 ^ (long)-1566353695);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)498289968 ^ (long)498290018);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-854893076 ^ (long)-854893180);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)284739576 ^ (long)284739510);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1932011012 ^ (long)1932011049);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1674691439 ^ (long)1674691561);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1894378923 ^ (long)1894378946);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-931985160 ^ (long)-931985333);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1151631175 ^ (long)-1151631252);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)756122368 ^ (long)756122560);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)632916417 ^ (long)632916450);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-473362830 ^ (long)-473362940);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)89409911 ^ (long)89409993);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)91749834 ^ (long)91749871);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1528136041 ^ (long)1528136157);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-675110625 ^ (long)-675110477);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1521236408 ^ (long)-1521236451);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1405200139 ^ (long)1405200220);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1901961428 ^ (long)-1901961307);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)2019074537 ^ (long)2019074362);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-300428963 ^ (long)-300428804);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-952642097 ^ (long)-952642186);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1421309368 ^ (long)-1421309371);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1796552216 ^ (long)-1796552268);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)2103535273 ^ (long)2103535142);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-117547303 ^ (long)-117547351);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)942504207 ^ (long)942504253);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)144191750 ^ (long)144191810);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1787036108 ^ (long)-1787035924);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)24689168 ^ (long)24689368);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)59540122 ^ (long)59539980);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1729973606 ^ (long)-1729973644);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)836847510 ^ (long)836847577);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-626915258 ^ (long)-626915133);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-275572275 ^ (long)-275572311);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-183737801 ^ (long)-183737809);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)3142084 ^ (long)3142065);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-2058963098 ^ (long)-2058963041);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-9789161 ^ (long)-9789141);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1584453940 ^ (long)1584454098);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)322457118 ^ (long)322457176);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1699752431 ^ (long)-1699752294);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)153349250 ^ (long)153349123);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1887357925 ^ (long)-1887357755);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1232368313 ^ (long)-1232368161);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1954322025 ^ (long)-1954322034);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-13997257 ^ (long)-13997176);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)60097182 ^ (long)60097036);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)217996080 ^ (long)217996058);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1553707947 ^ (long)-1553708024);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)323521658 ^ (long)323521536);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1697899477 ^ (long)1697899271);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-263873286 ^ (long)-263873320);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1667332898 ^ (long)-1667333118);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)409897894 ^ (long)409897903);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)136645771 ^ (long)136645727);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-729327014 ^ (long)-729326943);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-410208301 ^ (long)-410208324);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1250587786 ^ (long)1250587721);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1456282213 ^ (long)-1456282264);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1764345215 ^ (long)1764345213);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1625924387 ^ (long)1625924365);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)544782954 ^ (long)544782917);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1665627678 ^ (long)-1665627734);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1978735891 ^ (long)1978736006);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-39275419 ^ (long)-39275366);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)537580034 ^ (long)537580067);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-102059444 ^ (long)-102059476);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-40105155 ^ (long)-40105169);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1504789991 ^ (long)1504789850);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)494616770 ^ (long)494616630);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)165533741 ^ (long)165533720);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)812157457 ^ (long)812157470);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1206565643 ^ (long)1206565780);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-462239845 ^ (long)-462239938);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1877737750 ^ (long)-1877737774);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1874305011 ^ (long)-1874304908);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1233775990 ^ (long)1233775987);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1238264608 ^ (long)-1238264706);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)268802557 ^ (long)268802528);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-916685614 ^ (long)-916685665);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)665371742 ^ (long)665371661);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)962701484 ^ (long)962701484);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)831162681 ^ (long)831162832);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)462316053 ^ (long)462316185);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)119579586 ^ (long)119579638);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1733532690 ^ (long)-1733532726);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-422782202 ^ (long)-422782037);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1516149687 ^ (long)1516149613);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1467307133 ^ (long)-1467307096);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)2073201248 ^ (long)2073201183);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)2053906905 ^ (long)2053906746);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1948563376 ^ (long)1948563206);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-605124832 ^ (long)-605124611);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1105284149 ^ (long)-1105284314);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)397462166 ^ (long)397462173);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1917671025 ^ (long)-1917671167);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1762472894 ^ (long)-1762472952);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1117293217 ^ (long)1117293120);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)131957609 ^ (long)131957672);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1094824171 ^ (long)1094823980);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1237058679 ^ (long)1237058754);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1921997827 ^ (long)1921998022);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-30122962 ^ (long)-30122814);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1841657694 ^ (long)-1841657671);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)533219706 ^ (long)533219633);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)138171426 ^ (long)138171444);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1028807369 ^ (long)-1028807314);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1315973297 ^ (long)-1315973295);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1052064088 ^ (long)-1052064203);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1049951121 ^ (long)1049951226);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1035913777 ^ (long)-1035913882);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1284637328 ^ (long)-1284637397);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1006393922 ^ (long)-1006394106);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)739062556 ^ (long)739062761);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1670882092 ^ (long)1670882127);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)71996712 ^ (long)71996913);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1026793820 ^ (long)1026793851);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-18890086 ^ (long)-18889987);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1518132400 ^ (long)-1518132284);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)206857446 ^ (long)206857354);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-40956862 ^ (long)-40956780);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1043471572 ^ (long)1043471447);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1574551285 ^ (long)1574551238);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1706135646 ^ (long)1706135620);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-587649946 ^ (long)-587649884);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1567689922 ^ (long)1567689885);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-478846024 ^ (long)-478845995);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1695435255 ^ (long)-1695435144);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1125189625 ^ (long)1125189505);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)2059813101 ^ (long)2059813043);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-36003479 ^ (long)-36003335);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1679492010 ^ (long)-1679491928);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-874079824 ^ (long)-874079825);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1236398082 ^ (long)-1236398149);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1687121898 ^ (long)1687121792);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1980198459 ^ (long)-1980198463);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)711888308 ^ (long)711888364);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)281736369 ^ (long)281736230);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-747902980 ^ (long)-747903131);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)2044610119 ^ (long)2044610294);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-2090668277 ^ (long)-2090668049);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)88170715 ^ (long)88170553);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1851127049 ^ (long)1851127203);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1121590735 ^ (long)-1121590718);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)149748693 ^ (long)149748507);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)219020794 ^ (long)219020715);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1276762544 ^ (long)-1276762456);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1000692143 ^ (long)-1000692135);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1626270672 ^ (long)1626270679);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1783389819 ^ (long)1783389816);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1062162215 ^ (long)1062162346);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1304946265 ^ (long)-1304946320);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)252287721 ^ (long)252287653);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-965769204 ^ (long)-965769066);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-53656024 ^ (long)-53655904);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1315302277 ^ (long)1315302288);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)125371867 ^ (long)125371866);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1672070505 ^ (long)-1672070652);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)746490042 ^ (long)746490104);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1685805156 ^ (long)-1685805260);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1770731907 ^ (long)1770731848);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-461173909 ^ (long)-461173855);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1746905301 ^ (long)-1746905104);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1655093430 ^ (long)-1655093501);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1160864442 ^ (long)-1160864438);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-393101018 ^ (long)-393100902);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1483067293 ^ (long)-1483067239);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1729659626 ^ (long)-1729659450);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1903156115 ^ (long)-1903156017);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1873186565 ^ (long)-1873186632);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)188653316 ^ (long)188653558);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-278020650 ^ (long)-278020702);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1457790383 ^ (long)-1457790419);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)31246181 ^ (long)31246198);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)30223147 ^ (long)30223243);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)129780662 ^ (long)129780673);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1181776814 ^ (long)-1181776830);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-13976542 ^ (long)-13976574);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-839402515 ^ (long)-839402677);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)310776228 ^ (long)310776200);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)137711699 ^ (long)137711780);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)2075311404 ^ (long)2075311381);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-502540010 ^ (long)-502539789);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-731281164 ^ (long)-731281246);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1881838501 ^ (long)-1881838530);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)910446183 ^ (long)910446101);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-417877870 ^ (long)-417877885);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1570775289 ^ (long)-1570775146);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)500006153 ^ (long)500006285);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1641546405 ^ (long)-1641546261);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-42871021 ^ (long)-42870802);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1034021984 ^ (long)-1034021961);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1979024085 ^ (long)-1979023900);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)575858007 ^ (long)575858025);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1999711518 ^ (long)-1999711675);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1669103538 ^ (long)-1669103406);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-623636424 ^ (long)-623636382);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)2146939943 ^ (long)2146940139);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1935677173 ^ (long)1935677125);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)920688330 ^ (long)920688187);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1611508506 ^ (long)-1611508486);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-670639208 ^ (long)-670639210);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1080263009 ^ (long)1080263029);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)637223549 ^ (long)637223573);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-136883062 ^ (long)-136882953);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-92862348 ^ (long)-92862266);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1827234757 ^ (long)1827234796);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-214877724 ^ (long)-214877714);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1517796876 ^ (long)1517796922);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)309831600 ^ (long)309831455);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-91322728 ^ (long)-91322663);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)224075142 ^ (long)224075045);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1016372021 ^ (long)1016371972);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-753645365 ^ (long)-753645456);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)434370985 ^ (long)434370823);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-308191674 ^ (long)-308191743);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1460283856 ^ (long)-1460283696);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1679499753 ^ (long)1679499522);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)2098810213 ^ (long)2098810341);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)2111273895 ^ (long)2111273792);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1487110270 ^ (long)-1487110317);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1954915949 ^ (long)-1954916079);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1040381057 ^ (long)-1040380987);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-842005354 ^ (long)-842005380);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1113493207 ^ (long)-1113493127);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-55040014 ^ (long)-55040227);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)267244602 ^ (long)267244746);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1551885930 ^ (long)1551885917);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)293537722 ^ (long)293537664);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)888598430 ^ (long)888598376);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)2042646894 ^ (long)2042646805);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-112177154 ^ (long)-112177192);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-680585105 ^ (long)-680585145);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-652472838 ^ (long)-652472991);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-535752158 ^ (long)-535752161);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-203003212 ^ (long)-203003148);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)131620157 ^ (long)131620179);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)851257245 ^ (long)851257154);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-718525026 ^ (long)-718525019);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-867245575 ^ (long)-867245689);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1785061280 ^ (long)1785061220);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1443429885 ^ (long)1443429787);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1298979012 ^ (long)1298978883);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1808802939 ^ (long)-1808802941);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-299581336 ^ (long)-299581217);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)579111366 ^ (long)579111266);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)409118408 ^ (long)409118222);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)322740528 ^ (long)322740495);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1737854981 ^ (long)1737855057);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1856301214 ^ (long)-1856301137);
                    if (!0F.\u200f\u200d\u2002) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1389209573 ^ (long)1389209369);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)57657782 ^ (long)57657673)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)758558394 ^ (long)758534469)) >>> (int)((long)-686724443 ^ (long)-686724435)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-28321936 ^ (long)-28321936);
            if (!0F.\u200f\u200d\u2002) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-822553818 ^ (long)-822553820);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)30609324 ^ (long)30609327) | var5_6 << (int)((long)1075943348 ^ (long)1075943345)) ^ var3_4[var7_8]) & (int)((long)-1883978994 ^ (long)-1883978767);
                    if (0F.\u200f\u200d\u2002) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-293584419 ^ (long)-293584418) | var6_7 << (int)((long)-485178525 ^ (long)-485178522)) ^ var3_4[var7_8]) & (int)((long)-1008303541 ^ (long)-1008303436);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0F.e[var2_3] = new String(var3_4).intern();
        }
        return 0F.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public final void 8() {
        block3: {
            block2: {
                var1_1 = 0F.\u200f\u200d\u2002;
                if (var1_1 || var1_1) lbl-1000:
                // 9 sources

                {
                    return;
                }
                if (0F.3.s == null) break block2;
                if (var1_1) ** GOTO lbl-1000
                if (0F.3.r == null) break block2;
                if (var1_1 || var1_1) ** GOTO lbl-1000
                this.1 = System.currentTimeMillis();
                if (var1_1 || var1_1) ** GOTO lbl-1000
                if (!((String)this.0.0()).equals(0F.b((int)((long)-1311916163 ^ (long)1311908048), (int)((long)1100730317 ^ (long)1100737500)))) break block3;
                if (var1_1 || var1_1) ** GOTO lbl-1000
                ((3)0F.3.s.e.a()).setSendPackets((boolean)((long)-1012080382 ^ (long)-1012080382));
                if (var1_1) ** GOTO lbl-1000
                return;
            }
            if (var1_1) ** GOTO lbl-1000
            this.1((boolean)((long)522656166 ^ (long)522656166));
            if (var1_1) ** GOTO lbl-1000
        }
        if (!var1_1) ** break;
        ** while (true)
    }

    public 0F() {
        boolean bl = \u200f\u200d\u2002;
        super(0F.b((int)((long)-1129068572 ^ (long)1129076811), (int)((long)-1227197463 ^ (long)-1227206649)) /* "Blink" */, 0F.b((int)((long)-1699167162 ^ (long)1699175393), (int)((long)-616633009 ^ (long)616638040)) /* "Lag Switch" */);
        String[] stringArray = new String[(int)((long)814695653 ^ (long)814695655)];
        stringArray[(int)((long)-979978515 ^ (long)-979978515)] = 0F.b((int)((long)-237336737 ^ (long)237312242), (int)((long)282444427 ^ (long)282453658));
        stringArray[(int)((long)-1637911696 ^ (long)-1637911695)] = 0F.b((int)((long)1874821672 ^ (long)-1874846335), (int)((long)-1791486569 ^ (long)1791462484)) /* "Position" */;
        String[] stringArray2 = stringArray;
        34H h2 = (34H)((34H)((34H)this.0().5(0F.b((int)((long)-674723915 ^ (long)674699293), (int)((long)2113347979 ^ (long)2113370248)) /* "Type" */)).7(0F.b((int)((long)-803602601 ^ (long)803627249), (int)((long)-2093021630 ^ (long)2093018591)) /* "type" */)).1(0F.b((int)((long)1914848332 ^ (long)-1914840089), (int)((long)208157318 ^ (long)208174650)) /* "The type of packets to choke" */);
        ((34H)((34H)((34H)this.0().5(0F.b((int)((long)-674723915 ^ (long)674699293), (int)((long)2113347979 ^ (long)2113370248)) /* "Type" */)).7(0F.b((int)((long)-803602601 ^ (long)803627249), (int)((long)-2093021630 ^ (long)2093018591)) /* "type" */)).1(0F.b((int)((long)1914848332 ^ (long)-1914840089), (int)((long)208157318 ^ (long)208174650)) /* "The type of packets to choke" */)).3 = stringArray2;
        this.0 = (11)h2.5();
        this.4 = (1P)((34X)((34X)((34X)this.4().5(0F.b((int)((long)-1339907391 ^ (long)1339899247), (int)((long)-1922066137 ^ (long)1922042841)) /* "Show Player" */)).7(0F.b((int)((long)134460606 ^ (long)-134468844), (int)((long)-110141602 ^ (long)110152897)) /* "player" */)).1(0F.b((int)((long)1730161008 ^ (long)-1730169135), (int)((long)1467115934 ^ (long)-1467107671)) /* "Renders the player model that other players see" */)).5();
        this.2 = null;
        this.8 = new ArrayList<oj>();
        this.7 = new Listener(f -> {
            String string;
            boolean bl;
            block11: {
                block9: {
                    boolean bl2;
                    block10: {
                        bl2 = \u200f\u200d\u2002;
                        if (bl2 || bl2) break block9;
                        bl = ((String)this.0.0()).equals(0F.b((int)((long)304963166 ^ (long)-304954893), (int)((long)-1118099482 ^ (long)-1118108681)));
                        if (!bl) break block10;
                        if (bl2) break block9;
                        this.6 = System.currentTimeMillis() - this.1;
                        if (bl2) break block9;
                    }
                    if (!bl2) break block11;
                }
                return;
            }
            String string2 = 0F.b((int)((long)-1374140554 ^ (long)1374148818), (int)((long)-704835170 ^ (long)704810077)) /* "suffix" */;
            StringBuilder stringBuilder = new StringBuilder().append(6C.5((double)this.6 / 1000.0)).append(2w$6X.KAOZ("\ucf62", -730076845));
            if (bl) {
                string = 2w$6X.KAOZ("", 1196082438);
                if (\u200f\u200d\u2002) {
                    throw null;
                }
            } else {
                string = 0F.b((int)((long)29983528 ^ (long)-30008179), (int)((long)867722192 ^ (long)867709205)) /* ", " */ + this.8.size() + 2w$6X.KAOZ("\udbcb", -1071448583);
            }
            2R.1(this, string2, stringBuilder.append(string).toString());
            if (this.2 == null && this.4.2) {
                this.2 = new 34I((bfw)0F.3.s);
                this.2.7((int)((long)1864815047 ^ (long)-1983245392));
            }
            if (this.2 != null && !this.4.2) {
                0F.3.r.d((int)((long)51467650 ^ (long)-436365323));
                this.2 = null;
            }
        }, new Predicate[(int)((long)1847728765 ^ (long)1847728765)]);
        Predicate[] predicateArray = new Predicate[(int)((long)-1853403888 ^ (long)-1853403887)];
        Class[] classArray = new Class[(int)((long)-1463809211 ^ (long)-1463809212)];
        classArray[(int)((long)-439291391 ^ (long)-439291391)] = st.class;
        predicateArray[(int)((long)-1605174926 ^ (long)-1605174926)] = new 34s(classArray);
        this.5 = new Listener(c2 -> {
            block6: {
                block2: {
                    boolean bl;
                    block3: {
                        block5: {
                            block4: {
                                bl = \u200f\u200d\u2002;
                                if (bl || bl) break block2;
                                if (!((String)this.0.0()).equals(0F.b((int)((long)-1244119860 ^ (long)1244111712), (int)((long)-933153752 ^ (long)-933148966)))) break block3;
                                if (bl || bl) break block2;
                                c2.cancel();
                                if (bl || bl) break block2;
                                if (0F.3.s.cD() != 0F.3.s.m) break block4;
                                if (bl) break block2;
                                if (0F.3.s.cH() != 0F.3.s.o) break block4;
                                if (bl) break block2;
                                if (0F.3.s.cE() == 0F.3.s.n) break block5;
                                if (bl) break block2;
                            }
                            if (bl) break block2;
                            this.6 += System.currentTimeMillis() - this.1;
                            if (bl || bl) break block2;
                            if (c2.7 == null) break block5;
                            if (bl || bl) break block2;
                            this.8.add(c2.7);
                            if (bl) break block2;
                        }
                        if (bl) break block2;
                        this.1 = System.currentTimeMillis();
                        if (bl) break block2;
                    }
                    if (!bl) break block6;
                }
                return;
            }
        }, predicateArray);
        this.9 = new Listener(j2 -> {
            block3: {
                block2: {
                    boolean bl = \u200f\u200d\u2002;
                    if (bl || bl) break block2;
                    this.1((boolean)((long)1224752560 ^ (long)1224752560));
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)-347513017 ^ (long)-347513017)]);
    }
}

