/* ==========================================================================
 * MODULE: Auto Tool
 * CATEGORY (inferred): Player
 * DESCRIPTION: Find the best tool for the job!
 * OBFUSCATED CLASS: net.impactclient.0o
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  bmb
 *  dcj
 *  dcl$a
 *  fx
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.2w;
import net.impactclient.2w$6X;
import net.impactclient.34G;
import net.impactclient.34R;
import net.impactclient.3X;
import net.impactclient.4f;
import net.impactclient.4s;
import net.impactclient.5y;
import net.impactclient.9N;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0o
extends 3X
implements 34R {
    private final 2w<bmb> 1;
    private static final String[] d;
    @EventHandler
    private final Listener<4f> 7;
    private final 34G 5;
    public static final boolean \u2007\u200a\u2008;
    private static final String[] e;
    private final 9N<Integer> 8;
    private fx 9;

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 0o.\u2007\u200a\u2008;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)-985473895 ^ (long)-985473893)];
            if (var7) break block16;
            var3_2 = (int)((long)-821892745 ^ (long)-821892745);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u2b7f\u03de\u1035\u1898\u2b97\u03d2\u10f3\u18bf\u2b76\u0342\u1082\u182b\u2b72\u03d7\u1023\u1814\u2b67\u032c\u104a\u18c5\u2bd6\u0342\u1039\u1813\u2bd4\u0383\u10c8\u1869\u2b50\u03bd\u100b\u183b\u2b25\u03a1\u1033\u1869\u2b78\u038d\u103c\u183b\u2be6", 1630866932);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)637121206 ^ (long)637121215);
            if (var7) break block16;
            var0_6 = (int)((long)-981798561 ^ (long)981798560);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)1059912983 ^ (long)-1059912984);
                if (0o.\u2007\u200a\u2008) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!0o.\u2007\u200a\u2008) continue block8;
                            throw null;
                        }
                        0o.d = var5_1;
                        0o.e = new String[(int)((long)-691287302 ^ (long)-691287304)];
                        if (!0o.\u2007\u200a\u2008) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)-1277938239 ^ (long)-1277938239);
                v5 = (int)((long)676818335 ^ (long)676818362);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)1249326466 ^ (long)1249326467)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-508420696 ^ (long)-508420689)) {
                                case 0: {
                                    v12 = (int)((long)-1300312884 ^ (long)-1300312958);
                                    if (!0o.\u2007\u200a\u2008) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)1650053594 ^ (long)1650053580);
                                    if (!0o.\u2007\u200a\u2008) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-1808132206 ^ (long)-1808132177);
                                    if (!0o.\u2007\u200a\u2008) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)-1962584466 ^ (long)-1962584508);
                                    if (!0o.\u2007\u200a\u2008) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)-165126164 ^ (long)-165126250);
                                    if (!0o.\u2007\u200a\u2008) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)1985356153 ^ (long)1985356113);
                                    if (!0o.\u2007\u200a\u2008) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-268117762 ^ (long)-268117816);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!0o.\u2007\u200a\u2008);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!0o.\u2007\u200a\u2008) ** continue;
                throw null;
            }
        }
    }

    public 0o() {
        boolean bl = \u2007\u200a\u2008;
        super(0o.b((int)((long)1767758427 ^ (long)1767746927), (int)((long)-697754423 ^ (long)-697732422)) /* "Auto Tool" */, 0o.b((int)((long)223674652 ^ (long)223704617), (int)((long)-1800293587 ^ (long)-1800281129)) /* "Find the best tool for the job!" */);
        this.8 = 4s.6();
        this.5 = 34G.5(this.8::8);
        Predicate[] predicateArray = new Predicate[(int)((long)1639881916 ^ (long)1639881917)];
        predicateArray[(int)((long)900710796 ^ (long)900710796)] = bmb2 -> {
            boolean bl = \u2007\u200a\u2008;
            if (bl || bl) return true;
            if (bmb2.a(0o.3.r.d_(this.9)) != 1.0f) {
                if (bl) return true;
                return (int)((long)-1317592045 ^ (long)-1317592046) != 0;
            }
            if (!bl) return (int)((long)882947968 ^ (long)882947968) != 0;
            return true;
        };
        Object object = predicateArray;
        5y y = new 5y();
        new 5y().1 = object;
        v1.4 = object = Comparator.comparingDouble(bmb2 -> {
            boolean bl = \u2007\u200a\u2008;
            if (bl || bl) {
                return 0.0;
            }
            return -bmb2.a(0o.3.r.d_(this.9));
        });
        this.1 = y.7();
        this.7 = new Listener(f -> {
            fx fx2;
            boolean bl = \u2007\u200a\u2008;
            if (bl || bl) return;
            if (0o.3.v == null) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            if (0o.3.v.c() == dcl.a.b) {
                if (bl) {
                    return;
                }
                fx2 = ((dcj)0o.3.v).a();
                if (\u2007\u200a\u2008) {
                    throw null;
                }
            } else {
                fx2 = null;
            }
            f = fx2;
            this.5.8();
            if (!0o.3.k.aq.d() || f == null) return;
            int n = this.7((fx)f);
            if (n < 0) {
                return;
            }
            this.8.accept(n);
            this.5.8 = (int)((long)-696957061 ^ (long)-696957062);
        }, new Predicate[(int)((long)1493956564 ^ (long)1493956564)]);
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0o.\u2007\u200a\u2008;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-144745328 ^ (long)-144757852)) & (int)((long)-1242341167 ^ (long)-1242325202);
            if (var9_2) ** GOTO lbl-1000
            if (0o.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0o.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)230997614 ^ (long)230997614)] & (int)((long)-543412602 ^ (long)-543412615)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-2111042450 ^ (long)-2111042418);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-484720817 ^ (long)-484720879);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-43123370 ^ (long)-43123353);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-921140614 ^ (long)-921140507);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1175764651 ^ (long)-1175764585);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-598106480 ^ (long)-598106411);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1090114627 ^ (long)1090114729);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-412761270 ^ (long)-412761278);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-315933513 ^ (long)-315933552);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)453191644 ^ (long)453191472);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)333711288 ^ (long)333711150);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1698069759 ^ (long)1698069539);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)901757472 ^ (long)901757462);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1170086862 ^ (long)-1170086796);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)279250176 ^ (long)279250431);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1679475298 ^ (long)-1679475302);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)2079035696 ^ (long)2079035725);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-674800730 ^ (long)-674800668);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-2018725502 ^ (long)-2018725515);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1823589866 ^ (long)-1823589758);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1180640187 ^ (long)-1180640237);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1952116679 ^ (long)1952116588);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1514390804 ^ (long)1514390785);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1150544972 ^ (long)-1150545063);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-663451929 ^ (long)-663452121);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)999457155 ^ (long)999457074);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)690766670 ^ (long)690766651);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1934969859 ^ (long)1934969908);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-2125123314 ^ (long)-2125123235);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)892830238 ^ (long)892830373);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1742174359 ^ (long)1742174364);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)932482912 ^ (long)932482921);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1641802615 ^ (long)-1641802527);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)250125549 ^ (long)250125346);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)67412986 ^ (long)67412799);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-614441584 ^ (long)-614441698);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-981594413 ^ (long)-981594407);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-2060384418 ^ (long)-2060384467);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1905286402 ^ (long)-1905286446);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1023487615 ^ (long)1023487527);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1888089087 ^ (long)-1888089052);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-799893372 ^ (long)-799893308);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)2107969600 ^ (long)2107969545);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1871755842 ^ (long)-1871755883);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1349275266 ^ (long)-1349275298);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1512203961 ^ (long)1512203969);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)2124115023 ^ (long)2124115030);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-540307387 ^ (long)-540307267);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)1635180299 ^ (long)1635180343);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1218253994 ^ (long)-1218253839);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1593878439 ^ (long)1593878368);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1837950034 ^ (long)1837950029);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1891486980 ^ (long)-1891486998);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1985060720 ^ (long)-1985060622);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1006895266 ^ (long)-1006895174);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)70581956 ^ (long)70581928);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-307465435 ^ (long)-307465362);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-322254774 ^ (long)-322254831);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1296981525 ^ (long)1296981575);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-706392513 ^ (long)-706392572);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)565814142 ^ (long)565814021);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1763039389 ^ (long)1763039248);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1441384408 ^ (long)1441384371);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1656036987 ^ (long)-1656037041);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1620654543 ^ (long)1620654337);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1201923453 ^ (long)1201923537);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)798500139 ^ (long)798500279);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1977143376 ^ (long)-1977143506);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1176778663 ^ (long)-1176778580);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1302607190 ^ (long)-1302607310);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-108955994 ^ (long)-108956000);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-740360055 ^ (long)-740360016);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1599517333 ^ (long)1599517407);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-14310203 ^ (long)-14310365);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)208461451 ^ (long)208461514);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)994660737 ^ (long)994660719);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)76945571 ^ (long)76945512);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1393465148 ^ (long)-1393465129);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1560238906 ^ (long)-1560239088);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1999815343 ^ (long)1999815239);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1447153037 ^ (long)-1447152980);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)2028874825 ^ (long)2028874867);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1588099964 ^ (long)1588100041);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-698314671 ^ (long)-698314508);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1691981884 ^ (long)1691982050);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1705122022 ^ (long)-1705121810);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1833297791 ^ (long)1833297794);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)960946982 ^ (long)960947111);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-506803677 ^ (long)-506803577);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1249270057 ^ (long)-1249270155);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)256496899 ^ (long)256497056);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)479093158 ^ (long)479093189);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-912826652 ^ (long)-912826850);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1891428204 ^ (long)-1891428133);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1870904158 ^ (long)1870904290);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1594765970 ^ (long)-1594765983);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1822518308 ^ (long)-1822518296);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-320352341 ^ (long)-320352487);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)202059260 ^ (long)202059224);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1258043939 ^ (long)1258043914);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-180751200 ^ (long)-180751153);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-2113749070 ^ (long)-2113749071);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1771372244 ^ (long)-1771372066);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1363363061 ^ (long)1363362943);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)115600101 ^ (long)115599926);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1186719312 ^ (long)1186719482);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1412421545 ^ (long)-1412421444);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)647610861 ^ (long)647610848);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-2105824478 ^ (long)-2105824277);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1665647731 ^ (long)-1665647680);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)39550159 ^ (long)39550111);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1012706590 ^ (long)1012706809);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)821079428 ^ (long)821079428);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1067657462 ^ (long)-1067657331);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)332395984 ^ (long)332395905);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1775880908 ^ (long)1775880946);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1915716686 ^ (long)1915716755);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1470077082 ^ (long)1470076941);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)2016351021 ^ (long)2016351188);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1824040804 ^ (long)-1824040865);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)274001272 ^ (long)274001256);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)2047909398 ^ (long)2047909581);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)775117844 ^ (long)775118037);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)872717433 ^ (long)872717558);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1716016478 ^ (long)1716016442);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)518868404 ^ (long)518868242);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1860715067 ^ (long)-1860715222);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)396086637 ^ (long)396086640);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-2069326536 ^ (long)-2069326513);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1513875993 ^ (long)1513876035);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)983706239 ^ (long)983706351);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1428260438 ^ (long)-1428260454);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1974813915 ^ (long)1974813873);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-692241041 ^ (long)-692241048);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1251237045 ^ (long)-1251237051);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-967031865 ^ (long)-967032063);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1679200011 ^ (long)1679200188);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1695011498 ^ (long)-1695011393);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1175222952 ^ (long)1175222830);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)521846239 ^ (long)521846134);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)842789527 ^ (long)842789388);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1924900517 ^ (long)-1924900602);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)420654859 ^ (long)420654890);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1151511472 ^ (long)-1151511322);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1426260960 ^ (long)1426260858);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1456323280 ^ (long)1456323212);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)214828554 ^ (long)214828760);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1141516876 ^ (long)-1141516948);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-967892744 ^ (long)-967892842);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-642291029 ^ (long)-642291014);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)271076393 ^ (long)271076567);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-205774034 ^ (long)-205773854);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-73807753 ^ (long)-73807783);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1301725769 ^ (long)1301725852);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1115091528 ^ (long)-1115091604);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1178145797 ^ (long)1178145980);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1076767404 ^ (long)-1076767344);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)762077112 ^ (long)762076930);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1338430880 ^ (long)-1338430894);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1389944576 ^ (long)-1389944349);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)514090611 ^ (long)514090626);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1635548419 ^ (long)1635548449);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1046483775 ^ (long)1046483798);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-350245518 ^ (long)-350245470);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)2032204960 ^ (long)2032204952);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)772835565 ^ (long)772835444);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)895458160 ^ (long)895458146);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)363574242 ^ (long)363574160);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1166680025 ^ (long)-1166680021);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1844170091 ^ (long)-1844170004);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1673844542 ^ (long)-1673844649);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-547576740 ^ (long)-547576788);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-976057015 ^ (long)-976057032);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1475055448 ^ (long)1475055399);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1297081244 ^ (long)-1297081296);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)558071897 ^ (long)558072039);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1571909009 ^ (long)1571908910);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)970663620 ^ (long)970663621);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1258401033 ^ (long)-1258401185);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)2027780338 ^ (long)2027780161);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1415456479 ^ (long)1415456349);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-414043941 ^ (long)-414043932);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)861895353 ^ (long)861895234);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-404264394 ^ (long)-404264256);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)749019229 ^ (long)749019207);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-314069658 ^ (long)-314069572);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)625988532 ^ (long)625988373);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1531853311 ^ (long)-1531853209);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1718162933 ^ (long)1718162801);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-151511913 ^ (long)-151511845);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)2021033182 ^ (long)2021033019);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1628474967 ^ (long)-1628474964);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-8959887 ^ (long)-8959778);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)345945470 ^ (long)345945586);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1772348119 ^ (long)-1772347920);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1438281297 ^ (long)1438281445);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1096341975 ^ (long)-1096342010);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-2060640153 ^ (long)-2060640237);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)461792898 ^ (long)461792769);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1320141812 ^ (long)-1320141788);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-539678946 ^ (long)-539678878);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1364609083 ^ (long)-1364609194);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1460636864 ^ (long)1460636858);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1502739392 ^ (long)-1502739452);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1230048548 ^ (long)1230048660);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)928545996 ^ (long)928545890);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-942524070 ^ (long)-942524048);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)346063218 ^ (long)346063295);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1132760077 ^ (long)-1132760144);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1430464990 ^ (long)1430464847);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)2139921780 ^ (long)2139921768);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)209142599 ^ (long)209142759);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)121142086 ^ (long)121142228);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)228811030 ^ (long)228811096);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1604690849 ^ (long)-1604690846);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1529207078 ^ (long)1529207161);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1816097584 ^ (long)1816097723);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1588300563 ^ (long)-1588300699);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1530419049 ^ (long)-1530419093);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)353516762 ^ (long)353516639);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1536964906 ^ (long)-1536965034);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1929168778 ^ (long)1929168879);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1749720897 ^ (long)-1749721034);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)776799195 ^ (long)776799158);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)167023579 ^ (long)167023400);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1761255272 ^ (long)-1761255344);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)49005302 ^ (long)49005062);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1855865753 ^ (long)1855865678);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1352246499 ^ (long)1352246402);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1049273968 ^ (long)-1049273865);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1593989975 ^ (long)1593990122);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1937496793 ^ (long)1937496770);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1118972335 ^ (long)-1118972316);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-3349898 ^ (long)-3349918);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1209848272 ^ (long)-1209848200);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1713064310 ^ (long)-1713064196);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)472580786 ^ (long)472580778);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)198508377 ^ (long)198508475);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)799641418 ^ (long)799641499);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1024299515 ^ (long)1024299513);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)394447544 ^ (long)394447381);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)816369596 ^ (long)816369602);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)914181173 ^ (long)914181139);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1672107930 ^ (long)1672107983);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)2044835853 ^ (long)2044835930);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1671352595 ^ (long)-1671352640);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)520989498 ^ (long)520989607);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1950615327 ^ (long)-1950615342);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-516851217 ^ (long)-516851215);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1653838532 ^ (long)-1653838460);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1980806947 ^ (long)-1980807036);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1917101919 ^ (long)-1917101887);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-589570087 ^ (long)-589570098);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1636257071 ^ (long)1636257128);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1104376600 ^ (long)-1104376823);
                    if (!0o.\u2007\u200a\u2008) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1659189398 ^ (long)-1659189431);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-276703492 ^ (long)-276703741)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1947203100 ^ (long)1947142627)) >>> (int)((long)-1255714351 ^ (long)-1255714343)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)199686360 ^ (long)199686360);
            if (!0o.\u2007\u200a\u2008) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)2110495617 ^ (long)2110495619);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-883487762 ^ (long)-883487763) | var5_6 << (int)((long)-66178093 ^ (long)-66178090)) ^ var3_4[var7_8]) & (int)((long)1630545853 ^ (long)1630545730);
                    if (0o.\u2007\u200a\u2008) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-486513518 ^ (long)-486513519) | var6_7 << (int)((long)875956311 ^ (long)875956306)) ^ var3_4[var7_8]) & (int)((long)1239936618 ^ (long)1239936661);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0o.e[var2_3] = new String(var3_4).intern();
        }
        return 0o.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    public final int 7(fx fx2) {
        block3: {
            block2: {
                boolean bl = \u2007\u200a\u2008;
                if (bl || bl) break block2;
                this.9 = fx2;
                if (!bl && !bl) break block3;
            }
            return -1895641981;
        }
        return this.1.0((List<bmb>)0o.3.s.bm.a);
    }
}

