/* ==========================================================================
 * MODULE: Middle Click Friend
 * CATEGORY (inferred): Player
 * DESCRIPTION: Middle clicking players will add them as a friend.
 * OBFUSCATED CLASS: net.impactclient.09
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  bfw
 *  dck
 *  dcl$a
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.20;
import net.impactclient.2O;
import net.impactclient.2k;
import net.impactclient.2s;
import net.impactclient.2w$6X;
import net.impactclient.3X;
import net.impactclient.3s0;
import net.impactclient.5z;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 09
extends 3X
implements 3s0 {
    private static final String[] e;
    public static final boolean \u2000\u200d\u200a\u2007\u2001;
    private static final String[] d;
    @EventHandler
    private final Listener<2k> 1;

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 09.\u2000\u200d\u200a\u2007\u2001;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)352590897 ^ (long)352590899)];
            if (var7) break block16;
            var3_2 = (int)((long)-1111666331 ^ (long)-1111666331);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u0516\u2d7c\u3e26\u36e5\u0512\u2db3\u3e07\u36e2\u05d5\u2df8\u3e95\u3615\u050d\u2de4\u3e0e\u3671\u056c\u2d2b\u3ee2\u369b\u0577\u2dbd\u3e0a\u36dd\u0597\u2db4\u3eb7\u3622\u05c3\u2dc4\u3e57\u3692\u051c\u2d3c\u3e59\u360e\u0524\u2da6\u3e59\u36ab\u0517\u2d2a\u3eb5\u36da\u05e1\u2d56\u3ec9\u3681\u0591\u2ddf\u3e16\u3698\u0558\u2d0d\u3ec3\u3620\u050d\u2d0b\u3ead\u3613\u0548\u2d18\u3ef4\u3622\u053c\u2da8\u3e1c\u36d8\u053a\u2ded", 446964584);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)-1263907289 ^ (long)-1263907276);
            if (var7) break block16;
            var0_6 = (int)((long)1431514632 ^ (long)-1431514633);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)604104197 ^ (long)-604104198);
                if (09.\u2000\u200d\u200a\u2007\u2001) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!09.\u2000\u200d\u200a\u2007\u2001) continue block8;
                            throw null;
                        }
                        09.d = var5_1;
                        09.e = new String[(int)((long)766225494 ^ (long)766225492)];
                        if (!09.\u2000\u200d\u200a\u2007\u2001) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)-736120376 ^ (long)-736120376);
                v5 = (int)((long)-857617109 ^ (long)-857617085);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)1970242428 ^ (long)1970242429)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)112979318 ^ (long)112979313)) {
                                case 0: {
                                    v12 = (int)((long)-225475370 ^ (long)-225475426);
                                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)-1733196691 ^ (long)-1733196775);
                                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)2089371270 ^ (long)2089371384);
                                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)-353547931 ^ (long)-353547947);
                                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)-420333569 ^ (long)-420333599);
                                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)-624764230 ^ (long)-624764241);
                                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-2121380401 ^ (long)-2121380453);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!09.\u2000\u200d\u200a\u2007\u2001);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!09.\u2000\u200d\u200a\u2007\u2001) ** continue;
                throw null;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 09.\u2000\u200d\u200a\u2007\u2001;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-665067353 ^ (long)-665071021)) & (int)((long)1519751429 ^ (long)1519742714);
            if (var9_2) ** GOTO lbl-1000
            if (09.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 09.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-489687332 ^ (long)-489687332)] & (int)((long)-1963774000 ^ (long)-1963774161)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1427868632 ^ (long)-1427868629);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1153040089 ^ (long)-1153040044);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1258310061 ^ (long)-1258309940);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)591799301 ^ (long)591799540);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1976216563 ^ (long)-1976216569);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1063153496 ^ (long)-1063153478);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1952355266 ^ (long)1952355169);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-543609484 ^ (long)-543609374);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1106827533 ^ (long)1106827667);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-457736165 ^ (long)-457735983);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)545225848 ^ (long)545225976);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1100532751 ^ (long)-1100532834);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1603275007 ^ (long)-1603274942);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)457847830 ^ (long)457847928);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1497641753 ^ (long)1497641838);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-372659462 ^ (long)-372659574);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-852908244 ^ (long)-852908261);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1996846949 ^ (long)-1996847081);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)436237667 ^ (long)436237732);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1032850013 ^ (long)1032850042);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-781057037 ^ (long)-781057237);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1919171602 ^ (long)1919171770);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-607127217 ^ (long)-607127232);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)174452477 ^ (long)174452356);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)912394815 ^ (long)912394850);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1147279281 ^ (long)-1147279249);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)247148387 ^ (long)247148363);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1397956894 ^ (long)1397956917);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1132280713 ^ (long)-1132280642);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)18585917 ^ (long)18586024);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)813132049 ^ (long)813132157);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)686928505 ^ (long)686928617);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1405736245 ^ (long)1405736371);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)689261271 ^ (long)689261266);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)576701589 ^ (long)576701631);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1099211411 ^ (long)-1099211332);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-484619156 ^ (long)-484619027);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-809534475 ^ (long)-809534628);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)54219429 ^ (long)54219313);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)188820984 ^ (long)188820849);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1673647950 ^ (long)1673647970);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1689775636 ^ (long)-1689775747);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)25811040 ^ (long)25810996);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)295116827 ^ (long)295116963);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)898327965 ^ (long)898328028);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-339336151 ^ (long)-339336114);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1765425630 ^ (long)1765425489);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-67322716 ^ (long)-67322866);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-801993062 ^ (long)-801993076);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-2034267025 ^ (long)-2034267023);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1826370365 ^ (long)-1826370341);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1303403095 ^ (long)-1303403160);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)496656715 ^ (long)496656879);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1307497486 ^ (long)-1307497715);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-170869012 ^ (long)-170869003);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1481117939 ^ (long)-1481117752);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1584606434 ^ (long)1584606457);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)752196471 ^ (long)752196556);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-213331502 ^ (long)-213331532);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)463209934 ^ (long)463209901);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1042449492 ^ (long)1042449505);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-324761062 ^ (long)-324760875);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1596118765 ^ (long)1596118604);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1144498026 ^ (long)-1144497969);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1565522202 ^ (long)-1565522424);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-267111063 ^ (long)-267111079);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1176679598 ^ (long)1176679593);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)720155146 ^ (long)720155388);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1326085123 ^ (long)-1326085185);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)204255297 ^ (long)204255414);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1308216935 ^ (long)-1308216952);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1221410375 ^ (long)1221410433);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1463035712 ^ (long)1463035773);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-2123143702 ^ (long)-2123143838);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1524807426 ^ (long)-1524807604);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-71311549 ^ (long)-71311372);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1841326312 ^ (long)1841326100);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1246755807 ^ (long)-1246755627);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-801811733 ^ (long)-801811761);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1291208390 ^ (long)1291208447);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-804774753 ^ (long)-804774860);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)3293348 ^ (long)3293323);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1262696064 ^ (long)1262696084);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-2115586779 ^ (long)-2115586562);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)261303041 ^ (long)261303171);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1657503813 ^ (long)1657503909);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-806173638 ^ (long)-806173533);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)666435750 ^ (long)666435789);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1759805474 ^ (long)-1759805633);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1914261518 ^ (long)1914261628);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)354487632 ^ (long)354487559);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1949795404 ^ (long)-1949795421);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1906372536 ^ (long)1906372394);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1995774368 ^ (long)-1995774376);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)957722469 ^ (long)957722459);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-2026652258 ^ (long)-2026652376);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1267389004 ^ (long)-1267389121);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1563696133 ^ (long)1563696325);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)151692392 ^ (long)151692324);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-2136020272 ^ (long)-2136020438);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1078114877 ^ (long)1078115002);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-330251557 ^ (long)-330251719);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-2059252137 ^ (long)-2059252068);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1604916728 ^ (long)1604916493);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)872005220 ^ (long)872005313);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1571071318 ^ (long)-1571071407);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)2140351754 ^ (long)2140351890);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1531680331 ^ (long)1531680331);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-743012442 ^ (long)-743012604);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1618918663 ^ (long)1618918770);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)769552982 ^ (long)769552935);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-800182129 ^ (long)-800182177);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-364305387 ^ (long)-364305272);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1069701882 ^ (long)-1069701830);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1791753559 ^ (long)1791753549);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)203310154 ^ (long)203310314);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1055518529 ^ (long)1055518491);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1113086806 ^ (long)1113086852);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1097727312 ^ (long)-1097727240);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-656956706 ^ (long)-656956762);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1362587768 ^ (long)1362587741);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-2113593320 ^ (long)-2113593324);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-2010425671 ^ (long)-2010425836);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-390114863 ^ (long)-390115066);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1409779730 ^ (long)1409779959);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)229663403 ^ (long)229663391);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)656542340 ^ (long)656542346);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1153687156 ^ (long)1153687147);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-573180982 ^ (long)-573181001);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-146677188 ^ (long)-146677055);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-333856307 ^ (long)-333856330);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1468000745 ^ (long)1468000602);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1702346044 ^ (long)-1702346084);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-2141241850 ^ (long)-2141241808);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)205053412 ^ (long)205053413);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)2040158754 ^ (long)2040158808);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)649648104 ^ (long)649648010);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-2056228972 ^ (long)-2056228955);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1579845052 ^ (long)1579845105);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-2113484114 ^ (long)-2113484231);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)628893612 ^ (long)628893557);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1805100927 ^ (long)1805100978);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)2145088509 ^ (long)2145088328);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1501425784 ^ (long)-1501425838);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1867246276 ^ (long)1867246187);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1590961797 ^ (long)1590961893);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1778730897 ^ (long)-1778730932);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)956487029 ^ (long)956487114);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1356626095 ^ (long)1356626027);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)270068079 ^ (long)270068156);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1937411629 ^ (long)1937411687);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-516743076 ^ (long)-516743087);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1327845730 ^ (long)1327845863);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1281439481 ^ (long)1281439261);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1258794079 ^ (long)-1258794052);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-675891203 ^ (long)-675891278);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)346010991 ^ (long)346011065);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1843844333 ^ (long)-1843844349);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1852973585 ^ (long)-1852973789);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-797955077 ^ (long)-797955195);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1011359454 ^ (long)-1011359254);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-14171357 ^ (long)-14171387);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1032902859 ^ (long)1032902889);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-281472286 ^ (long)-281472495);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-39191445 ^ (long)-39191403);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1008116208 ^ (long)1008116162);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1974919085 ^ (long)-1974918981);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-194757458 ^ (long)-194757590);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1169457586 ^ (long)1169457438);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1329338315 ^ (long)1329338184);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1891962119 ^ (long)1891962269);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1535242802 ^ (long)1535242851);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-504881558 ^ (long)-504881583);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1104933422 ^ (long)-1104933522);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1859769026 ^ (long)1859768971);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1417326309 ^ (long)1417326089);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1284175271 ^ (long)1284175189);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1031306857 ^ (long)1031306951);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)808353734 ^ (long)808353721);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1356675592 ^ (long)-1356675822);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1889374397 ^ (long)1889374376);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1763459563 ^ (long)-1763459406);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-931263780 ^ (long)-931263898);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-768188308 ^ (long)-768188347);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1242478086 ^ (long)1242478319);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)180133743 ^ (long)180133819);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-844751872 ^ (long)-844751868);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1953557515 ^ (long)-1953557728);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-719092590 ^ (long)-719092607);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)260119021 ^ (long)260118813);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1218151951 ^ (long)1218152026);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-533253605 ^ (long)-533253519);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1030034979 ^ (long)-1030035152);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1793947293 ^ (long)-1793947260);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1674925885 ^ (long)1674925942);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)218859981 ^ (long)218859979);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-570663849 ^ (long)-570663798);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)62350963 ^ (long)62351097);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1061647640 ^ (long)1061647655);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1104676365 ^ (long)1104676480);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1778670084 ^ (long)1778670256);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)129326926 ^ (long)129326878);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)908900873 ^ (long)908900961);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1317160561 ^ (long)-1317160543);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-2028414559 ^ (long)-2028414646);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-108594567 ^ (long)-108594621);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-757519223 ^ (long)-757519211);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1815412994 ^ (long)-1815413062);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1058055240 ^ (long)-1058055211);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1579884733 ^ (long)-1579884640);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1416527341 ^ (long)-1416527203);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)504651376 ^ (long)504651326);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-798485400 ^ (long)-798485407);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)661613104 ^ (long)661613073);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1999727530 ^ (long)1999727563);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)3153800 ^ (long)3153870);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1812874907 ^ (long)-1812875008);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)995554738 ^ (long)995554756);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1719050231 ^ (long)1719050025);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)207116926 ^ (long)207116961);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)722496667 ^ (long)722496628);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)749413223 ^ (long)749413279);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-482554261 ^ (long)-482554155);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)454871097 ^ (long)454871138);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)266287269 ^ (long)266287278);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1863025697 ^ (long)-1863025738);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1725113604 ^ (long)-1725113694);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)210041482 ^ (long)210041480);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1799391830 ^ (long)1799391766);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)550097576 ^ (long)550097655);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-249951479 ^ (long)-249951371);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)226841287 ^ (long)226841216);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1788773248 ^ (long)-1788773338);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-915051308 ^ (long)-915051498);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-648842827 ^ (long)-648843000);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)201666085 ^ (long)201666163);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)113379599 ^ (long)113379777);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-15826383 ^ (long)-15826296);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-655779416 ^ (long)-655779424);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)674088087 ^ (long)674088163);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-2057221950 ^ (long)-2057221978);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)505435858 ^ (long)505435721);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1595198397 ^ (long)-1595198222);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-48517588 ^ (long)-48517476);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1868224037 ^ (long)-1868224249);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)737686161 ^ (long)737686018);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)920936695 ^ (long)920936613);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1190378423 ^ (long)1190378283);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1516413453 ^ (long)-1516413536);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-692195433 ^ (long)-692195381);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)2137012139 ^ (long)2137012045);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1182187928 ^ (long)-1182187861);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1624728815 ^ (long)1624728770);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)689910626 ^ (long)689910567);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1776117948 ^ (long)-1776117897);
                    if (!09.\u2000\u200d\u200a\u2007\u2001) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1383222752 ^ (long)1383222553);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1939951273 ^ (long)1939951190)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-90468708 ^ (long)-90476189)) >>> (int)((long)-695701863 ^ (long)-695701871)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)2015758563 ^ (long)2015758563);
            if (!09.\u2000\u200d\u200a\u2007\u2001) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)818845734 ^ (long)818845732);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1063852850 ^ (long)-1063852851) | var5_6 << (int)((long)890372308 ^ (long)890372305)) ^ var3_4[var7_8]) & (int)((long)-1087483112 ^ (long)-1087482905);
                    if (09.\u2000\u200d\u200a\u2007\u2001) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-941207602 ^ (long)-941207603) | var6_7 << (int)((long)-1964845067 ^ (long)-1964845072)) ^ var3_4[var7_8]) & (int)((long)799666563 ^ (long)799666556);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            09.e[var2_3] = new String(var3_4).intern();
        }
        return 09.e[var2_3];
    }

    public 09() {
        boolean bl = \u2000\u200d\u200a\u2007\u2001;
        super(09.b((int)((long)-1180738800 ^ (long)-1180735004), (int)((long)1251591723 ^ (long)-1251602931)) /* "Middle Click Friend" */, 09.b((int)((long)-1926167582 ^ (long)-1926156009), (int)((long)1728576694 ^ (long)-1728547471)) /* "Middle clicking players will add them as a friend." */);
        this.1 = new Listener(object -> {
            boolean bl;
            block21: {
                block20: {
                    block19: {
                        block18: {
                            bl = \u2000\u200d\u200a\u2007\u2001;
                            if (bl || bl) return;
                            if (((2s)object).4 != (int)((long)-635435539 ^ (long)-635435540)) break block18;
                            if (bl) return;
                            if (((2s)object).2 == (int)((long)1848882178 ^ (long)1848882176)) break block19;
                            if (bl) return;
                        }
                        if (bl) return;
                        return;
                    }
                    if (bl) return;
                    if (09.3.v == null) break block20;
                    if (bl) return;
                    if (09.3.v.c() == dcl.a.c) break block21;
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            object = ((dck)09.3.v).a();
            if (!(object instanceof bfw)) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            20 var1_2 = 5z.4().1;
            if (bl || bl) return;
            object = object.R().getString();
            if (bl || bl) return;
            if (!var1_2.8((String)object)) {
                if (bl || bl) return;
                Object object2 = object;
                var1_2.8(new 2O((String)object2, (String)object2));
                if (bl) return;
                return;
            }
            if (bl) return;
            var1_2.1((String)object);
            if (!bl && !bl) return;
        }, new Predicate[(int)((long)1567304816 ^ (long)1567304816)]);
    }
}

