/* ==========================================================================
 * MODULE: Nametags
 * CATEGORY (inferred): Render
 * DESCRIPTION: Replaces Vanilla Nametags with more detailed ones
 * OBFUSCATED CLASS: net.impactclient.7G
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aft
 *  aot
 *  aqa
 *  aqm
 *  are
 *  bbb
 *  bcv
 *  bfw
 *  bmb
 *  bps
 *  com.mojang.blaze3d.systems.RenderSystem
 *  ddl
 *  dem$j
 *  dem$r
 *  dfm
 *  dku
 *  dzm
 *  gm
 *  k
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  nr
 *  oe
 *  org.apache.commons.lang3.StringUtils
 *  pw.knx.feather.structures.Color
 *  rn
 *  vk
 */
package net.impactclient;

import clientapi.load.mixin.7.2;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.lang.invoke.LambdaMetafactory;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import me.zero.clarinet.hook.mixin.accessor.AccessorFontRenderer;
import net.impactclient.1D;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.1m;
import net.impactclient.1q;
import net.impactclient.2L;
import net.impactclient.2_;
import net.impactclient.2a;
import net.impactclient.2b;
import net.impactclient.2n;
import net.impactclient.2r;
import net.impactclient.2w$6X;
import net.impactclient.34D;
import net.impactclient.34J;
import net.impactclient.34L;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.34f;
import net.impactclient.34n;
import net.impactclient.34s;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3i;
import net.impactclient.3sC;
import net.impactclient.3sY;
import net.impactclient.5z;
import net.impactclient.62;
import net.impactclient.6J;
import net.impactclient.6L;
import net.impactclient.87;
import net.impactclient.8S;
import net.impactclient.8W;
import net.impactclient.8h;
import net.impactclient.94;
import net.impactclient.9K;
import net.impactclient.9b;
import net.impactclient.9k;
import org.apache.commons.lang3.StringUtils;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7G
extends 3X
implements 8h {
    private 1P 7d;
    private 1P 7k;
    private 1P 7p;
    private 1P 7l;
    private 1P 7i;
    private 1P 5;
    private 1P 6;
    @EventHandler
    private final Listener<3i> 7I;
    @EventHandler
    private final Listener<2r> 7;
    private static final String[] e;
    private 1P 7s;
    @EventHandler
    private final Listener<1q> 75;
    private static final String[] d;
    public static final boolean \u2005\u2000\u2006;
    private 1P 7c;
    private 1P 9;
    private 1K 74;
    private final List<1D> 76;
    private 1K 7g;
    private 1P 78;
    private 1m<3sY> 0;
    private dku 8;
    private 1K 1;
    private 1P 7B;
    private 1P 2;
    private 1K 7V;
    private 1K 4;
    private 1P 7z;
    private 1P 72;
    private 1P 7j;

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private /* synthetic */ void 1(2r var1_1, dfm var2_4, bfw var3_5) {
        block57: {
            block56: {
                var17_6 = 7G.\u2005\u2000\u2006;
                if (var17_6) lbl-1000:
                // 6 sources

                {
                    return;
                }
                var4_7 = 3e.5();
                if (var17_6 || var17_6) ** GOTO lbl-1000
                v0 = ((2)var3_5).interpolate(var1_1.3());
                v1 = (double)var3_5.cz() + 0.3;
                if (var3_5.bz()) {
                    v2 = 0.3;
                    if (7G.\u2005\u2000\u2006) {
                        throw null;
                    }
                } else {
                    v2 = 0.0;
                }
                if (!(var6_11 /* !! */  = (2L)LambdaMetafactory.metafactory(null, null, null, ()Lnet/impactclient/8S;, 0(net.impactclient.8S ), ()Lnet/impactclient/8S;)((8S)(var5_8 = v0.7(0.0, v1 - v2, 0.0))).3()).isPresent()) {
                    return;
                }
                var6_11 /* !! */  = var6_11 /* !! */ .get();
                RenderSystem.pushMatrix();
                var1_2 = this.4(var5_8, var1_1.3(), this.7l.2);
                RenderSystem.translated((double)var6_11 /* !! */ .9, (double)(var6_11 /* !! */ .1 - (double)(11.0f * var1_2)), (double)0.0);
                RenderSystem.scaled((double)var1_2, (double)var1_2, (double)var1_2);
                v3 = new oe(2w$6X.KAOZ("", -1451439052));
                var14_12 /* !! */  = var3_5;
                var7_14 /* !! */  = new oe(2w$6X.KAOZ("", -297627794));
                if (5z.4().1.1(var14_12 /* !! */ .R().getString()) != null) {
                    v4 = new k[(int)((long)229856545 ^ (long)229856544)];
                    v4[(int)((long)-1419375503 ^ (long)-1419375503)] = k.d;
                    var6_11 /* !! */  = v4;
                    v5 = new 3sC().2(2w$6X.KAOZ("\udf84", -630785853), null, (k[])var6_11 /* !! */ );
                    v6 = new k[(int)((long)-1500657533 ^ (long)-1500657534)];
                    v6[(int)((long)1172532356 ^ (long)1172532356)] = k.l;
                    var6_11 /* !! */  = v6;
                    v7 = v5.2(2w$6X.KAOZ("\u7794", 1341739214), null, (k[])var6_11 /* !! */ );
                    v8 = new k[(int)((long)-1944863461 ^ (long)-1944863462)];
                    v8[(int)((long)-714744859 ^ (long)-714744859)] = k.d;
                    var6_11 /* !! */  = v8;
                    var7_14 /* !! */ .a((nr)v7.2((String)7G.b((int)((int)((long)-1361644327 ^ (long)1361657231)), (int)((int)((long)231536062 ^ (long)-231518823))), null, (k[])var6_11 /* !! */ ).7);
                }
                v9 = v3.a((nr)var7_14 /* !! */ );
                var6_11 /* !! */  = var3_5;
                var14_12 /* !! */  = this;
                var7_14 /* !! */  = new oe(2w$6X.KAOZ("", 1644347254));
                var8_17 = 7G.3.w();
                if (var14_12 /* !! */ .7c.2 && var8_17 != null) {
                    var5_8 = var8_17.a(var6_11 /* !! */ .bS());
                    if (var5_8 == null) {
                        v10 = new oe(7G.b((int)((long)-1798690419 ^ (long)1798693118), (int)((long)-1406580495 ^ (long)1406598978)) /* "Bot" */);
                        if (7G.\u2005\u2000\u2006) {
                            throw null;
                        }
                    } else {
                        var5_8 = var5_8.b();
                        switch (87.7[var5_8.ordinal()]) {
                            case 1: {
                                v11 = 2w$6X.KAOZ("\u2e23", -558626484);
                                if (!7G.\u2005\u2000\u2006) break;
                                throw null;
                            }
                            case 2: {
                                v11 = 2w$6X.KAOZ("\uefb0", 1188677839);
                                if (!7G.\u2005\u2000\u2006) break;
                                throw null;
                            }
                            case 3: {
                                v11 = 2w$6X.KAOZ("\ucae6", 123989403);
                                if (!7G.\u2005\u2000\u2006) break;
                                throw null;
                            }
                            case 4: {
                                v11 = 7G.b((int)((long)722362439 ^ (long)-722360038), (int)((long)-957222619 ^ (long)957250268)) /* "sp" */;
                                if (!7G.\u2005\u2000\u2006) break;
                                throw null;
                            }
                            default: {
                                v11 = 7G.b((int)((long)1202919826 ^ (long)-1202925376), (int)((long)-718111249 ^ (long)718123760)) /* "unset" */;
                            }
                        }
                        v10 = new oe(StringUtils.capitalize((String)v11));
                    }
                    var6_11 /* !! */  = v10;
                    v10.a(k.h);
                    var7_14 /* !! */ .c(2w$6X.KAOZ("\u9fda", -257312611));
                    var7_14 /* !! */ .a((nr)var6_11 /* !! */ );
                    var7_14 /* !! */ .c(7G.b((int)((long)-769899531 ^ (long)769886899), (int)((long)-1041327637 ^ (long)-1041330130)) /* "] " */);
                    var7_14 /* !! */ .a(k.i);
                }
                v12 = v9.a((nr)var7_14 /* !! */ );
                var6_11 /* !! */  = var3_5;
                var14_12 /* !! */  = this;
                var7_14 /* !! */  = new oe(2w$6X.KAOZ("", 1400024739));
                if (var14_12 /* !! */ .7B.2 && (var8_17 = var6_11 /* !! */ .bG()) instanceof ddl) {
                    var7_14 /* !! */ .a(((ddl)var8_17).e());
                }
                var1_3 = v12.a((nr)var7_14 /* !! */ );
                var14_12 /* !! */  = var3_5;
                var7_14 /* !! */  = var14_12 /* !! */ .R().getString();
                var8_17 = 2a.2((bfw)var14_12 /* !! */ );
                var5_8 = var14_12 /* !! */ .bG();
                var6_11 /* !! */  = 5z.4().1.1((String)var7_14 /* !! */ );
                if (var8_17.4().9().isPresent()) {
                    var6_11 /* !! */  = k.v;
                    if (7G.\u2005\u2000\u2006) {
                        throw null;
                    }
                } else if (var6_11 /* !! */  != null) {
                    var6_11 /* !! */  = k.l;
                    if (7G.\u2005\u2000\u2006) {
                        throw null;
                    }
                } else if (var5_8 != null) {
                    var6_11 /* !! */  = var5_8.n();
                    if (7G.\u2005\u2000\u2006) {
                        throw null;
                    }
                } else {
                    var6_11 /* !! */  = k.h;
                }
                var5_8 = new oe((String)var7_14 /* !! */ );
                var5_8.a((k)var6_11 /* !! */ );
                var6_11 /* !! */  = var3_5;
                var14_12 /* !! */  = this;
                var7_14 /* !! */  = new oe(2w$6X.KAOZ("", -572524931));
                if (var14_12 /* !! */ .7B.2 && (var8_17 = var6_11 /* !! */ .bG()) instanceof ddl) {
                    var7_14 /* !! */ .a(((ddl)var8_17).f());
                }
                var6_11 /* !! */  = var7_14 /* !! */ ;
                var7_15 = Math.round(var3_5.dk());
                var8_18 = (int)((long)988021010 ^ (long)988021010);
                try {
                    var8_18 = Math.round(var3_5.dT());
                    ** if (!7G.\u2005\u2000\u2006) goto lbl-1000
                }
                catch (Exception v13) {
                    if (var17_6) ** GOTO lbl-1000
                }
lbl-1000:
                // 1 sources

                {
                    throw null;
                }
lbl-1000:
                // 1 sources

                {
                }
                if (var17_6) ** GOTO lbl-1000
                if (!this.72.2) ** GOTO lbl-1000
                if (var17_6) ** GOTO lbl-1000
                if (var8_18 != 0) {
                    if (!var17_6) ** break;
                    ** continue;
                    v14 = var7_15 + 2w$6X.KAOZ("\u5446", 1233941361) + var8_18;
                    if (7G.\u2005\u2000\u2006) {
                        throw null;
                    }
                } else lbl-1000:
                // 2 sources

                {
                    v14 = "" + (var7_15 + var8_18);
                }
                var7_16 = v14;
                var8_19 = 2a.2((bfw)var3_5).4();
                var14_12 /* !! */  = var8_19;
                if (var8_19.7 == null || var14_12 /* !! */ .7.isEmpty()) {
                    v15 /* !! */  = Optional.empty();
                    if (7G.\u2005\u2000\u2006) {
                        throw null;
                    }
                } else {
                    v15 /* !! */  = var9_21 = Optional.ofNullable(6J.0(var14_12 /* !! */ .7, (boolean)((long)-2102336857 ^ (long)-2102336857)));
                }
                if (v15 /* !! */ .isPresent()) {
                    v16 = (int)((long)-2096067659 ^ (long)-2096067649);
                    if (7G.\u2005\u2000\u2006) {
                        throw null;
                    }
                } else {
                    v16 = var10_22 = (int)((long)-1913985944 ^ (long)-1913985944);
                }
                if (this.2.2) {
                    v17 = this.8.b(2w$6X.KAOZ("\u92ba", 344896902).concat(String.valueOf(var7_16)));
                    if (7G.\u2005\u2000\u2006) {
                        throw null;
                    }
                } else {
                    v17 = (int)((long)63592609 ^ (long)63592609);
                }
                var11_23 = v17;
                var12_24 = this.8.b(var1_3.getString());
                var13_25 = this.8.b(var5_8.getString());
                var14_13 = this.8.b(var6_11 /* !! */ .getString());
                var11_23 = (var12_24 + var13_25 + var14_13 + var11_23 + var10_22) / (int)((long)-675827570 ^ (long)-675827572);
                var14_13 = (int)var8_19.8;
                var15_26 = var8_19.9().orElse((int)((long)377165205 ^ (long)-377165206));
                var16_27 = var8_19.6().orElse(34L.3((int)((long)-819560511 ^ (long)-819560501), (int)((long)293950309 ^ (long)293950319), (int)((long)-129832323 ^ (long)-129832329), (int)((long)-1521970637 ^ (long)-1521970523)));
                var8_20 = var8_19.3().orElse(34L.3((int)((long)2094882247 ^ (long)2094882211), (int)((long)-564113405 ^ (long)-564113305), (int)((long)1544846125 ^ (long)1544846153), (int)((long)-1451083296 ^ (long)-1451083402)));
                9b.5((float)(-var11_23 - (int)((long)-1602766441 ^ (long)-1602766443)) - 1.5f, -2.5f, (float)(var11_23 + (int)((long)320269358 ^ (long)320269356)) + 1.5f, (float)((AccessorFontRenderer)this.8).getFontHeight() + 1.5f, 0.5f, var8_20, var16_27);
                RenderSystem.enableBlend();
                RenderSystem.blendFunc((dem.r)dem.r.l, (dem.j)dem.j.j);
                if (var9_21.isPresent()) {
                    this.8.getClass();
                    RenderSystem.pushMatrix();
                    RenderSystem.translated((double)0.0, (double)-0.5, (double)0.0);
                    2n.7((vk)var9_21.get(), -var11_23 - (int)((long)414791345 ^ (long)414791344), (int)((long)958380007 ^ (long)958380007), (int)((long)-492291706 ^ (long)-492291700));
                    RenderSystem.popMatrix();
                }
                this.8.a(var2_4, var1_3.getString(), (float)(-var11_23 + var10_22), 0.0f, (int)((long)2084701780 ^ (long)-2084701781));
                if (var14_13 == 0) break block56;
                this.8.a(var2_4, var5_8.getString(), (float)(-var11_23 + var10_22 + var12_24), 0.0f, var15_26);
                if (var4_7 == null) break block57;
            }
            this.8.b(var2_4, var5_8.getString(), (float)(-var11_23 + var10_22 + var12_24), 0.0f, var15_26);
        }
        this.8.a(var2_4, var6_11 /* !! */ .getString(), (float)(-var11_23 + var10_22 + var12_24 + var13_25), 0.0f, (int)((long)1035138016 ^ (long)-1035138017));
        RenderSystem.disableBlend();
        if (this.2.2) {
            this.8.a(var2_4, var7_16, (float)(var11_23 - this.8.b(var7_16)), 0.0f, 94.3((aqm)var3_5));
        }
        if (this.7j.2) {
            block55: {
                var1_3 = new ArrayList<E>();
                for (var5_9 = var3_5.bm.b.size() - (int)((long)217749967 ^ (long)217749966); var5_9 >= 0; --var5_9) {
                    v18 = (bmb)var3_5.bm.b.get(var5_9);
                    if (var4_7 == null) {
                        if (v18.a()) continue;
                        var1_3.add(var6_11 /* !! */ );
                        if (var4_7 == null) continue;
                    }
                    break block55;
                }
                v18 = var5_10 = var3_5.b(aot.b);
            }
            if (!v18.a()) {
                var1_3.add(var5_10);
            }
            if (!(var6_11 /* !! */  = var3_5.b(aot.a)).a()) {
                var1_3.add(var6_11 /* !! */ );
            }
            var1_3.forEach((Consumer<bmb>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, 8(java.util.List dfm bmb ), (Lbmb;)V)((7G)this, (List)var1_3, (dfm)var2_4));
        }
        RenderSystem.popMatrix();
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7G.\u2005\u2000\u2006;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)108172363 ^ (long)108172288)];
            if (var7) break block23;
            var3_2 = (int)((long)1464932728 ^ (long)1464932728);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u20f9\u095b\u1a2d\u12c6\u20d0\u0947\u1a78\u12ca\u20bf\u0942\u1a11\u12a2\u201b\u0911\u1a17\u12a3\u20f6\u0999\u1ab0\u1217\u2023\u0988\u1a3b\u122e\u20e4\u099d\u1aa0\u1288\u20ac\u09d3\u1a9e\u12cb\u20c3\u09d8\u1a07\u12d2\u20ae\u0972\u1aa7\u1207\u2002\u09ce\u1ab3\u12fe\u20bd\u0993\u1a52\u12bf\u203b\u0939\u1adc\u126f\u2024\u0915\u1a17\u12d0\u20a9\u0949\u1a61\u12d7\u200e\u0982\u1aa4\u127c\u2070\u09a3\u1a2c\u1220\u2090\u09ca\u1a7b\u120e\u20de\u09e7\u1ad7\u1232\u2046\u09dc\u1a58\u1259\u201b\u0999\u1a8c\u1221\u20f9\u09fd\u1a8a\u1292\u20b4\u0910\u1ab4\u1242\u2083\u09a5\u1a6d\u1277\u2066\u0927\u1a85\u1228\u20aa\u093d\u1a6c\u120a\u2078\u0996\u1a5d\u12b7\u2046\u09d0\u1adc\u1227\u20d3\u09b3\u1ac8\u1223\u2060\u097b\u1a8d\u12f7\u2006\u097e\u1a8b\u124e\u209e\u09ef\u1a6e\u121d\u204a\u0926\u1a8a\u1206\u2088\u0991\u1a19\u12ad\u20a4\u0949\u1aec\u1276\u209c\u09d9\u1a91\u1239\u200f\u091d\u1aea\u1215\u2066\u0986\u1ad2\u1261\u20fa\u095e\u1a12\u12f9\u200c\u0963\u1a83\u1221\u200e\u09fb\u1aa9\u12bd\u20ef\u099f\u1a51\u128c\u203b\u09b3\u1a6e\u1240\u20d8\u09c7\u1a05\u128d\u2050\u090a\u1ae5\u1299\u20d0\u097a\u1a43\u1262\u20c7\u09c2\u1a11\u12c8\u20f9\u09bd\u1a4c\u1207\u203c\u09be\u1ad9\u1245\u20c8\u099d\u1aa0\u126d\u20a1\u09c9\u1adc\u12a6\u2062\u0943\u1a1a\u1213\u201d\u096c\u1a6e\u1210\u20ac\u0906\u1a2f\u1280\u2067\u09c0\u1add\u1284\u20dc\u093f\u1a10\u122c\u2089\u0902\u1a76\u121b\u206c\u0966\u1a00\u1266\u20c0\u09ed\u1a52\u12f4\u20d5\u09dd\u1a33\u121c\u2084\u0959\u1ac3\u1273\u20ee\u09e0\u1ac0\u1266\u20db\u0907\u1ac6\u12c2\u20fc\u090f\u1ac6\u1262\u20a9\u09cc\u1a6c\u1255\u2020\u096b\u1af0\u12e5\u20b5\u0953\u1ae5\u12a5\u20be\u0940\u1a2e\u12a0\u20dc\u0957\u1ab2\u1282\u2055\u09d7\u1ad4\u1251\u20f9\u0921\u1af5\u120e\u20cd\u0927\u1a5f\u12bb\u2091\u094a\u1a03\u12fc\u2066\u09e7\u1aa9\u12d0\u2095\u091c\u1a51\u12b8\u2092\u09d9\u1a17\u120f\u20f8\u09c7\u1a02\u1235\u20ba\u098c\u1a26\u12e8\u20cc\u0927\u1a5d\u1226\u203f\u0955\u1a88\u1281\u20f5\u096d\u1a0e\u1200\u2032\u0943\u1abd\u124f\u2028\u093e\u1a86\u12eb\u203a\u0967\u1af2\u1205\u20ce\u090b\u1af9\u129e\u2033\u0974\u1aea\u1259\u202e\u095c\u1a31\u1237\u200f\u09ae\u1a98\u12f2\u20b7\u0979\u1a35\u12e9\u2055\u0916\u1a92\u1265\u204f\u091f\u1abe\u12cd\u20d1\u09c1\u1a5f\u1214\u2018\u0941\u1ac1\u1236\u205d\u0945\u1ace\u122b\u20dd\u09f6\u1aa2\u1272\u209b\u09b8\u1a96\u1228\u202b\u09c7\u1a96\u125b\u20ef\u0985\u1afc\u127e\u200f\u0948\u1adc\u125b\u2007\u0940\u1af5\u1225\u20f2\u09f7\u1a20\u1280\u2076\u09b4\u1a4e\u124f\u2018\u09d7\u1a3f\u1287\u20c0\u09f9\u1ad4\u1267\u20f2\u0912\u1a40\u1228\u207c\u09e6\u1a58\u127f\u20ee\u09c8\u1af0\u12c5\u20f1\u0923\u1aeb\u12eb\u2011\u0908\u1ad6\u12c5\u202b\u0970\u1a89\u128b\u20d3\u097d\u1a77\u1282\u207a\u0926\u1afd\u12b6\u20e5\u0974\u1aaf\u120f\u20fb\u09f4\u1ab8\u12d5\u20c6\u0991\u1ac0\u1209\u20a0\u09e3\u1a1f\u12d2\u20f9\u0946\u1a06\u1265\u2035\u0928\u1a21\u124c\u20d2\u09a7\u1aa9\u12d3\u20fe\u0936\u1aba\u12d9\u2037\u095d\u1a9c\u126d\u20fe\u0967\u1a5e\u12ec\u2031\u09ef\u1a2d\u12d8\u20b6\u0980\u1adb\u1285\u2007\u0917\u1ab3\u12cd\u20cd\u095b\u1ab4\u1246\u2007\u09f7\u1ab5\u12a8\u20f7\u0961\u1a9d\u12e2\u20c4\u09aa\u1a7d\u1271\u209a\u0944\u1a0c\u12b7\u2009\u0955\u1ad0\u120e\u205c\u0945\u1aea\u12e1\u20f8\u0904\u1af3\u1266\u2064\u0925\u1a53\u12af\u20c2\u0947\u1af2\u122a\u20b2\u0971\u1a63\u1220\u20bd\u09a5\u1aa7\u1248\u20ec\u092d\u1aed\u124a\u2031\u099e\u1adb\u12e2\u20fc\u0917\u1a13\u1240\u204b\u0957\u1ae5\u12a1\u2014\u09e9\u1a6d\u1240\u2035\u0956\u1a82\u126d\u20c7\u097f\u1a66\u12a8\u2066\u091c\u1a2f\u12ce\u2062\u0998\u1a5c\u12d8\u20cd\u09cf\u1ad8\u1297\u2014\u0977\u1a14\u12a5\u2077\u097a\u1a1e\u1220\u20da\u099a\u1add\u12ee\u20ac\u0937\u1af7\u1290\u206e\u0938\u1a06\u122c\u200a\u0908\u1aaf\u12c0\u20e9\u09bf\u1a6c\u12d0\u20a3\u098d\u1afb\u12f2\u20f9\u094a\u1a62\u1276\u2013\u099d\u1a08\u12b4\u2070\u094c\u1a95\u1231\u2065\u09ee\u1a55\u127d\u207e\u09f8\u1a5b\u1218\u20e8\u097b\u1a6e\u120c\u20a2\u09df\u1a70\u125c\u2099\u0943\u1ab6\u1266\u2007\u0993\u1a2e\u12fc\u20c9\u0938\u1ab5\u12d0\u20c5\u096d\u1a4c\u1211\u20a2\u097c\u1a73\u123d\u2071\u09ee\u1a58\u12f4\u2050\u09b9\u1ad5\u1279\u20de\u091c\u1a8d\u1249\u209c\u0964\u1a14\u1202\u20e8\u09aa\u1a5d\u127c\u20d2\u09a2\u1add\u12d8\u20d9\u0964\u1a0e\u1227\u20d6\u094c\u1a99\u124c\u2063\u09c1\u1a2d\u121c\u20a4\u09c2\u1a5f\u12d0\u208b\u09b2\u1a16\u1213\u200f\u0920\u1a5f\u1226\u206b\u0944\u1a1d\u12c9\u20d1\u09e8\u1a50\u1255\u2069\u0912\u1ad0\u1285\u2068\u0957\u1ae9\u121a\u20ad\u09d0\u1a4c\u12fc\u2070\u0933\u1a66\u122f\u2063\u09cb\u1a8f\u121f\u2021\u09d4\u1a24\u12d4\u200d\u09d2\u1a71\u126c\u20cc\u099d\u1a60\u1256\u20e0\u09ee\u1af2\u1269\u2029\u094d\u1aa5\u12b4\u20a4\u09c9\u1a00\u12ad\u2094\u09a3\u1a78\u1231\u20df\u0977\u1ab6\u126c\u20a1\u09cf\u1abe\u12bc\u2005\u09ce\u1a78\u122e\u20fa\u09e9\u1a5f\u12e3\u20ef\u09d8\u1a8d\u125a\u20c3\u099a\u1a6b\u1267\u20e7\u09dc\u1a19\u12e1\u203e\u09c1\u1aec\u12dd\u2042\u090b\u1a61\u12e7\u2020\u0904\u1a88\u1296\u2023\u0951\u1ae5\u12e7\u200a\u09ba\u1a2e\u12fa\u20dc\u099a\u1a1d\u1273\u207b\u0905\u1a1d\u1264\u2097\u090c\u1a90\u12fc\u20ba\u09d3\u1a8c\u12c2\u2019\u094f\u1ad0\u12c2\u20bf\u0914\u1a5c\u1273\u2009\u09ac\u1a50\u12d7\u207c\u09cf\u1a9b\u1240\u20ce\u0932\u1a2a\u1226\u20f4\u0990\u1a29\u125d\u203f\u09eb\u1a4d\u1259\u20da\u09bf\u1a5a\u126e\u208e\u0947\u1ae5\u1220\u2019\u0942\u1a80\u12de\u2061\u09d7\u1ade\u1222\u20f9\u099e\u1a65\u123a\u2013\u094a\u1ae5\u12e1\u20de\u0907\u1a0c\u124b\u2003\u09b9\u1a51\u12ab\u204d\u09da\u1a22\u1290\u20cf\u0995\u1abe\u12e9\u2075\u0938\u1a23\u12ad\u20a4\u0994\u1ade\u12db\u2044\u0938\u1a01\u12a0\u20c2\u09ce\u1a0b\u1281\u20f7\u09be\u1ae3\u12a3\u20bd\u0924\u1a0f\u127a\u207b\u095a\u1a18\u12cf\u20c5\u09d9\u1a9a\u1246\u20cb\u09d9\u1a00\u1216\u20bc\u0957\u1a39\u1271\u2031\u0908\u1a6e\u1250\u203e\u09ce\u1a29\u12b5\u200c\u0995\u1acb\u120b\u206a\u094c\u1a49\u12d4\u2088\u0917\u1a6f\u12a7\u201b\u09ad\u1a5d\u128a\u20ee\u0976\u1a0d\u12fb\u20f3\u09b5\u1a40\u1212\u20f8\u09e4\u1a24\u1224\u20c8\u0999\u1a54\u12c1\u205a\u0975\u1ac8\u12d7\u20cc\u0900\u1a16\u1234\u2052\u09a0\u1a9d\u12bc\u20a8\u09dd\u1a32\u123a\u20d7\u099a\u1ae7\u123c\u2035\u0929\u1a6a\u1227\u20de\u092b\u1ad0\u1225\u20bd\u09e7\u1a5e\u1236\u207b\u099c\u1a46\u124f\u2016\u0970\u1ace\u1288\u2038\u09a7\u1a82\u1238\u204a\u0965\u1ac2\u12e9\u20a7\u09f8\u1acf\u123a\u207a\u0909\u1a5d\u122f\u20f4\u09d1\u1a13\u127e\u20f4\u0929\u1a9e\u1243\u209f\u0938\u1a43\u1296\u20d6\u0979\u1ad6\u12cd\u207b\u098e\u1a6f\u129f\u2064\u09bb\u1a5c\u1241\u2069\u0933\u1ac3\u12a7\u2074\u095b\u1ad3\u1254\u208c\u0960\u1ab5\u12c2\u20c5\u09c4\u1a5c\u1200\u20a3\u09ec\u1a1b\u1265\u20b2\u095c\u1a35\u1257\u20ed\u093d\u1a74\u12c2\u20fa\u09c1\u1a5d\u120c\u20bc\u09a1\u1af4\u1294\u2039\u099b\u1a3a\u1236\u209c\u099f\u1a0a\u1219\u20d1\u09f4\u1a06\u12c5\u2009\u09aa\u1aed\u1249\u2024\u0924\u1ac3\u126f\u202f\u0902\u1af0\u128a\u2086\u090b\u1aaa\u12af\u20f5\u092b\u1a58\u1211\u2014\u0963\u1a3a\u12a9\u20d6\u097d\u1ac7\u12f3\u2020\u09df\u1ab4\u123c\u20e5\u0926\u1a38\u1210\u2090\u0950\u1aca\u1292\u20e6\u0973\u1a58\u12ef\u20e6\u0941\u1a13\u12c2\u2023\u09db\u1a01\u122e\u20d4\u090f\u1a5a\u1272\u2047\u0974\u1ab5\u1203\u2034\u09b4\u1aba\u1281\u2086\u0967\u1a02\u12f7\u20c7\u09a9\u1a37\u12b9\u20a8\u0911\u1af5\u12a3\u20ca\u0920\u1a05\u12d2\u208e\u091d\u1afb\u1284\u2025\u09ce\u1a22\u1297\u20ef\u09a2\u1a71\u126c\u2031\u0921\u1ad3\u12e5\u200c\u0913\u1af3\u1218\u2033\u0941\u1ac3\u1208\u2090\u09e5\u1a40\u124f\u2085\u0950\u1ac3\u12f4\u2031\u0974\u1ad6\u129e\u20b3\u0963\u1a3e\u12f3\u2034\u09f7\u1a5e\u12d7\u2039\u0993\u1a44\u1233\u20de\u0936\u1ac8\u1224\u2029\u09ea\u1a62\u12f0\u2030\u09d5\u1a77\u1251\u20f4\u09c2\u1a91\u1293\u202f\u09f1\u1a50\u1270\u2062\u0970\u1a8f\u1238\u2007\u0965\u1a0d\u121d\u20d9\u0969\u1af2\u120d\u2090\u094e\u1aef\u12b9\u202c\u097a\u1a87\u1232\u2082\u09fb\u1ab6\u1299\u202a\u09d0\u1a4d\u12f8\u20c8\u09c2\u1a15\u12a6\u2047\u0995\u1a48\u12e8\u20b6\u0932\u1aad\u12cb\u202f\u09a6\u1ad7\u12c4\u206f\u09df\u1a36\u12dc\u2003\u09c8\u1a8f\u12fa\u2025\u0938\u1aa3\u12e8\u20ed\u0953\u1a5d\u123a\u203b\u09ec\u1a47\u1262\u20e4\u09eb\u1a10\u12aa\u2071\u0922\u1ada\u12f8\u207b\u0956\u1a6c\u129f\u2017\u09f6\u1adb\u126d\u2093\u096c\u1a0a\u1218\u20c3\u09d7\u1a44\u12ed\u2059\u09ea\u1af9\u1257\u20a5\u099b\u1ada\u1209\u20b9\u0974\u1a8d\u1251\u20c0\u0995\u1aa9\u12a8\u2047\u093a\u1a2c\u1253\u2082\u0963\u1a23\u12c9\u208b\u09bd\u1a63\u12b9\u207a\u0959\u1ab9\u126e\u206d\u0908\u1a50\u1231\u2065\u0937\u1ab8\u125f\u20aa\u09d1\u1aa6\u122a\u20ae\u0924\u1a1c\u12ed\u20ed\u0900\u1a5f\u12a6\u2003\u0954\u1a10\u12cb\u2070\u09a8\u1a50\u12a9\u2052\u09a9\u1ab7\u12f2\u2084\u09b9\u1a74\u122a\u2075\u09e6\u1a2f\u12fc\u200d\u097b\u1a5d\u124d\u20be\u09ab\u1ac3\u1248", 484181997);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1621733923 ^ (long)1621733926);
            if (var7) break block23;
            var0_6 = (int)((long)1529413198 ^ (long)-1529413199);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)513112680 ^ (long)513112592);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)454756824 ^ (long)-454756825);
                    if (7G.\u2005\u2000\u2006) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7G.\u2005\u2000\u2006) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\uc8c3\ue198\uf2e6\ufa2d\uc85c\ue124\uf24b\ufa8a\uc8b6\ue139\uf204\ufa6f", 751890404);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1508732590 ^ (long)-1508732591);
                            var0_6 = (int)((long)-957424789 ^ (long)957424788);
                            while (true) {
                                v0 = (int)((long)-1345624502 ^ (long)-1345624491);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1033586661 ^ (long)1033586661);
                                if (!7G.\u2005\u2000\u2006) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7G.\u2005\u2000\u2006) ** continue;
                                throw null;
                            }
                            7G.d = var5_1;
                            7G.e = new String[(int)((long)156132963 ^ (long)156132904)];
                            if (!7G.\u2005\u2000\u2006) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-2042777373 ^ (long)-2042777373);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-485744494 ^ (long)-485744493)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)127776459 ^ (long)127776460)) {
                                case 0: {
                                    v15 = (int)((long)-1343727587 ^ (long)-1343727544);
                                    if (!7G.\u2005\u2000\u2006) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-490205927 ^ (long)-490205880);
                                    if (!7G.\u2005\u2000\u2006) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-58874120 ^ (long)-58874142);
                                    if (!7G.\u2005\u2000\u2006) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-411244965 ^ (long)-411245017);
                                    if (!7G.\u2005\u2000\u2006) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1741025796 ^ (long)-1741025821);
                                    if (!7G.\u2005\u2000\u2006) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)775303594 ^ (long)775303678);
                                    if (!7G.\u2005\u2000\u2006) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1728167658 ^ (long)-1728167631);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7G.\u2005\u2000\u2006);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    private static /* synthetic */ 8S 2(8S s) {
        boolean bl = \u2005\u2000\u2006;
        if (bl || bl) {
            return null;
        }
        return s;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean 7(aqa aqa2) {
        boolean bl;
        block24: {
            block26: {
                block25: {
                    block23: {
                        block22: {
                            bl = \u2005\u2000\u2006;
                            if (bl || bl) return true;
                            if (!(aqa2 instanceof bfw)) break block22;
                            if (bl) return true;
                            if (aqa2 != 3.aa()) break block23;
                            if (bl) return true;
                        }
                        if (bl) return true;
                        return (int)((long)-425042894 ^ (long)-425042894) != 0;
                    }
                    if (bl) return true;
                    if ((aqa2 = (bfw)aqa2).bF()) {
                        if (bl) return true;
                        if (!this.9.2) {
                            if (bl || bl) return true;
                            return (int)((long)1506288473 ^ (long)1506288473) != 0;
                        }
                    }
                    if (bl) return true;
                    if (aqa2.em()) {
                        if (bl) return true;
                        if (!this.6.2) {
                            if (bl || bl) return true;
                            return (int)((long)-750642903 ^ (long)-750642903) != 0;
                        }
                    }
                    if (bl) return true;
                    if (aqa2 instanceof dzm) break block24;
                    if (bl || bl) return true;
                    if (!aqa2.bF()) break block25;
                    if (bl) return true;
                    if (!this.9.2) break block24;
                    if (bl) return true;
                }
                if (bl) return true;
                if (!aqa2.em()) break block26;
                if (bl) return true;
                if (!this.6.2) break block24;
                if (bl) return true;
            }
            if (bl) return true;
            return (int)((long)-690056085 ^ (long)-690056086) != 0;
        }
        if (!bl) return (int)((long)85031616 ^ (long)85031617) != 0;
        return true;
    }

    private static /* synthetic */ 8S 0(8S s) {
        boolean bl = \u2005\u2000\u2006;
        if (bl || bl) {
            return null;
        }
        return s;
    }

    public 7G() {
        boolean bl = \u2005\u2000\u2006;
        super(7G.b((int)((long)-1895835154 ^ (long)1895829660), (int)((long)-1372035 ^ (long)1360721)) /* "Nametags" */, 7G.b((int)((long)-2039590537 ^ (long)2039584859), (int)((long)971298387 ^ (long)-971302761)) /* "Replaces Vanilla Nametags with more detailed ones" */);
        Object object = Boolean.TRUE;
        34J j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-1947799037 ^ (long)1947810628), (int)((long)1491528301 ^ (long)-1491523982)) /* "TTF" */)).7(7G.b((int)((long)-496995500 ^ (long)497007217), (int)((long)21976819 ^ (long)-21959645)) /* "ttf" */)).1(7G.b((int)((long)-148903061 ^ (long)148906549), (int)((long)-1205227325 ^ (long)1205233294)) /* "Use TTF font rendering instead of the game's default rendering" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-1947799037 ^ (long)1947810628), (int)((long)1491528301 ^ (long)-1491523982)) /* "TTF" */)).7(7G.b((int)((long)-496995500 ^ (long)497007217), (int)((long)21976819 ^ (long)-21959645)) /* "ttf" */)).1(7G.b((int)((long)-148903061 ^ (long)148906549), (int)((long)-1205227325 ^ (long)1205233294)) /* "Use TTF font rendering instead of the game's default rendering" */)).7 = object;
        this.7d = (1P)j2.5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-1366266455 ^ (long)1366271217), (int)((long)-1073239436 ^ (long)1073228165)) /* "Items" */)).7(7G.b((int)((long)646881029 ^ (long)-646883751), (int)((long)-101328511 ^ (long)101350596)) /* "items" */)).1(7G.b((int)((long)1003582892 ^ (long)-1003569961), (int)((long)569137345 ^ (long)-569139538)) /* "Draw nametags on dropped items" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-1366266455 ^ (long)1366271217), (int)((long)-1073239436 ^ (long)1073228165)) /* "Items" */)).7(7G.b((int)((long)646881029 ^ (long)-646883751), (int)((long)-101328511 ^ (long)101350596)) /* "items" */)).1(7G.b((int)((long)1003582892 ^ (long)-1003569961), (int)((long)569137345 ^ (long)-569139538)) /* "Draw nametags on dropped items" */)).7 = object;
        this.7s = (1P)j2.5();
        object = 3sY.a;
        j2 = (34f)((34f)((34f)this.2(3sY.class).5(7G.b((int)((long)1829156619 ^ (long)-1829142940), (int)((long)-392152754 ^ (long)-392165878)) /* "Collate" */)).7(7G.b((int)((long)-180830214 ^ (long)180844189), (int)((long)-1755082901 ^ (long)-1755085836)) /* "collate" */)).1(7G.b((int)((long)-809632682 ^ (long)809645345), (int)((long)1169073503 ^ (long)1169086918)) /* "Collate item tags that overlap to increase visibility" */);
        ((34f)((34f)((34f)this.2(3sY.class).5(7G.b((int)((long)1829156619 ^ (long)-1829142940), (int)((long)-392152754 ^ (long)-392165878)) /* "Collate" */)).7(7G.b((int)((long)-180830214 ^ (long)180844189), (int)((long)-1755082901 ^ (long)-1755085836)) /* "collate" */)).1(7G.b((int)((long)-809632682 ^ (long)809645345), (int)((long)1169073503 ^ (long)1169086918)) /* "Collate item tags that overlap to increase visibility" */)).7 = object;
        this.0 = (1m)((34f)((34f)j2).3(this.7s)).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)214257170 ^ (long)-214268072), (int)((long)-646724645 ^ (long)646734370)) /* "Dynamic" */)).7(7G.b((int)((long)-1630808944 ^ (long)1630805433), (int)((long)1378232957 ^ (long)1378251009)) /* "dynamic" */)).1(7G.b((int)((long)315011632 ^ (long)-315000000), (int)((long)12684020 ^ (long)-12692330)) /* "Scale item nametags dynamically depending on distance" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)214257170 ^ (long)-214268072), (int)((long)-646724645 ^ (long)646734370)) /* "Dynamic" */)).7(7G.b((int)((long)-1630808944 ^ (long)1630805433), (int)((long)1378232957 ^ (long)1378251009)) /* "dynamic" */)).1(7G.b((int)((long)315011632 ^ (long)-315000000), (int)((long)12684020 ^ (long)-12692330)) /* "Scale item nametags dynamically depending on distance" */)).7 = object;
        this.5 = (1P)((34X)j2.3(this.7s)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-523841139 ^ (long)523835617), (int)((long)-1130457454 ^ (long)-1130439691)) /* "Tamed" */)).7(7G.b((int)((long)1907820638 ^ (long)-1907834590), (int)((long)-1989705544 ^ (long)-1989690191)) /* "tamed" */)).1(7G.b((int)((long)-1171309378 ^ (long)1171322343), (int)((long)-805953900 ^ (long)-805953853)) /* "Draw nametags on tamed mobs" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-523841139 ^ (long)523835617), (int)((long)-1130457454 ^ (long)-1130439691)) /* "Tamed" */)).7(7G.b((int)((long)1907820638 ^ (long)-1907834590), (int)((long)-1989705544 ^ (long)-1989690191)) /* "tamed" */)).1(7G.b((int)((long)-1171309378 ^ (long)1171322343), (int)((long)-805953900 ^ (long)-805953853)) /* "Draw nametags on tamed mobs" */)).7 = object;
        this.7k = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-1799138807 ^ (long)1799134071), (int)((long)1030748658 ^ (long)-1030743605)))).7(7G.b((int)((long)688530371 ^ (long)-688526708), (int)((long)-1013946374 ^ (long)1013966595)))).1(7G.b((int)((long)1563768369 ^ (long)-1563754632), (int)((long)1012215331 ^ (long)-1012234290)) /* "Scale tamed nametags dynamically depending on distance" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-1799138807 ^ (long)1799134071), (int)((long)1030748658 ^ (long)-1030743605)))).7(7G.b((int)((long)688530371 ^ (long)-688526708), (int)((long)-1013946374 ^ (long)1013966595)))).1(7G.b((int)((long)1563768369 ^ (long)-1563754632), (int)((long)1012215331 ^ (long)-1012234290)) /* "Scale tamed nametags dynamically depending on distance" */)).7 = object;
        this.78 = (1P)((34X)((34X)j2).3(this.7k)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-56033332 ^ (long)56047244), (int)((long)-116782004 ^ (long)-116775344)) /* "Sounds" */)).7(7G.b((int)((long)-16221847 ^ (long)16232513), (int)((long)-1048696517 ^ (long)1048695272)) /* "sounds" */)).1(7G.b((int)((long)1884977328 ^ (long)-1884966499), (int)((long)744478411 ^ (long)744473085)) /* "Draw nametags on sounds" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-56033332 ^ (long)56047244), (int)((long)-116782004 ^ (long)-116775344)) /* "Sounds" */)).7(7G.b((int)((long)-16221847 ^ (long)16232513), (int)((long)-1048696517 ^ (long)1048695272)) /* "sounds" */)).1(7G.b((int)((long)1884977328 ^ (long)-1884966499), (int)((long)744478411 ^ (long)744473085)) /* "Draw nametags on sounds" */)).7 = object;
        this.7p = (1P)((34X)j2).5();
        object = 2.0;
        j2 = ((34e)((34e)((34e)this.7().5(7G.b((int)((long)-1364618911 ^ (long)1364613161), (int)((long)764403693 ^ (long)764404842)) /* "Duration" */)).7(7G.b((int)((long)1933791761 ^ (long)-1933796549), (int)((long)-451335920 ^ (long)-451313869)) /* "duration" */)).1(7G.b((int)((long)-1184377082 ^ (long)1184374371), (int)((long)575603201 ^ (long)-575624348)) /* "How long a sound lingers (seconds)" */)).3(0.5).2(20.0);
        ((34e)((34e)((34e)this.7().5(7G.b((int)((long)-1364618911 ^ (long)1364613161), (int)((long)764403693 ^ (long)764404842)) /* "Duration" */)).7(7G.b((int)((long)1933791761 ^ (long)-1933796549), (int)((long)-451335920 ^ (long)-451313869)) /* "duration" */)).1(7G.b((int)((long)-1184377082 ^ (long)1184374371), (int)((long)575603201 ^ (long)-575624348)) /* "How long a sound lingers (seconds)" */)).3(0.5).2(20.0).7 = object;
        this.7g = (1K)((34e)((34e)j2).3(this.7p)).5();
        object = 0.5;
        j2 = ((34e)((34e)((34e)this.7().5(7G.b((int)((long)314487945 ^ (long)-314475053), (int)((long)-1865541701 ^ (long)1865542803)) /* "Fade" */)).7(7G.b((int)((long)-1543015088 ^ (long)1543027757), (int)((long)1469569627 ^ (long)1469573420)) /* "fade" */)).1(7G.b((int)((long)1604492589 ^ (long)-1604496282), (int)((long)-299489782 ^ (long)-299475886)) /* "How long it takes to fade away completely (seconds)" */)).3(0.0).2(5.0);
        ((34e)((34e)((34e)this.7().5(7G.b((int)((long)314487945 ^ (long)-314475053), (int)((long)-1865541701 ^ (long)1865542803)) /* "Fade" */)).7(7G.b((int)((long)-1543015088 ^ (long)1543027757), (int)((long)1469569627 ^ (long)1469573420)) /* "fade" */)).1(7G.b((int)((long)1604492589 ^ (long)-1604496282), (int)((long)-299489782 ^ (long)-299475886)) /* "How long it takes to fade away completely (seconds)" */)).3(0.0).2(5.0).7 = object;
        this.74 = (1K)((34e)((34e)j2).3(this.7p)).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-1048008415 ^ (long)1048010847), (int)((long)-810758946 ^ (long)810757351)))).7(7G.b((int)((long)-87817618 ^ (long)87804705), (int)((long)446136543 ^ (long)-446169050)))).1(7G.b((int)((long)-393411140 ^ (long)393399536), (int)((long)2053762509 ^ (long)-2053762423)) /* "Scale sound nametags dynamically depending on distance" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-1048008415 ^ (long)1048010847), (int)((long)-810758946 ^ (long)810757351)))).7(7G.b((int)((long)-87817618 ^ (long)87804705), (int)((long)446136543 ^ (long)-446169050)))).1(7G.b((int)((long)-393411140 ^ (long)393399536), (int)((long)2053762509 ^ (long)-2053762423)) /* "Scale sound nametags dynamically depending on distance" */)).7 = object;
        this.7z = (1P)((34X)((34X)j2).3(this.7p)).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-2076473522 ^ (long)2076462693), (int)((long)-1985369889 ^ (long)-1985363071)) /* "Health" */)).7(7G.b((int)((long)6469886 ^ (long)-6458992), (int)((long)-1455314615 ^ (long)1455303043)) /* "health" */)).1(7G.b((int)((long)1994364694 ^ (long)-1994367389), (int)((long)-623009759 ^ (long)622992536)) /* "Displays Health on a 10pt scale" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-2076473522 ^ (long)2076462693), (int)((long)-1985369889 ^ (long)-1985363071)) /* "Health" */)).7(7G.b((int)((long)6469886 ^ (long)-6458992), (int)((long)-1455314615 ^ (long)1455303043)) /* "health" */)).1(7G.b((int)((long)1994364694 ^ (long)-1994367389), (int)((long)-623009759 ^ (long)622992536)) /* "Displays Health on a 10pt scale" */)).7 = object;
        this.2 = (1P)((34X)j2).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-1259363380 ^ (long)1259367085), (int)((long)1456714110 ^ (long)-1456715444)) /* "Separate" */)).7(7G.b((int)((long)1165418381 ^ (long)-1165420864), (int)((long)711095202 ^ (long)-711098172)) /* "separate" */)).1(7G.b((int)((long)-1134878099 ^ (long)1134881594), (int)((long)-586421216 ^ (long)-586419693)) /* "Displays extra health separately from max health" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-1259363380 ^ (long)1259367085), (int)((long)1456714110 ^ (long)-1456715444)) /* "Separate" */)).7(7G.b((int)((long)1165418381 ^ (long)-1165420864), (int)((long)711095202 ^ (long)-711098172)) /* "separate" */)).1(7G.b((int)((long)-1134878099 ^ (long)1134881594), (int)((long)-586421216 ^ (long)-586419693)) /* "Displays extra health separately from max health" */)).7 = object;
        this.72 = (1P)((34X)((34X)j2).3(this.2)).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)140477080 ^ (long)-140489796), (int)((long)-1004003012 ^ (long)-1003989165)) /* "Armor" */)).7(7G.b((int)((long)331870847 ^ (long)-331859173), (int)((long)1279473107 ^ (long)-1279460249)) /* "armor" */)).1(7G.b((int)((long)1204810578 ^ (long)-1204798974), (int)((long)-352752138 ^ (long)352776110)) /* "Displays Items and Armor" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)140477080 ^ (long)-140489796), (int)((long)-1004003012 ^ (long)-1003989165)) /* "Armor" */)).7(7G.b((int)((long)331870847 ^ (long)-331859173), (int)((long)1279473107 ^ (long)-1279460249)) /* "armor" */)).1(7G.b((int)((long)1204810578 ^ (long)-1204798974), (int)((long)-352752138 ^ (long)352776110)) /* "Displays Items and Armor" */)).7 = object;
        this.7j = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-1523499905 ^ (long)1523512587), (int)((long)-94661873 ^ (long)94644942)) /* "Rank" */)).7(7G.b((int)((long)1957322468 ^ (long)-1957324898), (int)((long)-1959935718 ^ (long)1959922590)) /* "rank" */)).1(7G.b((int)((long)-1274865535 ^ (long)1274859951), (int)((long)-1938399482 ^ (long)1938413899)) /* "Displays team prefix and suffix (\"rank\")" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-1523499905 ^ (long)1523512587), (int)((long)-94661873 ^ (long)94644942)) /* "Rank" */)).7(7G.b((int)((long)1957322468 ^ (long)-1957324898), (int)((long)-1959935718 ^ (long)1959922590)) /* "rank" */)).1(7G.b((int)((long)-1274865535 ^ (long)1274859951), (int)((long)-1938399482 ^ (long)1938413899)) /* "Displays team prefix and suffix (\"rank\")" */)).7 = object;
        this.7B = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-7116674 ^ (long)7119192), (int)((long)742404466 ^ (long)742392289)) /* "Gamemode" */)).7(7G.b((int)((long)-778173481 ^ (long)778160774), (int)((long)-179792665 ^ (long)-179779345)) /* "gamemode" */)).1(7G.b((int)((long)-1662208601 ^ (long)1662221505), (int)((long)-426279869 ^ (long)-426281020)) /* "Displays Gamemode (Survival/Creative/Adventure/Spectator)" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-7116674 ^ (long)7119192), (int)((long)742404466 ^ (long)742392289)) /* "Gamemode" */)).7(7G.b((int)((long)-778173481 ^ (long)778160774), (int)((long)-179792665 ^ (long)-179779345)) /* "gamemode" */)).1(7G.b((int)((long)-1662208601 ^ (long)1662221505), (int)((long)-426279869 ^ (long)-426281020)) /* "Displays Gamemode (Survival/Creative/Adventure/Spectator)" */)).7 = object;
        this.7c = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)1988940628 ^ (long)-1988945392), (int)((long)-847482766 ^ (long)847494415)) /* "Priority" */)).7(7G.b((int)((long)1117616357 ^ (long)-1117605430), (int)((long)1493488237 ^ (long)1493476239)) /* "priority" */)).1(7G.b((int)((long)-2022447295 ^ (long)2022452762), (int)((long)1658979367 ^ (long)-1658986849)) /* "Orders the render list so that closer nametags are on top of further ones" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)1988940628 ^ (long)-1988945392), (int)((long)-847482766 ^ (long)847494415)) /* "Priority" */)).7(7G.b((int)((long)1117616357 ^ (long)-1117605430), (int)((long)1493488237 ^ (long)1493476239)) /* "priority" */)).1(7G.b((int)((long)-2022447295 ^ (long)2022452762), (int)((long)1658979367 ^ (long)-1658986849)) /* "Orders the render list so that closer nametags are on top of further ones" */)).7 = object;
        this.7i = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)-640614802 ^ (long)640628511), (int)((long)1770365487 ^ (long)1770360625)) /* "Sleeping" */)).7(7G.b((int)((long)-188308525 ^ (long)188312192), (int)((long)-467334599 ^ (long)467315700)) /* "sleeping" */)).1(7G.b((int)((long)542380605 ^ (long)-542385322), (int)((long)157772707 ^ (long)-157770265)) /* "Draw nametags for Sleeping Players" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)-640614802 ^ (long)640628511), (int)((long)1770365487 ^ (long)1770360625)) /* "Sleeping" */)).7(7G.b((int)((long)-188308525 ^ (long)188312192), (int)((long)-467334599 ^ (long)467315700)) /* "sleeping" */)).1(7G.b((int)((long)542380605 ^ (long)-542385322), (int)((long)157772707 ^ (long)-157770265)) /* "Draw nametags for Sleeping Players" */)).7 = object;
        this.6 = (1P)((34X)j2).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)18577685 ^ (long)-18567088), (int)((long)834726193 ^ (long)834712602)) /* "Invisibles" */)).7(7G.b((int)((long)1207753887 ^ (long)-1207757376), (int)((long)-42303564 ^ (long)-42323481)) /* "invis" */)).1(7G.b((int)((long)-2041977381 ^ (long)2041982116), (int)((long)1724369232 ^ (long)-1724355677)) /* "Draw nametags for Invisible Players" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)18577685 ^ (long)-18567088), (int)((long)834726193 ^ (long)834712602)) /* "Invisibles" */)).7(7G.b((int)((long)1207753887 ^ (long)-1207757376), (int)((long)-42303564 ^ (long)-42323481)) /* "invis" */)).1(7G.b((int)((long)-2041977381 ^ (long)2041982116), (int)((long)1724369232 ^ (long)-1724355677)) /* "Draw nametags for Invisible Players" */)).7 = object;
        this.9 = (1P)((34X)j2).5();
        object = 1.0;
        j2 = ((34e)((34e)((34e)this.7().5(7G.b((int)((long)2056646552 ^ (long)-2056640800), (int)((long)1780996998 ^ (long)-1780981034)) /* "Scale" */)).7(7G.b((int)((long)589530965 ^ (long)-589541887), (int)((long)-1768106652 ^ (long)1768102747)) /* "scale" */)).1(7G.b((int)((long)1286663063 ^ (long)-1286659329), (int)((long)-338447086 ^ (long)338450931)) /* "Scale of the nametags" */)).3(1.0).2(4.0);
        ((34e)((34e)((34e)this.7().5(7G.b((int)((long)2056646552 ^ (long)-2056640800), (int)((long)1780996998 ^ (long)-1780981034)) /* "Scale" */)).7(7G.b((int)((long)589530965 ^ (long)-589541887), (int)((long)-1768106652 ^ (long)1768102747)) /* "scale" */)).1(7G.b((int)((long)1286663063 ^ (long)-1286659329), (int)((long)-338447086 ^ (long)338450931)) /* "Scale of the nametags" */)).3(1.0).2(4.0).7 = object;
        this.7V = (1K)((34e)j2).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7G.b((int)((long)1182093414 ^ (long)-1182099196), (int)((long)-1728708332 ^ (long)1728694350)) /* "Player Scaling" */)).7(7G.b((int)((long)-1613644033 ^ (long)1613658005), (int)((long)-1542232539 ^ (long)1542236759)) /* "playerdynamic" */)).1(7G.b((int)((long)-1003364014 ^ (long)1003366436), (int)((long)-225915759 ^ (long)225914410)) /* "Scale player nametags dynamically depending on distance" */);
        ((34X)((34X)((34X)this.4().5(7G.b((int)((long)1182093414 ^ (long)-1182099196), (int)((long)-1728708332 ^ (long)1728694350)) /* "Player Scaling" */)).7(7G.b((int)((long)-1613644033 ^ (long)1613658005), (int)((long)-1542232539 ^ (long)1542236759)) /* "playerdynamic" */)).1(7G.b((int)((long)-1003364014 ^ (long)1003366436), (int)((long)-225915759 ^ (long)225914410)) /* "Scale player nametags dynamically depending on distance" */)).7 = object;
        this.7l = (1P)((34X)j2).5();
        object = 8.0;
        j2 = ((34e)((34e)((34e)this.7().5(7G.b((int)((long)1022254928 ^ (long)-1022257647), (int)((long)-1132545055 ^ (long)-1132542120)) /* "Min Dist" */)).7(7G.b((int)((long)-1965232547 ^ (long)1965238035), (int)((long)1037071813 ^ (long)-1037066327)) /* "mindist" */)).1(7G.b((int)((long)-459868347 ^ (long)459881991), (int)((long)1338728243 ^ (long)1338719563)) /* "Distance at which the nametags start getting smaller (dynamic only)" */)).3(2.0).2(40.0);
        ((34e)((34e)((34e)this.7().5(7G.b((int)((long)1022254928 ^ (long)-1022257647), (int)((long)-1132545055 ^ (long)-1132542120)) /* "Min Dist" */)).7(7G.b((int)((long)-1965232547 ^ (long)1965238035), (int)((long)1037071813 ^ (long)-1037066327)) /* "mindist" */)).1(7G.b((int)((long)-459868347 ^ (long)459881991), (int)((long)1338728243 ^ (long)1338719563)) /* "Distance at which the nametags start getting smaller (dynamic only)" */)).3(2.0).2(40.0).7 = object;
        this.1 = (1K)((34e)j2).5();
        object = 20.0;
        j2 = ((34e)((34e)((34e)this.7().5(7G.b((int)((long)1103271448 ^ (long)-1103274149), (int)((long)2099390304 ^ (long)-2099380231)) /* "Max Dist" */)).7(7G.b((int)((long)563666173 ^ (long)-563669628), (int)((long)2083715640 ^ (long)-2083708555)) /* "maxdist" */)).1(7G.b((int)((long)-756869771 ^ (long)756866069), (int)((long)329414356 ^ (long)329406343)) /* "Distance at which the nametags stop getting smaller (dynamic only)" */)).3(16.0).2(100.0);
        ((34e)((34e)((34e)this.7().5(7G.b((int)((long)1103271448 ^ (long)-1103274149), (int)((long)2099390304 ^ (long)-2099380231)) /* "Max Dist" */)).7(7G.b((int)((long)563666173 ^ (long)-563669628), (int)((long)2083715640 ^ (long)-2083708555)) /* "maxdist" */)).1(7G.b((int)((long)-756869771 ^ (long)756866069), (int)((long)329414356 ^ (long)329406343)) /* "Distance at which the nametags stop getting smaller (dynamic only)" */)).3(16.0).2(100.0).7 = object;
        this.4 = (1K)((34e)j2).5();
        this.76 = new ArrayList<1D>();
        this.7 = new Listener(r2 -> {
            Object object2;
            34D d3;
            boolean bl = \u2005\u2000\u2006;
            if (bl || bl) return;
            if (7G.3.r == null) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            dfm dfm2 = r2.8();
            if (bl || bl) {
                return;
            }
            if (this.7d.2) {
                d3 = 8W.0;
                if (\u2005\u2000\u2006) {
                    throw null;
                }
            } else {
                d3 = this.8 = 7G.3.g;
            }
            if (this.7s.2) {
                62 var4_5;
                object2 = 6L.3(7G.3.r).filter(bcv.class::isInstance).map(bcv.class::cast).map(bcv2 -> {
                    block3: {
                        block2: {
                            boolean bl = \u2005\u2000\u2006;
                            if (bl || bl) break block2;
                            r2 = ((2)bcv2).interpolate(((2_)r2).3());
                            if (!bl && !bl) break block3;
                        }
                        return null;
                    }
                    return new 9K(bcv2.g().r().getString(), bcv2.g().E(), ((8S)((Object)r2)).7(0.0, 0.5, 0.0));
                }).collect(Collectors.toList());
                62 var6_6 = var4_5 = new 62(this.8);
                List<9K> list = object2;
                object2 = this;
                ArrayList arrayList = new ArrayList();
                list.forEach(k2 -> {
                    boolean bl = \u2005\u2000\u2006;
                    if (bl || bl) return;
                    var6_6 = arrayList.stream().filter(arg_0 -> this.9((62)var6_6, k2, arg_0)).findFirst().orElse(null);
                    if (var6_6 == null) {
                        if (bl || bl) return;
                        arrayList.add(new 9k((9K)k2));
                        if (bl) return;
                        return;
                    }
                    if (bl) return;
                    9k.0((9k)((Object)var6_6)).add(k2);
                    if (!bl && !bl) return;
                });
                arrayList.stream().map(9k::8).forEach(k2 -> {
                    block3: {
                        block2: {
                            boolean bl = \u2005\u2000\u2006;
                            if (bl || bl) break block2;
                            float f = this.4(k2.9(), r2.3(), this.5.2);
                            if (bl || bl) break block2;
                            k2.3().ifPresent(s -> {
                                block11: {
                                    boolean bl = \u2005\u2000\u2006;
                                    if (!bl && !bl) {
                                        2b b2 = ((9k)((Object)k2)).6(var4_5);
                                        2b b3 = b2.1(-b2.1().9, 0.0f);
                                        if (!bl && !bl) {
                                            RenderSystem.pushMatrix();
                                            if (!bl && !bl) {
                                                RenderSystem.translated((double)s.9, (double)(s.1 - (double)b3.5()), (double)0.0);
                                                if (!bl && !bl) {
                                                    float f2 = f;
                                                    RenderSystem.scalef((float)f2, (float)f2, (float)f);
                                                    if (!bl && !bl) {
                                                        int n = var2_2.2;
                                                        Object object = b3;
                                                        9b.6(((2b)object).1, ((2b)object).9, ((2b)object).6, ((2b)object).2, n);
                                                        if (!bl && !bl) {
                                                            RenderSystem.pushMatrix();
                                                            if (!bl && !bl) {
                                                                RenderSystem.translatef((float)b3.1().9, (float)var2_2.9, (float)0.0f);
                                                                if (!bl && !bl) {
                                                                    k2 = 9k.0(k2).iterator();
                                                                    if (!bl) {
                                                                        while (!bl) {
                                                                            if (k2.hasNext()) {
                                                                                if (bl) break;
                                                                                object = ((9K)k2.next()).4();
                                                                                if (bl || bl) break;
                                                                                var2_2.0.a(dfm2, (String)object, (float)(-var2_2.0.b((String)object)) / 2.0f, 0.0f, var2_2.4);
                                                                                if (bl || bl) break;
                                                                                RenderSystem.translatef((float)0.0f, (float)(var2_2.8 + (float)((AccessorFontRenderer)var2_2.0).getFontHeight()), (float)0.0f);
                                                                                if (bl || bl) break;
                                                                                if (!\u2005\u2000\u2006) continue;
                                                                                throw null;
                                                                            }
                                                                            if (bl) break;
                                                                            RenderSystem.popMatrix();
                                                                            if (bl || bl) break;
                                                                            RenderSystem.popMatrix();
                                                                            if (!bl && !bl) break block11;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    return;
                                }
                            });
                            if (!bl && !bl) break block3;
                        }
                        return;
                    }
                });
            }
            if (this.7k.2) {
                7G.3.r.b().forEach(object -> {
                    Object object2;
                    Object object3;
                    block13: {
                        block11: {
                            block12: {
                                block10: {
                                    boolean bl = \u2005\u2000\u2006;
                                    if (bl || bl) break block10;
                                    object3 = object;
                                    if (!(object3 instanceof are)) break block11;
                                    if (!bl && !bl) break block12;
                                }
                                return;
                            }
                            object2 = Optional.ofNullable(((are)object3).A_());
                            if (\u2005\u2000\u2006) {
                                throw null;
                            }
                            break block13;
                        }
                        if (object3 instanceof bbb) {
                            object2 = Optional.ofNullable(((bbb)object3).eX());
                            if (\u2005\u2000\u2006) {
                                throw null;
                            }
                        } else {
                            object2 = object3 = Optional.empty();
                        }
                    }
                    if (!((Optional)object2).isPresent()) {
                        return;
                    }
                    object3 = 7G.b((int)((long)-297734763 ^ (long)297739516), (int)((long)-1757737590 ^ (long)1757709420)) /* "Owned by: " */ + 34n.8((UUID)((Optional)object3).get()).orElse(((UUID)((Optional)object3).get()).toString());
                    object = ((2)object).interpolate(r2.3()).7(0.0, object.ce(), 0.0);
                    float f = this.4((8S)object, r2.3(), this.78.2);
                    if (!((Optional)(object = ((2L)() -> 7G.2((8S)object)).3())).isPresent()) {
                        return;
                    }
                    RenderSystem.pushMatrix();
                    RenderSystem.translated((double)((8S)((Optional)object).get()).9, (double)(((8S)((Optional)object).get()).1 - (double)(11.0f * f)), (double)0.0);
                    float f2 = f;
                    RenderSystem.scalef((float)f2, (float)f2, (float)f);
                    this.8.a(dfm2, (String)object3, (float)(-this.8.b((String)object3)) / 2.0f, 0.0f, (int)((long)982438075 ^ (long)-982438076));
                    RenderSystem.popMatrix();
                });
            }
            if (this.7p.2) {
                this.76.removeIf(d2 -> {
                    boolean bl = \u2005\u2000\u2006;
                    if (bl || bl) return true;
                    if (d2.4() > this.7g.1 + this.74.1) {
                        if (bl) return true;
                        return (int)((long)1504012043 ^ (long)1504012042) != 0;
                    }
                    if (!bl) return (int)((long)999460309 ^ (long)999460309) != 0;
                    return true;
                });
                this.76.forEach(optional -> {
                    String string;
                    int n;
                    int n2;
                    block13: {
                        block11: {
                            block12: {
                                block10: {
                                    boolean bl = \u2005\u2000\u2006;
                                    if (bl || bl) break block10;
                                    if (this.74.1 != 0.0) break block11;
                                    if (!bl) break block12;
                                }
                                return;
                            }
                            n2 = (int)((long)-543187328 ^ (long)-543187329);
                            if (\u2005\u2000\u2006) {
                                throw null;
                            }
                            break block13;
                        }
                        n2 = n = (int)(255.0 * (1.0 - (((1D)((Object)optional)).4() - this.7g.1) / this.74.1));
                    }
                    if (n2 <= (int)((long)-1244944273 ^ (long)-1244944305)) {
                        return;
                    }
                    vk vk2 = ((1D)((Object)optional)).8.a();
                    if (vk2.b().equals(7G.b((int)((long)1777446775 ^ (long)-1777441260), (int)((long)960648384 ^ (long)-960636169)) /* "minecraft" */)) {
                        string = vk2.a();
                        if (\u2005\u2000\u2006) {
                            throw null;
                        }
                    } else {
                        string = vk2.toString();
                    }
                    String string2 = string;
                    float f = this.4(((1D)((Object)optional)).1, r2.3(), this.7z.2);
                    if (!(optional = ((2L)() -> {
                        boolean bl = \u2005\u2000\u2006;
                        if (bl || bl) {
                            return null;
                        }
                        return d2.1;
                    }).3()).isPresent()) {
                        return;
                    }
                    RenderSystem.pushMatrix();
                    RenderSystem.translated((double)optional.get().9, (double)(optional.get().1 - (double)(11.0f * f)), (double)0.0);
                    float f2 = f;
                    RenderSystem.scalef((float)f2, (float)f2, (float)f);
                    this.8.a(dfm2, string2, (float)(-this.8.b(string2)) / 2.0f, 0.0f, pw.knx.feather.structures.Color.fromHex((int)((int)((long)-367445604 ^ (long)367445603))).alpha(n).getHex());
                    RenderSystem.popMatrix();
                });
                if (\u2005\u2000\u2006) {
                    throw null;
                }
            } else {
                this.76.clear();
            }
            if ((object2 = 6L.3(7G.3.r).filter(this::7).map(aqa2 -> {
                boolean bl = \u2005\u2000\u2006;
                if (bl || bl) {
                    return null;
                }
                return (bfw)aqa2;
            }).collect(Collectors.toList())).size() == 0) {
                return;
            }
            if (this.7i.2) {
                object2.sort(Comparator.comparingDouble(arg_0 -> ((aqa)3.aa()).g(arg_0)).reversed());
            }
            RenderSystem.pushMatrix();
            object2.forEach(arg_0 -> this.1(r2, dfm2, arg_0));
            RenderSystem.popMatrix();
        }, new Predicate[(int)((long)251788564 ^ (long)251788564)]);
        this.75 = new Listener(q -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2005\u2000\u2006;
                        if (bl || bl) break block2;
                        if (!this.7(q.9)) break block3;
                        if (bl || bl) break block2;
                        q.cancel();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-1452746191 ^ (long)-1452746191)]);
        Predicate[] predicateArray = new Predicate[(int)((long)-109017503 ^ (long)-109017504)];
        Class[] classArray = new Class[(int)((long)-2034711724 ^ (long)-2034711723)];
        classArray[(int)((long)2089390778 ^ (long)2089390778)] = rn.class;
        predicateArray[(int)((long)852075517 ^ (long)852075517)] = new 34s(classArray);
        this.7I = new Listener(i -> {
            boolean bl;
            block8: {
                block7: {
                    bl = \u2005\u2000\u2006;
                    if (bl || bl) return;
                    if (!this.7p.2) break block7;
                    if (bl) return;
                    if (i.2 == EventState.PRE) break block8;
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            this.76.add(new 1D((rn)i.7, (byte)((long)-1323215837 ^ (long)-1323215837)));
            if (!bl && !bl) return;
        }, predicateArray);
        this.8 = 7G.3.g;
    }

    private /* synthetic */ boolean 9(62 var1_1, 9K k2, 9k k3) {
        boolean bl = \u2005\u2000\u2006;
        if (bl || bl) {
            return true;
        }
        return ((3sY)this.0.0()).3(var1_1, k3, k2);
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7G.\u2005\u2000\u2006;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-2064761487 ^ (long)2064774173)) & (int)((long)-1997927747 ^ (long)-1997867710);
            if (var9_2) ** GOTO lbl-1000
            if (7G.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7G.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1197391522 ^ (long)-1197391522)] & (int)((long)-1445342538 ^ (long)-1445342647)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1403769600 ^ (long)-1403769365);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-304366343 ^ (long)-304366568);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1067948532 ^ (long)-1067948302);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1883315142 ^ (long)-1883314997);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)347644411 ^ (long)347644398);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1377555596 ^ (long)-1377555687);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1375587071 ^ (long)1375586840);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)714931356 ^ (long)714931275);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1936599728 ^ (long)1936599760);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1170219425 ^ (long)-1170219467);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)761610751 ^ (long)761610584);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)783803666 ^ (long)783803901);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1261316211 ^ (long)-1261316329);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1689834634 ^ (long)-1689834608);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-2022531650 ^ (long)-2022531748);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1277479641 ^ (long)1277479632);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1540087449 ^ (long)1540087500);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)19734550 ^ (long)19734762);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1710728598 ^ (long)-1710728606);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1674561402 ^ (long)1674561464);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)553525723 ^ (long)553525717);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1578478403 ^ (long)1578478588);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)2100566314 ^ (long)2100566417);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-830634475 ^ (long)-830634293);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)2036596192 ^ (long)2036596223);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)2072537114 ^ (long)2072537154);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)2032051847 ^ (long)2032051793);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)270728638 ^ (long)270728549);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1998145356 ^ (long)-1998145403);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-723982277 ^ (long)-723982225);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-2022239424 ^ (long)-2022239373);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1726133185 ^ (long)1726133216);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-875477214 ^ (long)-875477181);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1272953233 ^ (long)-1272953267);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-388908078 ^ (long)-388908160);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1615770094 ^ (long)1615769920);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-430533736 ^ (long)-430533820);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)582506294 ^ (long)582506432);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1210376166 ^ (long)-1210376047);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-341037503 ^ (long)-341037321);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-245394905 ^ (long)-245394707);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1793605469 ^ (long)-1793605498);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)367619035 ^ (long)367619015);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)723609085 ^ (long)723609061);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-994355844 ^ (long)-994355945);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1237367822 ^ (long)1237367921);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)439147706 ^ (long)439147702);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1389232352 ^ (long)1389232236);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1630572917 ^ (long)-1630573015);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)609533179 ^ (long)609533176);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)580229388 ^ (long)580229524);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-788515214 ^ (long)-788515191);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-209417895 ^ (long)-209417839);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1157240995 ^ (long)-1157240908);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1108237457 ^ (long)-1108237347);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-494123156 ^ (long)-494123076);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)383301846 ^ (long)383301877);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1167306388 ^ (long)-1167306405);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-253479510 ^ (long)-253479486);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-587442121 ^ (long)-587442096);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1424352513 ^ (long)-1424352553);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1507778344 ^ (long)1507778417);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-127018418 ^ (long)-127018298);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1029696975 ^ (long)-1029696990);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-869065150 ^ (long)-869065046);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-217486682 ^ (long)-217486602);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-2042757271 ^ (long)-2042757174);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1446415079 ^ (long)1446415066);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1087246135 ^ (long)-1087246170);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-109699963 ^ (long)-109700096);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1863927374 ^ (long)-1863927313);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)519192832 ^ (long)519193082);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)483768939 ^ (long)483768956);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1953040034 ^ (long)1953039902);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-76365440 ^ (long)-76365527);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1787474044 ^ (long)-1787474166);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1821268864 ^ (long)-1821268766);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-940238441 ^ (long)-940238431);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-432051016 ^ (long)-432050954);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-2101317399 ^ (long)-2101317516);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)208246670 ^ (long)208246671);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1324508155 ^ (long)-1324508009);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1091446593 ^ (long)-1091446748);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1414151379 ^ (long)1414151367);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-203085896 ^ (long)-203085873);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)336088400 ^ (long)336088541);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1577718769 ^ (long)-1577718717);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)578506252 ^ (long)578506379);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-80968031 ^ (long)-80968066);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)2114807301 ^ (long)2114807337);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1577084007 ^ (long)-1577083988);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)2071275351 ^ (long)2071275439);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)2109266322 ^ (long)2109266364);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1624131270 ^ (long)1624131131);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)851243392 ^ (long)851243345);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1901686335 ^ (long)-1901686371);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1735475336 ^ (long)-1735475294);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)2140325380 ^ (long)2140325510);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-612033472 ^ (long)-612033459);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1122812907 ^ (long)1122812679);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1614973155 ^ (long)-1614973021);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1649344709 ^ (long)-1649344704);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-846427501 ^ (long)-846427463);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)620229644 ^ (long)620229770);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1864349827 ^ (long)-1864349883);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)693039817 ^ (long)693039759);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)339487639 ^ (long)339487535);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-333038800 ^ (long)-333038828);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1005778731 ^ (long)1005778917);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)171943098 ^ (long)171943036);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)236294121 ^ (long)236294014);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-285876736 ^ (long)-285876589);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1708929101 ^ (long)-1708929253);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1512299322 ^ (long)-1512299507);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1812974960 ^ (long)-1812975038);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1905167024 ^ (long)-1905166935);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1791509096 ^ (long)-1791509221);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1173959312 ^ (long)1173959182);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)605589252 ^ (long)605589296);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1383800921 ^ (long)-1383800981);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)2116125710 ^ (long)2116125751);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1711328121 ^ (long)-1711328068);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-522393049 ^ (long)-522393001);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)192868868 ^ (long)192869095);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1561460117 ^ (long)-1561460192);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-2145894581 ^ (long)-2145894570);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)552310467 ^ (long)552310393);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-252858673 ^ (long)-252858659);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-2002279822 ^ (long)-2002279802);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1658547633 ^ (long)-1658547501);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)0x7BB7CCCB ^ (long)2075643020);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1567450275 ^ (long)1567450276);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-888256229 ^ (long)-888256113);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)904653793 ^ (long)904653725);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-420040283 ^ (long)-420040211);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)496778126 ^ (long)496778174);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-873422601 ^ (long)-873422618);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1553251545 ^ (long)-1553251436);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1949259480 ^ (long)1949259293);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-173241404 ^ (long)-173241433);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-91944864 ^ (long)-91944946);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)953014932 ^ (long)953014954);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1758288558 ^ (long)1758288604);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1621522912 ^ (long)1621522848);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1369343862 ^ (long)-1369343791);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1789454743 ^ (long)1789454814);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-473371638 ^ (long)-473371446);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1460744287 ^ (long)-1460744416);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1164438809 ^ (long)1164439019);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)784487486 ^ (long)784487671);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1390271740 ^ (long)-1390271497);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1274281390 ^ (long)-1274281258);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)2128880663 ^ (long)2128880858);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)948850870 ^ (long)948850745);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)7829984 ^ (long)0x777998);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1443145107 ^ (long)-1443145085);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-945570266 ^ (long)-945570259);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1000874473 ^ (long)1000874459);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1608185708 ^ (long)-1608185614);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1452478750 ^ (long)1452478773);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-2077539632 ^ (long)-2077539809);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)346643551 ^ (long)346643595);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)771553591 ^ (long)771553544);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1742419065 ^ (long)-1742418965);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1811556764 ^ (long)-1811556826);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-2050532496 ^ (long)-2050532498);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-869581913 ^ (long)-869581886);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)941574706 ^ (long)941574795);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1227656846 ^ (long)1227656921);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1212389161 ^ (long)1212389204);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1086646754 ^ (long)1086646673);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-290413977 ^ (long)-290414042);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-542408024 ^ (long)-542408080);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1991135755 ^ (long)-1991135868);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1436012172 ^ (long)1436012280);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)2092403015 ^ (long)2092403048);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1239101935 ^ (long)-1239101766);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)2064567737 ^ (long)2064567564);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1616505792 ^ (long)1616505604);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1171627379 ^ (long)-1171627416);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-865842450 ^ (long)-865842553);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1221992084 ^ (long)1221991984);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1569377873 ^ (long)-1569377934);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-405192451 ^ (long)-405192541);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1376245486 ^ (long)-1376245454);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-766397570 ^ (long)-766397645);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)357231815 ^ (long)357231694);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1919695711 ^ (long)1919695630);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1883030115 ^ (long)1883030249);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1186737251 ^ (long)1186737191);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1065835824 ^ (long)-1065835995);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1545678470 ^ (long)-1545678393);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1699206419 ^ (long)1699206588);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)251501665 ^ (long)251501760);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)358620186 ^ (long)358620181);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1023604839 ^ (long)1023604862);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)95414661 ^ (long)95414686);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-135377794 ^ (long)-135377797);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)909549772 ^ (long)909549736);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1077310053 ^ (long)-1077309970);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1006498528 ^ (long)-1006498419);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1722905234 ^ (long)-1722905321);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1388936331 ^ (long)-1388936299);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)488359666 ^ (long)488359630);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1802749911 ^ (long)1802749710);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1344164931 ^ (long)-1344164929);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-357717726 ^ (long)-357717745);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1915577021 ^ (long)1915576936);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-969952812 ^ (long)-969952928);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-2069339690 ^ (long)-2069339802);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1695047436 ^ (long)-1695047598);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1752826368 ^ (long)-1752826368);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-981241801 ^ (long)-981241701);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)578315595 ^ (long)578315549);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)2145828816 ^ (long)2145828647);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1172805010 ^ (long)-1172804982);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1142803082 ^ (long)1142802976);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1882091513 ^ (long)1882091322);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)836535999 ^ (long)836535916);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1661610683 ^ (long)1661610673);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1285962342 ^ (long)-1285962288);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-920506208 ^ (long)-920506233);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1610947088 ^ (long)-1610947094);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1831254193 ^ (long)1831254199);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1148942839 ^ (long)1148942729);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1564791948 ^ (long)1564791905);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1998615726 ^ (long)-1998615807);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-2024267353 ^ (long)-2024267378);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1642658745 ^ (long)1642658604);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)2136770165 ^ (long)2136770096);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1026073520 ^ (long)1026073345);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1542159515 ^ (long)1542159576);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1901974405 ^ (long)1901974474);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1644390298 ^ (long)1644390156);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1886089720 ^ (long)-1886089555);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1381893287 ^ (long)1381893136);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)599780182 ^ (long)599780241);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)2122764688 ^ (long)2122764544);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)911945743 ^ (long)911945957);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-893830050 ^ (long)-893829970);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1880402037 ^ (long)1880402148);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)350901810 ^ (long)350901938);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1418942342 ^ (long)-1418942277);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1902289417 ^ (long)-1902289439);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-679412851 ^ (long)-679412809);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1633960594 ^ (long)-1633960680);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)925374167 ^ (long)925374193);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-385000378 ^ (long)-385000263);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1805404975 ^ (long)-1805404991);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-811725846 ^ (long)-811726006);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)199953139 ^ (long)199953002);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-709514930 ^ (long)-709514799);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1203338647 ^ (long)1203338701);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1424141689 ^ (long)-1424141571);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1725323989 ^ (long)-1725323916);
                    if (!7G.\u2005\u2000\u2006) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-537104309 ^ (long)-537104305);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-333546204 ^ (long)-333546021)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1027687841 ^ (long)1027717726)) >>> (int)((long)883143961 ^ (long)883143953)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1684431112 ^ (long)1684431112);
            if (!7G.\u2005\u2000\u2006) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)194837751 ^ (long)194837749);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-911646957 ^ (long)-911646960) | var5_6 << (int)((long)-1710346048 ^ (long)-1710346043)) ^ var3_4[var7_8]) & (int)((long)-1384791585 ^ (long)-1384791776);
                    if (7G.\u2005\u2000\u2006) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1237507135 ^ (long)1237507132) | var6_7 << (int)((long)-1626893624 ^ (long)-1626893619)) ^ var3_4[var7_8]) & (int)((long)2074902154 ^ (long)2074902133);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7G.e[var2_3] = new String(var3_4).intern();
        }
        return 7G.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 8(List list, dfm dfm2, bmb bmb2) {
        block14: {
            boolean bl = \u2005\u2000\u2006;
            if (!bl && !bl) {
                int n = -(list.size() << (int)((long)714891576 ^ (long)714891579)) + (list.indexOf(bmb2) << (int)((long)599787085 ^ (long)599787081));
                if (!bl && !bl) {
                    2n.9(bmb2, n, (int)((long)-1763234719 ^ (long)1763234700));
                    if (!bl && !bl) {
                        RenderSystem.pushMatrix();
                        if (!bl && !bl) {
                            int n2 = n;
                            7G g2 = this;
                            if (!bl && !bl) {
                                RenderSystem.scaled((double)0.66, (double)0.66, (double)0.66);
                                if (!bl && !bl) {
                                    RenderSystem.disableDepthTest();
                                    if (!bl && !bl) {
                                        n2 += 2;
                                        if (!bl && !bl) {
                                            n2 = (int)((double)n2 * 1.5151515151515151);
                                            if (!bl && !bl) {
                                                bmb2 = bmb2.q();
                                                if (!bl && !bl) {
                                                    int n3 = (int)((long)-1483892411 ^ (long)-1483892411);
                                                    if (bl) return;
                                                    if (!bl) {
                                                        int n4 = (int)((long)2011314741 ^ (long)2011314741);
                                                        if (bl) return;
                                                        while (!bl) {
                                                            if (n4 < bmb2.size()) {
                                                                if (bl || bl) break;
                                                                String string = bmb2.a(n4).l(7G.b((int)((long)-1747229454 ^ (long)1747234215), (int)((long)-392950980 ^ (long)-392925699)) /* "id" */);
                                                                if (bl || bl) break;
                                                                short s = bmb2.a(n4).g(7G.b((int)((long)-577988189 ^ (long)577982670), (int)((long)-1377067854 ^ (long)1377043445)) /* "lvl" */);
                                                                if (bl || bl) break;
                                                                if ((string = (bps)gm.R.b(vk.a((String)string)).orElse(null)) != null) {
                                                                    if (bl || bl) break;
                                                                    string = aft.a((String)string.d((int)s).getString()).substring((int)((long)508357728 ^ (long)508357728), (int)((long)-1680297250 ^ (long)-1680297252)).toLowerCase();
                                                                    if (bl || bl) break;
                                                                    g2.8.a(dfm2, string, (float)n2, (float)(n3 + (int)((long)668245145 ^ (long)-668245179)), Color.white.getRGB());
                                                                    if (bl || bl) break;
                                                                    g2.8.a(dfm2, "" + k.l + s, (float)(n2 + (int)((long)1419789050 ^ (long)1419789045)), (float)(n3 + (int)((long)-1018099222 ^ (long)1018099254)), Color.gray.getRGB());
                                                                    if (bl || bl) break;
                                                                    n3 -= ((AccessorFontRenderer)g2.8).getFontHeight();
                                                                    if (bl) break;
                                                                }
                                                                if (bl) break;
                                                                ++n4;
                                                                if (bl) break;
                                                                if (!\u2005\u2000\u2006) continue;
                                                                throw null;
                                                            }
                                                            if (bl) break;
                                                            RenderSystem.enableDepthTest();
                                                            if (bl || bl) break;
                                                            RenderSystem.popMatrix();
                                                            if (!bl && !bl) break block14;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private float 4(8S s, float f, boolean bl) {
        boolean bl2 = \u2005\u2000\u2006;
        if (bl2 || bl2) return 0.0f;
        if (!bl) {
            if (bl2 || bl2) return 0.0f;
            return (float)this.7V.1;
        }
        if (bl2) return 0.0f;
        double d2 = 6L.4(((2)3.aa()).interpolate(f).4(s), this.1.1, this.4.1);
        if (!bl2 && !bl2) return (float)(this.7V.1 / d2 * this.1.1);
        return 0.0f;
    }
}

