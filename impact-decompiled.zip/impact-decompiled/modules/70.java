/* ==========================================================================
 * MODULE: Breadcrumbs
 * CATEGORY (inferred): Render
 * DESCRIPTION: Creates a trail behind you
 * OBFUSCATED CLASS: net.impactclient.70
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  brx
 *  com.mojang.blaze3d.systems.RenderSystem
 *  it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  pw.knx.feather.structures.Color
 *  pw.knx.feather.tessellate.Tessellator
 */
package net.impactclient;

import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1A;
import net.impactclient.1P;
import net.impactclient.1R;
import net.impactclient.1z;
import net.impactclient.2R;
import net.impactclient.2c;
import net.impactclient.2o;
import net.impactclient.2w$6X;
import net.impactclient.34E;
import net.impactclient.34J;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.34t;
import net.impactclient.3X;
import net.impactclient.3sh;
import net.impactclient.4L;
import net.impactclient.8S;
import net.impactclient.8h;
import net.impactclient.9b;
import pw.knx.feather.structures.Color;
import pw.knx.feather.tessellate.Tessellator;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 70
extends 3X
implements 8h {
    private 1A 2;
    private 1P 9;
    private 1A 25;
    @EventHandler
    private final Listener<34t> 1;
    private 1z 2M;
    public static final boolean \u200d;
    @EventHandler
    private final Listener<2o> 6;
    private 1P 8;
    private static final String[] e;
    public Int2ObjectMap<List<8S>> 4;
    private 1R 0;
    private 1A 7;
    @EventHandler
    private final Listener<3sh> 5;
    private static final String[] d;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 70.\u200d;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-531572390 ^ (long)-531572414)];
            if (var7) break block23;
            var3_2 = (int)((long)-1955049717 ^ (long)-1955049717);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u6314\u4a82\u597c\u51b9\u63d9\u4a79\u59ca\u51d0\u6300\u4ab6\u59e6\u51ed\u63ef\u4a8c\u595a\u5187\u6341\u4add\u5941\u5112\u638b\u4a5d\u5966\u51f3\u6304\u4a4f\u59a8\u5139\u6367\u4a58\u59e7\u51ea\u6378\u4a51\u591e\u51d9\u63ac\u4aa9\u59ab\u5159\u63e1\u4a88\u59e6\u51f4\u63dd\u4a38\u5937\u51d5\u6391\u4afb\u5997\u5118\u63ea\u4a0f\u5981\u5142\u6337\u4a89\u59c9\u511d\u63e3\u4ae1\u5983\u5173\u63f8\u4a5a\u5989\u51bf\u633f\u4a91\u5901\u51f9\u6396\u4a4c\u597d\u5160\u6380\u4ab5\u598f\u5143\u63f4\u4a2b\u5964\u512f\u6324\u4a99\u59eb\u515f\u6330\u4a76\u5906\u51b2\u639d\u4aa3\u59a8\u51e8\u6350\u4a1f\u59d5\u510a\u63fc\u4a09\u597d\u514d\u63db\u4ab8\u5917\u51fd\u633b\u4a05\u5922\u518b\u63f0\u4ae1\u5905\u5199\u6366\u4af3\u59e1\u519f\u6384\u4a09\u5983\u510f\u63dd\u4a01\u59cf\u510e\u631a\u4ab7\u591a\u515e\u63a1\u4ab3\u594f\u51eb\u63c2\u4a04\u599f\u5196\u635a\u4af9\u59f7\u5118\u6378\u4a5d\u5980\u51f4\u6312\u4a58\u59ee\u51dc\u63a1\u4a47\u5982\u5184\u63b0\u4ae5\u5992\u513d\u6322\u4a17\u59eb\u51b2\u6349\u4a30\u5927\u51f7\u63a2\u4ac8\u59a4\u51c9\u63bd\u4ab8\u59a2\u5171\u6335\u4aed\u5959\u5155\u63aa\u4ad5\u59be\u5161\u6372\u4abe\u59f7\u51f0\u6312\u4aae\u59a9\u5130\u6377\u4ad5\u598b\u5156\u6335\u4a57\u59f9\u511f\u6398\u4abf\u59dc\u51aa\u63e9\u4a71\u5941\u51b9\u6333\u4a2f\u59e6\u5168\u631f\u4a54\u5980\u51fb\u6333\u4a11\u598e\u515d\u6341\u4a87\u5904\u51c2\u631c\u4aa8\u595d\u51ae\u632b\u4ac8\u59fb\u51e9\u6356\u4aee\u596c\u51f5\u6391\u4ad8\u593c\u51ea\u63f7\u4a6b\u59fa\u51b5\u63fa\u4a8d\u5990\u5177\u6301\u4ab8\u59f7\u51f7\u63cb\u4aff\u598b\u51a6\u6319\u4a9c\u59d0\u5170\u6305\u4a71\u59d1\u51d4\u6330\u4a05\u5927\u51e9\u6371\u4a68\u59eb\u51f7\u63fb\u4a33\u59f7\u515b\u631a\u4a9f\u5943\u5163\u6362\u4a34\u590e\u51f7\u6387\u4ac1\u59b0\u51ad\u637f\u4a9c\u5936\u5188\u6383\u4a6f\u59db\u5102\u6333\u4ab6\u5985\u517f\u6373\u4ab6", 561202227);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-176305858 ^ (long)-176305867);
            if (var7) break block23;
            var0_6 = (int)((long)571913484 ^ (long)-571913485);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)538034379 ^ (long)538034412);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1062526891 ^ (long)1062526890);
                    if (70.\u200d) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!70.\u200d) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ud74f\ufe7d\uedf8\ue511\ud74c\ufed3\ued80\ue5a6\ud79c\ufe1c\ued07\ue587\ud782\ufe17\ued9c\ue56b\ud7ca\ufe5e\ued16\ue585\ud7ac\ufed5\ued0c\ue524\ud71c\ufef0\ued66\ue55d\ud7cb\ufe9c\uedb0\ue52b\ud7d3\ufe1c\uede9\ue587", -1377832960);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)989684622 ^ (long)989684624);
                            var0_6 = (int)((long)-1354312581 ^ (long)1354312580);
                            while (true) {
                                v0 = (int)((long)275112487 ^ (long)275112560);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1377081832 ^ (long)1377081832);
                                if (!70.\u200d) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!70.\u200d) ** continue;
                                throw null;
                            }
                            70.d = var5_1;
                            70.e = new String[(int)((long)-579713966 ^ (long)-579713974)];
                            if (!70.\u200d) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1202309588 ^ (long)-1202309588);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1592561087 ^ (long)1592561086)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-282047463 ^ (long)-282047458)) {
                                case 0: {
                                    v15 = (int)((long)1761607958 ^ (long)1761608052);
                                    if (!70.\u200d) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1216715454 ^ (long)1216715482);
                                    if (!70.\u200d) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1553865608 ^ (long)-1553865690);
                                    if (!70.\u200d) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-64944622 ^ (long)-64944568);
                                    if (!70.\u200d) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)165903514 ^ (long)165903503);
                                    if (!70.\u200d) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1228017409 ^ (long)1228017453);
                                    if (!70.\u200d) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)761087956 ^ (long)761087902);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!70.\u200d);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    private List<8S> 7() {
        int n;
        boolean bl = \u200d;
        if (bl || bl) {
            return null;
        }
        if (70.3.s.l.Y() == brx.g) {
            n = (int)((long)729010491 ^ (long)729010491);
            if (\u200d) {
                throw null;
            }
        } else if (70.3.s.l.Y() == brx.h) {
            n = (int)((long)1704155884 ^ (long)-1704155885);
            if (\u200d) {
                throw null;
            }
        } else {
            n = (int)((long)-1181183502 ^ (long)-1181183501);
        }
        return this.8(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 0() {
        block3: {
            block2: {
                boolean bl = \u200d;
                if (bl || bl) break block2;
                this.4.clear();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    public 70() {
        boolean bl = \u200d;
        super(70.b((int)((long)1887573317 ^ (long)-1887573194), (int)((long)599917315 ^ (long)-599939936)) /* "Breadcrumbs" */, 70.b((int)((long)1297619583 ^ (long)-1297619957), (int)((long)516659809 ^ (long)-516683681)) /* "Creates a trail behind you" */);
        Comparable<Boolean> comparable = Boolean.TRUE;
        34J j2 = (34X)((34X)((34X)this.4().5(70.b((int)((long)-232951205 ^ (long)232950826), (int)((long)-1218100736 ^ (long)1218094163)) /* "Active" */)).7(70.b((int)((long)1324331241 ^ (long)-1324331382), (int)((long)-2115531416 ^ (long)2115511690)) /* "active" */)).1(70.b((int)((long)-43027334 ^ (long)43026944), (int)((long)680167854 ^ (long)680186955)) /* "Whether or not to add positions to the trail" */);
        ((34X)((34X)((34X)this.4().5(70.b((int)((long)-232951205 ^ (long)232950826), (int)((long)-1218100736 ^ (long)1218094163)) /* "Active" */)).7(70.b((int)((long)1324331241 ^ (long)-1324331382), (int)((long)-2115531416 ^ (long)2115511690)) /* "active" */)).1(70.b((int)((long)-43027334 ^ (long)43026944), (int)((long)680167854 ^ (long)680186955)) /* "Whether or not to add positions to the trail" */)).7 = comparable;
        this.8 = (1P)j2.5();
        this.9 = (1P)((34X)((34X)((34X)this.4().5(70.b((int)((long)-1490545708 ^ (long)1490546100), (int)((long)1021210498 ^ (long)-1021208927)) /* "Walls" */)).7(70.b((int)((long)-550085918 ^ (long)550085785), (int)((long)-1366796459 ^ (long)-1366797220)) /* "walls" */)).1(70.b((int)((long)-680456887 ^ (long)680457008), (int)((long)1948080961 ^ (long)1948064141)) /* "Show the breadcrumbs through walls" */)).5();
        comparable = Color.fromRGB((int)((int)((long)-1695286633 ^ (long)-1695286680)), (int)((int)((long)862712004 ^ (long)862712004)), (int)((int)((long)703967666 ^ (long)703967666)));
        j2 = (34E)((34E)((34E)this.0().5(70.b((int)((long)69354768 ^ (long)-69354636), (int)((long)-659372041 ^ (long)659389498)) /* "Color" */)).7(70.b((int)((long)272185957 ^ (long)-272186344), (int)((long)627966372 ^ (long)-627998031)) /* "color" */)).1(70.b((int)((long)250608226 ^ (long)-250608619), (int)((long)684161517 ^ (long)684159636)) /* "The color" */);
        ((34E)((34E)((34E)this.0().5(70.b((int)((long)69354768 ^ (long)-69354636), (int)((long)-659372041 ^ (long)659389498)) /* "Color" */)).7(70.b((int)((long)272185957 ^ (long)-272186344), (int)((long)627966372 ^ (long)-627998031)) /* "color" */)).1(70.b((int)((long)250608226 ^ (long)-250608619), (int)((long)684161517 ^ (long)684159636)) /* "The color" */)).7 = comparable;
        this.0 = (1R)((34E)j2).5();
        comparable = (int)((long)-490563662 ^ (long)-490563763);
        j2 = ((34e)((34e)((34e)this.1().5(70.b((int)((long)510430669 ^ (long)-510430289), (int)((long)-1421970639 ^ (long)1421978896)) /* "Alpha" */)).7(70.b((int)((long)707703864 ^ (long)-707704231), (int)((long)2078627967 ^ (long)-2078629533)) /* "alpha" */)).1(70.b((int)((long)1607254125 ^ (long)-1607254499), (int)((long)558925381 ^ (long)558928968)) /* "Alpha color value" */)).3((int)((long)289071756 ^ (long)289071756)).2((int)((long)-273591824 ^ (long)-273592049));
        ((34e)((34e)((34e)this.1().5(70.b((int)((long)510430669 ^ (long)-510430289), (int)((long)-1421970639 ^ (long)1421978896)) /* "Alpha" */)).7(70.b((int)((long)707703864 ^ (long)-707704231), (int)((long)2078627967 ^ (long)-2078629533)) /* "alpha" */)).1(70.b((int)((long)1607254125 ^ (long)-1607254499), (int)((long)558925381 ^ (long)558928968)) /* "Alpha color value" */)).3((int)((long)289071756 ^ (long)289071756)).2((int)((long)-273591824 ^ (long)-273592049)).7 = comparable;
        this.2M = (1z)((34e)j2).5();
        comparable = Float.valueOf(10.0f);
        j2 = ((34e)((34e)((34e)this.9().5(70.b((int)((long)-2010999944 ^ (long)2011000078), (int)((long)-1898757209 ^ (long)-1898762368)) /* "Smoothing" */)).7(70.b((int)((long)548648961 ^ (long)-548649370), (int)((long)-687823009 ^ (long)-687801648)) /* "smooth" */)).1(70.b((int)((long)-480399405 ^ (long)480399798), (int)((long)538920285 ^ (long)538904506)) /* "Line smoothing factor, laggier" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(10.0f));
        ((34e)((34e)((34e)this.9().5(70.b((int)((long)-2010999944 ^ (long)2011000078), (int)((long)-1898757209 ^ (long)-1898762368)) /* "Smoothing" */)).7(70.b((int)((long)548648961 ^ (long)-548649370), (int)((long)-687823009 ^ (long)-687801648)) /* "smooth" */)).1(70.b((int)((long)-480399405 ^ (long)480399798), (int)((long)538920285 ^ (long)538904506)) /* "Line smoothing factor, laggier" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(10.0f)).7 = comparable;
        this.25 = (1A)((34e)j2).5();
        comparable = Float.valueOf(1.0f);
        j2 = ((34e)((34e)((34e)this.9().5(70.b((int)((long)1198532753 ^ (long)-1198532873), (int)((long)1798499411 ^ (long)-1798473757)) /* "Width" */)).7(70.b((int)((long)1901103196 ^ (long)-1901103580), (int)((long)1363270031 ^ (long)-1363265134)) /* "width" */)).1(70.b((int)((long)-339692017 ^ (long)339691633), (int)((long)943352640 ^ (long)-943351517)) /* "Line width of the Breadcrumbs" */)).3(Float.valueOf(0.1f)).2(Float.valueOf(5.0f));
        ((34e)((34e)((34e)this.9().5(70.b((int)((long)1198532753 ^ (long)-1198532873), (int)((long)1798499411 ^ (long)-1798473757)) /* "Width" */)).7(70.b((int)((long)1901103196 ^ (long)-1901103580), (int)((long)1363270031 ^ (long)-1363265134)) /* "width" */)).1(70.b((int)((long)-339692017 ^ (long)339691633), (int)((long)943352640 ^ (long)-943351517)) /* "Line width of the Breadcrumbs" */)).3(Float.valueOf(0.1f)).2(Float.valueOf(5.0f)).7 = comparable;
        this.7 = (1A)((34e)j2).5();
        comparable = Float.valueOf(0.1f);
        j2 = ((34e)((34e)((34e)this.9().5(70.b((int)((long)-1818143355 ^ (long)1818143737), (int)((long)2105183047 ^ (long)2105192629)) /* "Height" */)).7(70.b((int)((long)866142175 ^ (long)-866141782), (int)((long)-1576215837 ^ (long)-1576223391)) /* "height" */)).1(70.b((int)((long)-1158041547 ^ (long)1158041159), (int)((long)26161605 ^ (long)26158708)) /* "How high off the ground to draw" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(1.0f));
        ((34e)((34e)((34e)this.9().5(70.b((int)((long)-1818143355 ^ (long)1818143737), (int)((long)2105183047 ^ (long)2105192629)) /* "Height" */)).7(70.b((int)((long)866142175 ^ (long)-866141782), (int)((long)-1576215837 ^ (long)-1576223391)) /* "height" */)).1(70.b((int)((long)-1158041547 ^ (long)1158041159), (int)((long)26161605 ^ (long)26158708)) /* "How high off the ground to draw" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(1.0f)).7 = comparable;
        this.2 = (1A)((34e)j2).5();
        this.4 = new Int2ObjectArrayMap();
        this.5 = new Listener(object -> {
            boolean bl;
            block15: {
                block14: {
                    bl = \u200d;
                    if (bl || bl) return;
                    if (70.3.s == null) break block14;
                    if (bl) return;
                    if (((3sh)object).5 == EventState.PRE) break block15;
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            2R.1(this, 70.b((int)((long)-112166758 ^ (long)112166629), (int)((long)2102580917 ^ (long)-2102577073)) /* "suffix" */, String.valueOf((int)((double)this.7().size() / (((Float)this.25.0()).doubleValue() / (double)this.25.9))));
            if (bl || bl) return;
            if (!this.8.2) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            if (this.7().isEmpty()) {
                if (bl || bl) return;
                this.4();
                if (bl) return;
                return;
            }
            if (bl) return;
            object = this.7().get(this.7().size() - (int)((long)1327751996 ^ (long)1327751997));
            if (bl || bl) return;
            if (Math.sqrt(70.3.s.h(((8S)object).9, ((8S)object).1, ((8S)object).2)) > 1.0 / ((Float)this.25.0()).doubleValue()) {
                if (bl || bl) return;
                this.4();
                if (bl) return;
            }
            if (!bl) return;
        }, new Predicate[(int)((long)1159569634 ^ (long)1159569634)]);
        this.1 = new Listener(t -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u200d;
                        if (bl || bl) break block2;
                        if (t.5 != 70.3.s) break block3;
                        if (bl || bl) break block2;
                        this.0();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)35634425 ^ (long)35634425)]);
        this.6 = new Listener(object -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u200d;
                        if (bl || bl) break block2;
                        9b.6((boolean)((long)-934417906 ^ (long)-934417905));
                        if (bl || bl) break block2;
                        4L[] lArray = new 4L[(int)((long)1670201443 ^ (long)1670201442)];
                        lArray[(int)((long)1198610670 ^ (long)1198610670)] = 4L.c;
                        9b.3(lArray);
                        if (bl || bl) break block2;
                        if (this.9.2) break block3;
                        if (bl || bl) break block2;
                        RenderSystem.enableDepthTest();
                        if (bl || bl) break block2;
                        RenderSystem.depthMask((boolean)((long)-1476998351 ^ (long)-1476998352));
                        if (bl) break block2;
                    }
                    if (bl) break block2;
                    RenderSystem.color4f((float)this.0.6(), (float)this.0.4(), (float)this.0.7(), (float)((float)this.2M.4 / 255.0f));
                    if (bl || bl) break block2;
                    RenderSystem.lineWidth((float)this.7.9);
                    if (bl || bl) break block2;
                    object = new AtomicInteger((int)((long)-748254454 ^ (long)-748254454));
                    if (bl || bl) break block2;
                    Tessellator tessellator = 9b.5;
                    if (bl || bl) break block2;
                    2c c2 = (2c)3.ac();
                    if (bl || bl) break block2;
                    this.7().forEach(arg_0 -> this.0((AtomicInteger)object, tessellator, c2, arg_0));
                    if (bl || bl) break block2;
                    tessellator.draw((int)((long)170689352 ^ (long)170689355));
                    if (bl || bl) break block2;
                    9b.3();
                    if (bl || bl) break block2;
                    9b.6((boolean)((long)-1226268944 ^ (long)-1226268944));
                    if (!bl && !bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)932554285 ^ (long)932554285)]);
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 0(AtomicInteger atomicInteger, Tessellator tessellator, 2c c2, 8S s) {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u200d;
                    if (bl || bl) break block2;
                    if (!((double)atomicInteger.incrementAndGet() > ((Float)this.25.0()).doubleValue() - (double)this.25.9)) break block3;
                    if (bl || bl) break block2;
                    tessellator.addVertex((float)(s.9 - c2.getRenderPosX()), (float)(s.1 - c2.getRenderPosY() + (double)this.2.9), (float)(s.2 - c2.getRenderPosZ()));
                    if (bl || bl) break block2;
                    atomicInteger.set((int)((long)-1754777091 ^ (long)-1754777091));
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    public final List<8S> 8(int n2) {
        boolean bl = \u200d;
        if (bl || bl) {
            return null;
        }
        return (List)this.4.computeIfAbsent(n2, n -> {
            boolean bl = \u200d;
            if (bl || bl) {
                return null;
            }
            return new ArrayList();
        });
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u200d;
                    if (bl || bl) break block2;
                    if (70.3.s == null) break block3;
                    if (bl || bl) break block2;
                    this.0();
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 4() {
        block3: {
            block2: {
                boolean bl = \u200d;
                if (bl || bl) break block2;
                this.7().add(new 8S(70.3.s.cD(), 70.3.s.cE(), 70.3.s.cH()));
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 70.\u200d;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-900812802 ^ (long)900813197)) & (int)((long)-235788865 ^ (long)-235742656);
            if (var9_2) ** GOTO lbl-1000
            if (70.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 70.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-52989662 ^ (long)-52989662)] & (int)((long)1056717507 ^ (long)1056717372)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1238894711 ^ (long)-1238894723);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-2052772996 ^ (long)-2052772989);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-839064571 ^ (long)-839064551);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-722202867 ^ (long)-722202649);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)160326914 ^ (long)160326970);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-858928607 ^ (long)-858928612);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)399798027 ^ (long)399798255);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-238862039 ^ (long)-238861997);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1717885164 ^ (long)-1717884935);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)961888860 ^ (long)961888939);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)429300404 ^ (long)429300327);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)654533300 ^ (long)654533189);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)818908724 ^ (long)818908773);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-350940238 ^ (long)-350940223);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1489749198 ^ (long)-1489749225);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)2058397187 ^ (long)2058397399);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-767704674 ^ (long)-767704787);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-638245773 ^ (long)-638245671);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1711549113 ^ (long)-1711549051);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-724227007 ^ (long)-724226858);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-365686932 ^ (long)-365686835);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-110818368 ^ (long)-110818343);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-2086737269 ^ (long)-2086737371);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1400708299 ^ (long)-1400708288);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)333295125 ^ (long)333295261);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-2145376744 ^ (long)-2145376617);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)793284681 ^ (long)793284778);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)974736699 ^ (long)974736865);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)866935663 ^ (long)866935658);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)0x11EA11A1 ^ (long)300552584);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)335773760 ^ (long)335773723);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1412696225 ^ (long)-1412696215);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-38799526 ^ (long)-38799552);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1956802933 ^ (long)-1956803003);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1096748392 ^ (long)-1096748378);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1699304178 ^ (long)-1699303984);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1132016833 ^ (long)1132016815);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-385472417 ^ (long)-385472353);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)2095743879 ^ (long)2095743845);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1886023117 ^ (long)1886023166);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1612951367 ^ (long)-1612951547);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1881855048 ^ (long)-1881855119);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1300866936 ^ (long)1300866996);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)869435065 ^ (long)869434984);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)495476217 ^ (long)495476014);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1505983311 ^ (long)1505983458);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)143228421 ^ (long)143228640);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-774713724 ^ (long)-774713676);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)2030002968 ^ (long)2030003155);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1939172504 ^ (long)1939172557);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)600631555 ^ (long)600631627);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)492337688 ^ (long)492337700);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1956637416 ^ (long)-1956637319);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1205920254 ^ (long)1205920061);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)212874284 ^ (long)212874327);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1400318439 ^ (long)-1400318408);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)831122528 ^ (long)831122439);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1576263725 ^ (long)1576263728);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1919839520 ^ (long)1919839523);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)2034367031 ^ (long)2034367096);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1309909789 ^ (long)-1309909784);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1083728811 ^ (long)1083728830);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1190901217 ^ (long)1190901158);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1282338945 ^ (long)-1282338908);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-176593672 ^ (long)-176593766);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-260592083 ^ (long)-260591985);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-301634192 ^ (long)-301634098);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1019091236 ^ (long)-1019091401);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)567372366 ^ (long)567372381);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1297214183 ^ (long)-1297214195);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)323991235 ^ (long)323991286);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1872130125 ^ (long)-1872130187);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)135760606 ^ (long)135760464);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1567726457 ^ (long)1567726524);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-40586911 ^ (long)-40586984);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-802706851 ^ (long)-802706749);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1529034403 ^ (long)1529034264);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1227889632 ^ (long)1227889437);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1167240999 ^ (long)1167241080);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1988104412 ^ (long)1988104224);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-644834229 ^ (long)-644834072);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)294712856 ^ (long)294712985);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)464380112 ^ (long)464379977);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-872925866 ^ (long)-872925934);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-294572308 ^ (long)-294572358);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1849083002 ^ (long)-1849082940);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-364655964 ^ (long)-364656008);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-135623490 ^ (long)-135623668);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1930254462 ^ (long)1930254578);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1740608575 ^ (long)-1740608611);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-539830623 ^ (long)-539830583);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-601174759 ^ (long)-601174769);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1463393861 ^ (long)-1463393999);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1549699965 ^ (long)1549699889);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)445780510 ^ (long)445780726);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-131971812 ^ (long)-131971732);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1790929789 ^ (long)-1790929740);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)491078114 ^ (long)491078008);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1207492605 ^ (long)1207492579);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-956661467 ^ (long)-956661468);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)2127090157 ^ (long)2127090055);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1050898219 ^ (long)-1050898198);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-782614338 ^ (long)-782614363);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)2109992238 ^ (long)2109992272);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-185035886 ^ (long)-185035980);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-191156210 ^ (long)-191156100);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1765123519 ^ (long)1765123558);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1039201266 ^ (long)1039201042);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1589983977 ^ (long)1589983993);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)308772767 ^ (long)308772763);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)2093882484 ^ (long)2093882615);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1103106092 ^ (long)1103106100);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)169556583 ^ (long)169556547);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1382003409 ^ (long)1382003449);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1465813586 ^ (long)-1465813510);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-423037371 ^ (long)-423037413);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-650431698 ^ (long)-650431599);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1164422275 ^ (long)-1164422348);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)663957702 ^ (long)663957526);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-892586768 ^ (long)-892586938);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1796701983 ^ (long)-1796702014);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1351528530 ^ (long)-1351528553);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)870220493 ^ (long)870220306);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-678201666 ^ (long)-678201707);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)237747400 ^ (long)237747430);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1476224092 ^ (long)-1476224060);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)845921926 ^ (long)845921924);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1480008056 ^ (long)1480008140);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1002894032 ^ (long)1002894059);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1448533519 ^ (long)1448533679);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1615500765 ^ (long)-1615500715);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1224013283 ^ (long)1224013207);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1334624638 ^ (long)1334624764);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1035709742 ^ (long)-1035709712);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)163894081 ^ (long)163894077);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1853226453 ^ (long)-1853226386);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1744002355 ^ (long)1744002411);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-2096921597 ^ (long)-2096921413);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-601585548 ^ (long)-601585423);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-531411249 ^ (long)-531411234);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1699750269 ^ (long)1699750298);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-361394132 ^ (long)-361393953);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1167924585 ^ (long)1167924725);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)921339171 ^ (long)921339230);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1765141370 ^ (long)-1765141333);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-887334176 ^ (long)-887334267);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1256333123 ^ (long)1256333262);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-2140509781 ^ (long)-2140509715);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-930391791 ^ (long)-930391683);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1236624700 ^ (long)-1236624746);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1791635377 ^ (long)-1791635275);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-210517128 ^ (long)-210517128);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-936196472 ^ (long)-936196475);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-451573759 ^ (long)-451573652);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1519592622 ^ (long)-1519592554);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1349998146 ^ (long)1349998290);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-2126693261 ^ (long)-2126693202);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1407148403 ^ (long)1407148380);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1644589469 ^ (long)-1644589357);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-845684540 ^ (long)-845684557);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1212968454 ^ (long)1212968595);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-79906645 ^ (long)-79906695);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-102086238 ^ (long)-102086167);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-580942348 ^ (long)-580942558);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1455100677 ^ (long)1455100915);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-118981737 ^ (long)-118981842);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-918225318 ^ (long)-918225186);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1812905383 ^ (long)1812905286);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1915690236 ^ (long)-1915690097);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)321786838 ^ (long)321786647);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)601924082 ^ (long)601923949);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-494376096 ^ (long)-494376017);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1895186507 ^ (long)-1895186611);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)356764276 ^ (long)356764222);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-88045492 ^ (long)-88045528);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)286085645 ^ (long)286085650);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1548903731 ^ (long)-1548903734);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1123426807 ^ (long)1123426694);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1320572238 ^ (long)1320572197);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1708102181 ^ (long)-1708102281);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1643996320 ^ (long)-1643996297);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1486863481 ^ (long)1486863597);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-801887936 ^ (long)-801887965);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1180927592 ^ (long)-1180927734);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-2052072085 ^ (long)-2052072111);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)72458476 ^ (long)72458474);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)676720202 ^ (long)676720132);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-201533234 ^ (long)-201533343);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1330931394 ^ (long)1330931205);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-638767878 ^ (long)-638767958);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)821921189 ^ (long)821921135);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)770129363 ^ (long)770129182);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1123755929 ^ (long)-1123755794);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)368174544 ^ (long)368174582);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1724629839 ^ (long)1724629992);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-692890255 ^ (long)-692890211);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)277119495 ^ (long)277119558);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1502559725 ^ (long)1502559717);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)929845300 ^ (long)929845347);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1269548252 ^ (long)1269548036);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1310649457 ^ (long)1310649473);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1854478213 ^ (long)-1854478257);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-559273237 ^ (long)-559273241);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-633788709 ^ (long)-633788891);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1008056874 ^ (long)-1008056914);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1931004679 ^ (long)1931004743);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1527573542 ^ (long)1527573647);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)671217157 ^ (long)671217258);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-2031283777 ^ (long)-2031283963);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1611743659 ^ (long)-1611743623);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1586721573 ^ (long)-1586721642);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1770018162 ^ (long)-1770018063);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1727205353 ^ (long)-1727205147);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)587293241 ^ (long)587293227);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1302264769 ^ (long)-1302264658);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)780493613 ^ (long)780493575);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1193059654 ^ (long)1193059822);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1009646745 ^ (long)-1009646673);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-612462299 ^ (long)-612462334);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1870812907 ^ (long)1870812897);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1603443794 ^ (long)-1603443724);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1985970914 ^ (long)-1985970715);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)501965633 ^ (long)501965752);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-415925849 ^ (long)-415925866);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1392801982 ^ (long)1392801872);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)256719347 ^ (long)256719200);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-932404460 ^ (long)-932404428);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)853212704 ^ (long)853212804);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1047480730 ^ (long)-1047480817);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)247990655 ^ (long)247990681);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1186673455 ^ (long)1186673522);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-697761808 ^ (long)-697762011);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)2113621877 ^ (long)2113621956);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-2040179595 ^ (long)-2040179490);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-2015811691 ^ (long)-2015811744);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)19775167 ^ (long)19775078);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1045892804 ^ (long)1045892697);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1143069228 ^ (long)-1143069327);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1407176517 ^ (long)-1407176456);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1236308694 ^ (long)1236308656);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1502622635 ^ (long)1502622525);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1521373473 ^ (long)-1521373488);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)672890104 ^ (long)672889933);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-743140892 ^ (long)-743141109);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1872566028 ^ (long)-1872566156);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1719409565 ^ (long)-1719409558);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1032259181 ^ (long)-1032259136);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1377499647 ^ (long)1377499414);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-2065432707 ^ (long)-2065432753);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)736104222 ^ (long)736104344);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1116467456 ^ (long)1116467611);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)195868107 ^ (long)195867980);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1918080291 ^ (long)-1918080443);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1084751000 ^ (long)1084750885);
                    if (!70.\u200d) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)997420377 ^ (long)997420526);
                    if (!70.\u200d) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1902605349 ^ (long)-1902605355);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-2084400410 ^ (long)-2084400615)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)903637872 ^ (long)903648399)) >>> (int)((long)1713040980 ^ (long)1713040988)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-617823400 ^ (long)-617823400);
            if (!70.\u200d) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-956952539 ^ (long)-956952537);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)88599085 ^ (long)88599086) | var5_6 << (int)((long)1948138976 ^ (long)1948138981)) ^ var3_4[var7_8]) & (int)((long)1905948498 ^ (long)1905948589);
                    if (70.\u200d) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)957923407 ^ (long)957923404) | var6_7 << (int)((long)1553258725 ^ (long)1553258720)) ^ var3_4[var7_8]) & (int)((long)1023248404 ^ (long)1023248619);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            70.e[var2_3] = new String(var3_4).intern();
        }
        return 70.e[var2_3];
    }
}

