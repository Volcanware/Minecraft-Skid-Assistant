/* ==========================================================================
 * MODULE: No Render
 * CATEGORY (inferred): Render
 * DESCRIPTION: Prevent item entity rendering to reduce lag
 * OBFUSCATED CLASS: net.impactclient.7n
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqa
 *  aqe
 *  bcv
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  on
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.2w$6X;
import net.impactclient.34X;
import net.impactclient.34s;
import net.impactclient.3W;
import net.impactclient.3X;
import net.impactclient.3i;
import net.impactclient.4f;
import net.impactclient.6L;
import net.impactclient.8h;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7n
extends 3X
implements 8h {
    public static final boolean \u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009;
    @EventHandler
    private final Listener<3W> 5;
    private static final String[] d;
    @EventHandler
    private final Listener<4f> 6;
    private 1P 8;
    @EventHandler
    private final Listener<3i> 9;
    private static final String[] e;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1965545037 ^ (long)1965551456)) & (int)((long)505658131 ^ (long)505627884);
            if (var9_2) ** GOTO lbl-1000
            if (7n.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7n.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1922548225 ^ (long)1922548225)] & (int)((long)1571732513 ^ (long)1571732702)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1246701548 ^ (long)-1246701433);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1686219468 ^ (long)1686219310);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-476097801 ^ (long)-476097928);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)435085088 ^ (long)435085282);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1719801951 ^ (long)-1719801906);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-227337855 ^ (long)-227337858);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)780833299 ^ (long)780833342);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1387491333 ^ (long)-1387491330);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1292473189 ^ (long)1292473106);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)2116081939 ^ (long)2116082000);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1014599554 ^ (long)1014599601);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1944989999 ^ (long)1944990206);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-980516281 ^ (long)-980516323);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-2146075981 ^ (long)-2146076137);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1568782186 ^ (long)1568782221);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1095190646 ^ (long)-1095190718);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1996998811 ^ (long)-1996998771);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-715616656 ^ (long)-715616614);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-146654520 ^ (long)-146654671);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1415571739 ^ (long)-1415571841);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-805714449 ^ (long)-805714645);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-877681333 ^ (long)-877681309);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)944476401 ^ (long)944476309);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-718875028 ^ (long)-718875122);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1118184270 ^ (long)-1118184318);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-938877932 ^ (long)-938877909);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1407612245 ^ (long)-1407612226);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)558906972 ^ (long)558907007);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)458285999 ^ (long)458285830);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1658306768 ^ (long)1658306599);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-311992096 ^ (long)-311992199);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1301399518 ^ (long)1301399467);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1477458087 ^ (long)1477457938);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1393596421 ^ (long)-1393596606);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1159006162 ^ (long)-1159006145);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1737170490 ^ (long)1737170555);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1340277419 ^ (long)-1340277327);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1396329243 ^ (long)-1396329355);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)489695954 ^ (long)489695814);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)2054826775 ^ (long)2054826954);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-273291569 ^ (long)-273291586);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1297838064 ^ (long)1297838059);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1372472707 ^ (long)-1372472613);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)785900302 ^ (long)785900534);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1418203159 ^ (long)-1418203142);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-82670097 ^ (long)-82670107);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-713664244 ^ (long)-713664072);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1975991601 ^ (long)1975991596);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-967096210 ^ (long)-967096131);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1602882777 ^ (long)-1602882651);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)937772035 ^ (long)937772097);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-501771671 ^ (long)-501771623);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)999144828 ^ (long)999144730);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)745837639 ^ (long)745837689);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)259237357 ^ (long)259237329);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1795694131 ^ (long)1795694319);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)921077827 ^ (long)921077783);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)327108662 ^ (long)327108687);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-885988545 ^ (long)-885988492);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1139255185 ^ (long)-1139255234);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1114415508 ^ (long)-1114415507);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1783777496 ^ (long)-1783777373);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-728908180 ^ (long)-728908092);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1387847599 ^ (long)-1387847641);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1244067404 ^ (long)1244067489);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1088544422 ^ (long)-1088544281);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)310130044 ^ (long)310129993);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)399369333 ^ (long)399369407);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1625736618 ^ (long)1625736675);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1819913361 ^ (long)1819913250);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)100379761 ^ (long)100379823);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)2037939454 ^ (long)2037939233);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1374357644 ^ (long)1374357651);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1937500587 ^ (long)1937500427);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-873489446 ^ (long)-873489484);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1320667907 ^ (long)-1320668138);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)232218474 ^ (long)232218484);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)934038657 ^ (long)934038655);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1750676838 ^ (long)-1750676991);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-585456164 ^ (long)-585456316);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)366540372 ^ (long)366540454);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)58773673 ^ (long)58773710);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)701147125 ^ (long)701147004);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1099250126 ^ (long)1099250159);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-756301979 ^ (long)-756302026);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1524225259 ^ (long)-1524225089);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1376968959 ^ (long)-1376968751);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1587482295 ^ (long)1587482337);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-357991320 ^ (long)-357991325);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1747648142 ^ (long)1747648002);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)516314747 ^ (long)516314778);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1578403405 ^ (long)-1578403415);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1627341980 ^ (long)1627341905);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1016099840 ^ (long)-1016099776);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1840924901 ^ (long)-1840924835);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-606178266 ^ (long)-606178079);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)435954845 ^ (long)435954782);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1807587302 ^ (long)1807587213);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-2138943248 ^ (long)-2138943484);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)783039156 ^ (long)783039224);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1299628757 ^ (long)1299628662);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1679513660 ^ (long)1679513788);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)654068814 ^ (long)654068884);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-45968511 ^ (long)-45968551);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1586018900 ^ (long)1586018822);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1257036076 ^ (long)1257036112);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1909815346 ^ (long)-1909815347);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1507526430 ^ (long)1507526500);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)927770214 ^ (long)927770228);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1187892040 ^ (long)1187892019);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1168199391 ^ (long)-1168199292);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1943339947 ^ (long)-1943339906);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1928936842 ^ (long)-1928936938);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)201903879 ^ (long)201903880);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)799872481 ^ (long)799872446);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1196310012 ^ (long)1196309840);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)2143821262 ^ (long)2143821209);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)547273631 ^ (long)547273609);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-884578320 ^ (long)-884578418);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1972905674 ^ (long)-1972905567);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1924578107 ^ (long)-1924578241);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1664002730 ^ (long)-1664002791);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-251455972 ^ (long)-251455952);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)551477980 ^ (long)551477995);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-741780077 ^ (long)-741780202);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-2115434244 ^ (long)-2115434405);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1034826735 ^ (long)1034826688);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1314760190 ^ (long)1314760016);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1590698813 ^ (long)-1590698801);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-4340208 ^ (long)-4340028);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1210027369 ^ (long)-1210027487);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1379606573 ^ (long)1379606656);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1745589564 ^ (long)-1745589540);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)909205354 ^ (long)909205458);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1062270189 ^ (long)1062270006);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1314880341 ^ (long)-1314880402);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)864338378 ^ (long)864338416);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)854094605 ^ (long)854094661);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1913615852 ^ (long)1913615785);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)644839977 ^ (long)644839982);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-432997797 ^ (long)-432997705);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)349635011 ^ (long)349635019);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1306828314 ^ (long)-1306828320);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-860514185 ^ (long)-860514060);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1383519770 ^ (long)1383519890);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1324259348 ^ (long)1324259407);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-443411561 ^ (long)-443411631);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)770220458 ^ (long)770220482);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-330167126 ^ (long)-330167171);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1663747813 ^ (long)1663747707);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1407442094 ^ (long)-1407442060);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)869314408 ^ (long)869314408);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)2027002054 ^ (long)2027002011);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1003042977 ^ (long)1003043029);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1051851528 ^ (long)1051851690);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1908929504 ^ (long)1908929393);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)550488685 ^ (long)550488592);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1744287226 ^ (long)-1744287215);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1231482725 ^ (long)-1231482839);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1176604715 ^ (long)-1176604833);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1745200356 ^ (long)-1745200298);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1450672012 ^ (long)-1450671902);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-2017693151 ^ (long)-2017693101);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1911927664 ^ (long)1911927639);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-998454176 ^ (long)-998454103);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)33323524 ^ (long)33323704);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)802095936 ^ (long)802096060);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1396303166 ^ (long)1396303241);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1715586327 ^ (long)1715586449);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)341349342 ^ (long)341349331);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-306443076 ^ (long)-306443181);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)153249662 ^ (long)153249717);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1544962116 ^ (long)1544962148);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)582663872 ^ (long)582663918);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1934777677 ^ (long)-1934777638);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1397864264 ^ (long)-1397864370);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-446152798 ^ (long)-446152765);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-791674683 ^ (long)-791674757);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-76933404 ^ (long)-76933538);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1216512072 ^ (long)-1216512233);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1134058865 ^ (long)1134059007);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-11361658 ^ (long)-11361614);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)2103378222 ^ (long)2103378244);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1821193353 ^ (long)-1821193465);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1475681022 ^ (long)-1475680911);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)299928393 ^ (long)299928447);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1032453299 ^ (long)1032453262);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)655058225 ^ (long)655058404);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1201349795 ^ (long)-1201349885);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)309662133 ^ (long)309662075);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)897815098 ^ (long)897815195);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)341317583 ^ (long)341317459);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-1553399642 ^ (long)-1553399774);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)386098706 ^ (long)386098815);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1534427608 ^ (long)-1534427629);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1927789955 ^ (long)-1927789886);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-895535210 ^ (long)-895535299);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-743669566 ^ (long)-743669556);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-169361242 ^ (long)-169361217);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1632818152 ^ (long)1632818168);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)66109089 ^ (long)66109010);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)461375642 ^ (long)461375517);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1751921436 ^ (long)1751921610);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)374942555 ^ (long)374942467);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1366993513 ^ (long)-1366993465);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1111056165 ^ (long)-1111056161);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1400569024 ^ (long)1400569058);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1798706416 ^ (long)1798706181);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-453642698 ^ (long)-453642513);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)279038526 ^ (long)279038557);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1526613393 ^ (long)1526613408);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1399738858 ^ (long)1399738633);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-99131784 ^ (long)-99131904);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-842617303 ^ (long)-842617317);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1898640109 ^ (long)-1898640086);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1014267371 ^ (long)1014267314);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1538204432 ^ (long)-1538204647);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)2073373401 ^ (long)2073373205);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-108776963 ^ (long)-108777031);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1076509972 ^ (long)1076510000);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-351620436 ^ (long)-351620546);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1365046109 ^ (long)-1365046074);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-242766769 ^ (long)-242766691);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1905861349 ^ (long)-1905861226);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)957149758 ^ (long)957149808);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)928986148 ^ (long)928986289);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1052394887 ^ (long)-1052394987);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1927448867 ^ (long)-1927448844);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1914857898 ^ (long)1914857874);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)2014449289 ^ (long)2014449257);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1710570002 ^ (long)-1710570194);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)88237064 ^ (long)88237076);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1237459836 ^ (long)-1237459847);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-2064305269 ^ (long)-2064305340);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1471025287 ^ (long)-1471025207);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1732665528 ^ (long)-1732665491);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)869082122 ^ (long)869082289);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-921732566 ^ (long)-921732373);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-499840470 ^ (long)-499840316);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-278937260 ^ (long)-278937343);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1142356181 ^ (long)1142356068);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)2006608880 ^ (long)2006608868);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1979065157 ^ (long)1979065113);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-379580616 ^ (long)-379580601);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)742687002 ^ (long)742687024);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1308753250 ^ (long)-1308753297);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)378386104 ^ (long)378386014);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)692082957 ^ (long)692083084);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1280929108 ^ (long)1280929043);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1944544060 ^ (long)1944544161);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1865575807 ^ (long)1865575834);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1619780903 ^ (long)1619780910);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1280169807 ^ (long)-1280169732);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1888434239 ^ (long)1888434237);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)552110828 ^ (long)552110707);
                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)362425051 ^ (long)362424864);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)977422275 ^ (long)977422140)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)407729478 ^ (long)407734969)) >>> (int)((long)1543218049 ^ (long)1543218057)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)985604767 ^ (long)985604767);
            if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1219712940 ^ (long)1219712942);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1573942511 ^ (long)1573942508) | var5_6 << (int)((long)1985802564 ^ (long)1985802561)) ^ var3_4[var7_8]) & (int)((long)318247474 ^ (long)318247629);
                    if (7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1416107009 ^ (long)-1416107012) | var6_7 << (int)((long)365548008 ^ (long)365548013)) ^ var3_4[var7_8]) & (int)((long)123541050 ^ (long)123541189);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7n.e[var2_3] = new String(var3_4).intern();
        }
        return 7n.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1892566772 ^ (long)1892566769)];
            if (var7) break block23;
            var3_2 = (int)((long)868310915 ^ (long)868310915);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u113d\u382c\u2bb2\u23c6\u1144\u3805\u2b14\u23b6\u114f\u38e1\u2b6f\u2335\u1165\u38cd\u2bf9\u2337\u1103\u3847\u2b7b\u235e\u1178\u381b\u2b86\u23c4\u11ba\u3865\u2bfb\u233b\u11c0\u384d\u2bf1\u238a\u1100\u38cb\u2bc8\u23a5\u1186\u3843\u2b57\u2317\u1144\u3875\u2b06\u230f\u1127\u38df\u2b47\u2301\u111f\u383c\u2b39\u2391\u11ba\u384f\u2b3d\u23fa\u111e", -793954678);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1172762860 ^ (long)-1172762862);
            if (var7) break block23;
            var0_6 = (int)((long)573706709 ^ (long)-573706710);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1695386720 ^ (long)1695386711);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1173330798 ^ (long)1173330797);
                    if (7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u2349\u0a5d\u19d4\u1180\u2361\u0a42\u1905\u116f\u2338\u0a00\u1998\u112a\u2314\u0a7d\u19a6\u1109\u23b3\u0a4c\u1928\u11aa\u23de\u0a1c\u1909\u11ce\u23bd\u0af5\u19c4\u11c6\u23ba\u0aaa\u19c8\u11fe\u23b7\u0a1f\u1999\u1188\u23a9\u0ab0\u19b1\u118a\u234c\u0a26\u19bd\u11d3\u23de\u0aaf\u1953\u1135\u23c4\u0a04\u19f9\u110e\u232f\u0a6a\u199c\u1135\u23cb\u0ac8\u1999\u112f\u237d\u0a6c\u1938\u1188\u230c\u0a32\u19a7\u111d\u2347\u0ab0\u1930\u11ea\u2360\u0a51\u1907\u1109\u23aa", 610141418);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1163085573 ^ (long)-1163085582);
                            var0_6 = (int)((long)-274475859 ^ (long)274475858);
                            while (true) {
                                v0 = (int)((long)-397115291 ^ (long)-397115381);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)838594933 ^ (long)838594933);
                                if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) ** continue;
                                throw null;
                            }
                            7n.d = var5_1;
                            7n.e = new String[(int)((long)-988806271 ^ (long)-988806268)];
                            if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-811314706 ^ (long)-811314706);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1582259319 ^ (long)-1582259320)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1214333286 ^ (long)1214333281)) {
                                case 0: {
                                    v15 = (int)((long)-2076378009 ^ (long)-2076378069);
                                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1487409173 ^ (long)1487409215);
                                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1263003514 ^ (long)1263003488);
                                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1012620682 ^ (long)1012620756);
                                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1528025402 ^ (long)-1528025378);
                                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1799681493 ^ (long)1799681471);
                                    if (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-741813287 ^ (long)-741813353);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7n.\u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    public 7n() {
        boolean bl = \u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009;
        super(7n.b((int)((long)-326844056 ^ (long)-326830010), (int)((long)-66377177 ^ (long)-66364704)) /* "No Render" */, 7n.b((int)((long)-696425910 ^ (long)-696427674), (int)((long)1699377738 ^ (long)-1699367173)) /* "Prevent item entity rendering to reduce lag" */);
        this.8 = (1P)((34X)((34X)((34X)this.4().5(7n.b((int)((long)-548118222 ^ (long)-548120547), (int)((long)-1559699529 ^ (long)1559723582)) /* "Remove" */)).7(7n.b((int)((long)1864824300 ^ (long)1864813761), (int)((long)877210238 ^ (long)-877211394)) /* "remove" */)).1(7n.b((int)((long)1357321285 ^ (long)1357327724), (int)((long)782486524 ^ (long)782486379)) /* "Removes items and prevents them from spawning in the world entirely" */)).5();
        this.5 = new Listener(w -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009;
                        if (bl || bl) break block2;
                        if (w.7 != EventState.PRE) break block3;
                        if (bl) break block2;
                        if (!(w.1 instanceof bcv)) break block3;
                        if (bl || bl) break block2;
                        w.cancel();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-1297816373 ^ (long)-1297816373)]);
        Predicate[] predicateArray = new Predicate[(int)((long)-186260663 ^ (long)-186260661)];
        Class[] classArray = new Class[(int)((long)-415972194 ^ (long)-415972193)];
        classArray[(int)((long)327559602 ^ (long)327559602)] = on.class;
        predicateArray[(int)((long)-1136721559 ^ (long)-1136721559)] = new 34s(classArray);
        predicateArray[(int)((long)-1050541337 ^ (long)-1050541338)] = i -> {
            boolean bl = \u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009;
            if (bl || bl) return true;
            if (i.2 == EventState.PRE) {
                if (bl) return true;
                return (int)((long)-1365842803 ^ (long)-1365842804) != 0;
            }
            if (!bl) return (int)((long)-494483842 ^ (long)-494483842) != 0;
            return true;
        };
        this.9 = new Listener(i -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009;
                        if (bl || bl) break block2;
                        on on2 = (on)i.7;
                        if (bl || bl) break block2;
                        if (!this.8.2) break block3;
                        if (bl) break block2;
                        if (on2.l() != aqe.L) break block3;
                        if (bl || bl) break block2;
                        i.cancel();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, predicateArray);
        this.6 = new Listener(f -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2001\u2000\u2004\u200a\u200e\u2008\u2008\u2005\u2009;
                        if (bl || bl) break block2;
                        if (!this.8.2) break block3;
                        if (bl || bl) break block2;
                        6L.3(7n.3.r).filter(bcv.class::isInstance).forEach(aqa::ad);
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-1447420784 ^ (long)-1447420784)]);
    }
}

