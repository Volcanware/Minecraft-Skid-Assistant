/* ==========================================================================
 * MODULE: Freecam
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Fly out of your body, like spectator mode
 * OBFUSCATED CLASS: net.impactclient.7k
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqa
 *  bru
 *  cfw
 *  dcn
 *  djl
 *  djz
 *  dnx
 *  dzk
 *  dzl
 *  fx
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import clientapi.load.mixin.7.2;
import java.lang.constant.Constable;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import me.zero.clarinet.hook.mixin.accessor.AccessorPlayerEntity;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.1c;
import net.impactclient.2w$6X;
import net.impactclient.34J;
import net.impactclient.34R;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.3sh;
import net.impactclient.4W;
import net.impactclient.8Y;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7k
extends 3X
implements 34R {
    public static 7k 0S;
    private 1P 6;
    private static final dzk 1;
    public 8Y 2;
    public static final boolean \u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b;
    @EventHandler
    private final Listener<3sh> 8;
    private djl 9;
    private 1K 5;
    private static final String[] e;
    @EventHandler
    private final Listener<4W> 4;
    private 1K 7;
    private 1P 0;
    private static final String[] d;

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)584931621 ^ (long)584931627)];
            if (var7) break block25;
            var3_2 = (int)((long)-1893486979 ^ (long)-1893486979);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\u2bd2\u02a6\u11f0\u199e\u2b11\u024e\u11cb\u19e5\u2baa\u0268\u118f\u19f6\u2bc4\u0272\u118b\u19b1\u2b60\u027f\u1150\u19fe\u2b98\u025e\u11e7\u19ac\u2bbb\u0223\u1145\u19f0\u2b02\u0242\u11f0\u190c\u2bbc\u02a3\u1140\u1968\u2b2d\u02c6\u1121\u19f9\u2be7\u0213\u11ca\u1901\u2b8c\u0262\u11ec\u1948\u2b17\u0203\u1147\u19ce\u2b09\u02f6\u1165\u1926\u2b0e\u028d\u1159\u1900\u2bba\u029e\u1129\u191a\u2b7d\u02d9\u11f5\u1917\u2ba9\u0296\u11ec\u1936\u2b22\u02c4\u1148\u194b\u2b70\u0298\u11ef\u192a\u2b18\u026e\u1137\u19dc\u2b69\u0250\u113d\u1931\u2bc7\u0274\u1141\u1972\u2b19\u0233\u114e\u1939\u2bc1\u02b3\u1153\u1956\u2b7c\u02b5\u1121\u19fe\u2b52\u02d1\u11e7\u19cb\u2b79\u029f\u11a7\u194d\u2b38\u02ae\u114b\u192d\u2bef\u02ec\u1165\u1942\u2b55\u0203\u1150\u1936\u2b15\u02a7\u1151\u194a\u2b9c\u02dc\u11e8\u1938\u2bfa\u0263\u1108\u19c1\u2b96\u027a\u11d8\u19a6\u2bbe\u02d9\u1179\u191d\u2bf8\u0240\u1198\u1921\u2bba\u0288\u118a\u195c\u2b24\u0206\u1112\u1951\u2b90\u02c0\u1101\u191d\u2b37\u0253\u1128\u1983\u2b0b\u0254\u11f7\u199f\u2bd5\u020d\u11b8\u1965\u2be3\u0291\u112c\u1962\u2b96\u02e7\u11ac\u196e\u2b45\u025d\u1128\u1990\u2b42\u0233\u117d\u19c0\u2b1b\u0233\u111d\u1975\u2b51\u0264\u11a2\u1998\u2bca\u02d7\u11d8\u1950\u2b64\u02bd\u111e\u1974\u2b24\u02eb\u11c3\u19a3\u2bcc\u020b\u11bb\u192e\u2b98\u020c\u11cb\u197d\u2bc5\u02a8\u11ed\u19f5\u2b39\u02e7\u11a2\u1974\u2b7f\u0228\u115d\u19b9\u2bec\u026c\u1168\u1909\u2bca\u0290\u117b\u19a4\u2bdf\u0213\u1187\u199f\u2ba6\u0287\u1177\u19ab\u2b07\u02a7\u11dc\u193b\u2b04\u02d7\u11e5\u1953\u2b89\u0245\u11cd\u1905\u2b86\u02cf\u113b\u1988\u2b53\u0200\u115a\u1995\u2b4b\u0293\u114f\u197c\u2b6e\u0295\u11d9\u192b\u2bb4\u02fb\u1109\u19ac\u2ba4\u025c\u11a3\u19f6\u2b8b\u02b5\u1126\u19cb\u2b12\u0285\u1125\u194c\u2bcb\u029c\u114d\u19c6\u2b70\u023e\u11bd\u19f0\u2b48\u0233\u111d\u1975\u2b61\u02bf\u1170\u1901\u2b40\u029f\u117b\u1913\u2b7f\u0205\u11d3\u1951\u2b88\u02fe\u11cb\u1923\u2b0d\u0237\u119e\u191a\u2b36\u0201\u11a0\u192a\u2b84\u02b9\u1126\u19a7\u2b9e\u024b\u1142\u19e1\u2b19\u02bc\u1177\u19f9\u2b36\u0236\u1112\u198b\u2b02\u02f2\u113b\u1949\u2b9e\u02a3\u11c5\u1970\u2b4a\u028d\u11dd\u1950\u2b8c\u0274\u117e\u19d0\u2b87\u02b1\u113d\u1976\u2b38\u0286\u1175\u1968\u2b93\u024b\u11c0\u19dd\u2b84\u02c4\u11b2\u19ea\u2bba\u0204\u113f\u196e\u2bc6\u02be\u1132\u1932\u2b45\u023d\u114c\u1971\u2b87\u023e\u1105\u19db\u2baa\u0220\u1140\u19ae\u2b26\u0219\u11ba\u1969\u2be0\u02d4\u1165\u199c\u2baa\u02f1\u1160\u196c\u2b82\u02a7\u11b6\u193a\u2b5a\u02df\u112c\u1937\u2b6e\u0299\u1129\u1957\u2bc0\u0274\u1196\u1909\u2bd6\u0200\u116e\u1957\u2bd3\u02ce\u118a\u19cc\u2bd6\u026a\u1119\u192f\u2b42\u0284\u1144\u1922\u2b53\u0203\u11d9\u19df\u2be7\u0297\u11f1\u19e1\u2b77", 2065894532);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)211638123 ^ (long)211638106);
            if (var7) break block25;
            var0_6 = (int)((long)-511422187 ^ (long)511422186);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)-192081393 ^ (long)-192081325);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)-1581869641 ^ (long)1581869640);
                        if (7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\u4cee\u65ec\u766e\u7e80\u4c09\u651e\u7655\u7e8a\u4c2d\u6556\u762f\u7e97\u4cc7\u650b\u766c\u7e0d\u4cb6\u6511\u7692", 435448812);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)-1758767278 ^ (long)-1758767276);
                                var0_6 = (int)((long)-431848201 ^ (long)431848200);
                                while (true) {
                                    v0 = (int)((long)-741800206 ^ (long)-741800243);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)-1607860286 ^ (long)-1607860286);
                                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) ** continue;
                                    throw null;
                                }
                                7k.d = var5_1;
                                7k.e = new String[(int)((long)-2075583276 ^ (long)-2075583270)];
                                if (7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)-1852904426 ^ (long)-1852904426);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)-2104853861 ^ (long)-2104853862)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-1361717070 ^ (long)-1361717067)) {
                                    case 0: {
                                        v15 = (int)((long)1732139172 ^ (long)1732139174);
                                        if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)-1191157641 ^ (long)-1191157676);
                                        if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)121011349 ^ (long)121011386);
                                        if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)1157950990 ^ (long)1157951058);
                                        if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)-1618453559 ^ (long)-1618453588);
                                        if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)-592612986 ^ (long)-592612970);
                                        if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)1395988786 ^ (long)1395988849);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                7k.1 = new 1c();
                break;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1708883632 ^ (long)1708854569)) & (int)((long)-1526607637 ^ (long)-1526649068);
            if (var9_2) ** GOTO lbl-1000
            if (7k.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7k.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)311440042 ^ (long)311440042)] & (int)((long)-1831220686 ^ (long)-1831220531)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-930490845 ^ (long)-930490655);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1442092254 ^ (long)1442092100);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-31602031 ^ (long)-31601941);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1831128230 ^ (long)-1831128190);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1186096525 ^ (long)-1186096637);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-254615290 ^ (long)-254615157);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-2142870296 ^ (long)-2142870335);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1246906946 ^ (long)1246907019);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)795494206 ^ (long)795494356);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1748048105 ^ (long)-1748048030);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1822487805 ^ (long)1822487640);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1607414181 ^ (long)1607414181);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-937610135 ^ (long)-937610062);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-627847878 ^ (long)-627847829);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1826586772 ^ (long)-1826586729);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)2027366490 ^ (long)2027366403);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)2139188259 ^ (long)2139188334);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1847972276 ^ (long)1847972123);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1521743850 ^ (long)-1521743685);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)153360684 ^ (long)153360653);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)963852253 ^ (long)963852224);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-180255166 ^ (long)-180255066);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1303333388 ^ (long)-1303333452);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1525742355 ^ (long)-1525742349);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1768652417 ^ (long)1768652430);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-318346334 ^ (long)-318346243);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1053014655 ^ (long)-1053014534);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1668994163 ^ (long)-1668994265);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1091928123 ^ (long)-1091928189);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-739590537 ^ (long)-739590437);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-337282656 ^ (long)-337282659);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1384190494 ^ (long)-1384190711);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)2109635678 ^ (long)2109635669);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)156370042 ^ (long)156369945);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)740439968 ^ (long)740440022);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1947871386 ^ (long)1947871309);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1827215014 ^ (long)1827215026);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1103492648 ^ (long)1103492769);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-855535952 ^ (long)-855536065);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1652012954 ^ (long)1652012835);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1370295069 ^ (long)-1370295246);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1793491381 ^ (long)1793491441);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)348867484 ^ (long)348867402);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-124129686 ^ (long)-124129687);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)858693364 ^ (long)858693310);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1044314334 ^ (long)1044314242);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-192671923 ^ (long)-192671985);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1268743534 ^ (long)-1268743670);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)401303153 ^ (long)401303258);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)2093523342 ^ (long)2093523420);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)485625146 ^ (long)485625198);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)94207648 ^ (long)94207564);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1229409419 ^ (long)1229409519);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1464580913 ^ (long)1464581032);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)812283407 ^ (long)812283415);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)546036183 ^ (long)546036198);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-328093422 ^ (long)-328093292);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-545027035 ^ (long)-545026911);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1503566412 ^ (long)-1503566591);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)117059272 ^ (long)117059156);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-2032694057 ^ (long)-2032694263);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1334684784 ^ (long)-1334684696);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)721118962 ^ (long)721118825);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-291511176 ^ (long)-291511057);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1636103387 ^ (long)-1636103238);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1312182698 ^ (long)-1312182621);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1144045529 ^ (long)1144045499);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)2120338953 ^ (long)2120339172);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)106476153 ^ (long)106476250);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)406011207 ^ (long)406011376);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-42131506 ^ (long)-42131669);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)944532850 ^ (long)944532805);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)180889942 ^ (long)180889996);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1103429059 ^ (long)1103428929);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1574113487 ^ (long)1574113506);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1998904159 ^ (long)-1998904140);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)2103448473 ^ (long)2103448402);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1893629670 ^ (long)1893629635);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)953084032 ^ (long)953084104);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1340862857 ^ (long)1340862838);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-2012580564 ^ (long)-2012580526);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1619610773 ^ (long)-1619610826);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1499154376 ^ (long)1499154307);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)442822941 ^ (long)442823025);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)359744048 ^ (long)359744181);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1116335195 ^ (long)1116335261);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)2025760268 ^ (long)2025760260);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1387526673 ^ (long)-1387526819);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)399110081 ^ (long)399109963);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1731115159 ^ (long)-1731115137);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-2055450208 ^ (long)-2055450170);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)597637622 ^ (long)597637620);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)172678955 ^ (long)172679069);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-330374887 ^ (long)-330374674);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1814611592 ^ (long)1814611574);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)843074841 ^ (long)843074818);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)299025731 ^ (long)299025781);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-532463345 ^ (long)-532463166);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1577408161 ^ (long)1577408204);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1464251140 ^ (long)-1464251282);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1817162701 ^ (long)-1817162514);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1413948792 ^ (long)-1413948732);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1022178352 ^ (long)-1022178440);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)223628182 ^ (long)223628140);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-730305919 ^ (long)-730305893);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)314466163 ^ (long)314466247);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)244862880 ^ (long)244862786);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1407470195 ^ (long)1407470285);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1039439136 ^ (long)-1039439120);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-643701915 ^ (long)-643701992);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-223677851 ^ (long)-223677890);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-611467504 ^ (long)-611467495);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1901715760 ^ (long)-1901715728);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1419588807 ^ (long)1419588670);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1016874883 ^ (long)-1016874859);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1852634032 ^ (long)-1852634036);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1595689403 ^ (long)1595689259);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1697484467 ^ (long)1697484372);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)487021578 ^ (long)487021774);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)529780186 ^ (long)529780014);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1644809122 ^ (long)1644809154);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-164204217 ^ (long)-164204167);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)466344730 ^ (long)466344901);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1829925814 ^ (long)1829925847);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)2114185207 ^ (long)2114185092);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)655723391 ^ (long)655723379);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)633349982 ^ (long)633349986);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-497122720 ^ (long)-497122796);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)628038455 ^ (long)628038576);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1389445499 ^ (long)1389445498);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)777969788 ^ (long)777969717);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1499444086 ^ (long)-1499443973);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1170870943 ^ (long)1170870801);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1331182295 ^ (long)1331182221);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1385614402 ^ (long)-1385614373);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1843005596 ^ (long)-1843005616);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)783477713 ^ (long)783477536);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1576931012 ^ (long)1576931008);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1732508496 ^ (long)-1732508636);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)183878728 ^ (long)183878726);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-767811398 ^ (long)-767811415);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)400088802 ^ (long)400088794);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-372536978 ^ (long)-372536964);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1286238440 ^ (long)-1286238250);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)637858068 ^ (long)637858171);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1346790723 ^ (long)-1346790664);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)2082295983 ^ (long)2082296007);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-2001685874 ^ (long)-2001685962);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1836060577 ^ (long)1836060640);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)806689463 ^ (long)806689528);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1548068283 ^ (long)1548068171);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1867973704 ^ (long)1867973721);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1592227170 ^ (long)1592227262);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)2138201815 ^ (long)2138201831);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)393669906 ^ (long)393669929);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-478142552 ^ (long)-478142708);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1774827442 ^ (long)-1774827326);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1501643215 ^ (long)-1501643124);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)701946787 ^ (long)701946788);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)862888495 ^ (long)862888531);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-2069027372 ^ (long)-2069027474);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-2105248953 ^ (long)-2105248925);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)384033201 ^ (long)384033106);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)847586261 ^ (long)847586118);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1972945116 ^ (long)1972944923);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1423595023 ^ (long)1423595148);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-48013854 ^ (long)-48014047);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)685000158 ^ (long)685000180);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-341562948 ^ (long)-341563076);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)279901797 ^ (long)279901869);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)685887635 ^ (long)685887562);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)751608227 ^ (long)751608230);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)691736332 ^ (long)691736540);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1557509435 ^ (long)1557509512);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)661596960 ^ (long)661597126);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1853482889 ^ (long)1853482896);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1566871185 ^ (long)-1566871225);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1280022894 ^ (long)-1280022803);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1058573906 ^ (long)-1058574063);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)922292817 ^ (long)922292977);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-632312650 ^ (long)-632312717);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1030979100 ^ (long)1030979278);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)956011606 ^ (long)956011569);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)2037862846 ^ (long)2037862868);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-843637700 ^ (long)-843637654);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1021510309 ^ (long)-1021510307);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1958703191 ^ (long)-1958703217);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)318774485 ^ (long)318774518);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1006423782 ^ (long)-1006423776);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-584477955 ^ (long)-584478040);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)391980333 ^ (long)391980496);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1361216566 ^ (long)1361216538);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1422815006 ^ (long)1422815079);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-2050837004 ^ (long)-2050837150);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1972689758 ^ (long)-1972689707);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)918390942 ^ (long)918390932);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)778154585 ^ (long)778154657);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1347496868 ^ (long)1347496724);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1824528746 ^ (long)-1824528668);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-895330514 ^ (long)-895330559);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-624405262 ^ (long)-624405504);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)575818489 ^ (long)575818430);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1269389204 ^ (long)-1269389075);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)747087052 ^ (long)747086946);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)81443394 ^ (long)81443530);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1243375924 ^ (long)1243376008);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1694795295 ^ (long)1694795345);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)52153644 ^ (long)52153742);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-319601241 ^ (long)-319601402);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-585046261 ^ (long)-585046200);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1491593638 ^ (long)-1491593651);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)2030608564 ^ (long)2030608447);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)202911055 ^ (long)202911000);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)480790829 ^ (long)480790968);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)715429693 ^ (long)715429787);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1684462759 ^ (long)-1684462800);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)2140637671 ^ (long)2140637637);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1549039820 ^ (long)1549039616);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-2093949146 ^ (long)-2093949055);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)104287585 ^ (long)104287645);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1827757157 ^ (long)-1827757198);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-13568479 ^ (long)-13568287);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1343036996 ^ (long)-1343036958);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1050545410 ^ (long)1050545603);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1218465469 ^ (long)1218465456);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1151642583 ^ (long)1151642438);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1911561327 ^ (long)-1911561304);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1289695546 ^ (long)1289695689);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1665766764 ^ (long)1665766822);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)541667898 ^ (long)541668073);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1911375830 ^ (long)-1911375689);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-241356368 ^ (long)-241356519);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-80395988 ^ (long)-80395805);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1141488642 ^ (long)1141488796);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-776688787 ^ (long)-776688712);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1726413754 ^ (long)1726413801);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)149678430 ^ (long)149678443);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1659651145 ^ (long)1659651263);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1685951303 ^ (long)-1685951401);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-465657813 ^ (long)-465657856);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-417498643 ^ (long)-417498746);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1892663308 ^ (long)1892663380);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1722732696 ^ (long)-1722732664);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)137842675 ^ (long)137842653);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-604163001 ^ (long)-604162956);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1074436771 ^ (long)-1074436766);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)422385815 ^ (long)422385863);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-655381875 ^ (long)-655381962);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)331625509 ^ (long)331625668);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-96544377 ^ (long)-96544360);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1550149018 ^ (long)1550149032);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1809544169 ^ (long)1809544142);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1550161433 ^ (long)1550161613);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1891069477 ^ (long)1891069642);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1440118246 ^ (long)1440118152);
                    if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)132229766 ^ (long)132229687);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1633626136 ^ (long)-1633626345)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)93342133 ^ (long)93369930)) >>> (int)((long)-552811698 ^ (long)-552811706)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1109948234 ^ (long)1109948234);
            if (!7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)216119358 ^ (long)216119356);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)26879125 ^ (long)26879126) | var5_6 << (int)((long)2116601990 ^ (long)2116601987)) ^ var3_4[var7_8]) & (int)((long)1398432692 ^ (long)1398432587);
                    if (7k.\u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-2041813539 ^ (long)-2041813538) | var6_7 << (int)((long)-734777169 ^ (long)-734777174)) ^ var3_4[var7_8]) & (int)((long)949280848 ^ (long)949280943);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7k.e[var2_3] = new String(var3_4).intern();
        }
        return 7k.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        boolean bl = \u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b;
        if (bl || bl) return;
        if (7k.3.s == null) {
            if (bl || bl) return;
            this.1((boolean)((long)2054733507 ^ (long)2054733507));
            if (bl || bl) return;
            return;
        }
        if (bl) return;
        this.2 = new 8Y((byte)((long)-1504271422 ^ (long)-1504271422));
        if (bl || bl) return;
        2 var1_2 = (2)((Object)this.2);
        if (bl || bl) return;
        2 var2_3 = (2)7k.3.s;
        if (bl || bl) return;
        this.2.d(var2_3.getPos().9, var2_3.getPos().1, var2_3.getPos().2);
        if (bl || bl) return;
        var1_2.setLastTickPos(var2_3.getPos());
        if (bl || bl) return;
        var1_2.setPrevPos(var2_3.getPos());
        if (bl || bl) return;
        var1_2.setRotations(var2_3.getRotations());
        if (bl || bl) return;
        var1_2.setPrevRotations(var2_3.getRotations());
        if (bl || bl) return;
        ((AccessorPlayerEntity)((Object)this.2)).setInventory(7k.3.s.bm);
        if (bl || bl) return;
        this.2.f = new dzl(7k.3.k);
        if (bl || bl) return;
        bru.e.a(this.2.bC);
        if (bl || bl) return;
        this.2.H = (int)((long)-1422358058 ^ (long)-1422358057);
        if (bl || bl) return;
        3.a((aqa)this.2);
        if (bl || bl) return;
        this.5();
        if (bl || bl) return;
        this.9 = 7k.3.k.g();
        if (!bl && !bl) return;
    }

    public 7k() {
        boolean bl = \u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b;
        super(7k.b((int)((long)41622278 ^ (long)41642139), (int)((long)1129283164 ^ (long)-1129268361)) /* "Freecam" */, 7k.b((int)((long)726245771 ^ (long)726258201), (int)((long)-1870760775 ^ (long)1870781652)) /* "Fly out of your body, like spectator mode" */);
        Constable constable = 2.0;
        34J j2 = ((34e)((34e)((34e)this.7().5(7k.b((int)((long)-989856255 ^ (long)-989885029), (int)((long)1077755422 ^ (long)1077766046)) /* "Horizontal Speed" */)).7(7k.b((int)((long)1046616541 ^ (long)1046637126), (int)((long)-738083766 ^ (long)738089574)) /* "speed" */)).1(7k.b((int)((long)788829398 ^ (long)788850511), (int)((long)721163111 ^ (long)721184145)) /* "The speed that you fly in the horizontal plane at" */)).3(1.0).2(10.0);
        ((34e)((34e)((34e)this.7().5(7k.b((int)((long)-989856255 ^ (long)-989885029), (int)((long)1077755422 ^ (long)1077766046)) /* "Horizontal Speed" */)).7(7k.b((int)((long)1046616541 ^ (long)1046637126), (int)((long)-738083766 ^ (long)738089574)) /* "speed" */)).1(7k.b((int)((long)788829398 ^ (long)788850511), (int)((long)721163111 ^ (long)721184145)) /* "The speed that you fly in the horizontal plane at" */)).3(1.0).2(10.0).7 = constable;
        this.5 = (1K)j2.5();
        constable = 1.0;
        j2 = ((34e)((34e)((34e)this.7().5(7k.b((int)((long)1287651703 ^ (long)1287680745), (int)((long)-587810063 ^ (long)-587794087)) /* "Vertical Speed" */)).7(7k.b((int)((long)-1011635447 ^ (long)-1011623780), (int)((long)2070660158 ^ (long)2070675011)) /* "vspeed" */)).1(7k.b((int)((long)-1813394059 ^ (long)-1813397779), (int)((long)1833418402 ^ (long)1833423855)) /* "The speed that you fly in the vertical axis at" */)).3(1.0).2(10.0);
        ((34e)((34e)((34e)this.7().5(7k.b((int)((long)1287651703 ^ (long)1287680745), (int)((long)-587810063 ^ (long)-587794087)) /* "Vertical Speed" */)).7(7k.b((int)((long)-1011635447 ^ (long)-1011623780), (int)((long)2070660158 ^ (long)2070675011)) /* "vspeed" */)).1(7k.b((int)((long)-1813394059 ^ (long)-1813397779), (int)((long)1833418402 ^ (long)1833423855)) /* "The speed that you fly in the vertical axis at" */)).3(1.0).2(10.0).7 = constable;
        this.7 = (1K)j2.5();
        constable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7k.b((int)((long)-790963109 ^ (long)-790974520), (int)((long)169642889 ^ (long)-169672036)) /* "Reload Chunks" */)).7(7k.b((int)((long)-1636596569 ^ (long)-1636567245), (int)((long)1109588407 ^ (long)1109576340)) /* "reloadchunks" */)).1(7k.b((int)((long)-479120750 ^ (long)-479117053), (int)((long)-1394627843 ^ (long)1394625838)) /* "Reload renderer for all chunks on enable and disable.\\nRecommended to leave on, as it can cause issues with cave culling if off" */);
        ((34X)((34X)((34X)this.4().5(7k.b((int)((long)-790963109 ^ (long)-790974520), (int)((long)169642889 ^ (long)-169672036)) /* "Reload Chunks" */)).7(7k.b((int)((long)-1636596569 ^ (long)-1636567245), (int)((long)1109588407 ^ (long)1109576340)) /* "reloadchunks" */)).1(7k.b((int)((long)-479120750 ^ (long)-479117053), (int)((long)-1394627843 ^ (long)1394625838)) /* "Reload renderer for all chunks on enable and disable.\\nRecommended to leave on, as it can cause issues with cave culling if off" */)).7 = constable;
        this.6 = (1P)((34X)j2).5();
        constable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7k.b((int)((long)821925142 ^ (long)821945994), (int)((long)-1219537486 ^ (long)-1219542577)) /* "Rerender Chunks" */)).7(7k.b((int)((long)-2017803402 ^ (long)-2017808154), (int)((long)1057008539 ^ (long)-1057008523)) /* "rerenderchunks" */)).1(7k.b((int)((long)1560564930 ^ (long)1560553309), (int)((long)-1323832596 ^ (long)1323829872)) /* "Mark chunks as dirty. Highly recommended to leave this on, even if Reload Chunks is off!" */);
        ((34X)((34X)((34X)this.4().5(7k.b((int)((long)821925142 ^ (long)821945994), (int)((long)-1219537486 ^ (long)-1219542577)) /* "Rerender Chunks" */)).7(7k.b((int)((long)-2017803402 ^ (long)-2017808154), (int)((long)1057008539 ^ (long)-1057008523)) /* "rerenderchunks" */)).1(7k.b((int)((long)1560564930 ^ (long)1560553309), (int)((long)-1323832596 ^ (long)1323829872)) /* "Mark chunks as dirty. Highly recommended to leave this on, even if Reload Chunks is off!" */)).7 = constable;
        this.0 = (1P)((34X)j2).5();
        this.8 = new Listener(object -> {
            boolean bl;
            block15: {
                block14: {
                    bl = \u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b;
                    if (bl || bl) return;
                    if (object.5 == EventState.POST) {
                        if (bl || bl) return;
                        if (3.aa() != this.2) {
                            if (bl || bl) return;
                            3.a((aqa)this.2);
                            if (bl) return;
                        }
                        if (bl) return;
                        7k.3.k.a(djl.a);
                        if (bl || bl) return;
                        return;
                    }
                    if (bl) return;
                    if (7k.3.y instanceof dnx) break block14;
                    if (bl) return;
                    if (7k.3.s != null) break block15;
                    if (bl) return;
                }
                if (bl) return;
                this.1((boolean)((long)1366442036 ^ (long)1366442036));
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            8Y y = this.2;
            y.f.a((boolean)((long)-214030745 ^ (long)-214030745));
            if (bl || bl) return;
            y.a(1.0f, new dcn((double)y.f.a, (double)Boolean.compare(y.f.g, y.f.h), (double)y.f.b));
            if (bl || bl) return;
            y.D = y.cD();
            if (bl || bl) return;
            y.E = y.cE();
            if (bl || bl) return;
            y.F = y.cH();
            if (bl || bl) return;
            y.m = y.cD();
            if (bl || bl) return;
            y.n = y.cE();
            if (bl || bl) return;
            y.o = y.cH();
            if (bl || bl) return;
            8Y y2 = y;
            y2.d(y2.cD() + y.cC().b * this.5.1 * (double)0.35f, y.cE() + y.cC().c * this.7.1 * (double)0.35f, y.cH() + y.cC().d * this.5.1 * (double)0.35f);
            if (bl || bl) return;
            y.n(0.0, 0.0, 0.0);
            if (bl || bl) return;
            cfw cfw2 = y.l.z(new fx(y.cA()));
            if (bl || bl) return;
            y.V = cfw2.g().b;
            if (bl || bl) return;
            y.X = cfw2.g().c;
            if (bl || bl) return;
            y.c(7k.3.s.dk());
            if (bl || bl) return;
            y.an = 7k.3.s.an;
            if (bl || bl) return;
            y.ao = 7k.3.s.ao;
            if (bl || bl) return;
            y.ap = 7k.3.s.ap;
            if (!bl && !bl) return;
        }, new Predicate[(int)((long)-1686739393 ^ (long)-1686739393)]);
        this.4 = new Listener(w -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b;
                        if (bl || bl) break block2;
                        if (7k.3.s.f.getClass() != dzl.class) break block3;
                        if (bl || bl) break block2;
                        7k.3.s.f = 1;
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-264971462 ^ (long)-264971462)]);
        0S = this;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 5() {
        boolean bl = \u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b;
        if (bl || bl) return;
        if (this.6.2) {
            if (bl || bl) return;
            7k.3.e.e();
            if (bl) return;
            return;
        }
        if (bl) return;
        if (this.0.2) {
            if (bl || bl) return;
            fx fx2 = new fx(djz.C().s.cA());
            if (bl || bl) return;
            int n = djz.C().k.b + (int)((long)1016691719 ^ (long)1016691718) << (int)((long)681099396 ^ (long)681099392);
            if (bl || bl) return;
            djz.C().e.a(fx2.u() - n, (int)((long)-692060712 ^ (long)-692060712), fx2.w() - n, fx2.u() + n, (int)((long)-815466202 ^ (long)-815466458), fx2.w() + n);
            if (bl) return;
        }
        if (!bl) return;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block5: {
            block2: {
                boolean bl;
                block3: {
                    block4: {
                        bl = \u2005\u2008\u2005\u200a\u2003\u2005\u2007\u200b;
                        if (bl || bl) break block2;
                        7k.3.k.a(this.9);
                        if (bl || bl) break block2;
                        if (7k.3.s == null) break block3;
                        if (bl || bl) break block2;
                        7k.3.s.f = new dzl(7k.3.k);
                        if (bl || bl) break block2;
                        djz djz2 = 3;
                        djz2.a((aqa)djz2.s);
                        if (bl || bl) break block2;
                        if (!this.6.2) break block4;
                        if (bl || bl) break block2;
                        7k.3.e.e();
                        if (bl) break block2;
                    }
                    if (bl) break block2;
                    this.5();
                    if (bl) break block2;
                }
                if (!bl) break block5;
            }
            return;
        }
    }
}

