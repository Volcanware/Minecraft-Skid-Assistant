/* ==========================================================================
 * MODULE: Signs
 * CATEGORY (inferred): Render
 * DESCRIPTION: Perform various actions on signs
 * OBFUSCATED CLASS: net.impactclient.0n
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  tp
 */
package net.impactclient;

import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.2w$6X;
import net.impactclient.340;
import net.impactclient.34X;
import net.impactclient.34s;
import net.impactclient.3C;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3s0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0n
extends 3X
implements 3s0 {
    private static final Pattern 0;
    public static final boolean \u200f\u2009\u2004\u2002\u2000;
    private static final String[] e;
    private static final String[] d;
    @EventHandler
    private final Listener<3C> 7;
    private 1P 2;

    public 0n() {
        boolean bl = \u200f\u2009\u2004\u2002\u2000;
        super(0n.b((int)((long)510799539 ^ (long)-510816898), (int)((long)-24697586 ^ (long)24675591)) /* "Signs" */, 0n.b((int)((long)522863949 ^ (long)-522852730), (int)((long)-2113499249 ^ (long)-2113495675)) /* "Perform various actions on signs" */);
        Boolean bl2 = Boolean.TRUE;
        34X x2 = (34X)((34X)((34X)this.4().5(0n.b((int)((long)-248044573 ^ (long)248021035), (int)((long)1854091043 ^ (long)1854101951)) /* "Colored" */)).7(0n.b((int)((long)-164446739 ^ (long)164437539), (int)((long)1848983591 ^ (long)-1848979358)) /* "color" */)).1(0n.b((int)((long)351194935 ^ (long)-351179522), (int)((long)111964042 ^ (long)111959787)) /* "Allows you to use \"&\" to define formatting codes on signs" */);
        ((34X)((34X)((34X)this.4().5(0n.b((int)((long)-248044573 ^ (long)248021035), (int)((long)1854091043 ^ (long)1854101951)) /* "Colored" */)).7(0n.b((int)((long)-164446739 ^ (long)164437539), (int)((long)1848983591 ^ (long)-1848979358)) /* "color" */)).1(0n.b((int)((long)351194935 ^ (long)-351179522), (int)((long)111964042 ^ (long)111959787)) /* "Allows you to use \"&\" to define formatting codes on signs" */)).7 = bl2;
        this.2 = (1P)x2.5();
        Predicate[] predicateArray = new Predicate[(int)((long)161057118 ^ (long)161057119)];
        Class[] classArray = new Class[(int)((long)1329504050 ^ (long)1329504051)];
        classArray[(int)((long)114552892 ^ (long)114552892)] = tp.class;
        predicateArray[(int)((long)-2070732825 ^ (long)-2070732825)] = new 34s(classArray);
        this.7 = new Listener(c2 -> {
            boolean bl = \u200f\u2009\u2004\u2002\u2000;
            if (bl) return;
            String[] stringArray = 3e.5();
            if (bl) return;
            if (bl) return;
            if (!this.2.2) return;
            if (bl) return;
            if (bl) return;
            c2 = (tp)c2.7;
            if (bl) return;
            if (bl) return;
            int n = (int)((long)-1034529649 ^ (long)-1034529649);
            if (bl) return;
            do {
                String string;
                if (bl) return;
                if (n >= c2.c().length) return;
                if (bl) return;
                if (bl) return;
                String[] stringArray2 = c2.c();
                Function<Matcher, String> function = 340.7().andThen(340.4(0n.b((int)((long)31364665 ^ (long)-31377931), (int)((long)71275077 ^ (long)-71291765)) /* "§§0" */));
                CharSequence charSequence = c2.c()[n];
                Matcher matcher = 0.matcher(charSequence);
                if (matcher.find()) {
                    charSequence = new StringBuffer();
                    block1: while (true) {
                        matcher.appendReplacement((StringBuffer)charSequence, function.apply(matcher));
                        do {
                            if (matcher.find()) continue block1;
                            matcher.appendTail((StringBuffer)charSequence);
                        } while (stringArray != null);
                        break;
                    }
                    string = ((StringBuffer)charSequence).toString();
                    if (\u200f\u2009\u2004\u2002\u2000) {
                        throw null;
                    }
                } else {
                    string = charSequence;
                }
                stringArray2[n] = string;
                ++n;
            } while (stringArray == null);
        }, predicateArray);
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0n.\u200f\u2009\u2004\u2002\u2000;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)595897062 ^ (long)-595916498)) & (int)((long)1524309833 ^ (long)1524359350);
            if (var9_2) ** GOTO lbl-1000
            if (0n.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0n.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1688969041 ^ (long)1688969041)] & (int)((long)1289745491 ^ (long)1289745580)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)2041139845 ^ (long)2041139768);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-616146871 ^ (long)-616146729);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1779848012 ^ (long)1779848145);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)55270872 ^ (long)55270826);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1005290043 ^ (long)1005290183);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1990689469 ^ (long)-1990689424);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)77877265 ^ (long)77877461);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)803921353 ^ (long)803921163);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)715521159 ^ (long)715521168);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)499314077 ^ (long)499313964);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-592114158 ^ (long)-592114131);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1847601917 ^ (long)-1847601738);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-366063285 ^ (long)-366063338);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1912853751 ^ (long)-1912853727);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-679795475 ^ (long)-679795682);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)291601080 ^ (long)291601048);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-666226789 ^ (long)-666226755);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)949741286 ^ (long)949741165);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1017981280 ^ (long)-1017981211);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-75562019 ^ (long)-75562100);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1941332903 ^ (long)1941332868);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1681537879 ^ (long)1681537834);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)784786825 ^ (long)784786775);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1395557439 ^ (long)1395557513);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1835603274 ^ (long)1835603354);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1002923611 ^ (long)1002923636);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1764701520 ^ (long)-1764701648);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-819739567 ^ (long)-819739435);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)736265192 ^ (long)736265117);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-732249550 ^ (long)-732249451);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1626422397 ^ (long)1626422277);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1611714479 ^ (long)-1611714507);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)36982269 ^ (long)36982158);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)391699556 ^ (long)391699594);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-329500622 ^ (long)-329500638);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1761208060 ^ (long)1761207915);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1842961995 ^ (long)-1842961928);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)2084402217 ^ (long)2084402258);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)779152806 ^ (long)779152820);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1022324775 ^ (long)-1022324779);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1734012781 ^ (long)1734012815);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)365557490 ^ (long)365557367);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1347658577 ^ (long)1347658678);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)380765320 ^ (long)380765366);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)343583101 ^ (long)343583074);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1241821519 ^ (long)1241821538);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)996194321 ^ (long)996194483);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)235781618 ^ (long)235781459);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1984943956 ^ (long)-1984943973);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1737455115 ^ (long)-1737455266);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-508233507 ^ (long)-508233498);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1959440216 ^ (long)-1959440309);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1361678647 ^ (long)1361678705);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1542791541 ^ (long)-1542791546);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1848906331 ^ (long)1848906347);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-511910373 ^ (long)-511910219);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)803841576 ^ (long)803841681);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)820665277 ^ (long)820665249);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-636087216 ^ (long)-636087254);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1409056431 ^ (long)-1409056497);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1378601576 ^ (long)-1378601688);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1072966752 ^ (long)-1072966881);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)527095795 ^ (long)527095655);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1458573788 ^ (long)-1458573698);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1174503822 ^ (long)-1174503822);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1187662583 ^ (long)1187662489);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1559150644 ^ (long)1559150815);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)320574281 ^ (long)320574384);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-2146190230 ^ (long)-2146190325);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1415874672 ^ (long)-1415874565);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)573054140 ^ (long)573054133);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1924594397 ^ (long)1924594408);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-646315526 ^ (long)-646315691);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1501727985 ^ (long)1501727973);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)750174838 ^ (long)750174883);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)681799449 ^ (long)681799512);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1289811307 ^ (long)1289811262);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1598708564 ^ (long)-1598708636);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1014337122 ^ (long)1014337261);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1244915418 ^ (long)1244915203);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1711256116 ^ (long)1711256115);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)704054828 ^ (long)704054900);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-219272671 ^ (long)-219272571);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1669925756 ^ (long)1669925826);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-847792972 ^ (long)-847793038);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-468146837 ^ (long)-468146855);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1939791592 ^ (long)1939791361);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)233717416 ^ (long)233717495);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1583419056 ^ (long)-1583419112);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)839649558 ^ (long)839649761);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)770349968 ^ (long)770350023);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)854009724 ^ (long)854009747);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1486346807 ^ (long)-1486346803);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)21643122 ^ (long)21643067);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)605745013 ^ (long)605745095);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-2141674015 ^ (long)-2141674014);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1560518824 ^ (long)-1560518693);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)205145311 ^ (long)205145336);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1094638293 ^ (long)1094638122);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1497486016 ^ (long)1497486022);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)284776503 ^ (long)284776504);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1163537094 ^ (long)-1163537067);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-913086127 ^ (long)-913086085);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1294038495 ^ (long)-1294038518);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1208189565 ^ (long)-1208189535);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1072803446 ^ (long)1072803517);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)490032736 ^ (long)490032891);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)945587471 ^ (long)945587554);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1461469967 ^ (long)-1461470062);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)890881660 ^ (long)890881773);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1545602460 ^ (long)-1545602539);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1023584173 ^ (long)1023584062);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-250822866 ^ (long)-250822893);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-2089801108 ^ (long)-2089801172);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1233204603 ^ (long)-1233204613);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1892619772 ^ (long)-1892619538);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1732760574 ^ (long)-1732760360);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1431044340 ^ (long)1431044334);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-653807651 ^ (long)-653807636);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1575952803 ^ (long)1575952663);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)2120550780 ^ (long)2120550794);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1480524926 ^ (long)-1480524903);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-383605675 ^ (long)-383605655);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-307284780 ^ (long)-307284752);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-335763480 ^ (long)-335763535);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)632236350 ^ (long)632236336);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1563664630 ^ (long)-1563664639);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-43596646 ^ (long)-43596717);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-859131449 ^ (long)-859131622);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1017673985 ^ (long)-1017674037);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1857988813 ^ (long)-1857988826);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-2060672948 ^ (long)-2060672976);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1541245836 ^ (long)-1541245809);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1382812284 ^ (long)1382812351);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-911385371 ^ (long)-911385389);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1217488382 ^ (long)1217488216);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)662870164 ^ (long)662870076);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-456320205 ^ (long)-456320131);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1683677989 ^ (long)1683678175);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)857929703 ^ (long)857929595);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1263087335 ^ (long)-1263087190);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-846709074 ^ (long)-846709181);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1780702180 ^ (long)1780702008);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)2077377071 ^ (long)2077377277);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)349684893 ^ (long)349684900);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)661180492 ^ (long)661180630);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1404001143 ^ (long)-1404001078);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1171218879 ^ (long)-1171218923);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)107351209 ^ (long)107351049);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1369999037 ^ (long)1369999103);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-586271579 ^ (long)-586271656);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)15535289 ^ (long)15535189);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1148851355 ^ (long)1148851315);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)449634356 ^ (long)449634371);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1599427091 ^ (long)-1599427242);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1510807639 ^ (long)1510807675);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1124304052 ^ (long)1124303902);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-348316599 ^ (long)-348316469);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)255692287 ^ (long)255692175);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1704837227 ^ (long)1704837296);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)2082087161 ^ (long)2082087046);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)394976682 ^ (long)394976719);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)222960202 ^ (long)222960188);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1255513519 ^ (long)-1255513436);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)952778182 ^ (long)952778108);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1436460782 ^ (long)-1436460642);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1180786783 ^ (long)1180786700);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-672114593 ^ (long)-672114685);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-408349174 ^ (long)-408349149);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1295815543 ^ (long)-1295815610);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-176141725 ^ (long)-176141710);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-493094861 ^ (long)-493094875);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1074694000 ^ (long)-1074694100);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)187602872 ^ (long)187602943);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)2128792456 ^ (long)2128792554);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1221202719 ^ (long)1221202943);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1914179833 ^ (long)-1914179682);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-614236762 ^ (long)-614236857);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1735635678 ^ (long)1735635469);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1358131686 ^ (long)-1358131566);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1844093600 ^ (long)1844093605);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-745835622 ^ (long)-745835747);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1369587902 ^ (long)-1369587901);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-889210035 ^ (long)-889210028);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)894476288 ^ (long)894476417);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-187357523 ^ (long)-187357565);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1861177947 ^ (long)1861177911);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)2124848159 ^ (long)2124848135);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)892344210 ^ (long)892344084);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1292578150 ^ (long)1292578291);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1140979058 ^ (long)-1140979161);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1747992831 ^ (long)1747992694);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-223728374 ^ (long)-223728314);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-276928974 ^ (long)-276928949);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)829712305 ^ (long)829712169);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1697242413 ^ (long)-1697242590);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1182739041 ^ (long)-1182739112);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-732618448 ^ (long)-732618416);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1822175880 ^ (long)1822175882);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1375798633 ^ (long)-1375798777);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1119502066 ^ (long)-1119501976);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-387195053 ^ (long)-387195131);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1149968277 ^ (long)1149968219);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)871717457 ^ (long)871717518);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1270238776 ^ (long)-1270238946);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)157426142 ^ (long)157425930);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-379017279 ^ (long)-379017221);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-859536265 ^ (long)-859536152);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-258474729 ^ (long)-258474525);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1529940625 ^ (long)-1529940622);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)528173385 ^ (long)528173445);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)263997882 ^ (long)263997788);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1424243129 ^ (long)-1424243168);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1005138719 ^ (long)1005138888);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1496764307 ^ (long)1496764235);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1892223530 ^ (long)-1892223694);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1618330820 ^ (long)-1618330736);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1775296997 ^ (long)-1775296949);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1495267738 ^ (long)1495267607);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1005903452 ^ (long)1005903414);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-764318137 ^ (long)-764318205);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1093519127 ^ (long)-1093519197);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1854195810 ^ (long)-1854195948);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1906072090 ^ (long)-1906072298);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1718407895 ^ (long)1718407832);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1848592633 ^ (long)1848592627);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1855757265 ^ (long)-1855757273);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-162204319 ^ (long)-162204202);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1217042798 ^ (long)1217042838);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)714814707 ^ (long)714814558);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)344260236 ^ (long)344260344);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-181044977 ^ (long)-181044937);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-2005022190 ^ (long)-2005022119);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)906090288 ^ (long)906090490);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1224519501 ^ (long)1224519615);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-864571451 ^ (long)-864571546);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)531300027 ^ (long)531299946);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1090331228 ^ (long)1090331338);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1159679747 ^ (long)1159679832);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-338671319 ^ (long)-338671215);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-210530303 ^ (long)-210530286);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1274751094 ^ (long)1274750984);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-305255489 ^ (long)-305255465);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1527698868 ^ (long)1527698805);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1585950533 ^ (long)-1585950555);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)273056874 ^ (long)273056911);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1330697468 ^ (long)1330697273);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1446688086 ^ (long)1446688063);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1295953110 ^ (long)1295953028);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)823374541 ^ (long)823374572);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1894514124 ^ (long)1894513921);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1178791442 ^ (long)1178791607);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)606333090 ^ (long)606332976);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-215698622 ^ (long)-215698558);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1633921597 ^ (long)1633921715);
                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1757148672 ^ (long)-1757148635);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-81378384 ^ (long)-81378481)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1580543365 ^ (long)-1580585596)) >>> (int)((long)1951363210 ^ (long)1951363202)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1537177872 ^ (long)-1537177872);
            if (!0n.\u200f\u2009\u2004\u2002\u2000) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-833405283 ^ (long)-833405281);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-518617846 ^ (long)-518617847) | var5_6 << (int)((long)1720676243 ^ (long)1720676246)) ^ var3_4[var7_8]) & (int)((long)-2034899972 ^ (long)-2034900221);
                    if (0n.\u200f\u2009\u2004\u2002\u2000) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-576891286 ^ (long)-576891287) | var6_7 << (int)((long)1998010971 ^ (long)1998010974)) ^ var3_4[var7_8]) & (int)((long)-282471704 ^ (long)-282471913);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0n.e[var2_3] = new String(var3_4).intern();
        }
        return 0n.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 0n.\u200f\u2009\u2004\u2002\u2000;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)-1913296607 ^ (long)-1913296602)];
            if (var7) break block25;
            var3_2 = (int)((long)1812408521 ^ (long)1812408521);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\uca5c\ue204\uf122\uf922\uca50\ue2fa\uf191\uf998\uca4a\ue209\uf1a2\uf9e0\uca45\ue2b4\uf1d2\uf91b\uca6e\ue2c7\uf12c\uf9f8\ucada\ue26f\uf149\uf9ed\uca5d\ue2aa\uf1e3\uf96b\ucadf\ue223\uf1b2\uf9cd\ucaeb\ue295\uf10c\uf9f3\ucae0\ue288\uf1d3\uf9dd\uca52\ue2a9\uf151\uf933\uca08\ue255\uf17b\uf996\ucaef\ue25b\uf19b\uf9d4\ucaf2\ue2db\uf11a\uf9dc\uca4d\ue265\uf1b8\uf9ec\ucaa0\ue21a\uf15e\uf9a6\ucaf2\ue2da\uf1ee\uf93a\uca53\ue29c\uf1ab\uf98b\uca2b\ue2e0\uf123\uf9f1\ucaca\ue2c7\uf146\uf9f4\ucaaa\ue2c1\uf161\uf98c\uca9a\ue2e9\uf13f\uf92b\uca05\ue2e0\uf150\uf9f8\uca02\ue28f\uf1ad\uf956\uca18\ue224\uf160\uf97a\uca3c\ue286\uf115\uf9d8\uca1c\ue224\uf1d5\uf947\uca34\ue2ec\uf1b7\uf978\uca40\ue275\uf1a0\uf983\ucaf4\ue2a2\uf1d6\uf989\uca6f\ue2d5", -1686901664);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)1574337439 ^ (long)1574337432);
            if (var7) break block25;
            var0_6 = (int)((long)-1397326181 ^ (long)1397326180);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)2087335694 ^ (long)2087335806);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)-375206456 ^ (long)375206455);
                        if (0n.\u200f\u2009\u2004\u2002\u2000) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!0n.\u200f\u2009\u2004\u2002\u2000) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\uf4d1\udcc2\ucf1a\uc7ad\uf4ac\udc7c\ucff7\uc72f\uf4c7\udcb2\ucf58", -1414671664);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)2009591784 ^ (long)2009591789);
                                var0_6 = (int)((long)2099195194 ^ (long)-2099195195);
                                while (true) {
                                    v0 = (int)((long)-1777309959 ^ (long)-1777310023);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)1145353438 ^ (long)1145353438);
                                    if (!0n.\u200f\u2009\u2004\u2002\u2000) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!0n.\u200f\u2009\u2004\u2002\u2000) ** continue;
                                    throw null;
                                }
                                0n.d = var5_1;
                                0n.e = new String[(int)((long)385461797 ^ (long)385461794)];
                                if (0n.\u200f\u2009\u2004\u2002\u2000) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)2033726894 ^ (long)2033726894);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)-371365605 ^ (long)-371365606)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)939591641 ^ (long)939591646)) {
                                    case 0: {
                                        v15 = (int)((long)9102259 ^ (long)9102299);
                                        if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)-984467004 ^ (long)-984466959);
                                        if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)-111860299 ^ (long)-111860292);
                                        if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)1840245781 ^ (long)1840245786);
                                        if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)-528007205 ^ (long)-528007245);
                                        if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)25763624 ^ (long)25763603);
                                        if (!0n.\u200f\u2009\u2004\u2002\u2000) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)935930635 ^ (long)935930671);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!0n.\u200f\u2009\u2004\u2002\u2000);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                0n.0 = Pattern.compile(0n.b((int)((long)-2110809965 ^ (long)2110798681), (int)((long)-48461480 ^ (long)-48434694)) /* "(?i)&([0-9A-FK-OR])" */);
                break;
            }
        }
    }
}

