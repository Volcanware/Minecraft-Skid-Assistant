/* ==========================================================================
 * MODULE: Auto Weapon
 * CATEGORY (inferred): Combat
 * DESCRIPTION: Automatically determine the best weapon to use
 * OBFUSCATED CLASS: net.impactclient.38
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqf
 *  arj
 *  arl
 *  bmb
 *  bnf
 *  bps
 *  bpu
 *  bpw
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.lang.invoke.LambdaMetafactory;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.2w;
import net.impactclient.2w$6X;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.56;
import net.impactclient.5y;
import net.impactclient.8d;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 38
extends 3X
implements 56 {
    public static final boolean \u2008\u2004;
    private static final String[] e;
    public static final 2w<bmb> 8;
    private static final String[] d;
    @EventHandler
    private final Listener<8d> 4;
    private static final Map<bnf, Double> 0;

    /*
     * Enabled aggressive block sorting
     */
    private static double 1(bmb bmb2) {
        int n;
        double d;
        boolean bl = \u2008\u2004;
        if (bl) return 0.0;
        String[] stringArray = 3e.5();
        if (bl || bl) return 0.0;
        if (!(bmb2.b() instanceof bnf)) {
            if (bl || bl) return 0.0;
            return 0.0;
        }
        if (bl) return 0.0;
        bnf bnf2 = (bnf)bmb2.b();
        if (bl || bl) return 0.0;
        double d2 = 0.computeIfAbsent(bnf2, 38::5);
        if (bl || bl) return 0.0;
        int n2 = bpu.a((bps)bpw.m, (bmb)bmb2);
        if (bl || bl) return 0.0;
        int n3 = (int)((long)-283557992 ^ (long)-283557992);
        if (bl) return 0.0;
        do {
            double d3;
            if (bl) return 0.0;
            if (n3 >= n2) break;
            if (bl || bl) {
                return 0.0;
            }
            d = d2;
            n = n3;
            if (stringArray != null) return d + ((double)n * 4.0 - 1.0);
            if (n > 0) {
                d3 = 0.5;
                if (\u2008\u2004) {
                    throw null;
                }
            } else {
                d3 = 1.0;
            }
            d2 = d + d3;
            ++n3;
        } while (stringArray == null);
        n3 = bpu.a((bps)bpw.q, (bmb)bmb2);
        d = d2;
        n = n3;
        return d + ((double)n * 4.0 - 1.0);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    static {
        block18: {
            block17: {
                var9 = 38.\u2008\u2004;
                if (!var9) break block17;
                break block18;
            }
            var5_1 = new String[(int)((long)383977789 ^ (long)383977791)];
            if (var9) break block18;
            var3_2 = (int)((long)291551852 ^ (long)291551852);
            if (var9) break block18;
            var2_3 = 2w$6X.KAOZ("\u3b1b\u13a6\u00fa\u089f\u3b85\u1317\u00b1\u089e\u3ba0\u1363\u0088\u08a4\u3ba2\u131c\u00cd\u08c8\u3b2e\u13cb1\u08fd\u3b90\u1308\u00fd\u08f3\u3ba0\u13e9\u00f5\u0880\u3b06\u1326\u00e8\u0834\u3ba8\u13ed\u00bb\u08c9\u3be6\u13c3d\u080e\u3b54\u1319S\u0861\u3b57\u1390\u00eb\u084a\u3beb\u13f9\u00e1\u084e\u3b6c\u13d4\u0084\u0891\u3be3\u1316", 506666315);
            var4_4 = var2_3.length();
            if (var9) break block18;
            var1_5 = (int)((long)1539493183 ^ (long)1539493172);
            if (var9) break block18;
            var0_6 = (int)((long)-1579186853 ^ (long)1579186852);
            if (var9) break block18;
            block8: while (!var9) {
                block15: {
                    v0 = ++var0_6;
                    v1 = (int)((long)1550994706 ^ (long)-1550994707);
                    if (38.\u2008\u2004) {
                        throw null;
                        while (true) {
                            var5_1[var3_2++] = new String(v2).intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!38.\u2008\u2004) continue block8;
                                throw null;
                            }
                            38.d = var5_1;
                            38.e = new String[(int)((long)-1933427022 ^ (long)-1933427024)];
                            if (38.\u2008\u2004) {
                                throw null;
                            }
                            break block15;
                            break;
                        }
                    }
                    v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                    v4 = v3.length;
                    var6_7 = (int)((long)2048940459 ^ (long)2048940459);
                    v5 = (int)((long)-35191972 ^ (long)-35191969);
                    v6 = v3;
                    v7 = v4;
                    if (v4 > (int)((long)-2054106618 ^ (long)-2054106617)) ** GOTO lbl88
                    do {
                        block16: {
                            v8 = v5;
                            v6 = v6;
                            v9 = v6;
                            v10 = v5;
                            v11 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)1684893415 ^ (long)1684893408)) {
                                    case 0: {
                                        v12 = (int)((long)-6674125 ^ (long)-6674141);
                                        if (!38.\u2008\u2004) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v12 = (int)((long)-532735931 ^ (long)-532735899);
                                        if (!38.\u2008\u2004) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v12 = (int)((long)-468311199 ^ (long)-468311263);
                                        if (!38.\u2008\u2004) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v12 = (int)((long)-920019050 ^ (long)-920018984);
                                        if (!38.\u2008\u2004) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v12 = (int)((long)676340551 ^ (long)676340521);
                                        if (!38.\u2008\u2004) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v12 = (int)((long)-446223612 ^ (long)-446223572);
                                        if (!38.\u2008\u2004) break;
                                        throw null;
                                    }
                                    default: {
                                        v12 = (int)((long)2078796059 ^ (long)2078796112);
                                    }
                                }
                                v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                                ++var6_7;
                                v5 = v8;
                                if (v8 != 0) break block16;
                                v8 = v5;
                                v6 = v6;
                                v11 = v5;
                                v9 = v6;
                                v10 = v5;
                            } while (!38.\u2008\u2004);
                            throw null;
                        }
                        v2 = v6;
                        v7 = v7;
                    } while (v7 > var6_7);
                    if (!38.\u2008\u2004) ** continue;
                    throw null;
                }
                v13 = new Predicate[(int)((long)1545043196 ^ (long)1545043197)];
                v13[(int)((long)-431279858 ^ (long)-431279858)] = (Predicate<bmb>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, 0(bmb ), (Lbmb;)Z)();
                var8_8 /* !! */  = v13;
                var7_9 = new 5y<T>();
                new 5y<T>().1 = var8_8 /* !! */ ;
                v14.4 = var8_8 /* !! */  = Comparator.comparingDouble((ToDoubleFunction<bmb>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)D, 1(bmb ), (Lbmb;)D)()).reversed();
                38.8 = var7_9.7();
                38.0 = new HashMap<bnf, Double>();
                break;
            }
        }
    }

    private static /* synthetic */ boolean 0(bmb bmb2) {
        boolean bl = \u2008\u2004;
        if (bl || bl) {
            return true;
        }
        return bmb2.b() instanceof bnf;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static double 5(bnf object) {
        boolean bl = \u2008\u2004;
        if (bl || bl) return 0.0;
        if ((object = object.a(aqf.a).get((Object)arl.f)) == null) {
            if (bl || bl) return 0.0;
            return 0.0;
        }
        if (bl) return 0.0;
        if ((object = (arj)object.stream().findFirst().orElse(null)) == null) {
            if (bl || bl) return 0.0;
            return 0.0;
        }
        if (!bl) return object.d();
        return 0.0;
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 38.\u2008\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-617229757 ^ (long)617233314)) & (int)((long)1194212576 ^ (long)1194246943);
            if (var9_2) ** GOTO lbl-1000
            if (38.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 38.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-857251513 ^ (long)-857251513)] & (int)((long)-1295354517 ^ (long)-1295354476)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1535050199 ^ (long)-1535050160);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)218180127 ^ (long)218180329);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1978977334 ^ (long)-1978977349);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)383186188 ^ (long)383186215);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1345034267 ^ (long)-1345034299);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)305906140 ^ (long)305906151);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)800004353 ^ (long)800004536);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1922658192 ^ (long)-1922658254);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-2128592629 ^ (long)-2128592629);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1051657452 ^ (long)-1051657368);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)2042734276 ^ (long)2042734126);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1612206221 ^ (long)1612206318);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-462271820 ^ (long)-462271796);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)431057851 ^ (long)431057915);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)149067738 ^ (long)149067754);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1019143327 ^ (long)1019143358);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1841022947 ^ (long)1841022802);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)629353809 ^ (long)629353746);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)134545823 ^ (long)134545852);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1899107503 ^ (long)1899107391);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-325399729 ^ (long)-325399711);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1001146433 ^ (long)-1001146424);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1100047653 ^ (long)1100047658);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1878187846 ^ (long)-1878187974);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1296500244 ^ (long)1296500427);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1948846449 ^ (long)-1948846564);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1828937854 ^ (long)1828937799);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)2035086047 ^ (long)2035086037);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)641087243 ^ (long)641087484);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-228216267 ^ (long)-228216273);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)987733084 ^ (long)987733142);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1083144970 ^ (long)-1083145064);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-997806920 ^ (long)-997806932);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-264927397 ^ (long)-264927369);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-467158288 ^ (long)-467158375);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1029065751 ^ (long)1029065971);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1094080459 ^ (long)-1094080286);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1727319823 ^ (long)1727320032);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)39384239 ^ (long)39384200);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)582405620 ^ (long)582405566);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)705432680 ^ (long)705432591);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-866332386 ^ (long)-866332373);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1808498731 ^ (long)-1808498809);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-334125649 ^ (long)-334125710);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1345631016 ^ (long)1345631028);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1406902673 ^ (long)1406902544);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-870613440 ^ (long)-870613314);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-591688950 ^ (long)-591688823);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)599579585 ^ (long)599579462);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1957491074 ^ (long)1957491027);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1863712988 ^ (long)1863713009);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)788847486 ^ (long)788847462);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-703207017 ^ (long)-703207067);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1990311556 ^ (long)1990311656);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1453510001 ^ (long)1453510117);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1640406460 ^ (long)-1640406367);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)663015500 ^ (long)663015615);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-243165070 ^ (long)-243165079);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)218880091 ^ (long)218880116);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1187789850 ^ (long)1187790016);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)528714 ^ (long)528874);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1621819807 ^ (long)-1621819901);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-227496747 ^ (long)-227496953);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1621326975 ^ (long)-1621326970);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1308860321 ^ (long)1308860171);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-767057457 ^ (long)-767057450);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)737135199 ^ (long)737135317);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1694237210 ^ (long)-1694237417);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1480979261 ^ (long)-1480979277);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1884868050 ^ (long)-1884867891);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-496457249 ^ (long)-496457425);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1939570326 ^ (long)-1939570431);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1675844211 ^ (long)-1675844160);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1835906870 ^ (long)1835906988);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1845895988 ^ (long)1845896018);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1658395588 ^ (long)-1658395491);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)586387277 ^ (long)586387353);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)607216160 ^ (long)607216371);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1769352716 ^ (long)-1769352903);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1509650544 ^ (long)1509650589);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-696255465 ^ (long)-696255316);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-457900521 ^ (long)-457900354);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)2132671045 ^ (long)2132670979);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1712222381 ^ (long)-1712222219);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1386560822 ^ (long)1386560910);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)175029628 ^ (long)175029544);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1886567656 ^ (long)-1886567480);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)524380808 ^ (long)524380711);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-980726211 ^ (long)-980726252);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1359256220 ^ (long)-1359256078);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1374041726 ^ (long)-1374041791);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1599049933 ^ (long)-1599049780);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)404566053 ^ (long)404566162);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)609809483 ^ (long)609809408);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-423325558 ^ (long)-423325478);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1143855016 ^ (long)1143854875);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1634027182 ^ (long)-1634027041);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)586451386 ^ (long)586451313);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-202221093 ^ (long)-202221309);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-581065163 ^ (long)-581065214);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1034465231 ^ (long)-1034465154);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)2140521595 ^ (long)2140521627);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1569569416 ^ (long)1569569336);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)6356393 ^ (long)6356295);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1395965202 ^ (long)-1395965188);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)2014096660 ^ (long)2014096702);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)180925297 ^ (long)180925199);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)143544305 ^ (long)143544118);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-640829901 ^ (long)-640829718);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)621637756 ^ (long)621637647);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1247366594 ^ (long)-1247366516);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-555209415 ^ (long)-555209329);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1701995917 ^ (long)-1701995915);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1301604560 ^ (long)1301604443);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1012834111 ^ (long)-1012834125);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1907221395 ^ (long)1907221261);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1311854186 ^ (long)-1311854237);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)45788180 ^ (long)45788291);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-347195753 ^ (long)-347195870);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)590928907 ^ (long)590929062);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-935294489 ^ (long)-935294600);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-459544683 ^ (long)-459544724);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1601832508 ^ (long)-1601832492);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-736609294 ^ (long)-736609444);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1966608355 ^ (long)1966608298);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1663442576 ^ (long)1663442561);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-30896565 ^ (long)-30896530);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1745693873 ^ (long)-1745693906);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1375674174 ^ (long)-1375674326);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-654782449 ^ (long)-654782446);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1026816342 ^ (long)-1026816496);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1314306610 ^ (long)-1314306734);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-944601647 ^ (long)-944601715);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-392385979 ^ (long)-392386028);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-550072406 ^ (long)-550072391);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1933250512 ^ (long)1933250353);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)776961425 ^ (long)776961412);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1977246580 ^ (long)-1977246656);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)892838246 ^ (long)892838387);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1542007400 ^ (long)-1542007526);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1470342418 ^ (long)-1470342522);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-2087346927 ^ (long)-2087346770);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)116394753 ^ (long)116394917);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-910033721 ^ (long)-910033776);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-976419343 ^ (long)-976419507);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1088460938 ^ (long)1088460974);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-2143945517 ^ (long)-2143945600);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-298397490 ^ (long)-298397544);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1880034473 ^ (long)-1880034487);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1013358080 ^ (long)-1013358011);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)2047153949 ^ (long)2047153942);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1929325059 ^ (long)-1929325077);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1460770600 ^ (long)1460770654);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1801248144 ^ (long)1801248203);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1765114867 ^ (long)-1765114675);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1467868878 ^ (long)-1467868774);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)704926764 ^ (long)704926935);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-903945006 ^ (long)-903944978);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1513507078 ^ (long)-1513507231);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)343841391 ^ (long)343841338);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1613753430 ^ (long)1613753594);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)772135675 ^ (long)772135678);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)496526272 ^ (long)496526101);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1547194643 ^ (long)1547194641);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1660373912 ^ (long)1660374012);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1519529294 ^ (long)-1519529418);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1087468646 ^ (long)-1087468732);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)661441620 ^ (long)661441549);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1818673687 ^ (long)-1818673783);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)953924225 ^ (long)953924313);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1262961403 ^ (long)1262961244);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1323351996 ^ (long)1323351844);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-283990215 ^ (long)-283990117);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)901051494 ^ (long)901051567);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)613148893 ^ (long)613148696);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1111715582 ^ (long)1111715421);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1123336826 ^ (long)-1123336830);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-2140381080 ^ (long)-2140381165);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)637786487 ^ (long)637786606);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1954276264 ^ (long)1954276254);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-256921610 ^ (long)-256921659);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1707398246 ^ (long)1707398290);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)464677543 ^ (long)464677526);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1005815048 ^ (long)1005815174);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1567398490 ^ (long)1567398589);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1519976776 ^ (long)1519976773);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1496775393 ^ (long)-1496775253);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)249066930 ^ (long)249066857);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1052698243 ^ (long)1052698329);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-670509516 ^ (long)-670509352);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-114539628 ^ (long)-114539563);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)728961519 ^ (long)728961429);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-392764260 ^ (long)-392764328);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1527171275 ^ (long)1527171076);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)2031436353 ^ (long)2031436319);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1487229841 ^ (long)-1487229925);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-735908280 ^ (long)-735908279);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1126215695 ^ (long)1126215923);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)10360363 ^ (long)10360534);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)142832776 ^ (long)142832644);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-971105374 ^ (long)-971105491);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-757912066 ^ (long)-757912256);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-806264885 ^ (long)-806264908);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-513247427 ^ (long)-513247367);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1488924225 ^ (long)1488924203);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1124055401 ^ (long)1124055500);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-338473508 ^ (long)-338473673);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)330778223 ^ (long)330778253);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1410427255 ^ (long)1410427231);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1091654905 ^ (long)1091654796);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-661699404 ^ (long)-661699450);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1266918543 ^ (long)-1266918581);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-298537217 ^ (long)-298537220);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1759075771 ^ (long)1759075706);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1834286195 ^ (long)-1834286308);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1051629363 ^ (long)-1051629325);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-192278049 ^ (long)-192278023);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1823951792 ^ (long)1823951718);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1865910124 ^ (long)-1865910243);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-784892940 ^ (long)-784893130);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-323473367 ^ (long)-323473290);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1510205978 ^ (long)-1510206071);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1293941711 ^ (long)-1293941580);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)459669457 ^ (long)459669484);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-457091724 ^ (long)-457091718);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-239586351 ^ (long)-239586407);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-629327394 ^ (long)-629327364);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1616325500 ^ (long)1616325620);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-831519610 ^ (long)-831519602);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1748557669 ^ (long)1748557676);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1154025152 ^ (long)1154025100);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)647563921 ^ (long)647563881);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-609680324 ^ (long)-609680186);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-2091693639 ^ (long)-2091693781);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-307415499 ^ (long)-307415373);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1540656418 ^ (long)-1540656584);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-673497991 ^ (long)-673498047);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)490976402 ^ (long)490976379);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1119911200 ^ (long)1119911357);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)654332879 ^ (long)654332681);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)171427417 ^ (long)171427351);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-777467963 ^ (long)-777467992);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1274077968 ^ (long)1274077999);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1736029796 ^ (long)1736029753);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-296590996 ^ (long)-296591016);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)770121295 ^ (long)770121351);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1319877029 ^ (long)1319876878);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1762452490 ^ (long)-1762452589);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-192263789 ^ (long)-192263724);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1030741266 ^ (long)-1030741421);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1821603766 ^ (long)1821603704);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)500193375 ^ (long)500193363);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1296642375 ^ (long)-1296642386);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-636020852 ^ (long)-636020845);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)337124828 ^ (long)337124769);
                    if (!38.\u2008\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1544629383 ^ (long)-1544629339);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1463580808 ^ (long)1463580791)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)814305452 ^ (long)814329683)) >>> (int)((long)-749435552 ^ (long)-749435544)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1397912143 ^ (long)1397912143);
            if (!38.\u2008\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1761166783 ^ (long)1761166781);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1284362016 ^ (long)-1284362013) | var5_6 << (int)((long)-126286909 ^ (long)-126286906)) ^ var3_4[var7_8]) & (int)((long)-144043074 ^ (long)-144043199);
                    if (38.\u2008\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-2130522482 ^ (long)-2130522483) | var6_7 << (int)((long)-661705273 ^ (long)-661705278)) ^ var3_4[var7_8]) & (int)((long)-1060937060 ^ (long)-1060937117);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            38.e[var2_3] = new String(var3_4).intern();
        }
        return 38.e[var2_3];
    }

    public 38() {
        boolean bl = \u2008\u2004;
        super(38.b((int)((long)1497757426 ^ (long)-1497751789), (int)((long)-521708132 ^ (long)-521725607)) /* "Auto Weapon" */, 38.b((int)((long)1675783539 ^ (long)-1675787117), (int)((long)366615943 ^ (long)366637686)) /* "Automatically determine the best weapon to use" */);
        Predicate[] predicateArray = new Predicate[(int)((long)942912267 ^ (long)942912266)];
        predicateArray[(int)((long)1148075488 ^ (long)1148075488)] = d -> {
            boolean bl = \u2008\u2004;
            if (bl || bl) return true;
            if (d.7 == EventState.PRE) {
                if (bl) return true;
                if (d.1 == 38.3.s) {
                    if (bl) return true;
                    return (int)((long)568871056 ^ (long)568871057) != 0;
                }
            }
            if (!bl) return (int)((long)-1249524792 ^ (long)-1249524792) != 0;
            return true;
        };
        this.4 = new Listener(d -> {
            boolean bl = \u2008\u2004;
            if (bl || bl) return;
            int n = 8.0((List<bmb>)38.3.s.bm.a);
            if (n < 0) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            38.3.s.bm.d = n;
            if (!bl && !bl) return;
        }, predicateArray);
    }
}

