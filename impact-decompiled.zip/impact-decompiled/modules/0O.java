/* ==========================================================================
 * MODULE: BoatFly
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Allows you to fly while in boats
 * OBFUSCATED CLASS: net.impactclient.0O
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqa
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1A;
import net.impactclient.1P;
import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.3sh;
import net.impactclient.4m;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0O
extends 3X
implements 34B {
    private 1P 5;
    private static final String[] d;
    @EventHandler
    private final Listener<3sh> 6;
    private static final String[] e;
    private 1A 9;
    public static final boolean \u2003\u200c;
    private 1A 1;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0O.\u2003\u200c;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)677595059 ^ (long)677595064)];
            if (var7) break block23;
            var3_2 = (int)((long)1584600342 ^ (long)1584600342);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u66e3\u4ec4\u5d7d\u5503\u6603\u4e1d\u5d21\u557a\u66f6\u4e51\u5db4\u5579\u6648\u4e4a\u5d8e\u55bc\u6601\u4e0f\u5db5\u5510\u66e6\u4e76\u5d43\u557f\u66eb\u4e1f\u5db3\u55d8\u66b5\u4e38\u5da5\u5509\u6681\u4e13\u5d53\u5565\u6642\u4ee4\u5d49\u5507\u6685\u4e9d\u5df1\u556a\u66ec\u4e53\u5df7\u5539\u6620\u4e42\u5d83\u55bd\u66a0\u4e2f\u5d81\u5514\u6660\u4ef6\u5d93\u557e\u66ee\u4e2a\u5d55\u555e\u66ef\u4eef\u5d42\u55ad\u66c8\u4e6d\u5d99\u550b\u6607\u4eb5\u5db4\u5506\u6698\u4e6e\u5d1d\u55f3\u66eb\u4e04\u5d6b\u5580\u6685\u4ebe\u5dcf\u5584\u668e\u4ea0\u5dd1\u55c4\u66ba\u4ec4\u5d1b\u5578\u66e7\u4efa\u5d57\u5595\u66a5\u4eec\u5d92\u55a1\u6602\u4e06\u5dbc\u55f7\u66f1\u4e9c\u5db1\u55b6\u669c\u4e8d\u5dcb\u5513\u66f6\u4ef0\u5d37\u5574\u66e4\u4e14\u5d9d\u55b0\u661c\u4ecf\u5dee\u5567\u66b9\u4eb6\u5d02\u554b\u66d7\u4e41\u5d21\u5563\u663d\u4e03\u5de0\u5578\u6605\u4e26\u5d66\u5582\u66fb\u4e32", -269860673);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-216779256 ^ (long)-216779247);
            if (var7) break block23;
            var0_6 = (int)((long)-1443674146 ^ (long)1443674145);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)78691427 ^ (long)78691420);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1349770756 ^ (long)-1349770757);
                    if (0O.\u2003\u200c) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0O.\u2003\u200c) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u5786\u7f9f\u6c79\u64a3\u574a\u7fb3\u6cff\u64cc\u5702\u7f2b\u6c1d\u642f", -1466011383);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-553124862 ^ (long)-553124859);
                            var0_6 = (int)((long)86069784 ^ (long)-86069785);
                            while (true) {
                                v0 = (int)((long)-1141748787 ^ (long)-1141748832);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)343443584 ^ (long)343443584);
                                if (!0O.\u2003\u200c) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0O.\u2003\u200c) ** continue;
                                throw null;
                            }
                            0O.d = var5_1;
                            0O.e = new String[(int)((long)228530791 ^ (long)228530796)];
                            if (!0O.\u2003\u200c) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1972559886 ^ (long)1972559886);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)777486236 ^ (long)777486237)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)231663176 ^ (long)231663183)) {
                                case 0: {
                                    v15 = (int)((long)-199051245 ^ (long)-199051148);
                                    if (!0O.\u2003\u200c) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)402389331 ^ (long)402389263);
                                    if (!0O.\u2003\u200c) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1734329198 ^ (long)1734329204);
                                    if (!0O.\u2003\u200c) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)645847926 ^ (long)645847879);
                                    if (!0O.\u2003\u200c) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-157144691 ^ (long)-157144651);
                                    if (!0O.\u2003\u200c) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1653996092 ^ (long)-1653996086);
                                    if (!0O.\u2003\u200c) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)494686524 ^ (long)494686542);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0O.\u2003\u200c);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0O.\u2003\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-293495846 ^ (long)293479996)) & (int)((long)1976930379 ^ (long)1976922036);
            if (var9_2) ** GOTO lbl-1000
            if (0O.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0O.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1057296149 ^ (long)-1057296149)] & (int)((long)122809065 ^ (long)122808854)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)572749328 ^ (long)572749437);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1793778554 ^ (long)-1793778479);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)892772217 ^ (long)892772194);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-2030261539 ^ (long)-2030261668);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)76570578 ^ (long)76570386);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1647286255 ^ (long)-1647286030);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)816641055 ^ (long)816641244);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-451643722 ^ (long)-451643706);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1914783568 ^ (long)1914783496);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1174681016 ^ (long)1174680926);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)262863007 ^ (long)262862911);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1034140902 ^ (long)-1034140731);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-249620362 ^ (long)-249620314);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1789141588 ^ (long)-1789141654);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-137761647 ^ (long)-137761592);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)5125419 ^ (long)5125549);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1416666634 ^ (long)1416666872);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)276838742 ^ (long)276838701);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)74805074 ^ (long)74805019);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-847286792 ^ (long)-847286918);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-562215109 ^ (long)-562214953);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1646648618 ^ (long)1646648644);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1640754634 ^ (long)1640754515);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1106105191 ^ (long)1106105262);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-775617319 ^ (long)-775617488);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1194002473 ^ (long)1194002487);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1127732862 ^ (long)1127732767);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-659127028 ^ (long)-659126896);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1716760991 ^ (long)1716760915);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1999415605 ^ (long)-1999415660);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1685248434 ^ (long)1685248385);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-312628953 ^ (long)-312628896);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1344312477 ^ (long)1344312536);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)713587675 ^ (long)713587541);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1236752332 ^ (long)-1236752280);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-900368945 ^ (long)-900369044);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1488970720 ^ (long)-1488970746);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-591120244 ^ (long)-591120271);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1499944981 ^ (long)1499944961);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)622506032 ^ (long)622506094);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)2090127 ^ (long)2090085);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1384808127 ^ (long)1384808138);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-461717090 ^ (long)-461717083);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-321661877 ^ (long)-321661746);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1679783112 ^ (long)1679782988);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-849108620 ^ (long)-849108638);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)484306675 ^ (long)484306626);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1193653230 ^ (long)1193653048);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)764754649 ^ (long)764754445);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)2003855403 ^ (long)2003855395);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)2104097645 ^ (long)2104097681);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)498398837 ^ (long)498398968);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1842567363 ^ (long)1842567336);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1044607347 ^ (long)-1044607380);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)561324965 ^ (long)561324894);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)706990521 ^ (long)706990410);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1158474967 ^ (long)-1158474886);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-2091718014 ^ (long)-2091718118);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1314230541 ^ (long)-1314230605);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-206086268 ^ (long)-206086310);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1532710539 ^ (long)-1532710585);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1577551213 ^ (long)1577551315);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1174578331 ^ (long)1174578324);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1116896842 ^ (long)1116896907);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)675972924 ^ (long)675973061);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)647577026 ^ (long)647577005);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1366994292 ^ (long)-1366994392);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)123459903 ^ (long)123459912);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-309001305 ^ (long)-309001436);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-650025647 ^ (long)-650025551);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1547403732 ^ (long)-1547403742);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1078768879 ^ (long)-1078768732);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-254778818 ^ (long)-254778703);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1596875365 ^ (long)-1596875391);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1843192440 ^ (long)-1843192351);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)821623281 ^ (long)821623290);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1881245953 ^ (long)1881246118);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1635488348 ^ (long)-1635488506);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1691402595 ^ (long)1691402514);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1102177113 ^ (long)1102177123);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1930791360 ^ (long)1930791377);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)101145311 ^ (long)101145196);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)400274104 ^ (long)400274124);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)353170318 ^ (long)353170347);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1785671139 ^ (long)1785671011);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)959480276 ^ (long)959480131);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-286070089 ^ (long)-286070061);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1670673566 ^ (long)1670673559);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1251958401 ^ (long)1251958300);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)541327329 ^ (long)541327251);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1672067845 ^ (long)1672068050);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1998147299 ^ (long)1998147179);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1425577092 ^ (long)1425577159);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1964645775 ^ (long)1964645663);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-877366166 ^ (long)-877366118);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-574387033 ^ (long)-574387075);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-196559907 ^ (long)-196559928);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)232925980 ^ (long)232925976);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1764912706 ^ (long)-1764912781);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-147285306 ^ (long)-147285339);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)47919656 ^ (long)47919765);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1408378709 ^ (long)-1408378670);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1078204932 ^ (long)1078205141);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)51014020 ^ (long)51013905);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-2131799988 ^ (long)-2131799965);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)650533846 ^ (long)650533637);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)875101715 ^ (long)875101925);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)510220226 ^ (long)510220146);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1741651530 ^ (long)-1741651654);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1474783984 ^ (long)1474783921);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)509293554 ^ (long)509293365);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1834776116 ^ (long)1834776174);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-964013515 ^ (long)-964013529);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-714627574 ^ (long)-714627488);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1068942858 ^ (long)-1068942926);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1640788500 ^ (long)1640788735);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)2046653474 ^ (long)2046653449);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1164479168 ^ (long)1164479187);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1228780696 ^ (long)-1228780601);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)525771848 ^ (long)525771851);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1229268170 ^ (long)-1229268169);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-256507511 ^ (long)-256507495);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)315033647 ^ (long)315033792);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1340144759 ^ (long)1340144712);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1111014758 ^ (long)1111014903);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)670122273 ^ (long)670122241);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)2064979816 ^ (long)2064979807);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)132441517 ^ (long)132441499);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1449884658 ^ (long)-1449884452);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1747937824 ^ (long)1747937887);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1997249503 ^ (long)-1997249508);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)693341966 ^ (long)693342066);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1714967669 ^ (long)1714967771);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)125426726 ^ (long)125426914);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1440749318 ^ (long)1440749387);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1500637701 ^ (long)1500637739);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)362903171 ^ (long)362903171);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-81505711 ^ (long)-81505627);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)217920406 ^ (long)217920382);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-343064389 ^ (long)-343064558);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1480871701 ^ (long)-1480871760);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-843243705 ^ (long)-843243758);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-407801634 ^ (long)-407801666);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1366525907 ^ (long)1366525713);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)130221523 ^ (long)130221525);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)9213479 ^ (long)9213584);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1315486833 ^ (long)1315486917);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1810541826 ^ (long)1810541961);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-551078301 ^ (long)-551078290);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-923223608 ^ (long)-923223791);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1595397073 ^ (long)1595396939);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1348262099 ^ (long)-1348261929);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1930102437 ^ (long)1930102428);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-315589929 ^ (long)-315589944);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1296704280 ^ (long)-1296704309);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1134170765 ^ (long)1134170821);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-720180230 ^ (long)-720180447);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1668283526 ^ (long)1668283465);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1170417751 ^ (long)1170417865);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1874207381 ^ (long)-1874207248);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-476788801 ^ (long)-476788921);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-209694871 ^ (long)-209694837);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1093849306 ^ (long)1093849212);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-9012062 ^ (long)-9012012);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1705349952 ^ (long)1705350005);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)2095082758 ^ (long)2095082905);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)2140655143 ^ (long)2140655118);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1754058968 ^ (long)1754058806);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1776159961 ^ (long)1776159876);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1102283191 ^ (long)1102283151);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-2122964800 ^ (long)-2122964869);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1528015454 ^ (long)-1528015414);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-464458744 ^ (long)-464458499);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1185835402 ^ (long)-1185835428);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1421715589 ^ (long)-1421715460);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-458231744 ^ (long)-458231790);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)458774828 ^ (long)458774894);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)741419336 ^ (long)741419506);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1440209300 ^ (long)-1440209223);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-363516248 ^ (long)-363516254);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1839592012 ^ (long)-1839592056);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)846204375 ^ (long)846204387);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1648974108 ^ (long)-1648974109);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1739725738 ^ (long)1739725625);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)493432774 ^ (long)493432778);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)952980567 ^ (long)952980559);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)8825295 ^ (long)8825207);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-2115806333 ^ (long)-2115806257);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-2084030138 ^ (long)-2084029972);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1157344937 ^ (long)1157344949);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)272281215 ^ (long)272281240);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)587357192 ^ (long)587357302);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)655888609 ^ (long)655888632);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1740133373 ^ (long)1740133122);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1761561850 ^ (long)-1761561710);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-262177757 ^ (long)-262177586);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-354942894 ^ (long)-354942956);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-299883323 ^ (long)-299883371);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1994814493 ^ (long)-1994814539);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-2131340528 ^ (long)-2131340476);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-2063017893 ^ (long)-2063017853);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-80045916 ^ (long)-80045885);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)757074903 ^ (long)757074934);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1767344965 ^ (long)-1767344937);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1987185630 ^ (long)1987185571);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1167757691 ^ (long)-1167757569);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1017520611 ^ (long)1017520517);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1480955950 ^ (long)1480956005);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)667533857 ^ (long)667533935);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1377679356 ^ (long)1377679178);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1629059596 ^ (long)-1629059791);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1983570800 ^ (long)-1983570938);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1930060637 ^ (long)1930060671);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1081283440 ^ (long)1081283392);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-227718163 ^ (long)-227718324);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1146138825 ^ (long)1146138732);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-587179510 ^ (long)-587179451);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1317832709 ^ (long)-1317832711);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1959580369 ^ (long)-1959580286);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)651642564 ^ (long)651642446);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)441425681 ^ (long)441425883);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1889350104 ^ (long)1889350059);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1574851918 ^ (long)1574852070);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1758134173 ^ (long)1758134192);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-88191506 ^ (long)-88191662);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)737612748 ^ (long)737612745);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)687736387 ^ (long)687736423);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)940056060 ^ (long)940055819);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1287477429 ^ (long)1287477371);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)2139747737 ^ (long)2139747716);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-285533432 ^ (long)-285533393);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1883694645 ^ (long)1883694788);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-2093689168 ^ (long)-2093689188);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)918775762 ^ (long)918775661);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)755205372 ^ (long)755205355);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1717312757 ^ (long)1717312606);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1105233657 ^ (long)-1105233617);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)987517331 ^ (long)987517275);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-728499447 ^ (long)-728499349);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1533065029 ^ (long)1533065112);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)844642716 ^ (long)844642658);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1836478456 ^ (long)-1836478310);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1425416188 ^ (long)-1425416011);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1545664324 ^ (long)-1545664316);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-226226084 ^ (long)-226225991);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1547313080 ^ (long)1547313138);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-474332304 ^ (long)-474332338);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1424582069 ^ (long)1424581895);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1183217403 ^ (long)1183217322);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-110163287 ^ (long)-110163440);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)96973173 ^ (long)96973225);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1084502592 ^ (long)1084502692);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1835104055 ^ (long)1835104190);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-616103559 ^ (long)-616103502);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-2081049603 ^ (long)-2081049775);
                    if (!0O.\u2003\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-292001277 ^ (long)-292001178);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)969524592 ^ (long)969524623)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1502129476 ^ (long)-1502106301)) >>> (int)((long)720800774 ^ (long)720800782)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-587554392 ^ (long)-587554392);
            if (!0O.\u2003\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1965675944 ^ (long)-1965675942);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)258024152 ^ (long)258024155) | var5_6 << (int)((long)-154156123 ^ (long)-154156128)) ^ var3_4[var7_8]) & (int)((long)1451209449 ^ (long)1451209238);
                    if (0O.\u2003\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)77505026 ^ (long)77505025) | var6_7 << (int)((long)552016846 ^ (long)552016843)) ^ var3_4[var7_8]) & (int)((long)-465001888 ^ (long)-465001825);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0O.e[var2_3] = new String(var3_4).intern();
        }
        return 0O.e[var2_3];
    }

    public 0O() {
        boolean bl = \u2003\u200c;
        super(0O.b((int)((long)-1226245073 ^ (long)1226260928), (int)((long)-957458814 ^ (long)957452656)) /* "BoatFly" */, 0O.b((int)((long)-1795583551 ^ (long)1795566628), (int)((long)1411606759 ^ (long)1411581342)) /* "Allows you to fly while in boats" */);
        Float f = Float.valueOf(3.0f);
        34e e2 = ((34e)((34e)((34e)this.9().5(0O.b((int)((long)1697761630 ^ (long)-1697745729), (int)((long)-1226478756 ^ (long)-1226499547)) /* "Up Speed" */)).7(0O.b((int)((long)-1219225549 ^ (long)1219208656), (int)((long)433830858 ^ (long)433827448)) /* "up" */)).1(0O.b((int)((long)-1255804640 ^ (long)1255820486), (int)((long)1427597403 ^ (long)1427602190)) /* "The speed that you fly up" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(10.0f));
        ((34e)((34e)((34e)this.9().5(0O.b((int)((long)1697761630 ^ (long)-1697745729), (int)((long)-1226478756 ^ (long)-1226499547)) /* "Up Speed" */)).7(0O.b((int)((long)-1219225549 ^ (long)1219208656), (int)((long)433830858 ^ (long)433827448)) /* "up" */)).1(0O.b((int)((long)-1255804640 ^ (long)1255820486), (int)((long)1427597403 ^ (long)1427602190)) /* "The speed that you fly up" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(10.0f)).7 = f;
        this.1 = (1A)e2.5();
        f = Float.valueOf(3.0f);
        e2 = ((34e)((34e)((34e)this.9().5(0O.b((int)((long)1363608704 ^ (long)-1363625632), (int)((long)1700155033 ^ (long)-1700146430)) /* "Down Speed" */)).7(0O.b((int)((long)1978747615 ^ (long)-1978730701), (int)((long)-1628118619 ^ (long)-1628119246)) /* "down" */)).1(0O.b((int)((long)-411650508 ^ (long)411634640), (int)((long)-478154810 ^ (long)-478169894)) /* "The speed that you fly down" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(10.0f));
        ((34e)((34e)((34e)this.9().5(0O.b((int)((long)1363608704 ^ (long)-1363625632), (int)((long)1700155033 ^ (long)-1700146430)) /* "Down Speed" */)).7(0O.b((int)((long)1978747615 ^ (long)-1978730701), (int)((long)-1628118619 ^ (long)-1628119246)) /* "down" */)).1(0O.b((int)((long)-411650508 ^ (long)411634640), (int)((long)-478154810 ^ (long)-478169894)) /* "The speed that you fly down" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(10.0f)).7 = f;
        this.9 = (1A)e2.5();
        this.5 = (1P)((34X)((34X)((34X)this.4().5(0O.b((int)((long)1900642054 ^ (long)-1900625183), (int)((long)2128507913 ^ (long)-2128493890)) /* "Stability" */)).7(0O.b((int)((long)1266929000 ^ (long)-1266913146), (int)((long)-1713647625 ^ (long)-1713663771)) /* "stable" */)).1(0O.b((int)((long)1726126136 ^ (long)-1726143014), (int)((long)-366737984 ^ (long)366707683)) /* "Stabilizes movement" */)).5();
        this.6 = new Listener(sh -> {
            double d2;
            3sh sh2;
            boolean bl;
            block19: {
                block18: {
                    bl = \u2003\u200c;
                    if (bl || bl) return;
                    if (0O.3.s == null) break block18;
                    if (bl) return;
                    if (sh.5 == EventState.PRE) break block19;
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            sh = 0O.3.s.ct();
            if (sh == null) return;
            if (bl || bl) return;
            ((aqa)sh).p = 0O.3.s.p;
            if (bl || bl) return;
            if (0O.3.s.f.g) {
                if (bl || bl) {
                    return;
                }
                sh2 = sh;
                d2 = (double)this.1.9 / 10.0;
                if (\u2003\u200c) {
                    throw null;
                }
            } else if (0O.3.k.al.d()) {
                sh2 = sh;
                d2 = -((double)this.9.9 / 10.0);
                if (\u2003\u200c) {
                    throw null;
                }
            } else {
                sh2 = sh;
                if (this.5.2) {
                    d2 = 0.04;
                    if (\u2003\u200c) {
                        throw null;
                    }
                } else {
                    d2 = 0.0;
                }
            }
            4m.9((aqa)sh2, d2);
        }, new Predicate[(int)((long)814220193 ^ (long)814220193)]);
    }
}

