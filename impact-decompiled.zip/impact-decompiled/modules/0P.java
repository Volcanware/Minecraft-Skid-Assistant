/* ==========================================================================
 * MODULE: Levitation Control
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Eases control of shulker levitation effects
 * OBFUSCATED CLASS: net.impactclient.0P
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aot
 *  apw
 *  aqa
 *  bfw
 *  bgo
 *  dzm
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import clientapi.load.mixin.7.2;
import java.util.Comparator;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.11;
import net.impactclient.1A;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.2P;
import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.34H;
import net.impactclient.34J;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.4J;
import net.impactclient.4X;
import net.impactclient.4m;
import net.impactclient.66;
import net.impactclient.6L;
import net.impactclient.9V;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0P
extends 3X
implements 34B {
    private bgo 5;
    public static final boolean \u2005\u200c\u200e\u200c\u2006\u200c;
    @EventHandler
    private final Listener<4X> 4;
    private 1P 8;
    private static final String[] d;
    private 1A 0;
    private 11 1;
    private 1K 9;
    @EventHandler
    private final Listener<4J> 7;
    private static final String[] e;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0P.\u2005\u200c\u200e\u200c\u2006\u200c;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-437470877 ^ (long)-437470862)];
            if (var7) break block23;
            var3_2 = (int)((long)1274050859 ^ (long)1274050859);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u792b\u51ee\u42ac\u4af4\u7989\u5115\u4269\u4a1e\u79eb\u5195\u421d\u4a8d\u7922\u51f1\u4293\u4af4\u7933\u51b4\u4214\u4a5a\u79e6\u5152\u420b\u4a40\u790b\u5142\u427c\u4a42\u79ef\u510b\u4274\u4a02\u79af\u5111\u4264\u4ac8\u799f\u5132\u421a\u4ac5\u792d\u51bd\u421c\u4ace\u7926\u5138\u429e\u4a3d\u79a7\u51d4\u4221\u4afb\u7917\u513f\u42dd\u4ac1\u79d4\u5125\u428d\u4ab7\u7914\u5114\u4269\u4acc\u798c\u5179\u4265\u4ac8\u7998\u518e\u4286\u4a2f\u7991\u513c\u4258\u4a96\u7962\u51f3\u421a\u4a23\u79c8\u51e8\u42c7\u4a7a\u7953\u51e7\u427b\u4a58\u799b\u517c\u42f7\u4a82\u791f\u5177\u42f1\u4ae5\u79db\u515e\u4254\u4af7\u795d\u51af\u4289\u4a5a\u7961\u515b\u421b\u4a42\u79e0\u5179\u42d9\u4a52\u79c6\u5129\u429b\u4a00\u7954\u5177\u421a\u4abf\u7987\u51f8\u42a0\u4a52\u7997\u51f2\u42ff\u4a1a\u79cc\u5102\u4249\u4a89\u796d\u5119\u4276\u4ad7\u793b\u5107\u426c\u4a48\u79d0\u51d8\u42d1\u4af1\u79be\u51a1\u42fc\u4a60\u7925\u518b\u42d5\u4a44\u7925\u51f5\u4222\u4a77\u7926\u5111\u42cb\u4a76\u79c3\u5149\u423f\u4a4f\u79cf\u511a\u42b2\u4a61\u79ca\u5119\u428a\u4a2c\u799e\u5196\u42b0\u4a1a\u797b\u51f1\u4228\u4a03\u7927\u51c1\u428f\u4a20\u7971\u514e\u4221\u4a6c\u7977\u5149\u4212\u4ac9\u79a8\u5149\u423c\u4acb\u79da\u512d\u420d\u4ae3\u79c5\u51d0\u427e\u4ab7\u7931\u5116\u4269\u4a31\u79b5\u5123\u4267\u4a5c\u7974\u516d\u4264\u4a7c\u7982\u5113\u4237\u4a70\u799d\u515f\u42cd\u4ae1\u79c8\u5164\u42aa\u4a9a\u7952\u51b3\u4209\u4a65\u79db\u5132\u422b\u4a9f\u79da\u519b\u421c\u4ac5\u7903\u5143\u42ab\u4a08\u79b9\u511f\u4249\u4a46\u79a5\u51a4\u4285\u4a3a\u7915\u5170\u4216\u4afb\u792c\u517a\u4201\u4a37\u799c\u5100\u4279\u4a8f\u7914\u5154\u423f\u4a4f\u79eb\u51ab\u4220\u4a89\u79c0\u5164\u4224\u4a23", -1487118449);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-503708070 ^ (long)-503708065);
            if (var7) break block23;
            var0_6 = (int)((long)658512234 ^ (long)-658512235);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1745152949 ^ (long)-1745153006);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1964380550 ^ (long)1964380549);
                    if (0P.\u2005\u200c\u200e\u200c\u2006\u200c) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ub1a6\u9968\u8a21\u82f2\ub144\u99ad\u8a4b\u82c9\ub1e2\u9909\u8a92\u82b4\ub173\u9924\u8a1f\u8222\ub1ec\u992f\u8a19\u82f2\ub151\u99bc\u8a82\u8240\ub160\u993d\u8afa\u8245\ub1c6\u99e5\u8a96\u82e5\ub1f8\u9933\u8a88\u82f3\ub13d\u99fa\u8a17\u8290\ub15a\u99bf\u8ac8\u82c6\ub110\u99b4\u8a35\u8283\ub10a\u9907\u8ab7\u829c\ub19c\u99b2", -185166067);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)1505040834 ^ (long)1505040873);
                            var0_6 = (int)((long)-546293469 ^ (long)546293468);
                            while (true) {
                                v0 = (int)((long)-203247552 ^ (long)-203247502);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1272108259 ^ (long)1272108259);
                                if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) ** continue;
                                throw null;
                            }
                            0P.d = var5_1;
                            0P.e = new String[(int)((long)-281160974 ^ (long)-281160989)];
                            if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1829089689 ^ (long)1829089689);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1894227867 ^ (long)-1894227868)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-2056302153 ^ (long)-2056302160)) {
                                case 0: {
                                    v15 = (int)((long)1226631721 ^ (long)1226631700);
                                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)860480560 ^ (long)860480631);
                                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1141725608 ^ (long)-1141725584);
                                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1615435282 ^ (long)-1615435267);
                                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1230632181 ^ (long)-1230632158);
                                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)60478729 ^ (long)60478776);
                                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1664597294 ^ (long)-1664597330);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0P.\u2005\u200c\u200e\u200c\u2006\u200c);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0P.\u2005\u200c\u200e\u200c\u2006\u200c;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)185772395 ^ (long)185762262)) & (int)((long)-121037492 ^ (long)-120986957);
            if (var9_2) ** GOTO lbl-1000
            if (0P.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0P.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-2032709256 ^ (long)-2032709256)] & (int)((long)-1793977780 ^ (long)-1793977677)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1938122853 ^ (long)-1938122928);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)884498029 ^ (long)884498100);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1074666427 ^ (long)1074666404);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-894183680 ^ (long)-894183456);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1539844816 ^ (long)1539844653);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)2137222662 ^ (long)2137222835);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-3330800 ^ (long)-3330750);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1353592539 ^ (long)-1353592470);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1225065007 ^ (long)1225064972);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1460376198 ^ (long)1460376212);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1406448975 ^ (long)1406449015);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1798805001 ^ (long)1798805109);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1816615149 ^ (long)-1816614994);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-2033335331 ^ (long)-2033335517);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)2078318189 ^ (long)2078318286);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)2047168514 ^ (long)2047168706);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-28433403 ^ (long)-28433374);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1906741367 ^ (long)1906741473);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1182830655 ^ (long)1182830797);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)580854694 ^ (long)580854751);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-519932099 ^ (long)-519931982);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-829997931 ^ (long)-829998041);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1867003347 ^ (long)1867003208);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)756861586 ^ (long)756861595);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1890512071 ^ (long)1890511949);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1549485804 ^ (long)-1549485622);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-452157991 ^ (long)-452157968);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-640584929 ^ (long)-640584894);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)711705460 ^ (long)711705462);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1689287435 ^ (long)1689287580);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-875689837 ^ (long)-875689775);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)2025518486 ^ (long)2025518407);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-329323152 ^ (long)-329323094);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)791194379 ^ (long)791194579);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1504196547 ^ (long)-1504196424);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1044020537 ^ (long)1044020507);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1322325173 ^ (long)1322325209);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)518815427 ^ (long)518815387);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-589736305 ^ (long)-589736373);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1058059088 ^ (long)-1058059047);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1220536695 ^ (long)-1220536725);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1146031861 ^ (long)1146031864);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1514372568 ^ (long)1514372429);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-642288319 ^ (long)-642288233);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-143791579 ^ (long)-143791461);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1780943606 ^ (long)-1780943580);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1166279300 ^ (long)1166279294);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1829409798 ^ (long)1829409800);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)191001419 ^ (long)191001549);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1702141271 ^ (long)-1702141411);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1275939030 ^ (long)1275938932);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1034721950 ^ (long)-1034721839);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)2102598286 ^ (long)2102598296);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-554540725 ^ (long)-554540688);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-215331072 ^ (long)-215330988);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1798077428 ^ (long)-1798077365);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1494354956 ^ (long)1494355127);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)870985191 ^ (long)870985012);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1810340044 ^ (long)-1810340055);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1500790251 ^ (long)-1500790260);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1815900698 ^ (long)-1815900776);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1778132743 ^ (long)-1778132766);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1933258563 ^ (long)-1933258629);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1415050992 ^ (long)-1415050893);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)666401365 ^ (long)666401524);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-36392773 ^ (long)-36392926);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1840802951 ^ (long)1840802879);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-657317014 ^ (long)-657316914);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)753431193 ^ (long)753431125);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)954040120 ^ (long)954040185);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)333591060 ^ (long)333591279);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-2039016012 ^ (long)-2039015945);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1040110172 ^ (long)-1040110140);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-2015774527 ^ (long)-2015774479);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1086213396 ^ (long)-1086213451);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1103291329 ^ (long)-1103291210);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1421370427 ^ (long)-1421370485);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-762492016 ^ (long)-762492067);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1256082037 ^ (long)-1256082027);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1836666143 ^ (long)1836666156);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1897595313 ^ (long)-1897595323);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1643879667 ^ (long)-1643879457);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1954650444 ^ (long)1954650618);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)726873365 ^ (long)726873408);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1716624708 ^ (long)-1716624862);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1007957547 ^ (long)1007957563);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1554543178 ^ (long)1554543310);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1343281147 ^ (long)1343280962);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1671155064 ^ (long)-1671155079);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-2090793780 ^ (long)-2090793823);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)491155800 ^ (long)491155923);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1823050574 ^ (long)1823050660);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)75902050 ^ (long)75902070);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)114755739 ^ (long)114755660);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1774304505 ^ (long)1774304452);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-848399492 ^ (long)-848399424);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1087652309 ^ (long)-1087652210);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1517979661 ^ (long)1517979706);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1080046114 ^ (long)1080046241);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-51755222 ^ (long)-51755244);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1140844488 ^ (long)-1140844492);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)70722020 ^ (long)70722016);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1484005245 ^ (long)1484005143);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-306082363 ^ (long)-306082420);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1893493828 ^ (long)-1893493847);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1218568232 ^ (long)1218568361);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)414878919 ^ (long)414878889);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1378937475 ^ (long)-1378937509);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-775987205 ^ (long)-775987212);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1318477430 ^ (long)1318477383);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1374619607 ^ (long)1374619466);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-2053709335 ^ (long)-2053709498);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-2024764797 ^ (long)-2024764742);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1691934597 ^ (long)-1691934518);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)779154995 ^ (long)779155104);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-2001370522 ^ (long)-2001370532);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)394637538 ^ (long)394637541);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1932902969 ^ (long)1932903120);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1339755319 ^ (long)-1339755419);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-746003328 ^ (long)-746003335);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)2054351785 ^ (long)2054351724);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1564381283 ^ (long)1564381244);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-941509269 ^ (long)-941509220);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1341117344 ^ (long)-1341117321);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1983204521 ^ (long)-1983204426);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-508227278 ^ (long)-508227162);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1418050943 ^ (long)-1418051066);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1437262439 ^ (long)1437262406);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1922593271 ^ (long)-1922593186);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1074807332 ^ (long)-1074807325);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)2040817279 ^ (long)2040817334);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1161733644 ^ (long)1161733871);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)348970567 ^ (long)348970534);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1731482138 ^ (long)1731482314);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-616060852 ^ (long)-616060870);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)90294591 ^ (long)90294650);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)420804181 ^ (long)420804250);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)861728775 ^ (long)861728788);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1247289185 ^ (long)1247289104);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)902537091 ^ (long)902536971);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)760895557 ^ (long)760895669);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1097320833 ^ (long)1097320949);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1719684181 ^ (long)1719684144);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)385772928 ^ (long)385773002);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1145698010 ^ (long)-1145698035);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-2068288068 ^ (long)-2068288194);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1541549719 ^ (long)-1541549595);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)156799635 ^ (long)156799560);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)105757321 ^ (long)105757205);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1013143596 ^ (long)-1013143588);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-2078591229 ^ (long)-2078591116);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-3192712 ^ (long)-3192824);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)150149203 ^ (long)150149221);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)2046244160 ^ (long)2046244149);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1610821147 ^ (long)-1610821281);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1479017509 ^ (long)1479017558);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-801372307 ^ (long)-801372253);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1480951130 ^ (long)-1480951059);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1754398302 ^ (long)-1754398378);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1583908184 ^ (long)1583908204);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-845154874 ^ (long)-845154968);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1667865414 ^ (long)1667865459);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-2079177593 ^ (long)-2079177620);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)495608983 ^ (long)495608855);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1911956854 ^ (long)-1911956889);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-554615582 ^ (long)-554615726);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-864906366 ^ (long)-864906284);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1123556131 ^ (long)-1123556343);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-2018907710 ^ (long)-2018907705);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-196558611 ^ (long)-196558773);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-291632102 ^ (long)-291632073);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)581923426 ^ (long)581923388);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-555153278 ^ (long)-555153192);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)40075893 ^ (long)40075913);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1909426419 ^ (long)-1909426411);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-521014095 ^ (long)-521014158);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-2135935259 ^ (long)-2135935398);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1972513465 ^ (long)1972513465);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1268761846 ^ (long)-1268761765);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-2075820926 ^ (long)-2075821027);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-2140014880 ^ (long)-2140015097);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1671400299 ^ (long)-1671400272);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-2030884007 ^ (long)-2030883930);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1415049548 ^ (long)-1415049594);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1577028761 ^ (long)1577028631);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1193948150 ^ (long)-1193948106);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1523419258 ^ (long)-1523419343);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1388403622 ^ (long)1388403639);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)405225427 ^ (long)405225230);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-755376770 ^ (long)-755376806);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)923365799 ^ (long)923365693);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-874874075 ^ (long)-874873979);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)742843282 ^ (long)742843252);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-123938983 ^ (long)-123938895);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)558992114 ^ (long)558991882);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)337500590 ^ (long)337500482);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1924276127 ^ (long)1924276099);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)2065318174 ^ (long)2065318367);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)604091671 ^ (long)604091842);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-843823512 ^ (long)-843823580);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1912508900 ^ (long)-1912508680);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1268518374 ^ (long)1268518318);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)2106074349 ^ (long)2106074347);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1484645912 ^ (long)-1484645964);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1159332102 ^ (long)1159332235);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-509379682 ^ (long)-509379788);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)578038002 ^ (long)578037940);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1024955686 ^ (long)1024955740);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1106935985 ^ (long)-1106936016);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1693365479 ^ (long)1693365447);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1886276106 ^ (long)1886276174);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-132560848 ^ (long)-132560741);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)737412531 ^ (long)737412584);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1184259747 ^ (long)1184259783);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-200859147 ^ (long)-200859153);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)451298109 ^ (long)451298264);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-726191417 ^ (long)-726191412);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1808010020 ^ (long)1808010059);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1248815534 ^ (long)-1248815533);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1395567653 ^ (long)1395567709);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1055269599 ^ (long)1055269417);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)754524569 ^ (long)754524597);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1041537858 ^ (long)1041537969);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)269564651 ^ (long)269564457);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)999225461 ^ (long)999225514);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1722077922 ^ (long)-1722077853);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1107173304 ^ (long)-1107173187);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1534555290 ^ (long)-1534555185);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)823660578 ^ (long)823660658);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1518641627 ^ (long)-1518641438);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-2028007401 ^ (long)-2028007297);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)2086262057 ^ (long)2086262200);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)295611806 ^ (long)295611654);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-291279823 ^ (long)-291279785);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-443193568 ^ (long)-443193424);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1847937016 ^ (long)1847936922);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-43074873 ^ (long)-43074937);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1527447782 ^ (long)1527447560);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1893107287 ^ (long)-1893107386);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1695297203 ^ (long)-1695297226);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-793453555 ^ (long)-793453409);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-987632551 ^ (long)-987632399);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1216349658 ^ (long)-1216349631);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)2065261093 ^ (long)2065261143);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-2129627299 ^ (long)-2129627378);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1500443057 ^ (long)1500442908);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1532975133 ^ (long)1532975290);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1709370794 ^ (long)-1709370759);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1471319418 ^ (long)-1471319380);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1978594320 ^ (long)-1978594502);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-346293675 ^ (long)-346293635);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)340571464 ^ (long)340571540);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1436348244 ^ (long)1436348316);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1144626699 ^ (long)1144626696);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1188074200 ^ (long)1188074163);
                    if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-768880632 ^ (long)-768880571);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-31493287 ^ (long)-31493210)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)938696625 ^ (long)938713166)) >>> (int)((long)-698938976 ^ (long)-698938968)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1608843499 ^ (long)-1608843499);
            if (!0P.\u2005\u200c\u200e\u200c\u2006\u200c) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1052403415 ^ (long)-1052403413);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)840303753 ^ (long)840303754) | var5_6 << (int)((long)1338136435 ^ (long)1338136438)) ^ var3_4[var7_8]) & (int)((long)-2091327192 ^ (long)-2091327017);
                    if (0P.\u2005\u200c\u200e\u200c\u2006\u200c) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-675694573 ^ (long)-675694576) | var6_7 << (int)((long)-1580457064 ^ (long)-1580457059)) ^ var3_4[var7_8]) & (int)((long)1161017654 ^ (long)1161017801);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0P.e[var2_3] = new String(var3_4).intern();
        }
        return 0P.e[var2_3];
    }

    public 0P() {
        boolean bl = \u2005\u200c\u200e\u200c\u2006\u200c;
        super(0P.b((int)((long)1208012663 ^ (long)1208018883), (int)((long)-905614645 ^ (long)905627321)) /* "Levitation Control" */, 0P.b((int)((long)-802043994 ^ (long)-802033900), (int)((long)-1469950183 ^ (long)-1469962404)) /* "Eases control of shulker levitation effects" */);
        String[] stringArray = new String[(int)((long)1142909184 ^ (long)1142909186)];
        stringArray[(int)((long)-284178880 ^ (long)-284178880)] = 0P.b((int)((long)-464303234 ^ (long)-464297010), (int)((long)1443855343 ^ (long)1443839445)) /* "Still" */;
        stringArray[(int)((long)-1734493868 ^ (long)-1734493867)] = 0P.b((int)((long)25456980 ^ (long)25450990), (int)((long)-362848203 ^ (long)362865170));
        Object object = stringArray;
        34J j3 = (34H)((34H)((34H)this.0().5(0P.b((int)((long)903504502 ^ (long)903498459), (int)((long)-753057639 ^ (long)-753071917)) /* "Sneak Mode" */)).7(0P.b((int)((long)-1643408124 ^ (long)-1643397711), (int)((long)2059718288 ^ (long)-2059705214)) /* "sneakMode" */)).1(0P.b((int)((long)471545048 ^ (long)471538793), (int)((long)443422718 ^ (long)-443446220)) /* "Whether sneaking should enable or disable floating" */);
        ((34H)((34H)((34H)this.0().5(0P.b((int)((long)903504502 ^ (long)903498459), (int)((long)-753057639 ^ (long)-753071917)) /* "Sneak Mode" */)).7(0P.b((int)((long)-1643408124 ^ (long)-1643397711), (int)((long)2059718288 ^ (long)-2059705214)) /* "sneakMode" */)).1(0P.b((int)((long)471545048 ^ (long)471538793), (int)((long)443422718 ^ (long)-443446220)) /* "Whether sneaking should enable or disable floating" */)).3 = object;
        object = 0P.b((int)((long)-1756113717 ^ (long)-1756103567), (int)((long)1949489802 ^ (long)-1949476691));
        v1.7 = object;
        this.1 = (11)j3.5();
        object = Boolean.TRUE;
        j3 = (34X)((34X)((34X)this.4().5(0P.b((int)((long)447462335 ^ (long)447451912), (int)((long)-126487268 ^ (long)-126498949)) /* "Anti Bullet" */)).7(0P.b((int)((long)-652607259 ^ (long)-652597154), (int)((long)1700426316 ^ (long)1700404960)) /* "antiBullet" */)).1(0P.b((int)((long)-1616772008 ^ (long)-1616761632), (int)((long)-839050868 ^ (long)-839045296)) /* "Attacks incoming shulker bullets" */);
        ((34X)((34X)((34X)this.4().5(0P.b((int)((long)447462335 ^ (long)447451912), (int)((long)-126487268 ^ (long)-126498949)) /* "Anti Bullet" */)).7(0P.b((int)((long)-652607259 ^ (long)-652597154), (int)((long)1700426316 ^ (long)1700404960)) /* "antiBullet" */)).1(0P.b((int)((long)-1616772008 ^ (long)-1616761632), (int)((long)-839050868 ^ (long)-839045296)) /* "Attacks incoming shulker bullets" */)).7 = object;
        this.8 = (1P)((34X)j3).5();
        object = 5.0;
        j3 = ((34e)((34e)((34e)this.7().5(0P.b((int)((long)763767556 ^ (long)763757497), (int)((long)911215762 ^ (long)-911234212)) /* "Range" */)).7(0P.b((int)((long)-1825816334 ^ (long)-1825806261), (int)((long)-4929891 ^ (long)-4930910)) /* "range" */)).1(0P.b((int)((long)1811355161 ^ (long)1811365541), (int)((long)33960496 ^ (long)33971338)) /* "Distance that shulker bullets will be attacked from" */)).3(2.0).2(6.0);
        ((34e)((34e)((34e)this.7().5(0P.b((int)((long)763767556 ^ (long)763757497), (int)((long)911215762 ^ (long)-911234212)) /* "Range" */)).7(0P.b((int)((long)-1825816334 ^ (long)-1825806261), (int)((long)-4929891 ^ (long)-4930910)) /* "range" */)).1(0P.b((int)((long)1811355161 ^ (long)1811365541), (int)((long)33960496 ^ (long)33971338)) /* "Distance that shulker bullets will be attacked from" */)).3(2.0).2(6.0).7 = object;
        this.9 = (1K)((34e)((34e)j3).3(this.8)).5();
        object = Float.valueOf(360.0f);
        j3 = ((34e)((34e)((34e)this.9().5(0P.b((int)((long)657028995 ^ (long)657022768), (int)((long)487119171 ^ (long)487115367)) /* "FOV" */)).7(0P.b((int)((long)243976991 ^ (long)243983264), (int)((long)-377884517 ^ (long)-377895941)) /* "fov" */)).1(0P.b((int)((long)-1445255764 ^ (long)-1445262062), (int)((long)305472668 ^ (long)305479204)) /* "FOV that shulker bullets must be in to be targeted" */)).3(Float.valueOf(10.0f)).2(Float.valueOf(360.0f));
        ((34e)((34e)((34e)this.9().5(0P.b((int)((long)657028995 ^ (long)657022768), (int)((long)487119171 ^ (long)487115367)) /* "FOV" */)).7(0P.b((int)((long)243976991 ^ (long)243983264), (int)((long)-377884517 ^ (long)-377895941)) /* "fov" */)).1(0P.b((int)((long)-1445255764 ^ (long)-1445262062), (int)((long)305472668 ^ (long)305479204)) /* "FOV that shulker bullets must be in to be targeted" */)).3(Float.valueOf(10.0f)).2(Float.valueOf(360.0f)).7 = object;
        this.0 = (1A)((34e)((34e)j3).3(this.8)).5();
        this.7 = new Listener(j2 -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2005\u200c\u200e\u200c\u2006\u200c;
                        if (bl || bl) break block2;
                        if (j2.2 != EventState.POST) break block3;
                        if (bl) break block2;
                        if (!0P.3.s.a(apw.y)) break block3;
                        if (bl) break block2;
                        if (!(0P.3.s.f.h ^ ((String)this.1.0()).equals(0P.b((int)((long)118093128 ^ (long)118087166), (int)((long)-177854643 ^ (long)-177859553)) /* "Float" */))) break block3;
                        if (bl || bl) break block2;
                        4m.1(0.0);
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)1898898573 ^ (long)1898898573)]);
        this.4 = new Listener(x2 -> {
            boolean bl = \u2005\u200c\u200e\u200c\u2006\u200c;
            if (bl || bl) return;
            if (!this.8.2) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            switch (2P.0[x2.7.ordinal()]) {
                case 1: {
                    if (bl) return;
                    this.5 = 6L.3(0P.3.r).filter(bgo.class::isInstance).filter(aqa2 -> {
                        boolean bl = \u2005\u200c\u200e\u200c\u2006\u200c;
                        if (bl || bl) return true;
                        if ((double)aqa2.g((aqa)0P.3.s) < this.9.1) {
                            if (bl) return true;
                            if (66.3(aqa2) <= (double)(this.0.9 / 2.0f)) {
                                if (bl) return true;
                                return (int)((long)891856375 ^ (long)891856374) != 0;
                            }
                        }
                        if (!bl) return (int)((long)-2122275367 ^ (long)-2122275367) != 0;
                        return true;
                    }).min(Comparator.comparingDouble(arg_0 -> ((dzm)0P.3.s).g(arg_0))).orElse(null);
                    if (bl || bl) return;
                    if (this.5 == null) break;
                    if (bl || bl) return;
                    9V v = 66.3(((2)this.5).getPos().7(0.0, (double)this.5.ce() * 0.5, 0.0));
                    if (bl || bl) return;
                    x2.6(v.6).2(v.3);
                    if (bl || bl) return;
                    return;
                }
                case 2: {
                    if (bl) return;
                    if (this.5 == null) break;
                    if (bl || bl) return;
                    0P.3.s.a(aot.a);
                    if (bl || bl) return;
                    0P.3.q.a((bfw)0P.3.s, (aqa)this.5);
                    if (bl || bl) return;
                    this.5 = null;
                    if (bl) return;
                    break;
                }
            }
            if (!bl) return;
        }, new Predicate[(int)((long)734683758 ^ (long)734683758)]);
    }
}

