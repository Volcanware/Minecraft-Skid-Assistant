/* ==========================================================================
 * MODULE: Animations
 * CATEGORY (inferred): Render
 * DESCRIPTION: Modify held-item animations
 * OBFUSCATED CLASS: net.impactclient.0Z
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  aqa
 *  aqi
 *  aqm
 *  bmv
 *  bnf
 *  com.mojang.blaze3d.systems.RenderSystem
 *  eag
 *  ebm$b
 *  g
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  tq
 */
package net.impactclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Random;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import me.zero.clarinet.hook.mixin.accessor.AccessorFirstPersonRenderer;
import net.impactclient.11;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.2w$6X;
import net.impactclient.34H;
import net.impactclient.34J;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.34s;
import net.impactclient.3C;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3s0;
import net.impactclient.9d;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0Z
extends 3X
implements 3s0 {
    private Random 7;
    @EventHandler
    private final Listener<3C> 9;
    private static final String[] e;
    @EventHandler
    private final Listener<9d> 4;
    private 11 1;
    public static final boolean \u2003\u2002\u200a\u200a;
    public 1K 5;
    private float 8;
    private 1P 2;
    private static final String[] d;
    public 1P 0;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0Z.\u2003\u2002\u200a\u200a;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)387259714 ^ (long)387259732)];
            if (var7) break block23;
            var3_2 = (int)((long)-1748966465 ^ (long)-1748966465);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\ua3c6\u8b79\u981e\u900f\ua31b\u8b72\u98aa\u901a\ua3ce\u8b89\u98b3\u9008\ua36d\u8b06\u98da\u9028\ua3fb\u8b5d\u980c\u90ad\ua311\u8b2c\u9860\u903c\ua338\u8ba7\u9831\u9049\ua32c\u8bee\u987b\u90f6\ua3ad\u8bf9\u9876\u9008\ua3f0\u8bbb\u988a\u90b2\ua3c0\u8b56\u9808\u909b\ua331\u8be8\u9836\u90d8\ua340\u8b63\u9886\u90fe\ua39d\u8b6b\u98da\u90de\ua391\u8b61\u9819\u90f7\ua304\u8b4a\u98cf\u9017\ua30d\u8b5b\u980d\u9098\ua3b1\u8b99\u982b\u90e0\ua3c2\u8b06\u9889\u9003\ua340\u8ba7\u98b4\u90b6\ua3bc\u8b39\u98d9\u90e8\ua30e\u8b80\u98fa\u903c\ua331\u8b25\u98f8\u900a\ua353\u8bb7\u98f8\u900e\ua30d\u8b20\u9872\u909e\ua3c6\u8bdb\u9865\u9070\ua325\u8b72\u98c8\u909c\ua391\u8b61\u989e\u90bf\ua3eb\u8be8\u9831\u9048\ua3ca\u8b2b\u98ba\u9013\ua3fb\u8bdf\u9870\u90e7\ua3b1\u8b86\u98ae\u9018\ua3a7\u8b93\u9864\u90c1\ua32f\u8b45\u9801\u908f\ua3a2\u8bae\u9866\u903a\ua3c9\u8b66\u98f9\u9018\ua3c6\u8bd2\u98c2\u90a9\ua38b\u8ba3\u988c\u9025\ua3df\u8b1f\u98cd\u90de\ua3ac\u8b1b\u98c4\u909f\ua3df\u8b22\u982a\u906d\ua344\u8b17\u983a\u900e\ua3e1\u8bee\u9844\u90ab\ua3cd\u8b18\u98a4\u90a8\ua3ec\u8bbd\u98ac\u9007\ua390\u8be3\u9848\u90df\ua380\u8b6d\u980b\u9040\ua366\u8bcd\u9853\u900e\ua332\u8b1d\u98a9\u90f6\ua3c3\u8b13\u9832\u9031\ua33d\u8bc7\u9875\u909c\ua3b7\u8b05\u982a\u90ec\ua318\u8b95\u988c\u906a\ua398\u8bc4\u98d2\u90d5\ua396\u8b0a\u9891\u9052\ua363\u8b9e\u9846\u9007\ua3c1\u8b31\u988e\u90de\ua3c3\u8b3a\u9867\u905a\ua315\u8b40\u984c\u9072\ua31b\u8b2b\u9814\u90d1\ua364\u8be2\u9888\u9034\ua334\u8b3f\u98d9\u9075\ua392\u8b70\u98b2\u9091\ua3ee\u8be3\u98a4\u90c1\ua314\u8b38\u9840\u9075\ua3cc\u8b0b\u9872\u90b0\ua3cf\u8b7b\u9808\u90a8\ua313\u8b06\u98d0\u90b8\ua384\u8b61\u98ec\u9050\ua3ba\u8bbe\u9818\u9002\ua3fe\u8b6e\u986f\u90de\ua331\u8b8b\u983a\u904b\ua3ce\u8be3\u9843\u9034\ua33d\u8bfd\u987f\u9078\ua3a3\u8b33\u982e\u9084\ua362\u8b2b", 424773069);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1433538269 ^ (long)1433538270);
            if (var7) break block23;
            var0_6 = (int)((long)-1447160329 ^ (long)1447160328);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)485553052 ^ (long)485553044);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)391148298 ^ (long)-391148299);
                    if (0Z.\u2003\u2002\u200a\u200a) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0Z.\u2003\u2002\u200a\u200a) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u8eda\ua634\ub557\ubdd7\u8ec3\ua672\ub59e\ubdfb\u8e96\ua691", 704161936);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-264226167 ^ (long)-264226163);
                            var0_6 = (int)((long)992046086 ^ (long)-992046087);
                            while (true) {
                                v0 = (int)((long)1702294891 ^ (long)1702294805);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)511848455 ^ (long)511848455);
                                if (!0Z.\u2003\u2002\u200a\u200a) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0Z.\u2003\u2002\u200a\u200a) ** continue;
                                throw null;
                            }
                            0Z.d = var5_1;
                            0Z.e = new String[(int)((long)1041079172 ^ (long)1041079186)];
                            if (!0Z.\u2003\u2002\u200a\u200a) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1498068217 ^ (long)1498068217);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)2043504444 ^ (long)2043504445)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-624789126 ^ (long)-624789123)) {
                                case 0: {
                                    v15 = (int)((long)-1885783429 ^ (long)-1885783444);
                                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1759333462 ^ (long)1759333420);
                                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1554635539 ^ (long)1554635541);
                                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-646675518 ^ (long)-646675460);
                                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-480118965 ^ (long)-480118996);
                                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1541998583 ^ (long)1541998480);
                                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-226997010 ^ (long)-226997066);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0Z.\u2003\u2002\u200a\u200a);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0Z.\u2003\u2002\u200a\u200a;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1823860672 ^ (long)-1823860880)) & (int)((long)-688083236 ^ (long)-688107229);
            if (var9_2) ** GOTO lbl-1000
            if (0Z.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0Z.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)699068245 ^ (long)699068245)] & (int)((long)-1210116956 ^ (long)-1210117029)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-687154418 ^ (long)-687154336);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)2109534273 ^ (long)2109534372);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-2102958425 ^ (long)-2102958476);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1871179717 ^ (long)-1871179682);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1503497344 ^ (long)1503497303);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)471147977 ^ (long)471147949);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)286969358 ^ (long)286969486);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-767744343 ^ (long)-767744449);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-245711466 ^ (long)-245711579);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-2004176486 ^ (long)-2004176522);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1974866511 ^ (long)-1974866602);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1511474106 ^ (long)-1511473921);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-477843205 ^ (long)-477843438);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)744561644 ^ (long)744561497);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1299204118 ^ (long)1299204229);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)649004099 ^ (long)649004171);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1354870926 ^ (long)1354870862);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1786574338 ^ (long)-1786574368);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)122148941 ^ (long)122148954);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1513929319 ^ (long)-1513929272);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-377762883 ^ (long)-377762979);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1799237046 ^ (long)1799237005);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)2089598476 ^ (long)2089598574);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)2121029194 ^ (long)2121029229);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1288473279 ^ (long)1288473257);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1716381640 ^ (long)-1716381621);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1415082430 ^ (long)-1415082419);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1455620479 ^ (long)-1455620566);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)514803575 ^ (long)514803648);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-645242595 ^ (long)-645242448);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)389713454 ^ (long)389713497);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1405105293 ^ (long)1405105262);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)67640735 ^ (long)67640695);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1148472771 ^ (long)-1148472811);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-785992605 ^ (long)-785992500);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1145470121 ^ (long)1145470161);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1634973171 ^ (long)1634972972);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-346146597 ^ (long)-346146713);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-90918060 ^ (long)-90917990);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1612337037 ^ (long)1612337029);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)400747598 ^ (long)400747603);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-920680631 ^ (long)-920680631);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1700903181 ^ (long)-1700903204);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)32967843 ^ (long)32967681);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1764100116 ^ (long)-1764100128);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1928472976 ^ (long)-1928472843);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1431299019 ^ (long)-1431299022);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)2058376802 ^ (long)2058376894);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)817376250 ^ (long)817376226);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1423750512 ^ (long)1423750456);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-250701761 ^ (long)-250701750);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-553436660 ^ (long)-553436528);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-528419746 ^ (long)-528419683);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1723098343 ^ (long)-1723098202);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-143167532 ^ (long)-143167625);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-616059998 ^ (long)-616060109);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1920846111 ^ (long)-1920846312);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1730243239 ^ (long)-1730243130);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)235898034 ^ (long)235898019);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1035990714 ^ (long)1035990554);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1900239554 ^ (long)1900239508);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1082646751 ^ (long)1082646666);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-754948706 ^ (long)-754948847);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1971669265 ^ (long)1971669430);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1307062968 ^ (long)-1307062788);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-4280673 ^ (long)-4280739);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1687531233 ^ (long)-1687531028);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-2054886281 ^ (long)-2054886276);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1696956909 ^ (long)1696956681);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)893185908 ^ (long)893185976);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)2047478227 ^ (long)2047478206);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1749559587 ^ (long)-1749559656);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)2048867459 ^ (long)2048867444);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-148014193 ^ (long)-148014312);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)121353611 ^ (long)121353602);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-667986062 ^ (long)-667985933);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1955010975 ^ (long)-1955010827);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1975424603 ^ (long)-1975424621);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1265986773 ^ (long)-1265986634);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)876975575 ^ (long)876975613);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1488581350 ^ (long)1488581164);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1755739214 ^ (long)-1755739232);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1856034082 ^ (long)1856034296);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-344793849 ^ (long)-344793674);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)754000944 ^ (long)754000903);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1420695209 ^ (long)1420695151);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1360570891 ^ (long)1360571101);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1015252578 ^ (long)1015252526);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1159512166 ^ (long)-1159512079);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1834143196 ^ (long)1834143194);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-946051098 ^ (long)-946051167);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)849033681 ^ (long)849033589);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1011961870 ^ (long)-1011961943);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-511764275 ^ (long)-511764300);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-974428071 ^ (long)-974428067);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)378514622 ^ (long)378514498);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-635345982 ^ (long)-635346161);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-2022688270 ^ (long)-2022688480);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1807213926 ^ (long)1807214038);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1431277444 ^ (long)-1431277347);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)51259495 ^ (long)51259433);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1647219762 ^ (long)-1647219963);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)546669061 ^ (long)546669114);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-765123108 ^ (long)-765123301);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1982368986 ^ (long)1982368880);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1817433286 ^ (long)1817433117);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1235461212 ^ (long)1235461272);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)379813575 ^ (long)379813622);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)28545750 ^ (long)28545615);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-342760001 ^ (long)-342759966);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1831809000 ^ (long)1831808893);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-422046743 ^ (long)-422046774);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)161926675 ^ (long)161926893);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-88066721 ^ (long)-88066579);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-658414661 ^ (long)-658414794);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1345968224 ^ (long)1345968128);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1810876409 ^ (long)1810876252);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)111063133 ^ (long)111063176);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1943338462 ^ (long)-1943338414);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-179538373 ^ (long)-179538409);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1277443942 ^ (long)-1277444044);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1304459762 ^ (long)-1304459690);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-406524031 ^ (long)-406523941);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1913268024 ^ (long)-1913268069);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1096934382 ^ (long)1096934198);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1617686170 ^ (long)-1617686271);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-482035442 ^ (long)-482035438);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1992866245 ^ (long)-1992866074);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1641962821 ^ (long)-1641962767);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-797476814 ^ (long)-797476621);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)105125741 ^ (long)105125690);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-199586707 ^ (long)-199586672);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1270544106 ^ (long)-1270544091);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1682053114 ^ (long)1682052900);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-442200751 ^ (long)-442200816);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)982171509 ^ (long)982171421);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)290202015 ^ (long)290202082);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1464416449 ^ (long)1464416499);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1793180171 ^ (long)-1793180406);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)696024126 ^ (long)696024305);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1569026893 ^ (long)1569027041);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1821028380 ^ (long)1821028588);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1147824118 ^ (long)-1147823950);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-793977412 ^ (long)-793977517);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)997150442 ^ (long)997150212);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)696331441 ^ (long)696331319);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-955634282 ^ (long)-955634270);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1676617764 ^ (long)1676617752);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)588571911 ^ (long)588572140);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1878150764 ^ (long)1878150669);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-247683382 ^ (long)-247683486);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1141769790 ^ (long)1141769792);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1257682273 ^ (long)-1257682265);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1807594254 ^ (long)1807594357);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-208786768 ^ (long)-208786858);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1243776054 ^ (long)1243776044);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)618911464 ^ (long)618911385);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1460650103 ^ (long)1460650100);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1708820042 ^ (long)-1708819994);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1872426229 ^ (long)1872426213);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1624502506 ^ (long)1624502416);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1767232380 ^ (long)-1767232339);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1023480465 ^ (long)1023480453);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1992305132 ^ (long)-1992305078);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1841475575 ^ (long)-1841475478);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-608447299 ^ (long)-608447322);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)2104286061 ^ (long)2104285986);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1572297744 ^ (long)-1572297967);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-838126683 ^ (long)-838126735);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1821505061 ^ (long)-1821505198);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)2055128595 ^ (long)2055128617);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)248034551 ^ (long)248034319);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1273727908 ^ (long)-1273727806);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1969040657 ^ (long)-1969040769);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1419454690 ^ (long)-1419454552);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)383981591 ^ (long)383981745);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1580827074 ^ (long)-1580826971);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1963939565 ^ (long)1963939388);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1319330262 ^ (long)1319330107);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1842643696 ^ (long)1842643460);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)499613254 ^ (long)499613396);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1387833360 ^ (long)-1387833421);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1354442520 ^ (long)-1354442703);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1519901642 ^ (long)1519901590);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-751908597 ^ (long)-751908499);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-2066908540 ^ (long)-2066908467);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)118420001 ^ (long)118420018);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1388447833 ^ (long)1388447975);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)5209140 ^ (long)5209295);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1235613108 ^ (long)-1235612937);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-67377723 ^ (long)-67377734);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-184526697 ^ (long)-184526806);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)747446730 ^ (long)747446677);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1788034357 ^ (long)1788034363);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1218024240 ^ (long)1218024209);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-492662373 ^ (long)-492662507);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1917702762 ^ (long)1917702819);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1373415519 ^ (long)-1373415465);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)2040784898 ^ (long)2040784982);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)672639754 ^ (long)672639874);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-489526742 ^ (long)-489526561);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1362938057 ^ (long)1362937971);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-450474061 ^ (long)-450474167);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1619988511 ^ (long)-1619988733);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)635305936 ^ (long)635305878);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1242158180 ^ (long)-1242158203);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1382257438 ^ (long)1382257562);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)2068412518 ^ (long)2068412531);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)277273564 ^ (long)277273496);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-147243102 ^ (long)-147243089);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)198486056 ^ (long)198486108);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)690211356 ^ (long)690211388);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1537440387 ^ (long)-1537440262);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)347143734 ^ (long)347143754);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)941393270 ^ (long)941393243);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-97939438 ^ (long)-97939404);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1808025502 ^ (long)1808025499);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1914001164 ^ (long)1914001212);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-2086665948 ^ (long)-2086665796);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-2088370192 ^ (long)-2088370308);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1569978005 ^ (long)1569978004);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-765216273 ^ (long)-765216310);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)380281641 ^ (long)380281771);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1698138405 ^ (long)1698138487);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1438664299 ^ (long)-1438664235);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1065345038 ^ (long)1065345122);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1836234325 ^ (long)1836234373);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1289154302 ^ (long)-1289154197);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1497269233 ^ (long)-1497269019);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1749614823 ^ (long)-1749614616);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1892773148 ^ (long)1892773182);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)572597111 ^ (long)572597081);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1889286495 ^ (long)1889286448);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-2114652714 ^ (long)-2114652686);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1890235943 ^ (long)-1890236005);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1220888970 ^ (long)-1220889009);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1709683712 ^ (long)1709683909);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)568454963 ^ (long)568454936);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-961715825 ^ (long)-961715790);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1857655319 ^ (long)1857655421);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1955739378 ^ (long)-1955739305);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-2019520845 ^ (long)-2019520998);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1595271489 ^ (long)-1595271607);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-802268309 ^ (long)-802268331);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)30984413 ^ (long)30984367);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)383050930 ^ (long)383051007);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-2100929326 ^ (long)-2100929504);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-264305295 ^ (long)-264305285);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-674384822 ^ (long)-674384704);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1894398987 ^ (long)-1894398998);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-13145117 ^ (long)-13145240);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)731405727 ^ (long)731405780);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1949844323 ^ (long)-1949844321);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-531895075 ^ (long)-531895064);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-2109443982 ^ (long)-2109443855);
                    if (!0Z.\u2003\u2002\u200a\u200a) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)564795686 ^ (long)564795836);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1714068639 ^ (long)1714068576)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1417186279 ^ (long)1417180184)) >>> (int)((long)-1250764345 ^ (long)-1250764337)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-2092571017 ^ (long)-2092571017);
            if (!0Z.\u2003\u2002\u200a\u200a) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-919321688 ^ (long)-919321686);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1668280152 ^ (long)-1668280149) | var5_6 << (int)((long)-1015834111 ^ (long)-1015834108)) ^ var3_4[var7_8]) & (int)((long)-571704366 ^ (long)-571704531);
                    if (0Z.\u2003\u2002\u200a\u200a) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1853182363 ^ (long)-1853182362) | var6_7 << (int)((long)203197024 ^ (long)203197029)) ^ var3_4[var7_8]) & (int)((long)-543032304 ^ (long)-543032081);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0Z.e[var2_3] = new String(var3_4).intern();
        }
        return 0Z.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    private /* synthetic */ void 6(9d var1_1) {
        block39: {
            block38: {
                var12_2 = 0Z.\u2003\u2002\u200a\u200a;
                if (var12_2) lbl-1000:
                // 9 sources

                {
                    return;
                }
                var3_3 = var1_1.0;
                var4_4 = (AccessorFirstPersonRenderer)var3_3;
                var2_5 = 3e.5();
                if (var12_2 || var12_2) ** GOTO lbl-1000
                if (this.2.2) break block38;
                if (var12_2) ** GOTO lbl-1000
                return;
            }
            if (var12_2) ** GOTO lbl-1000
            if (!(var1_1.1.b() instanceof bmv)) break block39;
            if (var12_2 || var12_2) ** GOTO lbl-1000
            var1_1.cancel();
            if (var12_2 || var12_2) ** GOTO lbl-1000
            return;
        }
        if (var12_2) ** GOTO lbl-1000
        if (!(0Z.3.s.dD().b() instanceof bnf)) ** GOTO lbl-1000
        if (var12_2) ** GOTO lbl-1000
        if (0Z.3.s.dY().b() instanceof bmv) {
            if (!var12_2) ** break;
            ** continue;
            v0 = (int)((long)-1793733178 ^ (long)-1793733177);
            if (0Z.\u2003\u2002\u200a\u200a) {
                throw null;
            }
        } else lbl-1000:
        // 2 sources

        {
            v0 = (int)((long)1783839198 ^ (long)1783839198);
        }
        if (v0 == 0) {
            return;
        }
        var1_1.cancel();
        RenderSystem.pushMatrix();
        var5_6 = 0.0f;
        if (!0Z.3.T()) {
            this.8 += 0.15f * var1_1.2;
        }
        if (this.8 < 1.0f) {
            var5_6 = Math.max(0.0f, this.8);
            if (v1 > 0.5f) {
                var5_6 = 1.0f - this.8;
            }
        }
        var6_12 = var1_1.9;
        var4_4.callTransformSideFirstPerson(var6_12, var1_1.8, var5_6);
        var5_7 = (String)this.1.0();
        var7_13 = (int)((long)1373332245 ^ (long)-1373332246);
        switch (var5_7.hashCode()) {
            case 867554807: {
                if (!var5_7.equals(0Z.b((int)((long)-629785260 ^ (long)-629788041), (int)((long)-165402467 ^ (long)-165382927)) /* "Pandora" */)) break;
                var7_13 = (int)((long)-1325304476 ^ (long)-1325304476);
                if (var2_5 == null) break;
            }
            case 79882757: {
                if (!var5_7.equals(0Z.b((int)((long)1087606686 ^ (long)1087602879), (int)((long)107077426 ^ (long)107071893)) /* "Sigma" */)) break;
                var7_13 = (int)((long)-82758717 ^ (long)-82758718);
                if (var2_5 == null) break;
            }
            case 48570: {
                if (!var5_7.equals(0Z.b((int)((long)-1977354475 ^ (long)-1977354200), (int)((long)652655802 ^ (long)-652668943)))) break;
                var7_13 = (int)((long)867141565 ^ (long)867141567);
                if (var2_5 == null) break;
            }
            case 48571: {
                if (!var5_7.equals(0Z.b((int)((long)-1143022977 ^ (long)-1143024306), (int)((long)453791355 ^ (long)453776581)) /* "1.8" */)) break;
                var7_13 = (int)((long)-1903602173 ^ (long)-1903602176);
            }
        }
        switch (var7_13) {
            case 0: {
                var6_12.a(g.d.a(93.0f));
                var6_12.a(g.b.a(-80.0f));
                var6_12.a(g.f.a(-17.0f));
                var5_8 = afm.a((float)((float)(Math.sqrt(var1_1.4) * 3.141592653589793)));
                var6_12.a(-0.15000000596046448, 0.25, 0.15000000596046448);
                var6_12.a(new g(1.0f, -0.4f, 0.0f).a(-var5_8 * 30.0f));
                if (!0Z.\u2003\u2002\u200a\u200a) break;
                throw null;
            }
            case 1: {
                var5_9 = afm.a((float)((float)(Math.sqrt(var1_1.4) * 3.141592653589793)));
                var6_12.a(0.4 + (double)var5_9 * -0.2, 0.1, -0.2);
                var4_4.callTransformFirstPerson(var6_12, var1_1.8, var1_1.4);
                var6_12.a(-0.2, 0.1, 0.0);
                var6_12.a(g.b.a(-25.0f));
                var6_12.a(g.d.a(80.0f));
                var6_12.a(g.b.a(-75.0f));
                if (!0Z.\u2003\u2002\u200a\u200a) break;
                throw null;
            }
            case 2: 
            case 3: {
                var4_4.callTransformFirstPerson(var6_12, var1_1.8, var1_1.4);
                var5_10 = ((String)this.1.0()).equals(0Z.b((int)((long)-1592364019 ^ (long)-1592362179), (int)((long)-182138809 ^ (long)-182125535)) /* "1.7" */);
                if (var5_10) {
                    v2 = 0.18;
                    if (0Z.\u2003\u2002\u200a\u200a) {
                        throw null;
                    }
                } else {
                    v2 = var8_14 = 0.25;
                }
                if (var5_10) {
                    v3 = 0.125;
                    if (0Z.\u2003\u2002\u200a\u200a) {
                        throw null;
                    }
                } else {
                    v3 = var10_15 = 0.1;
                }
                if (var5_10) {
                    v4 = -0.05;
                    if (0Z.\u2003\u2002\u200a\u200a) {
                        throw null;
                    }
                } else {
                    v4 = 0.0;
                }
                var6_12.a(v4, var10_15, var8_14);
                var6_12.a(g.b.a(-25.0f));
                var6_12.a(g.d.a(80.0f));
                var6_12.a(g.b.a(-75.0f));
                var6_12.a(0.0, -var10_15 + 0.2, -var8_14 + 0.25);
                if (!var5_10) break;
                var6_12.a(-0.15, 0.05, 0.0);
            }
        }
        if (var1_1.8 == aqi.b) {
            v5 = (int)((long)885133127 ^ (long)885133126);
            if (0Z.\u2003\u2002\u200a\u200a) {
                throw null;
            }
        } else {
            v5 = (int)((long)1081843605 ^ (long)1081843605);
        }
        var5_11 = v5;
        v6 = 0Z.3.s;
        v7 = var1_1.1;
        if (var5_11 != 0) {
            v8 = ebm.b.e;
            if (0Z.\u2003\u2002\u200a\u200a) {
                throw null;
            }
        } else {
            v8 = ebm.b.d;
        }
        if (var5_11 == 0) {
            v9 = (int)((long)1062447395 ^ (long)1062447394);
            if (0Z.\u2003\u2002\u200a\u200a) {
                throw null;
            }
        } else {
            v9 = (int)((long)-302204772 ^ (long)-302204772);
        }
        var3_3.a((aqm)v6, v7, v8, (boolean)v9, var6_12, (eag)0Z.3.aE().b(), 0Z.3.ac().a((aqa)0Z.3.s, var1_1.2));
        RenderSystem.popMatrix();
    }

    public 0Z() {
        boolean bl = \u2003\u2002\u200a\u200a;
        super(0Z.b((int)((long)704128388 ^ (long)704129725), (int)((long)980161922 ^ (long)980165694)) /* "Animations" */, 0Z.b((int)((long)-1619820209 ^ (long)-1619816845), (int)((long)742025382 ^ (long)-742016997)) /* "Modify held-item animations" */);
        Object object = Boolean.TRUE;
        34J j2 = (34X)((34X)((34X)this.4().5(0Z.b((int)((long)-1332853546 ^ (long)-1332851724), (int)((long)-1371398088 ^ (long)-1371387461)) /* "Sword Blocking" */)).7(0Z.b((int)((long)1470860598 ^ (long)1470857740), (int)((long)-1897074585 ^ (long)1897086173)) /* "block" */)).1(0Z.b((int)((long)-1816164028 ^ (long)-1816164737), (int)((long)1797029969 ^ (long)-1797034243)) /* "Allows swords to be blocked when you have a shield in your off-hand." */);
        ((34X)((34X)((34X)this.4().5(0Z.b((int)((long)-1332853546 ^ (long)-1332851724), (int)((long)-1371398088 ^ (long)-1371387461)) /* "Sword Blocking" */)).7(0Z.b((int)((long)1470860598 ^ (long)1470857740), (int)((long)-1897074585 ^ (long)1897086173)) /* "block" */)).1(0Z.b((int)((long)-1816164028 ^ (long)-1816164737), (int)((long)1797029969 ^ (long)-1797034243)) /* "Allows swords to be blocked when you have a shield in your off-hand." */)).7 = object;
        this.2 = (1P)j2.5();
        String[] stringArray = new String[(int)((long)-580865596 ^ (long)-580865600)];
        stringArray[(int)((long)-1537909901 ^ (long)-1537909901)] = 0Z.b((int)((long)-450800235 ^ (long)-450798939), (int)((long)1126358679 ^ (long)1126361841)) /* "1.7" */;
        stringArray[(int)((long)1780648010 ^ (long)1780648011)] = 0Z.b((int)((long)-437041993 ^ (long)-437040252), (int)((long)-411161574 ^ (long)-411142177));
        stringArray[(int)((long)-188713669 ^ (long)-188713671)] = 0Z.b((int)((long)910537995 ^ (long)910539326), (int)((long)703172377 ^ (long)703185412));
        stringArray[(int)((long)-1219595831 ^ (long)-1219595830)] = 0Z.b((int)((long)-2068136036 ^ (long)-2068139843), (int)((long)1347151901 ^ (long)1347157690)) /* "Sigma" */;
        object = stringArray;
        j2 = (34H)((34H)((34H)this.0().5(0Z.b((int)((long)-1178186032 ^ (long)-1178189328), (int)((long)917195061 ^ (long)-917184246)) /* "Block Mode" */)).7(0Z.b((int)((long)99972230 ^ (long)99974050), (int)((long)1896546042 ^ (long)1896531223)) /* "mode" */)).1(0Z.b((int)((long)297225276 ^ (long)297222923), (int)((long)-1523123317 ^ (long)-1523143561)) /* "Change how the sword blocks" */);
        ((34H)((34H)((34H)this.0().5(0Z.b((int)((long)-1178186032 ^ (long)-1178189328), (int)((long)917195061 ^ (long)-917184246)) /* "Block Mode" */)).7(0Z.b((int)((long)99972230 ^ (long)99974050), (int)((long)1896546042 ^ (long)1896531223)) /* "mode" */)).1(0Z.b((int)((long)297225276 ^ (long)297222923), (int)((long)-1523123317 ^ (long)-1523143561)) /* "Change how the sword blocks" */)).3 = object;
        this.1 = (11)((34H)j2.3(this.2)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0Z.b((int)((long)-502851160 ^ (long)-502851946), (int)((long)-1220010298 ^ (long)1219997219)) /* "Better Shield" */)).7(0Z.b((int)((long)1791638291 ^ (long)1791636523), (int)((long)180851850 ^ (long)-180847808)) /* "shield" */)).1(0Z.b((int)((long)950565300 ^ (long)950564486), (int)((long)1073071721 ^ (long)-1073070991)) /* "Enable Shield Settings" */);
        ((34X)((34X)((34X)this.4().5(0Z.b((int)((long)-502851160 ^ (long)-502851946), (int)((long)-1220010298 ^ (long)1219997219)) /* "Better Shield" */)).7(0Z.b((int)((long)1791638291 ^ (long)1791636523), (int)((long)180851850 ^ (long)-180847808)) /* "shield" */)).1(0Z.b((int)((long)950565300 ^ (long)950564486), (int)((long)1073071721 ^ (long)-1073070991)) /* "Enable Shield Settings" */)).7 = object;
        this.0 = (1P)((34X)j2).5();
        object = 0.05;
        j2 = ((34e)((34e)((34e)this.7().5(0Z.b((int)((long)-829963394 ^ (long)-829961142), (int)((long)-1879626655 ^ (long)-1879634589)) /* "Lowered Amount" */)).7(0Z.b((int)((long)-358285192 ^ (long)-358281379), (int)((long)1267178345 ^ (long)1267197076)) /* "lower" */)).1(0Z.b((int)((long)-647383808 ^ (long)-647382465), (int)((long)1492247553 ^ (long)1492241310)) /* "Adjust the height of the shield" */)).3(0.0).2(0.2);
        ((34e)((34e)((34e)this.7().5(0Z.b((int)((long)-829963394 ^ (long)-829961142), (int)((long)-1879626655 ^ (long)-1879634589)) /* "Lowered Amount" */)).7(0Z.b((int)((long)-358285192 ^ (long)-358281379), (int)((long)1267178345 ^ (long)1267197076)) /* "lower" */)).1(0Z.b((int)((long)-647383808 ^ (long)-647382465), (int)((long)1492247553 ^ (long)1492241310)) /* "Adjust the height of the shield" */)).3(0.0).2(0.2).7 = object;
        this.5 = (1K)((34e)j2).5();
        this.7 = new Random();
        this.4 = new Listener(this::6, new Predicate[(int)((long)301814499 ^ (long)301814499)]);
        Predicate[] predicateArray = new Predicate[(int)((long)822058152 ^ (long)822058153)];
        Class[] classArray = new Class[(int)((long)-500215564 ^ (long)-500215563)];
        classArray[(int)((long)-251502701 ^ (long)-251502701)] = tq.class;
        predicateArray[(int)((long)-783277217 ^ (long)-783277217)] = new 34s(classArray);
        this.9 = new Listener(c2 -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2003\u2002\u200a\u200a;
                        if (bl || bl) break block2;
                        if (((String)this.1.0()).equals(0Z.b((int)((long)100083466 ^ (long)100083772), (int)((long)-1866330663 ^ (long)1866330512)))) break block3;
                        if (bl) break block2;
                        if (!(this.8 > 1.0f)) break block3;
                        if (bl) break block2;
                        if (this.7.nextInt((int)((long)-672403853 ^ (long)-672403847)) != (int)((long)-1435536767 ^ (long)-1435536763)) break block3;
                        if (bl || bl) break block2;
                        this.8 = -0.1f;
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, predicateArray);
    }
}

