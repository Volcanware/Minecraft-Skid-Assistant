/* ==========================================================================
 * MODULE: Velocity
 * CATEGORY (inferred): Player
 * DESCRIPTION: Adjust your Velocity
 * OBFUSCATED CLASS: net.impactclient.0w
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  po
 *  rc
 */
package net.impactclient;

import java.lang.constant.Constable;
import java.util.Random;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import me.zero.clarinet.hook.mixin.accessor.AccessorSEntityVelocityPacket;
import me.zero.clarinet.hook.mixin.accessor.AccessorSExplosionPacket;
import net.impactclient.1A;
import net.impactclient.1P;
import net.impactclient.1z;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.34J;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.34s;
import net.impactclient.3X;
import net.impactclient.3i;
import net.impactclient.3sh;
import net.impactclient.3u;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0w
extends 3X
implements 34B {
    private 1P 4;
    private 1z 2;
    public static final boolean \u2000\u2001;
    public 1P 6;
    private static final String[] e;
    private 1P 9;
    @EventHandler
    private final Listener<3i> 7;
    private static final String[] d;
    private 1A 5;
    private 1P 1;
    private 1z 0;
    private 1z 8;
    @EventHandler
    private final Listener<3sh> 9z;
    private 1A 9S;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0w.\u2000\u2001;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1229199605 ^ (long)1229199594)];
            if (var7) break block23;
            var3_2 = (int)((long)-1668934328 ^ (long)-1668934328);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u9107\ub998\uaaa1\ua239\u9172\ub96f\uaad1\ua281\u9143\ub9ef\uaa49\ua258\u9116\ub9be\uaa24\ua21b\u9150\ub9fa\uaa5f\ua2ef\u9127\ub917\uaa83\ua2d5\u91f7\ub931\uaa41\ua2b6\u9139\ub93e\uaa43\ua202\u915a\ub914\uaaef\ua222\u9116\ub9cd\uaa05\ua244\u910a\ub927\uaaec\ua262\u911b\ub9de\uaa74\ua240\u9174\ub910\uaa04\ua2aa\u9158\ub9d4\uaa5d\ua247\u9114\ub9f3\uaa82\ua228\u91a9\ub91a\uaa07\ua29c\u9164\ub99b\uaadc\ua2bf\u91d9\ub91b\uaaa2\ua2e3\u9122\ub90a\uaae1\ua280\u9128\ub93f\uaae5\ua285\u917b\ub9e3\uaa9d\ua20a\u91e5\ub9c7\uaa6d\ua286\u91ba\ub9ef\uaa52\ua24f\u915c\ub96f\uaafc\ua22f\u9150\ub9c6\uaadd\ua219\u9118\ub967\uaaae\ua24c\u9192\ub98b\uaa9e\ua287\u9186\ub9f6\uaafb\ua27f\u911f\ub927\uaaaf\ua211\u9188\ub999\uaa39\ua2a5\u91d7\ub994\uaa1d\ua2b8\u9198\ub909\uaaf6\ua254\u910e\ub9a8\uaa61\ua257\u9142\ub9ff\uaa60\ua206\u9156\ub950\uaac4\ua2dc\u91fc\ub9f3\uaa07\ua24f\u91a6\ub9c4\uaa79\ua227\u9193\ub925\uaab9\ua249\u9108\ub915\uaa51\ua2a5\u917f\ub9fa\uaa91\ua21a\u9118\ub951\uaa2b\ua247\u9178\ub9c9\uaa82\ua291\u911e\ub99b\uaa9f\ua2fa\u9174\ub9ba\uaae6\ua244\u9167\ub92c\uaae6\ua2cf\u9122\ub9fe\uaa89\ua22e\u9164\ub9de\uaa6f\ua2af\u91b3\ub910\uaa44\ua2b0\u918e\ub925\uaa89\ua2e9\u9171\ub9fb\uaacd\ua20b\u91e7\ub984\uaace\ua222\u91df\ub977\uaaa8\ua23d\u9134\ub975\uaa98\ua2d9\u916a\ub9dc\uaadd\ua216\u912e\ub943\uaa07\ua266\u9188\ub9d6\uaa39\ua2be\u913d\ub9e3\uaacd\ua267\u91ff\ub98e\uaabd\ua2fd\u91c2\ub978\uaadf\ua270\u9106\ub918\uaa66\ua2b5\u917d\ub994\uaa93\ua218\u9182\ub943\uaa35\ua2a7\u91f5\ub994\uaa5a\ua2aa\u91fa\ub9bb\uaaed\ua2bb\u91dd\ub9d1\uaaf3\ua21f\u9113\ub99f\uaa1b\ua268\u9198\ub9ea\uaaba\ua2ea\u9191\ub900\uaa86\ua2cb\u919c\ub9b9\uaa14\ua2c0\u915d\ub9d9\uaa0f\ua2a6\u911c\ub9e0\uaa6f\ua27b\u91f9\ub907\uaa02\ua27b\u9179\ub936\uaa46\ua244\u91fe\ub97c\uaa7e\ua245\u9122\ub905\uaabf\ua28d\u913b\ub91c\uaa30\ua2f3\u9103\ub980\uaa47\ua208\u91ad\ub900\uaab9\ua219\u91b1\ub9d2\uaa89\ua23e\u91e3\ub9dd\uaa9f\ua2c8\u914b\ub9ca\uaac6\ua21e\u91fa\ub920\uaae5\ua2fc\u9142\ub93a\uaa7e\ua264\u91e7\ub95e\uaa4f\ua241\u91f9\ub9f0\uaae4\ua231\u9154\ub94a\uaabe\ua247\u9181\ub9df\uaaf7\ua26e\u914e\ub9d6\uaaef\ua2f4\u91b7\ub931\uaaac\ua2c7\u91e3\ub912\uaa11\ua2e9\u9120\ub92f\uaa8e\ua243\u91f1\ub957\uaa54\ua205\u9177\ub93a\uaa3e\ua2d9\u91b3\ub91e\uaa05\ua2a6\u91cb\ub9bc\uaaea\ua23d\u9140\ub9d8\uaae0\ua2e5\u91d7\ub923\uaa6d\ua2d3\u91cf\ub92f\uaa4f\ua2dd\u91bb\ub91f\uaad4\ua2c9\u91dc\ub96d\uaa03\ua248\u912e\ub9b1\uaac2\ua29f\u9118\ub977\uaaee\ua268\u91dc\ub9e7\uaa24\ua284\u9153\ub979\uaa34\ua2d0\u912b\ub9af\uaa44\ua22e\u91cd\ub95a\uaa89\ua24d\u9164\ub906\uaa7f\ua2d6\u91f8\ub9e3\uaa15\ua222\u9158\ub98c\uaa39\ua2f2\u911f\ub9da\uaaaa\ua202\u9146\ub97c\uaa99\ua2af\u917f\ub920\uaac8\ua221\u9159\ub9ea\uaa60\ua263\u91b6\ub97c\uaaba\ua2bd\u9149\ub98f\uaa5e\ua228\u914d\ub93d\uaa1c\ua24c\u9112\ub980\uaaa9\ua21e\u91eb\ub9a7\uaa73\ua2bc\u91c8\ub989\uaac9\ua2ce\u9196\ub9e4\uaab6\ua27d\u91e4\ub9fb\uaa38\ua2df\u91ec\ub94e\uaab2\ua220\u91ba\ub90a\uaa89\ua260\u91a1\ub9f4\uaaf9\ua214\u9114\ub9a7\uaafd\ua2df\u9123\ub9fa\uaacf\ua26b\u912e\ub9fd\uaae7\ua202\u9150\ub9b5\uaaec\ua2d7\u9130\ub9b2\uaa0a\ua2f8\u91c7\ub9e1\uaa44\ua2e1\u9133\ub98c\uaad2\ua27e\u9126\ub91a\uaa07\ua24d\u9110\ub928\uaa4b\ua2c9\u9149\ub996\uaad4\ua287\u91f6\ub948\uaa7f\ua277\u91f1\ub9dd\uaa85\ua2bc\u91f6\ub92f\uaa3d\ua2f4\u91cb\ub9a8\uaaa3\ua2d5\u916d\ub9d5\uaa07\ua286\u91d8\ub97e\uaaad\ua236\u918e\ub9d8\uaa34\ua26e\u9156\ub9f6\uaa61\ua2f5\u91df\ub94a\uaa5a\ua283\u91a6\ub9dd\uaa2f\ua296\u9129\ub97f\uaa69\ua290\u9114\ub908\uaa61\ua23e\u914f\ub98d\uaa93\ua236\u91ab\ub9d7\uaa35\ua27a\u918a\ub998\uaa49\ua245\u914d\ub9dc\uaa61\ua2ad\u9151\ub9ac\uaaca\ua272\u91fd\ub95c\uaa8a\ua276\u913d\ub9e8\uaa4e\ua244\u91f4\ub99c\uaab9\ua2fc\u9166\ub9ac\uaaf1\ua2d9\u9173\ub991\uaae0\ua288\u91c5\ub931\uaa9d\ua2bd\u9104\ub977\uaa09\ua2ff\u914a\ub9df\uaa89\ua237\u91ff\ub97c\uaa4e\ua2ca\u91b8\ub960\uaa5d\ua256\u9197\ub913\uaa77\ua24e\u91c5\ub96b\uaa69\ua297\u91e6\ub92f\uaa44\ua2b6\u9189\ub92a\uaa85\ua241\u91fa\ub990\uaabc\ua203\u91fb\ub956\uaa84\ua2a6\u91be\ub979\uaa25\ua237\u91a0\ub995\uaa99\ua2b9\u9158\ub9ba\uaa50\ua238\u91bb\ub97f\uaaea\ua2d8\u913a", 153794359);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)318387849 ^ (long)318387841);
            if (var7) break block23;
            var0_6 = (int)((long)1611666858 ^ (long)-1611666859);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1072351221 ^ (long)1072351229);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1810659718 ^ (long)1810659717);
                    if (0w.\u2000\u2001) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0w.\u2000\u2001) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u749c\u5c2f\u4f54\u47ef\u7408\u5c67\u4fe2\u470c\u7414\u5cc0\u4fd3\u47fb\u7474", -291679629);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)2038406117 ^ (long)2038406113);
                            var0_6 = (int)((long)-99725984 ^ (long)99725983);
                            while (true) {
                                v0 = (int)((long)-998747365 ^ (long)-998747377);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)60565994 ^ (long)60565994);
                                if (!0w.\u2000\u2001) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0w.\u2000\u2001) ** continue;
                                throw null;
                            }
                            0w.d = var5_1;
                            0w.e = new String[(int)((long)1250547928 ^ (long)1250547911)];
                            if (!0w.\u2000\u2001) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-2127564926 ^ (long)-2127564926);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-753999503 ^ (long)-753999504)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-231278198 ^ (long)-231278195)) {
                                case 0: {
                                    v15 = (int)((long)771867356 ^ (long)771867273);
                                    if (!0w.\u2000\u2001) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1613997667 ^ (long)1613997675);
                                    if (!0w.\u2000\u2001) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1224177012 ^ (long)1224176961);
                                    if (!0w.\u2000\u2001) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)424231369 ^ (long)424231300);
                                    if (!0w.\u2000\u2001) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-251045246 ^ (long)-251045165);
                                    if (!0w.\u2000\u2001) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-767437924 ^ (long)-767437826);
                                    if (!0w.\u2000\u2001) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1218147834 ^ (long)1218147830);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0w.\u2000\u2001);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0w.\u2000\u2001;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1872911957 ^ (long)-1872891501)) & (int)((long)-1669565326 ^ (long)-1669559411);
            if (var9_2) ** GOTO lbl-1000
            if (0w.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0w.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-220273494 ^ (long)-220273494)] & (int)((long)19908956 ^ (long)19909027)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)271373244 ^ (long)271373215);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1933605726 ^ (long)1933605790);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)957527648 ^ (long)957527562);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1417715562 ^ (long)1417715662);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)707337736 ^ (long)707337861);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-496440299 ^ (long)-496440308);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)169222552 ^ (long)169222625);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1884384537 ^ (long)-1884384697);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-622893976 ^ (long)-622893987);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-151438139 ^ (long)-151438098);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-934549522 ^ (long)-934549693);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-255020111 ^ (long)-255020145);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1128092193 ^ (long)-1128092170);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1746160801 ^ (long)1746160745);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-698353451 ^ (long)-698353634);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1463567169 ^ (long)-1463567281);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)432914088 ^ (long)432914104);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1635887885 ^ (long)1635888091);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1861066435 ^ (long)-1861066412);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1766122119 ^ (long)-1766122078);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-332465191 ^ (long)-332465167);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-487140439 ^ (long)-487140550);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)442455141 ^ (long)442455182);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1109310897 ^ (long)-1109310885);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-2093914814 ^ (long)-2093914667);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-781886175 ^ (long)-781886205);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1750740081 ^ (long)-1750740155);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-687138519 ^ (long)-687138521);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)137374677 ^ (long)137374650);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1771465430 ^ (long)-1771465340);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-789962530 ^ (long)-789962729);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-2068813508 ^ (long)-2068813434);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)920465296 ^ (long)920465282);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)204311032 ^ (long)204310810);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1033561121 ^ (long)1033561120);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)2066279021 ^ (long)2066278939);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-334460548 ^ (long)-334460529);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1246838820 ^ (long)-1246838797);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1523597780 ^ (long)1523597612);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-13917006 ^ (long)-13917082);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-190555332 ^ (long)-190555368);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1321323038 ^ (long)1321323251);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1319196754 ^ (long)-1319196858);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1496575440 ^ (long)-1496575403);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-2130578248 ^ (long)-2130578426);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)39218437 ^ (long)39218479);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1789613970 ^ (long)-1789613917);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1423349039 ^ (long)1423349175);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1912683770 ^ (long)-1912683611);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1394132955 ^ (long)1394132891);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-176469022 ^ (long)-176469052);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)144633221 ^ (long)144633189);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1624791937 ^ (long)-1624791945);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-879727070 ^ (long)-879726937);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1979488069 ^ (long)-1979488029);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-817612256 ^ (long)-817612154);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-31822131 ^ (long)-31822306);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1865724185 ^ (long)1865724399);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)224551990 ^ (long)224551962);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-300393307 ^ (long)-300393366);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1251232978 ^ (long)-1251232976);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-492366124 ^ (long)-492366097);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)480281869 ^ (long)480282024);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1624403514 ^ (long)1624403527);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1128701589 ^ (long)1128701537);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1747186430 ^ (long)-1747186279);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1830288572 ^ (long)-1830288605);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1622684811 ^ (long)-1622684768);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1170762388 ^ (long)1170762485);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)501383656 ^ (long)501383542);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-749238735 ^ (long)-749238705);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)68535495 ^ (long)68535424);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1700655769 ^ (long)-1700655634);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)13659856 ^ (long)13659701);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)961190805 ^ (long)961190740);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1632802275 ^ (long)1632802052);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-343699879 ^ (long)-343699930);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1771066767 ^ (long)1771066628);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1873267187 ^ (long)1873267146);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-783347851 ^ (long)-783347772);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1943780623 ^ (long)-1943780727);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1028386982 ^ (long)1028386909);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-677279261 ^ (long)-677279460);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)148445013 ^ (long)148445137);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1776097005 ^ (long)1776096879);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)459063289 ^ (long)459063123);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-2064176885 ^ (long)-2064176764);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)2092216784 ^ (long)2092216815);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1219919421 ^ (long)-1219919503);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-971023317 ^ (long)-971023209);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)2117753611 ^ (long)2117753764);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-160262998 ^ (long)-160263137);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1287400953 ^ (long)-1287400767);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-757090662 ^ (long)-757090745);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1292951283 ^ (long)-1292951078);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-558775128 ^ (long)-558775241);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1705090490 ^ (long)1705090446);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1236400570 ^ (long)-1236400465);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1140926453 ^ (long)1140926230);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-232815871 ^ (long)-232815635);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1908649846 ^ (long)-1908649785);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)2005088214 ^ (long)2005088035);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)676577893 ^ (long)676577996);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1279731036 ^ (long)1279730964);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1584525935 ^ (long)-1584525867);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)351425176 ^ (long)351425081);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1191144020 ^ (long)-1191143943);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-863257595 ^ (long)-863257511);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1540445817 ^ (long)-1540445783);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)213972470 ^ (long)213972346);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)463043599 ^ (long)463043752);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)357908682 ^ (long)357908684);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)2005860045 ^ (long)2005859868);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-77663033 ^ (long)-77663223);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)879480775 ^ (long)879480576);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-383306341 ^ (long)-383306368);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-407977106 ^ (long)-407977213);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1033104108 ^ (long)-1033104010);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1512703202 ^ (long)-1512703219);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1057494112 ^ (long)1057494265);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1443087697 ^ (long)-1443087642);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1520746478 ^ (long)-1520746342);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1341954577 ^ (long)-1341954802);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)637019788 ^ (long)637019661);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1727159416 ^ (long)-1727159465);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)317367837 ^ (long)317367816);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1159538293 ^ (long)-1159538345);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1685968116 ^ (long)1685967998);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-978157423 ^ (long)-978157340);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)52397879 ^ (long)52397824);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)2040302201 ^ (long)2040302098);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1605628269 ^ (long)1605628340);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-547389781 ^ (long)-547389780);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1461360255 ^ (long)1461360229);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)712660485 ^ (long)712660575);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1586819987 ^ (long)-1586820034);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1139784621 ^ (long)-1139784626);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1825314078 ^ (long)1825314086);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-632979556 ^ (long)-632979470);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)529436242 ^ (long)529436254);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1856327112 ^ (long)1856326928);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1424472630 ^ (long)1424472783);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1524572511 ^ (long)1524572617);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1219383693 ^ (long)-1219383800);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-79059559 ^ (long)-79059555);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)705469309 ^ (long)705469309);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1848956062 ^ (long)-1848955934);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)299840784 ^ (long)299840960);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-90797416 ^ (long)-90797525);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)97984762 ^ (long)97984593);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1794802300 ^ (long)1794802213);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-400528063 ^ (long)-400528107);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-930072 ^ (long)-930197);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1474258789 ^ (long)1474258798);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1669638359 ^ (long)1669638240);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-383370872 ^ (long)-383370948);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1059187717 ^ (long)1059187766);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-465776119 ^ (long)-465775943);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-625875414 ^ (long)-625875218);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1780464362 ^ (long)-1780464150);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1827525469 ^ (long)-1827525458);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1229157134 ^ (long)-1229157296);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)2051127153 ^ (long)2051127277);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)754416477 ^ (long)754416583);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)860409517 ^ (long)860409386);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1771932181 ^ (long)1771932333);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1619437491 ^ (long)1619437520);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1812635362 ^ (long)-1812635281);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-875656858 ^ (long)-875656772);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)140357194 ^ (long)140357367);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1239160632 ^ (long)-1239160620);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)2044930070 ^ (long)2044930148);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)2092476826 ^ (long)2092476922);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)655636131 ^ (long)655636165);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-247568377 ^ (long)-247568309);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1738814999 ^ (long)1738815085);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-488242957 ^ (long)-488242994);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1095867231 ^ (long)-1095867145);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1639480493 ^ (long)-1639480325);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-706667297 ^ (long)-706667492);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-2095734535 ^ (long)-2095734765);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-61372459 ^ (long)-61372589);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1393859229 ^ (long)1393859243);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1459413826 ^ (long)1459413983);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1275443807 ^ (long)-1275443828);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)958674579 ^ (long)958674527);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-61777457 ^ (long)-61777571);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-280356448 ^ (long)-280356527);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1287536166 ^ (long)-1287536176);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-523011667 ^ (long)-523011818);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1235698549 ^ (long)1235698657);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1442480732 ^ (long)1442480811);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1002649077 ^ (long)1002648875);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1286698124 ^ (long)1286698212);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-802377281 ^ (long)-802377312);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-512530685 ^ (long)-512530447);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1216581632 ^ (long)1216581699);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)884735548 ^ (long)884735524);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1461911592 ^ (long)-1461911636);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-976649106 ^ (long)-976649214);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1637439675 ^ (long)-1637439593);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1077079988 ^ (long)1077080047);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-421169160 ^ (long)-421169303);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1579237420 ^ (long)-1579237487);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1293073553 ^ (long)1293073615);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1984332336 ^ (long)1984332510);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-2024149602 ^ (long)-2024149522);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)1104426312 ^ (long)1104426263);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1969475466 ^ (long)-1969475392);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-2134004169 ^ (long)-2134004217);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-519816962 ^ (long)-519817079);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1611829716 ^ (long)1611829635);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)256009365 ^ (long)256009320);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1200161399 ^ (long)1200161511);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1790289979 ^ (long)-1790289994);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1325976322 ^ (long)1325976387);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1940689673 ^ (long)1940689752);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1661367794 ^ (long)1661367581);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1419092723 ^ (long)1419092664);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-703689209 ^ (long)-703688991);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1843936583 ^ (long)-1843936593);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)387081675 ^ (long)387081706);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)738052972 ^ (long)738053014);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)541438394 ^ (long)541438460);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1962492229 ^ (long)-1962492281);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)842601593 ^ (long)842601594);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1469343179 ^ (long)1469343196);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1694775970 ^ (long)1694775968);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-811898089 ^ (long)-811897944);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)281739249 ^ (long)281739232);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1348853889 ^ (long)1348853827);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-895132358 ^ (long)-895132299);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1952545522 ^ (long)1952545404);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1750995803 ^ (long)1750995836);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)760950411 ^ (long)760950302);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-155021445 ^ (long)-155021409);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)2086983453 ^ (long)2086983468);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)463195462 ^ (long)463195414);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1718237029 ^ (long)-1718237015);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1794496166 ^ (long)-1794496248);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)2120654933 ^ (long)2120654992);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1380456642 ^ (long)1380456674);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1247706487 ^ (long)-1247706484);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1680610611 ^ (long)1680610681);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1616040402 ^ (long)-1616040415);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)275952516 ^ (long)275952545);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-517676052 ^ (long)-517676203);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)713754320 ^ (long)713754284);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)2130178810 ^ (long)2130178564);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)848370439 ^ (long)848370603);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)2003757343 ^ (long)2003757349);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)497910573 ^ (long)497910601);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-908662936 ^ (long)-908662998);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-544464552 ^ (long)-544464618);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1381684054 ^ (long)1381684063);
                    if (!0w.\u2000\u2001) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1888416073 ^ (long)-1888416022);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-930238724 ^ (long)-930238973)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)462032128 ^ (long)462091007)) >>> (int)((long)-693615717 ^ (long)-693615725)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)410312535 ^ (long)410312535);
            if (!0w.\u2000\u2001) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-573299307 ^ (long)-573299305);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1558292354 ^ (long)1558292353) | var5_6 << (int)((long)825640207 ^ (long)825640202)) ^ var3_4[var7_8]) & (int)((long)1757108090 ^ (long)1757108101);
                    if (0w.\u2000\u2001) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1176625179 ^ (long)1176625176) | var6_7 << (int)((long)-1127940109 ^ (long)-1127940106)) ^ var3_4[var7_8]) & (int)((long)1597503268 ^ (long)1597503451);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0w.e[var2_3] = new String(var3_4).intern();
        }
        return 0w.e[var2_3];
    }

    public 0w() {
        boolean bl = \u2000\u2001;
        super(0w.b((int)((long)-27908780 ^ (long)-27888261), (int)((long)1661527909 ^ (long)1661524681)) /* "Velocity" */, 0w.b((int)((long)529786838 ^ (long)529774572), (int)((long)-1341019271 ^ (long)1340998679)) /* "Adjust your Velocity" */);
        Constable constable = (int)((long)25998399 ^ (long)25998399);
        34J j2 = ((34e)((34e)((34e)this.1().5(0w.b((int)((long)1522257767 ^ (long)1522245461), (int)((long)-953016009 ^ (long)-952996656)) /* "Horizontal" */)).7(0w.b((int)((long)-1811386198 ^ (long)-1811406705), (int)((long)-826793578 ^ (long)826771520)) /* "hamt" */)).1(0w.b((int)((long)1987562511 ^ (long)1987550268), (int)((long)-251630433 ^ (long)251637325)) /* "Percentage of horizontal (X/Z) knockback taken\\n0% = no knockback, 100% = full knockback" */)).3((int)((long)431829133 ^ (long)431829133)).2((int)((long)1306554927 ^ (long)1306554955));
        ((34e)((34e)((34e)this.1().5(0w.b((int)((long)1522257767 ^ (long)1522245461), (int)((long)-953016009 ^ (long)-952996656)) /* "Horizontal" */)).7(0w.b((int)((long)-1811386198 ^ (long)-1811406705), (int)((long)-826793578 ^ (long)826771520)) /* "hamt" */)).1(0w.b((int)((long)1987562511 ^ (long)1987550268), (int)((long)-251630433 ^ (long)251637325)) /* "Percentage of horizontal (X/Z) knockback taken\\n0% = no knockback, 100% = full knockback" */)).3((int)((long)431829133 ^ (long)431829133)).2((int)((long)1306554927 ^ (long)1306554955)).7 = constable;
        this.2 = (1z)j2.5();
        constable = Float.valueOf(1.0f);
        j2 = ((34e)((34e)((34e)this.9().5(0w.b((int)((long)2110736250 ^ (long)2110723927), (int)((long)-281411189 ^ (long)281384116)) /* "HMultiplier" */)).7(0w.b((int)((long)1997976611 ^ (long)1997988883), (int)((long)-1829187610 ^ (long)1829204087)) /* "hmultiplier" */)).1(0w.b((int)((long)-962138221 ^ (long)-962150494), (int)((long)-1057462930 ^ (long)1057475678)) /* "A multiplier on top of the knockback taken" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(5.0f));
        ((34e)((34e)((34e)this.9().5(0w.b((int)((long)2110736250 ^ (long)2110723927), (int)((long)-281411189 ^ (long)281384116)) /* "HMultiplier" */)).7(0w.b((int)((long)1997976611 ^ (long)1997988883), (int)((long)-1829187610 ^ (long)1829204087)) /* "hmultiplier" */)).1(0w.b((int)((long)-962138221 ^ (long)-962150494), (int)((long)-1057462930 ^ (long)1057475678)) /* "A multiplier on top of the knockback taken" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(5.0f)).7 = constable;
        this.5 = (1A)j2.5();
        constable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0w.b((int)((long)-873660045 ^ (long)-873639592), (int)((long)-1217057800 ^ (long)1217052833)))).7(0w.b((int)((long)-480078793 ^ (long)-480066543), (int)((long)-1080605840 ^ (long)1080610726)) /* "hreverse" */)).1(0w.b((int)((long)-1983759466 ^ (long)-1983747145), (int)((long)-791191993 ^ (long)-791197939)) /* "Inverts the knockback direction" */);
        ((34X)((34X)((34X)this.4().5(0w.b((int)((long)-873660045 ^ (long)-873639592), (int)((long)-1217057800 ^ (long)1217052833)))).7(0w.b((int)((long)-480078793 ^ (long)-480066543), (int)((long)-1080605840 ^ (long)1080610726)) /* "hreverse" */)).1(0w.b((int)((long)-1983759466 ^ (long)-1983747145), (int)((long)-791191993 ^ (long)-791197939)) /* "Inverts the knockback direction" */)).7 = constable;
        this.1 = (1P)((34X)j2).5();
        constable = (int)((long)-197231688 ^ (long)-197231688);
        j2 = ((34e)((34e)((34e)this.1().5(0w.b((int)((long)-69685089 ^ (long)-69672779), (int)((long)-1361789741 ^ (long)-1361777080)) /* "Vertical" */)).7(0w.b((int)((long)1473047517 ^ (long)1473035242), (int)((long)104396170 ^ (long)-104371357)) /* "vamt" */)).1(0w.b((int)((long)-901292215 ^ (long)-901312654), (int)((long)533574616 ^ (long)533565709)) /* "Percentage of vertical (Y) knockback taken\\n0% = no knockback, 100% = full knockback" */)).3((int)((long)876561034 ^ (long)876561034)).2((int)((long)684938838 ^ (long)684938802));
        ((34e)((34e)((34e)this.1().5(0w.b((int)((long)-69685089 ^ (long)-69672779), (int)((long)-1361789741 ^ (long)-1361777080)) /* "Vertical" */)).7(0w.b((int)((long)1473047517 ^ (long)1473035242), (int)((long)104396170 ^ (long)-104371357)) /* "vamt" */)).1(0w.b((int)((long)-901292215 ^ (long)-901312654), (int)((long)533574616 ^ (long)533565709)) /* "Percentage of vertical (Y) knockback taken\\n0% = no knockback, 100% = full knockback" */)).3((int)((long)876561034 ^ (long)876561034)).2((int)((long)684938838 ^ (long)684938802)).7 = constable;
        this.8 = (1z)j2.5();
        constable = Float.valueOf(1.0f);
        j2 = ((34e)((34e)((34e)this.9().5(0w.b((int)((long)-2097558382 ^ (long)-2097570634), (int)((long)-697469116 ^ (long)697497546)) /* "VMultiplier" */)).7(0w.b((int)((long)1927178307 ^ (long)1927166076), (int)((long)2103797860 ^ (long)2103775081)) /* "vmultiplier" */)).1(0w.b((int)((long)-701552895 ^ (long)-701532353), (int)((long)217920248 ^ (long)217934925)))).3(Float.valueOf(1.0f)).2(Float.valueOf(5.0f));
        ((34e)((34e)((34e)this.9().5(0w.b((int)((long)-2097558382 ^ (long)-2097570634), (int)((long)-697469116 ^ (long)697497546)) /* "VMultiplier" */)).7(0w.b((int)((long)1927178307 ^ (long)1927166076), (int)((long)2103797860 ^ (long)2103775081)) /* "vmultiplier" */)).1(0w.b((int)((long)-701552895 ^ (long)-701532353), (int)((long)217920248 ^ (long)217934925)))).3(Float.valueOf(1.0f)).2(Float.valueOf(5.0f)).7 = constable;
        this.9S = (1A)((34e)j2).5();
        constable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0w.b((int)((long)-728476385 ^ (long)-728496835), (int)((long)639130461 ^ (long)639118096)) /* "Reverse" */)).7(0w.b((int)((long)-1930801147 ^ (long)-1930821571), (int)((long)-539631098 ^ (long)-539631817)) /* "vreverse" */)).1(0w.b((int)((long)-1460300388 ^ (long)-1460288087), (int)((long)1188154471 ^ (long)-1188161279)));
        ((34X)((34X)((34X)this.4().5(0w.b((int)((long)-728476385 ^ (long)-728496835), (int)((long)639130461 ^ (long)639118096)) /* "Reverse" */)).7(0w.b((int)((long)-1930801147 ^ (long)-1930821571), (int)((long)-539631098 ^ (long)-539631817)) /* "vreverse" */)).1(0w.b((int)((long)-1460300388 ^ (long)-1460288087), (int)((long)1188154471 ^ (long)-1188161279)))).7 = constable;
        this.9 = (1P)((34X)j2).5();
        constable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0w.b((int)((long)649077894 ^ (long)649098418), (int)((long)-478869856 ^ (long)478850627)) /* "Explosions" */)).7(0w.b((int)((long)646714897 ^ (long)646727213), (int)((long)-781721818 ^ (long)-781743392)) /* "explosions" */)).1(0w.b((int)((long)711596192 ^ (long)711608460), (int)((long)1828162402 ^ (long)1828170084)) /* "Toggle explosive knockback on/off" */);
        ((34X)((34X)((34X)this.4().5(0w.b((int)((long)649077894 ^ (long)649098418), (int)((long)-478869856 ^ (long)478850627)) /* "Explosions" */)).7(0w.b((int)((long)646714897 ^ (long)646727213), (int)((long)-781721818 ^ (long)-781743392)) /* "explosions" */)).1(0w.b((int)((long)711596192 ^ (long)711608460), (int)((long)1828162402 ^ (long)1828170084)) /* "Toggle explosive knockback on/off" */)).7 = constable;
        this.4 = (1P)((34X)j2).5();
        constable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(0w.b((int)((long)-617170984 ^ (long)-617158664), (int)((long)-1035327466 ^ (long)1035335123)) /* "Damage Fix" */)).7(0w.b((int)((long)-795443779 ^ (long)-795464301), (int)((long)277219167 ^ (long)277232490)) /* "damagefix" */)).1(0w.b((int)((long)1400168935 ^ (long)1400156625), (int)((long)-358943048 ^ (long)358971702)) /* "Prevents slowing down when receiving damage" */);
        ((34X)((34X)((34X)this.4().5(0w.b((int)((long)-617170984 ^ (long)-617158664), (int)((long)-1035327466 ^ (long)1035335123)) /* "Damage Fix" */)).7(0w.b((int)((long)-795443779 ^ (long)-795464301), (int)((long)277219167 ^ (long)277232490)) /* "damagefix" */)).1(0w.b((int)((long)1400168935 ^ (long)1400156625), (int)((long)-358943048 ^ (long)358971702)) /* "Prevents slowing down when receiving damage" */)).7 = constable;
        this.6 = (1P)((34X)j2).5();
        constable = (int)((long)-2087783553 ^ (long)-2087783653);
        j2 = ((34e)((34e)((34e)this.1().5(0w.b((int)((long)-1804326607 ^ (long)-1804306164), (int)((long)2012155082 ^ (long)-2012175273)) /* "Chance" */)).7(0w.b((int)((long)1055275649 ^ (long)1055287992), (int)((long)-1995362347 ^ (long)-1995355697)) /* "pchance" */)).1(0w.b((int)((long)1976707973 ^ (long)1976728492), (int)((long)-335134686 ^ (long)-335134727)) /* "The chance, as a percent, of the velocity change actually applying\\n100 = always\\n0 = never" */)).3((int)((long)1078883179 ^ (long)1078883179)).2((int)((long)-1163645682 ^ (long)-1163645590));
        ((34e)((34e)((34e)this.1().5(0w.b((int)((long)-1804326607 ^ (long)-1804306164), (int)((long)2012155082 ^ (long)-2012175273)) /* "Chance" */)).7(0w.b((int)((long)1055275649 ^ (long)1055287992), (int)((long)-1995362347 ^ (long)-1995355697)) /* "pchance" */)).1(0w.b((int)((long)1976707973 ^ (long)1976728492), (int)((long)-335134686 ^ (long)-335134727)) /* "The chance, as a percent, of the velocity change actually applying\\n100 = always\\n0 = never" */)).3((int)((long)1078883179 ^ (long)1078883179)).2((int)((long)-1163645682 ^ (long)-1163645590)).7 = constable;
        this.0 = (1z)((34e)j2).5();
        this.9z = new Listener(sh -> {
            block3: {
                block2: {
                    boolean bl = \u2000\u2001;
                    if (bl || bl) break block2;
                    2R.1(this, 0w.b((int)((long)1750442224 ^ (long)1750462675), (int)((long)1456518463 ^ (long)1456530041)) /* "suffix" */, this.2.4 + 0w.b((int)((long)-1536353852 ^ (long)-1536341524), (int)((long)1218814245 ^ (long)1218810804)) /* "% " */ + this.8.4 + 2w$6X.KAOZ("\uc6da", -1158946676));
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)1827322169 ^ (long)1827322169)]);
        Predicate[] predicateArray = new Predicate[(int)((long)241050172 ^ (long)241050173)];
        Class[] classArray = new Class[(int)((long)-758953062 ^ (long)-758953064)];
        classArray[(int)((long)-611109624 ^ (long)-611109624)] = rc.class;
        classArray[(int)((long)-593078243 ^ (long)-593078244)] = po.class;
        predicateArray[(int)((long)1452477493 ^ (long)1452477493)] = new 34s(classArray);
        this.7 = new Listener(object -> {
            int n;
            int n2;
            boolean bl = \u2000\u2001;
            if (bl || bl) return;
            if (((3i)((Object)((Object)object))).2 != EventState.PRE) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            if (new Random().nextInt((int)((long)1116419961 ^ (long)1116419869)) >= this.0.4) {
                if (bl || bl) return;
                return;
            }
            if (bl) {
                return;
            }
            float f = (float)this.2.4 / 100.0f * this.5.9;
            if (this.1.2) {
                n2 = (int)((long)61668329 ^ (long)-61668330);
                if (\u2000\u2001) {
                    throw null;
                }
            } else {
                n2 = (int)((long)1937202085 ^ (long)1937202084);
            }
            float f2 = f * (float)n2;
            float f3 = (float)this.8.4 / 100.0f * this.9S.9;
            if (this.9.2) {
                n = (int)((long)2123774117 ^ (long)-2123774118);
                if (\u2000\u2001) {
                    throw null;
                }
            } else {
                n = (int)((long)1321985938 ^ (long)1321985939);
            }
            float f4 = f3 * (float)n;
            if (((3u)((Object)((Object)object))).7 instanceof rc) {
                object = (AccessorSEntityVelocityPacket)((3u)((Object)((Object)object))).7;
                if (object.getEntityID() != 0w.3.s.Y()) return;
                object.setMotionX((int)0w.9(0w.3.s.cC().b * 8000.0, object.getMotionX(), f2));
                object.setMotionY((int)0w.9(0w.3.s.cC().c * 8000.0, object.getMotionY(), f4));
                object.setMotionZ((int)0w.9(0w.3.s.cC().d * 8000.0, object.getMotionZ(), f2));
                return;
            }
            if (!(((3u)((Object)((Object)object))).7 instanceof po) || this.4.2) return;
            object = (AccessorSExplosionPacket)((3u)((Object)((Object)object))).7;
            object.setMotionX(object.getMotionX() * f2);
            Object object2 = object;
            object2.setMotionY(object2.getMotionY() * f4);
            Object object3 = object;
            object3.setMotionZ(object3.getMotionZ() * f2);
        }, predicateArray);
    }

    private static double 9(double d2, double d3, double d4) {
        boolean bl = \u2000\u2001;
        if (bl || bl) {
            return 0.0;
        }
        return d2 + (d3 - d2) * d4;
    }
}

