/* ==========================================================================
 * MODULE: Crystal Aura
 * CATEGORY (inferred): Combat
 * DESCRIPTION: Automatically destroys end crystals near the client player
 * OBFUSCATED CLASS: net.impactclient.3c
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  aot
 *  api
 *  apk
 *  apw
 *  aqa
 *  aqm
 *  arl
 *  bbq
 *  bfw
 *  bmb
 *  bmd
 *  bpu
 *  brf
 *  brf$a
 *  brf$b
 *  brp
 *  brp$a
 *  brx
 *  bup
 *  ceh
 *  dci
 *  dcj
 *  dcl$a
 *  dcn
 *  dzm
 *  fx
 *  gc
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  oj
 *  pw.knx.feather.structures.Color
 *  tj
 *  ts
 */
package net.impactclient;

import clientapi.load.mixin.7.2;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.11;
import net.impactclient.1A;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.1R;
import net.impactclient.2c;
import net.impactclient.2n;
import net.impactclient.2o;
import net.impactclient.2w$6X;
import net.impactclient.34E;
import net.impactclient.34H;
import net.impactclient.34J;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.38;
import net.impactclient.3X;
import net.impactclient.3a;
import net.impactclient.3e;
import net.impactclient.4X;
import net.impactclient.56;
import net.impactclient.5z;
import net.impactclient.66;
import net.impactclient.6L;
import net.impactclient.8H;
import net.impactclient.9V;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3c
extends 3X
implements 56 {
    private 1R 5;
    private 1A 6;
    private 1A 9f;
    private static final String[] e;
    @EventHandler
    private final Listener<4X> 9t;
    private 1P 9E;
    @EventHandler
    private final Listener<2o> 0;
    public static final boolean \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
    private 1P 8;
    private static final String[] d;
    private bbq 9c;
    private 1R 4;
    private 1P 2;
    private final 8H 1;
    private 11 92;
    private fx 9;
    private 1K 7;

    /*
     * Enabled aggressive block sorting
     */
    private boolean 9(fx fx2) {
        boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
        if (bl || bl) return true;
        aot aot2 = 3c.1().orElse(null);
        if (aot2 == null) {
            if (bl || bl) return true;
            return (int)((long)-1449480770 ^ (long)-1449480770) != 0;
        }
        if (bl) return true;
        ceh ceh2 = 3c.3.r.d_(fx2);
        if (ceh2.b() != bup.bK) {
            if (bl) return true;
            if (ceh2.b() != bup.z) {
                if (bl || bl) return true;
                return (int)((long)-1993261021 ^ (long)-1993261021) != 0;
            }
        }
        if (bl) return true;
        ceh2 = fx2.b();
        if (bl || bl) return true;
        aot2 = 3c.3.s.b(aot2);
        if (bl || bl) return true;
        if (!3c.3.s.a((fx)ceh2, 3c.6(fx2), (bmb)aot2)) {
            if (bl || bl) return true;
            return (int)((long)312148180 ^ (long)312148180) != 0;
        }
        if (bl) return true;
        if (3c.3.r.w((fx)ceh2)) {
            if (bl) return true;
            if (3c.3.r.a(null, new dci((fx)ceh2).b(0.0, 1.0, 0.0)).isEmpty()) {
                if (bl) return true;
                return (int)((long)-1641361825 ^ (long)-1641361826) != 0;
            }
        }
        if (!bl) return (int)((long)1952379932 ^ (long)1952379932) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Optional<Integer> 9() {
        boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
        if (bl || bl) return null;
        if (3c.3.s.bm.a(3c.3.s.bm.d).b() == bmd.qc) {
            if (bl || bl) return null;
            return Optional.of(3c.3.s.bm.d);
        }
        if (bl) return null;
        int n = (int)((long)1213474825 ^ (long)1213474825);
        if (bl) return null;
        while (!bl) {
            if (n < (int)((long)1311112012 ^ (long)1311112005)) {
                if (bl || bl) return null;
                if (3c.3.s.bm.a(n).b() == bmd.qc) {
                    if (bl || bl) return null;
                    return Optional.of(n);
                }
                if (bl) return null;
                ++n;
                if (bl) return null;
                if (!\u2003\u2006\u2000\u200f\u2001\u2005\u2002) continue;
                throw null;
            }
            if (!bl) return Optional.empty();
        }
        return null;
    }

    private static float 9(dcn dcn2, aqm aqm2) {
        boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
        if (bl || bl) {
            return 0.0f;
        }
        return 3c.4(dcn2.b, dcn2.c, dcn2.d, aqm2);
    }

    /*
     * Enabled aggressive block sorting
     */
    private static float 8(float f) {
        float f2;
        boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
        if (bl || bl) return 0.0f;
        int n = 3c.3.r.ad().a();
        if (bl || bl) {
            return 0.0f;
        }
        if (n == 0) {
            f2 = 0.0f;
            if (!\u2003\u2006\u2000\u200f\u2001\u2005\u2002) return f * f2;
            throw null;
        } else if (n == (int)((long)229905088 ^ (long)229905090)) {
            f2 = 1.0f;
            if (!\u2003\u2006\u2000\u200f\u2001\u2005\u2002) return f * f2;
            throw null;
        } else if (n == (int)((long)1917581748 ^ (long)1917581749)) {
            f2 = 0.5f;
            if (!\u2003\u2006\u2000\u200f\u2001\u2005\u2002) return f * f2;
            throw null;
        } else {
            f2 = 1.5f;
        }
        return f * f2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static Optional<aot> 1() {
        block5: {
            boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
            if (!bl && !bl) {
                aot[] aotArray = aot.values();
                int n2 = aotArray.length;
                if (!bl) {
                    int n3 = (int)((long)-536245503 ^ (long)-536245503);
                    if (bl) return null;
                    while (!bl) {
                        if (n3 < n2) {
                            if (bl) break;
                            aot aot2 = aotArray[n3];
                            if (bl || bl) break;
                            if (3c.3.s.b(aot2).b() == bmd.qc) {
                                if (bl || bl) break;
                                return Optional.of(aot2);
                            }
                            if (bl) break;
                            ++n3;
                            if (bl) break;
                            if (!\u2003\u2006\u2000\u200f\u2001\u2005\u2002) continue;
                            throw null;
                        }
                        if (!bl) break block5;
                    }
                }
            }
            return null;
        }
        return 3c.9().map(n -> {
            boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
            if (bl || bl) {
                return null;
            }
            return aot.a;
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static float 6(aqm aqm2, float f, brp brp2) {
        boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
        if (bl || bl) return 0.0f;
        if (aqm2 instanceof bfw) {
            float f2;
            block8: {
                if (bl || bl) return 0.0f;
                bfw bfw2 = (bfw)aqm2;
                if (bl || bl) return 0.0f;
                brp2 = apk.a((brp)brp2);
                if (bl || bl) return 0.0f;
                f = api.a((float)f, (float)bfw2.du(), (float)((float)bfw2.a(arl.j).f()));
                if (bl || bl) return 0.0f;
                float f3 = afm.a((float)bpu.a((Iterable)bfw2.bo(), (apk)brp2), (float)0.0f, (float)20.0f);
                if (bl || bl) return 0.0f;
                f *= 1.0f - f3 / 25.0f;
                if (bl || bl) return 0.0f;
                if (aqm2.a(apw.k)) {
                    if (bl || bl) return 0.0f;
                    float f4 = f;
                    f = f4 - f4 / 4.0f;
                    if (bl) return 0.0f;
                }
                if (bl) return 0.0f;
                f2 = 0.0f;
                if (bl) return 0.0f;
                try {
                    if (bl) return 0.0f;
                    f2 = bfw2.dT();
                    if (bl || bl) return 0.0f;
                    if (!\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break block8;
                    throw null;
                }
                catch (Exception exception) {
                    if (bl) return 0.0f;
                }
            }
            if (bl) return 0.0f;
            return Math.max(f - f2, 0.0f);
        }
        if (!bl) return api.a((float)f, (float)aqm2.du(), (float)((float)aqm2.a(arl.j).f()));
        return 0.0f;
    }

    public 3c() {
        boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
        super(3c.b((int)((long)1536561409 ^ (long)1536570088), (int)((long)-1405906471 ^ (long)-1405902722)) /* "Crystal Aura" */, 3c.b((int)((long)692598887 ^ (long)692591500), (int)((long)-1689976776 ^ (long)-1689947508)) /* "Automatically destroys end crystals near the client player" */);
        Object object = Float.valueOf(12.0f);
        34J j2 = ((34e)((34e)((34e)this.9().5(3c.b((int)((long)1578691881 ^ (long)1578684135), (int)((long)86559792 ^ (long)86565631)) /* "APS" */)).7(3c.b((int)((long)-921212898 ^ (long)-921220104), (int)((long)890894977 ^ (long)-890879756)) /* "speed" */)).1(3c.b((int)((long)-50218724 ^ (long)-50226436), (int)((long)-1906915613 ^ (long)-1906921386)) /* "Amount of attacks that are inflicted each second" */)).3(Float.valueOf(5.0f)).2(Float.valueOf(20.0f));
        ((34e)((34e)((34e)this.9().5(3c.b((int)((long)1578691881 ^ (long)1578684135), (int)((long)86559792 ^ (long)86565631)) /* "APS" */)).7(3c.b((int)((long)-921212898 ^ (long)-921220104), (int)((long)890894977 ^ (long)-890879756)) /* "speed" */)).1(3c.b((int)((long)-50218724 ^ (long)-50226436), (int)((long)-1906915613 ^ (long)-1906921386)) /* "Amount of attacks that are inflicted each second" */)).3(Float.valueOf(5.0f)).2(Float.valueOf(20.0f)).7 = object;
        this.6 = (1A)j2.5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(3c.b((int)((long)-1750966557 ^ (long)-1750958832), (int)((long)-523231702 ^ (long)-523210945)) /* "Placement" */)).7(3c.b((int)((long)-993281020 ^ (long)-993288217), (int)((long)1191261059 ^ (long)-1191268608)) /* "placement" */)).1(3c.b((int)((long)1323466043 ^ (long)1323458247), (int)((long)-72304864 ^ (long)72304069)) /* "Place crystals" */);
        ((34X)((34X)((34X)this.4().5(3c.b((int)((long)-1750966557 ^ (long)-1750958832), (int)((long)-523231702 ^ (long)-523210945)) /* "Placement" */)).7(3c.b((int)((long)-993281020 ^ (long)-993288217), (int)((long)1191261059 ^ (long)-1191268608)) /* "placement" */)).1(3c.b((int)((long)1323466043 ^ (long)1323458247), (int)((long)-72304864 ^ (long)72304069)) /* "Place crystals" */)).7 = object;
        this.8 = (1P)((34X)j2).5();
        object = 4.5;
        j2 = ((34e)((34e)((34e)this.7().5(3c.b((int)((long)1446839693 ^ (long)1446848124), (int)((long)-404613402 ^ (long)404602728)) /* "Range" */)).7(3c.b((int)((long)2083963807 ^ (long)2083971168), (int)((long)2084307197 ^ (long)2084335585)) /* "range" */)).1(3c.b((int)((long)-1399197388 ^ (long)-1399205125), (int)((long)1068642773 ^ (long)1068654987)) /* "Distance that targets will be attacked from" */)).3(2.0).2(6.0);
        ((34e)((34e)((34e)this.7().5(3c.b((int)((long)1446839693 ^ (long)1446848124), (int)((long)-404613402 ^ (long)404602728)) /* "Range" */)).7(3c.b((int)((long)2083963807 ^ (long)2083971168), (int)((long)2084307197 ^ (long)2084335585)) /* "range" */)).1(3c.b((int)((long)-1399197388 ^ (long)-1399205125), (int)((long)1068642773 ^ (long)1068654987)) /* "Distance that targets will be attacked from" */)).3(2.0).2(6.0).7 = object;
        this.7 = (1K)j2.5();
        object = Float.valueOf(360.0f);
        j2 = ((34e)((34e)((34e)this.9().5(3c.b((int)((long)-1578070873 ^ (long)-1578062007), (int)((long)-869367692 ^ (long)-869350229)) /* "FOV" */)).7(3c.b((int)((long)1339423010 ^ (long)1339415235), (int)((long)-1211042820 ^ (long)1211047075)) /* "fov" */)).1(3c.b((int)((long)352472479 ^ (long)352480887), (int)((long)362596009 ^ (long)362601242)) /* "FOV that entities must be in to be targeted" */)).3(Float.valueOf(10.0f)).2(Float.valueOf(360.0f));
        ((34e)((34e)((34e)this.9().5(3c.b((int)((long)-1578070873 ^ (long)-1578062007), (int)((long)-869367692 ^ (long)-869350229)) /* "FOV" */)).7(3c.b((int)((long)1339423010 ^ (long)1339415235), (int)((long)-1211042820 ^ (long)1211047075)) /* "fov" */)).1(3c.b((int)((long)352472479 ^ (long)352480887), (int)((long)362596009 ^ (long)362601242)) /* "FOV that entities must be in to be targeted" */)).3(Float.valueOf(10.0f)).2(Float.valueOf(360.0f)).7 = object;
        this.9f = (1A)((34e)j2).5();
        String[] stringArray = new String[(int)((long)-499812629 ^ (long)-499812632)];
        stringArray[(int)((long)1888518727 ^ (long)1888518727)] = 3c.b((int)((long)1240947569 ^ (long)1240955014), (int)((long)383094106 ^ (long)-383102591));
        stringArray[(int)((long)348098633 ^ (long)348098632)] = 3c.b((int)((long)1336444809 ^ (long)1336452211), (int)((long)1590523173 ^ (long)1590493855)) /* "Place" */;
        stringArray[(int)((long)2137074650 ^ (long)2137074648)] = 3c.b((int)((long)369785896 ^ (long)369778652), (int)((long)1181823723 ^ (long)-1181830911));
        object = stringArray;
        j2 = (34H)((34H)((34H)this.0().5(3c.b((int)((long)790758042 ^ (long)790765922), (int)((long)694031160 ^ (long)-694050076)) /* "Suicide" */)).7(3c.b((int)((long)-2103944537 ^ (long)-2103936701), (int)((long)937224368 ^ (long)937199489)) /* "suicide" */)).1(3c.b((int)((long)-568093461 ^ (long)-568084729), (int)((long)-1709748773 ^ (long)1709751018)) /* "How crystals that could potentially kill you shall be acknowledged\\nAvoid = Don't do anything that could kill you\\nPlace = Place crystals that could kill you\\nCommit = Place and hit crystals that could kill you" */);
        ((34H)((34H)((34H)this.0().5(3c.b((int)((long)790758042 ^ (long)790765922), (int)((long)694031160 ^ (long)-694050076)) /* "Suicide" */)).7(3c.b((int)((long)-2103944537 ^ (long)-2103936701), (int)((long)937224368 ^ (long)937199489)) /* "suicide" */)).1(3c.b((int)((long)-568093461 ^ (long)-568084729), (int)((long)-1709748773 ^ (long)1709751018)) /* "How crystals that could potentially kill you shall be acknowledged\\nAvoid = Don't do anything that could kill you\\nPlace = Place crystals that could kill you\\nCommit = Place and hit crystals that could kill you" */)).3 = object;
        this.92 = (11)j2.5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(3c.b((int)((long)-1440141282 ^ (long)-1440148484), (int)((long)1473728212 ^ (long)-1473740296)) /* "Draw Outline" */)).7(3c.b((int)((long)-1872502680 ^ (long)-1872510050), (int)((long)1788674508 ^ (long)-1788706336)) /* "render" */)).1(3c.b((int)((long)-709630202 ^ (long)-709638932), (int)((long)-664754464 ^ (long)664758552)) /* "Draw an outline where we plan to place or set off crystals" */);
        ((34X)((34X)((34X)this.4().5(3c.b((int)((long)-1440141282 ^ (long)-1440148484), (int)((long)1473728212 ^ (long)-1473740296)) /* "Draw Outline" */)).7(3c.b((int)((long)-1872502680 ^ (long)-1872510050), (int)((long)1788674508 ^ (long)-1788706336)) /* "render" */)).1(3c.b((int)((long)-709630202 ^ (long)-709638932), (int)((long)-664754464 ^ (long)664758552)) /* "Draw an outline where we plan to place or set off crystals" */)).7 = object;
        this.9E = (1P)((34X)j2).5();
        object = pw.knx.feather.structures.Color.fromHex((int)Color.GREEN.getRGB());
        j2 = (34E)((34E)((34E)this.0().5(3c.b((int)((long)622949390 ^ (long)622942177), (int)((long)804570949 ^ (long)804579899)) /* "Place Color" */)).7(3c.b((int)((long)-1719458173 ^ (long)-1719466627), (int)((long)-90379245 ^ (long)-90401466)) /* "placeColor" */)).1(3c.b((int)((long)-1072541516 ^ (long)-1072532655), (int)((long)-534658284 ^ (long)-534666575)) /* "The color to outline blocks we plan to place crystals on" */);
        ((34E)((34E)((34E)this.0().5(3c.b((int)((long)622949390 ^ (long)622942177), (int)((long)804570949 ^ (long)804579899)) /* "Place Color" */)).7(3c.b((int)((long)-1719458173 ^ (long)-1719466627), (int)((long)-90379245 ^ (long)-90401466)) /* "placeColor" */)).1(3c.b((int)((long)-1072541516 ^ (long)-1072532655), (int)((long)-534658284 ^ (long)-534666575)) /* "The color to outline blocks we plan to place crystals on" */)).7 = object;
        this.5 = (1R)((34E)((34E)j2).3(this.9E)).5();
        object = pw.knx.feather.structures.Color.fromHex((int)Color.RED.getRGB());
        j2 = (34E)((34E)((34E)this.0().5(3c.b((int)((long)-2142805817 ^ (long)-2142813398), (int)((long)151018404 ^ (long)-151022676)) /* "Trigger Color" */)).7(3c.b((int)((long)1000348388 ^ (long)1000356118), (int)((long)-1453992482 ^ (long)1454009966)) /* "triggerColor" */)).1(3c.b((int)((long)5818717 ^ (long)5827258), (int)((long)-1947008631 ^ (long)1946986250)) /* "The color to outline crystals we plan to set off" */);
        ((34E)((34E)((34E)this.0().5(3c.b((int)((long)-2142805817 ^ (long)-2142813398), (int)((long)151018404 ^ (long)-151022676)) /* "Trigger Color" */)).7(3c.b((int)((long)1000348388 ^ (long)1000356118), (int)((long)-1453992482 ^ (long)1454009966)) /* "triggerColor" */)).1(3c.b((int)((long)5818717 ^ (long)5827258), (int)((long)-1947008631 ^ (long)1946986250)) /* "The color to outline crystals we plan to set off" */)).7 = object;
        this.4 = (1R)((34E)((34E)j2).3(this.9E)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(3c.b((int)((long)536020587 ^ (long)536028562), (int)((long)842752490 ^ (long)-842747011)) /* "Anti Weakness" */)).7(3c.b((int)((long)1248416031 ^ (long)1248424676), (int)((long)-1633537329 ^ (long)-1633546578)) /* "antiweakness" */)).1(3c.b((int)((long)-1921624167 ^ (long)-1921616796), (int)((long)1385552662 ^ (long)1385537504)) /* "Set off crystals with a sword if the player has the weakness effect" */);
        ((34X)((34X)((34X)this.4().5(3c.b((int)((long)536020587 ^ (long)536028562), (int)((long)842752490 ^ (long)-842747011)) /* "Anti Weakness" */)).7(3c.b((int)((long)1248416031 ^ (long)1248424676), (int)((long)-1633537329 ^ (long)-1633546578)) /* "antiweakness" */)).1(3c.b((int)((long)-1921624167 ^ (long)-1921616796), (int)((long)1385552662 ^ (long)1385537504)) /* "Set off crystals with a sword if the player has the weakness effect" */)).7 = object;
        this.2 = (1P)((34X)j2).5();
        this.1 = new 8H();
        this.0 = new Listener(o -> {
            boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
            if (bl || bl) return;
            if (!this.9E.2) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            if (this.9c != null) {
                if (bl || bl) return;
                3c.0(this.9c.cc(), this.4.2);
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            if (this.9 != null) {
                if (bl || bl) return;
                3c.0(new dci(0.0, 0.0, 0.0, 1.0, 1.0, 1.0).c(new dcn((double)this.9.u(), (double)this.9.v(), (double)this.9.w())), this.5.2);
                if (bl || bl) return;
                return;
            }
            if (!bl) return;
        }, new Predicate[(int)((long)1479561784 ^ (long)1479561784)]);
        this.9t = new Listener(x2 -> {
            boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
            if (bl) return;
            String[] stringArray = 3e.5();
            if (bl || bl) return;
            switch (3a.4[x2.7.ordinal()]) {
                case 1: {
                    fx fx2;
                    Object object;
                    if (bl) return;
                    this.9c = 6L.3(3c.3.r).filter(bbq.class::isInstance).filter(aqa2 -> {
                        boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
                        if (bl || bl) return true;
                        if ((double)aqa2.g((aqa)3c.3.s) < this.7.1) {
                            if (bl) return true;
                            if (66.3(aqa2) <= (double)(this.9f.9 / 2.0f)) {
                                if (bl) return true;
                                return (int)((long)-579699135 ^ (long)-579699136) != 0;
                            }
                        }
                        if (!bl) return (int)((long)-926072176 ^ (long)-926072176) != 0;
                        return true;
                    }).filter(aqa2 -> {
                        boolean bl;
                        block8: {
                            block7: {
                                bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
                                if (bl || bl) return true;
                                if (((String)this.92.0()).equals(3c.b((int)((long)1078459785 ^ (long)1078451833), (int)((long)1489408546 ^ (long)1489406828)) /* "Commit" */)) break block7;
                                if (bl) return true;
                                if ((double)(3c.3.s.dk() - 3c.9(aqa2.cA(), (aqm)3c.3.s)) <= 0.5) break block8;
                                if (bl) return true;
                            }
                            if (bl) return true;
                            return (int)((long)1522140807 ^ (long)1522140806) != 0;
                        }
                        if (!bl) return (int)((long)-1402172415 ^ (long)-1402172415) != 0;
                        return true;
                    }).min(Comparator.comparingDouble(arg_0 -> ((dzm)3c.3.s).g(arg_0))).orElse(null);
                    if (bl || bl) return;
                    if (this.9c != null) {
                        if (bl || bl) return;
                        9V v = 66.3(((2)this.9c).getPos().7(0.0, (double)this.9c.cz() * 0.75, 0.0));
                        if (bl || bl) return;
                        x2.6(v.6).2(v.3);
                        if (bl || bl) return;
                        return;
                    }
                    if (bl) {
                        return;
                    }
                    if (this.8.2 && 3c.1().isPresent()) {
                        object = this;
                        double d2 = ((3c)object).7.1;
                        dzm dzm2 = 3c.3.s;
                        ArrayList<fx> arrayList = new ArrayList<fx>();
                        int n = (int)dzm2.cD();
                        int n2 = (int)dzm2.cE();
                        int n3 = (int)dzm2.cH();
                        int n4 = (int)(d2 + 2.0);
                        double d3 = dzm2.cD() - 0.5;
                        double d4 = dzm2.cE() + (double)dzm2.ce() - 1.0;
                        double d5 = dzm2.cH() - 0.5;
                        int n5 = n - n4;
                        block4: while (true) {
                            int n6 = n5;
                            block5: while (n6 <= n + n4) {
                                int n7 = n3 - n4;
                                block6: while (true) {
                                    int n8 = n7;
                                    block7: while (n8 <= n3 + n4) {
                                        n6 = n2 - n4;
                                        if (stringArray != null) continue block5;
                                        for (int i = v3858546; i < n2 + n4; ++i) {
                                            double d6 = d2;
                                            double d7 = ((double)n5 - d3) * ((double)n5 - d3) + ((double)i - d4) * ((double)i - d4) + ((double)n7 - d5) * ((double)n7 - d5) - d6 * d6;
                                            n8 = d7 == 0.0 ? 0 : (d7 < 0.0 ? -1 : 1);
                                            if (stringArray != null) continue block7;
                                            if (n8 > 0) continue;
                                            arrayList.add(new fx(n5, i, n7));
                                            if (stringArray == null) continue;
                                        }
                                        ++n7;
                                        if (stringArray == null) continue block6;
                                    }
                                    break;
                                }
                                ++n5;
                                if (stringArray == null) continue block4;
                            }
                            break;
                        }
                        ArrayList<aqm> arrayList2 = new ArrayList<aqm>();
                        arrayList2.addAll(6L.3(3c.3.r).filter(aqm.class::isInstance).map(aqm.class::cast).filter(aqm2 -> {
                            boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
                            if (bl || bl) return true;
                            if (!5z.4().1.8(aqm2.R().getString())) {
                                if (bl) return true;
                                return (int)((long)686737776 ^ (long)686737777) != 0;
                            }
                            if (!bl) return (int)((long)-1486521379 ^ (long)-1486521379) != 0;
                            return true;
                        }).collect(Collectors.toList()));
                        fx2 = ((3c)object).9(arrayList.stream().filter(((3c)object)::9).collect(Collectors.toList()), arrayList2).orElse(null);
                        if (\u2003\u2006\u2000\u200f\u2001\u2005\u2002) {
                            throw null;
                        }
                    } else {
                        fx2 = this.9 = null;
                    }
                    if (this.9 == null) return;
                    object = 66.0(new dcn((double)this.9.u() + 0.5, (double)this.9.v() + 1.0, (double)this.9.w() + 0.5));
                    x2.6(((9V)object).6).2(((9V)object).3);
                    return;
                }
                case 2: {
                    if (this.9c != null) {
                        int n;
                        if (!this.1.4(this.6.9)) return;
                        this.1.0();
                        if (this.2.2 && 3c.3.s.b(apw.r) != null && (n = 38.8.0((List<bmb>)3c.3.s.bm.a)) >= 0) {
                            3c.3.s.bm.d = n;
                        }
                        3c.3.s.a(aot.a);
                        3c.3.q.a((bfw)3c.3.s, (aqa)this.9c);
                        this.9c = null;
                        return;
                    }
                    if (this.9 == null) return;
                    3c.1().ifPresent(aot2 -> {
                        block4: {
                            block2: {
                                boolean bl;
                                block3: {
                                    bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
                                    if (bl || bl) break block2;
                                    if (aot2 != aot.a) break block3;
                                    if (bl || bl) break block2;
                                    3c.9().ifPresent(n -> {
                                        block4: {
                                            block2: {
                                                boolean bl;
                                                block3: {
                                                    bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
                                                    if (bl || bl) break block2;
                                                    if (3c.3.s.bm.d == n) break block3;
                                                    if (bl || bl) break block2;
                                                    3c.3.s.e.a((oj)new tj(n.intValue()));
                                                    if (bl) break block2;
                                                }
                                                if (bl) break block2;
                                                3c.3.s.bm.d = n;
                                                if (!bl && !bl) break block4;
                                            }
                                            return;
                                        }
                                    });
                                    if (bl) break block2;
                                }
                                if (bl) break block2;
                                gc gc2 = 3c.6(this.9);
                                if (bl || bl) break block2;
                                3c.3.s.e.a((oj)new ts(aot2, new dcj(new dcn(0.0, 0.0, 0.0), gc2, this.9, (boolean)((long)-887292486 ^ (long)-887292486))));
                                if (!bl && !bl) break block4;
                            }
                            return;
                        }
                    });
                    return;
                }
            }
        }, new Predicate[(int)((long)-1080088211 ^ (long)-1080088211)]);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)8142420 ^ (long)8142454)];
            if (var7) break block23;
            var3_2 = (int)((long)1902885979 ^ (long)1902885979);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u4ecf\u6642\u7582\u7dda\u4e86\u661c\u75a3\u7df7\u4e2a\u66e0\u7510\u7d2c\u4e75\u667b\u7536\u7d22\u4e45\u66c3\u755f\u7d33\u4e36\u66e0\u75c6\u7dca\u4ebe\u66e1\u7556\u7dd1\u4eaa\u6688\u7544\u7db8\u4ed6\u66c0\u75f6\u7d43\u4e79\u667d\u753c\u7d45\u4eff\u66f3\u75e5\u7d38\u4e31\u661e\u7577\u7dbe\u4e89\u66f4\u75b2\u7d4f\u4ef0\u66db\u7540\u7d30\u4ef1\u66ab\u7543\u7d2f\u4eca\u660b\u75a7\u7d4d\u4ebd\u6632\u75bb\u7d9d\u4ef3\u66fe\u7564\u7d68\u4e06\u66ac\u7522\u7d2d\u4ef6\u66b1\u752e\u7d28\u4e1d\u6675\u7524\u7da0\u4edf\u6619\u7534\u7da5\u4e87\u6615\u75c8\u7d53\u4e4d\u669e\u7515\u7daa\u4e8f\u6699\u7517\u7d1a\u4ef2\u6627\u757a\u7d21\u4eb5\u6692\u7504\u7dcf\u4e3c\u66dd\u75a2\u7d25\u4eec\u6626\u7597\u7d69\u4eae\u668f\u753d\u7d6f\u4e7d\u6694\u751d\u7dfb\u4e01\u6681\u75ea\u7d72\u4e05\u6687\u759a\u7d0e\u4e12\u6668\u7538\u7d7f\u4e74\u6634\u7589\u7d1e\u4e89\u66aa\u7550\u7d39\u4e45\u6669\u75fc\u7d08\u4e61\u66af\u7519\u7da9\u4e85\u666b\u75e9\u7d6a\u4ed3\u6665\u756c\u7dca\u4e3c\u6613\u7502\u7dcb\u4e67\u664b\u7543\u7d25\u4e00\u66ff\u7584\u7d81\u4eb3\u663f\u754e\u7d55\u4ed9\u6673\u7547\u7d92\u4e2e\u66f6\u7586\u7dba\u4e32\u665d\u759e\u7d9f\u4e6b\u6674\u753d\u7d05\u4eda\u6694\u7599\u7d58\u4e88\u667a\u757a\u7d80\u4e08\u66cd\u759d\u7d9d\u4ee1\u6669\u7540\u7daa\u4e82\u66a9\u75dd\u7d6c\u4e35\u662d\u759a\u7d23\u4e93\u66cd\u75e2\u7dca\u4ede\u66bb\u7570\u7dee\u4eb6\u66ed\u75d1\u7de5\u4e93\u664a\u75e9\u7d2e\u4ec4\u665e\u7531\u7d16\u4eeb\u667d\u7536\u7d45\u4eb3\u6669\u7537\u7dc3\u4e83\u6606\u75d8\u7d73\u4e96\u662a\u7591\u7dab\u4ec1\u66b6\u75e3\u7d7b\u4eed\u6692\u7501\u7d9c\u4e4f\u6618\u7565\u7dae\u4edc\u6614\u7524\u7d13\u4ea3\u6635\u75de\u7d3d\u4e34\u663c\u75c4\u7d50\u4eb4\u66d4\u7520\u7dfd\u4e89\u66a2\u7534\u7dee\u4e30\u66d3\u757b\u7d6f\u4ecb\u669d\u7535\u7dfb\u4e4a\u66ad\u7588\u7d76\u4e68\u6662\u75d4\u7d77\u4e3f\u66e6\u75c4\u7db9\u4e34\u6679\u7597\u7dc9\u4ebb\u66c2\u7501\u7d46\u4eba\u6685\u75dd\u7d4c\u4e5f\u666f\u751e\u7db4\u4eea\u665a\u7532\u7d0e\u4e88\u6614\u754d\u7dc3\u4e0c\u66c7\u75a8\u7d9f\u4ecb\u66f3\u7511\u7d41\u4e7a\u6616\u7514\u7db2\u4eda\u66cc\u7574\u7d0c\u4e3f\u662f\u7584\u7dcb\u4eae\u667a\u754c\u7d60\u4e24\u66c0\u758b\u7d23\u4ecd\u6616\u75ab\u7d9d\u4ea9\u66a7\u755a\u7da6\u4ef2\u6676\u7583\u7d74\u4e79\u663f\u75a9\u7da9\u4e5d\u66b8\u753c\u7da3\u4e57\u669b\u7535\u7d29\u4ee5\u6687\u75cb\u7de2\u4eff\u6698\u75d0\u7d63\u4eb8\u6695\u7551\u7d68\u4eda\u6639\u7583\u7d8a\u4eeb\u666f\u759b\u7d30\u4e47\u6683\u7572\u7d51\u4e32\u66ed\u758e\u7d87\u4e76\u6667\u759b\u7d4d\u4e62\u668d\u7537\u7d9c\u4e4d\u665c\u7539\u7dc7\u4e0b\u66e9\u7583\u7d65\u4ec5\u661e\u75ac\u7dad\u4e7a\u66f1\u751a\u7db1\u4e91\u66ff\u7571\u7d4e\u4e30\u66f3\u75f2\u7d0f\u4e19\u6685\u75d3\u7d4c\u4ed5\u6655\u75d8\u7dcd\u4ec5\u66b4\u7595\u7d51\u4e07\u6698\u75e8\u7d6d\u4e6d\u66b7\u75fe\u7db4\u4ec8\u6642\u75bf\u7d66\u4ee7\u66a2\u7587\u7d17\u4eed\u666d\u7546\u7df8\u4e9c\u663c\u7509\u7d55\u4eab\u66fb\u75fb\u7d34\u4e56\u6621\u7572\u7d35\u4e91\u6640\u756b\u7d24\u4e3f\u6675\u759e\u7d79\u4ebf\u66a3\u7550\u7d7d\u4ea1\u666c\u75cd\u7d24\u4e0f\u66f3\u7597\u7d2c\u4e3c\u663d\u759b\u7d55\u4ec8\u66ff\u7572\u7d30\u4e09\u66d9\u75a1\u7d40\u4eaa\u6670\u7518\u7d0e\u4ed3\u6665\u75d3\u7dc9\u4e55\u66e4\u75c5\u7d7e\u4eee\u6687\u756d\u7dfe\u4e5b\u665d\u7511\u7d22\u4e4e\u6609\u7570\u7da2\u4e61\u666b\u7557\u7d63\u4e3e\u6632\u754a\u7d2b\u4e6c\u667e\u75b6\u7d9f\u4e2d\u6609\u7552\u7d2c\u4e09\u66f0\u75bd\u7d1f\u4ea4\u66b7\u75d2\u7d53\u4e48\u66ad\u7573\u7d1f\u4e35\u66b2\u75ab\u7d06\u4ebf\u6611\u7587\u7de3\u4ee4\u662f\u7523\u7da4\u4e2e\u66df\u7599\u7df6\u4e8b\u6693\u75b6\u7dfd\u4e5d\u661f\u7524\u7d30\u4ef8\u665e\u758c\u7d6a\u4e61\u6633\u75af\u7dcc\u4e23\u66fc\u759b\u7d39\u4e65\u66f4\u751b\u7d75\u4e57\u6622\u75f5\u7d80\u4e7a\u66b3\u7551\u7df9\u4e31\u66d3\u7562\u7d52\u4ef3\u66a6\u75d0\u7dde\u4ee1\u6604\u755e\u7d3b\u4eee\u66fb\u759e\u7d30\u4ee6\u66d6\u7524\u7d1a\u4e1c\u6669\u757a\u7d7e\u4e18\u6673\u7582\u7d14\u4ee3\u6607\u75a9\u7d05\u4e28\u6657\u75fd\u7db9\u4e3e\u6696\u75c8\u7d29\u4ef0\u6612\u75ac\u7d91\u4e08\u66f7\u7575\u7dd1\u4e08\u6640\u7542\u7d0f\u4ead\u668a\u75a1\u7d04\u4edc\u6685\u750b\u7dc3\u4ee7\u66ce\u7584\u7d98\u4e9b\u66fb\u75b9\u7dfb\u4e8f\u66b0\u751a\u7d63\u4ed0\u6699\u75e4\u7d6c\u4ecf\u6649\u75d1\u7de1\u4e69\u66cb\u75d3\u7d5b\u4e01\u6667\u7567\u7d35\u4e20\u66bf\u7549\u7de6\u4e5e\u661b\u7518\u7dcc\u4e27\u6671\u751e\u7df9\u4ea0\u669e\u7537\u7d13\u4ea2\u6642\u75c4\u7d3a\u4ecb\u66b0\u7587\u7d22\u4ec3\u66c7\u7525\u7d22\u4e80\u663f\u75a8\u7d04\u4eae\u6650\u7570\u7dda\u4e47\u6640\u75d4\u7d2e\u4ea2\u6608\u75af\u7d67\u4e05\u6642\u7553\u7d66\u4e04\u6668\u75b0\u7d29\u4eb8\u661b\u7505\u7dde\u4e98\u6629\u755e\u7d9c\u4ea6\u6666\u75c3\u7d2a\u4e54\u6690\u75bc\u7dc2\u4e96\u6694\u75bd\u7d26\u4e51\u66a1\u7551\u7da6\u4efc\u66de\u75ca\u7d4a\u4efd\u664b\u75df\u7dc3\u4e00\u6656\u75f5\u7d29\u4e96\u66f5\u75b0\u7d6f\u4e15\u661b\u755e\u7dea\u4e34\u66d8\u756a\u7ddd\u4e54\u66f0\u756e\u7dce\u4ecc\u6615\u75f6", -1096849170);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1728132215 ^ (long)1728132220);
            if (var7) break block23;
            var0_6 = (int)((long)-422601076 ^ (long)422601075);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1670587532 ^ (long)1670587635);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-7065016 ^ (long)7065015);
                    if (3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u46f2\u6e8d\u7d9e\u75ae\u466e\u6e16\u7d25\u7504\u46ad\u6ef1\u7d00\u759a\u46dd\u6e4b\u7de3\u75f4\u46a3\u6efe\u7dc4\u7512\u46cc\u6efd\u7dfd\u755b\u469b\u6e19\u7d56\u75b0\u4675\u6ea5\u7d79\u75cb\u46d7\u6eb5\u7da5\u7590\u46f8\u6ebc\u7d0f\u7526\u467b\u6e74\u7de8\u7556\u4606\u6e96\u7d85", 731144340);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)2085846897 ^ (long)2085846874);
                            var0_6 = (int)((long)178435839 ^ (long)-178435840);
                            while (true) {
                                v0 = (int)((long)1806152295 ^ (long)1806152282);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1545991800 ^ (long)1545991800);
                                if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) ** continue;
                                throw null;
                            }
                            3c.d = var5_1;
                            3c.e = new String[(int)((long)-822245220 ^ (long)-822245186)];
                            if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-544074360 ^ (long)-544074360);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1819264055 ^ (long)1819264054)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1111593017 ^ (long)-1111593024)) {
                                case 0: {
                                    v15 = (int)((long)1460759941 ^ (long)1460759938);
                                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-847509855 ^ (long)-847509805);
                                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-2078903209 ^ (long)-2078903178);
                                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1533624691 ^ (long)1533624698);
                                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)1659620602 ^ (long)1659620489);
                                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1076135976 ^ (long)1076136019);
                                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)159926231 ^ (long)159926209);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static float 4(double d2, double d3, double d4, aqm aqm2) {
        double d5;
        boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
        if (bl || bl) return 0.0f;
        double d6 = Math.sqrt(aqm2.h(d2, d3, d4)) / 12.0;
        if (d5 > 1.0) {
            if (bl || bl) return 0.0f;
            return 0.0f;
        }
        if (bl) return 0.0f;
        double d7 = brp.a((dcn)new dcn(d2, d3, d4), (aqa)aqm2);
        if (bl || bl) return 0.0f;
        double d8 = (1.0 - d6) * d7;
        float f = (int)((d8 * d8 + d8) / 2.0 * 7.0 * 12.0 + 1.0);
        if (!bl && !bl) return 3c.6(aqm2, 3c.8(f), new brp((brx)3c.3.r, null, d2, d3, d4, 6.0f, (boolean)((long)910776276 ^ (long)910776276), brp.a.c));
        return 0.0f;
    }

    /*
     * Enabled aggressive block sorting
     */
    private Optional<fx> 9(List<fx> list, List<aqm> iterator) {
        boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
        if (bl || bl) return null;
        fx fx2 = null;
        if (bl) return null;
        if (bl) return null;
        double d2 = 0.5;
        if (bl) return null;
        if (bl) return null;
        iterator = iterator.iterator();
        if (bl) return null;
        block0: while (!bl) {
            if (iterator.hasNext()) {
                if (bl) return null;
                aqm aqm2 = (aqm)iterator.next();
                if (aqm2 == 3c.3.s) continue;
                if (bl) return null;
                if (aqm2.dk() <= 0.0f) continue;
                if (bl) return null;
                if (!aqm2.aX()) continue;
                if (bl || bl) return null;
                Iterator<fx> iterator2 = list.iterator();
                if (bl) return null;
                while (!bl) {
                    if (iterator2.hasNext()) {
                        double d3;
                        if (bl) return null;
                        fx fx3 = iterator2.next();
                        if (bl || bl) return null;
                        if (aqm2.e(new dcn((double)fx3.u(), (double)fx3.v(), (double)fx3.w())) >= 169.0) continue;
                        if (bl || bl) return null;
                        dcn dcn2 = new dcn((double)fx3.u() + 0.5, (double)fx3.v() + 1.0, (double)fx3.w() + 0.5);
                        double d4 = 3c.9(dcn2, aqm2);
                        if (d3 > d2) {
                            double d5;
                            if (bl || bl) return null;
                            double d6 = 3c.9(dcn2, (aqm)3c.3.s);
                            if (d5 > d4) {
                                if (bl) return null;
                                if (d4 < (double)aqm2.dk()) continue;
                                if (bl) return null;
                            }
                            if (bl) return null;
                            if (((String)this.92.0()).equals(3c.b((int)((long)-1721628296 ^ (long)-1721619827), (int)((long)563919463 ^ (long)-563924252)) /* "Avoid" */)) {
                                if (bl || bl) return null;
                                if ((double)3c.3.s.dk() - d6 <= 0.5) continue;
                                if (bl) return null;
                            }
                            if (bl) return null;
                            d2 = d4;
                            if (bl || bl) return null;
                            fx2 = fx3;
                            if (bl) return null;
                        }
                        if (bl) return null;
                        if (!\u2003\u2006\u2000\u200f\u2001\u2005\u2002) continue;
                        throw null;
                    }
                    if (bl) return null;
                    if (!\u2003\u2006\u2000\u200f\u2001\u2005\u2002) continue block0;
                    throw null;
                }
                return null;
            }
            if (!bl) return Optional.ofNullable(fx2);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void 0(dci dci2, pw.knx.feather.structures.Color color) {
        block3: {
            block2: {
                boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
                if (bl || bl) break block2;
                2c c2 = (2c)2n.3.ac();
                if (bl || bl) break block2;
                2n.3(dci2.d(-c2.getRenderPosX(), -c2.getRenderPosY(), -c2.getRenderPosZ()), color.getHex(), 2.0f);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)2048235733 ^ (long)2048244538)) & (int)((long)1825440168 ^ (long)1825504855);
            if (var9_2) ** GOTO lbl-1000
            if (3c.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3c.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1174198470 ^ (long)-1174198470)] & (int)((long)1673072449 ^ (long)1673072574)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)635834765 ^ (long)635834848);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)685249291 ^ (long)685249283);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1828032140 ^ (long)1828032125);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1471724941 ^ (long)-1471724971);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1332004763 ^ (long)-1332004851);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1138640653 ^ (long)-1138640865);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1597479658 ^ (long)1597479660);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-876984048 ^ (long)-876983948);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1828151917 ^ (long)-1828151894);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-823106410 ^ (long)-823106461);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-672847184 ^ (long)-672847263);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1797248006 ^ (long)-1797248164);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)25804978 ^ (long)25805025);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)2137885224 ^ (long)2137885204);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-122141975 ^ (long)-122142095);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)2129008340 ^ (long)2129008340);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)312494330 ^ (long)312494110);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-926549646 ^ (long)-926549630);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1396605763 ^ (long)1396605774);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-560617383 ^ (long)-560617341);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1824354005 ^ (long)1824353967);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)435601069 ^ (long)435601101);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1927761571 ^ (long)1927761612);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1419857212 ^ (long)1419857159);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-584619234 ^ (long)-584619181);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1827008160 ^ (long)-1827008187);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-197395870 ^ (long)-197395840);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)830807550 ^ (long)830807458);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1075823433 ^ (long)-1075823616);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-721662103 ^ (long)-721662012);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-660045669 ^ (long)-660045633);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1411488459 ^ (long)1411488284);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1252482812 ^ (long)-1252482740);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1327901268 ^ (long)-1327901386);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1199930402 ^ (long)1199930466);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1840178079 ^ (long)1840178053);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1780134968 ^ (long)1780134948);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)100508095 ^ (long)100508012);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1681001658 ^ (long)-1681001588);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1229961203 ^ (long)1229960984);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-2020095318 ^ (long)-2020095475);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-29721104 ^ (long)-29721219);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1822808987 ^ (long)1822808852);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)199375565 ^ (long)199375395);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)159411086 ^ (long)159410958);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)726677846 ^ (long)726677855);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1283013156 ^ (long)-1283013234);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1300571342 ^ (long)1300571328);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)596017088 ^ (long)596017142);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)977367101 ^ (long)977367161);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-653607144 ^ (long)-653607129);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1963069687 ^ (long)-1963069563);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)836958252 ^ (long)836958352);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)60288780 ^ (long)60288856);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-108434320 ^ (long)-108434395);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1784416743 ^ (long)1784416724);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-499599656 ^ (long)-499599687);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-618141597 ^ (long)-618141634);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1409731536 ^ (long)1409731435);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1155934078 ^ (long)1155934012);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)993467762 ^ (long)993467841);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-918183392 ^ (long)-918183292);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)837540043 ^ (long)837539886);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1882489589 ^ (long)-1882489359);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-190141407 ^ (long)-190141293);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1142792943 ^ (long)1142792732);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)615130061 ^ (long)615129986);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1328846476 ^ (long)1328846580);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)302110114 ^ (long)302109978);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1949105714 ^ (long)-1949105911);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)587012095 ^ (long)587011968);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-310446858 ^ (long)-310446980);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-764653079 ^ (long)-764653252);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1791283943 ^ (long)1791283916);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1147171970 ^ (long)1147171989);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1528191016 ^ (long)-1528191124);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)2081196502 ^ (long)2081196320);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1463204382 ^ (long)-1463204607);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)162584613 ^ (long)162584607);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1764275097 ^ (long)1764275015);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)782886935 ^ (long)782886960);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1245098439 ^ (long)1245098369);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-686626300 ^ (long)-686626159);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1091458235 ^ (long)-1091458231);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)542589513 ^ (long)542589614);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1869945216 ^ (long)-1869945247);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1317814023 ^ (long)1317814126);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1610376518 ^ (long)-1610376682);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-293553885 ^ (long)-293553818);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)630725037 ^ (long)630724972);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)114147905 ^ (long)114147989);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1572291308 ^ (long)1572291324);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-439527010 ^ (long)-439527019);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1934395224 ^ (long)-1934395273);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-102437977 ^ (long)-102438009);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)265398247 ^ (long)265398049);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-618232091 ^ (long)-618232282);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-956313519 ^ (long)-956313531);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-65110643 ^ (long)-65110532);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1178262338 ^ (long)-1178262326);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1453492098 ^ (long)-1453492018);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1987492991 ^ (long)-1987493111);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1753251214 ^ (long)-1753251143);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)316682898 ^ (long)316682896);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1838719516 ^ (long)1838719539);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1932382157 ^ (long)-1932382043);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1015271098 ^ (long)-1015271114);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)2028173630 ^ (long)2028173689);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)40018402 ^ (long)40018178);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1936110473 ^ (long)-1936110431);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)2097078601 ^ (long)2097078606);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1902182349 ^ (long)1902182144);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)2078400532 ^ (long)2078400702);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-267329063 ^ (long)-267329231);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1197036719 ^ (long)-1197036760);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-341731476 ^ (long)-341731432);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)303733356 ^ (long)303733273);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1354030743 ^ (long)-1354030682);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1522289486 ^ (long)-1522289631);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)1712836961 ^ (long)1712836939);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-800214185 ^ (long)-800214224);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-2050569535 ^ (long)-2050569502);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)823742005 ^ (long)823742184);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)216894533 ^ (long)216894639);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1169177516 ^ (long)-1169177347);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)403615286 ^ (long)403615486);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1810655421 ^ (long)-1810655396);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1750731055 ^ (long)-1750731102);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)896726299 ^ (long)896726518);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1780241892 ^ (long)-1780241703);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)2013377683 ^ (long)2013377689);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-445425502 ^ (long)-445425525);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)752787561 ^ (long)752787657);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)947215174 ^ (long)947215146);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-853232737 ^ (long)-853232829);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-622396437 ^ (long)-622396515);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)527443734 ^ (long)527443857);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1589499189 ^ (long)-1589499319);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)896370056 ^ (long)896369988);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1700794312 ^ (long)1700794345);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1126497266 ^ (long)-1126497222);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1247366301 ^ (long)1247366314);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1911384697 ^ (long)-1911384735);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1138699668 ^ (long)1138699775);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)485142228 ^ (long)485142059);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1372676019 ^ (long)1372676049);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1537050996 ^ (long)-1537050944);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)258216089 ^ (long)258216086);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1438166399 ^ (long)-1438166326);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-61291724 ^ (long)-61291706);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-235603711 ^ (long)-235603667);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1708430960 ^ (long)-1708430968);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)382032254 ^ (long)382032250);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1182501882 ^ (long)-1182501737);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)268865356 ^ (long)268865513);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1776763696 ^ (long)1776763880);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1643239850 ^ (long)-1643239728);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-172527157 ^ (long)-172527152);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1080816349 ^ (long)1080816202);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)93711040 ^ (long)93710961);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1556420272 ^ (long)-1556420111);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1941072340 ^ (long)1941072154);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)685818804 ^ (long)685818634);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1419688572 ^ (long)-1419688547);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1767244484 ^ (long)1767244351);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-358493871 ^ (long)-358493943);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)871951350 ^ (long)871951135);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1591899087 ^ (long)1591898994);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)2004210238 ^ (long)2004210338);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1160540726 ^ (long)1160540803);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1503115369 ^ (long)-1503115327);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1572715392 ^ (long)-1572715504);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1320006148 ^ (long)-1320006238);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)921721714 ^ (long)921721695);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-722246050 ^ (long)-722246103);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-896635748 ^ (long)-896635806);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1168189417 ^ (long)1168189250);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1718337545 ^ (long)-1718337624);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-17460557 ^ (long)-17460690);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)40366482 ^ (long)40366479);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1089310161 ^ (long)1089310179);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)450227817 ^ (long)450227959);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-993844794 ^ (long)-993844887);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1211048384 ^ (long)1211048346);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1153237715 ^ (long)1153237505);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1423457599 ^ (long)1423457764);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1888704412 ^ (long)-1888704393);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)752452777 ^ (long)752452647);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1307341208 ^ (long)-1307341062);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-928580154 ^ (long)-928580263);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)694877482 ^ (long)694877499);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1604621716 ^ (long)1604621648);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)114601726 ^ (long)114601518);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)637470356 ^ (long)637470429);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)130557875 ^ (long)130557923);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-2032481028 ^ (long)-2032481109);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)494592948 ^ (long)494592844);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)525688778 ^ (long)525688586);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-303712830 ^ (long)-303712908);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1873124573 ^ (long)1873124559);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)101148172 ^ (long)101148296);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-430437623 ^ (long)-430437604);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1281159986 ^ (long)-1281160028);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-668363380 ^ (long)-668363403);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1218878089 ^ (long)1218878119);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-90732319 ^ (long)-90732427);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1996402131 ^ (long)-1996402043);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-766477531 ^ (long)-766477337);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1260740505 ^ (long)1260740563);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1745628928 ^ (long)-1745628829);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1832043560 ^ (long)1832043561);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1117531767 ^ (long)1117531658);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1898483064 ^ (long)-1898483151);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1152460665 ^ (long)-1152460678);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1852367749 ^ (long)1852367659);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)810989024 ^ (long)810988956);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1566355753 ^ (long)-1566355791);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-628051219 ^ (long)-628051276);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)997820456 ^ (long)997820478);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1526205957 ^ (long)-1526206094);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1986889236 ^ (long)1986889421);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1782737993 ^ (long)-1782738101);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-903620085 ^ (long)-903620055);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-478769404 ^ (long)-478769273);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1154139827 ^ (long)-1154139657);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-893571852 ^ (long)-893572009);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)2122674740 ^ (long)2122674886);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1628844142 ^ (long)-1628844077);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)278115018 ^ (long)278114899);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-240793517 ^ (long)-240793446);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1866754051 ^ (long)1866754184);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-2040428163 ^ (long)-2040428162);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)12440638 ^ (long)12440667);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)744591846 ^ (long)744591625);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1612460967 ^ (long)1612460951);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1319962175 ^ (long)1319962193);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1507317453 ^ (long)-1507317406);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-814859456 ^ (long)-814859394);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)163192899 ^ (long)163192925);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1113773713 ^ (long)-1113773772);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1117471151 ^ (long)1117471185);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-2008860613 ^ (long)-2008860482);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1578272853 ^ (long)-1578272792);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1412156622 ^ (long)-1412156493);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1036053490 ^ (long)1036053447);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)2133040403 ^ (long)2133040406);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)119415929 ^ (long)119415863);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)333839955 ^ (long)333839979);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-871711884 ^ (long)-871711931);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)623684481 ^ (long)623684387);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1995989302 ^ (long)-1995989443);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)979630608 ^ (long)979630731);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1197360327 ^ (long)-1197360367);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)2003564236 ^ (long)2003564147);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1083707377 ^ (long)-1083707276);
                    if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1470826805 ^ (long)1470826760);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)869072028 ^ (long)869071971)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1389624924 ^ (long)1389560227)) >>> (int)((long)1421947541 ^ (long)1421947549)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1256049503 ^ (long)1256049503);
            if (!3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)2026307931 ^ (long)2026307929);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1575070809 ^ (long)-1575070812) | var5_6 << (int)((long)1968791544 ^ (long)1968791549)) ^ var3_4[var7_8]) & (int)((long)-1602475196 ^ (long)-1602475077);
                    if (3c.\u2003\u2006\u2000\u200f\u2001\u2005\u2002) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1435066838 ^ (long)-1435066839) | var6_7 << (int)((long)-956727469 ^ (long)-956727466)) ^ var3_4[var7_8]) & (int)((long)-1256587220 ^ (long)-1256587053);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3c.e[var2_3] = new String(var3_4).intern();
        }
        return 3c.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    private static gc 6(fx fx2) {
        boolean bl = \u2003\u2006\u2000\u200f\u2001\u2005\u2002;
        if (bl || bl) return null;
        fx2 = new dcn((double)fx2.u(), (double)fx2.v(), (double)fx2.w()).b(0.5, 1.0, 0.5);
        if (bl || bl) return null;
        fx2 = 3c.3.r.a(new brf(new dcn(3c.3.s.cD(), 3c.3.s.cE() + (double)3c.3.s.ce(), 3c.3.s.cH()), (dcn)fx2, brf.a.a, brf.b.a, (aqa)3c.3.s));
        if (fx2.c() != dcl.a.b) {
            if (bl || bl) return null;
            return gc.b;
        }
        if (!bl) return fx2.b();
        return null;
    }
}

