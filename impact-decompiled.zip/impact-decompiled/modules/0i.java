/* ==========================================================================
 * MODULE: SneakyAssassins
 * CATEGORY (inferred): Combat
 * DESCRIPTION: Reveals the assassins
 * OBFUSCATED CLASS: net.impactclient.0i
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqa
 *  bfe
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  pw.knx.feather.structures.Color
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1R;
import net.impactclient.2n;
import net.impactclient.2o;
import net.impactclient.2w$6X;
import net.impactclient.34E;
import net.impactclient.3X;
import net.impactclient.4M;
import net.impactclient.6L;
import pw.knx.feather.structures.Color;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0i
extends 3X
implements 4M {
    private static final String[] e;
    @EventHandler
    private final Listener<2o> 5;
    private static final String[] d;
    private 1R 7;
    public static final boolean \u2009\u200d\u2001\u2008;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0i.\u2009\u200d\u2001\u2008;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-376185879 ^ (long)-376177428)) & (int)((long)-956238246 ^ (long)-956298843);
            if (var9_2) ** GOTO lbl-1000
            if (0i.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0i.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-498497070 ^ (long)-498497070)] & (int)((long)1138884705 ^ (long)1138884766)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1628317429 ^ (long)-1628317426);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1253881188 ^ (long)1253881337);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1607709861 ^ (long)-1607709862);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-973968879 ^ (long)-973968802);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-469510153 ^ (long)-469510233);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-2026572597 ^ (long)-2026572670);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1232358717 ^ (long)1232358697);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)733123696 ^ (long)733123685);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1324748896 ^ (long)1324748856);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1741710791 ^ (long)-1741710725);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-620764513 ^ (long)-620764522);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-734303736 ^ (long)-734303733);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-209917007 ^ (long)-209917149);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1629276633 ^ (long)1629276425);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-936496933 ^ (long)-936497062);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1523439310 ^ (long)1523439281);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1761750633 ^ (long)1761750607);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1158141942 ^ (long)-1158141847);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-733684713 ^ (long)-733684663);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1979360065 ^ (long)1979360131);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1925376782 ^ (long)1925376771);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)960724549 ^ (long)960724699);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-416483219 ^ (long)-416483117);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1543728500 ^ (long)-1543728588);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-759702698 ^ (long)-759702551);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1134140360 ^ (long)-1134140189);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1105547213 ^ (long)-1105547163);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-2119985344 ^ (long)-2119985381);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-595111076 ^ (long)-595111136);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1499407183 ^ (long)1499407216);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)955041750 ^ (long)955041758);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1735519987 ^ (long)1735519800);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-4584388 ^ (long)-4584352);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1046909228 ^ (long)-1046909417);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1715831271 ^ (long)-1715831124);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1630773440 ^ (long)-1630773361);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)2035782419 ^ (long)2035782509);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1737505983 ^ (long)1737505875);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1099070536 ^ (long)1099070693);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1726965584 ^ (long)1726965753);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1786458894 ^ (long)1786458925);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)574872033 ^ (long)574871974);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-566608148 ^ (long)-566608277);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1777078849 ^ (long)1777078839);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-685380349 ^ (long)-685380153);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1080914074 ^ (long)-1080914100);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-844620774 ^ (long)-844620706);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1071748772 ^ (long)1071748790);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)2074961217 ^ (long)2074961377);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)0x383D338D ^ (long)943534950);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1418123890 ^ (long)-1418123998);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1928770802 ^ (long)1928770667);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1622970588 ^ (long)-1622970566);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)127737505 ^ (long)127737386);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1750286391 ^ (long)1750286550);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1018687735 ^ (long)-1018687520);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1771219317 ^ (long)-1771219240);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)531980720 ^ (long)531980548);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-274311330 ^ (long)-274311178);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1332909100 ^ (long)-1332909307);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1115126729 ^ (long)-1115126756);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1872089576 ^ (long)1872089491);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)98152776 ^ (long)98152742);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1624474974 ^ (long)-1624475035);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-2127443501 ^ (long)-2127443468);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1565418258 ^ (long)-1565418304);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)2074055813 ^ (long)2074055787);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-2048059660 ^ (long)-2048059810);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)585504193 ^ (long)585504080);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)478466780 ^ (long)478466770);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-587046465 ^ (long)-587046563);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)606306519 ^ (long)606306506);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1872121340 ^ (long)1872121101);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1159996140 ^ (long)1159996031);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1713353109 ^ (long)1713353040);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)957683636 ^ (long)957683611);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1730951642 ^ (long)1730951661);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1693199191 ^ (long)1693199342);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-445809626 ^ (long)-445809558);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1178876925 ^ (long)1178876749);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-52673038 ^ (long)-52673211);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1550661391 ^ (long)-1550661395);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-220970817 ^ (long)-220970921);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-782452338 ^ (long)-782452373);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-288706754 ^ (long)-288706803);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1666981549 ^ (long)-1666981568);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1324832235 ^ (long)1324832143);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1906304724 ^ (long)-1906304701);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1900781461 ^ (long)1900781321);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1653380851 ^ (long)1653380849);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1371438982 ^ (long)1371438970);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1479852569 ^ (long)-1479852716);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1219201841 ^ (long)-1219201927);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)992086481 ^ (long)992086276);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1132293331 ^ (long)1132293177);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1952037347 ^ (long)-1952037344);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1937028147 ^ (long)-1937028171);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1403491663 ^ (long)1403491736);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-670335782 ^ (long)-670335988);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-473034259 ^ (long)-473034277);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)654756861 ^ (long)654756858);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1444910089 ^ (long)1444910251);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)2117763731 ^ (long)2117763746);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-796449407 ^ (long)-796449423);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-630770989 ^ (long)-630771051);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)631473145 ^ (long)631472948);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)298708082 ^ (long)298708194);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-371716484 ^ (long)-371716477);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1697488739 ^ (long)1697488831);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1676080847 ^ (long)-1676080775);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)705526580 ^ (long)705526671);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)593855852 ^ (long)593855817);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)343535322 ^ (long)343535257);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1187160893 ^ (long)1187161017);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1293603188 ^ (long)-1293603259);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1634658393 ^ (long)1634658332);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)1094469263 ^ (long)1094469342);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-38507644 ^ (long)-38507557);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-412215040 ^ (long)-412214838);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-2070956986 ^ (long)-2070956922);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-516294767 ^ (long)-516294686);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1397300890 ^ (long)-1397300808);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-509549426 ^ (long)-509549564);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-677632097 ^ (long)-677632065);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)314989891 ^ (long)314989870);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1344923123 ^ (long)-1344923032);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-2035967504 ^ (long)-2035967520);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1653891296 ^ (long)-1653891316);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)2054102500 ^ (long)2054102276);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1467807096 ^ (long)-1467807209);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1928555129 ^ (long)1928555099);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-850468095 ^ (long)-850467973);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1375874591 ^ (long)1375874692);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)271915505 ^ (long)271915308);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1494499641 ^ (long)1494499775);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-510949253 ^ (long)-510949279);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-637991084 ^ (long)-637991029);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)315684983 ^ (long)315684901);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1077891889 ^ (long)-1077892030);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-706509417 ^ (long)-706509530);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1775262905 ^ (long)1775262784);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1285470024 ^ (long)1285470070);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1103861565 ^ (long)1103861623);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1860587013 ^ (long)1860587165);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-744330056 ^ (long)-744330209);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1632340494 ^ (long)-1632340525);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1020217301 ^ (long)1020217103);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-674925723 ^ (long)-674925628);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1636027693 ^ (long)1636027767);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)761712575 ^ (long)761712571);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)652573050 ^ (long)652573166);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)1001925456 ^ (long)1001925467);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1622324869 ^ (long)1622324945);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-859785606 ^ (long)-859785630);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-220398660 ^ (long)-220398677);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1057324800 ^ (long)1057324810);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-956971288 ^ (long)-956971368);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1163084251 ^ (long)-1163084188);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1956430806 ^ (long)-1956430605);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1210934827 ^ (long)1210935001);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1005769915 ^ (long)1005769774);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1127480439 ^ (long)-1127480380);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1876374964 ^ (long)1876374996);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1793430038 ^ (long)1793430062);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-856764485 ^ (long)-856764639);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1278512690 ^ (long)-1278512867);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1564776459 ^ (long)1564776477);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-230171196 ^ (long)-230171376);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1284986997 ^ (long)-1284987107);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)663387472 ^ (long)663387442);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1339850723 ^ (long)-1339850639);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)127246181 ^ (long)127246093);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1827737063 ^ (long)1827736976);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1257601127 ^ (long)-1257601252);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)94587928 ^ (long)94588149);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-2045893395 ^ (long)-2045893420);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)714803104 ^ (long)714803142);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-28596726 ^ (long)-28596671);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-618041947 ^ (long)-618042047);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)757170076 ^ (long)757170121);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-170023409 ^ (long)-170023173);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-236064491 ^ (long)-236064471);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)944395848 ^ (long)944395865);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-380381199 ^ (long)-380381274);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1132062575 ^ (long)-1132062675);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-772668679 ^ (long)-772668926);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1106257254 ^ (long)-1106257312);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1376381499 ^ (long)1376381459);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)687963401 ^ (long)687963437);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1487354920 ^ (long)-1487355035);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1013175252 ^ (long)1013175073);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1233527594 ^ (long)-1233527669);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)417330888 ^ (long)417330849);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)595604115 ^ (long)595604053);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1542716278 ^ (long)1542716409);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-632849112 ^ (long)-632848991);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-336605835 ^ (long)-336605818);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1680674902 ^ (long)1680675029);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1606655271 ^ (long)1606655361);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1784153031 ^ (long)1784152969);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-171270356 ^ (long)-171270292);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)189461158 ^ (long)189461041);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)174969795 ^ (long)174969708);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)420316303 ^ (long)420316227);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)976153877 ^ (long)976153893);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-545610358 ^ (long)-545610408);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1134706887 ^ (long)-1134706788);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)901297828 ^ (long)901297747);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1822306899 ^ (long)-1822306944);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-741662174 ^ (long)-741662048);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1343737676 ^ (long)1343737778);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-918565107 ^ (long)-918565098);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)367394555 ^ (long)367394438);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1359952174 ^ (long)1359952215);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-895636486 ^ (long)-895636702);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1574415961 ^ (long)-1574416017);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1973918003 ^ (long)-1973918038);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1716716686 ^ (long)1716716695);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1214733434 ^ (long)-1214733463);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1905353358 ^ (long)-1905353280);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)904120552 ^ (long)904120474);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)667641837 ^ (long)667641823);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-358829659 ^ (long)-358829666);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)242761014 ^ (long)242761168);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1682236342 ^ (long)1682236279);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1578348680 ^ (long)1578348797);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-2011815115 ^ (long)-2011814917);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1289059227 ^ (long)1289059246);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-658585856 ^ (long)-658585767);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1917844043 ^ (long)-1917844171);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)2037424964 ^ (long)2037425063);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-432464668 ^ (long)-432464668);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)565566310 ^ (long)565566366);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1949759258 ^ (long)-1949759384);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-951043798 ^ (long)-951043703);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1829479599 ^ (long)1829479630);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1988387746 ^ (long)-1988387590);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1659264698 ^ (long)-1659264654);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-435969694 ^ (long)-435969704);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-415484358 ^ (long)-415484336);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1910449234 ^ (long)1910449316);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1481364677 ^ (long)-1481364587);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)2033795613 ^ (long)2033795689);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1445573346 ^ (long)-1445573359);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1431380667 ^ (long)-1431380498);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1083008921 ^ (long)-1083008789);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1992229068 ^ (long)-1992228909);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1088160456 ^ (long)-1088160382);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-345130043 ^ (long)-345130060);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1244330817 ^ (long)1244330829);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1831105366 ^ (long)1831105341);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)2142204256 ^ (long)2142204262);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1015146417 ^ (long)-1015146416);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1555349600 ^ (long)1555349661);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-2145812770 ^ (long)-2145812906);
                    if (!0i.\u2009\u200d\u2001\u2008) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1827791974 ^ (long)1827791951);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-682981535 ^ (long)-682981474)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-502420339 ^ (long)-502443150)) >>> (int)((long)-1841526420 ^ (long)-1841526428)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1568386575 ^ (long)1568386575);
            if (!0i.\u2009\u200d\u2001\u2008) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)509369779 ^ (long)509369777);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-386154913 ^ (long)-386154916) | var5_6 << (int)((long)1173138866 ^ (long)1173138871)) ^ var3_4[var7_8]) & (int)((long)1920721281 ^ (long)1920721278);
                    if (0i.\u2009\u200d\u2001\u2008) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1813178490 ^ (long)1813178489) | var6_7 << (int)((long)1926752889 ^ (long)1926752892)) ^ var3_4[var7_8]) & (int)((long)-961309147 ^ (long)-961308966);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0i.e[var2_3] = new String(var3_4).intern();
        }
        return 0i.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0i.\u2009\u200d\u2001\u2008;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-1718420959 ^ (long)-1718420956)];
            if (var7) break block23;
            var3_2 = (int)((long)-73253914 ^ (long)-73253914);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u9700\ubfaf\uac77\ua4c6\u9782\ubf39\uacd1\ua4c8\u9763\ubfc4\uac81\ua44f\u979e\ubf89\uac2e\ua45a\u9778\ubf8f\uac04\ua4a3\u97c2\ubf14\uaca0\ua495\u977c\ubf0d\uac5a\ua4cb\u975d\ubfdf\uacc2\ua4ad\u97a8\ubf0e\uac42\ua482\u972c\ubfa8\uacd4\ua495\u97b7\ubfde\uac6d\ua44f\u9781\ubf12\uac0f\ua425\u97cf\ubf52\uacb9\ua41c\u97ea\ubfd8\uac6f\ua438\u97b4\ubfab\uac60\ua407\u9798\ubfe8\uacdf\ua4d1\u971b\ubfc9\uac30\ua454\u975d\ubf82\uacf5\ua422\u9798", 1751560592);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-550786946 ^ (long)-550786965);
            if (var7) break block23;
            var0_6 = (int)((long)-2037645252 ^ (long)2037645251);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-441560704 ^ (long)-441560596);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1076297793 ^ (long)1076297792);
                    if (0i.\u2009\u200d\u2001\u2008) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0i.\u2009\u200d\u2001\u2008) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ua482\u8c27\u9fc1\u976d\ua4fb\u8c09\u9f53\u97fe\ua494\u8ce6\u9f5a\u97a4\ua4ed\u8c04\u9f9d\u97f8\ua4a4\u8c46\u9f3a\u976e\ua4b5", 107905596);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-278892352 ^ (long)-278892337);
                            var0_6 = (int)((long)-1204054793 ^ (long)1204054792);
                            while (true) {
                                v0 = (int)((long)1921308815 ^ (long)1921308838);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1805863467 ^ (long)1805863467);
                                if (!0i.\u2009\u200d\u2001\u2008) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0i.\u2009\u200d\u2001\u2008) ** continue;
                                throw null;
                            }
                            0i.d = var5_1;
                            0i.e = new String[(int)((long)1519795267 ^ (long)1519795270)];
                            if (!0i.\u2009\u200d\u2001\u2008) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1102838187 ^ (long)-1102838187);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1784365325 ^ (long)-1784365326)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-693711472 ^ (long)-693711465)) {
                                case 0: {
                                    v15 = (int)((long)845430678 ^ (long)845430733);
                                    if (!0i.\u2009\u200d\u2001\u2008) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1367323263 ^ (long)-1367323223);
                                    if (!0i.\u2009\u200d\u2001\u2008) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)193646279 ^ (long)193646287);
                                    if (!0i.\u2009\u200d\u2001\u2008) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)938415011 ^ (long)938415022);
                                    if (!0i.\u2009\u200d\u2001\u2008) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-36344984 ^ (long)-36344980);
                                    if (!0i.\u2009\u200d\u2001\u2008) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1018329802 ^ (long)-1018329823);
                                    if (!0i.\u2009\u200d\u2001\u2008) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1451074183 ^ (long)1451074242);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0i.\u2009\u200d\u2001\u2008);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    public 0i() {
        boolean bl = \u2009\u200d\u2001\u2008;
        super(0i.b((int)((long)-1541868930 ^ (long)-1541876360), (int)((long)-9127503 ^ (long)-9140499)) /* "SneakyAssassins" */, 0i.b((int)((long)862496547 ^ (long)862486566), (int)((long)-160214683 ^ (long)-160229510)) /* "Reveals the assassins" */);
        Color color = Color.fromRGB((int)((int)((long)-203936520 ^ (long)-203936520)), (int)((int)((long)1598458426 ^ (long)1598458621)), (int)((int)((long)870060241 ^ (long)870060241)));
        34E e2 = (34E)((34E)((34E)this.0().5(0i.b((int)((long)2124081870 ^ (long)2124074441), (int)((long)1490112155 ^ (long)-1490105259)) /* "Color" */)).7(0i.b((int)((long)225559438 ^ (long)225567887), (int)((long)-214593517 ^ (long)-214579817)) /* "color" */)).1(0i.b((int)((long)1979194936 ^ (long)1979201852), (int)((long)773437751 ^ (long)-773425667)) /* "The color that players will be highlighted in" */);
        ((34E)((34E)((34E)this.0().5(0i.b((int)((long)2124081870 ^ (long)2124074441), (int)((long)1490112155 ^ (long)-1490105259)) /* "Color" */)).7(0i.b((int)((long)225559438 ^ (long)225567887), (int)((long)-214593517 ^ (long)-214579817)) /* "color" */)).1(0i.b((int)((long)1979194936 ^ (long)1979201852), (int)((long)773437751 ^ (long)-773425667)) /* "The color that players will be highlighted in" */)).7 = color;
        this.7 = (1R)e2.5();
        this.5 = new Listener(o -> {
            block3: {
                block2: {
                    boolean bl = \u2009\u200d\u2001\u2008;
                    if (bl || bl) break block2;
                    6L.3(0i.3.r).filter(bfe.class::isInstance).map(bfe.class::cast).filter(this::7).forEach(bfe2 -> {
                        block3: {
                            block2: {
                                boolean bl = \u2009\u200d\u2001\u2008;
                                if (bl || bl) break block2;
                                2n.4((aqa)bfe2, this.7.2(), (boolean)((long)1140046359 ^ (long)1140046358), o.3());
                                if (!bl) break block3;
                            }
                            return;
                        }
                    });
                    if (!bl && !bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)990000051 ^ (long)990000051)]);
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean 7(bfe bfe2) {
        boolean bl;
        block8: {
            block7: {
                bl = \u2009\u200d\u2001\u2008;
                if (bl || bl) return true;
                if (bfe2.q != 0.0f) break block7;
                if (bl) return true;
                if (bfe2.bA()) break block7;
                if (bl) return true;
                if (bfe2.aR == 0.0f) break block8;
                if (bl) return true;
            }
            if (bl) return true;
            return (int)((long)1086839538 ^ (long)1086839539) != 0;
        }
        if (!bl) return (int)((long)-2085933114 ^ (long)-2085933114) != 0;
        return true;
    }
}

