/* ==========================================================================
 * MODULE: Air Jump
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Allows you to jump in-air
 * OBFUSCATED CLASS: net.impactclient.0V
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 */
package net.impactclient;

import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.3X;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0V
extends 3X
implements 34B {
    public static final boolean \u2004;
    private static final String[] e;
    private static final String[] d;

    public 0V() {
        boolean bl = \u2004;
        super(0V.b((int)((long)599038648 ^ (long)-599055086), (int)((long)-1150674359 ^ (long)1150659096)) /* "Air Jump" */, 0V.b((int)((long)-1885432354 ^ (long)1885416053), (int)((long)1549483766 ^ (long)1549497203)) /* "Allows you to jump in-air" */);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 0V.\u2004;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)-984776631 ^ (long)-984776629)];
            if (var7) break block16;
            var3_2 = (int)((long)539062524 ^ (long)539062524);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u2f57\u07a8\u1431\u1c68\u2f38\u07a9\u1410\u1ca9\u2fb7\u07a6\u14ac\u1ce3\u2ffe\u0766\u14c4\u1c73\u2f17\u0753\u1491\u1c4d\u2fcd\u075d\u149e\u1c9f\u2f0f\u0725\u1450\u1cfc\u2fd4\u076d\u147f\u1ccc\u2f34\u07af", 1418135940);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)2144005429 ^ (long)2144005420);
            if (var7) break block16;
            var0_6 = (int)((long)1184547937 ^ (long)-1184547938);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-2030950040 ^ (long)2030950039);
                if (0V.\u2004) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!0V.\u2004) continue block8;
                            throw null;
                        }
                        0V.d = var5_1;
                        0V.e = new String[(int)((long)-207634610 ^ (long)-207634612)];
                        if (!0V.\u2004) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)398119545 ^ (long)398119545);
                v5 = (int)((long)27263390 ^ (long)27263479);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)1395008914 ^ (long)1395008915)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1765181592 ^ (long)-1765181585)) {
                                case 0: {
                                    v12 = (int)((long)-1642402175 ^ (long)-1642402157);
                                    if (!0V.\u2004) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)507083823 ^ (long)507083820);
                                    if (!0V.\u2004) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-996119549 ^ (long)-996119504);
                                    if (!0V.\u2004) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)-207189190 ^ (long)-207189235);
                                    if (!0V.\u2004) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)804134442 ^ (long)804134512);
                                    if (!0V.\u2004) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)-566406468 ^ (long)-566406450);
                                    if (!0V.\u2004) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)799064535 ^ (long)799064477);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!0V.\u2004);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!0V.\u2004) ** continue;
                throw null;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0V.\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)219801415 ^ (long)-219784980)) & (int)((long)1960127185 ^ (long)1960170798);
            if (var9_2) ** GOTO lbl-1000
            if (0V.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0V.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)841356672 ^ (long)841356672)] & (int)((long)2009439121 ^ (long)2009439086)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)322389560 ^ (long)322389504);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1582819613 ^ (long)-1582819830);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)814796122 ^ (long)814796140);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)591136477 ^ (long)591136277);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1050757328 ^ (long)-1050757326);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1807086595 ^ (long)1807086709);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1612586722 ^ (long)-1612586734);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)275082057 ^ (long)275082148);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1373434231 ^ (long)-1373434218);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-200850947 ^ (long)-200850989);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)297263066 ^ (long)297262996);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1963750899 ^ (long)-1963750831);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1860631550 ^ (long)1860631532);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-200771876 ^ (long)-200771948);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1258255303 ^ (long)1258255256);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1206430003 ^ (long)1206430099);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1010707759 ^ (long)1010707789);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)856321992 ^ (long)856321978);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1597508783 ^ (long)-1597508746);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-689324723 ^ (long)-689324790);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1788737174 ^ (long)1788737030);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1093651112 ^ (long)-1093651156);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1972351292 ^ (long)1972351255);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-2101079013 ^ (long)-2101078915);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1420103384 ^ (long)-1420103361);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-657829902 ^ (long)-657830005);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1904127078 ^ (long)-1904127124);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1440699449 ^ (long)1440699396);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)649733982 ^ (long)649733918);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1655774519 ^ (long)-1655774527);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1496844829 ^ (long)-1496844802);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1565364549 ^ (long)-1565364670);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)841357247 ^ (long)841357133);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1552345871 ^ (long)-1552346089);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1948716897 ^ (long)1948716908);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-938724384 ^ (long)-938724522);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-15630583 ^ (long)-15630498);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-2004247565 ^ (long)-2004247634);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1731058219 ^ (long)-1731058346);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1004548848 ^ (long)-1004548645);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1245476398 ^ (long)-1245476446);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-616312295 ^ (long)-616312260);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1802730392 ^ (long)1802730492);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)2033192210 ^ (long)2033192224);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-2072252098 ^ (long)-2072252149);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)13432066 ^ (long)13432070);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1919987519 ^ (long)1919987580);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)2022964759 ^ (long)2022964844);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-875488472 ^ (long)-875488400);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)144562819 ^ (long)144562840);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)42192986 ^ (long)42193095);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1608030695 ^ (long)-1608030469);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)696103576 ^ (long)696103664);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-949988821 ^ (long)-949988673);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1064636760 ^ (long)-1064636690);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1151656384 ^ (long)1151656290);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1823317653 ^ (long)-1823317686);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)643823631 ^ (long)643823825);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)615170934 ^ (long)615170853);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)13459655 ^ (long)13459473);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)455176706 ^ (long)455176887);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1765167358 ^ (long)1765167143);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1671831929 ^ (long)1671831818);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1520525087 ^ (long)-1520525311);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1926781779 ^ (long)-1926781790);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1695337894 ^ (long)1695337867);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-109558988 ^ (long)-109558994);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1443266037 ^ (long)1443266001);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-612245263 ^ (long)-612245458);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-230152012 ^ (long)-230152057);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1900891443 ^ (long)-1900891401);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-483110106 ^ (long)-483109977);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1628893795 ^ (long)-1628893797);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1998906141 ^ (long)-1998906255);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1627438098 ^ (long)-1627438191);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1049253516 ^ (long)-1049253422);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1639015466 ^ (long)-1639015503);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)888971724 ^ (long)888971534);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1410033133 ^ (long)1410032898);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)868574246 ^ (long)868574401);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-395633076 ^ (long)-395632995);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1408608828 ^ (long)-1408609011);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-269467387 ^ (long)-269467195);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1435237637 ^ (long)-1435237823);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1172435824 ^ (long)-1172435794);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1230868593 ^ (long)1230868700);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1547429378 ^ (long)-1547429630);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)148201648 ^ (long)148201636);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)832354094 ^ (long)832354240);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-377619144 ^ (long)-377619055);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1919513160 ^ (long)1919513092);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-660932195 ^ (long)-660932250);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-21096034 ^ (long)-21095990);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1459499102 ^ (long)-1459499102);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1176528344 ^ (long)-1176528244);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)272220532 ^ (long)272220498);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1362768172 ^ (long)-1362768384);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1005726560 ^ (long)1005726584);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1763039563 ^ (long)-1763039682);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)410714609 ^ (long)410714402);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-422333608 ^ (long)-422333621);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1776518288 ^ (long)1776518154);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-809807171 ^ (long)-809807309);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-903718522 ^ (long)-903718546);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-980350924 ^ (long)-980350904);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1922833069 ^ (long)1922832897);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)883523449 ^ (long)883523539);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1963043099 ^ (long)-1963043090);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-995264261 ^ (long)-995264383);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-2123125594 ^ (long)-2123125752);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-223662853 ^ (long)-223663001);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1909707051 ^ (long)-1909707166);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-2075113853 ^ (long)-2075113754);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1456348645 ^ (long)1456348517);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1054487249 ^ (long)1054487129);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)525236992 ^ (long)525237179);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1403116038 ^ (long)-1403116235);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1125021578 ^ (long)1125021643);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)755562642 ^ (long)755562599);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1097776174 ^ (long)-1097776189);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1327588587 ^ (long)1327588562);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)601932590 ^ (long)601932786);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)65992186 ^ (long)65992164);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1050706938 ^ (long)-1050706732);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1287924341 ^ (long)1287924250);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-10982487 ^ (long)-10982613);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1407164870 ^ (long)-1407164703);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1510180114 ^ (long)1510180167);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-183528320 ^ (long)-183528241);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-2105450417 ^ (long)-2105450401);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1079073525 ^ (long)-1079073484);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)940471298 ^ (long)940471537);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1017673487 ^ (long)1017673603);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)474265789 ^ (long)474265828);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)2007697033 ^ (long)2007697017);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1764146970 ^ (long)1764147057);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-727929347 ^ (long)-727929484);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-346493197 ^ (long)-346493428);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1931827681 ^ (long)-1931827501);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1109670807 ^ (long)-1109670849);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)721424782 ^ (long)721424814);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-2057702426 ^ (long)-2057702522);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1618349078 ^ (long)-1618349091);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-48203307 ^ (long)-48203505);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-931038840 ^ (long)-931038951);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1658019220 ^ (long)1658019319);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1236089090 ^ (long)-1236089296);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1885736480 ^ (long)-1885736694);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-748034872 ^ (long)-748034943);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1144520043 ^ (long)-1144519976);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1107307895 ^ (long)1107308029);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-430196494 ^ (long)-430196657);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-611780802 ^ (long)-611780704);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1311943248 ^ (long)1311943295);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1125642818 ^ (long)-1125642951);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)804561910 ^ (long)804561795);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)56261327 ^ (long)56261337);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1768577504 ^ (long)-1768577324);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-404682094 ^ (long)-404682205);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-714165245 ^ (long)-714165082);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-198236008 ^ (long)-198235949);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)2005148976 ^ (long)2005149034);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)547404584 ^ (long)547404740);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)2133108182 ^ (long)2133108048);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)427651444 ^ (long)427651437);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)142647013 ^ (long)142646985);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1463120583 ^ (long)-1463120515);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-821901634 ^ (long)-821901626);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1416334173 ^ (long)1416334280);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-846156752 ^ (long)-846156747);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)138582006 ^ (long)138581856);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1964427521 ^ (long)-1964427631);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)493909215 ^ (long)493909091);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)132743625 ^ (long)132743436);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-143090961 ^ (long)-143091105);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)454822576 ^ (long)454822621);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1366791486 ^ (long)-1366791674);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-529636911 ^ (long)-529636912);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)598571746 ^ (long)598571742);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-53032065 ^ (long)-53032034);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1859449422 ^ (long)1859449401);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1351606768 ^ (long)1351606582);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)2086473460 ^ (long)2086473327);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1785548331 ^ (long)1785548434);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-953550006 ^ (long)-953549945);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1196351051 ^ (long)1196351151);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-894060631 ^ (long)-894060630);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1988797429 ^ (long)1988797221);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-145507963 ^ (long)-145507919);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)755914533 ^ (long)755914664);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1843561819 ^ (long)1843561940);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1087972835 ^ (long)-1087972637);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1979388085 ^ (long)1979388091);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1195544859 ^ (long)-1195544933);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-778085000 ^ (long)-778084897);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1749523979 ^ (long)1749524211);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)302572720 ^ (long)302572709);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)444561526 ^ (long)444561608);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1606844666 ^ (long)-1606844541);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)244249464 ^ (long)244249529);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)799073042 ^ (long)799073038);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1907015063 ^ (long)1907014952);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)615318246 ^ (long)615318230);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)898520548 ^ (long)898520473);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-921213820 ^ (long)-921213925);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1935069562 ^ (long)-1935069583);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1268087510 ^ (long)1268087415);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)978206832 ^ (long)978206936);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-981785059 ^ (long)-981785068);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1162222819 ^ (long)1162222651);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)779187011 ^ (long)779186978);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1399496081 ^ (long)1399496050);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-268523281 ^ (long)-268523476);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)413598938 ^ (long)413598733);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)202547156 ^ (long)202546953);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)623569982 ^ (long)623570133);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1368427302 ^ (long)-1368427381);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1615742375 ^ (long)1615742349);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1289529028 ^ (long)1289529062);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1791531276 ^ (long)-1791531343);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-822438687 ^ (long)-822438830);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1925643968 ^ (long)1925643906);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)214355544 ^ (long)214355618);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)578043998 ^ (long)578043916);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1178307739 ^ (long)1178307596);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)471676135 ^ (long)471676045);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1048687994 ^ (long)1048687908);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1488131633 ^ (long)-1488131814);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)703354474 ^ (long)703354441);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1787099190 ^ (long)1787099238);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1103527202 ^ (long)1103527251);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-399772654 ^ (long)-399772549);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)2037163287 ^ (long)2037163448);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1076622634 ^ (long)-1076622707);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1812960446 ^ (long)-1812960504);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-503726097 ^ (long)-503726306);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)20508281 ^ (long)20508370);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)724177101 ^ (long)724177006);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)396609290 ^ (long)396609470);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1973361792 ^ (long)1973361735);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1110409719 ^ (long)-1110409714);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1511995846 ^ (long)1511995743);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)79323068 ^ (long)79322969);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)766027518 ^ (long)766027386);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1212920960 ^ (long)1212920888);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-847876722 ^ (long)-847876842);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1782550017 ^ (long)1782550057);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1410486202 ^ (long)-1410486153);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1540857195 ^ (long)-1540857170);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1122509315 ^ (long)1122509456);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1283378920 ^ (long)-1283378734);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-1745114795 ^ (long)-1745114823);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-441361495 ^ (long)-441361637);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-604542414 ^ (long)-604542437);
                    if (!0V.\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)960696991 ^ (long)960696930);
                    if (!0V.\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1145640680 ^ (long)-1145640686);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1180673015 ^ (long)-1180672778)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1223240707 ^ (long)-1223283710)) >>> (int)((long)-1500904855 ^ (long)-1500904863)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1701475481 ^ (long)1701475481);
            if (!0V.\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1003133317 ^ (long)1003133319);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-724466180 ^ (long)-724466177) | var5_6 << (int)((long)677498344 ^ (long)677498349)) ^ var3_4[var7_8]) & (int)((long)355981429 ^ (long)355981450);
                    if (0V.\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-8660715 ^ (long)-8660714) | var6_7 << (int)((long)454994212 ^ (long)454994209)) ^ var3_4[var7_8]) & (int)((long)1654305036 ^ (long)1654305267);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0V.e[var2_3] = new String(var3_4).intern();
        }
        return 0V.e[var2_3];
    }
}

