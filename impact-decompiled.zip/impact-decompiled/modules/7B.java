/* ==========================================================================
 * MODULE: Randomizer
 * CATEGORY (inferred): Player
 * DESCRIPTION: Randomly switch between hotbar slots
 * OBFUSCATED CLASS: net.impactclient.7B
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.ArrayList;
import java.util.Random;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.2w$6X;
import net.impactclient.34R;
import net.impactclient.34X;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3sh;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7B
extends 3X
implements 34R {
    public static final boolean \u200e\u200d\u200b\u2008\u2004;
    private static final String[] e;
    @EventHandler
    private final Listener<3sh> 4;
    private static final String[] d;
    private 1P[] 2;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7B.\u200e\u200d\u200b\u2008\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1291580247 ^ (long)1291571028)) & (int)((long)-630733319 ^ (long)-630769146);
            if (var9_2) ** GOTO lbl-1000
            if (7B.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7B.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1240339079 ^ (long)1240339079)] & (int)((long)174481865 ^ (long)174481718)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1498876579 ^ (long)-1498876470);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)103407862 ^ (long)103407617);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-1937300312 ^ (long)-1937300452);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)871594099 ^ (long)871594126);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1811192945 ^ (long)-1811192949);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)634429740 ^ (long)634429855);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1434097876 ^ (long)-1434097754);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-118589241 ^ (long)-118589305);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)81308538 ^ (long)81308632);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)313426055 ^ (long)313425992);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1738855083 ^ (long)-1738855165);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1340722993 ^ (long)-1340722966);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-70737103 ^ (long)-70737135);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-660152407 ^ (long)-660152568);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1759033198 ^ (long)1759033089);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1576067344 ^ (long)1576067388);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1802984845 ^ (long)1802984801);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1632117585 ^ (long)-1632117546);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1435277070 ^ (long)-1435277210);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1073928797 ^ (long)1073928788);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1735921676 ^ (long)-1735921718);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1235843863 ^ (long)1235844077);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)720173786 ^ (long)720173742);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1554419992 ^ (long)-1554420178);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)934538080 ^ (long)934538029);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1009629795 ^ (long)1009629729);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1068401240 ^ (long)-1068401204);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1014434952 ^ (long)1014434909);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)90985172 ^ (long)90984964);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-161703618 ^ (long)-161703448);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-201049162 ^ (long)-201049285);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1949743482 ^ (long)1949743419);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1866235121 ^ (long)1866234911);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-1768503068 ^ (long)-1768503255);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1393566836 ^ (long)1393566929);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1952354839 ^ (long)1952355007);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1946888968 ^ (long)-1946889215);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1728496798 ^ (long)1728496679);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1629701311 ^ (long)1629701365);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1081287424 ^ (long)-1081287205);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-793779777 ^ (long)-793779843);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)2062502052 ^ (long)2062502049);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-2042415021 ^ (long)-2042414906);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1962518393 ^ (long)-1962518407);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1119311472 ^ (long)1119311577);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1955915962 ^ (long)-1955915847);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-10805142 ^ (long)-10805126);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-590286163 ^ (long)-590286319);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)2098386608 ^ (long)2098386676);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)394469744 ^ (long)394469752);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)2139115966 ^ (long)2139115833);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-140248916 ^ (long)-140248928);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)431536151 ^ (long)431536269);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1459783203 ^ (long)-1459783363);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1124874136 ^ (long)-1124874202);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1838388548 ^ (long)1838388529);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1611193271 ^ (long)-1611193227);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)2146479221 ^ (long)2146479162);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-895951562 ^ (long)-895951616);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1470560931 ^ (long)-1470560815);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)304626396 ^ (long)304626288);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-634456748 ^ (long)-634456709);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1143832563 ^ (long)1143832421);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-408633727 ^ (long)-408633741);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-725153096 ^ (long)-725153133);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1814463868 ^ (long)1814463815);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-837150321 ^ (long)-837150225);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-830804545 ^ (long)-830804548);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-703217199 ^ (long)-703217254);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1079294012 ^ (long)1079294043);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1308253565 ^ (long)-1308253447);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)152856789 ^ (long)152856588);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1434539217 ^ (long)-1434539042);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)213361832 ^ (long)213361794);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)348904578 ^ (long)348904545);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1213005849 ^ (long)-1213005837);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-224212243 ^ (long)-224212250);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1984016426 ^ (long)-1984016405);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-164053145 ^ (long)-164053118);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1669913582 ^ (long)-1669913529);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1730346247 ^ (long)1730346453);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-49106442 ^ (long)-49106572);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1885472473 ^ (long)-1885472508);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)1406236433 ^ (long)1406236500);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1571023677 ^ (long)1571023696);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1861637869 ^ (long)-1861637767);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1974433422 ^ (long)1974433287);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1764000103 ^ (long)1764000163);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)921506643 ^ (long)921506641);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)680646104 ^ (long)680645955);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-57530147 ^ (long)-57530277);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1030484972 ^ (long)1030484929);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1440435238 ^ (long)-1440435340);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)971713728 ^ (long)971713544);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-441948736 ^ (long)-441948737);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-557958740 ^ (long)-557958659);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)248843533 ^ (long)248843737);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-2097073991 ^ (long)-2097074164);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)240594661 ^ (long)240594533);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)939197251 ^ (long)939197194);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-421085796 ^ (long)-421085778);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)231650146 ^ (long)231650129);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1882270432 ^ (long)1882270214);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)891433623 ^ (long)891433617);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1896385917 ^ (long)1896385834);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1294468712 ^ (long)-1294468737);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)2011672970 ^ (long)2011672935);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1753278498 ^ (long)1753278669);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)795481794 ^ (long)795481673);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1664470124 ^ (long)-1664470038);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-1549869744 ^ (long)-1549869762);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)917060235 ^ (long)917060261);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)888037308 ^ (long)888037290);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-2003403918 ^ (long)-2003403928);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1915353113 ^ (long)-1915353321);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1895138331 ^ (long)-1895138437);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)791559392 ^ (long)791559367);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1611994418 ^ (long)-1611994515);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-2007272397 ^ (long)-2007272312);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-98954693 ^ (long)-98954561);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1289041784 ^ (long)-1289041899);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)341308062 ^ (long)341308092);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-666944510 ^ (long)-666944326);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1822429443 ^ (long)1822429492);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)854718138 ^ (long)854718205);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1197775065 ^ (long)-1197775026);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1776581329 ^ (long)1776581329);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-529952049 ^ (long)-529952198);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1634448883 ^ (long)-1634448802);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-717229218 ^ (long)-717229258);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)282120252 ^ (long)282120212);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)219657171 ^ (long)219657134);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1101643933 ^ (long)1101643968);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-704211920 ^ (long)-704211858);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)213815337 ^ (long)213815407);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)648690102 ^ (long)648690108);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1417357193 ^ (long)-1417357260);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)172672104 ^ (long)172672178);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)858494965 ^ (long)858494749);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)747480596 ^ (long)747480755);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)2004765576 ^ (long)2004765668);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1761263725 ^ (long)-1761263703);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1369154119 ^ (long)1369154239);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-423395253 ^ (long)-423395271);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)593676416 ^ (long)593676362);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1624014746 ^ (long)1624014628);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)251309462 ^ (long)251309337);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)836941809 ^ (long)836941631);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-36077906 ^ (long)-36077990);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-296872278 ^ (long)-296872257);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1514438021 ^ (long)1514437972);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-91152950 ^ (long)-91153061);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1814183249 ^ (long)1814183278);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1962472849 ^ (long)1962472860);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)2094549721 ^ (long)2094549645);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1487186650 ^ (long)1487186470);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-454475045 ^ (long)-454475134);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-894786565 ^ (long)-894786718);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1079375146 ^ (long)-1079375120);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1298761658 ^ (long)1298761636);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-2122752474 ^ (long)-2122752445);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-460031789 ^ (long)-460031980);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-281525842 ^ (long)-281525913);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1558963740 ^ (long)1558963715);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1044325279 ^ (long)1044325252);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1563949638 ^ (long)1563949741);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1574123935 ^ (long)-1574123948);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)308550390 ^ (long)308550264);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1032967069 ^ (long)1032966936);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1111317222 ^ (long)1111317029);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1688388640 ^ (long)-1688388794);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1811178959 ^ (long)-1811179000);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-2011266458 ^ (long)-2011266481);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1310190096 ^ (long)-1310190190);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1250040631 ^ (long)-1250040820);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1833168891 ^ (long)-1833168797);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)75164731 ^ (long)75164922);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-543823333 ^ (long)-543823160);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)2059992837 ^ (long)2059992905);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-322616189 ^ (long)-322616280);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1242290376 ^ (long)1242290356);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-216736620 ^ (long)-216736635);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)503223716 ^ (long)503223604);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1395361676 ^ (long)1395361617);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1832381365 ^ (long)1832381289);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1373687411 ^ (long)-1373687363);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1369159451 ^ (long)-1369159530);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1337286155 ^ (long)1337286295);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1239933813 ^ (long)1239933881);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-263893203 ^ (long)-263893034);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1389116421 ^ (long)-1389116446);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-2057110542 ^ (long)-2057110698);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1023779463 ^ (long)1023779519);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-689488570 ^ (long)-689488595);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1280009350 ^ (long)-1280009422);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)633403425 ^ (long)633403507);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)411202184 ^ (long)411202101);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)372156752 ^ (long)372156749);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1355494291 ^ (long)1355494372);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)430493118 ^ (long)430493020);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1311629124 ^ (long)1311629307);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1412737665 ^ (long)1412737682);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1230176843 ^ (long)1230176996);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)422893502 ^ (long)422893414);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1025191440 ^ (long)1025191447);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-847168395 ^ (long)-847168471);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1282656448 ^ (long)1282656415);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-919871567 ^ (long)-919871709);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1928617602 ^ (long)-1928617569);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)957761839 ^ (long)957762031);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)934442082 ^ (long)934442120);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1786344309 ^ (long)1786344348);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-663600235 ^ (long)-663600146);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1956859860 ^ (long)-1956859869);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1826705626 ^ (long)-1826705602);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-235518838 ^ (long)-235518802);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-602031191 ^ (long)-602031330);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-887820639 ^ (long)-887820651);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)22204436 ^ (long)22204535);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1052495666 ^ (long)-1052495745);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1656322611 ^ (long)1656322797);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1480477510 ^ (long)1480477662);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1699216365 ^ (long)-1699216283);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1853494384 ^ (long)-1853494351);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)376685859 ^ (long)376686076);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-2005747784 ^ (long)-2005747960);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)592978202 ^ (long)592978241);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1023632227 ^ (long)-1023632185);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1605976710 ^ (long)-1605976624);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1201046052 ^ (long)-1201046132);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1932271005 ^ (long)1932270896);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1854315324 ^ (long)-1854315309);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1219869658 ^ (long)-1219869455);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-844321166 ^ (long)-844321156);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)36870857 ^ (long)36870841);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1442020297 ^ (long)-1442020241);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-2048097059 ^ (long)-2048097060);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-506199294 ^ (long)-506199052);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-510298951 ^ (long)-510299022);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)599634917 ^ (long)599634757);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1484156558 ^ (long)1484156671);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1761919757 ^ (long)1761919927);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1335405286 ^ (long)1335405140);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1806188870 ^ (long)-1806188983);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-276945922 ^ (long)-276946079);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)906881679 ^ (long)906881726);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-2113126812 ^ (long)-2113126784);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-584551911 ^ (long)-584551782);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-699194896 ^ (long)-699195037);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)804971886 ^ (long)804971890);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)931767316 ^ (long)931767404);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1097183679 ^ (long)1097183710);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1712886414 ^ (long)-1712886285);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1889817652 ^ (long)-1889817634);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1761816599 ^ (long)1761816737);
                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1889088331 ^ (long)1889088451);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1780460058 ^ (long)1780460261)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1598262847 ^ (long)1598255552)) >>> (int)((long)953789320 ^ (long)953789312)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)371807454 ^ (long)371807454);
            if (!7B.\u200e\u200d\u200b\u2008\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)258015185 ^ (long)258015187);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1386780058 ^ (long)-1386780059) | var5_6 << (int)((long)1197416216 ^ (long)1197416221)) ^ var3_4[var7_8]) & (int)((long)-644517141 ^ (long)-644517356);
                    if (7B.\u200e\u200d\u200b\u2008\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1160400324 ^ (long)1160400327) | var6_7 << (int)((long)258427554 ^ (long)258427559)) ^ var3_4[var7_8]) & (int)((long)-391474943 ^ (long)-391474690);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7B.e[var2_3] = new String(var3_4).intern();
        }
        return 7B.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7B.\u200e\u200d\u200b\u2008\u2004;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)971330863 ^ (long)971330858)];
            if (var7) break block23;
            var3_2 = (int)((long)777498118 ^ (long)777498118);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u64af\u4de2\u5eb3\u5675\u64cb\u4ded\u5e8b\u5622\u642c\u4d69\u5ee7\u5604\u6441\u4dc3\u5e44\u56af\u6471\u4d43\u5e8b\u5661\u64db\u4dcb\u5e7e\u56c1\u6401\u4d85\u5e10\u5651\u6437\u4d4c\u5e13\u5611\u648c\u4da1\u5eea", -759741467);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1865461902 ^ (long)-1865461899);
            if (var7) break block23;
            var0_6 = (int)((long)423627504 ^ (long)-423627505);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-853247809 ^ (long)-853247811);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1995123880 ^ (long)1995123879);
                    if (7B.\u200e\u200d\u200b\u2008\u2004) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7B.\u200e\u200d\u200b\u2008\u2004) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ue1a5\uc807\udbb8\ud309\ue1f4\uc8b2\udbe3\ud38b\ue118\uc88a\udb3a\ud34f\ue167\uc823\udba6\ud3d2\ue177\uc8e4\udb93\ud34d\ue1db\uc85f\udbd6\ud375\ue19d\uc83e\udb2f\ud319\ue131\uc866\udb48\ud366\ue1c7\uc81e\udb6b\ud3c8\ue109\uc81e\udb57\ud33f\ue1f3\uc836\udb52\ud3f4\ue11e\uc85b\udbf6", 1022740139);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-749024252 ^ (long)-749024242);
                            var0_6 = (int)((long)-1709493796 ^ (long)1709493795);
                            while (true) {
                                v0 = (int)((long)1734501126 ^ (long)1734501186);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1379127097 ^ (long)-1379127097);
                                if (!7B.\u200e\u200d\u200b\u2008\u2004) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7B.\u200e\u200d\u200b\u2008\u2004) ** continue;
                                throw null;
                            }
                            7B.d = var5_1;
                            7B.e = new String[(int)((long)976121082 ^ (long)976121087)];
                            if (!7B.\u200e\u200d\u200b\u2008\u2004) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1212539185 ^ (long)-1212539185);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1018956719 ^ (long)1018956718)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)226611325 ^ (long)226611322)) {
                                case 0: {
                                    v15 = (int)((long)477191628 ^ (long)477191631);
                                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)1204556133 ^ (long)1204556084);
                                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1850158986 ^ (long)1850159061);
                                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)646599280 ^ (long)646599292);
                                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1259528773 ^ (long)-1259528756);
                                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1909255457 ^ (long)-1909255477);
                                    if (!7B.\u200e\u200d\u200b\u2008\u2004) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1762100457 ^ (long)1762100436);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7B.\u200e\u200d\u200b\u2008\u2004);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    public 7B() {
        boolean bl = \u200e\u200d\u200b\u2008\u2004;
        super(7B.b((int)((long)1378693133 ^ (long)-1378683917), (int)((long)1986035299 ^ (long)-1986031896)) /* "Randomizer" */, 7B.b((int)((long)1632610375 ^ (long)-1632605250), (int)((long)292160785 ^ (long)292170401)) /* "Randomly switch between hotbar slots" */);
        this.4 = new Listener(arrayList -> {
            String[] stringArray;
            boolean bl;
            block11: {
                block10: {
                    bl = \u200e\u200d\u200b\u2008\u2004;
                    if (bl) return;
                    stringArray = 3e.5();
                    if (bl || bl) return;
                    if (7B.3.s == null) break block10;
                    if (bl) return;
                    if (((3sh)((Object)arrayList)).5 == EventState.PRE) break block11;
                    if (bl) return;
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            arrayList = new ArrayList();
            if (bl || bl) return;
            int n = (int)((long)-2022262758 ^ (long)-2022262758);
            if (bl) return;
            while (!bl) {
                boolean bl2;
                if (n < (int)((long)1704568725 ^ (long)1704568732)) {
                    if (bl || bl) return;
                    bl2 = this.2[n].2;
                    if (stringArray == null) {
                        if (bl2) {
                            if (bl || bl) return;
                            arrayList.add(n);
                            if (bl) return;
                        }
                        if (bl) return;
                        ++n;
                        if (bl) return;
                        if (stringArray == null) continue;
                        if (bl) return;
                    }
                } else {
                    if (bl) return;
                    bl2 = arrayList.isEmpty();
                }
                if (bl2) {
                    if (bl || bl) return;
                    this.1((boolean)((long)1827800951 ^ (long)1827800951));
                    if (bl || bl) return;
                    return;
                }
                if (bl) return;
                7B.3.s.bm.d = (Integer)arrayList.get(new Random().nextInt(arrayList.size()));
                if (!bl && !bl) return;
            }
        }, new Predicate[(int)((long)1402561836 ^ (long)1402561836)]);
        this.2 = new 1P[(int)((long)1151158923 ^ (long)1151158914)];
        String[] stringArray = 3e.5();
        for (int i = (int)((long)1456442251 ^ (long)1456442251); i < (int)((long)1231835643 ^ (long)1231835634); ++i) {
            Boolean bl2 = Boolean.TRUE;
            34X x2 = (34X)((34X)((34X)this.4().5(7B.b((int)((long)-775691693 ^ (long)775692718), (int)((long)-1167922360 ^ (long)-1167938678)) /* "Hotbar " */ + (i + (int)((long)539759890 ^ (long)539759891)))).7(7B.b((int)((long)285628610 ^ (long)-285631682), (int)((long)-1442123883 ^ (long)-1442130611)) /* "hotbar" */ + (i + (int)((long)1853395652 ^ (long)1853395653)))).1(7B.b((int)((long)-1115004646 ^ (long)1115005669), (int)((long)1455230293 ^ (long)-1455248386)) /* "Include hotbar slot " */ + (i + (int)((long)-1271869091 ^ (long)-1271869092)));
            ((34X)((34X)((34X)this.4().5(7B.b((int)((long)-775691693 ^ (long)775692718), (int)((long)-1167922360 ^ (long)-1167938678)) /* "Hotbar " */ + (i + (int)((long)539759890 ^ (long)539759891)))).7(7B.b((int)((long)285628610 ^ (long)-285631682), (int)((long)-1442123883 ^ (long)-1442130611)) /* "hotbar" */ + (i + (int)((long)1853395652 ^ (long)1853395653)))).1(7B.b((int)((long)-1115004646 ^ (long)1115005669), (int)((long)1455230293 ^ (long)-1455248386)) /* "Include hotbar slot " */ + (i + (int)((long)-1271869091 ^ (long)-1271869092)))).7 = bl2;
            this.2[i] = (1P)x2.5();
            if (stringArray == null) continue;
        }
    }
}

