/* ==========================================================================
 * MODULE: High Jump
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Change the jump height multiplier
 * OBFUSCATED CLASS: net.impactclient.0m
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1K;
import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.4m;
import net.impactclient.9x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0m
extends 3X
implements 34B {
    private static final String[] d;
    public static final boolean \u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005;
    @EventHandler
    private final Listener<9x> 4;
    private 1K 8;
    private static final String[] e;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1607669039 ^ (long)1607669034)];
            if (var7) break block23;
            var3_2 = (int)((long)1967496998 ^ (long)1967496998);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\uab76\u83a7\u90de\u985a\uab16\u83fa\u90d4\u98d2\uab14\u83d9\u9060\u9818\uabe2\u833e\u909e\u9821\uab2c\u833b\u9064\u98c2\uab41\u837f\u90d2\u9853\uab87\u8322\u9059\u9835\uab03\u8337\u9086", 1495109087);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1667352399 ^ (long)1667352389);
            if (var7) break block23;
            var0_6 = (int)((long)426900707 ^ (long)-426900708);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1639090356 ^ (long)-1639090415);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1062927100 ^ (long)1062927099);
                    if (0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u1997\u31f3\u2232\u2a42\u191f\u3183\u2240\u2a61\u1978\u3130\u2211\u2afd\u1930\u31f4\u226d\u2a69\u1976\u313e\u22f6\u2a01\u19bd\u3116\u2289\u2ab3\u197c\u31e7\u2224\u2a10\u1989\u3158\u22ac\u2ab8\u19d0\u31c6\u22e2\u2ae4\u192a\u318b\u22d0\u2a58\u1959\u316c\u227c\u2a94\u19d6\u3138\u228f\u2acf\u19d9\u3103\u223b\u2a7f\u1903\u3160\u224d\u2adb\u19b1\u316d\u2247\u2a57\u196e\u31ae\u22c4\u2afb\u1935\u31a5\u2230\u2a86\u1902\u31c1\u2299\u2a88\u197e\u3166\u2260\u2a01\u199b\u3171", -1059045565);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-486144842 ^ (long)-486144873);
                            var0_6 = (int)((long)839678454 ^ (long)-839678455);
                            while (true) {
                                v0 = (int)((long)-1659533071 ^ (long)-1659533057);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1932736715 ^ (long)-1932736715);
                                if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) ** continue;
                                throw null;
                            }
                            0m.d = var5_1;
                            0m.e = new String[(int)((long)-678666829 ^ (long)-678666826)];
                            if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1353265737 ^ (long)1353265737);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)705350194 ^ (long)705350195)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1568280831 ^ (long)-1568280826)) {
                                case 0: {
                                    v15 = (int)((long)869341544 ^ (long)869341527);
                                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)2016028442 ^ (long)2016028474);
                                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)1159864207 ^ (long)1159864222);
                                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-638310004 ^ (long)-638309969);
                                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)233985342 ^ (long)233985364);
                                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-42244906 ^ (long)-42244918);
                                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1887661731 ^ (long)1887661722);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1096060041 ^ (long)-1096077124)) & (int)((long)1028469977 ^ (long)1028508454);
            if (var9_2) ** GOTO lbl-1000
            if (0m.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0m.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1579298006 ^ (long)-1579298006)] & (int)((long)1862647767 ^ (long)1862647592)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1365146620 ^ (long)1365146521);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1789565124 ^ (long)-1789565184);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-359357017 ^ (long)-359356980);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-125503592 ^ (long)-125503575);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1601056941 ^ (long)-1601056843);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-605879090 ^ (long)-605879155);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)97344936 ^ (long)97344880);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1933961675 ^ (long)1933961617);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)918695151 ^ (long)918695053);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-105630117 ^ (long)-105629957);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-724845689 ^ (long)-724845687);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)259564993 ^ (long)259565043);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-442052371 ^ (long)-442052412);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)304780909 ^ (long)304780871);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1541460542 ^ (long)1541460490);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-1763135913 ^ (long)-1763135778);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)593072700 ^ (long)593072867);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-975298603 ^ (long)-975298576);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)672442366 ^ (long)672442211);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1587360121 ^ (long)-1587360184);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)371935446 ^ (long)371935351);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1899388368 ^ (long)1899388308);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)2069194981 ^ (long)2069194912);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-2008041367 ^ (long)-2008041395);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1815322343 ^ (long)-1815322290);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1679573254 ^ (long)1679573332);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-19728612 ^ (long)-19728599);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-266096354 ^ (long)-266096225);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)722353389 ^ (long)722353219);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1639365834 ^ (long)1639365857);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)805277213 ^ (long)805277247);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)262720843 ^ (long)262721016);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-708118649 ^ (long)-708118755);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1296996161 ^ (long)1296996214);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)361875461 ^ (long)361875654);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1863872587 ^ (long)1863872744);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)262757533 ^ (long)262757511);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1602256042 ^ (long)1602255981);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-2130636903 ^ (long)-2130636937);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1946999512 ^ (long)-1946999525);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-244621114 ^ (long)-244621244);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1463272923 ^ (long)-1463272808);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)689260197 ^ (long)689260034);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1574316980 ^ (long)-1574316890);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1024062178 ^ (long)1024062124);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-374514314 ^ (long)-374514245);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1268478393 ^ (long)-1268478280);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)749551884 ^ (long)749551917);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-638653578 ^ (long)-638653620);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1475513086 ^ (long)-1475512879);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-445426978 ^ (long)-445427110);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-11307331 ^ (long)-11307321);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-201485281 ^ (long)-201485098);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1779979903 ^ (long)1779979841);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1727946686 ^ (long)1727946530);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)580561365 ^ (long)580561219);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-43930460 ^ (long)-43930583);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1031076912 ^ (long)-1031077107);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)928615694 ^ (long)928615865);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-2079793709 ^ (long)-2079793700);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1581054717 ^ (long)1581054675);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-203827773 ^ (long)-203827936);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1492119970 ^ (long)-1492119995);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1391147538 ^ (long)1391147628);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1592804704 ^ (long)-1592804746);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1933046900 ^ (long)-1933047021);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1128743595 ^ (long)1128743602);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)559798486 ^ (long)559798442);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-921624544 ^ (long)-921624402);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1139727667 ^ (long)-1139727866);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)597923976 ^ (long)597924032);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1964894289 ^ (long)-1964894460);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)922670409 ^ (long)922670344);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1137208762 ^ (long)1137208738);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-630313788 ^ (long)-630313853);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1006938817 ^ (long)1006938734);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1137971514 ^ (long)1137971688);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-927968731 ^ (long)-927968526);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1930439865 ^ (long)1930439828);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1101533600 ^ (long)1101533617);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-33504198 ^ (long)-33504071);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-2119917175 ^ (long)-2119917111);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)583455512 ^ (long)583455720);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1880309515 ^ (long)-1880309660);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1845360116 ^ (long)1845360079);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)817137485 ^ (long)817137502);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1758218324 ^ (long)-1758218267);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1169780100 ^ (long)1169780186);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-2038793924 ^ (long)-2038793751);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1450141396 ^ (long)1450141330);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1297003780 ^ (long)-1297004015);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)424214089 ^ (long)424214080);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1773733786 ^ (long)1773733634);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-2003888892 ^ (long)-2003888861);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1560160968 ^ (long)1560160832);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1022847223 ^ (long)-1022847055);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)801179417 ^ (long)801179591);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)2091016600 ^ (long)2091016482);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)209787714 ^ (long)209787711);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-819053795 ^ (long)-819053593);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-1170088277 ^ (long)-1170088326);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1790787584 ^ (long)-1790787546);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1784697906 ^ (long)-1784697894);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1131603488 ^ (long)1131603627);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)256363218 ^ (long)256363052);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)986297390 ^ (long)986297401);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)2119859470 ^ (long)2119859634);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)491111896 ^ (long)491111728);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)2006378680 ^ (long)2006378664);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1892603558 ^ (long)1892603638);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)745433786 ^ (long)745433749);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1879681439 ^ (long)1879681380);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1284252741 ^ (long)1284252844);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-404028375 ^ (long)-404028189);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-99060686 ^ (long)-99060556);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)532551643 ^ (long)532551607);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1075246310 ^ (long)-1075246229);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1592143690 ^ (long)1592143786);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-442206378 ^ (long)-442206427);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)2081165144 ^ (long)2081165221);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)234407298 ^ (long)234407386);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)392961274 ^ (long)392961056);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)463999106 ^ (long)463999079);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-882539251 ^ (long)-882539013);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-2118569063 ^ (long)-2118569084);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)308606350 ^ (long)308606364);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1942759832 ^ (long)-1942759912);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1862720491 ^ (long)1862720349);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1329103970 ^ (long)1329103963);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-944087938 ^ (long)-944087860);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-172129134 ^ (long)-172129030);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)803630012 ^ (long)803629902);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1540504624 ^ (long)1540504743);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1538506803 ^ (long)-1538506848);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1241967623 ^ (long)-1241967732);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-171271926 ^ (long)-171271821);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1177334445 ^ (long)-1177334518);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-858276907 ^ (long)-858277019);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-869873606 ^ (long)-869873599);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)954458705 ^ (long)954458760);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-14430854 ^ (long)-14430726);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1632183781 ^ (long)-1632183778);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1100043562 ^ (long)-1100043522);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1640471919 ^ (long)-1640471813);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1606710430 ^ (long)-1606710288);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1313315141 ^ (long)-1313315273);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1034969551 ^ (long)1034969540);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)802232628 ^ (long)802232663);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-503442117 ^ (long)-503442076);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1099009478 ^ (long)1099009482);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1757881946 ^ (long)-1757881902);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-661160625 ^ (long)-661160627);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-226073469 ^ (long)-226073396);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)756341044 ^ (long)756341233);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1068098375 ^ (long)1068098521);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-44790641 ^ (long)-44790685);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)882122289 ^ (long)882122335);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1574161515 ^ (long)-1574161419);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1315932482 ^ (long)-1315932554);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1345965967 ^ (long)-1345966050);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1842148610 ^ (long)1842148733);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1366708234 ^ (long)1366708390);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-224918482 ^ (long)-224918469);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1848890283 ^ (long)1848890239);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1976310479 ^ (long)-1976310287);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-502735770 ^ (long)-502735821);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1184183502 ^ (long)-1184183393);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)310344189 ^ (long)310344162);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-920232031 ^ (long)-920232134);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)568029074 ^ (long)568028986);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-328766102 ^ (long)-328765954);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-2090000856 ^ (long)-2090000775);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1274938788 ^ (long)1274938709);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1168780883 ^ (long)1168780995);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)722282500 ^ (long)722282658);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)937099719 ^ (long)937099526);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)31448744 ^ (long)31448715);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1905484182 ^ (long)1905484181);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-309807180 ^ (long)-309807166);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-877774910 ^ (long)-877775067);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1992721706 ^ (long)1992721709);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)2018918190 ^ (long)2018918191);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-529939916 ^ (long)-529939964);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1482216024 ^ (long)-1482216020);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)556768703 ^ (long)556768712);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1147931862 ^ (long)-1147931837);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1942938450 ^ (long)1942938595);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-896531599 ^ (long)-896531531);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1037127209 ^ (long)-1037127319);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-727540524 ^ (long)-727540710);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1340893037 ^ (long)1340893019);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)2126832485 ^ (long)2126832636);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-25245519 ^ (long)-25245644);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)128960628 ^ (long)128960546);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1722868914 ^ (long)-1722868799);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1217557328 ^ (long)1217557466);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)520227140 ^ (long)520227162);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)2011346610 ^ (long)2011346590);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)2027719281 ^ (long)2027719249);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1843969866 ^ (long)-1843969861);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1777578022 ^ (long)-1777578051);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1469243165 ^ (long)1469243247);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-333674739 ^ (long)-333674672);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-2094655675 ^ (long)-2094655562);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)124658790 ^ (long)124658800);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-407978039 ^ (long)-407978033);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1274764374 ^ (long)-1274764341);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-618174313 ^ (long)-618174353);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)142335284 ^ (long)142335371);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1449311904 ^ (long)1449311819);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1202375597 ^ (long)-1202375650);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1649054352 ^ (long)1649054213);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1926563886 ^ (long)1926564042);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-455526749 ^ (long)-455526828);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)136835066 ^ (long)136834876);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-513202762 ^ (long)-513202700);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1422267952 ^ (long)-1422268020);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-99248112 ^ (long)-99247964);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1643243586 ^ (long)-1643243675);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1361030164 ^ (long)1361030174);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1048223588 ^ (long)-1048223717);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1448325369 ^ (long)-1448325313);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-571659012 ^ (long)-571659069);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)259298868 ^ (long)259299064);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-591467135 ^ (long)-591467062);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)77608711 ^ (long)77608946);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)672369186 ^ (long)672369394);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1706973583 ^ (long)1706973485);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1270828685 ^ (long)-1270828644);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1059115008 ^ (long)-1059114932);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1765098535 ^ (long)1765098747);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)373478995 ^ (long)373479104);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1543317697 ^ (long)-1543317562);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)85306750 ^ (long)85306722);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-513899373 ^ (long)-513899285);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-436491876 ^ (long)-436491906);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-364837682 ^ (long)-364837838);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1610785615 ^ (long)1610785563);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-778617297 ^ (long)-778617138);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1761501195 ^ (long)1761501374);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-933210270 ^ (long)-933210311);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-952006507 ^ (long)-952006415);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)716613621 ^ (long)716613468);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1873266388 ^ (long)-1873266295);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)909777469 ^ (long)909777559);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-655387369 ^ (long)-655387324);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-2054174429 ^ (long)-2054174429);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)552614850 ^ (long)552614656);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-346733609 ^ (long)-346733667);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-128679151 ^ (long)-128678998);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-457822004 ^ (long)-457822104);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-199413883 ^ (long)-199413875);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1753562515 ^ (long)-1753562613);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)413799451 ^ (long)413799586);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1230511275 ^ (long)1230511254);
                    if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-792590112 ^ (long)-792590316);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1768067913 ^ (long)-1768068024)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-241669803 ^ (long)-241658198)) >>> (int)((long)1620872893 ^ (long)1620872885)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-457418202 ^ (long)-457418202);
            if (!0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1600280085 ^ (long)1600280087);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)290750681 ^ (long)290750682) | var5_6 << (int)((long)-1384501444 ^ (long)-1384501447)) ^ var3_4[var7_8]) & (int)((long)488831792 ^ (long)488831951);
                    if (0m.\u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-56274672 ^ (long)-56274669) | var6_7 << (int)((long)1061649636 ^ (long)1061649633)) ^ var3_4[var7_8]) & (int)((long)62490070 ^ (long)62489897);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0m.e[var2_3] = new String(var3_4).intern();
        }
        return 0m.e[var2_3];
    }

    public 0m() {
        boolean bl = \u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005;
        super(0m.b((int)((long)1820313661 ^ (long)1820298228), (int)((long)116824620 ^ (long)116829761)) /* "High Jump" */, 0m.b((int)((long)-1351837601 ^ (long)-1351820393), (int)((long)1591932160 ^ (long)-1591924145)) /* "Change the jump height multiplier" */);
        this.8 = (1K)((34e)((34e)((34e)this.7().5(0m.b((int)((long)1152767149 ^ (long)1152751463), (int)((long)939748991 ^ (long)939737989)) /* "Multiplier" */)).7(0m.b((int)((long)980644390 ^ (long)980627949), (int)((long)-1843748322 ^ (long)1843743994)) /* "multiplier" */)).1(0m.b((int)((long)571793373 ^ (long)571776018), (int)((long)-333923380 ^ (long)333929716)) /* "The height multiplication factor for jumping" */)).3(1.0).2(10.0).5();
        this.4 = new Listener(x2 -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u200a\u2003\u200c\u2008\u200e\u200c\u2005\u2005;
                        if (bl || bl) break block2;
                        if (x2.0 != 0m.3.s) break block3;
                        if (bl || bl) break block2;
                        4m.1(0m.3.s.cC().c * this.8.1);
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-1922810949 ^ (long)-1922810949)]);
    }
}

