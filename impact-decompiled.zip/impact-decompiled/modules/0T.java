/* ==========================================================================
 * MODULE: Anti Hazard
 * CATEGORY (inferred): Misc
 * DESCRIPTION: Helps you avoid hazards
 * OBFUSCATED CLASS: net.impactclient.0T
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqa
 *  bye
 *  dci
 *  dde
 *  ddh
 *  dwu
 *  dzm
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  oj
 *  ta
 *  ta$a
 */
package net.impactclient;

import clientapi.load.mixin.7.2;
import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.34L;
import net.impactclient.34X;
import net.impactclient.3X;
import net.impactclient.4E;
import net.impactclient.4X;
import net.impactclient.8S;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0T
extends 3X
implements 34B {
    private static final String[] e;
    public 1P 6;
    private boolean 6K;
    public static final boolean \u2007;
    @EventHandler
    private final Listener<4E> 9;
    private boolean 0;
    public static ddh 7;
    public 1P 8;
    private 1P 2;
    @EventHandler
    private final Listener<4X> 4;
    public 1P 1;
    public static 0T 5;
    private static final String[] d;

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 0T.\u2007;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)-1367776641 ^ (long)-1367776655)];
            if (var7) break block25;
            var3_2 = (int)((long)1976495978 ^ (long)1976495978);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\u045e\u2cbc\u3fb2\u37c6\u04ea\u2cf7\u3f03\u378d\u047b\u2c75\u3f88\u37b7\u0465\u2c2a\u3f01\u3762\u0402\u2c54\u3f7d\u37e3\u042b\u2c09\u3f5e\u3721\u0451\u2c2f\u3f0c\u3772\u044a\u2ccd\u3fc4\u3765\u04fa\u2c20\u3f50\u3796\u0426\u2c16\u3fa1\u3741\u042e\u2cd7\u3f9d\u37e3\u04ae\u2cfb\u3f3d\u377f\u0407\u2c92\u3fb2\u37e8\u04cd\u2cdd\u3ffe\u3744\u0457\u2c45\u3f63\u3729\u0472\u2cbf\u3f83\u37d9\u04fb\u2c47\u3f52\u3751\u04be\u2c68\u3fac\u3770\u04c5\u2c0c\u3fc5\u3741\u04cb\u2ce1\u3fdd\u3705\u041d\u2cf8\u3ffc\u376c\u0437\u2c19\u3f4e\u375e\u046c\u2c3f\u3f1b\u373e\u04b0\u2c08\u3f54\u37d8\u048c\u2c70\u3f19\u372a\u04ec\u2c5a\u3fd8\u3734\u0429\u2c6b\u3fa6\u37f5\u04f6\u2c77\u3fed\u376b\u04da\u2c87\u3fbf\u37c8\u0460\u2c55\u3f7c\u374c\u0452\u2cd0\u3fde\u37c1\u0442\u2c3c\u3f06\u37d4\u0402\u2c29\u3f00\u37b0\u0495\u2c1d\u3f07\u3708\u0476\u2ce0\u3f13\u375b\u0462\u2c45\u3f01\u376b\u0494\u2c61\u3fd3\u3730\u04b5\u2caa\u3f15\u37c6\u0405\u2c72\u3f85\u375b\u04d1\u2caf\u3f97\u37ee\u041e\u2cb5\u3f9c\u373e\u047a\u2cbb\u3f62\u37ce\u04b8\u2c9b\u3f6c\u370e\u04dd\u2cc3\u3fc6\u37b8\u04ab\u2cde\u3fd1\u37e2\u049c\u2c04\u3fcc\u37f3\u0431\u2cea\u3f8e\u3720\u0474\u2ce6\u3f1a\u37c9\u04d0\u2cf2\u3f15\u3768\u0403\u2c10\u3f81\u3795\u04c8\u2c21\u3fa3\u3759\u0424\u2c8f\u3fb3\u37da\u04a2\u2ce4\u3f12", -1697701374);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)1643730617 ^ (long)1643730619);
            if (var7) break block25;
            var0_6 = (int)((long)-486710412 ^ (long)486710411);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)-790830356 ^ (long)-790830404);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)1749161777 ^ (long)-1749161778);
                        if (0T.\u2007) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!0T.\u2007) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\u91ea\ub94f\uaa4d\ua2c8\u9156\ub966\uaa36\ua2d0\u912d\ub982\uaac8\ua23c\u91ec\ub912\uaafd\ua2d3\u91a5\ub9b8\uaaa4\ua233\u917d\ub9a7\uaa81\ua286\u911d\ub9af\uaac3\ua2ce\u9121\ub902\uaa17\ua287\u91c2\ub93e\uaa15\ua217\u91cc\ub964\uaabe\ua24d\u918f\ub914\uaaeb\ua2d9\u9122\ub9fe\uaaee\ua29d\u913f\ub98c", 126334768);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)-2004832209 ^ (long)-2004832224);
                                var0_6 = (int)((long)1726853136 ^ (long)-1726853137);
                                while (true) {
                                    v0 = (int)((long)658390283 ^ (long)658390379);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)-734828430 ^ (long)-734828430);
                                    if (!0T.\u2007) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!0T.\u2007) ** continue;
                                    throw null;
                                }
                                0T.d = var5_1;
                                0T.e = new String[(int)((long)679808996 ^ (long)679809002)];
                                if (0T.\u2007) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)1791534473 ^ (long)1791534473);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)2047871397 ^ (long)2047871396)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-2054563620 ^ (long)-2054563621)) {
                                    case 0: {
                                        v15 = (int)((long)288576505 ^ (long)288576479);
                                        if (!0T.\u2007) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)716696853 ^ (long)716696944);
                                        if (!0T.\u2007) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)1576793666 ^ (long)1576793676);
                                        if (!0T.\u2007) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)-12700549 ^ (long)-12700649);
                                        if (!0T.\u2007) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)-1651234921 ^ (long)-1651234897);
                                        if (!0T.\u2007) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)-1486170238 ^ (long)-1486170157);
                                        if (!0T.\u2007) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)1774300709 ^ (long)1774300756);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!0T.\u2007);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                0T.7 = dde.a((dci)new dci(0.0625, 0.0, 0.0625, 0.9375, 0.25, 0.9375));
                break;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2007;
                    if (bl || bl) break block2;
                    if (0T.3.s == null) break block3;
                    if (bl || bl) break block2;
                    0T.3.s.e.a((oj)new ta((aqa)0T.3.s, ta.a.b));
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0T.\u2007;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1717063845 ^ (long)1717068205)) & (int)((long)1735101618 ^ (long)1735095117);
            if (var9_2) ** GOTO lbl-1000
            if (0T.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0T.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)1924846497 ^ (long)1924846497)] & (int)((long)-2035555994 ^ (long)-2035555943)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1270462881 ^ (long)-1270462783);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1243009175 ^ (long)1243009241);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)501014610 ^ (long)501014693);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)633270707 ^ (long)633270615);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1857115701 ^ (long)-1857115728);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1598721114 ^ (long)-1598721028);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1408007772 ^ (long)-1408007709);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1708296048 ^ (long)-1708295995);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)913048715 ^ (long)913048665);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-15735403 ^ (long)-15735371);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1600577278 ^ (long)1600577175);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1559878920 ^ (long)1559878941);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-429207645 ^ (long)-429207761);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-693568472 ^ (long)-693568406);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1285816646 ^ (long)-1285816759);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-618013558 ^ (long)-618013603);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1862103038 ^ (long)-1862102972);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)112562094 ^ (long)112562137);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)745210171 ^ (long)745210186);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-29483208 ^ (long)-29483210);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)430962361 ^ (long)430962191);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-935354863 ^ (long)-935354752);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1384640526 ^ (long)1384640681);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1320659354 ^ (long)1320659390);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-366765366 ^ (long)-366765499);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1940872477 ^ (long)1940872609);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-2033524275 ^ (long)-2033524366);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-735892816 ^ (long)-735892948);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-235185432 ^ (long)-235185478);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-150609397 ^ (long)-150609336);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1077924223 ^ (long)-1077924335);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1608604134 ^ (long)1608604117);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1981367912 ^ (long)-1981367924);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1211030435 ^ (long)1211030519);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1010016967 ^ (long)-1010016871);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)538676240 ^ (long)538676405);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)315155572 ^ (long)315155543);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1104833389 ^ (long)-1104833413);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1490392444 ^ (long)-1490392323);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)301761608 ^ (long)301761684);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)498463439 ^ (long)498463232);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)843213815 ^ (long)843213818);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)728747364 ^ (long)728747387);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1489743825 ^ (long)1489743830);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)331319170 ^ (long)331319219);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)705594740 ^ (long)705594717);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-482497441 ^ (long)-482497505);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-2021509647 ^ (long)-2021509690);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-855301775 ^ (long)-855301861);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1956556827 ^ (long)-1956556823);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)826230412 ^ (long)826230392);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1640659933 ^ (long)1640659797);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)904757600 ^ (long)904757674);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)186491694 ^ (long)186491858);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1637391450 ^ (long)-1637391553);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1796155070 ^ (long)1796155127);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-2098976182 ^ (long)-2098976134);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)2104140606 ^ (long)2104140563);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-656959429 ^ (long)-656959369);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)2043425915 ^ (long)2043425826);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1662244350 ^ (long)-1662244133);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1739058747 ^ (long)1739058872);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1570330338 ^ (long)1570330200);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1602558542 ^ (long)-1602558467);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)860785422 ^ (long)860785518);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1378087681 ^ (long)1378087915);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1692065438 ^ (long)-1692065459);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1424259141 ^ (long)-1424259108);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1349704427 ^ (long)-1349704260);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1783385316 ^ (long)1783385224);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1461388148 ^ (long)1461388196);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1214412639 ^ (long)-1214412639);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)559381512 ^ (long)559381709);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1527885642 ^ (long)1527885719);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1345506403 ^ (long)1345506530);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1892453790 ^ (long)1892453734);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1644922866 ^ (long)-1644922849);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1353754320 ^ (long)1353754342);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1164370190 ^ (long)-1164370348);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-24266540 ^ (long)-24266520);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1780509408 ^ (long)-1780509294);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)159349906 ^ (long)159349794);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)446474337 ^ (long)446474270);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)514826193 ^ (long)514826206);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)266669317 ^ (long)266669547);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)2130377280 ^ (long)2130377303);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-330964349 ^ (long)-330964259);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1613987235 ^ (long)1613987208);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1922909029 ^ (long)-1922909162);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1549525672 ^ (long)-1549525756);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)171539745 ^ (long)171539912);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-565327201 ^ (long)-565327226);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)633054610 ^ (long)633054671);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)372976114 ^ (long)372975967);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1474258281 ^ (long)1474258234);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1529077138 ^ (long)1529077034);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)410389122 ^ (long)410389052);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1879493213 ^ (long)-1879493358);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1693863098 ^ (long)-1693863157);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)11686351 ^ (long)11686318);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)707017403 ^ (long)707017334);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1578671861 ^ (long)-1578671755);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1375667553 ^ (long)1375667670);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)1300190439 ^ (long)1300190374);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1008970658 ^ (long)-1008970743);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-1260461376 ^ (long)-1260461524);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1471991277 ^ (long)-1471991243);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1760419556 ^ (long)-1760419480);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-563830109 ^ (long)-563830152);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-416368451 ^ (long)-416368601);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)698286696 ^ (long)698286701);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)2053787959 ^ (long)2053787992);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)208712042 ^ (long)208712018);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)2091894961 ^ (long)2091894878);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1231118154 ^ (long)1231118119);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)744385900 ^ (long)744385893);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)236285684 ^ (long)236285687);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)839530082 ^ (long)839530193);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1871737272 ^ (long)-1871737264);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1292975194 ^ (long)-1292975313);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-105615165 ^ (long)-105615113);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)353778949 ^ (long)353779174);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1137401968 ^ (long)-1137401947);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)2096001869 ^ (long)2096001841);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-228351443 ^ (long)-228351296);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-650858133 ^ (long)-650858143);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-432379148 ^ (long)-432379287);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1339693603 ^ (long)1339693782);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-326470429 ^ (long)-326470427);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)722705413 ^ (long)722705646);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)570968853 ^ (long)570968945);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1713404072 ^ (long)1713403932);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-2064596487 ^ (long)-2064596654);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-427024458 ^ (long)-427024432);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)550834159 ^ (long)550834172);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-2043257931 ^ (long)-2043258037);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)502665285 ^ (long)502665312);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)287688312 ^ (long)287688346);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1576339789 ^ (long)1576339867);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-670414138 ^ (long)-670414156);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-789692150 ^ (long)-789692055);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-345021297 ^ (long)-345021390);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1973686893 ^ (long)-1973686846);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)122342005 ^ (long)122342035);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)815568355 ^ (long)815568262);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)782614194 ^ (long)782614159);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)480273972 ^ (long)480274170);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1579801478 ^ (long)1579801494);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-604810374 ^ (long)-604810312);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1382076937 ^ (long)-1382076932);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)669376004 ^ (long)669376128);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)493477954 ^ (long)493478073);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-460219228 ^ (long)-460219332);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1148405859 ^ (long)1148405947);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-496134965 ^ (long)-496135039);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1344566845 ^ (long)1344567030);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-685688328 ^ (long)-685688477);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-2127031860 ^ (long)-2127031840);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)201725286 ^ (long)201725421);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)899487158 ^ (long)899487006);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-145991071 ^ (long)-145990922);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-819325730 ^ (long)-819325836);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-217528003 ^ (long)-217527814);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)656630023 ^ (long)656630041);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1894851392 ^ (long)-1894851359);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-114736871 ^ (long)-114736741);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1311601536 ^ (long)-1311601654);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)372645029 ^ (long)372644899);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)710771979 ^ (long)710772035);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)31698397 ^ (long)31698266);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)865929476 ^ (long)865929649);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-783279878 ^ (long)-783279993);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1913713060 ^ (long)-1913713111);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-850854825 ^ (long)-850854767);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1341355862 ^ (long)1341355850);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1967212661 ^ (long)1967212559);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-975122767 ^ (long)-975122907);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-188042972 ^ (long)-188042791);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-669525892 ^ (long)-669525778);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)1817257019 ^ (long)1817257069);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1173114090 ^ (long)1173113973);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-122285230 ^ (long)-122285167);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1784389052 ^ (long)-1784389076);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1841886770 ^ (long)-1841886961);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1047604485 ^ (long)-1047604610);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1446663764 ^ (long)-1446663790);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)2087568513 ^ (long)2087568517);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-56700079 ^ (long)-56700018);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-613608221 ^ (long)-613608394);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)829581271 ^ (long)829581202);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1890989290 ^ (long)-1890989289);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1315457371 ^ (long)1315457337);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1991767503 ^ (long)1991767359);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-787621898 ^ (long)-787622125);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1558861913 ^ (long)-1558861905);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1792151127 ^ (long)1792151052);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1582736994 ^ (long)-1582737021);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)749654959 ^ (long)749654907);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-761892394 ^ (long)-761892375);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1961102985 ^ (long)-1961102890);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-488365392 ^ (long)-488365537);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)70557162 ^ (long)70557102);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-59317570 ^ (long)-59317731);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1675927571 ^ (long)1675927788);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-491036061 ^ (long)-491036133);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-552858624 ^ (long)-552858517);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1005473200 ^ (long)-1005473119);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-451303233 ^ (long)-451303251);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-704123930 ^ (long)-704124067);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-1090855850 ^ (long)-1090855898);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-262871755 ^ (long)-262871801);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1681405380 ^ (long)1681405192);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1335840788 ^ (long)1335840863);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)874930206 ^ (long)874930320);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1618344732 ^ (long)1618344847);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-33157441 ^ (long)-33157613);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1404477718 ^ (long)-1404477774);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)859865657 ^ (long)859865702);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1259096068 ^ (long)1259096318);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)96972856 ^ (long)96973040);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)17756644 ^ (long)17756471);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1244721791 ^ (long)-1244721851);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)243092286 ^ (long)243092368);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1256219888 ^ (long)1256219850);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-205651575 ^ (long)-205651536);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1169476771 ^ (long)1169476707);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)738009515 ^ (long)738009353);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-1645914690 ^ (long)-1645914808);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1852554718 ^ (long)-1852554638);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1819037322 ^ (long)1819037433);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1996034413 ^ (long)1996034331);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-580196813 ^ (long)-580196827);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)139237733 ^ (long)139237812);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1572402920 ^ (long)1572402880);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-43323356 ^ (long)-43323264);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-713630800 ^ (long)-713630938);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-2007827058 ^ (long)-2007827095);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1807413541 ^ (long)-1807413515);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1686485419 ^ (long)1686485417);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)1917187364 ^ (long)1917187565);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)38781650 ^ (long)38781641);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1969390066 ^ (long)-1969389833);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)2140019387 ^ (long)2140019345);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-1896700406 ^ (long)-1896700371);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)985323791 ^ (long)985323930);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-547318154 ^ (long)-547318164);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)1563959509 ^ (long)1563959483);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1860781906 ^ (long)1860781936);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1754689832 ^ (long)1754690038);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)230032396 ^ (long)230032439);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)932128491 ^ (long)932128363);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1520836709 ^ (long)1520836741);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1376520998 ^ (long)1376521172);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1314988531 ^ (long)-1314988308);
                    if (!0T.\u2007) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)2110326842 ^ (long)2110327008);
                    if (!0T.\u2007) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-573864865 ^ (long)-573864730);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-780164300 ^ (long)-780164149)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1000449026 ^ (long)-1000430591)) >>> (int)((long)849070295 ^ (long)849070303)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-409808999 ^ (long)-409808999);
            if (!0T.\u2007) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)361682859 ^ (long)361682857);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1329477083 ^ (long)-1329477082) | var5_6 << (int)((long)2012339345 ^ (long)2012339348)) ^ var3_4[var7_8]) & (int)((long)1665420962 ^ (long)1665420893);
                    if (0T.\u2007) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-97731067 ^ (long)-97731066) | var6_7 << (int)((long)834747575 ^ (long)834747570)) ^ var3_4[var7_8]) & (int)((long)-294262286 ^ (long)-294262515);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0T.e[var2_3] = new String(var3_4).intern();
        }
        return 0T.e[var2_3];
    }

    public 0T() {
        boolean bl = \u2007;
        super(0T.b((int)((long)1428159028 ^ (long)1428147002), (int)((long)-1800957539 ^ (long)-1800937677)) /* "Anti Hazard" */, 0T.b((int)((long)817175847 ^ (long)817179688), (int)((long)1437450967 ^ (long)1437436208)) /* "Helps you avoid hazards" */);
        Boolean bl2 = Boolean.TRUE;
        34X x3 = (34X)((34X)((34X)this.4().5(0T.b((int)((long)1734880794 ^ (long)1734876954), (int)((long)936251629 ^ (long)-936251045)) /* "Cacti" */)).7(0T.b((int)((long)-639921682 ^ (long)-639917849), (int)((long)-791721675 ^ (long)791723052)) /* "cacti" */)).1(0T.b((int)((long)-1942796306 ^ (long)-1942784277), (int)((long)1375039716 ^ (long)1375042147)) /* "Prevents cacti from dealing damage" */);
        ((34X)((34X)((34X)this.4().5(0T.b((int)((long)1734880794 ^ (long)1734876954), (int)((long)936251629 ^ (long)-936251045)) /* "Cacti" */)).7(0T.b((int)((long)-639921682 ^ (long)-639917849), (int)((long)-791721675 ^ (long)791723052)) /* "cacti" */)).1(0T.b((int)((long)-1942796306 ^ (long)-1942784277), (int)((long)1375039716 ^ (long)1375042147)) /* "Prevents cacti from dealing damage" */)).7 = bl2;
        this.6 = (1P)x3.5();
        bl2 = Boolean.TRUE;
        x3 = (34X)((34X)((34X)this.4().5(0T.b((int)((long)-438384501 ^ (long)-438371968), (int)((long)1283246246 ^ (long)1283239963)) /* "Magma" */)).7(0T.b((int)((long)-1706501141 ^ (long)-1706497305), (int)((long)1170722103 ^ (long)1170724282)) /* "magma" */)).1(0T.b((int)((long)553485157 ^ (long)553497199), (int)((long)858747737 ^ (long)-858737895)) /* "Prevents Magma blocks from dealing damage" */);
        ((34X)((34X)((34X)this.4().5(0T.b((int)((long)-438384501 ^ (long)-438371968), (int)((long)1283246246 ^ (long)1283239963)) /* "Magma" */)).7(0T.b((int)((long)-1706501141 ^ (long)-1706497305), (int)((long)1170722103 ^ (long)1170724282)) /* "magma" */)).1(0T.b((int)((long)553485157 ^ (long)553497199), (int)((long)858747737 ^ (long)-858737895)) /* "Prevents Magma blocks from dealing damage" */)).7 = bl2;
        this.2 = (1P)x3.5();
        bl2 = Boolean.TRUE;
        x3 = (34X)((34X)((34X)this.4().5(0T.b((int)((long)649550034 ^ (long)649554390), (int)((long)2774539 ^ (long)2772767)) /* "Pressure Plates" */)).7(0T.b((int)((long)-1064464129 ^ (long)-1064459785), (int)((long)-767153311 ^ (long)767143006)) /* "pp" */)).1(0T.b((int)((long)1924176967 ^ (long)1924181322), (int)((long)666811400 ^ (long)-666798817)) /* "Prevents your player from activating pressure plates" */);
        ((34X)((34X)((34X)this.4().5(0T.b((int)((long)649550034 ^ (long)649554390), (int)((long)2774539 ^ (long)2772767)) /* "Pressure Plates" */)).7(0T.b((int)((long)-1064464129 ^ (long)-1064459785), (int)((long)-767153311 ^ (long)767143006)) /* "pp" */)).1(0T.b((int)((long)1924176967 ^ (long)1924181322), (int)((long)666811400 ^ (long)-666798817)) /* "Prevents your player from activating pressure plates" */)).7 = bl2;
        this.1 = (1P)x3.5();
        bl2 = Boolean.TRUE;
        x3 = (34X)((34X)((34X)this.4().5(0T.b((int)((long)-921270392 ^ (long)-921258357), (int)((long)895308533 ^ (long)895306093)) /* "Fire" */)).7(0T.b((int)((long)1282709344 ^ (long)1282713185), (int)((long)716581129 ^ (long)-716577145)) /* "fire" */)).1(0T.b((int)((long)-1599915710 ^ (long)-1599928256), (int)((long)69136533 ^ (long)-69135912)) /* "Prevents your player from walking into fire" */);
        ((34X)((34X)((34X)this.4().5(0T.b((int)((long)-921270392 ^ (long)-921258357), (int)((long)895308533 ^ (long)895306093)) /* "Fire" */)).7(0T.b((int)((long)1282709344 ^ (long)1282713185), (int)((long)716581129 ^ (long)-716577145)) /* "fire" */)).1(0T.b((int)((long)-1599915710 ^ (long)-1599928256), (int)((long)69136533 ^ (long)-69135912)) /* "Prevents your player from walking into fire" */)).7 = bl2;
        this.8 = (1P)x3.5();
        this.6K = (int)((long)-1655542760 ^ (long)-1655542760);
        this.9 = new Listener(object -> {
            block3: {
                block2: {
                    boolean bl = \u2007;
                    if (bl || bl) break block2;
                    object = new 8S(((4E)object).9, ((4E)object).7 - 0.2, ((4E)object).5);
                    this.0 = 34L.0(((2)0T.3.s).getPos().2((8S)object)) instanceof bye;
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)-17411170 ^ (long)-17411170)]);
        this.4 = new Listener(x2 -> {
            block9: {
                block10: {
                    ta.a a2;
                    block11: {
                        block8: {
                            boolean bl = \u2007;
                            if (bl || bl) break block8;
                            if (!this.2.2) break block9;
                            if (bl || bl) break block8;
                            if (!this.0) break block10;
                            if (bl || bl) break block8;
                            this.6K = (int)((long)1555611278 ^ (long)1555611278);
                            if (!bl && !bl) break block11;
                        }
                        return;
                    }
                    dwu dwu2 = 0T.3.s.e;
                    dzm dzm2 = 0T.3.s;
                    if (x2.7 == EventState.PRE) {
                        a2 = ta.a.b;
                        if (\u2007) {
                            throw null;
                        }
                    } else {
                        a2 = ta.a.a;
                    }
                    dwu2.a((oj)new ta((aqa)dzm2, a2));
                    return;
                }
                if (this.6K) {
                    return;
                }
                0T.3.s.e.a((oj)new ta((aqa)0T.3.s, ta.a.b));
                this.6K = (int)((long)1803210241 ^ (long)1803210240);
            }
        }, new Predicate[(int)((long)2005870358 ^ (long)2005870358)]);
        5 = this;
    }
}

