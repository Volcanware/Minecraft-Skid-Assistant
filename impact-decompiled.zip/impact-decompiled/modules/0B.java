/* ==========================================================================
 * MODULE: Minestrike
 * CATEGORY (inferred): Combat
 * DESCRIPTION: MultiHack designed for the Minestrike Minigame
 * OBFUSCATED CLASS: net.impactclient.0B
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  aot
 *  apw
 *  aqa
 *  bcv
 *  bfw
 *  blx
 *  bmb
 *  brc
 *  brf
 *  brf$a
 *  brf$b
 *  brx
 *  bup
 *  bvv
 *  ccr
 *  com.google.common.collect.ImmutableMap
 *  com.google.common.collect.ImmutableMap$Builder
 *  com.mojang.blaze3d.systems.RenderSystem
 *  cva
 *  dci
 *  dcj
 *  dcl$a
 *  dcn
 *  hh
 *  it.unimi.dsi.fastutil.objects.Object2IntArrayMap
 *  it.unimi.dsi.fastutil.objects.Object2IntMap
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  org.lwjgl.opengl.GL11
 */
package net.impactclient;

import com.google.common.collect.ImmutableMap;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.Comparator;
import java.util.function.Predicate;
import java.util.stream.Stream;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.0F;
import net.impactclient.11;
import net.impactclient.18;
import net.impactclient.1A;
import net.impactclient.1P;
import net.impactclient.1z;
import net.impactclient.2R;
import net.impactclient.2U;
import net.impactclient.2c;
import net.impactclient.2n;
import net.impactclient.2o;
import net.impactclient.2r;
import net.impactclient.2w$6X;
import net.impactclient.34H;
import net.impactclient.34J;
import net.impactclient.34L;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3P;
import net.impactclient.3X;
import net.impactclient.3Y;
import net.impactclient.3e;
import net.impactclient.3k;
import net.impactclient.3sg;
import net.impactclient.4M;
import net.impactclient.4X;
import net.impactclient.5K;
import net.impactclient.5p;
import net.impactclient.5z;
import net.impactclient.66;
import net.impactclient.8S;
import net.impactclient.9V;
import net.impactclient.9b;
import net.impactclient.9j;
import org.lwjgl.opengl.GL11;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0B
extends 3X
implements 4M {
    private 1A 9d;
    private 11 9U;
    private static final String[] e;
    private 1z 9t;
    private 18 8;
    private 1P 9H;
    private static final String[] d;
    @EventHandler
    private final Listener<2o> 6;
    private final 3k 9l;
    private boolean 9p;
    private 11 95;
    @EventHandler
    private final Listener<4X> 9M;
    private 1P 2;
    public static final boolean \u2005\u2004\u2000\u2000\u2004;
    @EventHandler
    private final Listener<9j> 0;
    private 1P 99;
    @EventHandler
    private final Listener<2U> 93;
    private 1P 9C;
    private final ImmutableMap<Integer, float[]> 4;
    private 11 7;
    private final Object2IntMap<18> 9B;
    @EventHandler
    private final Listener<2r> 5;
    private 1P 1;
    private 1P 9P;
    private 1P 9z;
    private 1P 9w;
    private 1P 9;
    private 11 9E;
    private 1P 9f;

    /*
     * Enabled aggressive block sorting
     */
    private static boolean 5(18 var0) {
        boolean bl = \u2005\u2004\u2000\u2000\u2004;
        if (bl || bl) return true;
        if (var0.8 != 0B.3.s) {
            if (bl) return true;
            if (var0.5.d) {
                if (bl) return true;
                if (var0.8.aX()) {
                    if (bl) return true;
                    if (!var0.8.em()) {
                        if (bl) return true;
                        if (!var0.8.bF()) {
                            if (bl) return true;
                            return (int)((long)-870392606 ^ (long)-870392605) != 0;
                        }
                    }
                }
            }
        }
        if (!bl) return (int)((long)-1754536220 ^ (long)-1754536220) != 0;
        return true;
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0B.\u2005\u2004\u2000\u2000\u2004;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1616993817 ^ (long)-1616989472)) & (int)((long)1162299748 ^ (long)1162327707);
            if (var9_2) ** GOTO lbl-1000
            if (0B.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0B.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1764395505 ^ (long)-1764395505)] & (int)((long)1033923937 ^ (long)1033923998)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)934985107 ^ (long)934985194);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)216857041 ^ (long)216856856);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-700176812 ^ (long)-700176772);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1308979651 ^ (long)-1308979487);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1078087050 ^ (long)-1078087065);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1243585423 ^ (long)-1243585453);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1023978026 ^ (long)1023978104);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-282810948 ^ (long)-282811075);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-472105774 ^ (long)-472105836);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1496243549 ^ (long)-1496243656);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)523007546 ^ (long)523007648);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1406144319 ^ (long)-1406144298);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1768050119 ^ (long)-1768049982);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1064417170 ^ (long)1064417067);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-692908378 ^ (long)-692908333);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-68464230 ^ (long)-68464334);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1738451678 ^ (long)-1738451679);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)153509978 ^ (long)153509986);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)95077032 ^ (long)95076902);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-218033140 ^ (long)-218032903);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-904803151 ^ (long)-904803319);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1265749493 ^ (long)-1265749374);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1058099749 ^ (long)1058099898);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1075538398 ^ (long)-1075538423);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1820063711 ^ (long)-1820063603);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)2101470107 ^ (long)2101470014);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1549603671 ^ (long)1549603817);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1784077649 ^ (long)-1784077759);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1950512885 ^ (long)1950512703);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)469765743 ^ (long)469765651);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1907351552 ^ (long)-1907351542);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-1980844039 ^ (long)-1980844138);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-630189966 ^ (long)-630189841);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1443923615 ^ (long)1443923607);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)52160311 ^ (long)52160275);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1608539429 ^ (long)1608539571);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)938923294 ^ (long)938923482);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1272086850 ^ (long)-1272086870);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)165469082 ^ (long)165468943);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1919742498 ^ (long)-1919742657);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)553862308 ^ (long)553862345);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-574375793 ^ (long)-574375838);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)698239196 ^ (long)698239115);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1970260457 ^ (long)-1970260386);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1106297474 ^ (long)-1106297487);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-62176999 ^ (long)-62176825);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1210097228 ^ (long)-1210097238);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1838795449 ^ (long)-1838795494);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-611778163 ^ (long)-611778195);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)2065139150 ^ (long)2065139060);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1365274030 ^ (long)-1365274080);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)17076072 ^ (long)17076137);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1316919614 ^ (long)-1316919781);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)12014424 ^ (long)12014431);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)346163559 ^ (long)346163599);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-405762734 ^ (long)-405762619);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1033762848 ^ (long)1033762884);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1902213487 ^ (long)-1902213495);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1124607839 ^ (long)-1124607932);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)269101126 ^ (long)269101113);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1569476802 ^ (long)1569476859);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)414030599 ^ (long)414030812);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)710892795 ^ (long)710892624);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)997075874 ^ (long)997075899);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-826965335 ^ (long)-826965329);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-2013670233 ^ (long)-2013670177);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)2053019484 ^ (long)2053019459);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-8762895 ^ (long)-8763001);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)696538649 ^ (long)696538693);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-100674703 ^ (long)-100674790);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)364994886 ^ (long)364994993);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)185254327 ^ (long)185254326);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1961113352 ^ (long)-1961113373);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)637315459 ^ (long)637315457);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-308524438 ^ (long)-308524493);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1253413010 ^ (long)-1253412920);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1822490230 ^ (long)-1822490299);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1358910733 ^ (long)-1358910792);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-553013775 ^ (long)-553013812);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1162188021 ^ (long)1162188015);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1970307692 ^ (long)1970307730);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1800543005 ^ (long)1800543122);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1260847236 ^ (long)1260847273);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1012156356 ^ (long)-1012156212);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1020059898 ^ (long)1020059678);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1206638603 ^ (long)1206638761);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)2003621237 ^ (long)2003621172);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-496695384 ^ (long)-496695380);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-3841543 ^ (long)-3841612);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1289891230 ^ (long)-1289891105);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1629701403 ^ (long)-1629701442);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1419308485 ^ (long)1419308365);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-32313049 ^ (long)-32312846);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)261306654 ^ (long)261306765);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)741115844 ^ (long)741115696);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-2065328949 ^ (long)-2065329004);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)126057136 ^ (long)126057063);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-623076483 ^ (long)-623076480);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-896504023 ^ (long)-896503809);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)2119362299 ^ (long)2119362133);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1685508 ^ (long)1685730);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1511732426 ^ (long)1511732368);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1748007166 ^ (long)-1748007124);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1867753180 ^ (long)-1867753109);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)522704424 ^ (long)522704480);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1983810908 ^ (long)1983810969);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1024666697 ^ (long)1024666700);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1316983844 ^ (long)1316984038);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1943690483 ^ (long)1943690322);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1029719030 ^ (long)1029718886);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1863407387 ^ (long)1863407511);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1856835564 ^ (long)-1856835546);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)42856508 ^ (long)42856662);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1937410293 ^ (long)1937410143);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1623623562 ^ (long)1623623624);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1391906198 ^ (long)-1391906225);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-541675466 ^ (long)-541675499);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)783892057 ^ (long)783892158);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1004591837 ^ (long)-1004591652);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)2044716501 ^ (long)2044716294);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)404847700 ^ (long)404847616);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-185909465 ^ (long)-185909283);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-93336784 ^ (long)-93336810);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1672227591 ^ (long)-1672227624);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1327629093 ^ (long)1327629087);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1773876472 ^ (long)-1773876255);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-2065520127 ^ (long)-2065520023);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)1037954887 ^ (long)1037955058);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1728078561 ^ (long)-1728078497);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1438929863 ^ (long)-1438929884);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)285074152 ^ (long)285074119);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-487251437 ^ (long)-487251455);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1289471762 ^ (long)1289471907);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1455419961 ^ (long)1455419996);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1898063225 ^ (long)1898063277);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1131242471 ^ (long)1131242379);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1268475050 ^ (long)-1268475080);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)15176525 ^ (long)15176579);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1857974326 ^ (long)-1857974345);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1705697949 ^ (long)1705697918);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)273595166 ^ (long)273595198);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1041737086 ^ (long)1041737182);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1488620680 ^ (long)1488620560);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-139286961 ^ (long)-139286904);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)103452214 ^ (long)103452362);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1227244320 ^ (long)1227244320);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-451213631 ^ (long)-451213768);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-2037818559 ^ (long)-2037818552);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1378858205 ^ (long)-1378858033);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)14169424 ^ (long)14169345);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)388603038 ^ (long)388603029);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1812722122 ^ (long)-1812722008);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1396679219 ^ (long)1396679248);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1468939644 ^ (long)-1468939550);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1199571398 ^ (long)1199571338);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)464373371 ^ (long)464373308);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1659384907 ^ (long)-1659385081);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1477739260 ^ (long)-1477739215);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)626606034 ^ (long)626606047);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1578653749 ^ (long)-1578653726);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-1521883609 ^ (long)-1521883624);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1954754902 ^ (long)1954754973);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)222763286 ^ (long)222763468);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1010136115 ^ (long)-1010136199);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1969375230 ^ (long)1969375098);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-2133689335 ^ (long)-2133689163);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1140619729 ^ (long)1140619578);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1590975646 ^ (long)-1590975546);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-2048507494 ^ (long)-2048507604);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1574241284 ^ (long)1574241500);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1745192873 ^ (long)-1745192894);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1886456230 ^ (long)1886456279);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1290837445 ^ (long)1290837320);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1744582503 ^ (long)1744582464);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1403911150 ^ (long)-1403910976);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-305561995 ^ (long)-305561869);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)480059379 ^ (long)480059391);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)35885425 ^ (long)35885472);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1189209453 ^ (long)1189209409);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)445320432 ^ (long)445320357);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-755586570 ^ (long)-755586668);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1449069007 ^ (long)-1449068861);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)34532969 ^ (long)34533104);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1646246557 ^ (long)1646246477);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)2073374771 ^ (long)2073374821);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1658203968 ^ (long)-1658204018);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)2067724972 ^ (long)2067724906);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1909993231 ^ (long)-1909993378);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)856767246 ^ (long)856767306);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-925281378 ^ (long)-925281479);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-810283054 ^ (long)-810283163);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1906512881 ^ (long)1906512871);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-918716512 ^ (long)-918716573);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1978331919 ^ (long)1978331991);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1272424597 ^ (long)1272424469);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1824417031 ^ (long)-1824417142);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)455552371 ^ (long)455552275);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)656933761 ^ (long)656933810);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-962107661 ^ (long)-962107697);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-787940473 ^ (long)-787940604);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1232648857 ^ (long)1232648810);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1233568802 ^ (long)1233568960);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-957094306 ^ (long)-957094153);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1885523030 ^ (long)-1885523153);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1039764581 ^ (long)1039764510);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)433148864 ^ (long)433148855);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-204458348 ^ (long)-204458395);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1084786531 ^ (long)-1084786436);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1468605540 ^ (long)1468605652);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1400832299 ^ (long)1400832441);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1537836499 ^ (long)1537836376);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1766090727 ^ (long)1766090527);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1386617949 ^ (long)1386617914);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)597998239 ^ (long)597998175);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1526462540 ^ (long)1526462473);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1434957934 ^ (long)1434957909);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1772631595 ^ (long)1772631637);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1084882376 ^ (long)-1084882366);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)336802946 ^ (long)336802824);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1888701395 ^ (long)-1888701221);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)2065271800 ^ (long)2065271798);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)50676891 ^ (long)50676906);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)356443300 ^ (long)356443167);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)434487305 ^ (long)434487478);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-198648774 ^ (long)-198648648);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1565784066 ^ (long)1565784081);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1965894624 ^ (long)-1965894403);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)2047837138 ^ (long)2047837158);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1148375162 ^ (long)1148375082);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-2087118839 ^ (long)-2087118793);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)463940337 ^ (long)463940274);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1897040565 ^ (long)1897040577);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1647480310 ^ (long)-1647480221);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1560113327 ^ (long)1560113381);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1957678257 ^ (long)-1957678241);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-231173230 ^ (long)-231173362);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-541354060 ^ (long)-541354044);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1485128014 ^ (long)-1485127967);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)456474195 ^ (long)456474352);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-953789767 ^ (long)-953789839);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1456498386 ^ (long)1456498243);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)88984399 ^ (long)88984546);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)194241617 ^ (long)194241733);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1957718102 ^ (long)1957718201);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1088441487 ^ (long)1088441404);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)2021753889 ^ (long)2021754092);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-455588241 ^ (long)-455588283);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-632565309 ^ (long)-632565259);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1714768630 ^ (long)-1714768427);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-739898113 ^ (long)-739898161);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)782469854 ^ (long)782469812);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-744080215 ^ (long)-744080338);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1671405669 ^ (long)1671405627);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)581184723 ^ (long)581184719);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1652831313 ^ (long)1652831334);
                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)418017291 ^ (long)418017479);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-2030519935 ^ (long)-2030519938)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-343073688 ^ (long)-343022697)) >>> (int)((long)1715526959 ^ (long)1715526951)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-558085631 ^ (long)-558085631);
            if (!0B.\u2005\u2004\u2000\u2000\u2004) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1218548333 ^ (long)1218548335);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-1554305588 ^ (long)-1554305585) | var5_6 << (int)((long)-411287335 ^ (long)-411287332)) ^ var3_4[var7_8]) & (int)((long)2117356941 ^ (long)2117356914);
                    if (0B.\u2005\u2004\u2000\u2000\u2004) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-221387093 ^ (long)-221387096) | var6_7 << (int)((long)1786400684 ^ (long)1786400681)) ^ var3_4[var7_8]) & (int)((long)1451384820 ^ (long)1451384587);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0B.e[var2_3] = new String(var3_4).intern();
        }
        return 0B.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    private 8S 2(bfw bfw2) {
        boolean bl = \u2005\u2004\u2000\u2000\u2004;
        if (bl) return null;
        18 var3_3 = this.9l.9;
        double d2 = 0B.3.s.g((aqa)bfw2);
        String[] stringArray = 3e.5();
        if (bl || bl) return null;
        double d3 = 0.0;
        if (bl) return null;
        if (bl) return null;
        double d4 = 0.0;
        if (bl) return null;
        if (bl) return null;
        if (var3_3.4.2()) {
            if (bl) return null;
            if (var3_3.4.7().h) {
                if (bl || bl) return null;
                switch (3P.5[var3_3.4.7().ordinal()]) {
                    case 1: {
                        if (bl) return null;
                        d3 = 1.7 * Math.max(d2 / 12.0 + 2.0, 1.0);
                        if (bl || bl) return null;
                        if (stringArray == null) break;
                        if (bl) return null;
                    }
                    case 2: {
                        if (bl) return null;
                        d3 = 1.5 * Math.max(d2 / 8.0 + 2.0, 1.0);
                        if (bl || bl) return null;
                        if (stringArray == null) break;
                        if (bl) return null;
                    }
                    case 3: {
                        if (bl) return null;
                        d3 = 1.9 * Math.max(d2 / 15.0 + 2.0, 1.0);
                        if (bl || bl) return null;
                        if (stringArray == null) break;
                        if (bl) return null;
                    }
                    case 4: {
                        if (bl) return null;
                        d3 = 1.5 * Math.max(d2 / 20.0 + 1.0, 1.0);
                        if (bl || bl) return null;
                        if (stringArray == null) break;
                        if (bl) return null;
                    }
                    case 5: {
                        if (bl) return null;
                        d3 = 1.5 * Math.max(d2 / 15.0 + 2.0, 1.0);
                        if (bl || bl) return null;
                        d4 = d2 / 40.0;
                        if (bl) return null;
                        break;
                    }
                }
            }
        }
        if (bl) return null;
        float f = 1.0f;
        if (bl) return null;
        if (bl) return null;
        String string = ((String)this.7.0()).toLowerCase();
        if (bl) return null;
        int n = (int)((long)-1002452287 ^ (long)1002452286);
        if (bl) return null;
        switch (string.hashCode()) {
            case 3198432: {
                if (bl) return null;
                if (!string.equals(0B.b((int)((long)1191147555 ^ (long)1191144196), (int)((long)1450641439 ^ (long)-1450660767)) /* "head" */)) break;
                if (bl) return null;
                n = (int)((long)76155027 ^ (long)76155027);
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 94627585: {
                if (bl) return null;
                if (!string.equals(0B.b((int)((long)-824620628 ^ (long)-824616290), (int)((long)-315523889 ^ (long)315538265)) /* "chest" */)) break;
                if (bl) return null;
                n = (int)((long)-2066354784 ^ (long)-2066354783);
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 3317797: {
                if (bl) return null;
                if (!string.equals(0B.b((int)((long)-533563016 ^ (long)-533566903), (int)((long)-1584758369 ^ (long)1584753900)) /* "legs" */)) break;
                if (bl) return null;
                n = (int)((long)1093736978 ^ (long)1093736976);
                if (bl) return null;
                break;
            }
        }
        if (bl) return null;
        switch (n) {
            case 0: {
                if (bl) return null;
                f = 0.75f;
                if (bl) return null;
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 1: {
                if (bl) return null;
                f = 0.55f;
                if (bl) return null;
                if (bl) return null;
                if (stringArray == null) break;
                if (bl) return null;
            }
            case 2: {
                if (bl) return null;
                f = 0.3f;
                if (bl) return null;
                break;
            }
        }
        if (bl) return null;
        if (this.9P.2) {
            if (bl || bl) return null;
            float f2 = 5p.5((bfw)0B.3.s);
            if (bl || bl) return null;
            float f3 = 5p.5(bfw2);
            if (bl || bl) return null;
            if (f2 > 0.0f) {
                if (bl) return null;
                if (f3 > 0.0f) {
                    if (bl || bl) return null;
                    d3 += (double)afm.f((float)(f2 / f3));
                    if (bl) return null;
                }
            }
        }
        if (bl) return null;
        dcn dcn2 = new dcn(bfw2.cD(), bfw2.cE() + (double)(bfw2.ce() * f), bfw2.cH());
        if (bl || bl) return null;
        dcn dcn3 = new dcn(bfw2.cD() + (bfw2.cD() - bfw2.m) * d3, bfw2.cE() + (bfw2.cE() - bfw2.n) + (double)(bfw2.ce() * f) + d4, bfw2.cH() + (bfw2.cH() - bfw2.o) * d3);
        if (bl || bl) return null;
        this.9p = this.9w.2;
        if (bl || bl) return null;
        bfw2 = 0B.3.r.a(new brf(dcn2, dcn3, brf.a.a, brf.b.a, (aqa)0B.3.s));
        if (bl || bl) return null;
        this.9p = (int)((long)867872673 ^ (long)867872673);
        if (bl || bl) return null;
        if (bfw2.c() == dcl.a.a) {
            if (bl || bl) return null;
            return new 8S(dcn3.b, dcn3.c, dcn3.d);
        }
        if (!bl) return new 8S(bfw2.e().b, bfw2.e().c, bfw2.e().d);
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ void 9(18 var1_1, 18 var2_2) {
        boolean bl;
        block23: {
            block22: {
                bl = \u2005\u2004\u2000\u2000\u2004;
                if (bl || bl) return;
                this.9B.putIfAbsent((Object)var2_2, (int)((long)-1700062378 ^ (long)-1700062378));
                if (bl || bl) return;
                8S s = this.2(var2_2.8);
                if (bl || bl) return;
                s = new dcn(s.9, s.1, s.2);
                if (bl || bl) return;
                dcn dcn2 = new dcn(0B.3.s.cD(), 0B.3.s.cE() + (double)0B.3.s.ce(), 0B.3.s.cH());
                if (bl || bl) return;
                this.9p = this.9w.2;
                if (bl || bl) return;
                if (0B.3.r.a(new brf(dcn2, (dcn)s, brf.a.a, brf.b.a, (aqa)0B.3.s)).c() != dcl.a.a) {
                    if (bl) return;
                    if (0B.3.r.a(new brf((dcn)s, dcn2, brf.a.a, brf.b.a, (aqa)0B.3.s)).c() != dcl.a.a) {
                        if (bl || bl) return;
                        this.9B.put((Object)var2_2, (int)((long)1581851387 ^ (long)1581851387));
                        if (bl || bl) return;
                        return;
                    }
                }
                if (bl) return;
                this.9p = (int)((long)1338513883 ^ (long)1338513883);
                if (bl || bl) return;
                int n = this.9B.get((Object)var2_2) + (int)((long)523563846 ^ (long)523563847);
                if (bl || bl) return;
                this.9B.put((Object)var2_2, n);
                if (bl || bl) return;
                if (this.9t.4 > n) {
                    if (bl || bl) return;
                    return;
                }
                if (bl) return;
                if (!0B.5(var2_2)) break block22;
                if (bl) return;
                if (this.8 == null) break block23;
                if (bl) return;
            }
            if (bl) return;
            return;
        }
        if (bl) return;
        if (var2_2.5 == var1_1.5) {
            if (bl || bl) return;
            return;
        }
        if (bl) return;
        if (5z.4().1.8(var2_2.8.R().getString())) {
            if (bl) return;
            if (!this.2.2) {
                if (bl || bl) return;
                return;
            }
        }
        if (bl) return;
        if (66.3((aqa)var2_2.8) <= (double)(this.9d.9 / 2.0f)) {
            if (bl || bl) return;
            this.8 = var2_2;
            if (bl) return;
        }
        if (!bl) return;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0B.\u2005\u2004\u2000\u2000\u2004;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)238340457 ^ (long)238340394)];
            if (var7) break block23;
            var3_2 = (int)((long)-1097013493 ^ (long)-1097013493);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\uc6e7\uee75\ufd09\uf569\uc6aa\ueeab\ufdc5\uf540\uc6b4\uee46\ufd98\uf509\uc633\ueefc\ufdec\uf5b7\uc6e3\uee3a\ufd43\uf5e4\uc6cf\uee5d\ufd8a\uf527\uc683\uee37\ufdd9\uf56b\uc658\uee5a\ufdcc\uf52c\uc67a\uee4a\ufd1c\uf55a\uc66c\ueeca\ufdc4\uf5d3\uc6a5\uee68\ufda9\uf538\uc626\ueedb\ufd03\uf5f5\uc6fe\uee68\ufd05\uf5fe\uc647\ueed1\ufdf7\uf5c2\uc69a\uee66\ufd72\uf5a7\uc6bc\ueeb6\ufd7a\uf5ca\uc6a8\uee37\ufdbd\uf5ba\uc6fc\uee80\ufdb6\uf538\uc65d\ueeb2\ufd45\uf51d\uc60f\ueea7\ufd10\uf5cc\uc616\ueef3\ufd19\uf57b\uc6d6\uee54\ufd9a\uf5b8\uc6ba\ueeb4\ufdb7\uf51b\uc6c5\uee4c\ufd76\uf533\uc672\uee6c\ufd75\uf598\uc6b5\uee57\ufd45\uf508\uc6b2\ueeea\ufd99\uf577\uc6c6\uee1d\ufd79\uf522\uc6e3\uee6e\ufd72\uf58b\uc677\uee4f\ufd39\uf585\uc6fd\uee08\ufddd\uf5c1\uc6d9\uee14\ufdea\uf545\uc6d6\uee2e\ufd19\uf5ce\uc614\uee6a\ufdc0\uf5c2\uc618\ueeae\ufdfc\uf592\uc651\uee6e\ufd08\uf551\uc63d\uee17\ufdf8\uf5c9\uc64a\uee8c\ufd20\uf50f\uc6f4\uee88\ufdaf\uf55b\uc658\uee07\ufdf2\uf51b\uc6c1\uee23\ufdcf\uf506\uc63e\ueeab\ufd61\uf5c5\uc6e3\uee8d\ufdcb\uf509\uc632\uee2d\ufd51\uf55c\uc647\uee8f\ufdf0\uf592\uc6fb\uee17\ufdb8\uf534\uc6ff\uee49\ufd08\uf540\uc60b\ueec6\ufdf5\uf5f3\uc622\uee64\ufdec\uf52b\uc63d\uee61\ufd56\uf5ca\uc6a5\uee66\ufda2\uf5e8\uc641\ueeaa\ufdaf\uf5e9\uc6c7\uee28\ufd6e\uf5ea\uc6f3\ueeaa\ufdfe\uf5be\uc6df\uee74\ufd1b\uf500\uc652\uee4d\ufdd6\uf57c\uc674\uee4a\ufdbb\uf50f\uc6a3\ueef5\ufd86\uf55a\uc6a0\uee74\ufdb0\uf5f8\uc68f\uee2e\ufdcc\uf5ac\uc66f\uee3a\ufdd1\uf508\uc644\uee48\ufd9e\uf580\uc696\ueee7\ufdba\uf5cb\uc6e9\uee72\ufd56\uf567\uc6c3\uee0e\ufd8c\uf57d\uc661\ueea7\ufd76\uf55c\uc655\uee9c\ufd8b\uf550\uc66a\uee65\ufd7c\uf546\uc642\ueefa\ufdb4\uf586\uc653\uee20\ufddd\uf5cd\uc689\uee76\ufdce\uf5c5\uc62c\uee5b\ufde0\uf5ce\uc6dd\uee8f\ufdc0\uf535\uc63f\uee4b\ufda1\uf59e\uc64a\uee40\ufd76\uf56d\uc68e\ueea6\ufd0b\uf5cd\uc6e9\uee07\ufdc2\uf5eb\uc6ad\uee9e\ufdd0\uf5c2\uc619\uee7f\ufd67\uf5fc\uc6ca\uee6a\ufdfb\uf524\uc602\ueeab\ufd5b\uf5d0\uc625\ueef8\ufdb9\uf502\uc60d\uee4f\ufd0c\uf568\uc689\uee27\ufd6a\uf5e9\uc68b\uee6e\ufdf7\uf549\uc635\uee03\ufd9c\uf571\uc60a\ueed5\ufdaa\uf564\uc6c3\uee07\ufdc9\uf527\uc621\ueed5\ufdd9\uf557\uc6f2\uee5f\ufd39\uf583\uc6a7\ueee7\ufd3d\uf5db\uc6c8\uee3a\ufd43\uf588\uc68f\uee34\ufd74\uf571\uc62f\ueecd\ufd72\uf55a\uc616\uee0f\ufdab\uf5f2\uc686\ueec4\ufdf7\uf5ac\uc6ec\ueea4\ufd2e\uf5a8\uc607\uee5c\ufd48\uf5cd\uc61c\ueeea\ufda4\uf598\uc697\uee58\ufd4e\uf518\uc639\ueec6\ufded\uf591\uc626\ueed4\ufda1\uf5e3\uc66f\uee10\ufd24\uf55e\uc63c\uee93\ufd16\uf56f\uc6d2\uee5f\ufdad\uf59d\uc66a\ueed0\ufdb7\uf5cb\uc6f0\uee58\ufd0f\uf5a4\uc673\uee89\ufd4d\uf5fe\uc631\ueeee\ufdf0\uf5c4\uc6a6\ueeaa\ufdb3\uf5b1\uc660\uee23\ufd9a\uf58b\uc66d\uee86\ufdbb\uf517\uc6fe\ueeb4\ufd6c\uf50d\uc628\ueeb0\ufd4e\uf554\uc6dc\uee65\ufdcf\uf51b\uc6fa\ueee5\ufdd5\uf5da\uc666\uee57\ufda8\uf500\uc62a\uee26\ufd5e\uf59b\uc65a\uee96\ufd3f\uf5e5\uc6c3\ueeb3\ufdaa\uf5d9\uc6c4\uee84\ufdb6\uf563\uc646\uee22\ufd67\uf594\uc67f\uee69\ufde5\uf5c0\uc612\ueeb8\ufda4\uf580\uc614\ueea0\ufd42\uf5ed\uc607\uee53\ufdb9\uf5c6\uc69d\uee27\ufd4f\uf5e8\uc63c\ueea2\ufdb4\uf5de\uc62c\ueef8\ufdb8\uf511\uc64b\ueea4\ufd39\uf5da\uc69b\ueebd\ufdfa\uf560\uc643\ueefe\ufd5f\uf538\uc629\ueee9\ufd03\uf565\uc65c\ueece\ufd91\uf512\uc6db\uee55\ufd02\uf560\uc635\uee04\ufd60\uf5d9\uc685\ueef9\ufdf2\uf553\uc68a\ueecb\ufdd8\uf5e5\uc62d\ueea6\ufd06\uf5e6\uc6c5\uee37\ufdba\uf561\uc69d\uee14\ufdbb\uf5cc\uc625\uee5c\ufd24\uf515\uc61d\uee11\ufdb7\uf5ad\uc67c\ueee9\ufd65\uf5ea\uc6a1\uee4e\ufd11\uf5cf\uc62e\uee50\ufd68\uf5da\uc619\uee26\ufd18\uf5b2\uc6d4\uee25\ufd2a\uf5d1\uc6bd\uee4d\ufd6d\uf524\uc6a1\uee70\ufd2e\uf5ab\uc632\uee4c\ufd81\uf5e2\uc699\ueedd\ufdbb\uf524\uc602\uee90\ufde2\uf529\uc6f1\ueec3\ufdac\uf5c8\uc684\uee2c\ufd43\uf52f\uc6db\ueeff\ufdbc\uf588\uc670\uee4c\ufde0\uf58c\uc694\uee05\ufdeb\uf5dc\uc6e9\ueef5\ufd09\uf510\uc68d\ueee7\ufd3b\uf5ca\uc65a\ueee8\ufd68\uf51b\uc6f6\uee67\ufdcc\uf553\uc688\ueed1\ufd70\uf5c5\uc6a1\uee3f\ufd86\uf528\uc6e4\uee22\ufdaa\uf5e5\uc67c\ueede\ufdc1\uf590\uc632\ueeb7\ufde7\uf548\uc6fa\uee60\ufd70\uf5d6\uc633\uee78\ufd8c\uf500\uc6b1\ueea4\ufdae\uf5c7\uc644\uee27\ufd9c\uf5ea\uc6b6\uee14\ufd11\uf5ec\uc6fa\ueec8\ufd47\uf510\uc6ec\ueea6\ufdcd\uf5c8\uc61a\ueee5\ufd9c\uf566\uc6c5\uee79\ufd56\uf537\uc60b\ueef5\ufd4c\uf5a9\uc6c5\uee0e\ufd3f\uf595\uc6fb\ueeb9\ufd7d\uf506\uc66b\uee92\ufd82\uf5d1\uc6cf\uee14\ufd10\uf550\uc6e1\uee0f\ufdfb\uf56d\uc6ca\uee4e\ufd86\uf584\uc670\uee93\ufd0e\uf579\uc67b\uee2c\ufd6b\uf5ca\uc6bf\uee74\ufd80\uf54e\uc603\uee11\ufdf3\uf545\uc623\ueeb8\ufd00\uf571\uc6f2\uee02\ufdf2\uf5c9\uc6b4\uee7b\ufd91\uf5c6\uc61d\uee09\ufde4\uf5f1\uc6f4\uee33\ufde4\uf583\uc6af\ueed9\ufd64\uf5d2\uc6b0\ueea3\ufd01\uf556\uc629\uee3e\ufd94\uf5ce\uc607\uee56\ufdfe\uf5c9\uc6bb\ueeec\ufd50\uf5c1\uc622\ueec1\ufd2a\uf533\uc68b\ueead\ufd27\uf576\uc698\ueeb4\ufd44\uf5cc\uc6dd\ueea7\ufd44\uf5f1\uc67d\uee05\ufdba\uf51e\uc6b7\uee7f\ufdb4\uf5e0\uc685\uee93\ufd56\uf5e5\uc607\uee3e\ufdd8\uf54c\uc6c7\ueeb4\ufd3e\uf591\uc627\uee9c\ufde8\uf5e6\uc66e\uee90\ufd9b\uf5b4\uc69e\uee0c\ufd01\uf572\uc633\uee92\ufda1\uf5e5\uc6a2\uee68\ufd85\uf577\uc615\uee32\ufdb1\uf577\uc69a\uee7b\ufdbc\uf5e5\uc621\uee63\ufdb8\uf537\uc685\ueea8\ufd6a\uf5d4\uc62f\uee8c\ufd92\uf582\uc65d\ueef2\ufdda\uf5bd\uc662\uee94\ufd9d\uf5a6\uc69e\uee3c\ufdb6\uf5ab\uc6bb\uee65\ufd70\uf584\uc6bd\uee20\ufd7e\uf5ee\uc6b3\ueee1\ufd48\uf545\uc655\ueea6\ufda0\uf56e\uc6ea\ueece\ufd75\uf5f7\uc681\ueecb\ufd66\uf58e\uc6d8\uee9f\ufd72\uf590\uc6b0\ueedb\ufdc7\uf5a9\uc631\ueeba\ufd56\uf56a\uc672\ueea1\ufd5a\uf51c\uc692\ueea7\ufdcb\uf5b6\uc612\uee86\ufd5f\uf5ce\uc6fb\uee8c\ufd02\uf508\uc63d\uee26\ufd07\uf5bc\uc628\uee3d\ufd02\uf5da\uc62e\uee8d\ufdfd\uf507\uc688\uee04\ufd44\uf5cf\uc67c\ueeda\ufd56\uf54e\uc6b6\uee09\ufdac\uf567\uc634\ueea0\ufd93\uf588\uc6e9\ueefa\ufdf0\uf5b6\uc6f3\ueedd\ufdf3\uf505\uc6b8\uee83\ufdc2\uf542\uc6b0\ueed9\ufdfa\uf5a0\uc63e\uee72\ufd63\uf589\uc6d0\uee0e\ufd9c\uf5f2\uc605\uee8a\ufd71\uf52b\uc68b\ueea7\ufdef\uf5ca\uc6dd\uee88\ufda1\uf5cd\uc64c\ueeed\ufd52\uf58e\uc6a9\uee1e\ufd8a\uf5cd\uc689\uee74\ufd43\uf5e6\uc619\uee4b\ufd73\uf5de\uc6ed\ueec2\ufdf7\uf553\uc630\ueea1\ufd50\uf5b4\uc65a\ueec5\ufda8\uf56c\uc6c8\ueef2\ufd8a\uf5a5\uc639\ueed6\ufd12\uf5f4\uc616\uee28\ufdcc\uf5d4\uc6ec\uee80\ufde0\uf5f3\uc650\uee68\ufd5d\uf5e0\uc651\ueed8\ufd91\uf55d\uc61d\ueefe\ufdeb\uf5d5\uc696\ueede\ufd9f\uf520\uc6f6\uee6c\ufd3f\uf5f4\uc62c\uee09\ufda9\uf57f\uc60e\uee49\ufd28\uf5fb\uc639\uee44\ufd75\uf552\uc620\uee40\ufdd0\uf5a9\uc62e\uee4f\ufdbb\uf58f\uc68f\ueeae\ufd56\uf5f1\uc600\uee55\ufddf\uf586\uc6c6\ueeaf\ufdc7\uf535\uc688\uee99\ufdb8\uf524\uc63a\uee82\ufd62\uf596\uc60a", 1207951371);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1194940888 ^ (long)-1194940892);
            if (var7) break block23;
            var0_6 = (int)((long)-706363531 ^ (long)706363530);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1488822081 ^ (long)-1488822062);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)1778164846 ^ (long)-1778164847);
                    if (0B.\u2005\u2004\u2000\u2000\u2004) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0B.\u2005\u2004\u2000\u2000\u2004) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u4816\u60e9\u73ce\u7b59\u489c\u60fa\u7310\u7b90\u48fb\u6078\u7335\u7bc4\u48f4\u6031\u73cf\u7b94\u48b3\u60e5\u7339\u7bd7\u48d1\u60a4\u73c3\u7b8d\u4876\u60de\u7377\u7bc5\u487f\u6094\u7372", 655191683);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-1043976384 ^ (long)-1043976381);
                            var0_6 = (int)((long)985133845 ^ (long)-985133846);
                            while (true) {
                                v0 = (int)((long)856031421 ^ (long)856031372);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1112812296 ^ (long)-1112812296);
                                if (!0B.\u2005\u2004\u2000\u2000\u2004) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0B.\u2005\u2004\u2000\u2000\u2004) ** continue;
                                throw null;
                            }
                            0B.d = var5_1;
                            0B.e = new String[(int)((long)-851244289 ^ (long)-851244356)];
                            if (!0B.\u2005\u2004\u2000\u2000\u2004) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1342352424 ^ (long)-1342352424);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)-1371121430 ^ (long)-1371121429)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)522637791 ^ (long)522637784)) {
                                case 0: {
                                    v15 = (int)((long)-730578219 ^ (long)-730578290);
                                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1630101566 ^ (long)-1630101526);
                                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)761756565 ^ (long)761756637);
                                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)483862876 ^ (long)483862820);
                                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-238911594 ^ (long)-238911513);
                                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-203115478 ^ (long)-203115393);
                                    if (!0B.\u2005\u2004\u2000\u2000\u2004) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)63315378 ^ (long)63315400);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0B.\u2005\u2004\u2000\u2000\u2004);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    public 0B() {
        boolean bl = \u2005\u2004\u2000\u2000\u2004;
        super(0B.b((int)((long)-1052178437 ^ (long)-1052175124), (int)((long)1700790329 ^ (long)-1700793752)) /* "Minestrike" */, 0B.b((int)((long)198541780 ^ (long)198546129), (int)((long)-2133309705 ^ (long)-2133324789)) /* "MultiHack designed for the Minestrike Minigame" */);
        String[] stringArray = new String[(int)((long)-1671743723 ^ (long)-1671743721)];
        stringArray[(int)((long)-1725814778 ^ (long)-1725814778)] = 0B.b((int)((long)1541616070 ^ (long)1541612239), (int)((long)1391477745 ^ (long)1391474361)) /* "Aimlock" */;
        stringArray[(int)((long)-2095571680 ^ (long)-2095571679)] = 0B.b((int)((long)1059998289 ^ (long)1060002135), (int)((long)1624548807 ^ (long)-1624546492)) /* "Silent" */;
        Object object = stringArray;
        34J j3 = (34H)((34H)((34H)this.0().5(0B.b((int)((long)1403649060 ^ (long)1403645740), (int)((long)1582593653 ^ (long)-1582582725)) /* "Mode" */)).7(0B.b((int)((long)-1843495223 ^ (long)-1843499551), (int)((long)467784187 ^ (long)-467774313)) /* "mode" */)).1(0B.b((int)((long)2033068720 ^ (long)2033072540), (int)((long)413115151 ^ (long)413127081)) /* "The mode that the aimbot uses to calculate angles" */);
        ((34H)((34H)((34H)this.0().5(0B.b((int)((long)1403649060 ^ (long)1403645740), (int)((long)1582593653 ^ (long)-1582582725)) /* "Mode" */)).7(0B.b((int)((long)-1843495223 ^ (long)-1843499551), (int)((long)467784187 ^ (long)-467774313)) /* "mode" */)).1(0B.b((int)((long)2033068720 ^ (long)2033072540), (int)((long)413115151 ^ (long)413127081)) /* "The mode that the aimbot uses to calculate angles" */)).3 = object;
        this.9U = (11)j3.5();
        String[] stringArray2 = new String[(int)((long)-1131787840 ^ (long)-1131787838)];
        stringArray2[(int)((long)1821104296 ^ (long)1821104296)] = 0B.b((int)((long)-1693825104 ^ (long)-1693821705), (int)((long)-2137783082 ^ (long)2137759937)) /* "Always" */;
        stringArray2[(int)((long)1865932718 ^ (long)1865932719)] = 0B.b((int)((long)439570958 ^ (long)439566592), (int)((long)-1830497358 ^ (long)-1830506928)) /* "Shooting" */;
        object = stringArray2;
        j3 = (34H)((34H)((34H)this.0().5(0B.b((int)((long)765329915 ^ (long)765334260), (int)((long)1092125227 ^ (long)1092127843)) /* "Aim Type" */)).7(0B.b((int)((long)15430376 ^ (long)15426005), (int)((long)-1550193038 ^ (long)-1550216390)) /* "aimType" */)).1(0B.b((int)((long)296100341 ^ (long)296104650), (int)((long)-679518203 ^ (long)679521825)) /* "How locking should behave when there's a target" */);
        ((34H)((34H)((34H)this.0().5(0B.b((int)((long)765329915 ^ (long)765334260), (int)((long)1092125227 ^ (long)1092127843)) /* "Aim Type" */)).7(0B.b((int)((long)15430376 ^ (long)15426005), (int)((long)-1550193038 ^ (long)-1550216390)) /* "aimType" */)).1(0B.b((int)((long)296100341 ^ (long)296104650), (int)((long)-679518203 ^ (long)679521825)) /* "How locking should behave when there's a target" */)).3 = object;
        this.95 = (11)j3.5();
        String[] stringArray3 = new String[(int)((long)1165439657 ^ (long)1165439658)];
        stringArray3[(int)((long)1440260440 ^ (long)1440260440)] = 0B.b((int)((long)475427951 ^ (long)475424585), (int)((long)-530523147 ^ (long)530540287)) /* "Head" */;
        stringArray3[(int)((long)-772491709 ^ (long)-772491710)] = 0B.b((int)((long)1694674007 ^ (long)1694678857), (int)((long)-508622638 ^ (long)508594838)) /* "Chest" */;
        stringArray3[(int)((long)-145763916 ^ (long)-145763914)] = 0B.b((int)((long)-15845997 ^ (long)-15849795), (int)((long)-1699016148 ^ (long)1698996056)) /* "Legs" */;
        object = stringArray3;
        j3 = (34H)((34H)((34H)this.0().5(0B.b((int)((long)-227429052 ^ (long)-227432876), (int)((long)-1355792399 ^ (long)1355789743)) /* "Bone" */)).7(0B.b((int)((long)298453676 ^ (long)298457496), (int)((long)-725160923 ^ (long)725158991)) /* "bone" */)).1(0B.b((int)((long)873333385 ^ (long)873337224), (int)((long)450378601 ^ (long)-450378491)) /* "The bone that the aimbot locks on to" */);
        ((34H)((34H)((34H)this.0().5(0B.b((int)((long)-227429052 ^ (long)-227432876), (int)((long)-1355792399 ^ (long)1355789743)) /* "Bone" */)).7(0B.b((int)((long)298453676 ^ (long)298457496), (int)((long)-725160923 ^ (long)725158991)) /* "bone" */)).1(0B.b((int)((long)873333385 ^ (long)873337224), (int)((long)450378601 ^ (long)-450378491)) /* "The bone that the aimbot locks on to" */)).3 = object;
        this.7 = (11)j3.5();
        String[] stringArray4 = new String[(int)((long)953116285 ^ (long)953116287)];
        stringArray4[(int)((long)-1730228819 ^ (long)-1730228819)] = 0B.b((int)((long)709112904 ^ (long)709109597), (int)((long)86820791 ^ (long)-86808405)) /* "Distance" */;
        stringArray4[(int)((long)1824224181 ^ (long)1824224180)] = 0B.b((int)((long)2135443970 ^ (long)2135447846), (int)((long)-1019586716 ^ (long)-1019585851)) /* "Crosshair" */;
        object = stringArray4;
        j3 = (34H)((34H)((34H)this.0().5(0B.b((int)((long)-577462272 ^ (long)-577457397), (int)((long)1769076551 ^ (long)-1769078241)) /* "Priority" */)).7(0B.b((int)((long)-1115436038 ^ (long)-1115432731), (int)((long)-1558606772 ^ (long)1558595462)) /* "priority" */)).1(0B.b((int)((long)-1554191425 ^ (long)-1554188038), (int)((long)-530829732 ^ (long)-530816267)) /* "How targets are prioritized" */);
        ((34H)((34H)((34H)this.0().5(0B.b((int)((long)-577462272 ^ (long)-577457397), (int)((long)1769076551 ^ (long)-1769078241)) /* "Priority" */)).7(0B.b((int)((long)-1115436038 ^ (long)-1115432731), (int)((long)-1558606772 ^ (long)1558595462)) /* "priority" */)).1(0B.b((int)((long)-1554191425 ^ (long)-1554188038), (int)((long)-530829732 ^ (long)-530816267)) /* "How targets are prioritized" */)).3 = object;
        this.9E = (11)j3.5();
        object = Boolean.TRUE;
        j3 = (34X)((34X)((34X)this.4().5(0B.b((int)((long)-1533178834 ^ (long)-1533174009), (int)((long)1551203843 ^ (long)-1551197607)) /* "Aimbot" */)).7(0B.b((int)((long)-2010434019 ^ (long)-2010438369), (int)((long)1954311954 ^ (long)1954310639)) /* "aimbot" */)).1(0B.b((int)((long)1936549755 ^ (long)1936553059), (int)((long)-1376120452 ^ (long)1376111881)) /* "Automatically lock onto enemies" */);
        ((34X)((34X)((34X)this.4().5(0B.b((int)((long)-1533178834 ^ (long)-1533174009), (int)((long)1551203843 ^ (long)-1551197607)) /* "Aimbot" */)).7(0B.b((int)((long)-2010434019 ^ (long)-2010438369), (int)((long)1954311954 ^ (long)1954310639)) /* "aimbot" */)).1(0B.b((int)((long)1936549755 ^ (long)1936553059), (int)((long)-1376120452 ^ (long)1376111881)) /* "Automatically lock onto enemies" */)).7 = object;
        this.9 = (1P)((34X)j3).5();
        object = Boolean.TRUE;
        j3 = (34X)((34X)((34X)this.4().5(0B.b((int)((long)607059980 ^ (long)607064855), (int)((long)-452757329 ^ (long)-452781529)) /* "Auto Shoot" */)).7(0B.b((int)((long)-570020891 ^ (long)-570017548), (int)((long)1460519217 ^ (long)-1460515364)) /* "autoshoot" */)).1(0B.b((int)((long)-436709978 ^ (long)-436713839), (int)((long)-146982209 ^ (long)146992932)) /* "Automatically shoot at the targetted enemy" */);
        ((34X)((34X)((34X)this.4().5(0B.b((int)((long)607059980 ^ (long)607064855), (int)((long)-452757329 ^ (long)-452781529)) /* "Auto Shoot" */)).7(0B.b((int)((long)-570020891 ^ (long)-570017548), (int)((long)1460519217 ^ (long)-1460515364)) /* "autoshoot" */)).1(0B.b((int)((long)-436709978 ^ (long)-436713839), (int)((long)-146982209 ^ (long)146992932)) /* "Automatically shoot at the targetted enemy" */)).7 = object;
        this.9H = (1P)((34X)j3).5();
        object = Boolean.FALSE;
        j3 = (34X)((34X)((34X)this.4().5(0B.b((int)((long)2076698655 ^ (long)2076703493), (int)((long)1700739881 ^ (long)-1700741304)) /* "Friends" */)).7(0B.b((int)((long)-1354702739 ^ (long)-1354697908), (int)((long)-2009979894 ^ (long)-2009980719)) /* "friends" */)).1(0B.b((int)((long)-12823549 ^ (long)-12826866), (int)((long)948068410 ^ (long)-948046226)) /* "Target players that are tagged as a friend" */);
        ((34X)((34X)((34X)this.4().5(0B.b((int)((long)2076698655 ^ (long)2076703493), (int)((long)1700739881 ^ (long)-1700741304)) /* "Friends" */)).7(0B.b((int)((long)-1354702739 ^ (long)-1354697908), (int)((long)-2009979894 ^ (long)-2009980719)) /* "friends" */)).1(0B.b((int)((long)-12823549 ^ (long)-12826866), (int)((long)948068410 ^ (long)-948046226)) /* "Target players that are tagged as a friend" */)).7 = object;
        this.2 = (1P)((34X)j3).5();
        object = Boolean.TRUE;
        j3 = (34X)((34X)((34X)this.4().5(0B.b((int)((long)1376354768 ^ (long)1376359142), (int)((long)-1025831627 ^ (long)-1025829336)) /* "Scoped" */)).7(0B.b((int)((long)1696043620 ^ (long)1696039236), (int)((long)-293518086 ^ (long)293519605)) /* "scoped" */)).1(0B.b((int)((long)894372878 ^ (long)894377754), (int)((long)199134094 ^ (long)-199136753)) /* "Whether or not you have to be scoped to target enemies." */);
        ((34X)((34X)((34X)this.4().5(0B.b((int)((long)1376354768 ^ (long)1376359142), (int)((long)-1025831627 ^ (long)-1025829336)) /* "Scoped" */)).7(0B.b((int)((long)1696043620 ^ (long)1696039236), (int)((long)-293518086 ^ (long)293519605)) /* "scoped" */)).1(0B.b((int)((long)894372878 ^ (long)894377754), (int)((long)199134094 ^ (long)-199136753)) /* "Whether or not you have to be scoped to target enemies." */)).7 = object;
        this.9C = (1P)((34X)j3).5();
        object = Boolean.TRUE;
        j3 = (34X)((34X)((34X)this.4().5(0B.b((int)((long)2051422957 ^ (long)2051418612), (int)((long)1177411349 ^ (long)1177389955)) /* "Player ESP" */)).7(0B.b((int)((long)1127307744 ^ (long)1127303846), (int)((long)1704596208 ^ (long)1704596236)) /* "esp" */)).1(0B.b((int)((long)-1197277564 ^ (long)-1197281897), (int)((long)-1432580085 ^ (long)-1432556517)) /* "Reveals player locations with a box" */);
        ((34X)((34X)((34X)this.4().5(0B.b((int)((long)2051422957 ^ (long)2051418612), (int)((long)1177411349 ^ (long)1177389955)) /* "Player ESP" */)).7(0B.b((int)((long)1127307744 ^ (long)1127303846), (int)((long)1704596208 ^ (long)1704596236)) /* "esp" */)).1(0B.b((int)((long)-1197277564 ^ (long)-1197281897), (int)((long)-1432580085 ^ (long)-1432556517)) /* "Reveals player locations with a box" */)).7 = object;
        this.1 = (1P)((34X)j3).5();
        object = Boolean.TRUE;
        j3 = (34X)((34X)((34X)this.4().5(0B.b((int)((long)-726619523 ^ (long)-726615731), (int)((long)1893536361 ^ (long)-1893554610)) /* "Item ESP" */)).7(0B.b((int)((long)-1277103504 ^ (long)-1277107890), (int)((long)-517285279 ^ (long)517298748)) /* "items" */)).1(0B.b((int)((long)1647544301 ^ (long)1647547598), (int)((long)-2133371246 ^ (long)-2133387406)) /* "Draws a box around grenades" */);
        ((34X)((34X)((34X)this.4().5(0B.b((int)((long)-726619523 ^ (long)-726615731), (int)((long)1893536361 ^ (long)-1893554610)) /* "Item ESP" */)).7(0B.b((int)((long)-1277103504 ^ (long)-1277107890), (int)((long)-517285279 ^ (long)517298748)) /* "items" */)).1(0B.b((int)((long)1647544301 ^ (long)1647547598), (int)((long)-2133371246 ^ (long)-2133387406)) /* "Draws a box around grenades" */)).7 = object;
        this.99 = (1P)((34X)j3).5();
        this.9f = (1P)((34X)((34X)((34X)this.4().5(0B.b((int)((long)-652359967 ^ (long)-652356126), (int)((long)1574040232 ^ (long)-1574023864)) /* "Draw FOV" */)).7(0B.b((int)((long)-1892510861 ^ (long)-1892515761), (int)((long)1928542294 ^ (long)1928554045)) /* "drawfov" */)).1(0B.b((int)((long)1029262521 ^ (long)1029267348), (int)((long)630327178 ^ (long)630330528)) /* "Draws a circle that shows your FOV" */)).5();
        object = Float.valueOf(360.0f);
        j3 = ((34e)((34e)((34e)this.9().5(0B.b((int)((long)1690126987 ^ (long)1690130872), (int)((long)-1485973659 ^ (long)-1485983622)) /* "FOV" */)).7(0B.b((int)((long)1364001291 ^ (long)1364005152), (int)((long)-687213501 ^ (long)687230583)) /* "fov" */)).1(0B.b((int)((long)1320937105 ^ (long)1320940971), (int)((long)94014041 ^ (long)-94039947)) /* "Target enemies within a certain FOV" */)).3(Float.valueOf(10.0f)).2(Float.valueOf(360.0f));
        ((34e)((34e)((34e)this.9().5(0B.b((int)((long)1690126987 ^ (long)1690130872), (int)((long)-1485973659 ^ (long)-1485983622)) /* "FOV" */)).7(0B.b((int)((long)1364001291 ^ (long)1364005152), (int)((long)-687213501 ^ (long)687230583)) /* "fov" */)).1(0B.b((int)((long)1320937105 ^ (long)1320940971), (int)((long)94014041 ^ (long)-94039947)) /* "Target enemies within a certain FOV" */)).3(Float.valueOf(10.0f)).2(Float.valueOf(360.0f)).7 = object;
        this.9d = (1A)((34e)j3).5();
        object = Boolean.TRUE;
        j3 = (34X)((34X)((34X)this.4().5(0B.b((int)((long)670372964 ^ (long)670369629), (int)((long)417451842 ^ (long)-417440244)) /* "No Smoke Lag" */)).7(0B.b((int)((long)-1744055179 ^ (long)-1744058511), (int)((long)2137172109 ^ (long)-2137170286)) /* "nsl" */)).1(0B.b((int)((long)-1198814535 ^ (long)-1198810716), (int)((long)-969667453 ^ (long)969639867)) /* "Prevents lag caused by smokes" */);
        ((34X)((34X)((34X)this.4().5(0B.b((int)((long)670372964 ^ (long)670369629), (int)((long)417451842 ^ (long)-417440244)) /* "No Smoke Lag" */)).7(0B.b((int)((long)-1744055179 ^ (long)-1744058511), (int)((long)2137172109 ^ (long)-2137170286)) /* "nsl" */)).1(0B.b((int)((long)-1198814535 ^ (long)-1198810716), (int)((long)-969667453 ^ (long)969639867)) /* "Prevents lag caused by smokes" */)).7 = object;
        this.9z = (1P)((34X)j3).5();
        object = Boolean.TRUE;
        j3 = (34X)((34X)((34X)this.4().5(0B.b((int)((long)-776665655 ^ (long)-776661298), (int)((long)1356627767 ^ (long)1356610250)) /* "Ignore Smoke" */)).7(0B.b((int)((long)-144010933 ^ (long)-144014773), (int)((long)-59541570 ^ (long)-59545213)) /* "ignoresmoke" */)).1(0B.b((int)((long)1654646637 ^ (long)1654649944), (int)((long)-275458611 ^ (long)-275448356)) /* "Ignores smoke when raytracing target positions" */);
        ((34X)((34X)((34X)this.4().5(0B.b((int)((long)-776665655 ^ (long)-776661298), (int)((long)1356627767 ^ (long)1356610250)) /* "Ignore Smoke" */)).7(0B.b((int)((long)-144010933 ^ (long)-144014773), (int)((long)-59541570 ^ (long)-59545213)) /* "ignoresmoke" */)).1(0B.b((int)((long)1654646637 ^ (long)1654649944), (int)((long)-275458611 ^ (long)-275448356)) /* "Ignores smoke when raytracing target positions" */)).7 = object;
        this.9w = (1P)((34X)j3).5();
        object = Boolean.TRUE;
        j3 = (34X)((34X)((34X)this.4().5(0B.b((int)((long)356820171 ^ (long)356825072), (int)((long)526868986 ^ (long)-526874945)) /* "Latency Compensation" */)).7(0B.b((int)((long)-976483546 ^ (long)-976480244), (int)((long)-1015940047 ^ (long)-1015958684)) /* "latencycomp" */)).1(0B.b((int)((long)1021982668 ^ (long)1021977838), (int)((long)-559329474 ^ (long)559335526)) /* "Compensates for your latency compared to other player's" */);
        ((34X)((34X)((34X)this.4().5(0B.b((int)((long)356820171 ^ (long)356825072), (int)((long)526868986 ^ (long)-526874945)) /* "Latency Compensation" */)).7(0B.b((int)((long)-976483546 ^ (long)-976480244), (int)((long)-1015940047 ^ (long)-1015958684)) /* "latencycomp" */)).1(0B.b((int)((long)1021982668 ^ (long)1021977838), (int)((long)-559329474 ^ (long)559335526)) /* "Compensates for your latency compared to other player's" */)).7 = object;
        this.9P = (1P)((34X)j3).5();
        this.9t = (1z)((34e)((34e)((34e)this.1().5(0B.b((int)((long)48006411 ^ (long)48010788), (int)((long)-2146337273 ^ (long)2146358293)) /* "Visible Ticks" */)).7(0B.b((int)((long)1872867527 ^ (long)1872864255), (int)((long)127758268 ^ (long)-127746593)) /* "visibleTicks" */)).1(0B.b((int)((long)-1378881310 ^ (long)-1378884632), (int)((long)-894122634 ^ (long)894116675)) /* "The amount of ticks an enemy must be visible for to be targetted" */)).3((int)((long)-1913144367 ^ (long)-1913144367)).2((int)((long)-1900943378 ^ (long)-1900943418)).5();
        this.9p = (int)((long)-1028512302 ^ (long)-1028512302);
        float[] fArray = new float[(int)((long)-26096385 ^ (long)-26096388)];
        fArray[(int)((long)1409850556 ^ (long)1409850556)] = 1.0f;
        fArray[(int)((long)670082258 ^ (long)670082259)] = 0.0f;
        fArray[(int)((long)1079872556 ^ (long)1079872558)] = 1.0f;
        float[] fArray2 = new float[(int)((long)-1922043970 ^ (long)-1922043971)];
        fArray2[(int)((long)496278656 ^ (long)496278656)] = 0.6f;
        fArray2[(int)((long)953387355 ^ (long)953387354)] = 0.6f;
        fArray2[(int)((long)1526940972 ^ (long)1526940974)] = 0.6f;
        float[] fArray3 = new float[(int)((long)1803372056 ^ (long)1803372059)];
        fArray3[(int)((long)-683752169 ^ (long)-683752169)] = 1.0f;
        fArray3[(int)((long)-1010910617 ^ (long)-1010910618)] = 0.4f;
        fArray3[(int)((long)-264391530 ^ (long)-264391532)] = 0.0f;
        float[] fArray4 = new float[(int)((long)10999550 ^ (long)10999549)];
        fArray4[(int)((long)-1498542542 ^ (long)-1498542542)] = 1.0f;
        fArray4[(int)((long)-888342283 ^ (long)-888342284)] = 1.0f;
        fArray4[(int)((long)1187718524 ^ (long)1187718526)] = 1.0f;
        float[] fArray5 = new float[(int)((long)-1860300024 ^ (long)-1860300021)];
        fArray5[(int)((long)-1031522259 ^ (long)-1031522259)] = 0.0f;
        fArray5[(int)((long)1662248928 ^ (long)1662248929)] = 0.3f;
        fArray5[(int)((long)1342654637 ^ (long)1342654639)] = 0.0f;
        this.4 = new ImmutableMap.Builder().put((Object)((int)((long)-731000739 ^ (long)-731000506)), (Object)fArray).put((Object)((int)((long)1965895444 ^ (long)1965895324)), (Object)fArray2).put((Object)((int)((long)613467331 ^ (long)613467644)), (Object)fArray3).put((Object)((int)((long)710532423 ^ (long)710532288)), (Object)fArray4).put((Object)((int)((long)59940460 ^ (long)59940712)), (Object)fArray5).build();
        this.9B = new Object2IntArrayMap();
        this.9l = new 3k();
        this.9M = new Listener(x2 -> {
            int n;
            Comparator<18> comparator;
            int n2;
            String string;
            boolean bl = \u2005\u2004\u2000\u2000\u2004;
            if (bl) return;
            String[] stringArray = 3e.5();
            if (bl || bl) return;
            if (x2.7 == EventState.POST) {
                if (bl || bl) return;
                if (this.8 != null) {
                    if (bl) return;
                    if (this.9H.2) {
                        if (bl || bl) return;
                        0B.3.q.a((bfw)0B.3.s, (brx)0B.3.r, aot.a);
                        if (bl) return;
                    }
                }
                if (bl) return;
                return;
            }
            if (bl) return;
            this.9l.0();
            if (bl || bl) return;
            this.9B.keySet().removeIf(var1_1 -> {
                boolean bl = \u2005\u2004\u2000\u2000\u2004;
                if (bl || bl) return true;
                if (!this.9l.3().contains(var1_1)) {
                    if (bl) return true;
                    return (int)((long)609530684 ^ (long)609530685) != 0;
                }
                if (!bl) return (int)((long)664941170 ^ (long)664941170) != 0;
                return true;
            });
            if (bl || bl) return;
            this.8 = null;
            if (bl || bl) {
                return;
            }
            String string2 = 0B.b((int)((long)-1896231164 ^ (long)-1896227807), (int)((long)-846683768 ^ (long)-846675358)) /* "suffix" */;
            if (this.9.2 && this.9l.5) {
                string = (String)this.9U.0();
                if (\u2005\u2004\u2000\u2000\u2004) {
                    throw null;
                }
            } else {
                string = 2w$6X.KAOZ("", -751255494);
            }
            2R.1(this, string2, string);
            if (!this.9l.5 || 5z.4().1z.7(0F.class).3()) {
                return;
            }
            Object object = this.9l.9;
            if (!((18)object).5.d || !this.9.2) {
                return;
            }
            if (((18)object).4.2() && ((18)object).4.7().h) {
                n2 = (int)((long)-1495939280 ^ (long)-1495939279);
                if (\u2005\u2004\u2000\u2000\u2004) {
                    throw null;
                }
            } else {
                n2 = (int)((long)-94387493 ^ (long)-94387493);
            }
            if (n2 == 0) {
                return;
            }
            Stream<18> stream = this.9l.3().stream();
            String string3 = ((String)this.9E.0()).toLowerCase();
            int n3 = (int)((long)1282719862 ^ (long)-1282719863);
            switch (string3.hashCode()) {
                case 288459765: {
                    if (!string3.equals(0B.b((int)((long)-819499345 ^ (long)-819495517), (int)((long)-854249730 ^ (long)854245280)) /* "distance" */)) break;
                    n3 = (int)((long)-1001013814 ^ (long)-1001013814);
                    if (stringArray == null) break;
                }
                case 1397962786: {
                    if (!string3.equals(0B.b((int)((long)1805373519 ^ (long)1805370205), (int)((long)505382073 ^ (long)505390172)) /* "crosshair" */)) break;
                    n3 = (int)((long)944408551 ^ (long)944408550);
                    break;
                }
            }
            switch (n3) {
                case 0: {
                    comparator = Comparator.comparingDouble(var0 -> {
                        boolean bl = \u2005\u2004\u2000\u2000\u2004;
                        if (bl || bl) {
                            return 0.0;
                        }
                        return var0.8.g((aqa)0B.3.s);
                    });
                    if (!\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                case 1: {
                    comparator = Comparator.comparingDouble(var0 -> {
                        boolean bl = \u2005\u2004\u2000\u2000\u2004;
                        if (bl || bl) {
                            return 0.0;
                        }
                        return 66.3((aqa)var0.8);
                    });
                    if (!\u2005\u2004\u2000\u2000\u2004) break;
                    throw null;
                }
                default: {
                    comparator = Comparator.comparingDouble(var0 -> {
                        boolean bl = \u2005\u2004\u2000\u2000\u2004;
                        if (bl || bl) {
                            return 0.0;
                        }
                        return 0.0;
                    });
                }
            }
            stream.sorted(comparator).forEach(arg_0 -> this.9((18)object, arg_0));
            if (((18)object).4.7() == 3Y.d) {
                int n4;
                18 var4_7 = object;
                if (var4_7.8.bz() && ((bmb)var4_7.8.bm.b.get((int)((long)-128803241 ^ (long)-128803244))).b() == bup.cK.h() && !var4_7.8.a(apw.p)) {
                    n4 = (int)((long)-1345603757 ^ (long)-1345603758);
                    if (\u2005\u2004\u2000\u2000\u2004) {
                        throw null;
                    }
                } else {
                    n4 = (int)((long)-411998385 ^ (long)-411998385);
                }
                if (n4 == 0 && this.9C.2) {
                    this.8 = null;
                }
            }
            18 var4_8 = object;
            string3 = 18.3.v;
            if (var4_8.8 == 18.3.s && var4_8.5 == 3sg.a && string3.c() == dcl.a.b && 34L.7(((dcj)string3).a()) instanceof bvv) {
                n = (int)((long)1999814245 ^ (long)1999814244);
                if (\u2005\u2004\u2000\u2000\u2004) {
                    throw null;
                }
            } else {
                n = (int)((long)55471669 ^ (long)55471669);
            }
            if (n != 0) {
                this.8 = null;
                x2.6(0B.3.s.p).2(0B.3.s.q);
            }
            if (this.8 == null) return;
            0B b2 = this;
            object = 66.3(b2.2(b2.8.8));
            if (((String)this.95.0()).equals(0B.b((int)((long)2132211592 ^ (long)2132206740), (int)((long)1933194253 ^ (long)-1933200392))) && !this.9H.2 && !0B.3.k.ap.d()) {
                return;
            }
            x2.6(((9V)object).6).2(((9V)object).3);
            if (!((String)this.9U.0()).equals(0B.b((int)((long)-1342561763 ^ (long)-1342557941), (int)((long)514745312 ^ (long)-514721189)))) return;
            0B.3.s.p = ((9V)object).6;
            0B.3.s.q = ((9V)object).3;
        }, new Predicate[(int)((long)863347579 ^ (long)863347579)]);
        this.0 = new Listener(j2 -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2005\u2004\u2000\u2000\u2004;
                        if (bl || bl) break block2;
                        if (!this.9p) break block3;
                        if (bl) break block2;
                        if (j2.6.n().c() != cva.c) break block3;
                        if (bl || bl) break block2;
                        j2.cancel();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-492059771 ^ (long)-492059771)]);
        this.5 = new Listener(r2 -> {
            boolean bl = \u2005\u2004\u2000\u2000\u2004;
            if (bl || bl) return;
            if (!this.9f.2) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            int n = 3.aD().k() / (int)((long)-1031063405 ^ (long)-1031063407);
            if (bl || bl) return;
            int n2 = 3.aD().l() / (int)((long)843874095 ^ (long)843874093);
            if (bl || bl) return;
            float f = (float)0B.3.k.aO;
            if (bl || bl) return;
            float f2 = (float)Math.toRadians(this.9d.9 / 2.0f);
            f = afm.a((float)f2) / afm.b((float)f2) / (afm.a((float)f) / afm.b((float)f)) * (float)n;
            if (bl || bl) return;
            5K.6((int)((long)-1829872819 ^ (long)1829854029));
            if (bl || bl) return;
            9b.6((boolean)((long)226467252 ^ (long)226467253));
            if (bl || bl) return;
            RenderSystem.lineWidth((float)1.0f);
            if (bl || bl) return;
            GL11.glBegin((int)((int)((long)-428924546 ^ (long)-428924548)));
            if (bl || bl) return;
            int n3 = (int)((long)-412473760 ^ (long)-412473760);
            if (bl) return;
            while (!bl) {
                if (n3 < (int)((long)-2132223903 ^ (long)-2132223735)) {
                    if (bl || bl) return;
                    float f3 = afm.a((float)((float)Math.toRadians(n3))) * f + (float)n;
                    if (bl || bl) return;
                    float f4 = afm.b((float)((float)Math.toRadians(n3))) * f + (float)n2;
                    if (bl || bl) return;
                    GL11.glVertex2d((double)f3, (double)f4);
                    if (bl || bl) return;
                    ++n3;
                    if (bl) return;
                    if (!\u2005\u2004\u2000\u2000\u2004) continue;
                    throw null;
                }
                if (bl) return;
                GL11.glEnd();
                if (bl || bl) return;
                9b.6((boolean)((long)-2046278365 ^ (long)-2046278365));
                if (bl || bl) return;
                5K.6((int)((long)-454779919 ^ (long)454779918));
                if (!bl && !bl) return;
            }
        }, new Predicate[(int)((long)-623354757 ^ (long)-623354757)]);
        this.93 = new Listener(u -> {
            boolean bl;
            block11: {
                block10: {
                    block9: {
                        block8: {
                            bl = \u2005\u2004\u2000\u2000\u2004;
                            if (bl || bl) return;
                            if (!this.9z.2) break block8;
                            if (bl) return;
                            if (this.9l.5) break block9;
                            if (bl) return;
                        }
                        if (bl) return;
                        return;
                    }
                    if (bl) return;
                    if (u.7.b().equals(hh.Q)) break block10;
                    if (bl) return;
                    if (!u.7.b().equals(hh.f)) break block11;
                    if (bl) return;
                }
                if (bl) return;
                u.cancel();
                if (bl) return;
            }
            if (!bl) return;
        }, new Predicate[(int)((long)-129953386 ^ (long)-129953386)]);
        this.6 = new Listener(o -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2005\u2004\u2000\u2000\u2004;
                        if (bl || bl) break block2;
                        this.9l.3().forEach(var2_2 -> {
                            boolean bl = \u2005\u2004\u2000\u2000\u2004;
                            if (bl || bl) return;
                            if (!0B.5(var2_2)) {
                                if (bl || bl) return;
                                return;
                            }
                            if (bl) return;
                            int n = var2_2.5.c;
                            if (bl || bl) return;
                            if (this.1.2) {
                                if (bl || bl) return;
                                2n.4((aqa)var2_2.8, n, (boolean)((long)-1663482786 ^ (long)-1663482785), o.3());
                                if (bl) return;
                            }
                            if (!bl) return;
                        });
                        if (bl || bl) break block2;
                        if (!this.99.2) break block3;
                        if (bl || bl) break block2;
                        0B.3.r.b().forEach(aqa2 -> {
                            block4: {
                                block2: {
                                    boolean bl;
                                    block3: {
                                        bl = \u2005\u2004\u2000\u2000\u2004;
                                        if (bl || bl) break block2;
                                        if (!(aqa2 instanceof bcv)) break block3;
                                        if (bl || bl) break block2;
                                        aqa2 = (bcv)aqa2;
                                        if (bl || bl) break block2;
                                        float[] fArray = (float[])this.4.get((Object)blx.a((blx)aqa2.g().b()));
                                        if (fArray == null) break block3;
                                        if (bl || bl) break block2;
                                        2n.3((bcv)aqa2, 34L.4(fArray), 1.0f, o.3());
                                        if (bl) break block2;
                                    }
                                    if (!bl) break block4;
                                }
                                return;
                            }
                        });
                        if (bl || bl) break block2;
                        0B.3.r.j.forEach(ccj2 -> {
                            block4: {
                                block2: {
                                    boolean bl;
                                    block3: {
                                        bl = \u2005\u2004\u2000\u2000\u2004;
                                        if (bl || bl) break block2;
                                        if (!(ccj2 instanceof ccr)) break block3;
                                        if (bl || bl) break block2;
                                        dci dci2 = bup.fv.n().j((brc)0B.3.r, ccj2.o()).a();
                                        if (bl || bl) break block2;
                                        Object object = (2c)3.ac();
                                        if (bl || bl) break block2;
                                        dci2 = dci2.d(-object.getRenderPosX(), -object.getRenderPosY(), -object.getRenderPosZ());
                                        if (bl || bl) break block2;
                                        float[] fArray = (float[])this.4.get((Object)((int)((long)650300296 ^ (long)650300051)));
                                        object = fArray;
                                        int n = 34L.0(fArray[(int)((long)-1900008575 ^ (long)-1900008575)], (float)object[(int)((long)1040161730 ^ (long)1040161731)], (float)object[(int)((long)1387348213 ^ (long)1387348215)], 1.0f);
                                        if (bl || bl) break block2;
                                        int n2 = 34L.0((float)object[(int)((long)1857354698 ^ (long)1857354698)], (float)object[(int)((long)1466767327 ^ (long)1466767326)], (float)object[(int)((long)1802453910 ^ (long)1802453908)], 0.2f);
                                        if (bl || bl) break block2;
                                        2n.0(dci2.a(ccj2.o()), n2, n, 1.0f);
                                        if (bl) break block2;
                                    }
                                    if (!bl) break block4;
                                }
                                return;
                            }
                        });
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-1512648036 ^ (long)-1512648036)]);
    }
}

