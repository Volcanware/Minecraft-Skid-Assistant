/* ==========================================================================
 * MODULE: Liquid Interact
 * CATEGORY (inferred): Render
 * DESCRIPTION: Enables place/break interaction with Liquids
 * OBFUSCATED CLASS: net.impactclient.7a
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 */
package net.impactclient;

import net.impactclient.2w$6X;
import net.impactclient.34R;
import net.impactclient.3X;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7a
extends 3X
implements 34R {
    public static final boolean \u2001\u200d;
    private static final String[] e;
    private static final String[] d;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7a.\u2001\u200d;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)800672236 ^ (long)-800661668)) & (int)((long)397723357 ^ (long)397687074);
            if (var9_2) ** GOTO lbl-1000
            if (7a.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7a.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)978530034 ^ (long)978530034)] & (int)((long)576002730 ^ (long)576002645)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)1015632343 ^ (long)1015632165);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)484295862 ^ (long)484295732);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-477455487 ^ (long)-477455597);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1863475880 ^ (long)1863475955);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)507212652 ^ (long)507212634);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1307106448 ^ (long)-1307106456);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)665968411 ^ (long)665968603);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1645082523 ^ (long)-1645082604);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)1669545327 ^ (long)1669545454);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1952798217 ^ (long)-1952798366);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1351137358 ^ (long)-1351137508);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-788417459 ^ (long)-788417316);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)136617605 ^ (long)136617580);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-1425517545 ^ (long)-1425517538);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-129521929 ^ (long)-129522160);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-162186370 ^ (long)-162186466);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1102025494 ^ (long)1102025665);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1617757719 ^ (long)-1617757842);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1574846366 ^ (long)-1574846439);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-220145194 ^ (long)-220145286);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)159152246 ^ (long)159152331);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-15499682 ^ (long)-15499540);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-505454675 ^ (long)-505454750);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)403913469 ^ (long)403913450);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)381030949 ^ (long)381030950);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)788723749 ^ (long)788723890);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)874830194 ^ (long)874830319);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1010854498 ^ (long)1010854594);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)352899830 ^ (long)352899779);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)551950338 ^ (long)551950471);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-945663235 ^ (long)-945663271);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)130677110 ^ (long)130677229);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)35056580 ^ (long)35056435);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1263376204 ^ (long)1263376336);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-172575976 ^ (long)-172575945);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)691857258 ^ (long)691857219);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1488963553 ^ (long)-1488963541);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1680031092 ^ (long)1680030978);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1533989072 ^ (long)1533988891);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)608821139 ^ (long)608821079);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-2045256415 ^ (long)-2045256422);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)761684189 ^ (long)761684176);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1148749402 ^ (long)-1148749395);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)312904935 ^ (long)312904812);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-639565485 ^ (long)-639565432);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1596470192 ^ (long)-1596470219);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1021849610 ^ (long)1021849781);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-561391437 ^ (long)-561391392);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1894521338 ^ (long)-1894521115);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-992407176 ^ (long)-992407187);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-152733450 ^ (long)-152733534);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)224227794 ^ (long)224227660);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-1746200850 ^ (long)-1746200927);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)431937386 ^ (long)431937280);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1789966374 ^ (long)1789966353);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)26699935 ^ (long)26699966);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)134537614 ^ (long)134537555);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1238917849 ^ (long)1238917662);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-875303542 ^ (long)-875303636);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)858645616 ^ (long)858645732);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)512735154 ^ (long)512735044);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1854535248 ^ (long)1854535293);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)2027088022 ^ (long)2027088107);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1971827686 ^ (long)1971827580);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)248098541 ^ (long)248098451);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)2018561158 ^ (long)2018561246);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1515385645 ^ (long)1515385821);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1352244003 ^ (long)1352244182);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1015959894 ^ (long)-1015959894);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1957323424 ^ (long)-1957323423);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)1715493107 ^ (long)1715493072);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1439766580 ^ (long)1439766645);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1836198658 ^ (long)1836198662);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1934720947 ^ (long)1934720969);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-530812247 ^ (long)-530812412);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-573361900 ^ (long)-573361670);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1233067764 ^ (long)1233067770);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1712092695 ^ (long)1712092711);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1771980106 ^ (long)1771980257);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1097620683 ^ (long)-1097620629);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)565423079 ^ (long)565422940);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)786304819 ^ (long)786304843);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1931967016 ^ (long)1931967093);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-712462109 ^ (long)-712462163);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1597264883 ^ (long)-1597264888);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1288532583 ^ (long)-1288532491);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1875006626 ^ (long)-1875006656);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)665315051 ^ (long)665314865);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-610985608 ^ (long)-610985635);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-1038297888 ^ (long)-1038297918);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1224855883 ^ (long)1224855868);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1443962388 ^ (long)-1443962593);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)1536843070 ^ (long)1536843224);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1838091834 ^ (long)-1838091852);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1604947204 ^ (long)-1604947226);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)385342149 ^ (long)385342115);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1268078977 ^ (long)-1268078904);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)325499396 ^ (long)325499552);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-128059305 ^ (long)-128059144);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1175757287 ^ (long)1175757134);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1570684352 ^ (long)1570684329);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1047805766 ^ (long)-1047805845);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1698379672 ^ (long)1698379594);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1448185789 ^ (long)-1448185695);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-563630959 ^ (long)-563630930);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-454151758 ^ (long)-454151935);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1273458341 ^ (long)1273458195);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1850235874 ^ (long)-1850235698);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-370033269 ^ (long)-370033203);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1864732143 ^ (long)-1864731940);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-545988216 ^ (long)-545988292);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)777816428 ^ (long)777816556);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)2097180167 ^ (long)2097180224);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)2087276539 ^ (long)2087276402);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)1921172895 ^ (long)1921172983);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1087945829 ^ (long)-1087945849);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-926032256 ^ (long)-926032179);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-2127376046 ^ (long)-2127375957);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1403472139 ^ (long)1403472338);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1930529268 ^ (long)-1930529242);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)2037787659 ^ (long)2037787841);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1408042190 ^ (long)-1408042025);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)44639439 ^ (long)44639444);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1962312698 ^ (long)1962312690);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1301704528 ^ (long)-1301704507);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1708045214 ^ (long)1708045231);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1404334232 ^ (long)-1404334154);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1463980378 ^ (long)-1463980389);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1719403685 ^ (long)-1719403564);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1189742162 ^ (long)-1189742106);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)824781795 ^ (long)824781808);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-1507645386 ^ (long)-1507645430);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-84535045 ^ (long)-84535189);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)2105179429 ^ (long)2105179420);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)1322150714 ^ (long)1322150695);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-899383010 ^ (long)-899382947);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-301265340 ^ (long)-301265347);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-2022194254 ^ (long)-2022194411);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)187997226 ^ (long)187997410);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1088357127 ^ (long)1088357370);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-299897976 ^ (long)-299898025);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)951723431 ^ (long)951723347);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)231457571 ^ (long)231457585);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-62931911 ^ (long)-62931844);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1845318015 ^ (long)-1845318133);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1211274661 ^ (long)1211274500);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-584115313 ^ (long)-584115288);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1132165102 ^ (long)1132164882);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1799715257 ^ (long)-1799715277);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1631133234 ^ (long)-1631133310);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1758026087 ^ (long)1758026034);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-520951231 ^ (long)-520951295);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1329921485 ^ (long)1329921305);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1116794479 ^ (long)-1116794462);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-809748220 ^ (long)-809747996);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1687124220 ^ (long)1687124069);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1661570004 ^ (long)1661569942);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1095940304 ^ (long)1095940306);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-453101647 ^ (long)-453101735);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)741120414 ^ (long)741120428);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1235199107 ^ (long)1235199108);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)81704121 ^ (long)81704024);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1130858610 ^ (long)1130858742);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1373055632 ^ (long)1373055598);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1100804745 ^ (long)1100804665);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-866824591 ^ (long)-866824521);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1896377953 ^ (long)-1896377968);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1711863528 ^ (long)1711863355);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-2090394084 ^ (long)-2090393904);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1913624052 ^ (long)-1913623839);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1200397937 ^ (long)1200398076);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-443356454 ^ (long)-443356610);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1533148073 ^ (long)1533147986);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)123113872 ^ (long)123113910);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-488505457 ^ (long)-488505577);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-158432137 ^ (long)-158432058);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-541198246 ^ (long)-541198267);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)597052758 ^ (long)597052794);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1052653791 ^ (long)-1052653592);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)473623142 ^ (long)473623110);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1605234334 ^ (long)1605234292);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-107867905 ^ (long)-107867917);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1336732533 ^ (long)1336732421);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1204431838 ^ (long)1204431718);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1286720066 ^ (long)1286720251);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1791165421 ^ (long)-1791165332);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)192440292 ^ (long)192440201);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1515942781 ^ (long)1515942723);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)330127552 ^ (long)330127562);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)111746531 ^ (long)111746554);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)182186632 ^ (long)182186571);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)72004072 ^ (long)72004078);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)1653394287 ^ (long)1653394308);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-49523117 ^ (long)-49523190);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1232008306 ^ (long)-1232008431);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-886601280 ^ (long)-886601405);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1713625199 ^ (long)-1713625260);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1918042581 ^ (long)1918042377);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1277285494 ^ (long)1277285626);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)885539546 ^ (long)885539448);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1308879097 ^ (long)1308878986);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1892309620 ^ (long)1892309552);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1149097298 ^ (long)-1149097230);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1279748074 ^ (long)-1279747938);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-908913234 ^ (long)-908913290);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-549051198 ^ (long)-549051243);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)181833675 ^ (long)181833627);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)571294217 ^ (long)571294247);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)278432021 ^ (long)278432249);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-475799329 ^ (long)-475799365);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1347875058 ^ (long)1347874894);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1189890196 ^ (long)1189890294);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-255682914 ^ (long)-255683064);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)109240756 ^ (long)109240599);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1373737460 ^ (long)-1373737448);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1318813930 ^ (long)-1318813808);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1015978766 ^ (long)1015978804);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)1514499162 ^ (long)1514499215);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)888509176 ^ (long)888508930);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-776074821 ^ (long)-776074766);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-2000896408 ^ (long)-2000896457);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-2044924657 ^ (long)-2044924495);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-818902184 ^ (long)-818902103);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1489496669 ^ (long)-1489496628);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1373161807 ^ (long)1373161911);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-822510055 ^ (long)-822510030);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1239089246 ^ (long)-1239089300);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1473797348 ^ (long)1473797364);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-1363351838 ^ (long)-1363351951);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-727074087 ^ (long)-727074120);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1927346544 ^ (long)-1927346441);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-107331445 ^ (long)-107331363);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)97994737 ^ (long)97994683);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-895712590 ^ (long)-895712708);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)905877676 ^ (long)905877508);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)2060348043 ^ (long)2060347937);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1632340376 ^ (long)-1632340422);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-438632597 ^ (long)-438632704);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1978598931 ^ (long)-1978598971);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-75378473 ^ (long)-75378574);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1915310811 ^ (long)1915310797);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1317384856 ^ (long)-1317384949);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-83118348 ^ (long)-83118514);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)408891275 ^ (long)408891252);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)626227424 ^ (long)626227386);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)213679139 ^ (long)213679330);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-317459037 ^ (long)-317459022);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)1160656051 ^ (long)1160656098);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1472009420 ^ (long)-1472009400);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)450359308 ^ (long)450359514);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-689232923 ^ (long)-689233142);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)-970098055 ^ (long)-970097989);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-119357785 ^ (long)-119357934);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1449759063 ^ (long)1449759004);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1500371131 ^ (long)1500371157);
                    if (!7a.\u2001\u200d) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)439549009 ^ (long)439549033);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)430261206 ^ (long)430261033)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)674525282 ^ (long)674533277)) >>> (int)((long)-1101499566 ^ (long)-1101499558)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1653298119 ^ (long)1653298119);
            if (!7a.\u2001\u200d) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)327793009 ^ (long)327793011);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1373460888 ^ (long)1373460891) | var5_6 << (int)((long)2100153220 ^ (long)2100153217)) ^ var3_4[var7_8]) & (int)((long)943114648 ^ (long)943114599);
                    if (7a.\u2001\u200d) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1716952205 ^ (long)-1716952208) | var6_7 << (int)((long)1071381036 ^ (long)1071381033)) ^ var3_4[var7_8]) & (int)((long)-1975031821 ^ (long)-1975032052);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7a.e[var2_3] = new String(var3_4).intern();
        }
        return 7a.e[var2_3];
    }

    public 7a() {
        boolean bl = \u2001\u200d;
        super(7a.b((int)((long)1415300623 ^ (long)-1415294785), (int)((long)388150678 ^ (long)-388168468)) /* "Liquid Interact" */, 7a.b((int)((long)396747776 ^ (long)-396725583), (int)((long)1052583097 ^ (long)-1052582483)) /* "Enables place/break interaction with Liquids" */);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 7a.\u2001\u200d;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)333503185 ^ (long)333503187)];
            if (var7) break block16;
            var3_2 = (int)((long)724859834 ^ (long)724859834);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u0ce7\u259b\u36a7\u3eca\u0c32\u25cf\u36b3\u3e14\u0cda\u259b\u3692\u3e7f\u0cc2\u25c3\u36aa\u3ee5\u0c76\u25da\u36ad\u3e12\u0c64\u2520\u368f\u3ea1\u0c7a\u2571\u365f\u3e28\u0cfb\u2556\u361f\u3ee0\u0cb4\u25ac\u3637\u3eb4\u0ceb\u25f5\u3658\u3e10\u0c7f\u254b\u367b\u3e46\u0c31\u25aa\u36e3\u3e7f\u0c58\u258b\u3677\u3e11\u0cd2\u2506\u3618\u3ef0\u0c0a\u255b\u3635\u3ece", -1234752760);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)-1653171537 ^ (long)-1653171552);
            if (var7) break block16;
            var0_6 = (int)((long)715097358 ^ (long)-715097359);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)1319154562 ^ (long)-1319154563);
                if (7a.\u2001\u200d) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!7a.\u2001\u200d) continue block8;
                            throw null;
                        }
                        7a.d = var5_1;
                        7a.e = new String[(int)((long)-1739451089 ^ (long)-1739451091)];
                        if (!7a.\u2001\u200d) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)663103916 ^ (long)663103916);
                v5 = (int)((long)-1802912474 ^ (long)-1802912398);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)2028371316 ^ (long)2028371317)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)2144607016 ^ (long)2144607023)) {
                                case 0: {
                                    v12 = (int)((long)-1345977578 ^ (long)-1345977547);
                                    if (!7a.\u2001\u200d) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)1750372755 ^ (long)1750372749);
                                    if (!7a.\u2001\u200d) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-268042257 ^ (long)-268042304);
                                    if (!7a.\u2001\u200d) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)-1912136459 ^ (long)-1912136547);
                                    if (!7a.\u2001\u200d) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)1510524174 ^ (long)1510524236);
                                    if (!7a.\u2001\u200d) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)1422116943 ^ (long)1422116909);
                                    if (!7a.\u2001\u200d) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)-1687573421 ^ (long)-1687573458);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!7a.\u2001\u200d);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!7a.\u2001\u200d) ** continue;
                throw null;
            }
        }
    }
}

