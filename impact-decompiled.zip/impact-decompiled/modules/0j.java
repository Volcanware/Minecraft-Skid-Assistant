/* ==========================================================================
 * MODULE: Auto Cheat
 * CATEGORY (inferred): Misc
 * DESCRIPTION: Automatically detects the AntiCheat being used by the current server
 * OBFUSCATED CLASS: net.impactclient.0j
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  com.google.common.collect.ImmutableMap$Builder
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import com.google.common.collect.ImmutableMap;
import java.lang.invoke.LambdaMetafactory;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.3X;
import net.impactclient.3s0;
import net.impactclient.3sW;
import net.impactclient.3sx;
import net.impactclient.4f;
import net.impactclient.4h;
import net.impactclient.6F;
import net.impactclient.6w;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0j
extends 3X
implements 3s0 {
    private static final ImmutableMap<String, 3sW> 0;
    public 3sW 9;
    @EventHandler
    private final Listener<4f> 6;
    private boolean 8;
    public static final boolean \u200e\u2005\u2005;
    @EventHandler
    private final Listener<3sx> 5;
    private static final String[] d;
    private static final ImmutableMap<Predicate<String>, 3sW> 4;
    private static final String[] e;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        block5: {
            block2: {
                boolean bl;
                block4: {
                    block3: {
                        bl = \u200e\u2005\u2005;
                        if (bl || bl) break block2;
                        if (this.9 == null) break block3;
                        if (bl) break block2;
                        if (this.9 != 3sW.g) break block4;
                        if (bl) break block2;
                    }
                    if (bl) break block2;
                    this.7();
                    if (bl) break block2;
                }
                if (!bl) break block5;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block25: {
            block24: {
                var7 = 0j.\u200e\u2005\u2005;
                if (!var7) break block24;
                break block25;
            }
            var5_1 = new String[(int)((long)-245904658 ^ (long)-245904668)];
            if (var7) break block25;
            var3_2 = (int)((long)2062921043 ^ (long)2062921043);
            if (var7) break block25;
            var2_3 = 2w$6X.KAOZ("\u3705\u1fce\u0c9a\u04b9\u3790\u1f2c\u0c2c\u04fd\u376e\u1f37\u0c39\u04d7\u37d3\u1f48\u0c18\u049e\u3787\u1f2f\u0c87\u044d\u3766\u1f6c\u0c68\u0452\u376e\u1fd2\u0ce2\u04e1\u3763\u1f65\u0c84\u04ac\u3785\u1f32\u0c42\u04ab\u3769\u1fd4\u0cd2\u04c5\u3765\u1fb3\u0c6f\u0447\u37cd\u1f65\u0cd1\u0412\u37c1\u1fa1\u0ce1\u047b\u37fc\u1f0f\u0ca9\u042b\u3720\u1f7a\u0c09\u0430\u37e8\u1fac\u0c41\u042b\u3786\u1f87\u0c23\u04c9\u376f\u1f2a\u0c46\u04a9\u3762\u1f37\u0ceb\u0480\u378a\u1f7e\u0c90", 95817987);
            var4_4 = var2_3.length();
            if (var7) break block25;
            var1_5 = (int)((long)-1734578232 ^ (long)-1734578240);
            if (var7) break block25;
            var0_6 = (int)((long)1464245284 ^ (long)-1464245285);
            if (var7) break block25;
            block11: while (!var7) {
                block22: {
                    block21: {
                        v0 = (int)((long)1203147193 ^ (long)1203147164);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)312422984 ^ (long)-312422985);
                        if (0j.\u200e\u2005\u2005) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!0j.\u200e\u2005\u2005) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\u56eb\u7e16\u6d94\u65c4\u5614\u7e7d\u6d19\u659e\u5619\u7eea\u6d7f\u6549\u5630\u7e2f\u6dac\u6523\u5654\u7e1f\u6dab\u653d\u568f\u7e0d\u6d92\u6594\u565b\u7e87\u6d0d\u6518\u568d\u7e2b\u6dfc\u65fb\u56c0\u7e7d\u6d8a\u65d7\u566a\u7ea7\u6d35\u6566\u56c2\u7e88\u6d3e\u65c1\u5624\u7e96\u6dd5\u653b\u5661\u7e19\u6d04\u6516\u5689\u7ed7\u6d75\u6509\u56e2\u7e6a\u6df1\u65ad\u5692\u7e30\u6df4\u6552\u5652\u7ee9\u6d2c\u65c2\u56c1\u7e48\u6d60\u65a3\u56bb\u7e35\u6d16\u65ef\u567e\u7e3c\u6d93\u65d3\u5647\u7ed2\u6de4\u65c2\u56d7\u7ec0\u6da7", -1540656971);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)-1969821230 ^ (long)-1969821290);
                                var0_6 = (int)((long)52299061 ^ (long)-52299062);
                                while (true) {
                                    v0 = (int)((long)2013225857 ^ (long)2013225920);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)-2133909361 ^ (long)-2133909361);
                                    if (!0j.\u200e\u2005\u2005) break block21;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!0j.\u200e\u2005\u2005) ** continue;
                                    throw null;
                                }
                                0j.d = var5_1;
                                0j.e = new String[(int)((long)-40915569 ^ (long)-40915579)];
                                if (0j.\u200e\u2005\u2005) {
                                    throw null;
                                }
                                break block22;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)-1686686022 ^ (long)-1686686022);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)-553868500 ^ (long)-553868499)) ** GOTO lbl108
                    do {
                        block23: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-1950273028 ^ (long)-1950273029)) {
                                    case 0: {
                                        v15 = (int)((long)-2050407482 ^ (long)-2050407477);
                                        if (!0j.\u200e\u2005\u2005) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)-1492642295 ^ (long)-1492642278);
                                        if (!0j.\u200e\u2005\u2005) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)1017422198 ^ (long)1017422128);
                                        if (!0j.\u200e\u2005\u2005) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)-1954634950 ^ (long)-1954634892);
                                        if (!0j.\u200e\u2005\u2005) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)-195036523 ^ (long)-195036426);
                                        if (!0j.\u200e\u2005\u2005) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)-596146527 ^ (long)-596146539);
                                        if (!0j.\u200e\u2005\u2005) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)-1912032881 ^ (long)-1912032801);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block23;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!0j.\u200e\u2005\u2005);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                0j.4 = new ImmutableMap.Builder().put((Predicate<String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, 8(java.lang.String ), (Ljava/lang/String;)Z)(), (Object)3sW.d).put((Predicate<String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, 0(java.lang.String ), (Ljava/lang/String;)Z)(), (Object)3sW.e).put((Predicate<String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, 6(java.lang.String ), (Ljava/lang/String;)Z)(), (Object)3sW.c).put((Predicate<String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, 7(java.lang.String ), (Ljava/lang/String;)Z)(), (Object)3sW.b).put((Predicate<String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, 3(java.lang.String ), (Ljava/lang/String;)Z)(), (Object)3sW.a).build();
                0j.0 = new ImmutableMap.Builder().put((Object)0j.b((int)((long)1644996580 ^ (long)-1644991493), (int)((long)-1012391640 ^ (long)-1012388551)) /* "nocheatplus" */, (Object)3sW.a).put((Object)0j.b((int)((long)-747307139 ^ (long)747320161), (int)((long)1993288360 ^ (long)-1993292708)) /* "aac" */, (Object)3sW.b).build();
                break;
            }
        }
    }

    private static /* synthetic */ boolean 8(String string) {
        boolean bl = \u200e\u2005\u2005;
        if (bl || bl) {
            return true;
        }
        return string.endsWith(0j.b((int)((long)234934398 ^ (long)-234939292), (int)((long)-884779154 ^ (long)884795103)) /* "mineplex.com" */);
    }

    private static /* synthetic */ boolean 6(String string) {
        boolean bl = \u200e\u2005\u2005;
        if (bl || bl) {
            return true;
        }
        return string.endsWith(0j.b((int)((long)193014018 ^ (long)-193010407), (int)((long)-1684337393 ^ (long)1684308671)) /* "hypixel.net" */);
    }

    private static /* synthetic */ boolean 0(String string) {
        boolean bl = \u200e\u2005\u2005;
        if (bl || bl) {
            return true;
        }
        return string.endsWith(0j.b((int)((long)47574675 ^ (long)-47570290), (int)((long)1938532057 ^ (long)1938543485)) /* "badlion.net" */);
    }

    private static /* synthetic */ boolean 3(String string) {
        boolean bl = \u200e\u2005\u2005;
        if (bl || bl) {
            return true;
        }
        return string.equals(0j.b((int)((long)1810432300 ^ (long)-1810444997), (int)((long)-790324746 ^ (long)790331130)) /* "ncp.odiegaming.com" */);
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0j.\u200e\u2005\u2005;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-264537521 ^ (long)264549969)) & (int)((long)-269724971 ^ (long)-269701846);
            if (var9_2) ** GOTO lbl-1000
            if (0j.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0j.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1787257693 ^ (long)-1787257693)] & (int)((long)617759982 ^ (long)617759761)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)955128294 ^ (long)955128317);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)188116383 ^ (long)188116369);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)-2085653551 ^ (long)-2085653538);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-2099169087 ^ (long)-2099169270);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-576144024 ^ (long)-576144082);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)113523833 ^ (long)113523961);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1131578799 ^ (long)-1131578698);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1617402044 ^ (long)-1617402016);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)2078201600 ^ (long)2078201661);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-972860394 ^ (long)-972860282);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-250681992 ^ (long)-250681963);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)328757588 ^ (long)328757746);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-852232767 ^ (long)-852232836);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)376846550 ^ (long)376846362);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-383468962 ^ (long)-383468911);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)91788987 ^ (long)91788852);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)818352058 ^ (long)818352122);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-449948824 ^ (long)-449948801);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-468324507 ^ (long)-468324514);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1270094714 ^ (long)-1270094781);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1005622871 ^ (long)1005622919);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1944272652 ^ (long)1944272710);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1916697591 ^ (long)1916697544);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1202275714 ^ (long)1202275699);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)960131997 ^ (long)960131851);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1849916379 ^ (long)-1849916275);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1601710945 ^ (long)-1601710909);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1736891923 ^ (long)-1736892011);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1108227778 ^ (long)1108227697);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-678573122 ^ (long)-678573185);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-217378857 ^ (long)-217379026);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)810900914 ^ (long)810900858);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-2084777169 ^ (long)-2084777013);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1980615829 ^ (long)1980615757);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1589403473 ^ (long)1589403638);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1169119009 ^ (long)-1169119189);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1973051505 ^ (long)-1973051422);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1995937091 ^ (long)-1995937118);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)599361391 ^ (long)599361280);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)541844999 ^ (long)541845124);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)793534416 ^ (long)793534441);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1995486111 ^ (long)-1995486191);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)742326107 ^ (long)742326099);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-417029955 ^ (long)-417030002);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-2006576429 ^ (long)-2006576540);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)950100647 ^ (long)950100635);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)2006685743 ^ (long)2006685857);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)736735973 ^ (long)736735787);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1942812065 ^ (long)-1942811949);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-627142649 ^ (long)-627142631);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)2082194209 ^ (long)2082194191);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)547620373 ^ (long)547620424);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-709420914 ^ (long)-709420909);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)419031559 ^ (long)419031570);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)821347975 ^ (long)821347980);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)2101520826 ^ (long)2101520641);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)771394606 ^ (long)771394671);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-562571580 ^ (long)-562571538);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1934345327 ^ (long)1934345469);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-820698635 ^ (long)-820698794);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)517834668 ^ (long)517834748);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1749431427 ^ (long)1749431433);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1816530990 ^ (long)-1816531173);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1259685500 ^ (long)1259685500);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)747664493 ^ (long)747664494);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-791325922 ^ (long)-791325715);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-283701712 ^ (long)-283701657);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)444000767 ^ (long)444000608);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1306882994 ^ (long)1306882867);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)349951369 ^ (long)349951331);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)191164085 ^ (long)191164060);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-530187067 ^ (long)-530187100);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-368223137 ^ (long)-368223186);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-658212124 ^ (long)-658212192);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)589032090 ^ (long)589032009);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)346163581 ^ (long)346163592);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-2099077247 ^ (long)-2099077146);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1747419186 ^ (long)1747419292);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-859775734 ^ (long)-859775554);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1111782437 ^ (long)-1111782559);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)792012094 ^ (long)792012108);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)1059103383 ^ (long)1059103432);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1865493654 ^ (long)-1865493577);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)848344393 ^ (long)848344426);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)381926473 ^ (long)381926590);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-2114108351 ^ (long)-2114108355);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)873717688 ^ (long)873717710);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1090682586 ^ (long)-1090682519);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-813759555 ^ (long)-813759719);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-622618628 ^ (long)-622618706);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-737115284 ^ (long)-737115226);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-727129590 ^ (long)-727129589);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)142753747 ^ (long)142753730);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1158919779 ^ (long)-1158919682);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1742733073 ^ (long)1742733183);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-103284466 ^ (long)-103284380);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)419863618 ^ (long)419863795);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-343021484 ^ (long)-343021440);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1066276782 ^ (long)1066276775);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)371524544 ^ (long)371524541);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)2061970405 ^ (long)2061970356);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1599875507 ^ (long)-1599875382);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)501952003 ^ (long)501952044);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-162052385 ^ (long)-162052517);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1822481963 ^ (long)1822482133);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1346466777 ^ (long)1346466755);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1290405692 ^ (long)1290405834);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)700128989 ^ (long)700128985);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-475293332 ^ (long)-475293318);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1432874726 ^ (long)-1432874607);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1830466592 ^ (long)1830466787);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-131903238 ^ (long)-131903427);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-551808720 ^ (long)-551808718);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)907224003 ^ (long)907224059);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-2120566704 ^ (long)-2120566730);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)617961220 ^ (long)617961297);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)984491598 ^ (long)984491760);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1558503566 ^ (long)-1558503573);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-307659894 ^ (long)-307659944);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1255367309 ^ (long)-1255367288);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1576967586 ^ (long)-1576967572);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-965790405 ^ (long)-965790314);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-1799165464 ^ (long)-1799165595);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1564736444 ^ (long)-1564736397);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)971395977 ^ (long)971395923);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1957575886 ^ (long)1957575763);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-108652865 ^ (long)-108653053);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-187658863 ^ (long)-187659000);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1764460771 ^ (long)-1764460583);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-2090319632 ^ (long)-2090319870);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1773143073 ^ (long)1773143185);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-301827362 ^ (long)-301827460);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)462277944 ^ (long)462278015);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1403510711 ^ (long)-1403510765);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)2097251150 ^ (long)2097251225);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-554293099 ^ (long)-554293050);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)235726681 ^ (long)235726812);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1424175299 ^ (long)-1424175331);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-103937882 ^ (long)-103938033);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)0xC66C4CC ^ (long)208061612);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)304178611 ^ (long)304178517);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1138577037 ^ (long)-1138576997);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)29507901 ^ (long)29508001);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1678676247 ^ (long)1678676274);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-913929604 ^ (long)-913929484);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1468353330 ^ (long)-1468353370);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1810157961 ^ (long)1810157956);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)808508714 ^ (long)808508924);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)218777299 ^ (long)218777272);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-788350810 ^ (long)-788350766);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)733007992 ^ (long)733008083);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-2119271566 ^ (long)-2119271563);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-947548451 ^ (long)-947548465);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-533468885 ^ (long)-533468678);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1543115950 ^ (long)-1543115938);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)976000301 ^ (long)976000451);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-105889020 ^ (long)-105888986);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)1848030231 ^ (long)1848030439);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-922564670 ^ (long)-922564676);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)701172829 ^ (long)701172742);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1345933288 ^ (long)1345933276);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1544126522 ^ (long)-1544126608);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-314348514 ^ (long)-314348538);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)992770235 ^ (long)992770215);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-136689016 ^ (long)-136688897);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1894779989 ^ (long)-1894780019);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1825436188 ^ (long)-1825436203);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-446374910 ^ (long)-446374905);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1503440457 ^ (long)1503440593);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)2119047391 ^ (long)2119047216);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1555499253 ^ (long)1555499050);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-1282680444 ^ (long)-1282680486);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-1810360783 ^ (long)-1810360627);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1590039675 ^ (long)-1590039603);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-408882954 ^ (long)-408883026);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1422374204 ^ (long)-1422374185);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1751141222 ^ (long)1751141273);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-474466081 ^ (long)-474466208);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1536027037 ^ (long)-1536026887);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-487139065 ^ (long)-487139004);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)592418700 ^ (long)592418698);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1842307841 ^ (long)-1842307895);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1162830343 ^ (long)-1162830567);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-372558742 ^ (long)-372558650);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-2007049273 ^ (long)-2007049327);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)0xDDD8D6 ^ (long)14538943);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1096025410 ^ (long)-1096025468);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-499994356 ^ (long)-499994247);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-1721329868 ^ (long)-1721329706);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)2086792272 ^ (long)2086792311);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1308697071 ^ (long)1308697055);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)951656215 ^ (long)951656396);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)35703497 ^ (long)35703472);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-13604785 ^ (long)-13604646);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)475172962 ^ (long)475173105);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-1836043886 ^ (long)-1836043921);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)588578741 ^ (long)588578675);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-1398235959 ^ (long)-1398236037);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-665251745 ^ (long)-665251650);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1453781479 ^ (long)-1453781413);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1406453195 ^ (long)1406453015);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1732877578 ^ (long)1732877670);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1527961015 ^ (long)1527960995);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)599851955 ^ (long)599851991);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-2079776334 ^ (long)-2079776494);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1733820574 ^ (long)1733820618);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1126530431 ^ (long)-1126530310);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1576869453 ^ (long)-1576869526);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1837581827 ^ (long)1837581917);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1797003214 ^ (long)1797003139);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-115117898 ^ (long)-115118040);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)384928929 ^ (long)384928842);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-949048254 ^ (long)-949048070);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)1537598255 ^ (long)1537598215);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)981025708 ^ (long)981025592);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1332983708 ^ (long)1332983692);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1714453056 ^ (long)-1714453174);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1026824416 ^ (long)-1026824261);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)537883095 ^ (long)537883126);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)1741982887 ^ (long)1741982733);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1774806505 ^ (long)1774806422);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)976395987 ^ (long)976395930);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1232119431 ^ (long)1232119468);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)122422788 ^ (long)122422914);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-1734675928 ^ (long)-1734675765);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1842223146 ^ (long)1842223359);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-1868299348 ^ (long)-1868299459);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1829898919 ^ (long)1829898858);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-7464038 ^ (long)-7464157);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-2064971338 ^ (long)-2064971366);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1770643544 ^ (long)-1770643475);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)2019562535 ^ (long)2019562632);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1912456816 ^ (long)1912456953);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-170897511 ^ (long)-170897449);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)2001953016 ^ (long)2001952890);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)1994403306 ^ (long)1994403295);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-933465064 ^ (long)-933464990);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1757629228 ^ (long)1757629325);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)773097059 ^ (long)773096966);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)287920523 ^ (long)287920617);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1678564280 ^ (long)1678564216);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)979116856 ^ (long)979117009);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)820848737 ^ (long)820848658);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1253288984 ^ (long)1253289178);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1960390049 ^ (long)1960389956);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1803536076 ^ (long)1803535993);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)15719142 ^ (long)15718979);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1191734953 ^ (long)-1191735013);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)2067309727 ^ (long)2067309683);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-261687117 ^ (long)-261687048);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1822003518 ^ (long)1822003559);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)715258832 ^ (long)715258695);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1506635033 ^ (long)-1506635235);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)430016664 ^ (long)430016693);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1852911655 ^ (long)1852911839);
                    if (!0j.\u200e\u2005\u2005) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)1339945750 ^ (long)1339945768);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)2060228119 ^ (long)2060228328)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1333068914 ^ (long)-1333132175)) >>> (int)((long)-1051141039 ^ (long)-1051141031)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)116034066 ^ (long)116034066);
            if (!0j.\u200e\u2005\u2005) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)174773573 ^ (long)174773575);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1023433833 ^ (long)1023433834) | var5_6 << (int)((long)813881788 ^ (long)813881785)) ^ var3_4[var7_8]) & (int)((long)-180391114 ^ (long)-180390967);
                    if (0j.\u200e\u2005\u2005) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1710556822 ^ (long)-1710556823) | var6_7 << (int)((long)82642686 ^ (long)82642683)) ^ var3_4[var7_8]) & (int)((long)769274015 ^ (long)769273952);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0j.e[var2_3] = new String(var3_4).intern();
        }
        return 0j.e[var2_3];
    }

    public 0j() {
        boolean bl = \u200e\u2005\u2005;
        super(0j.b((int)((long)-938289391 ^ (long)938285832), (int)((long)1251155094 ^ (long)1251170071)) /* "Auto Cheat" */, 0j.b((int)((long)-298968189 ^ (long)298964885), (int)((long)557573248 ^ (long)-557576333)) /* "Automatically detects the AntiCheat being used by the current server" */);
        this.5 = new Listener(sx -> {
            block3: {
                block2: {
                    boolean bl = \u200e\u2005\u2005;
                    if (bl || bl) break block2;
                    this.8 = (int)((long)625133323 ^ (long)625133322);
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)1834982899 ^ (long)1834982899)]);
        this.6 = new Listener(f -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u200e\u2005\u2005;
                        if (bl || bl) break block2;
                        if (!this.8) break block3;
                        if (bl || bl) break block2;
                        this.7();
                        if (bl) break block2;
                    }
                    if (bl) break block2;
                    2R.1(this, 0j.b((int)((long)-1648261577 ^ (long)1648249391), (int)((long)1755041934 ^ (long)1755046076)) /* "suffix" */, this.9.h);
                    if (!bl && !bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)-1399301626 ^ (long)-1399301626)]);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 7() {
        boolean bl;
        block11: {
            block10: {
                bl = \u200e\u2005\u2005;
                if (bl || bl) return;
                this.8 = (int)((long)1471461852 ^ (long)1471461852);
                if (bl || bl) return;
                this.9 = 3sW.g;
                if (bl || bl) return;
                if (3.E() == null) break block10;
                if (bl) return;
                if (!3.G()) break block11;
                if (bl) return;
            }
            if (bl) return;
            this.9 = 3sW.f;
            if (bl || bl) return;
            return;
        }
        if (bl) return;
        4.forEach((predicate, sW) -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u200e\u2005\u2005;
                        if (bl || bl) break block2;
                        if (!predicate.test(0j.3.E().b.toLowerCase())) break block3;
                        if (bl || bl) break block2;
                        this.9 = sW;
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        });
        if (bl || bl) return;
        if (this.9 == 3sW.g) {
            if (bl || bl) return;
            new 6F().3((6w w) -> {
                boolean bl = \u200e\u2005\u2005;
                if (bl || bl) return;
                if (w.8 != 4h.a) {
                    if (bl || bl) return;
                    return;
                }
                if (bl) return;
                w.6().forEach(string -> {
                    block3: {
                        block2: {
                            boolean bl = \u200e\u2005\u2005;
                            if (bl || bl) break block2;
                            0.forEach((string2, sW) -> {
                                block4: {
                                    block2: {
                                        boolean bl;
                                        block3: {
                                            bl = \u200e\u2005\u2005;
                                            if (bl || bl) break block2;
                                            if (!string2.equalsIgnoreCase((String)string)) break block3;
                                            if (bl || bl) break block2;
                                            this.9 = sW;
                                            if (bl) break block2;
                                        }
                                        if (!bl) break block4;
                                    }
                                    return;
                                }
                            });
                            if (!bl) break block3;
                        }
                        return;
                    }
                });
                if (!bl && !bl) return;
            });
            if (bl) return;
        }
        if (!bl) return;
    }

    private static /* synthetic */ boolean 7(String string) {
        boolean bl = \u200e\u2005\u2005;
        if (bl || bl) {
            return true;
        }
        return string.equals(0j.b((int)((long)450130785 ^ (long)-450117761), (int)((long)1848700961 ^ (long)-1848684086)) /* "2b2t.org" */);
    }
}

