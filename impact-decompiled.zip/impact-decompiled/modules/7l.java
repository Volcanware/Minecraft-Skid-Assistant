/* ==========================================================================
 * MODULE: Wireframe
 * CATEGORY (inferred): Render
 * DESCRIPTION: Turns blocks into Wireframes
 * OBFUSCATED CLASS: net.impactclient.7l
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 */
package net.impactclient;

import net.impactclient.1A;
import net.impactclient.2w$6X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.8h;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7l
extends 3X
implements 8h {
    public static final boolean \u200a;
    private static final String[] d;
    private static final String[] e;
    public 1A 2;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7l.\u200a;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-532319434 ^ (long)-532319437)];
            if (var7) break block23;
            var3_2 = (int)((long)453872868 ^ (long)453872868);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u7a9f\u5319\u40bc\u48ba\u7a2c\u539b\u4078\u4874\u7a8e\u53e3\u407d\u48f7\u7aa0\u5304\u4078\u4873\u7a4a\u53fd\u4002\u48d8\u7a67\u5310\u401c\u4833\u7a67\u53a5\u4087\u48ec\u7af1\u532b\u40ed\u4820\u7ab3\u53cc\u408e\u48b9\u7acc\u53b9\u402a\u48c5\u7a0b\u5354\u40b9\u4829\u7ab1\u5396\u409e\u485d\u7ac5\u53a7\u4083\u4893\u7a17\u5379\u40cb\u481b\u7a1b\u530c\u4010\u48ea\u7a94\u53f1\u4033\u48b0\u7a4c\u5315\u4094\u48a8\u7aec\u53b7\u4033\u4820\u7a15\u5331\u404f\u48b4\u7a48", -251175495);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-414963119 ^ (long)-414963123);
            if (var7) break block23;
            var0_6 = (int)((long)-742089146 ^ (long)742089145);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1143256714 ^ (long)1143256808);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)344356694 ^ (long)-344356695);
                    if (7l.\u200a) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7l.\u200a) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u8e54\ua767\ub419\ubc7d\u8eda\ua7a3\ub497\ubc36\u8e5d\ua723\ub43b\ubc5d\u8e4f\ua7d5\ub4fe\ubc3d", -2027443968);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)1155262643 ^ (long)1155262646);
                            var0_6 = (int)((long)1543217520 ^ (long)-1543217521);
                            while (true) {
                                v0 = (int)((long)935961787 ^ (long)935961747);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1647118340 ^ (long)-1647118340);
                                if (!7l.\u200a) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7l.\u200a) ** continue;
                                throw null;
                            }
                            7l.d = var5_1;
                            7l.e = new String[(int)((long)2131477645 ^ (long)2131477640)];
                            if (!7l.\u200a) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1250398146 ^ (long)-1250398146);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1114307530 ^ (long)1114307531)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)1500732910 ^ (long)1500732905)) {
                                case 0: {
                                    v15 = (int)((long)159814650 ^ (long)159814631);
                                    if (!7l.\u200a) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)200969641 ^ (long)200969721);
                                    if (!7l.\u200a) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)760447326 ^ (long)760447267);
                                    if (!7l.\u200a) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-2068769347 ^ (long)-2068769329);
                                    if (!7l.\u200a) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-117878511 ^ (long)-117878499);
                                    if (!7l.\u200a) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)132532924 ^ (long)132532876);
                                    if (!7l.\u200a) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-153390649 ^ (long)-153390599);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7l.\u200a);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    public 7l() {
        boolean bl = \u200a;
        super(7l.b((int)((long)1529113747 ^ (long)-1529116069), (int)((long)-974861758 ^ (long)-974866793)) /* "Wireframe" */, 7l.b((int)((long)-1381351446 ^ (long)1381357859), (int)((long)713369189 ^ (long)713363792)) /* "Turns blocks into Wireframes" */);
        this.2 = (1A)((34e)((34e)((34e)this.9().5(7l.b((int)((long)1157616406 ^ (long)-1157614117), (int)((long)-1512778124 ^ (long)-1512779782)) /* "Line Width" */)).7(7l.b((int)((long)-557156081 ^ (long)557162437), (int)((long)1287058857 ^ (long)1287030876)) /* "width" */)).1(7l.b((int)((long)1122666392 ^ (long)-1122672301), (int)((long)-117742155 ^ (long)-117757794)) /* "Adjust the line width of the wireframe" */)).3(Float.valueOf(0.1f)).2(Float.valueOf(3.0f)).5();
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7l.\u200a;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1785863025 ^ (long)-1785856584)) & (int)((long)-2032433963 ^ (long)-2032436438);
            if (var9_2) ** GOTO lbl-1000
            if (7l.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7l.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)304673299 ^ (long)304673299)] & (int)((long)1324974827 ^ (long)1324974612)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)82421449 ^ (long)82421414);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-371370191 ^ (long)-371370071);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1263698359 ^ (long)1263698273);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-323850437 ^ (long)-323850478);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-383790864 ^ (long)-383790918);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1532524868 ^ (long)1532524825);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-752360338 ^ (long)-752360339);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)879732758 ^ (long)879732816);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-673374766 ^ (long)-673374937);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)606471721 ^ (long)606471817);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1628780445 ^ (long)-1628780520);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1315892301 ^ (long)1315892369);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1641471607 ^ (long)1641471733);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-789022509 ^ (long)-789022652);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)1570111228 ^ (long)1570111207);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-95588048 ^ (long)-95587990);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1623002614 ^ (long)1623002523);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)118408229 ^ (long)118408386);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)519414615 ^ (long)519414745);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1466915724 ^ (long)1466915608);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1512205791 ^ (long)1512205605);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1229181848 ^ (long)1229181700);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-893775595 ^ (long)-893775497);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-519386287 ^ (long)-519386270);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-923514560 ^ (long)-923514455);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-2018453898 ^ (long)-2018453976);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)611168937 ^ (long)611168905);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-455982826 ^ (long)-455982731);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)2060147638 ^ (long)2060147591);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1614783118 ^ (long)-1614783195);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1076809601 ^ (long)1076809540);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-66610518 ^ (long)-66610546);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-706231644 ^ (long)-706231750);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1675483693 ^ (long)1675483741);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-2128334237 ^ (long)-2128334082);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1909360457 ^ (long)-1909360547);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1158417198 ^ (long)-1158417342);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-261463617 ^ (long)-261463688);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)713154227 ^ (long)713154274);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)579294771 ^ (long)579294933);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)158258215 ^ (long)158258199);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)421726388 ^ (long)421726324);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1781270980 ^ (long)-1781270981);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1259802806 ^ (long)1259802748);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-1197091109 ^ (long)-1197091214);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1113354556 ^ (long)-1113354527);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1877170181 ^ (long)1877170276);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)679464671 ^ (long)679464478);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-669998593 ^ (long)-669998726);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1364597114 ^ (long)1364597153);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)477204760 ^ (long)477204906);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1115945122 ^ (long)-1115945009);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)229582754 ^ (long)229582791);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1831742063 ^ (long)1831741982);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1192506127 ^ (long)1192506293);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1797625727 ^ (long)-1797625729);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1242364566 ^ (long)-1242364554);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)610003529 ^ (long)610003566);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1874923411 ^ (long)1874923307);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)596282274 ^ (long)596282349);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-363682956 ^ (long)-363682837);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)149329331 ^ (long)149329181);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1005520627 ^ (long)-1005520456);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)1955411580 ^ (long)1955411509);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)908183141 ^ (long)908183253);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1332779959 ^ (long)-1332779871);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1571480918 ^ (long)-1571481056);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)878009178 ^ (long)878009323);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-403980057 ^ (long)-403980251);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-804109837 ^ (long)-804109915);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1355978507 ^ (long)-1355978691);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-397412935 ^ (long)-397412990);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1288195536 ^ (long)-1288195345);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1298966033 ^ (long)-1298966269);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-1463029151 ^ (long)-1463029057);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1251610295 ^ (long)1251610213);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-57881506 ^ (long)-57881371);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1605922493 ^ (long)-1605922354);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-451244618 ^ (long)-451244784);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1969964741 ^ (long)1969964601);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1058130461 ^ (long)1058130553);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)379824151 ^ (long)379824141);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1167786199 ^ (long)-1167785991);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)2026700950 ^ (long)2026701012);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)1299451969 ^ (long)1299451930);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1831110997 ^ (long)1831110941);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)191919270 ^ (long)191919276);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)2048074921 ^ (long)2048074942);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-944970960 ^ (long)-944970948);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)500404156 ^ (long)500404070);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1570878401 ^ (long)-1570878447);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1908778208 ^ (long)1908778184);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)171823593 ^ (long)171823563);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)26112436 ^ (long)26112428);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1475258835 ^ (long)1475258704);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1609949689 ^ (long)1609949583);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)158281628 ^ (long)158281496);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)928134884 ^ (long)928134824);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1078946538 ^ (long)-1078946327);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-805601717 ^ (long)-805601718);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1918229874 ^ (long)1918229940);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1832926006 ^ (long)-1832925996);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-714223539 ^ (long)-714223565);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-626911174 ^ (long)-626911209);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)611338186 ^ (long)611338229);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)58226704 ^ (long)58226689);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1288290754 ^ (long)-1288290679);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1856049752 ^ (long)-1856049667);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)630555252 ^ (long)630555341);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1602176974 ^ (long)-1602176865);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)1551603558 ^ (long)1551603681);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)1308730805 ^ (long)1308730681);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1495641975 ^ (long)1495641984);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-1550604786 ^ (long)-1550604582);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)77443984 ^ (long)77443939);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1715762129 ^ (long)1715762160);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-2056034806 ^ (long)-2056034617);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1240442128 ^ (long)1240442230);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-691614936 ^ (long)-691614820);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-823834767 ^ (long)-823834670);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)483466692 ^ (long)483466688);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1179052266 ^ (long)1179052170);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1527523553 ^ (long)1527523560);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)1812859077 ^ (long)1812858902);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)716728072 ^ (long)716728291);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-446192063 ^ (long)-446192049);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)562020770 ^ (long)562020795);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-309157987 ^ (long)-309158110);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-2091567372 ^ (long)-2091567385);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1311372702 ^ (long)1311372715);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-1248741173 ^ (long)-1248741357);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1155065932 ^ (long)1155065890);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)385416133 ^ (long)385416121);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-2018107743 ^ (long)-2018107755);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)60239512 ^ (long)60239501);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-573980520 ^ (long)-573980482);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1353284947 ^ (long)-1353284975);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1590863342 ^ (long)1590863172);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1795915051 ^ (long)-1795915037);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-278296881 ^ (long)-278297042);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1627336664 ^ (long)1627336695);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)129763320 ^ (long)129763170);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1822097369 ^ (long)-1822097326);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-1436456197 ^ (long)-1436456392);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1279521965 ^ (long)-1279521807);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-797887863 ^ (long)-797887897);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1600580105 ^ (long)-1600580169);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1322248831 ^ (long)1322248872);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-2023221556 ^ (long)-2023221593);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-229861215 ^ (long)-229861223);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-950410193 ^ (long)-950410204);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)333424143 ^ (long)333424211);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1069702947 ^ (long)1069703134);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1065646565 ^ (long)-1065646446);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-1141458385 ^ (long)-1141458362);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)2116074896 ^ (long)2116074866);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1250138253 ^ (long)1250138236);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)252604615 ^ (long)252604419);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1760949419 ^ (long)-1760949441);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-395330365 ^ (long)-395330356);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1204868002 ^ (long)1204867868);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1027277352 ^ (long)-1027277559);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)291981356 ^ (long)291981319);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)738866751 ^ (long)738866836);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1924879522 ^ (long)-1924879511);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1359660050 ^ (long)-1359660105);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)320147626 ^ (long)320147681);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)125242846 ^ (long)125242682);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-665957355 ^ (long)-665957369);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1801046836 ^ (long)-1801047033);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-1101778057 ^ (long)-1101777989);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-633785098 ^ (long)-633785141);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)661154307 ^ (long)661154362);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-787560591 ^ (long)-787560482);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-51544590 ^ (long)-51544659);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)336355346 ^ (long)336355518);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-517229586 ^ (long)-517229714);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-242886314 ^ (long)-242886195);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1795582152 ^ (long)1795582158);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1001695279 ^ (long)-1001695453);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1905949821 ^ (long)-1905949767);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-2071155471 ^ (long)-2071155646);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1515468637 ^ (long)1515468557);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-2109134874 ^ (long)-2109134853);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1394899985 ^ (long)1394899988);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1245746445 ^ (long)-1245746685);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)116344370 ^ (long)116344452);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1816765351 ^ (long)-1816765408);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-548399190 ^ (long)-548399174);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-216496196 ^ (long)-216496242);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1613566996 ^ (long)1613567125);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)963775721 ^ (long)963775621);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)202701255 ^ (long)202701116);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-807545445 ^ (long)-807545537);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)386452820 ^ (long)386452988);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)314855609 ^ (long)314855503);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-1665918045 ^ (long)-1665918051);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1558702545 ^ (long)1558702403);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)1301973971 ^ (long)1301973908);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)92915842 ^ (long)92915735);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1783307251 ^ (long)-1783307192);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)64124216 ^ (long)64124373);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1108431940 ^ (long)1108432101);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)207137096 ^ (long)207137071);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)429875585 ^ (long)429875556);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1326512127 ^ (long)-1326511993);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1817070704 ^ (long)-1817070704);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)2137595371 ^ (long)2137595327);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-351696787 ^ (long)-351696645);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-819852617 ^ (long)-819852598);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-338852063 ^ (long)-338851927);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1389465061 ^ (long)1389465021);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)981008371 ^ (long)981008207);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1445882572 ^ (long)-1445882457);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-335117510 ^ (long)-335117552);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1037634922 ^ (long)-1037634862);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-439537041 ^ (long)-439536906);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)188300554 ^ (long)188300612);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-360605977 ^ (long)-360606167);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-2063978147 ^ (long)-2063978104);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1723250855 ^ (long)-1723250762);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-548860942 ^ (long)-548861056);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)494065687 ^ (long)494065763);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)53582215 ^ (long)53582088);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-245229293 ^ (long)-245229110);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1937170814 ^ (long)1937170689);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1019284609 ^ (long)1019284620);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-848949632 ^ (long)-848949597);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)406388934 ^ (long)406388786);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-421765121 ^ (long)-421765369);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-107880925 ^ (long)-107880862);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)1722331058 ^ (long)1722331098);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1699108374 ^ (long)-1699108529);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)125641489 ^ (long)125641570);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1507946123 ^ (long)1507946132);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)722906381 ^ (long)722906485);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)2137203592 ^ (long)2137203594);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)544058149 ^ (long)544058194);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)1836950037 ^ (long)1836950127);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)786902379 ^ (long)786902312);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-200209915 ^ (long)-200209736);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1793259296 ^ (long)1793259456);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)745494764 ^ (long)745494577);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-559054397 ^ (long)-559054534);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-1585565121 ^ (long)-1585565075);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1551334186 ^ (long)-1551334307);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1450831425 ^ (long)-1450831374);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)20480645 ^ (long)20480681);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-485504630 ^ (long)-485504612);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-330473254 ^ (long)-330473347);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)214220413 ^ (long)214220468);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)532427527 ^ (long)532427535);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1514435676 ^ (long)-1514435769);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-741984815 ^ (long)-741984994);
                    if (!7l.\u200a) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1300024132 ^ (long)1300024144);
                    if (!7l.\u200a) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-915711166 ^ (long)-915711215);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-849488303 ^ (long)-849488210)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-586047812 ^ (long)-586063549)) >>> (int)((long)-375739901 ^ (long)-375739893)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)957371660 ^ (long)957371660);
            if (!7l.\u200a) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-1077009704 ^ (long)-1077009702);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1080529523 ^ (long)1080529520) | var5_6 << (int)((long)317500380 ^ (long)317500377)) ^ var3_4[var7_8]) & (int)((long)1983221481 ^ (long)1983221270);
                    if (7l.\u200a) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1036211029 ^ (long)-1036211032) | var6_7 << (int)((long)-726567910 ^ (long)-726567905)) ^ var3_4[var7_8]) & (int)((long)1513954569 ^ (long)1513954806);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7l.e[var2_3] = new String(var3_4).intern();
        }
        return 7l.e[var2_3];
    }
}

