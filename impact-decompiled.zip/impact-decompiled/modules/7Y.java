/* ==========================================================================
 * MODULE: Tracers
 * CATEGORY (inferred): Render
 * DESCRIPTION: Draws a line to entities
 * OBFUSCATED CLASS: net.impactclient.7Y
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  afm
 *  aqa
 *  aqm
 *  bfw
 *  com.mojang.blaze3d.systems.RenderSystem
 *  k
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  org.lwjgl.opengl.GL11
 *  pw.knx.feather.structures.Color
 */
package net.impactclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1A;
import net.impactclient.1K;
import net.impactclient.1P;
import net.impactclient.1R;
import net.impactclient.1m;
import net.impactclient.2_;
import net.impactclient.2r;
import net.impactclient.2w$6X;
import net.impactclient.2z;
import net.impactclient.34E;
import net.impactclient.34J;
import net.impactclient.34L;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.34f;
import net.impactclient.3J;
import net.impactclient.3X;
import net.impactclient.3e;
import net.impactclient.3f;
import net.impactclient.4L;
import net.impactclient.4t;
import net.impactclient.5K;
import net.impactclient.5r;
import net.impactclient.5z;
import net.impactclient.6L;
import net.impactclient.6y;
import net.impactclient.8S;
import net.impactclient.8h;
import net.impactclient.94;
import net.impactclient.9V;
import net.impactclient.9b;
import net.impactclient.9i;
import org.lwjgl.opengl.GL11;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7Y
extends 3X
implements 8h {
    private 1R 4;
    private 1K 0F;
    private 1K 08;
    private 1P 0D;
    private 1P 0A;
    @EventHandler
    private final Listener<2r> 0f;
    private static final String[] d;
    private 4t 8;
    private 1P 0;
    private 1P 0j;
    private 1A 0q;
    private 1P 7;
    private 1P 5;
    private 1P 0o;
    private 1R 0C;
    private 1K 9;
    private 1P 04;
    private static final String[] e;
    public static final boolean \u2003;
    private 1K 1;
    private 1R 0z;
    private 1A 0P;
    private 1R 0Q;
    private 1m<6y> 0S;
    private 1m<6y> 02;
    private 1K 2;
    final 9V 0_;
    private 1P 0v;
    private 1P 0B;
    private 1P 0m;
    private 1P 0X;
    private 1P 0Z;
    private 1R 0l;
    private 1R 6;
    private 1P 0g;
    private 1P 0G;
    private 1P 0h;
    private 1R 0H;
    private 1K 0x;
    private 1P 0p;
    private 1P 0T;

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7Y.\u2003;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)300316863 ^ (long)300316895)];
            if (var7) break block23;
            var3_2 = (int)((long)471491994 ^ (long)471491994);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u295d\u00ea\u1318\u1b38\u29ed\u00ef\u132b\u1ba4\u2981\u0090\u13bb\u1b65\u29e4\u00ed\u1338\u1bb4\u2966t\u13e6\u1bd8\u29d1P\u139f\u1bf7\u2933\u00db\u1371\u1b05\u292e\u0005\u1325\u1ba2\u29f8\u0094\u133e\u1bdb\u29f0\u00bd\u13a2\u1bcb\u294c\u0006\u136e\u1bd6\u293bR\u13fd\u1b5c\u29ef\u00f6\u13c9\u1b33\u2992\u00e6\u13a7\u1b42\u2953o\u13c4\u1bc7\u2976\u00ef\u1313\u1b0c\u293b\u00a1\u1343\u1b01\u29aef\u135d\u1bea\u29a7\u00f0\u1382\u1be1\u291a\u00e3\u136b\u1b24\u2960q\u13fa\u1b75\u2986\u00f7\u13d3\u1b76\u29a3j\u1321\u1b73\u29b9M\u1351\u1bbe\u29f3\u00cd\u1388\u1b8d\u29c2\u00f3\u13dd\u1b51\u29ef1\u1307\u1b4a\u294cq\u13b7\u1b8f\u29b5\u00df\u13aa\u1bbc\u2948\u0019\u131e\u1b1b\u29d8\u0097\u1365\u1b2a\u29b9\u00e7\u137d\u1bb8\u2978\u00a6\u1399\u1b07\u29b1\f\u1327\u1b2a\u2982\u00b5\u1333\u1bff\u2997\u00ae\u13c9\u1bf2\u2954\u0014\u1355\u1bf6\u29b5\u0087\u13ab\u1b14\u293a\u00bb\u132c\u1b19\u2931\u00af\u1324\u1bd0\u299b\u00b4\u134d\u1b7d\u2994v\u133a\u1bc7\u291f\"\u1340\u1b45\u294b\u00fb\u139d\u1bda\u2957s\u13bb\u1b50\u29e7\u00a0\u1343\u1b80\u29ce\u0018\u138e\u1b71\u297a\u00b2\u13bf\u1b58\u29e9\u0087\u130a\u1b78\u292f\u00b4\u13aa\u1b78\u2999\u00ea\u1359\u1b1a\u2949\u007f\u130c\u1b77\u29c2\u00fc\u13fb\u1b63\u293cR\u13fe\u1bae\u2928\u0094\u1305\u1b1b\u295c\u0093\u135e\u1b00\u294b\u00ce\u1383\u1bee\u2989\u00fb\u13d3\u1bd6\u2938<\u13c5\u1b0f\u29d6L\u138f\u1ba6\u2979\u009b\u13fd\u1b81\u2909\u0005\u13c2\u1bd6\u29096\u13c0\u1b35\u297b\u00bd\u131e\u1b8e\u29f3\u00c3\u13ec\u1bdd\u291d\u00be\u1300\u1b66\u299f\r\u13da\u1b0e\u29a2v\u1304\u1bee\u29c3\u00cf\u13db\u1b05\u2938\u00aa\u13f3\u1bf0\u299a6\u1302\u1bf8\u29e2\u00e4\u137e\u1b93\u2980\u00bb\u13a8\u1bba\u29e3\u00c0\u136c\u1b49\u297aH\u1389\u1bb8\u2995\u00a5\u1308\u1b26\u298d\u00ee\u13f8\u1bb8\u291cl\u1309\u1b5a\u296bs\u136c\u1b33\u2979f\u13ae\u1b26\u2973\u00bf\u130a\u1b13\u2947\u009e\u130d\u1b3e\u2976\u00f7\u1335\u1b8d\u2935\u00a5\u13b9\u1bdb\u290a\u00ce\u132d\u1bc6\u293c\u00f6\u1365\u1b4b\u2976\u00ac\u139a\u1b5f\u2973)\u13ec\u1b50\u29efy\u13bf\u1b6b\u29e5\u001a\u138f\u1bff\u2914\u00cf\u135f\u1b5e\u2920\u00d6\u1347\u1b29\u29e5n\u1378\u1b84\u2911W\u1375\u1ba9\u2994\u00d6\u13c8\u1ba1\u2962\u00b6\u135b\u1b43\u29b1\u00ad\u1362\u1b61\u2963w\u1300\u1b57\u29e8\u0019\u1352\u1bb6\u298d\u00b9\u13a0\u1bd0\u2929\u00ec\u138e\u1bea\u299a\u00c4\u13f8\u1b9a\u2907E\u1358\u1b31\u2983`\u13a8\u1be3\u29e6<\u1362\u1b12\u298b-\u1360\u1b42\u2930\u00bf\u1389\u1bbc\u29c5\u00b5\u134d\u1b5d\u29566\u1363\u1bdf\u29d7Z\u1333\u1bbe\u29ac\u0004\u1375\u1b09\u2938:\u13ef\u1b87\u2959\u00c1\u1327\u1b38\u2913\u00b9\u13e3\u1b9e\u2947_\u1319\u1b02\u29b9\u00b6\u1332\u1ba5\u29a0\u00a8\u133c\u1bb0\u2995\u00e7\u1390\u1b38\u2987C\u1319\u1b46\u29046\u13d6\u1bd7\u297eO\u13c4\u1bae\u2988\u008c\u1390\u1b60\u292f\u0082\u13c4\u1b80\u292bc\u13d6\u1b4a\u290c\u001d\u13bb\u1b68\u29ea\u00c5\u139a\u1be0\u29d7<\u136b\u1bfa\u29ad\u001b\u1313\u1bfd\u297f\u0001\u1386\u1bd5\u294e\u00bb\u137c\u1b80\u292f\u0088\u136f\u1bdd\u2908/\u133f\u1be1\u299d\u008b\u135d\u1b34\u2950\u001f\u1381\u1bc0\u29f9C\u1356\u1ba4\u2946\u00f2\u1336\u1bb0\u298c\u00e2\u1393\u1b39\u2971X\u13a6\u1b49\u29cbf\u1375\u1bb8\u29cc\u0000\u13f4\u1bb4\u297dY\u1302\u1b44\u29c0F\u1318\u1b4a\u29c7\u0016\u13a4\u1b56\u2932\u0091\u1350\u1b38\u298c\u00f7\u13a2\u1b5d\u29a4|\u13b2\u1b1e\u295f\u001c\u1377\u1b9b\u298b\u00f5\u13a5\u1bc4\u29a97\u1338\u1b68\u2933h\u1363\u1b1e\u292c%\u13a3\u1bc1\u298c\u0013\u1311\u1b66\u2956\u000e\u13ef\u1bc7\u29b3g\u132a\u1b95\u29eeZ\u1302\u1bdb\u290a\u0007\u13be\u1bae\u290f~\u1378\u1b5f\u2945\u0097\u1357\u1bbc\u29f8\u000f\u13c7\u1b3b\u2908u\u1394\u1b9d\u29eb\u0012\u1319\u1b76\u29f0\u008c\u139b\u1bbe\u2920\u00ca\u1306\u1be8\u2983\u0086\u13d4\u1bd5\u2962@\u130e\u1bb6\u2954p\u1369\u1b01\u2900@\u136e\u1bc2\u29bf\u00dd\u137b\u1bd5\u29d5\u00d0\u131d\u1ba4\u29e4d\u137f\u1b74\u291b\u00de\u139c\u1b38\u2918\u00cf\u1313\u1bb2\u299f\u008e\u13a2\u1b1e\u2971?\u139d\u1bdb\u29da\u00eb\u138c\u1b03\u290d\u00a2\u1368\u1b8a\u299c\u0087\u13f2\u1b44\u2915\\\u13d5\u1b2f\u297b/\u137e\u1b0c\u2970\u00ff\u133c\u1b56\u29cd,\u135a\u1b0a\u2960X\u13b4\u1b0e\u290b\u00f5\u130e\u1b1b\u297d\u00d7\u1335\u1b1f\u29e5\u00c6\u135a\u1ba8\u29d4\u008c\u1382\u1b75\u29b6\u009e\u1351\u1b76\u29e3\u00e2\u13a3\u1bff\u2920\u00e6\u13f4\u1bc6\u2991\u00ab\u132c\u1b98\u29f7`\u1346\u1b14\u2914\n\u13c1\u1ba4\u2928}\u13ec\u1bb1\u2994\u00b1\u1356\u1ba3\u296d\u00ff\u1389\u1b7f\u29a3\u0088\u13f9\u1bdb\u29d8\u00d6\u13ce\u1b52\u290e\u00fb\u1357\u1b8e\u29b3\u00f6\u135f\u1b0d\u2994\u0083\u13e2\u1bf3\u29f8\u008e\u13e1\u1ba0\u299a\u00f8\u135b\u1b47\u294d\u001e\u1379\u1bba\u29405\u1319\u1b2d\u29b66\u1377\u1b43\u2975\u00f7\u13f2\u1b87\u29f5[\u137e\u1bd0\u2977m\u13d4\u1b8d\u291f\u00dd\u1304\u1bd7\u2935\u00ed\u1371\u1ba9\u293ev\u135a\u1bb5\u2969P\u133f\u1b6d\u29976\u1304\u1be7\u2942\u00f5\u1309\u1b48\u2944\u00bb\u133b\u1be5\u29f2?\u130a\u1bc1\u2934&\u134c\u1b4e\u2973\u00fe\u13d3\u1b94\u29fa\u00ad\u136a\u1b6b\u2939.\u13ba\u1bbe\u29753\u13b4\u1b42\u29cd\u00ff\u1329\u1b78\u29d41\u13c8\u1bef\u2990\b\u13a8\u1be5\u293b\u0085\u137e\u1b23\u29691\u132e\u1bbb\u29c8\u0085\u13e8\u1b43\u2932\u0089\u1373\u1b33\u2946l\u1356\u1b8c\u29f20\u1370\u1bf3\u29ce\u00b0\u13ac\u1bab\u29bc\t\u1328\u1b4f\u2985\u00b6\u1312\u1b47\u29a8\u00ec\u13ed\u1b11\u29bcY\u1376\u1bc9\u29e2\u00c9\u1313\u1bd7\u29ae\u001f\u13af\u1be1\u299f\u008f\u1340\u1be0\u293bb\u1394\u1b21\u29e0\u0005\u131b\u1bf3\u299f\u00ef\u13ae\u1b17\u297f\u00ae\u13ed\u1b0b\u29aa\u0013\u1365\u1b16\u29c4\u00c0\u1357\u1b36\u2923#\u136c\u1b17\u29d5\u00f8\u134d\u1be0\u29b4\u00e2\u137d\u1b19\u29e3>\u133d\u1b2b\u29e7!\u1331\u1b0a\u2901\u007f\u13fb\u1bd8\u2918\t\u13a0\u1bdd\u2957}\u137c\u1ba2\u29e8z\u1301\u1b17\u293a\u0083\u131d\u1ba8\u29b6\u00b7\u138c\u1b1b\u294e\f\u136b\u1b98\u297a8\u134f\u1b97\u291aC\u13d5\u1b56\u29d1\u008e\u13cd\u1b5b\u29ac\u00a2\u13b4\u1b2a\u296e\u0086\u138d\u1b29\u29fc-\u1335\u1bee\u2951j\u13bf\u1b85\u294bZ\u13aa\u1b37\u2905\u0086\u13d5\u1b81\u293d\u00f0\u13f3\u1bc1\u2904j\u1322\u1bf7\u2919%\u136c\u1b55\u294c\u008c\u1355\u1b79\u2983_\u1389\u1b47\u297c\u00af\u1395\u1b84\u2905\u0018\u13d1\u1bf1\u2932j\u1335\u1b81\u2937[\u13ae\u1be2\u2948\u0083\u1389\u1b66\u298f\u00c3\u1363\u1b68\u29c6\u0096\u13c0\u1ba5\u2965\u00e2\u1363\u1bde\u29f3\u00ae\u1345\u1bf2\u29c5\u0014\u136c\u1bc9\u29ef\u0007\u130a\u1b1f\u295c\u001d\u1360\u1b26\u2923\u00dc\u13ff\u1b36\u2927\u00c5\u13e8\u1b57\u2956\u00a0\u1315\u1b3f\u29ee1\u1350\u1b70\u2972u\u13ae\u1b2d\u29deF\u1316\u1bd5\u2947\u00af\u1385\u1b14\u295a\u00ba\u13da\u1b71\u294c\u008a\u13bd\u1bdf\u29ee\u008b\u1302\u1b26\u2942\u0090\u134a\u1b9f\u293f1\u13fc\u1b15\u295f\u00fe\u13fc\u1b85\u299f\u0015\u136a\u1b36\u292e\u0085\u1358\u1bcb\u2929\u009d\u133f\u1b97\u29bcE\u1307\u1b2f\u2911n\u136d\u1bf8\u2954\u00d1\u1304\u1baf\u290b\u00d9\u1375\u1b1d\u29db\u00bd\u13b1\u1b50\u29c0\u00fd\u1318\u1bf4\u29b2\u00bc\u1343\u1b63\u29b68\u13fb\u1be2\u2983\u0007\u1310\u1ba2\u2932\u00ac\u1351\u1b5f\u2976\t\u13d7\u1b40\u2901\u0018\u1357\u1b40\u2902\u00dc\u13c6\u1bdf\u29db\u0084\u13fe\u1bc4\u2977W\u139f\u1b46\u2934\\\u13bf\u1bce\u2982\u0087\u13ba\u1b1c\u2901\u00c0\u1335\u1b9e\u29b3\u00c4\u1365\u1b3d\u29deZ\u13bd\u1b52\u294e\u00e4\u13a3\u1b3c\u2998\u001c\u1395\u1b85\u2908\u00e2\u1394\u1b03\u29e5r\u1355\u1b50\u2982\u00ec\u1387\u1b0d\u2968\u001d\u1361\u1bdc\u2982\u0080\u13b8\u1bd0\u29fb&\u1323\u1b66\u292dM\u13a0\u1bec\u29cbT\u1360\u1bd1\u29c3g\u1380\u1b98\u2966\u0015\u135e\u1b38\u294a|\u13db\u1bb3\u290f\u00a3\u1388\u1bb3\u2998o\u131b\u1b80\u2911\u0010\u1344\u1b42\u2971\u00e6\u1344\u1b7c\u2964\u0014\u130a\u1b8b\u29e7\u009f\u13b0\u1ba2\u29f2\u008a\u130e\u1b43\u295c8\u134d\u1baa\u2916#\u1301\u1b16\u2992\u00fb\u13b9\u1b51\u29fe\u00cf\u1362\u1b87\u29ca\u0097\u13c4\u1b89\u29bav\u135b\u1ba5\u2981`\u139b\u1bf2\u293f>\u1394\u1b74\u2934\u00ff\u1385\u1b62\u29f1\u00d4\u13f7\u1bd2\u2930J\u1324\u1b1e\u2989\u00a3\u13c9\u1b54\u292a\"\u13e7\u1b3d\u2933\u00e0\u1351\u1bb0\u29db(\u135c\u1b3d\u299b\u00b6\u13ed\u1bb5\u29c7I\u1391\u1b37\u2948\u00bf\u1395\u1b47\u2933J\u1307\u1b38\u2912\u00a9\u1384\u1b1f\u29d6\u0004\u132c\u1bd9\u2918k\u13c2\u1bcd\u2901v\u1387\u1bc2\u29ba]\u131b\u1b59\u29f0!\u13d6\u1b4a\u2957\u00a6\u13d4\u1b7c\u29fc\f\u1388\u1bae\u290a\u0097\u1339\u1bdd\u2949\u00aa\u13de\u1b69\u292e\u00ac\u1372\u1b8c\u29c5\u009a\u13d9\u1b7b\u2978\u00dc\u1371\u1b17\u29e4\u0011\u13a2\u1b15\u2965(\u1310\u1b51\u29cdP\u13cc\u1b0f\u295b\u008b\u139a\u1b6f\u2929F\u13ea\u1bb3\u29849\u13d8\u1bef\u292d\u00ea\u1376\u1bab\u295d\u00b2\u1395\u1bf1\u299b\u001e\u138a\u1b2d\u295f\r\u1353\u1b26\u298e\u0014\u1394\u1b49\u2999\u00a5\u139b\u1b21\u295c'\u13a6\u1bca\u293bo\u1370\u1b58\u29c0\u00a7\u13ee\u1b1c\u2976\u00f4\u13f9\u1b7b\u29e7-\u13c9\u1b56\u29f1\u0002\u1315\u1bd5\u29ae]\u1334\u1b4a\u2960\u0096\u1320\u1bd8\u2996\u00ee\u1370\u1bc4\u2919\u00b3\u1340\u1be0\u29eb$\u1303\u1b92\u29be\u0000\u13c4\u1b47\u29da\u00e5\u13d1\u1b85\u2974\u00f6\u13bf\u1bc5\u2956\u0015\u132f\u1bc1\u299d\u00c9\u1391\u1bfd\u29a9\u00f5\u1307\u1b10\u2947\u0013\u1376\u1b01\u29b4\u00df\u13ff\u1be5\u2989\u00b1\u132b\u1b17\u2981\u00e1\u13bb\u1be6\u2904\u00bc\u13e7\u1bd2\u293e\u001f\u1330\u1b56\u29ba\u00e7\u138b\u1ba4\u299a\u00e0\u132b\u1ba6\u293e\u00ef\u13ed\u1bbe\u29a0\u0012\u1361\u1b2d\u2951\u0004\u131f\u1b53\u29f3\u0086\u138a\u1b75\u29d1\u00ab\u1399\u1bc4\u29acY\u13bc\u1b84\u296e9\u130d\u1beb\u2928\u0088\u13bf\u1bf5\u29d9\u0087\u1322\u1b63\u29e29\u135f\u1bba\u29e6\u00a5\u132d\u1b47\u298a\t\u1364\u1b23\u29a4n\u130a\u1bcc\u29798\u1301\u1bf2\u29e0\u0090\u1369\u1baf\u2904\u0089\u133f\u1b5f\u2967\u00b4\u134e\u1b07\u2923\u00e4\u1391\u1b02\u2995g\u131c\u1bc6\u2962\u00d3\u132d\u1b52\u29f2\u00f9\u13b6\u1bb3\u291c\u0085\u13bd\u1b87\u2986z\u136c\u1b49\u297a\u00af\u132a\u1b7f\u2993\"\u13fc\u1bba\u296e\u0006\u13f6\u1be7\u29b3\u00b6\u13a9\u1ba2\u292a\r\u1358\u1b45\u2954\u00d4\u13e9\u1bf4\u29b4\u00d3\u133d\u1bac\u2931|\u1304\u1b19\u2956q\u1313\u1bc1\u2936\t\u13e1\u1b3e\u29a1\u00a7\u131e\u1bfb\u29da\u0004\u13c9\u1b4e\u291e\u00d7\u13f2\u1bd0\u29fe\u00b7\u1301\u1b84\u291b\u0003\u1318\u1bc2\u29d5\u009a\u137b\u1b16\u297eI\u1329\u1be4\u2975~\u13a2\u1b7a\u29f9\u00e1\u13dc\u1bd5\u29dbJ\u13bc\u1b2f\u2952\u00ae\u134d\u1b86\u2956\u0000\u13ec\u1bc9\u2983|\u13ce\u1b00\u29c6\u001f\u1363\u1ba5\u299d\u00d1\u137c\u1bf1\u29a2\u000f\u1378\u1b58\u297f\u00ec\u13af\u1b64\u29b8\u0084\u13bd\u1bdb\u2940\u00cc\u139d\u1b51\u290f\u00c0\u1322\u1b64\u2914\u00ec\u13f7\u1bcc\u2979Y\u137b\u1bfa\u291d\u00df\u1308\u1b04\u2907\u00c6\u134b\u1baf\u2922l\u13ef\u1beb\u29e9\u009e\u1308\u1bfc\u2993\u00da\u13f3\u1bcf\u298dZ\u138b\u1bb2\u29f6V\u1320\u1b0f\u2984\u00a8\u1335\u1b5c\u29e4\u00a5\u1375\u1b53\u2945\u0089\u1388\u1b1d\u2936\u0083\u1340\u1b20\u291f\u00fd\u13fb\u1b5d\u29f4|\u1387\u1b2a\u29f2\u00af\u1369\u1bd3\u2958d\u13c1\u1b06\u29ca\u00e1\u13ed\u1ba3\u293dK\u1372\u1ba6\u2928\u009e\u13f6\u1bf4\u294e\u00d4\u132b\u1be2\u298f\u009d\u1359\u1bf8\u2902\u0019\u13b3\u1b07\u2954^\u13e0\u1b98\u292f\u007f\u138f\u1b39\u29a9\u00fd\u1396\u1bbe\u2991h\u1365\u1b0a\u29d3A\u137c\u1ba5\u2982\u00af\u1354\u1b42\u2943\u00eb\u13ac\u1b90\u29eb\u009b\u1368\u1b54\u2932\u00c0\u13b5\u1b3f\u2926\u00ad\u1321\u1bcb\u2936p\u1382\u1b25\u29b9\u00f0\u1300\u1bb2\u29f1h\u1319\u1b35\u2933\u00b7\u13f8\u1b95\u2965M\u13c5\u1bb7\u29c2\u00af\u13c4\u1b45\u2919\n\u135a\u1b33\u29b0\u00a6\u138c\u1b4c\u291f\u00f5\u13f2\u1b75\u29dck\u139f\u1b93\u299d\u001e\u13fd\u1b48\u291b=\u136f\u1b1c\u2955\u00f4\u13df\u1bab\u29d5\u00bd\u13ed\u1ba4\u2996k\u1312\u1b3f\u2908\u009b\u13fe\u1b3d\u2930T\u13e5\u1b83\u292d\u00d2\u1365\u1b92\u294fI\u1313\u1b45\u29ced\u1329\u1bdd\u29cb\u001a\u1304\u1b62\u2981\u0007\u13ff\u1b7b\u2941\u001b\u1364\u1bb3\u296fT\u1315\u1bb6\u29cbB\u13ac\u1ba3\u295c\u00c1\u13de\u1b26\u2952\u008e\u1372\u1bd2\u2924\u000b\u13bf\u1b46\u299a\u0082\u13e8\u1b28\u29f7\u00c4\u1356\u1bd3\u29e3|\u138f\u1bab\u29d3\u00cb\u1310\u1b2a\u2931}\u139b\u1b93\u29ff\u00a6\u13a8\u1b59\u2928\u00a2\u1324\u1bf1\u29a1\u0000\u1313\u1b38\u2972\u0016\u13d0\u1ba1\u2960\u00cb\u1365\u1b67\u29d6\u00b5\u1346\u1b06\u2949b\u1350\u1b3e\u29f1\u0007\u13a4\u1b78\u291as\u1352\u1ba5\u29c8q\u131d\u1bd0\u29cdv\u13f7\u1b45\u295a\u009c\u1347\u1b28\u2950r\u137f\u1b7b\u29c1\u00a7\u136f\u1be7\u29c6m\u13df\u1b65\u2902\u00b3\u13b5\u1bbc\u2953~\u13b6\u1b85\u2929\u0081\u13d8\u1b33\u2970\u0096\u1301\u1b2b\u29bau\u139f\u1b42\u29b94\u13c8\u1bc8\u29ff\u00ea\u1329\u1b64\u2902\u0005\u139e\u1b18\u2977\u00e6\u134e\u1b97\u292c\u00fb\u1344\u1bc2\u29f1\u00f0\u13c1\u1b98\u29e5Y\u13c6\u1b0b\u29b1\u00f3\u1301\u1bb4\u2958t\u1312\u1b01\u2957Z\u13e8\u1bef\u295d\u00d3\u136a\u1b78\u2971\u0011\u1336\u1bbe\u2948U\u133f\u1b37\u292eY\u1305\u1b09\u2959\u00ef\u13a5\u1b68\u293f4\u13f1\u1b02\u2919\u00f8\u13e0\u1b8e\u2984\u0085\u1344\u1b7d\u292c\u00b1\u1362\u1b6e\u29ae\u00b9\u13cc\u1bde\u29d7\u00c8\u1339\u1b78\u29d2\u00fb\u13ae\u1b14\u29d3\u0001\u13a9\u1b5a\u29fa}\u13d2\u1bd1\u295a\u009f\u1370\u1b6f\u2928\u00bf\u13e4\u1b75\u297d\u008a\u1301\u1bf6\u293e`\u13b2\u1bf9\u297e$\u1359\u1b33\u29eb\u00cf\u13a4", -36434223);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-265591098 ^ (long)-265591081);
            if (var7) break block23;
            var0_6 = (int)((long)1520014148 ^ (long)-1520014149);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1036376946 ^ (long)1036376903);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-127689040 ^ (long)127689039);
                    if (7Y.\u2003) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7Y.\u2003) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u6570\u4cfe\u5f5e\u5729\u65f0\u4ca9\u5f6a\u5703\u65d5\u4c4a\u5f84\u57ad\u65bf\u4c2d\u5f3a\u571e\u6546\u4cee\u5fcb\u57dd\u65b8\u4cb7\u5f2a\u57fb\u6537\u4cf9\u5fe9\u5772\u6596\u4c07\u5f0b\u57bc\u65e8\u4c74", -1028701480);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)2003567387 ^ (long)2003567388);
                            var0_6 = (int)((long)-943891273 ^ (long)943891272);
                            while (true) {
                                v0 = (int)((long)-1011103612 ^ (long)-1011103526);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1269796145 ^ (long)-1269796145);
                                if (!7Y.\u2003) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7Y.\u2003) ** continue;
                                throw null;
                            }
                            7Y.d = var5_1;
                            7Y.e = new String[(int)((long)-1703895193 ^ (long)-1703895289)];
                            if (!7Y.\u2003) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)2015906714 ^ (long)2015906714);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1119622706 ^ (long)1119622707)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-632674653 ^ (long)-632674652)) {
                                case 0: {
                                    v15 = (int)((long)-1425503505 ^ (long)-1425503520);
                                    if (!7Y.\u2003) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1457458034 ^ (long)-1457457953);
                                    if (!7Y.\u2003) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)0x33CBC3 ^ (long)3394455);
                                    if (!7Y.\u2003) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)2066456618 ^ (long)2066456589);
                                    if (!7Y.\u2003) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)2100754819 ^ (long)2100754902);
                                    if (!7Y.\u2003) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1325017762 ^ (long)-1325017764);
                                    if (!7Y.\u2003) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1297379080 ^ (long)-1297379120);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7Y.\u2003);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    final void 5(8S s) {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2003;
                    if (bl || bl) break block2;
                    if (!(s.2 >= 1.0001)) break block3;
                    if (bl || bl) break block2;
                    double d2 = (double)3.aD().k() - s.9;
                    8S s2 = s;
                    s.9 = d2;
                    if (bl || bl) break block2;
                    s2.1 = (double)3.aD().l() - s.1;
                    if (bl || bl) break block2;
                    if (!this.0B.2) break block3;
                    if (bl || bl) break block2;
                    s2 = s.1(this.0_.1());
                    double d3 = afm.d((double)s2.1, (double)s2.9);
                    if (bl || bl) break block2;
                    8S s3 = s;
                    d2 = s3.9 + (double)(afm.b((float)((float)d3)) * (float)3.aD().k());
                    s2 = s3;
                    s3.9 = d2;
                    if (bl || bl) break block2;
                    s2.1 = s.1 + (double)(afm.a((float)((float)d3)) * (float)3.aD().l());
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7Y.\u2003;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-493240678 ^ (long)-493232332)) & (int)((long)-2043928904 ^ (long)-2043879097);
            if (var9_2) ** GOTO lbl-1000
            if (7Y.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7Y.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-494539640 ^ (long)-494539640)] & (int)((long)-273604558 ^ (long)-273604403)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-476447934 ^ (long)-476447770);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1078640186 ^ (long)-1078640261);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1202163824 ^ (long)1202163790);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)404219169 ^ (long)404219358);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1831179693 ^ (long)-1831179605);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-804323868 ^ (long)-804323962);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)121258571 ^ (long)121258717);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1031658068 ^ (long)1031658198);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)694754670 ^ (long)694754775);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1639262968 ^ (long)1639262755);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1919804093 ^ (long)-1919803984);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1655253196 ^ (long)1655253155);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)323565213 ^ (long)323565138);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-923139193 ^ (long)-923139085);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1902172361 ^ (long)-1902172219);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-191963033 ^ (long)-191963026);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-945015505 ^ (long)-945015370);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)362951726 ^ (long)362951724);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)914181111 ^ (long)914180970);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1465308945 ^ (long)-1465309183);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1056466067 ^ (long)1056466054);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)1786602318 ^ (long)1786602450);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-1651859714 ^ (long)-1651859923);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1619385892 ^ (long)1619385999);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1409528752 ^ (long)-1409528624);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1480939467 ^ (long)-1480939355);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-292033886 ^ (long)-292033910);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)4934545 ^ (long)4934421);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)428326543 ^ (long)428326564);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1011849077 ^ (long)-1011849103);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1563616163 ^ (long)-1563616143);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1107228228 ^ (long)1107228283);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-1171968882 ^ (long)-1171968989);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)60658677 ^ (long)60658614);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)140969906 ^ (long)140969975);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-901216106 ^ (long)-901216123);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1968856043 ^ (long)-1968855941);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-519366145 ^ (long)-519366203);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1636630240 ^ (long)1636630090);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1096766458 ^ (long)-1096766463);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)434461307 ^ (long)434461206);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1081513592 ^ (long)1081513553);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-433023419 ^ (long)-433023404);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1999209356 ^ (long)-1999209462);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1157474420 ^ (long)1157474365);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-529370143 ^ (long)-529370333);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)117213312 ^ (long)117213388);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1493025614 ^ (long)1493025611);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)894102974 ^ (long)894102942);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1867690650 ^ (long)-1867690591);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-2082632722 ^ (long)-2082632774);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-622969598 ^ (long)-622969584);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)629049766 ^ (long)629049774);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-578431086 ^ (long)-578431011);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1857159777 ^ (long)1857159776);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-938259746 ^ (long)-938259941);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-1591568602 ^ (long)-1591568401);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)628086533 ^ (long)628086687);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-1132543625 ^ (long)-1132543675);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-2116438608 ^ (long)-2116438680);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)224512177 ^ (long)224512016);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1747381711 ^ (long)1747381545);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)282292933 ^ (long)282292826);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1280022095 ^ (long)-1280022212);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1863216056 ^ (long)1863215951);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1235377488 ^ (long)1235377513);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-837800808 ^ (long)-837800772);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-205007735 ^ (long)-205007807);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-379757694 ^ (long)-379757671);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-642246715 ^ (long)-642246875);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)2056226027 ^ (long)2056225930);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-2046801041 ^ (long)-2046801035);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1613885326 ^ (long)1613885268);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)925396058 ^ (long)925396143);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)930896273 ^ (long)930896295);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1684701709 ^ (long)-1684701716);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1480421832 ^ (long)-1480421808);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1984735288 ^ (long)-1984735357);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)511037598 ^ (long)511037535);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-536704541 ^ (long)-536704567);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1937290795 ^ (long)-1937290776);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1646475333 ^ (long)-1646475301);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-1464545476 ^ (long)-1464545468);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1030974767 ^ (long)-1030974820);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)957280080 ^ (long)957280214);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)724430993 ^ (long)724431055);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)1345950744 ^ (long)1345950812);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-25173125 ^ (long)-25173120);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1817959024 ^ (long)1817959126);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)216140942 ^ (long)216141009);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1020392422 ^ (long)1020392236);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)522435074 ^ (long)522435138);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)890449477 ^ (long)890449643);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1223982235 ^ (long)1223982195);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1263140726 ^ (long)-1263140810);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-881640994 ^ (long)-881641109);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-970660709 ^ (long)-970660746);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1105349888 ^ (long)-1105349659);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1008928491 ^ (long)1008928412);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1493078938 ^ (long)-1493078862);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-875557919 ^ (long)-875557932);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-782468039 ^ (long)-782468042);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)917503801 ^ (long)917503874);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1429721579 ^ (long)-1429721353);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1240225119 ^ (long)-1240225214);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1229319863 ^ (long)1229319781);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)2066013373 ^ (long)2066013374);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1879823733 ^ (long)-1879823715);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-2065394625 ^ (long)-2065394494);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)1712433318 ^ (long)1712433198);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-2102618470 ^ (long)-2102618561);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1532084139 ^ (long)-1532084178);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)589169827 ^ (long)589169692);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)-342768326 ^ (long)-342768350);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-1205438651 ^ (long)-1205438695);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)910429956 ^ (long)910430061);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-643879163 ^ (long)-643879051);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-1479663935 ^ (long)-1479664015);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1323230057 ^ (long)1323230121);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1695491457 ^ (long)-1695491423);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)1940819681 ^ (long)1940819462);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1322494699 ^ (long)-1322494670);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1985186610 ^ (long)1985186696);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-295783605 ^ (long)-295783505);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1123764399 ^ (long)-1123764356);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1398763752 ^ (long)1398763666);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-1402026904 ^ (long)-1402026906);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-374741822 ^ (long)-374741809);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-923893934 ^ (long)-923893860);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1661859253 ^ (long)1661859219);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1500558656 ^ (long)1500558593);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1638957115 ^ (long)1638957155);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1050942690 ^ (long)-1050942640);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)928338055 ^ (long)928338014);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)2066288283 ^ (long)2066288239);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)354268763 ^ (long)354268806);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-733427100 ^ (long)-733427116);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1467169967 ^ (long)1467169798);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)767594567 ^ (long)767594539);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-310359824 ^ (long)-310360013);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)1926891814 ^ (long)1926891934);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)2133639904 ^ (long)2133639751);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1088903400 ^ (long)-1088903277);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-382035375 ^ (long)-382035217);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1285758519 ^ (long)-1285758696);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1564625835 ^ (long)-1564625675);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)372156944 ^ (long)372157046);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)908856322 ^ (long)908856541);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)537900182 ^ (long)537900045);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1120463092 ^ (long)1120462935);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)783601972 ^ (long)783602145);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)401908245 ^ (long)401908332);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1602436385 ^ (long)1602436520);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1277164590 ^ (long)-1277164701);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1649061928 ^ (long)1649062083);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-934225680 ^ (long)-934225750);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-1323710561 ^ (long)-1323710553);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1742515521 ^ (long)-1742515546);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1153164750 ^ (long)-1153164581);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)1602513700 ^ (long)1602513832);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-582402405 ^ (long)-582402379);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)425029423 ^ (long)425029546);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1600711203 ^ (long)-1600711281);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-112394514 ^ (long)-112394625);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1242664710 ^ (long)1242664882);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)318671240 ^ (long)318671115);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)914374451 ^ (long)914374455);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1798072408 ^ (long)-1798072372);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1393394721 ^ (long)-1393394941);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-315736411 ^ (long)-315736441);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)2102794661 ^ (long)2102794550);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1476401784 ^ (long)1476401695);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1714706671 ^ (long)1714706623);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-235534800 ^ (long)-235534683);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)939024448 ^ (long)939024554);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-81626460 ^ (long)-81626375);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1764372507 ^ (long)1764372538);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1567005614 ^ (long)1567005660);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1487821262 ^ (long)-1487821311);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-909399212 ^ (long)-909399066);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1215937620 ^ (long)1215937700);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)756831582 ^ (long)756831696);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)455743468 ^ (long)455743299);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1363092609 ^ (long)1363092696);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-1483670496 ^ (long)-1483670300);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1615584151 ^ (long)1615584160);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)609301446 ^ (long)609301261);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)392219666 ^ (long)392219732);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)310613423 ^ (long)310613492);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)619442142 ^ (long)619442001);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)534653429 ^ (long)534653377);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)2144328277 ^ (long)2144328322);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-263925618 ^ (long)-263925744);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-847556381 ^ (long)-847556381);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)1569631833 ^ (long)1569631911);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)1659786825 ^ (long)1659786947);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)674291517 ^ (long)674291659);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1493075977 ^ (long)1493076024);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-612968473 ^ (long)-612968526);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)554263557 ^ (long)554263796);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-652726967 ^ (long)-652727009);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-810098492 ^ (long)-810098651);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-237328064 ^ (long)-237327916);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1809879728 ^ (long)1809879586);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)69767546 ^ (long)69767465);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1249014977 ^ (long)1249014923);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)662363648 ^ (long)662363887);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1480448495 ^ (long)-1480448507);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1231393682 ^ (long)1231393679);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)657244451 ^ (long)657244416);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-634983686 ^ (long)-634983892);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)707108110 ^ (long)707108114);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-72401597 ^ (long)-72401614);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-835271032 ^ (long)-835270951);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)2031128245 ^ (long)2031128272);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)306860421 ^ (long)306860342);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-34258474 ^ (long)-34258530);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1931550477 ^ (long)-1931550587);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-33392147 ^ (long)-33392153);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)2129811911 ^ (long)2129811825);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1052794839 ^ (long)-1052794813);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)132744909 ^ (long)132744897);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1379687073 ^ (long)1379687132);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1184282958 ^ (long)-1184282896);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)830717575 ^ (long)830717505);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-951694057 ^ (long)-951693920);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)302480173 ^ (long)302480145);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)917606437 ^ (long)917606562);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)-684226357 ^ (long)-684226554);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1139643931 ^ (long)1139643996);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-387321429 ^ (long)-387321468);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1128795998 ^ (long)-1128796066);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)345230292 ^ (long)345230084);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)1102172066 ^ (long)1102172125);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-160096345 ^ (long)-160096474);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)382229950 ^ (long)382229801);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1954071185 ^ (long)1954071268);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1359088983 ^ (long)-1359088934);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-28962851 ^ (long)-28962882);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)198879672 ^ (long)198879667);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1620267460 ^ (long)-1620267477);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)99894626 ^ (long)99894683);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)622311969 ^ (long)622312121);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-518298393 ^ (long)-518298469);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-70599516 ^ (long)-70599672);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)297874799 ^ (long)297874801);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-865772523 ^ (long)-865772295);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)210009581 ^ (long)210009478);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1672171427 ^ (long)-1672171418);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)340392907 ^ (long)340392803);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)2055465810 ^ (long)2055465794);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)443627658 ^ (long)443627590);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-1325317386 ^ (long)-1325317548);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-1263338745 ^ (long)-1263338751);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)1085949498 ^ (long)1085949471);
                    if (!7Y.\u2003) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1158400928 ^ (long)-1158400969);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1007562174 ^ (long)-1007562051)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)786325385 ^ (long)786342006)) >>> (int)((long)-625512405 ^ (long)-625512413)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-1495079813 ^ (long)-1495079813);
            if (!7Y.\u2003) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-884412910 ^ (long)-884412912);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-40681264 ^ (long)-40681261) | var5_6 << (int)((long)859028607 ^ (long)859028602)) ^ var3_4[var7_8]) & (int)((long)-179213542 ^ (long)-179213339);
                    if (7Y.\u2003) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)1641543724 ^ (long)1641543727) | var6_7 << (int)((long)582730177 ^ (long)582730180)) ^ var3_4[var7_8]) & (int)((long)1646197503 ^ (long)1646197248);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7Y.e[var2_3] = new String(var3_4).intern();
        }
        return 7Y.e[var2_3];
    }

    public 7Y() {
        boolean bl = \u2003;
        String[] stringArray = 3e.5();
        super(7Y.b((int)((long)1808375078 ^ (long)1808399534), (int)((long)1974466566 ^ (long)-1974438977)) /* "Tracers" */, 7Y.b((int)((long)1818721221 ^ (long)1818696290), (int)((long)402530645 ^ (long)402541751)) /* "Draws a line to entities" */);
        String[] stringArray2 = stringArray;
        Object object = Boolean.FALSE;
        34J j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)-1218293805 ^ (long)-1218302343), (int)((long)1558041437 ^ (long)1558038338)) /* "Invisible" */)).7(7Y.b((int)((long)491979133 ^ (long)492003576), (int)((long)1338976622 ^ (long)-1338977026)) /* "invis" */)).1(7Y.b((int)((long)-1408993999 ^ (long)-1409018741), (int)((long)-128798633 ^ (long)-128802449)) /* "Target invisible entities" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)-1218293805 ^ (long)-1218302343), (int)((long)1558041437 ^ (long)1558038338)) /* "Invisible" */)).7(7Y.b((int)((long)491979133 ^ (long)492003576), (int)((long)1338976622 ^ (long)-1338977026)) /* "invis" */)).1(7Y.b((int)((long)-1408993999 ^ (long)-1409018741), (int)((long)-128798633 ^ (long)-128802449)) /* "Target invisible entities" */)).7 = object;
        this.0j = (1P)j2.5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)-1697714451 ^ (long)-1697738932), (int)((long)846749842 ^ (long)846757448)) /* "Sleeping" */)).7(7Y.b((int)((long)-1117989966 ^ (long)-1117998592), (int)((long)557630043 ^ (long)-557638574)) /* "sleeping" */)).1(7Y.b((int)((long)431716817 ^ (long)431691813), (int)((long)972516314 ^ (long)972502933)) /* "Target entities that are sleeping" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)-1697714451 ^ (long)-1697738932), (int)((long)846749842 ^ (long)846757448)) /* "Sleeping" */)).7(7Y.b((int)((long)-1117989966 ^ (long)-1117998592), (int)((long)557630043 ^ (long)-557638574)) /* "sleeping" */)).1(7Y.b((int)((long)431716817 ^ (long)431691813), (int)((long)972516314 ^ (long)972502933)) /* "Target entities that are sleeping" */)).7 = object;
        this.0p = (1P)j2.5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)1012069537 ^ (long)1012045109), (int)((long)-886191637 ^ (long)886184825)) /* "Player" */)).7(7Y.b((int)((long)-2012634864 ^ (long)-2012626777), (int)((long)599181881 ^ (long)-599180487)) /* "player" */)).1(7Y.b((int)((long)-891704418 ^ (long)-891696636), (int)((long)-373102318 ^ (long)373102187)) /* "Target player entities" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)1012069537 ^ (long)1012045109), (int)((long)-886191637 ^ (long)886184825)) /* "Player" */)).7(7Y.b((int)((long)-2012634864 ^ (long)-2012626777), (int)((long)599181881 ^ (long)-599180487)) /* "player" */)).1(7Y.b((int)((long)-891704418 ^ (long)-891696636), (int)((long)-373102318 ^ (long)373102187)) /* "Target player entities" */)).7 = object;
        this.0X = (1P)j2.5();
        object = 6y.a;
        j2 = (34f)((34f)((34f)this.2(6y.class).5(7Y.b((int)((long)104933682 ^ (long)104941744), (int)((long)-1516978563 ^ (long)-1516963219)) /* "Friends" */)).7(7Y.b((int)((long)1196486643 ^ (long)1196461571), (int)((long)-438551143 ^ (long)438540541)) /* "friends" */)).1(7Y.b((int)((long)-1454702256 ^ (long)-1454677776), (int)((long)1613546840 ^ (long)1613549738)) /* "How friends should be treated" */);
        ((34f)((34f)((34f)this.2(6y.class).5(7Y.b((int)((long)104933682 ^ (long)104941744), (int)((long)-1516978563 ^ (long)-1516963219)) /* "Friends" */)).7(7Y.b((int)((long)1196486643 ^ (long)1196461571), (int)((long)-438551143 ^ (long)438540541)) /* "friends" */)).1(7Y.b((int)((long)-1454702256 ^ (long)-1454677776), (int)((long)1613546840 ^ (long)1613549738)) /* "How friends should be treated" */)).7 = object;
        this.02 = (1m)((34f)((34f)j2).3(this.0X)).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)584226312 ^ (long)584251303), (int)((long)-336680825 ^ (long)336672056)) /* "Custom Color" */)).7(7Y.b((int)((long)1246380245 ^ (long)1246372186), (int)((long)-1143402431 ^ (long)-1143374176)) /* "friendcoloroverride" */)).1(7Y.b((int)((long)-872612794 ^ (long)-872636944), (int)((long)-852344528 ^ (long)-852353626)) /* "Draw a different color to friends vs. non-friend players" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)584226312 ^ (long)584251303), (int)((long)-336680825 ^ (long)336672056)) /* "Custom Color" */)).7(7Y.b((int)((long)1246380245 ^ (long)1246372186), (int)((long)-1143402431 ^ (long)-1143374176)) /* "friendcoloroverride" */)).1(7Y.b((int)((long)-872612794 ^ (long)-872636944), (int)((long)-852344528 ^ (long)-852353626)) /* "Draw a different color to friends vs. non-friend players" */)).7 = object;
        this.0A = (1P)((34X)j2.3(this.02)).5();
        object = pw.knx.feather.structures.Color.fromHex((int)34L.7(k.l));
        j2 = (34E)((34E)((34E)this.0().5(7Y.b((int)((long)74004689 ^ (long)74013001), (int)((long)-1191399218 ^ (long)-1191390609)) /* "Color" */)).7(7Y.b((int)((long)-903598849 ^ (long)-903590572), (int)((long)-1207219176 ^ (long)1207222125)) /* "friendcolor" */)).1(7Y.b((int)((long)-820203736 ^ (long)-820195693), (int)((long)-587153152 ^ (long)587144819)) /* "Color for friends" */);
        ((34E)((34E)((34E)this.0().5(7Y.b((int)((long)74004689 ^ (long)74013001), (int)((long)-1191399218 ^ (long)-1191390609)) /* "Color" */)).7(7Y.b((int)((long)-903598849 ^ (long)-903590572), (int)((long)-1207219176 ^ (long)1207222125)) /* "friendcolor" */)).1(7Y.b((int)((long)-820203736 ^ (long)-820195693), (int)((long)-587153152 ^ (long)587144819)) /* "Color for friends" */)).7 = object;
        this.0z = (1R)((34E)((34E)j2).3(this.0A)).5();
        object = 6y.a;
        j2 = (34f)((34f)((34f)this.2(6y.class).5(7Y.b((int)((long)937621201 ^ (long)937596792), (int)((long)-1002918806 ^ (long)1002909222)) /* "Teammates" */)).7(7Y.b((int)((long)-1031366010 ^ (long)-1031341281), (int)((long)-1582726068 ^ (long)-1582694647)) /* "team" */)).1(7Y.b((int)((long)593906715 ^ (long)593898920), (int)((long)1654183787 ^ (long)1654173541)) /* "How teammates should be treated" */);
        ((34f)((34f)((34f)this.2(6y.class).5(7Y.b((int)((long)937621201 ^ (long)937596792), (int)((long)-1002918806 ^ (long)1002909222)) /* "Teammates" */)).7(7Y.b((int)((long)-1031366010 ^ (long)-1031341281), (int)((long)-1582726068 ^ (long)-1582694647)) /* "team" */)).1(7Y.b((int)((long)593906715 ^ (long)593898920), (int)((long)1654183787 ^ (long)1654173541)) /* "How teammates should be treated" */)).7 = object;
        this.0S = (1m)((34f)((34f)j2).3(this.0X)).5();
        this.0Q = (1R)((34E)((34E)((34E)((34E)this.0().5(7Y.b((int)((long)-755443369 ^ (long)-755451739), (int)((long)-1675250604 ^ (long)-1675231651)))).7(7Y.b((int)((long)1431524746 ^ (long)1431516169), (int)((long)238470048 ^ (long)238484510)) /* "playerColor" */)).1(7Y.b((int)((long)527717437 ^ (long)527709652), (int)((long)-1477683833 ^ (long)1477688581)) /* "The color of the tracer line" */)).3(this.0X)).5();
        object = 32.0;
        j2 = ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)-1788614253 ^ (long)-1788639105), (int)((long)836314088 ^ (long)-836320617)))).7(7Y.b((int)((long)2080638642 ^ (long)2080663383), (int)((long)427141356 ^ (long)427151612)) /* "playerMaxDist" */)).1(7Y.b((int)((long)-490276634 ^ (long)-490301110), (int)((long)-914659530 ^ (long)-914663997)) /* "Maximum distance to a player for color change, or to draw at all." */)).3(0.0).2(100.0);
        ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)-1788614253 ^ (long)-1788639105), (int)((long)836314088 ^ (long)-836320617)))).7(7Y.b((int)((long)2080638642 ^ (long)2080663383), (int)((long)427141356 ^ (long)427151612)) /* "playerMaxDist" */)).1(7Y.b((int)((long)-490276634 ^ (long)-490301110), (int)((long)-914659530 ^ (long)-914663997)) /* "Maximum distance to a player for color change, or to draw at all." */)).3(0.0).2(100.0).7 = object;
        this.0x = (1K)((34e)((34e)j2).3(this.0X)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)668850147 ^ (long)668841492), (int)((long)-669293786 ^ (long)669316634)))).7(7Y.b((int)((long)-892297507 ^ (long)-892272815), (int)((long)1292744149 ^ (long)1292735646)) /* "playerDisableAfterMax" */)).1(7Y.b((int)((long)-1911197530 ^ (long)-1911221944), (int)((long)55208041 ^ (long)-55184402)) /* "When a player is farther away than the max distance, don't draw any tracer at all" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)668850147 ^ (long)668841492), (int)((long)-669293786 ^ (long)669316634)))).7(7Y.b((int)((long)-892297507 ^ (long)-892272815), (int)((long)1292744149 ^ (long)1292735646)) /* "playerDisableAfterMax" */)).1(7Y.b((int)((long)-1911197530 ^ (long)-1911221944), (int)((long)55208041 ^ (long)-55184402)) /* "When a player is farther away than the max distance, don't draw any tracer at all" */)).7 = object;
        this.0h = (1P)((34X)((34X)j2).3(this.0X)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)-51525069 ^ (long)-51532859), (int)((long)-1197277333 ^ (long)1197286466)))).7(7Y.b((int)((long)150192593 ^ (long)150183982), (int)((long)1893033620 ^ (long)-1893013200)) /* "playerDistanceColor" */)).1(7Y.b((int)((long)-517417268 ^ (long)-517425292), (int)((long)1530710055 ^ (long)1530711620)));
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)-51525069 ^ (long)-51532859), (int)((long)-1197277333 ^ (long)1197286466)))).7(7Y.b((int)((long)150192593 ^ (long)150183982), (int)((long)1893033620 ^ (long)-1893013200)) /* "playerDistanceColor" */)).1(7Y.b((int)((long)-517417268 ^ (long)-517425292), (int)((long)1530710055 ^ (long)1530711620)))).7 = object;
        this.0D = (1P)((34X)((34X)j2).3(this.0X)).5();
        object = pw.knx.feather.structures.Color.fromHex((int)Color.GREEN.getRGB());
        j2 = (34E)((34E)((34E)((34E)this.0().5(7Y.b((int)((long)831912250 ^ (long)831887549), (int)((long)-861252888 ^ (long)861257698)) /* "Far Color" */)).7(7Y.b((int)((long)-2084534845 ^ (long)-2084510626), (int)((long)-605233464 ^ (long)-605234593)))).1(7Y.b((int)((long)-937800311 ^ (long)-937808796), (int)((long)-2141028173 ^ (long)-2141010718)) /* "What the color should transition to as the player is further away" */)).3(this.0D);
        ((34E)((34E)((34E)((34E)this.0().5(7Y.b((int)((long)831912250 ^ (long)831887549), (int)((long)-861252888 ^ (long)861257698)) /* "Far Color" */)).7(7Y.b((int)((long)-2084534845 ^ (long)-2084510626), (int)((long)-605233464 ^ (long)-605234593)))).1(7Y.b((int)((long)-937800311 ^ (long)-937808796), (int)((long)-2141028173 ^ (long)-2141010718)) /* "What the color should transition to as the player is further away" */)).3(this.0D)).7 = object;
        this.0l = (1R)((34E)j2).5();
        object = 8.0;
        j2 = ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)1504912574 ^ (long)1504920846), (int)((long)-1761639164 ^ (long)1761614111)))).7(7Y.b((int)((long)-774880445 ^ (long)-774888754), (int)((long)991912735 ^ (long)-991919208)) /* "playerMinDist" */)).1(7Y.b((int)((long)352547388 ^ (long)352523183), (int)((long)-102299056 ^ (long)102271991)) /* "Minimum distance to a player for color change" */)).3(0.0).2(16.0);
        ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)1504912574 ^ (long)1504920846), (int)((long)-1761639164 ^ (long)1761614111)))).7(7Y.b((int)((long)-774880445 ^ (long)-774888754), (int)((long)991912735 ^ (long)-991919208)) /* "playerMinDist" */)).1(7Y.b((int)((long)352547388 ^ (long)352523183), (int)((long)-102299056 ^ (long)102271991)) /* "Minimum distance to a player for color change" */)).3(0.0).2(16.0).7 = object;
        this.2 = (1K)((34e)((34e)j2).3(this.0D)).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)67791099 ^ (long)67766655), (int)((long)-1744970576 ^ (long)-1744987456)) /* "Hostile" */)).7(7Y.b((int)((long)-1169165369 ^ (long)-1169190301), (int)((long)-1848456586 ^ (long)1848454852)) /* "hostile" */)).1(7Y.b((int)((long)1150430609 ^ (long)1150438444), (int)((long)2096243558 ^ (long)2096255017)) /* "Target hostile entities" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)67791099 ^ (long)67766655), (int)((long)-1744970576 ^ (long)-1744987456)) /* "Hostile" */)).7(7Y.b((int)((long)-1169165369 ^ (long)-1169190301), (int)((long)-1848456586 ^ (long)1848454852)) /* "hostile" */)).1(7Y.b((int)((long)1150430609 ^ (long)1150438444), (int)((long)2096243558 ^ (long)2096255017)) /* "Target hostile entities" */)).7 = object;
        this.0v = (1P)((34X)j2).5();
        this.0H = (1R)((34E)((34E)((34E)((34E)this.0().5(7Y.b((int)((long)365317539 ^ (long)365309009), (int)((long)-2114182425 ^ (long)-2114164498)))).7(7Y.b((int)((long)-523220904 ^ (long)-523228743), (int)((long)705665270 ^ (long)-705671982)) /* "hostileColor" */)).1(7Y.b((int)((long)-551781683 ^ (long)-551806159), (int)((long)1488252703 ^ (long)-1488228322)))).3(this.0v)).5();
        object = 32.0;
        j2 = ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)2097416452 ^ (long)2097440934), (int)((long)-235581141 ^ (long)235594457)) /* "Max Distance" */)).7(7Y.b((int)((long)607597413 ^ (long)607605446), (int)((long)1743461811 ^ (long)-1743478193)) /* "hostileMaxDist" */)).1(7Y.b((int)((long)-493530030 ^ (long)-493537879), (int)((long)1787046011 ^ (long)1787066984)) /* "Maximum distance to a hostile entity for color change, or to draw at all." */)).3(0.0).2(100.0);
        ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)2097416452 ^ (long)2097440934), (int)((long)-235581141 ^ (long)235594457)) /* "Max Distance" */)).7(7Y.b((int)((long)607597413 ^ (long)607605446), (int)((long)1743461811 ^ (long)-1743478193)) /* "hostileMaxDist" */)).1(7Y.b((int)((long)-493530030 ^ (long)-493537879), (int)((long)1787046011 ^ (long)1787066984)) /* "Maximum distance to a hostile entity for color change, or to draw at all." */)).3(0.0).2(100.0).7 = object;
        this.1 = (1K)((34e)((34e)j2).3(this.0v)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)1656296458 ^ (long)1656321518), (int)((long)1859769562 ^ (long)-1859777858)) /* "Disable After Max" */)).7(7Y.b((int)((long)-154136511 ^ (long)-154111581), (int)((long)-1943033617 ^ (long)1943026803)) /* "hostileDisableAfterMax" */)).1(7Y.b((int)((long)1102610474 ^ (long)1102635450), (int)((long)2088294301 ^ (long)-2088283758)) /* "When a hostile entity is farther away than the max distance, don't draw any tracer at all" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)1656296458 ^ (long)1656321518), (int)((long)1859769562 ^ (long)-1859777858)) /* "Disable After Max" */)).7(7Y.b((int)((long)-154136511 ^ (long)-154111581), (int)((long)-1943033617 ^ (long)1943026803)) /* "hostileDisableAfterMax" */)).1(7Y.b((int)((long)1102610474 ^ (long)1102635450), (int)((long)2088294301 ^ (long)-2088283758)) /* "When a hostile entity is farther away than the max distance, don't draw any tracer at all" */)).7 = object;
        this.0m = (1P)((34X)((34X)j2).3(this.0v)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)1353116677 ^ (long)1353092496), (int)((long)-48934448 ^ (long)-48936077)) /* "Distance Color" */)).7(7Y.b((int)((long)279945325 ^ (long)279953803), (int)((long)426614889 ^ (long)-426634303)) /* "hostileDistanceColor" */)).1(7Y.b((int)((long)2120164406 ^ (long)2120172982), (int)((long)52090133 ^ (long)52091513)) /* "Change the color of the tracer based on distance (between min and max)" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)1353116677 ^ (long)1353092496), (int)((long)-48934448 ^ (long)-48936077)) /* "Distance Color" */)).7(7Y.b((int)((long)279945325 ^ (long)279953803), (int)((long)426614889 ^ (long)-426634303)) /* "hostileDistanceColor" */)).1(7Y.b((int)((long)2120164406 ^ (long)2120172982), (int)((long)52090133 ^ (long)52091513)) /* "Change the color of the tracer based on distance (between min and max)" */)).7 = object;
        this.0g = (1P)((34X)((34X)j2).3(this.0v)).5();
        object = pw.knx.feather.structures.Color.fromHex((int)Color.GREEN.getRGB());
        j2 = (34E)((34E)((34E)((34E)this.0().5(7Y.b((int)((long)-199062966 ^ (long)-199038035), (int)((long)319047635 ^ (long)319033780)))).7(7Y.b((int)((long)1897269395 ^ (long)1897294105), (int)((long)980058112 ^ (long)980060010)) /* "playerFarColor" */)).1(7Y.b((int)((long)1292376269 ^ (long)1292400982), (int)((long)-60541476 ^ (long)-60524485)) /* "What the color should transition to as the hostile entity is further away" */)).3(this.0g);
        ((34E)((34E)((34E)((34E)this.0().5(7Y.b((int)((long)-199062966 ^ (long)-199038035), (int)((long)319047635 ^ (long)319033780)))).7(7Y.b((int)((long)1897269395 ^ (long)1897294105), (int)((long)980058112 ^ (long)980060010)) /* "playerFarColor" */)).1(7Y.b((int)((long)1292376269 ^ (long)1292400982), (int)((long)-60541476 ^ (long)-60524485)) /* "What the color should transition to as the hostile entity is further away" */)).3(this.0g)).7 = object;
        this.4 = (1R)((34E)j2).5();
        object = 8.0;
        j2 = ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)1726760501 ^ (long)1726752676), (int)((long)344809309 ^ (long)344812781)) /* "Min Distance" */)).7(7Y.b((int)((long)1043662438 ^ (long)1043687326), (int)((long)1206513060 ^ (long)1206499093)))).1(7Y.b((int)((long)-1669848229 ^ (long)-1669840219), (int)((long)-1466909459 ^ (long)1466896051)) /* "Minimum distance to a hostile entity for color change" */)).3(0.0).2(16.0);
        ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)1726760501 ^ (long)1726752676), (int)((long)344809309 ^ (long)344812781)) /* "Min Distance" */)).7(7Y.b((int)((long)1043662438 ^ (long)1043687326), (int)((long)1206513060 ^ (long)1206499093)))).1(7Y.b((int)((long)-1669848229 ^ (long)-1669840219), (int)((long)-1466909459 ^ (long)1466896051)) /* "Minimum distance to a hostile entity for color change" */)).3(0.0).2(16.0).7 = object;
        this.9 = (1K)((34e)((34e)j2).3(this.0g)).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)-343204807 ^ (long)-343179865), (int)((long)-275875660 ^ (long)275893732)) /* "Passive" */)).7(7Y.b((int)((long)-374815086 ^ (long)-374823055), (int)((long)1614243517 ^ (long)1614227833)) /* "passive" */)).1(7Y.b((int)((long)-2115030067 ^ (long)-2115022235), (int)((long)-8065025 ^ (long)8064623)) /* "Target passive entities" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)-343204807 ^ (long)-343179865), (int)((long)-275875660 ^ (long)275893732)) /* "Passive" */)).7(7Y.b((int)((long)-374815086 ^ (long)-374823055), (int)((long)1614243517 ^ (long)1614227833)) /* "passive" */)).1(7Y.b((int)((long)-2115030067 ^ (long)-2115022235), (int)((long)-8065025 ^ (long)8064623)) /* "Target passive entities" */)).7 = object;
        this.04 = (1P)((34X)j2).5();
        this.6 = (1R)((34E)((34E)((34E)((34E)this.0().5(7Y.b((int)((long)-1406934694 ^ (long)-1406959448), (int)((long)-1595711703 ^ (long)-1595730656)))).7(7Y.b((int)((long)-1217913942 ^ (long)-1217889785), (int)((long)-474672180 ^ (long)474657905)) /* "passiveColor" */)).1(7Y.b((int)((long)-756686143 ^ (long)-756710595), (int)((long)1954687662 ^ (long)-1954695761)))).3(this.04)).5();
        object = 32.0;
        j2 = ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)-1236463295 ^ (long)-1236438813), (int)((long)-1373167057 ^ (long)1373147613)) /* "Max Distance" */)).7(7Y.b((int)((long)-1092926003 ^ (long)-1092934549), (int)((long)-105838397 ^ (long)-105836662)) /* "passiveMaxDist" */)).1(7Y.b((int)((long)-2145818223 ^ (long)-2145843169), (int)((long)1131764146 ^ (long)-1131756727)) /* "Maximum distance to a passive entity for color change, or to draw at all." */)).3(0.0).2(100.0);
        ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)-1236463295 ^ (long)-1236438813), (int)((long)-1373167057 ^ (long)1373147613)) /* "Max Distance" */)).7(7Y.b((int)((long)-1092926003 ^ (long)-1092934549), (int)((long)-105838397 ^ (long)-105836662)) /* "passiveMaxDist" */)).1(7Y.b((int)((long)-2145818223 ^ (long)-2145843169), (int)((long)1131764146 ^ (long)-1131756727)) /* "Maximum distance to a passive entity for color change, or to draw at all." */)).3(0.0).2(100.0).7 = object;
        this.0F = (1K)((34e)((34e)j2).3(this.04)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)-1732236694 ^ (long)-1732228210), (int)((long)-1385797527 ^ (long)1385805325)) /* "Disable After Max" */)).7(7Y.b((int)((long)-1454389336 ^ (long)-1454397867), (int)((long)567437682 ^ (long)567439537)) /* "passiveDisableAfterMax" */)).1(7Y.b((int)((long)-25440089 ^ (long)-25448115), (int)((long)903381072 ^ (long)-903400721)) /* "When a passive entity is farther away than the max distance, don't draw any tracer at all" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)-1732236694 ^ (long)-1732228210), (int)((long)-1385797527 ^ (long)1385805325)) /* "Disable After Max" */)).7(7Y.b((int)((long)-1454389336 ^ (long)-1454397867), (int)((long)567437682 ^ (long)567439537)) /* "passiveDisableAfterMax" */)).1(7Y.b((int)((long)-25440089 ^ (long)-25448115), (int)((long)903381072 ^ (long)-903400721)) /* "When a passive entity is farther away than the max distance, don't draw any tracer at all" */)).7 = object;
        this.0G = (1P)((34X)((34X)j2).3(this.04)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)-73460370 ^ (long)-73435909), (int)((long)1151996935 ^ (long)1151995556)) /* "Distance Color" */)).7(7Y.b((int)((long)963671023 ^ (long)963646042), (int)((long)853319217 ^ (long)-853333140)) /* "passiveDistanceColor" */)).1(7Y.b((int)((long)161240182 ^ (long)161232374), (int)((long)1873343160 ^ (long)1873346004)) /* "Change the color of the tracer based on distance (between min and max)" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)-73460370 ^ (long)-73435909), (int)((long)1151996935 ^ (long)1151995556)) /* "Distance Color" */)).7(7Y.b((int)((long)963671023 ^ (long)963646042), (int)((long)853319217 ^ (long)-853333140)) /* "passiveDistanceColor" */)).1(7Y.b((int)((long)161240182 ^ (long)161232374), (int)((long)1873343160 ^ (long)1873346004)) /* "Change the color of the tracer based on distance (between min and max)" */)).7 = object;
        this.0 = (1P)((34X)((34X)j2).3(this.04)).5();
        object = pw.knx.feather.structures.Color.fromHex((int)Color.GREEN.getRGB());
        j2 = (34E)((34E)((34E)((34E)this.0().5(7Y.b((int)((long)-2043406282 ^ (long)-2043381295), (int)((long)-1430739113 ^ (long)-1430720208)))).7(7Y.b((int)((long)224303194 ^ (long)224328144), (int)((long)-2086282844 ^ (long)-2086281522)) /* "playerFarColor" */)).1(7Y.b((int)((long)1182916168 ^ (long)1182908355), (int)((long)-1196345685 ^ (long)1196359229)) /* "What the color should transition to as the passive entity is further away" */)).3(this.0);
        ((34E)((34E)((34E)((34E)this.0().5(7Y.b((int)((long)-2043406282 ^ (long)-2043381295), (int)((long)-1430739113 ^ (long)-1430720208)))).7(7Y.b((int)((long)224303194 ^ (long)224328144), (int)((long)-2086282844 ^ (long)-2086281522)) /* "playerFarColor" */)).1(7Y.b((int)((long)1182916168 ^ (long)1182908355), (int)((long)-1196345685 ^ (long)1196359229)) /* "What the color should transition to as the passive entity is further away" */)).3(this.0)).7 = object;
        this.0C = (1R)((34E)j2).5();
        object = 8.0;
        j2 = ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)1589318211 ^ (long)1589343186), (int)((long)-1613395682 ^ (long)-1613382994)) /* "Min Distance" */)).7(7Y.b((int)((long)-1844579621 ^ (long)-1844604125), (int)((long)1530279914 ^ (long)1530293595)))).1(7Y.b((int)((long)2127843577 ^ (long)2127835503), (int)((long)-848366589 ^ (long)-848370981)) /* "Minimum distance to a passive entity for color change" */)).3(0.0).2(16.0);
        ((34e)((34e)((34e)this.7().5(7Y.b((int)((long)1589318211 ^ (long)1589343186), (int)((long)-1613395682 ^ (long)-1613382994)) /* "Min Distance" */)).7(7Y.b((int)((long)-1844579621 ^ (long)-1844604125), (int)((long)1530279914 ^ (long)1530293595)))).1(7Y.b((int)((long)2127843577 ^ (long)2127835503), (int)((long)-848366589 ^ (long)-848370981)) /* "Minimum distance to a passive entity for color change" */)).3(0.0).2(16.0).7 = object;
        this.08 = (1K)((34e)((34e)j2).3(this.0)).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)888742451 ^ (long)888751050), (int)((long)-886342288 ^ (long)886356566)) /* "Anti Bot" */)).7(7Y.b((int)((long)652676987 ^ (long)652701331), (int)((long)566143122 ^ (long)566136382)) /* "antibot" */)).1(7Y.b((int)((long)1805139074 ^ (long)1805147505), (int)((long)861341104 ^ (long)-861359780)) /* "Ignores bot entities" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)888742451 ^ (long)888751050), (int)((long)-886342288 ^ (long)886356566)) /* "Anti Bot" */)).7(7Y.b((int)((long)652676987 ^ (long)652701331), (int)((long)566143122 ^ (long)566136382)) /* "antibot" */)).1(7Y.b((int)((long)1805139074 ^ (long)1805147505), (int)((long)861341104 ^ (long)-861359780)) /* "Ignores bot entities" */)).7 = object;
        this.0Z = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)-1816503309 ^ (long)-1816511903), (int)((long)-583294346 ^ (long)-583284241)) /* "Rainbow Damage" */)).7(7Y.b((int)((long)-515377175 ^ (long)-515402153), (int)((long)-790636329 ^ (long)-790627866)) /* "rbd" */)).1(7Y.b((int)((long)-1346813439 ^ (long)-1346821219), (int)((long)-367174011 ^ (long)367167064)) /* "Highlights entities taking damage with a rainbow color" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)-1816503309 ^ (long)-1816511903), (int)((long)-583294346 ^ (long)-583284241)) /* "Rainbow Damage" */)).7(7Y.b((int)((long)-515377175 ^ (long)-515402153), (int)((long)-790636329 ^ (long)-790627866)) /* "rbd" */)).1(7Y.b((int)((long)-1346813439 ^ (long)-1346821219), (int)((long)-367174011 ^ (long)367167064)) /* "Highlights entities taking damage with a rainbow color" */)).7 = object;
        this.0o = (1P)((34X)j2).5();
        object = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)-618132605 ^ (long)-618108371), (int)((long)722525415 ^ (long)722519741)) /* "Ignore Stationary" */)).7(7Y.b((int)((long)-2025378612 ^ (long)-2025370324), (int)((long)-1869309474 ^ (long)1869310196)) /* "ignoreStationary" */)).1(7Y.b((int)((long)1208411551 ^ (long)1208386618), (int)((long)1954343063 ^ (long)-1954346107)) /* "Don't draw a tracer to stationary entities" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)-618132605 ^ (long)-618108371), (int)((long)722525415 ^ (long)722519741)) /* "Ignore Stationary" */)).7(7Y.b((int)((long)-2025378612 ^ (long)-2025370324), (int)((long)-1869309474 ^ (long)1869310196)) /* "ignoreStationary" */)).1(7Y.b((int)((long)1208411551 ^ (long)1208386618), (int)((long)1954343063 ^ (long)-1954346107)) /* "Don't draw a tracer to stationary entities" */)).7 = object;
        this.7 = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)-735211705 ^ (long)-735187248), (int)((long)-1810444585 ^ (long)1810451240)) /* "Smooth" */)).7(7Y.b((int)((long)1739368636 ^ (long)1739376949), (int)((long)2124652022 ^ (long)2124674009)) /* "smooth" */)).1(7Y.b((int)((long)1039557548 ^ (long)1039532573), (int)((long)-1928786589 ^ (long)-1928782363)) /* "Makes the tracer line smooth" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)-735211705 ^ (long)-735187248), (int)((long)-1810444585 ^ (long)1810451240)) /* "Smooth" */)).7(7Y.b((int)((long)1739368636 ^ (long)1739376949), (int)((long)2124652022 ^ (long)2124674009)) /* "smooth" */)).1(7Y.b((int)((long)1039557548 ^ (long)1039532573), (int)((long)-1928786589 ^ (long)-1928782363)) /* "Makes the tracer line smooth" */)).7 = object;
        this.5 = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)1071387474 ^ (long)1071411924), (int)((long)-1900376156 ^ (long)-1900377920)) /* "Complete" */)).7(7Y.b((int)((long)1553479757 ^ (long)1553488338), (int)((long)176626856 ^ (long)-176636241)) /* "complete" */)).1(7Y.b((int)((long)263547269 ^ (long)263522362), (int)((long)238391865 ^ (long)238396571)) /* "Completes the line if the entity is behind you" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)1071387474 ^ (long)1071411924), (int)((long)-1900376156 ^ (long)-1900377920)) /* "Complete" */)).7(7Y.b((int)((long)1553479757 ^ (long)1553488338), (int)((long)176626856 ^ (long)-176636241)) /* "complete" */)).1(7Y.b((int)((long)263547269 ^ (long)263522362), (int)((long)238391865 ^ (long)238396571)) /* "Completes the line if the entity is behind you" */)).7 = object;
        this.0B = (1P)((34X)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(7Y.b((int)((long)1677968356 ^ (long)1677959697), (int)((long)-569368939 ^ (long)-569353294)) /* "Body" */)).7(7Y.b((int)((long)1742799976 ^ (long)1742824835), (int)((long)418533447 ^ (long)-418530172)) /* "body" */)).1(7Y.b((int)((long)17102060 ^ (long)17077533), (int)((long)1911132775 ^ (long)-1911148299)) /* "Draws tracer up whole body" */);
        ((34X)((34X)((34X)this.4().5(7Y.b((int)((long)1677968356 ^ (long)1677959697), (int)((long)-569368939 ^ (long)-569353294)) /* "Body" */)).7(7Y.b((int)((long)1742799976 ^ (long)1742824835), (int)((long)418533447 ^ (long)-418530172)) /* "body" */)).1(7Y.b((int)((long)17102060 ^ (long)17077533), (int)((long)1911132775 ^ (long)-1911148299)) /* "Draws tracer up whole body" */)).7 = object;
        this.0T = (1P)((34X)j2).5();
        object = Float.valueOf(1.0f);
        j2 = ((34e)((34e)((34e)this.9().5(7Y.b((int)((long)746843916 ^ (long)746819213), (int)((long)417844553 ^ (long)417832056)) /* "Opacity" */)).7(7Y.b((int)((long)-872628235 ^ (long)-872620479), (int)((long)471239721 ^ (long)471240260)) /* "opacity" */)).1(7Y.b((int)((long)-1361491294 ^ (long)-1361499365), (int)((long)1447944631 ^ (long)1447947831)) /* "How opaque the tracer line should be" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(1.0f));
        ((34e)((34e)((34e)this.9().5(7Y.b((int)((long)746843916 ^ (long)746819213), (int)((long)417844553 ^ (long)417832056)) /* "Opacity" */)).7(7Y.b((int)((long)-872628235 ^ (long)-872620479), (int)((long)471239721 ^ (long)471240260)) /* "opacity" */)).1(7Y.b((int)((long)-1361491294 ^ (long)-1361499365), (int)((long)1447944631 ^ (long)1447947831)) /* "How opaque the tracer line should be" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(1.0f)).7 = object;
        this.0P = (1A)((34e)j2).5();
        object = Float.valueOf(1.0f);
        j2 = ((34e)((34e)((34e)this.9().5(7Y.b((int)((long)988494584 ^ (long)988502786), (int)((long)1035797945 ^ (long)-1035814278)) /* "Width" */)).7(7Y.b((int)((long)-1993484447 ^ (long)-1993492850), (int)((long)-1279869966 ^ (long)-1279877632)) /* "width" */)).1(7Y.b((int)((long)-93823042 ^ (long)-93831678), (int)((long)2104852688 ^ (long)-2104863233)) /* "Tracer line width" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(5.0f));
        ((34e)((34e)((34e)this.9().5(7Y.b((int)((long)988494584 ^ (long)988502786), (int)((long)1035797945 ^ (long)-1035814278)) /* "Width" */)).7(7Y.b((int)((long)-1993484447 ^ (long)-1993492850), (int)((long)-1279869966 ^ (long)-1279877632)) /* "width" */)).1(7Y.b((int)((long)-93823042 ^ (long)-93831678), (int)((long)2104852688 ^ (long)-2104863233)) /* "Tracer line width" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(5.0f)).7 = object;
        this.0q = (1A)((34e)j2).5();
        this.0_ = new 9V();
        this.0f = new Listener(r2 -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u2003;
                        if (bl || bl) break block2;
                        float f = (float)3.aD().k() / 2.0f;
                        9V v = this.0_;
                        this.0_.6 = f;
                        if (bl || bl) break block2;
                        v.3 = (float)3.aD().l() / 2.0f;
                        if (bl || bl) break block2;
                        9b.6((boolean)((long)1289405218 ^ (long)1289405219));
                        if (bl || bl) break block2;
                        4L[] lArray = new 4L[(int)((long)1320790384 ^ (long)1320790386)];
                        lArray[(int)((long)-1686875807 ^ (long)-1686875807)] = 4L.c;
                        lArray[(int)((long)832398889 ^ (long)832398888)] = 4L.a;
                        9b.3(lArray);
                        if (bl || bl) break block2;
                        RenderSystem.lineWidth((float)this.0q.9);
                        if (bl || bl) break block2;
                        if (this.5.2) break block3;
                        if (bl || bl) break block2;
                        GL11.glDisable((int)((int)((long)-1445245003 ^ (long)-1445247851)));
                        if (bl) break block2;
                    }
                    if (bl) break block2;
                    6L.3(7Y.3.r).filter(this.8::9).forEach(object2 -> {
                        float[] fArray;
                        double d2;
                        7Y y;
                        Object object3;
                        8S s;
                        boolean bl;
                        block50: {
                            block49: {
                                String[] stringArray;
                                block48: {
                                    block47: {
                                        block45: {
                                            double d3;
                                            block46: {
                                                block44: {
                                                    bl = \u2003;
                                                    if (bl) return;
                                                    stringArray = 3e.5();
                                                    if (bl || bl) return;
                                                    if (this.7.2) {
                                                        if (bl) return;
                                                        if (Math.abs(object2.cC().b) < 0.001) {
                                                            if (bl) return;
                                                            if (Math.abs(object2.cC().c) < 0.001) {
                                                                if (bl) return;
                                                                if (Math.abs(object2.cC().d) < 0.001) {
                                                                    if (bl || bl) return;
                                                                    return;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    if (bl) return;
                                                    d3 = object2.g(3.aa());
                                                    if (bl || bl) return;
                                                    if (!(object2 instanceof bfw)) break block44;
                                                    if (bl) return;
                                                    if (d3 > this.0x.1) {
                                                        if (bl) return;
                                                        if (this.0h.2) {
                                                            if (bl) return;
                                                            return;
                                                        }
                                                    }
                                                    break block45;
                                                }
                                                if (bl) return;
                                                if (!34L.7(object2)) break block46;
                                                if (bl) return;
                                                if (d3 > this.0F.1) {
                                                    if (bl) return;
                                                    if (this.0G.2) {
                                                        if (bl) return;
                                                        return;
                                                    }
                                                }
                                                break block45;
                                            }
                                            if (bl) return;
                                            if (d3 > this.1.1) {
                                                if (bl) return;
                                                if (this.0m.2) {
                                                    if (bl || bl) return;
                                                    return;
                                                }
                                            }
                                        }
                                        if (bl) return;
                                        s = 5K.8(94.8(object2, ((2_)r2).3()));
                                        if (bl || bl) return;
                                        r2 = 5K.8(94.8(object2, ((2_)r2).3()).7(0.0, object2.cz(), 0.0));
                                        if (bl || bl) return;
                                        if (s == null) break block47;
                                        if (bl) return;
                                        if (r2 != null) break block48;
                                        if (bl) return;
                                    }
                                    if (bl) return;
                                    return;
                                }
                                if (bl) return;
                                this.5(s);
                                if (bl || bl) return;
                                this.5((8S)((Object)r2));
                                if (bl || bl) return;
                                object3 = object2;
                                y = this;
                                if (bl || bl) return;
                                d2 = object3.g(3.aa());
                                if (bl || bl) return;
                                if (!34L.7(object3)) break block49;
                                if (bl || bl) return;
                                fArray = 7Y.3(y.0.2, y.08.1, y.0F.1, y.6.2, y.0C.2, d2);
                                if (bl) return;
                                if (stringArray == null) break block50;
                                if (bl) return;
                            }
                            if (bl) return;
                            fArray = 7Y.3(y.0g.2, y.9.1, y.1.1, y.0H.2, y.4.2, d2);
                            if (bl) return;
                        }
                        if (bl) return;
                        if (object3 instanceof aqm) {
                            if (bl || bl) return;
                            if ((object3 = (aqm)object3) instanceof bfw) {
                                if (bl || bl) return;
                                fArray = 7Y.3(y.0D.2, y.2.1, y.0x.1, y.0Q.2, y.0l.2, d2);
                                if (bl || bl) return;
                                if (y.0A.2) {
                                    if (bl) return;
                                    if (5z.4().1.8(object3.R().toString())) {
                                        if (bl || bl) return;
                                        fArray = 34L.5(y.0z.2.getHex());
                                        if (bl) return;
                                    }
                                }
                            }
                            if (bl) return;
                            if (y.0o.2) {
                                if (bl) return;
                                if ((float)object3.an > 0.0f) {
                                    if (bl || bl) return;
                                    fArray = 34L.5(34L.9(1.0f, 1.0f, (int)((long)-669434307 ^ (long)-669434307)));
                                    if (bl) return;
                                }
                            }
                        }
                        if (bl) return;
                        fArray[(int)((long)-878082379 ^ (long)-878082378)] = y.0P.9;
                        if (bl || bl) return;
                        int n = 9b.2(34L.4(fArray));
                        if (bl || bl) return;
                        9b.5.setColor(n).addVertex(this.0_.6, this.0_.3, 0.0f).setColor(n).addVertex((float)s.9, (float)s.1, 0.0f);
                        if (bl || bl) return;
                        if (((8S)object).2 >= 0.0) {
                            if (bl) return;
                            if (((8S)object).2 < 1.0) {
                                if (bl) return;
                                if (this.0T.2) {
                                    if (bl || bl) return;
                                    9b.5.setColor(n).addVertex((float)((8S)object).9, (float)((8S)object).1, 0.0f);
                                    if (bl) return;
                                }
                            }
                        }
                        if (bl) return;
                        9b.5.draw((int)((long)2038552292 ^ (long)2038552295));
                        if (!bl && !bl) return;
                    });
                    if (bl || bl) break block2;
                    9b.3();
                    if (bl || bl) break block2;
                    9b.6((boolean)((long)-869655181 ^ (long)-869655181));
                    if (!bl && !bl) break block4;
                }
                return;
            }
        }, new Predicate[(int)((long)2024238036 ^ (long)2024238036)]);
        9i[] iArray = new 9i[(int)((long)-1225295642 ^ (long)-1225295646)];
        iArray[(int)((long)-1376573523 ^ (long)-1376573523)] = 94.8(this);
        iArray[(int)((long)-1834495329 ^ (long)-1834495330)] = 94.4(() -> {
            boolean bl = \u2003;
            if (bl || bl) {
                return null;
            }
            return (6y)((Object)((Object)this.02.0()));
        });
        iArray[(int)((long)356549157 ^ (long)356549159)] = 94.5(() -> {
            boolean bl = \u2003;
            if (bl || bl) {
                return null;
            }
            return (6y)((Object)((Object)this.0S.0()));
        });
        iArray[(int)((long)-2119262431 ^ (long)-2119262430)] = new 2z(5r.a, aqa2 -> {
            boolean bl;
            block8: {
                block7: {
                    bl = \u2003;
                    if (bl || bl) return true;
                    if (!this.0Z.2) break block7;
                    if (bl) return true;
                    if (!5z.4().1z.7(3f.class).5.test((aqa)aqa2)) break block8;
                    if (bl) return true;
                }
                if (bl) return true;
                return (int)((long)-1892747671 ^ (long)-1892747672) != 0;
            }
            if (!bl) return (int)((long)1014011435 ^ (long)1014011435) != 0;
            return true;
        });
        this.8 = new 4t(iArray);
        if (3J.1() != null) {
            3e.2(new String[(int)((long)285113098 ^ (long)285113102)]);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static float[] 3(boolean bl, double d2, double d3, pw.knx.feather.structures.Color color, pw.knx.feather.structures.Color color2, double d4) {
        boolean bl2 = \u2003;
        if (bl2 || bl2) return null;
        if (!bl) {
            if (bl2 || bl2) return null;
            return 34L.5(color.getHex());
        }
        if (bl2) return null;
        double d5 = (d4 - d2) / (d3 - d2);
        if (bl2 || bl2) return null;
        double d6 = afm.b((double)color.getHue(), (double)color2.getHue(), (double)d5);
        if (bl2 || bl2) return null;
        double d7 = afm.b((double)color.getSaturation(), (double)color2.getSaturation(), (double)d5);
        if (bl2 || bl2) return null;
        double d8 = afm.b((double)color.getBrightness(), (double)color2.getBrightness(), (double)d5);
        if (!bl2 && !bl2) return 34L.5(pw.knx.feather.structures.Color.fromHSB((float)((float)d6), (float)((float)d7), (float)((float)d8)).getHex());
        return null;
    }
}

