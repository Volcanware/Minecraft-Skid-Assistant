/* ==========================================================================
 * MODULE: Respawn
 * CATEGORY (inferred): Player
 * DESCRIPTION: Manage actions that occur upon death
 * OBFUSCATED CLASS: net.impactclient.7u
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  k
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  nr
 *  sf
 *  sf$a
 */
package net.impactclient;

import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.1z;
import net.impactclient.2w$6X;
import net.impactclient.34R;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.34k;
import net.impactclient.3C;
import net.impactclient.3X;
import net.impactclient.3sC;
import net.impactclient.5p;
import net.impactclient.5z;
import net.impactclient.6L;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 7u
extends 3X
implements 34R {
    public 1z 4;
    @EventHandler
    private final Listener<3C> 8;
    private 1P 7;
    public static final boolean \u200d\u200d;
    private static final String[] d;
    private 1P 5;
    private static final String[] e;
    public 1P 2;
    private 1P 9;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 7u.\u200d\u200d;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1985175595 ^ (long)1985170959)) & (int)((long)1419390585 ^ (long)1419432326);
            if (var9_2) ** GOTO lbl-1000
            if (7u.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 7u.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)788929603 ^ (long)788929603)] & (int)((long)260102024 ^ (long)260102007)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)27872381 ^ (long)27872370);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-2000790030 ^ (long)-2000790198);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1986868669 ^ (long)1986868490);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1449509962 ^ (long)-1449509893);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)1600062643 ^ (long)1600062636);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-291888045 ^ (long)-291888124);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)570628063 ^ (long)570627882);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-2143828318 ^ (long)-2143828327);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)807638548 ^ (long)807638761);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1842947249 ^ (long)1842947161);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1524974219 ^ (long)-1524974165);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)1374782671 ^ (long)1374782523);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-2090323992 ^ (long)-2090324062);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1269728972 ^ (long)1269728971);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1595200315 ^ (long)-1595200290);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-2908618 ^ (long)-2908460);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1015710913 ^ (long)1015710894);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-991596160 ^ (long)-991596046);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1958118929 ^ (long)-1958118969);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1681976432 ^ (long)1681976546);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)1869550061 ^ (long)1869550077);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)589476503 ^ (long)589476568);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1780496928 ^ (long)1780497049);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-418760828 ^ (long)-418760731);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-1627248143 ^ (long)-1627248260);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1996601672 ^ (long)-1996601847);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)113177881 ^ (long)113178003);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1116767672 ^ (long)-1116767714);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1132208904 ^ (long)1132208916);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1510174509 ^ (long)1510174694);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1115156864 ^ (long)1115156962);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-71882757 ^ (long)-71882791);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1165210418 ^ (long)1165210597);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1077541109 ^ (long)1077541118);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)315254057 ^ (long)315254128);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1077353980 ^ (long)-1077353839);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1082674562 ^ (long)-1082674478);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)672855520 ^ (long)672855489);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1885819771 ^ (long)1885819808);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1445442466 ^ (long)-1445442409);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-777507182 ^ (long)-777507327);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1119718178 ^ (long)1119718200);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)244420111 ^ (long)244420132);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)1035790522 ^ (long)1035790461);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)-2096342251 ^ (long)-2096342160);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1563708431 ^ (long)1563708562);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)950683649 ^ (long)950683805);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1922974141 ^ (long)1922974165);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)765437827 ^ (long)765437874);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1446941424 ^ (long)-1446941404);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-2009524105 ^ (long)-2009524183);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1963146513 ^ (long)1963146658);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)1816441540 ^ (long)1816441398);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1375178733 ^ (long)-1375178671);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)953903522 ^ (long)953903557);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1237450968 ^ (long)1237450931);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1567356953 ^ (long)1567357180);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)861762366 ^ (long)861762552);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)893939334 ^ (long)893939270);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1757479845 ^ (long)1757479868);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1772155808 ^ (long)-1772155866);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1422458080 ^ (long)-1422458100);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)1427330102 ^ (long)1427330139);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-158590496 ^ (long)-158590680);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)972767875 ^ (long)972767883);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)101654735 ^ (long)101654718);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1425567761 ^ (long)1425567849);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1859934870 ^ (long)1859934833);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)1885502653 ^ (long)1885502595);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-2119946619 ^ (long)-2119946609);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)312245413 ^ (long)312245340);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1145943055 ^ (long)-1145943199);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-1608995397 ^ (long)-1608995554);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1362428008 ^ (long)1362428056);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-100069091 ^ (long)-100068910);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-1975611231 ^ (long)-1975611316);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-934796893 ^ (long)-934796912);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1976940560 ^ (long)-1976940599);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1771280523 ^ (long)1771280398);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)726577976 ^ (long)726577941);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)115146587 ^ (long)115146677);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)2073723283 ^ (long)2073723381);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-2052941438 ^ (long)-2052941353);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1106203793 ^ (long)-1106203656);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-738405160 ^ (long)-738405258);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-2067505911 ^ (long)-2067505856);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-573669623 ^ (long)-573669468);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-382753839 ^ (long)-382753904);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)1256031997 ^ (long)1256031891);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)486265607 ^ (long)486265747);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1617100794 ^ (long)-1617100766);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)928060516 ^ (long)928060546);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-263423120 ^ (long)-263423180);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-798659280 ^ (long)-798659174);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1208897073 ^ (long)1208897240);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1846298727 ^ (long)-1846298836);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)-1793777937 ^ (long)-1793778009);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-729327366 ^ (long)-729327456);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-278435621 ^ (long)-278435801);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-2029891357 ^ (long)-2029891563);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-739538045 ^ (long)-739538151);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1344046709 ^ (long)-1344046632);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-920736161 ^ (long)-920736032);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-566002066 ^ (long)-566001935);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-757924079 ^ (long)-757924006);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)867053887 ^ (long)867053954);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-744551859 ^ (long)-744551877);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-1994033622 ^ (long)-1994033461);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-359644782 ^ (long)-359644674);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-737148942 ^ (long)-737149136);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)422667481 ^ (long)422667494);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-745177082 ^ (long)-745176851);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)854031941 ^ (long)854032101);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)930147832 ^ (long)930147835);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-540325929 ^ (long)-540326124);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-589417107 ^ (long)-589417035);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-3477182 ^ (long)-3477199);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1014833030 ^ (long)1014832944);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1715286305 ^ (long)1715286432);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-311260716 ^ (long)-311260927);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-2033406450 ^ (long)-2033406314);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1647980341 ^ (long)1647980295);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)84108661 ^ (long)84108667);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-709610658 ^ (long)-709610680);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-394133506 ^ (long)-394133702);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)-1434028470 ^ (long)-1434028333);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1876849749 ^ (long)1876849885);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)866131546 ^ (long)866131642);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1849055720 ^ (long)1849055570);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-1941387728 ^ (long)-1941387550);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-894393259 ^ (long)-894393304);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1536229322 ^ (long)1536229242);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)1961171297 ^ (long)1961171439);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1523762389 ^ (long)1523762368);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-949264584 ^ (long)-949264407);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1133986523 ^ (long)1133986378);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1682452381 ^ (long)1682452241);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1988109863 ^ (long)-1988109927);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-501395541 ^ (long)-501395594);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1630046743 ^ (long)1630046770);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1054437238 ^ (long)-1054437228);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1296015113 ^ (long)-1296015255);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1078362849 ^ (long)1078362714);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1287447796 ^ (long)1287447586);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1169866703 ^ (long)1169866718);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)0x33939D9 ^ (long)54082005);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1956234010 ^ (long)-1956234021);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-740876324 ^ (long)-740876488);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-1388468578 ^ (long)-1388468582);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1498413359 ^ (long)1498413555);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-1794925394 ^ (long)-1794925322);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-817298780 ^ (long)-817298803);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)847212207 ^ (long)847212077);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-354458416 ^ (long)-354458494);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)815076473 ^ (long)815076361);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)898553401 ^ (long)898553503);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)246029938 ^ (long)246029893);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1664697140 ^ (long)-1664697105);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1621081684 ^ (long)-1621081816);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)473825489 ^ (long)473825366);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-66583442 ^ (long)-66583344);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1791340715 ^ (long)1791340747);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-963615270 ^ (long)-963615244);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1213498219 ^ (long)1213498282);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1135450293 ^ (long)1135450223);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)1911018936 ^ (long)1911018839);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1079014171 ^ (long)-1079014351);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1046672753 ^ (long)1046672654);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-2020890018 ^ (long)-2020889934);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)1241653602 ^ (long)1241653565);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1734868383 ^ (long)1734868387);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-988826631 ^ (long)-988826711);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1883122628 ^ (long)1883122492);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1205435955 ^ (long)1205436047);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)89451602 ^ (long)89451763);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1054016108 ^ (long)-1054016040);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-208744138 ^ (long)-208744085);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-43618260 ^ (long)-43618218);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)565057979 ^ (long)565057810);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-2021329336 ^ (long)-2021329237);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)482897555 ^ (long)482897636);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-148533368 ^ (long)-148533367);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)1487230862 ^ (long)1487230847);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-2013165844 ^ (long)-2013165944);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-864936394 ^ (long)-864936335);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-2028377944 ^ (long)-2028378030);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-685857457 ^ (long)-685857406);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)883826458 ^ (long)883826490);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)765579228 ^ (long)765579024);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)683311545 ^ (long)683311386);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1627484704 ^ (long)-1627484691);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)556136112 ^ (long)556136100);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)937451150 ^ (long)937451089);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)805562878 ^ (long)805562799);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1583614161 ^ (long)-1583613956);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-824146384 ^ (long)-824146266);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)704445337 ^ (long)704445359);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)-2009672582 ^ (long)-2009672688);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1481015630 ^ (long)-1481015632);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)1228748398 ^ (long)1228748398);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-1079954660 ^ (long)-1079954663);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)2077999818 ^ (long)2077999795);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1081051250 ^ (long)1081051354);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-1987479683 ^ (long)-1987479721);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)557296411 ^ (long)557296494);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)161394270 ^ (long)161394192);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1677453490 ^ (long)-1677453464);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-785493261 ^ (long)-785493400);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1929983141 ^ (long)1929982983);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)306164293 ^ (long)306164349);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-44341633 ^ (long)-44341717);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-774263358 ^ (long)-774263367);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)-1550757172 ^ (long)-1550757124);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1135299672 ^ (long)-1135299727);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1906970058 ^ (long)-1906969892);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-2059559161 ^ (long)-2059559028);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)934986343 ^ (long)934986396);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)988085358 ^ (long)988085441);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-733229170 ^ (long)-733229159);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1229702696 ^ (long)-1229702869);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-864406415 ^ (long)-864406476);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-614952968 ^ (long)-614953162);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)244148053 ^ (long)244148001);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-348155260 ^ (long)-348155360);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-327229950 ^ (long)-327229820);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)32793555 ^ (long)32793366);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-460732375 ^ (long)-460732369);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-517659018 ^ (long)-517659128);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1856729790 ^ (long)1856729753);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1061037831 ^ (long)-1061037840);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1601985642 ^ (long)1601985685);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-2144171189 ^ (long)-2144171061);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-1618221675 ^ (long)-1618221649);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1280967876 ^ (long)-1280967785);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1755745017 ^ (long)-1755744914);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)389681285 ^ (long)389681401);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-899781293 ^ (long)-899781252);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-736284599 ^ (long)-736284541);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)90935031 ^ (long)90934932);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)377346243 ^ (long)377346167);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)841604779 ^ (long)841604848);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)1258130757 ^ (long)1258130837);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-1481078170 ^ (long)-1481078079);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)267807528 ^ (long)0xFF66B6B);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1857097294 ^ (long)1857097299);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1658600589 ^ (long)1658600511);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1341965280 ^ (long)-1341965097);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-486454092 ^ (long)-486454217);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1340898868 ^ (long)1340898854);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)2041458228 ^ (long)2041458365);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1079689986 ^ (long)1079690001);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1625865595 ^ (long)1625865605);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)803589921 ^ (long)803590013);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)1225138627 ^ (long)1225138508);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)495843657 ^ (long)495843665);
                    if (!7u.\u200d\u200d) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)778466793 ^ (long)778466780);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1647481030 ^ (long)-1647480891)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1175266397 ^ (long)-1175313316)) >>> (int)((long)1777714965 ^ (long)1777714973)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)2116288984 ^ (long)2116288984);
            if (!7u.\u200d\u200d) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)-358486357 ^ (long)-358486359);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1533686593 ^ (long)1533686594) | var5_6 << (int)((long)75663404 ^ (long)75663401)) ^ var3_4[var7_8]) & (int)((long)801681226 ^ (long)801681333);
                    if (7u.\u200d\u200d) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-786056751 ^ (long)-786056750) | var6_7 << (int)((long)-852830111 ^ (long)-852830108)) ^ var3_4[var7_8]) & (int)((long)-1198581409 ^ (long)-1198581344);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            7u.e[var2_3] = new String(var3_4).intern();
        }
        return 7u.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 7u.\u200d\u200d;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-176530423 ^ (long)-176530414)];
            if (var7) break block23;
            var3_2 = (int)((long)874052908 ^ (long)874052908);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u8044\ua945\uba34\ub24a\u8003\ua9ae\ubab2\ub226\u80a4\ua95b\uba15\ub289\u80d0\ua9b6\uba36\ub29a\u804f\ua9ca\uba14\ub2e6\u80e1\ua9ea\ubae5\ub23f\u8037\ua99e\ubaeb\ub258\u8097\ua90b\uba04\ub25d\u80a8\ua9f2\uba77\ub2a4\u80ae\ua932\ubac6\ub2cb\u8077\ua92b\uba47\ub247\u80df\ua9a6\ubac3\ub297\u809f\ua962\uba20\ub2b5\u804c\ua9b1\ubace\ub2bc\u80de\ua905\uba40\ub20c\u806f\ua93b\uba36\ub2a3\u80d9\ua90c\uba71\ub277\u80de\ua9f3\uba6e\ub2b1\u8065\ua93d\ubaa3\ub252\u8082\ua9dc\uba15\ub2b0\u80ae\ua9fb\ubab2\ub2d9\u80ae\ua90a\uba57\ub23d\u8060\ua92f\uba22\ub29c\u8081\ua9d6\uba8e\ub29b\u80bb\ua9ac\uba4e\ub221\u80ee\ua9cb\uba5e\ub2a5\u80bf\ua9a5\uba41\ub239\u80e0\ua927\ubaec\ub2c4\u8001\ua9e0\uba07\ub276\u807f\ua981\uba04\ub262\u806f\ua90c\uba02\ub26d\u8042\ua963\uba78\ub25c\u8063\ua99c\ubaa4\ub276\u806e\ua9ff\uba51\ub219\u8028\ua928\uba1a\ub23b\u8088\ua91d\uba1d\ub24c\u80e6\ua987\uba7d\ub2c1\u8031\ua933\uba8a\ub298\u8078\ua98e\uba34\ub21d\u80cb\ua94c\ubafa\ub255\u802b\ua9bb\ubac5\ub2f6\u80b2\ua906\uba64\ub256\u80d4\ua9c6\ubae0\ub22b\u8071\ua980\uba0a\ub280\u80c9\ua996\uba21\ub255\u80f2\ua924\ubaf6\ub253\u8059\ua928\uba15\ub2e3\u801f\ua9ed\ubafe\ub2e0\u801e\ua99e\uba7f\ub261\u80d6\ua9f5\uba31\ub2eb\u808c\ua99b\ubad0\ub2ff\u8035\ua907\uba51\ub288\u8062\ua9b2\uba54\ub239\u8066\ua9b2\uba90\ub2dc\u8062\ua928\uba6e\ub2eb\u8097\ua906\uba9e\ub29c\u8051\ua93c\uba6f\ub277\u8044\ua906\ubab9\ub2e6\u8034\ua9ba\uba86\ub254\u80db\ua9fd\uba14\ub250\u807f\ua92c\uba58\ub232\u80d9\ua9d0\ubac9\ub2e0\u80b8\ua99b\uba65\ub291\u8080\ua91b\uba99\ub29f\u80d9\ua934\ubabb\ub278\u806e\ua97a\ubadb\ub25b\u8023\ua9db\uba22\ub281\u8004\ua9c5\ubafe\ub20f\u80b0\ua9c5\uba26\ub202\u805c\ua9b0\uba36\ub2b4\u8097\ua91b\uba92\ub275\u8058\ua933\uba0c\ub205\u80a2\ua94a\ubab1\ub21c\u805c\ua928\uba70\ub238\u80f2\ua901\uba29\ub2b8\u8035\ua9a8\uba5d\ub2af\u806a\ua940\ubae8\ub252\u80ae\ua961\uba93\ub257\u804b\ua9b1\ubac6\ub281\u805b\ua903\uba2e\ub249\u80c5\ua9c4\ubadf\ub26d\u8060\ua9be\uba86\ub2c4\u80f9\ua9f5\uba22\ub2d6\u8086\ua913\uba26\ub273\u80dc\ua915", 1333700496);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)1218902739 ^ (long)1218902736);
            if (var7) break block23;
            var0_6 = (int)((long)-1635465832 ^ (long)1635465831);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1266295750 ^ (long)-1266295797);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)175022056 ^ (long)-175022057);
                    if (7u.\u200d\u200d) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7u.\u200d\u200d) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\ubdee\u94d9\u87e5\u8f6c\ubd8e\u94a7\u8702\u8f7c\ubdd8\u94f6\u875a\u8f6f\ubd80\u94f7\u8738\u8f53\ubdbb\u9493\u871c\u8fb7\ubd6c\u9417\u8780\u8f6b\ubd2c\u94be\u87eb\u8f11\ubdf0\u9409\u873c\u8f75\ubd39\u94c5\u87e4\u8f80\ubdb9\u9489\u8711\u8f40\ubd01\u94e8\u87cf\u8f6c\ubd3f\u94b2\u870c\u8fbb\ubdab\u94c8\u8767\u8f42\ubd63\u9472\u87b8\u8f64\ubdc0\u94e5\u87fd\u8fa4\ubdaf\u944e\u875b\u8f7a", -1665426700);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-153126207 ^ (long)-153126182);
                            var0_6 = (int)((long)-579087517 ^ (long)579087516);
                            while (true) {
                                v0 = (int)((long)475421972 ^ (long)475422008);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)2103556117 ^ (long)2103556117);
                                if (!7u.\u200d\u200d) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!7u.\u200d\u200d) ** continue;
                                throw null;
                            }
                            7u.d = var5_1;
                            7u.e = new String[(int)((long)-1942044464 ^ (long)-1942044469)];
                            if (!7u.\u200d\u200d) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-35545997 ^ (long)-35545997);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1162463678 ^ (long)1162463679)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-75911868 ^ (long)-75911869)) {
                                case 0: {
                                    v15 = (int)((long)-1371363979 ^ (long)-1371364015);
                                    if (!7u.\u200d\u200d) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-1325642368 ^ (long)-1325642328);
                                    if (!7u.\u200d\u200d) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)2115099720 ^ (long)2115099754);
                                    if (!7u.\u200d\u200d) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-1249374825 ^ (long)-1249374796);
                                    if (!7u.\u200d\u200d) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1323791057 ^ (long)-1323791001);
                                    if (!7u.\u200d\u200d) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)340884070 ^ (long)340884090);
                                    if (!7u.\u200d\u200d) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)830496461 ^ (long)830496408);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!7u.\u200d\u200d);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public final void 5() {
        block5: {
            block2: {
                boolean bl;
                block3: {
                    block4: {
                        bl = \u200d\u200d;
                        if (bl || bl) break block2;
                        if (!this.3()) break block3;
                        if (bl || bl) break block2;
                        if (!this.7.2) break block4;
                        if (bl || bl) break block2;
                        k[] kArray = new k[(int)((long)1304315144 ^ (long)1304315145)];
                        kArray[(int)((long)750749158 ^ (long)750749158)] = k.j;
                        k[] kArray2 = kArray;
                        3sC sC = new 3sC().1(7u.b((int)((long)1586098663 ^ (long)1586094024), (int)((long)1394248563 ^ (long)-1394261858)) /* "You Died At: " */).2(7u.b((int)((long)-44634261 ^ (long)-44646065), (int)((long)874306153 ^ (long)-874291567)) /* "X: " */, null, kArray2);
                        k[] kArray3 = new k[(int)((long)-1228720527 ^ (long)-1228720528)];
                        kArray3[(int)((long)1319195910 ^ (long)1319195910)] = k.h;
                        kArray2 = kArray3;
                        3sC sC2 = sC.2((int)7u.3.s.cD() + 7u.b((int)((long)-746429102 ^ (long)-746435728), (int)((long)-588939691 ^ (long)588955210)) /* ", " */, null, kArray2);
                        k[] kArray4 = new k[(int)((long)1901182184 ^ (long)1901182185)];
                        kArray4[(int)((long)-1662172132 ^ (long)-1662172132)] = k.j;
                        kArray2 = kArray4;
                        3sC sC3 = sC2.2(7u.b((int)((long)1255934656 ^ (long)1255941367), (int)((long)19074288 ^ (long)-19098904)) /* "Y: " */, null, kArray2);
                        k[] kArray5 = new k[(int)((long)-1271001298 ^ (long)-1271001297)];
                        kArray5[(int)((long)246184976 ^ (long)246184976)] = k.h;
                        kArray2 = kArray5;
                        3sC sC4 = sC3.2((int)7u.3.s.cE() + 7u.b((int)((long)-1082483426 ^ (long)-1082477772), (int)((long)-422955417 ^ (long)422950517)), null, kArray2);
                        k[] kArray6 = new k[(int)((long)924335084 ^ (long)924335085)];
                        kArray6[(int)((long)451253324 ^ (long)451253324)] = k.j;
                        kArray2 = kArray6;
                        3sC sC5 = sC4.2(7u.b((int)((long)234628792 ^ (long)234621083), (int)((long)1650818099 ^ (long)1650799202)) /* "Z: " */, null, kArray2);
                        k[] kArray7 = new k[(int)((long)592133206 ^ (long)592133207)];
                        kArray7[(int)((long)212246188 ^ (long)212246188)] = k.h;
                        kArray2 = kArray7;
                        5p.9((nr)sC5.2((String)new StringBuilder().append((int)((int)7u.3.s.cH())).append((String)2w$6X.KAOZ((Object)"\u45e6", (int)-616734078)).toString(), null, (k[])kArray2).7);
                        if (bl) break block2;
                    }
                    if (bl) break block2;
                    if (!this.5.2) break block3;
                    if (bl || bl) break block2;
                    5z.4().5.execute(() -> {
                        block3: {
                            block2: {
                                boolean bl = \u200d\u200d;
                                if (bl || bl) break block2;
                                int n = (int)((long)-2047392214 ^ (long)-2047383524);
                                5z.4();
                                Path path = 5z.1(7u.b(n, (int)((long)-167873070 ^ (long)167884901)));
                                List<String> list = 6L.1((Path)path).3;
                                if (bl || bl) break block2;
                                String string = new SimpleDateFormat(7u.b((int)((long)1828219619 ^ (long)1828209875), (int)((long)1862225643 ^ (long)-1862220273)) /* "yyyy-MM-dd hh:mm:ss" */).format(new Date());
                                if (bl || bl) break block2;
                                Object[] objectArray = new Object[(int)((long)-248084489 ^ (long)-248084493)];
                                objectArray[(int)((long)-923201734 ^ (long)-923201734)] = string;
                                objectArray[(int)((long)-1386800661 ^ (long)-1386800662)] = 7u.3.s.cD();
                                objectArray[(int)((long)-1307499368 ^ (long)-1307499366)] = 7u.3.s.cE();
                                objectArray[(int)((long)-2018830685 ^ (long)-2018830688)] = 7u.3.s.cH();
                                list.add(String.format(7u.b((int)((long)-243523881 ^ (long)-243519254), (int)((long)438416988 ^ (long)438425527)) /* "%s [%01.2f, %01.2f, %01.2f]" */, objectArray));
                                if (bl || bl) break block2;
                                6L.1(list, path);
                                if (!bl && !bl) break block3;
                            }
                            return;
                        }
                    });
                    if (bl) break block2;
                }
                if (!bl) break block5;
            }
            return;
        }
    }

    public 7u() {
        boolean bl = \u200d\u200d;
        super(7u.b((int)((long)291523368 ^ (long)291530004), (int)((long)-2059529643 ^ (long)-2059513944)) /* "Respawn" */, 7u.b((int)((long)-830359138 ^ (long)-830367818), (int)((long)-2011606856 ^ (long)-2011606459)) /* "Manage actions that occur upon death" */);
        this.2 = (1P)((34X)((34X)((34X)this.4().5(7u.b((int)((long)997528569 ^ (long)997539272), (int)((long)1209616883 ^ (long)-1209624854)) /* "Auto-Respawn" */)).7(7u.b((int)((long)550820834 ^ (long)550827471), (int)((long)636520493 ^ (long)636541947)) /* "auto" */)).1(7u.b((int)((long)1855996893 ^ (long)1856007656), (int)((long)-1415240238 ^ (long)-1415217242)) /* "Automatically respawn" */)).5();
        this.9 = (1P)((34X)((34X)((34X)((34X)this.4().5(7u.b((int)((long)1614329989 ^ (long)1614321324), (int)((long)478348726 ^ (long)-478358147)) /* "Home" */)).7(7u.b((int)((long)1230087770 ^ (long)1230080118), (int)((long)1506803499 ^ (long)-1506795920)) /* "home" */)).1(7u.b((int)((long)-1566819573 ^ (long)-1566829266), (int)((long)-879281243 ^ (long)-879277145)) /* "Automatically execute /home" */)).3(this.2)).5();
        Integer n = (int)((long)1608254192 ^ (long)1608256308);
        34e e = ((34e)((34e)((34e)this.1().5(7u.b((int)((long)442617101 ^ (long)442622777), (int)((long)44460561 ^ (long)-44457359)) /* "Delay" */)).7(7u.b((int)((long)1618837007 ^ (long)1618825256), (int)((long)1745960262 ^ (long)1745963661)) /* "delay" */)).1(7u.b((int)((long)425616414 ^ (long)425609760), (int)((long)856791941 ^ (long)856795790)) /* "The Delay in MS for until respawning" */)).3((int)((long)531248956 ^ (long)531249094)).2((int)((long)1016867013 ^ (long)1016860629));
        ((34e)((34e)((34e)this.1().5(7u.b((int)((long)442617101 ^ (long)442622777), (int)((long)44460561 ^ (long)-44457359)) /* "Delay" */)).7(7u.b((int)((long)1618837007 ^ (long)1618825256), (int)((long)1745960262 ^ (long)1745963661)) /* "delay" */)).1(7u.b((int)((long)425616414 ^ (long)425609760), (int)((long)856791941 ^ (long)856795790)) /* "The Delay in MS for until respawning" */)).3((int)((long)531248956 ^ (long)531249094)).2((int)((long)1016867013 ^ (long)1016860629)).7 = n;
        this.4 = (1z)((34e)e.3(this.2)).5();
        this.7 = (1P)((34X)((34X)((34X)this.4().5(7u.b((int)((long)2084750256 ^ (long)2084760982), (int)((long)1247398710 ^ (long)1247387124)) /* "Death Coords" */)).7(7u.b((int)((long)-194223994 ^ (long)-194228556), (int)((long)-1851388885 ^ (long)1851359326)) /* "coords" */)).1(7u.b((int)((long)-1476038670 ^ (long)-1476050471), (int)((long)-1204637027 ^ (long)-1204641813)) /* "Prints out the coordinates that you died to chat" */)).5();
        this.5 = (1P)((34X)((34X)((34X)this.4().5(7u.b((int)((long)-239093702 ^ (long)-239102455), (int)((long)1508918455 ^ (long)1508911826)) /* "Save Coords" */)).7(7u.b((int)((long)-992129877 ^ (long)-992124278), (int)((long)128714181 ^ (long)128725681)) /* "save" */)).1(7u.b((int)((long)2096215158 ^ (long)2096208472), (int)((long)543613355 ^ (long)543606895)) /* "Saves the coordinates that you died at to a file" */)).5();
        Predicate[] predicateArray = new Predicate[(int)((long)-1217341429 ^ (long)-1217341430)];
        Class[] classArray = new Class[(int)((long)715759116 ^ (long)715759117)];
        classArray[(int)((long)-1713168909 ^ (long)-1713168909)] = sf.class;
        predicateArray[(int)((long)69104709 ^ (long)69104709)] = new 34k(classArray);
        this.8 = new Listener(c2 -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u200d\u200d;
                        if (bl || bl) break block2;
                        if (((sf)c2.7).b() != sf.a.a) break block3;
                        if (bl) break block2;
                        if (!this.9.2) break block3;
                        if (bl || bl) break block2;
                        7u.3.s.f(7u.b((int)((long)1387854684 ^ (long)1387844988), (int)((long)1376296433 ^ (long)-1376310689)) /* "/home" */);
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, predicateArray);
    }
}

