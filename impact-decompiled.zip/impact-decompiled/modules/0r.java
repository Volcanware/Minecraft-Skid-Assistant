/* ==========================================================================
 * MODULE: Auto Mine
 * CATEGORY (inferred): Player
 * DESCRIPTION: Automatically mines for you
 * OBFUSCATED CLASS: net.impactclient.0r
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  baritone.api.BaritoneAPI
 *  baritone.api.Settings
 *  baritone.api.Settings$Setting
 *  baritone.api.process.IMineProcess
 *  buo
 *  bup
 *  dcl$a
 *  djw
 *  gb
 *  gm
 *  k
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  np
 *  np$a
 *  nr
 *  vk
 */
package net.impactclient;

import baritone.api.BaritoneAPI;
import baritone.api.Settings;
import baritone.api.process.IMineProcess;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import me.zero.clarinet.hook.mixin.accessor.AccessorKeyBinding;
import net.impactclient.0l;
import net.impactclient.11;
import net.impactclient.1P;
import net.impactclient.2R;
import net.impactclient.2w$6X;
import net.impactclient.34G;
import net.impactclient.34H;
import net.impactclient.34J;
import net.impactclient.34R;
import net.impactclient.34X;
import net.impactclient.3X;
import net.impactclient.3d;
import net.impactclient.3e;
import net.impactclient.3sC;
import net.impactclient.4f;
import net.impactclient.5p;
import net.impactclient.5z;
import net.impactclient.8z;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0r
extends 3X
implements 34R {
    private 1P 2;
    private static final String[] d;
    private 11 6;
    private static final String[] e;
    private 34G 0;
    @EventHandler
    private final Listener<4f> 4;
    public static final boolean \u2004\u200d\u200d\u200d\u200f;
    private boolean 8;

    public 0r() {
        boolean bl = \u2004\u200d\u200d\u200d\u200f;
        super(0r.b((int)((long)-1730505556 ^ (long)1730485844), (int)((long)995662200 ^ (long)995669454)) /* "Auto Mine" */, 0r.b((int)((long)1225496506 ^ (long)-1225515692), (int)((long)1550239108 ^ (long)-1550225681)) /* "Automatically mines for you" */);
        Object object = Boolean.TRUE;
        34J j2 = (34X)((34X)((34X)this.4().5(0r.b((int)((long)-1780971149 ^ (long)1780941709), (int)((long)-214590913 ^ (long)214595501)) /* "Bot Mode" */)).7(0r.b((int)((long)-644653403 ^ (long)644666435), (int)((long)1444965287 ^ (long)1444952980)) /* "baritone" */)).1(0r.b((int)((long)-1953404328 ^ (long)1953423544), (int)((long)-1765664236 ^ (long)-1765655736)) /* "Utilize baritone's A* technology to pathfind to and mine target ores" */);
        ((34X)((34X)((34X)this.4().5(0r.b((int)((long)-1780971149 ^ (long)1780941709), (int)((long)-214590913 ^ (long)214595501)) /* "Bot Mode" */)).7(0r.b((int)((long)-644653403 ^ (long)644666435), (int)((long)1444965287 ^ (long)1444952980)) /* "baritone" */)).1(0r.b((int)((long)-1953404328 ^ (long)1953423544), (int)((long)-1765664236 ^ (long)-1765655736)) /* "Utilize baritone's A* technology to pathfind to and mine target ores" */)).7 = object;
        this.2 = (1P)j2.5();
        String[] stringArray = new String[(int)((long)-669785065 ^ (long)-669785058)];
        stringArray[(int)((long)-501822561 ^ (long)-501822561)] = 0r.b((int)((long)-1382023733 ^ (long)1382053686), (int)((long)1477944542 ^ (long)-1477967763)) /* "Diamond" */;
        stringArray[(int)((long)-1219374278 ^ (long)-1219374277)] = 0r.b((int)((long)-168319414 ^ (long)168307900), (int)((long)1751693427 ^ (long)1751696961)) /* "Iron" */;
        stringArray[(int)((long)-1263246920 ^ (long)-1263246918)] = 0r.b((int)((long)-582334647 ^ (long)582340006), (int)((long)53329460 ^ (long)-53334980)) /* "Gold" */;
        stringArray[(int)((long)1859020039 ^ (long)1859020036)] = 0r.b((int)((long)-73646037 ^ (long)73648838), (int)((long)-1798746246 ^ (long)1798761621)) /* "Emerald" */;
        stringArray[(int)((long)-1467111279 ^ (long)-1467111275)] = 0r.b((int)((long)-1132935455 ^ (long)1132940306), (int)((long)385874048 ^ (long)-385874776)) /* "Redstone" */;
        stringArray[(int)((long)526706410 ^ (long)526706415)] = 0r.b((int)((long)1050107843 ^ (long)-1050094303), (int)((long)369611242 ^ (long)369608687)) /* "Lapis" */;
        stringArray[(int)((long)1773813392 ^ (long)1773813398)] = 0r.b((int)((long)817342487 ^ (long)-817356044), (int)((long)-1257526100 ^ (long)-1257508954)) /* "Coal" */;
        stringArray[(int)((long)-2048145178 ^ (long)-2048145183)] = 0r.b((int)((long)-357482094 ^ (long)357485411), (int)((long)-1396073262 ^ (long)1396051180)) /* "Quartz" */;
        stringArray[(int)((long)1191918949 ^ (long)1191918957)] = 0r.b((int)((long)-1358700261 ^ (long)1358719999), (int)((long)-636056575 ^ (long)636030023)) /* "Logs" */;
        object = stringArray;
        j2 = (34H)((34H)((34H)this.0().5(0r.b((int)((long)349430533 ^ (long)-349410817), (int)((long)1003379160 ^ (long)1003362436)) /* "Target" */)).7(0r.b((int)((long)1939113560 ^ (long)-1939141473), (int)((long)272155856 ^ (long)272165160)) /* "target" */)).1(0r.b((int)((long)1516039225 ^ (long)-1516017979), (int)((long)1423069622 ^ (long)1423077514)) /* "The mine target\\nTo mine custom block(s) do .b mine <block_name> <block_name>" */);
        ((34H)((34H)((34H)this.0().5(0r.b((int)((long)349430533 ^ (long)-349410817), (int)((long)1003379160 ^ (long)1003362436)) /* "Target" */)).7(0r.b((int)((long)1939113560 ^ (long)-1939141473), (int)((long)272155856 ^ (long)272165160)) /* "target" */)).1(0r.b((int)((long)1516039225 ^ (long)-1516017979), (int)((long)1423069622 ^ (long)1423077514)) /* "The mine target\\nTo mine custom block(s) do .b mine <block_name> <block_name>" */)).3 = object;
        this.6 = (11)((34H)j2.3(this.2)).5();
        this.0 = 34G.5(() -> ((IMineProcess)BaritoneAPI.getProvider().getPrimaryBaritone().getMineProcess()).cancel());
        this.8 = (int)((long)-602803804 ^ (long)-602803803);
        this.4 = new Listener(arrayList -> {
            block27: {
                block28: {
                    String[] stringArray;
                    block26: {
                        boolean bl = \u2004\u200d\u200d\u200d\u200f;
                        if (bl) return;
                        stringArray = 3e.5();
                        if (bl || bl) return;
                        if (((4f)((Object)arrayList)).8 != EventState.POST) {
                            if (bl || bl) return;
                            return;
                        }
                        if (bl) return;
                        arrayList = 0r.b((int)((long)-1720525407 ^ (long)1720538974), (int)((long)-786691769 ^ (long)786661938)) /* "Mouse" */;
                        if (bl || bl) return;
                        if (!this.2.2) break block26;
                        if (bl || bl) return;
                        if (!((Boolean)BaritoneAPI.getSettings().allowBreak.value).booleanValue()) {
                            if (bl || bl) return;
                            arrayList = 5z.4().2.5.8;
                            if (bl || bl) return;
                            k[] kArray = new k[(int)((long)-379103788 ^ (long)-379103787)];
                            kArray[(int)((long)-1521372629 ^ (long)-1521372629)] = k.m;
                            k[] kArray2 = kArray;
                            k[] kArray3 = new k[(int)((long)-1916055191 ^ (long)-1916055192)];
                            kArray3[(int)((long)1502260275 ^ (long)1502260275)] = k.k;
                            3sC sC = new 3sC().2(0r.b((int)((long)1909042172 ^ (long)-1909055221), (int)((long)2000718097 ^ (long)-2000744777)) /* "allowBreak is disabled! You must " */, null, kArray2).2(0r.b((int)((long)1819188972 ^ (long)-1819208691), (int)((long)-774294485 ^ (long)-774293175)) /* "[Enable]" */, new np(np.a.c, (String)((Object)arrayList) + 0r.b((int)((long)2109011067 ^ (long)-2108981614), (int)((long)-977778529 ^ (long)977777486)) /* "b allowBreak" */), kArray3);
                            k[] kArray4 = new k[(int)((long)444287452 ^ (long)444287453)];
                            kArray4[(int)((long)-38295074 ^ (long)-38295074)] = k.m;
                            kArray2 = kArray4;
                            5p.9((nr)sC.2((String)0r.b((int)((int)((long)-1814641250 ^ (long)1814646631)), (int)((int)((long)2001583063 ^ (long)-2001569599))), null, (k[])kArray2).7);
                            if (bl || bl) return;
                            this.1((boolean)((long)2128998477 ^ (long)2128998477));
                            if (bl || bl) return;
                            return;
                        }
                        if (bl) return;
                        3d.2();
                        if (bl || bl) return;
                        if (this.8) {
                            List<String> list;
                            if (bl || bl) return;
                            if (((String)this.6.0()).equals(0r.b((int)((long)-1031346018 ^ (long)1031365230), (int)((long)-1447282658 ^ (long)-1447271476)))) {
                                if (bl) {
                                    return;
                                }
                                buo[] buoArray = new buo[(int)((long)1247933513 ^ (long)1247933519)];
                                buoArray[(int)((long)1806618942 ^ (long)1806618942)] = bup.N;
                                buoArray[(int)((long)-571436843 ^ (long)-571436844)] = bup.L;
                                buoArray[(int)((long)-1820537532 ^ (long)-1820537530)] = bup.O;
                                buoArray[(int)((long)1638965393 ^ (long)1638965394)] = bup.M;
                                buoArray[(int)((long)1601612194 ^ (long)1601612198)] = bup.J;
                                buoArray[(int)((long)-199962885 ^ (long)-199962882)] = bup.K;
                                list = Stream.of(buoArray).map(arg_0 -> ((gb)gm.Q).b(arg_0)).map(vk::toString).collect(Collectors.toList());
                                if (\u2004\u200d\u200d\u200d\u200f) {
                                    throw null;
                                }
                            } else {
                                String string;
                                String string2 = 0r.b((int)((long)-112081123 ^ (long)112086504), (int)((long)-109509218 ^ (long)109483735)) /* "%s_ore" */;
                                Object[] objectArray = new Object[(int)((long)906086171 ^ (long)906086170)];
                                int n = (int)((long)1011019074 ^ (long)1011019074);
                                if (((String)this.6.0()).equals(0r.b((int)((long)-868297699 ^ (long)868310761), (int)((long)-129488701 ^ (long)129476403)))) {
                                    string = 0r.b((int)((long)1198888170 ^ (long)-1198907880), (int)((long)-1588756102 ^ (long)1588751710)) /* "nether_quartz" */;
                                    if (\u2004\u200d\u200d\u200d\u200f) {
                                        throw null;
                                    }
                                } else {
                                    string = ((String)this.6.0()).toLowerCase();
                                }
                                objectArray[n] = string;
                                list = new ArrayList<String>(Collections.singleton(String.format(string2, objectArray)));
                            }
                            arrayList = list;
                            BaritoneAPI.getProvider().getPrimaryBaritone().getMineProcess().mineByName(arrayList.toArray(new String[(int)((long)318083031 ^ (long)318083031)]));
                            this.8 = (int)((long)-1571744404 ^ (long)-1571744404);
                        }
                        arrayList = (String)this.6.0();
                        if (!BaritoneAPI.getProvider().getPrimaryBaritone().getMineProcess().isActive()) {
                            this.1((boolean)((long)-464736657 ^ (long)-464736657));
                            return;
                        }
                        this.0.8 = (int)((long)1505148446 ^ (long)1505148447);
                        if (stringArray == null) break block27;
                    }
                    this.0.8();
                    if (0r.3.v.c() != dcl.a.b) break block28;
                    ((AccessorKeyBinding)0r.3.k.aq).setPressed((boolean)((long)-1824613278 ^ (long)-1824613277));
                    if (stringArray == null) break block27;
                }
                djw.a();
            }
            2R.1(this, 0r.b((int)((long)-438080633 ^ (long)438100332), (int)((long)-183340297 ^ (long)183361837)) /* "suffix" */, arrayList);
        }, new Predicate[(int)((long)650529662 ^ (long)650529662)]);
        this.6.3((z, string, string2) -> {
            block3: {
                block2: {
                    boolean bl = \u2004\u200d\u200d\u200d\u200f;
                    if (bl || bl) break block2;
                    this.8 = (int)((long)-1230081021 ^ (long)-1230081022);
                    if (!bl) break block3;
                }
                return;
            }
        });
        j2 = BaritoneAPI.getSettings();
        object = 0l.0((Settings.Setting<Boolean>)((Settings)j2).legitMine, 0r.b((int)((long)2102607648 ^ (long)-2102610488), (int)((long)1290265214 ^ (long)1290261826)) /* "Legit Mine" */, 0r.b((int)((long)-3274005 ^ (long)3244046), (int)((long)1624825539 ^ (long)1624810642)) /* "Auto Mine won't be able to recognize ores that it can't see" */);
        object.2(0l.0((Settings.Setting<Integer>)((Settings)j2).legitMineYLevel, 0r.b((int)((long)1585411327 ^ (long)-1585381864), (int)((long)-1119682416 ^ (long)1119652317)) /* "Y Level" */, 0r.b((int)((long)-1054543870 ^ (long)1054571240), (int)((long)358481065 ^ (long)-358462991)) /* "The Y level that legit mine will target" */, (int)((long)-1191597396 ^ (long)-1191597399), (int)((long)-979054680 ^ (long)-979054640)));
        object.2(0l.0((Settings.Setting<Boolean>)((Settings)j2).legitMineIncludeDiagonals, 0r.b((int)((long)-585909108 ^ (long)585905783), (int)((long)122818825 ^ (long)-122830281)) /* "Include Diagonals" */, 0r.b((int)((long)-1956091770 ^ (long)1956110954), (int)((long)-1336359283 ^ (long)-1336347470)) /* "Legit mine will recognize ores that are diagonal to the target block" */));
        this.2.2((8z)object);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0r.\u2004\u200d\u200d\u200d\u200f;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)1966491475 ^ (long)1966491506)];
            if (var7) break block23;
            var3_2 = (int)((long)-671286752 ^ (long)-671286752);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u0d1f\u252c\u360f\u3e84\u0d59\u25f3\u36cd\u3e13\u0dff\u2519\u3671\u3e47\u0d6d\u250c\u360b\u3e8b\u0d8f\u2594\u36a4\u3ed1\u0d4c\u25a2\u3660\u3ea7\u0d47\u259a\u36b9\u3ead\u0d77\u258d\u3679\u3e8b\u0dca\u25d2\u36d4\u3e73\u0db4\u25f3\u36d6\u3e1f\u0d69\u257b\u36cd\u3e1f\u0ddb\u252a\u3682\u3ebd\u0d54\u2519\u364e\u3e44\u0d29\u25d2\u3651\u3e4c\u0dc6\u2509\u3603\u3ea5\u0d2a\u2514\u3698\u3ec8\u0d06\u2592\u36c5\u3ee1\u0d8f\u2578\u3630\u3e72\u0d77\u254f\u3609\u3ecf\u0db0\u25e2\u365a\u3ea0\u0dd6\u2577\u3646\u3e86\u0df0\u251b\u366a\u3ece\u0d1a\u2557\u36ab\u3ec0\u0dbc\u2565\u3673\u3eac\u0d8e\u2516\u36d6\u3e37\u0da7\u2537\u3615\u3ece\u0d46\u256a\u364e\u3e7c\u0d7a\u2512\u3642\u3e59\u0d78\u254d\u3661\u3e3c\u0d79\u252f\u3679\u3e1f\u0dc7\u2570\u36c4\u3eaa\u0d85\u252f\u36e5\u3e63\u0d5b\u25bd\u36c5\u3e70\u0d4c\u25d0\u3689\u3e92\u0de8\u2500\u3649\u3e1b\u0d4f\u2504\u3653\u3e32\u0d6f\u2529\u36bc\u3ef9\u0dd7\u252a\u362b\u3ee2\u0d4a\u25e4\u3600\u3ef6\u0d28\u2524\u36e7\u3e13\u0dcb\u25cf\u36f8\u3e0a\u0d72\u2520\u367d\u3e0c\u0d24\u258c\u366b\u3ed8\u0da8\u25e3\u363f\u3e00\u0d5f\u25ad\u3624\u3e41\u0d18\u2504\u3685\u3e49\u0d2f\u2537\u364a\u3ee0\u0d57\u2506\u36b0\u3ea7\u0dca\u25f0\u3622\u3e5d\u0dad\u2568\u36cb\u3ef1\u0d50\u2537\u360f\u3e1c\u0dae\u25bc\u368f\u3e65\u0d52\u2533\u3651\u3e5f\u0db9\u2503\u3647\u3e80\u0d1c\u25bb\u3626\u3ed7\u0d6c\u25e0\u36c2\u3e85\u0d93\u259e\u363b\u3e38\u0d86\u2563\u3624\u3e60\u0d7e\u2568\u368b\u3e8a\u0d3c\u2506\u3607\u3e28\u0dc6\u2505\u36e3\u3e89\u0d3b\u2565\u3644\u3e2c\u0d15\u25e8\u3646\u3e26\u0de3\u2552\u3694\u3e43\u0dc2\u25a8\u3610\u3e70\u0dfd\u2513\u3652\u3ee6\u0dd0\u25d2\u36a3\u3ea1\u0d08\u253e\u365b\u3ead\u0d39\u2585\u36fc\u3ec5\u0dd1\u25c2\u3674\u3e96\u0db2\u255a\u36b8\u3e6e\u0dc6\u254c\u362c\u3e3c\u0d79\u25a0\u3646\u3e11\u0d53\u25e9\u3646\u3e91\u0d59\u25a5\u3633\u3e7a\u0d75\u25d8\u3654\u3e20\u0d95\u25b7\u3658\u3eda\u0d39\u252c\u36e5\u3e4c\u0d9d\u2565\u36b4\u3e91\u0de9\u2530\u361a\u3e6e\u0d89\u2597\u3646\u3e97\u0de4\u2590\u36af\u3e17\u0dbe\u2594\u364a\u3e9a\u0d63\u2512\u36c8\u3e6f\u0df4\u25b9\u360f\u3eb2\u0dbe\u25f3\u3680\u3e82\u0ddc\u25ed\u36d9\u3eb4\u0db7\u2553\u3605\u3e3a\u0d86\u256e\u3623\u3e03\u0df9\u256f\u36e6\u3e6f\u0d87\u2574\u3651\u3ec6\u0dfb\u2567\u3667\u3e8b\u0d05\u2571\u3674\u3ea5\u0d57\u25b9\u36a4\u3ea1\u0da4\u253d\u36b5\u3ebb\u0dc1\u2569\u3659\u3ec2\u0d1d\u2577\u36af\u3eed\u0d88\u25ca\u3669\u3ea6\u0d50\u2531\u36b4\u3ec7\u0df7\u2575\u360c\u3ef2\u0de9\u25d2\u36af\u3eb6\u0dbc\u250e\u3658\u3ee3\u0ddd\u25a2\u36ef\u3e7e\u0ddb\u257e\u36ed\u3e9b\u0d18\u25f7\u3637\u3e43\u0de2\u25ad\u363b\u3ed5\u0da2\u25c1\u3634\u3e1d\u0d8b\u259b\u36b9\u3e9a\u0d05\u25da\u366b\u3edd\u0d99\u2522\u360e\u3e1e\u0d7e\u25f4\u368c\u3e2f\u0d24\u257b\u36b2\u3ecf\u0d5a\u257e\u3657\u3e2e\u0df8\u25aa\u3668\u3e11\u0dc3\u25b4\u369d\u3e93\u0d9b\u254f\u3623\u3ed5\u0de2\u253a\u36d5\u3ec4\u0d71\u25ed\u366e\u3e14\u0d02\u25e2\u3663\u3edc\u0da7\u25ec\u3691\u3e6d\u0d7a\u2511\u3686\u3ed1\u0dbf\u2554\u36a6\u3e60\u0d8e\u25bf\u364c\u3e68\u0d18\u2594\u366d\u3efd\u0d6a\u25e6\u36c5\u3ed1\u0dbf\u251b\u3661\u3ea1\u0df5\u2574\u36b4\u3e96\u0d31\u25d3\u364d\u3e6a\u0d49\u2581\u360e\u3e36\u0d1d\u2548\u3613\u3e0d\u0d34\u25f2\u369f\u3eb7\u0d5d\u25d3\u3623\u3e95\u0d50\u2540\u36e0\u3e20\u0d67\u25dc\u3622\u3e10\u0de6\u2568\u3604\u3e0a\u0d2c\u2526\u3654\u3e4b\u0dfb\u2523\u36f3\u3e41\u0df5\u255e\u36df\u3ecf\u0d5f\u25c7\u3669\u3e1d\u0d61\u2575\u368a\u3eb1\u0d8f\u2539\u3603\u3e72\u0d95\u2555\u3694\u3ea4\u0d9a\u2558\u363e\u3e6f\u0df1\u25f5\u3652\u3ec3\u0dc9\u25e6\u3616\u3e85\u0d1e\u2544\u3642\u3e25\u0def\u25fc\u363c\u3eff\u0d91\u253b\u36d2\u3eb3\u0d6a\u2549\u36a0\u3ef7\u0d9f\u2575", 1235823578);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1870986928 ^ (long)-1870986921);
            if (var7) break block23;
            var0_6 = (int)((long)2066457163 ^ (long)-2066457164);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1013232671 ^ (long)-1013232664);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-239414444 ^ (long)239414443);
                    if (0r.\u2004\u200d\u200d\u200d\u200f) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0r.\u2004\u200d\u200d\u200d\u200f) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u09d4\u21fc\u3278\u3a46\u09f3\u21e5\u322c\u3af6\u098f\u211d\u328b\u3ade\u09a6\u21f9\u320b\u3a47", 744370098);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-745803314 ^ (long)-745803321);
                            var0_6 = (int)((long)1820908843 ^ (long)-1820908844);
                            while (true) {
                                v0 = (int)((long)1831682131 ^ (long)1831682074);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)1956799945 ^ (long)1956799945);
                                if (!0r.\u2004\u200d\u200d\u200d\u200f) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0r.\u2004\u200d\u200d\u200d\u200f) ** continue;
                                throw null;
                            }
                            0r.d = var5_1;
                            0r.e = new String[(int)((long)-452199835 ^ (long)-452199868)];
                            if (!0r.\u2004\u200d\u200d\u200d\u200f) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)1347510281 ^ (long)1347510281);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1489990447 ^ (long)1489990446)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1381383568 ^ (long)-1381383561)) {
                                case 0: {
                                    v15 = (int)((long)191783074 ^ (long)191783089);
                                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)88068894 ^ (long)88068940);
                                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-806113185 ^ (long)-806113218);
                                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)1926213293 ^ (long)1926213370);
                                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)491081668 ^ (long)491081618);
                                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)828375909 ^ (long)828375928);
                                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)-1647849439 ^ (long)-1647849464);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0r.\u2004\u200d\u200d\u200d\u200f);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 8() {
        block3: {
            block2: {
                boolean bl = \u2004\u200d\u200d\u200d\u200f;
                if (bl || bl) break block2;
                BaritoneAPI.getProvider().getPrimaryBaritone().getMineProcess().cancel();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0r.\u2004\u200d\u200d\u200d\u200f;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1953234421 ^ (long)-1953204462)) & (int)((long)793368421 ^ (long)793323674);
            if (var9_2) ** GOTO lbl-1000
            if (0r.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0r.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)213245151 ^ (long)213245151)] & (int)((long)1994274414 ^ (long)1994274449)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)573133992 ^ (long)573133826);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1007455720 ^ (long)-1007455541);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1351004080 ^ (long)1351003909);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1366672509 ^ (long)-1366672436);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)544736640 ^ (long)544736628);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1239770328 ^ (long)1239770136);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-103917086 ^ (long)-103917076);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-377731637 ^ (long)-377731772);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-1119088679 ^ (long)-1119088893);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-1816017043 ^ (long)-1816016903);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-2009077755 ^ (long)-2009077743);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)976605410 ^ (long)976605424);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1946143795 ^ (long)-1946143802);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)1364970604 ^ (long)1364970738);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)186668536 ^ (long)186668357);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1164565908 ^ (long)1164565967);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-2055732138 ^ (long)-2055732215);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)966856252 ^ (long)966856234);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-949840195 ^ (long)-949840226);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)1807428782 ^ (long)1807428806);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-190310005 ^ (long)-190310014);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)70255183 ^ (long)70255229);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-667153850 ^ (long)-667153792);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1791235894 ^ (long)1791236050);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-697626561 ^ (long)-697626555);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)270027970 ^ (long)270027967);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1458616499 ^ (long)1458616545);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)821815480 ^ (long)821815321);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-2106662798 ^ (long)-2106662878);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)1510597624 ^ (long)1510597564);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-328403193 ^ (long)-328402948);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-938936974 ^ (long)-938936867);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1734938001 ^ (long)1734938110);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)135936545 ^ (long)135936612);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-450944454 ^ (long)-450944501);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)1094497712 ^ (long)1094497667);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1857561626 ^ (long)-1857561608);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1035629294 ^ (long)-1035629096);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1830190685 ^ (long)-1830190838);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-47801820 ^ (long)-47801764);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1601296405 ^ (long)1601296456);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)2046172229 ^ (long)2046172174);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-738053228 ^ (long)-738053261);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)170877790 ^ (long)170877919);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1843090065 ^ (long)1843090172);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-808689649 ^ (long)-808689654);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)80675774 ^ (long)80675769);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-369822684 ^ (long)-369822514);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-110230107 ^ (long)-110230194);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)216444132 ^ (long)216444040);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-1146393047 ^ (long)-1146392994);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-178256353 ^ (long)-178256251);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-843490298 ^ (long)-843490250);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1419631062 ^ (long)-1419631047);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)1292903231 ^ (long)1292903393);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-1107213346 ^ (long)-1107213359);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)652959930 ^ (long)652959966);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-142433030 ^ (long)-142433265);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1258473485 ^ (long)1258473517);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1659320104 ^ (long)1659320095);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)809754332 ^ (long)809754150);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1409371428 ^ (long)-1409371460);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)874005747 ^ (long)874005684);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1283924769 ^ (long)-1283924915);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-138756431 ^ (long)-138756481);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1909031777 ^ (long)1909031919);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-230808940 ^ (long)-230808851);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1231031112 ^ (long)1231031216);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1278180290 ^ (long)-1278180331);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1191294440 ^ (long)1191294396);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-794147591 ^ (long)-794147834);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)-1801657795 ^ (long)-1801657784);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-153511065 ^ (long)-153510941);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)1212136498 ^ (long)1212136645);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)465879820 ^ (long)465880027);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)354982552 ^ (long)354982454);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)2139890523 ^ (long)2139890464);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)649258156 ^ (long)649258062);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1388371595 ^ (long)1388371482);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)409072596 ^ (long)409072407);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)1621557551 ^ (long)1621557562);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)2138462214 ^ (long)2138462214);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)-735343424 ^ (long)-735343517);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-1415578922 ^ (long)-1415579035);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)937171521 ^ (long)937171485);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-202099030 ^ (long)-202099193);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1744362450 ^ (long)-1744362371);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1317875689 ^ (long)-1317875483);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1564742875 ^ (long)-1564742828);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)1402647831 ^ (long)1402648028);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)381102116 ^ (long)381102091);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)2026629597 ^ (long)2026629436);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-167097904 ^ (long)-167097920);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)743157882 ^ (long)743157777);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1378308277 ^ (long)1378308206);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-448718357 ^ (long)-448718482);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1700297727 ^ (long)1700297688);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-2139281020 ^ (long)-2139281016);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-594029056 ^ (long)-594028912);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-534682680 ^ (long)-534682801);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1212167334 ^ (long)1212167178);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1514457043 ^ (long)1514456839);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1104402912 ^ (long)1104402774);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-634589336 ^ (long)-634589285);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)2033283643 ^ (long)2033283694);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)564710333 ^ (long)564710273);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)2118524563 ^ (long)2118524517);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1762566436 ^ (long)1762566624);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-315408471 ^ (long)-315408496);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-371471906 ^ (long)-371472020);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)916644300 ^ (long)916644130);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1159877944 ^ (long)-1159878011);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-1684970175 ^ (long)-1684970022);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1347779670 ^ (long)1347779823);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-562936917 ^ (long)-562936974);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-752631951 ^ (long)-752632005);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-367776511 ^ (long)-367776446);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)817016464 ^ (long)817016409);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1489007440 ^ (long)1489007577);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-773147552 ^ (long)-773147411);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-70294562 ^ (long)-70294529);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-183320730 ^ (long)-183320658);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1501765195 ^ (long)1501765179);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)2142074117 ^ (long)2142074357);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-367333780 ^ (long)-367333838);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)1044060941 ^ (long)1044061062);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)475967759 ^ (long)475967919);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)136731853 ^ (long)136731818);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1061541194 ^ (long)1061541364);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1837886152 ^ (long)1837886064);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1978772189 ^ (long)1978772142);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)307958006 ^ (long)307957776);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)943527163 ^ (long)943527122);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1041421531 ^ (long)1041421378);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1138383333 ^ (long)-1138383297);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)227145188 ^ (long)227145079);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)763127468 ^ (long)763127533);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1642188510 ^ (long)-1642188320);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-306555929 ^ (long)-306555984);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)-1137681994 ^ (long)-1137681975);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)950134426 ^ (long)950134348);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1681053289 ^ (long)-1681053233);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-1379057038 ^ (long)-1379057076);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)1501112962 ^ (long)1501113086);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)-1490050139 ^ (long)-1490050273);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1119922813 ^ (long)-1119922838);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)1713247217 ^ (long)1713247136);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1833550878 ^ (long)1833551033);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)855933429 ^ (long)855933205);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-161877454 ^ (long)-161877491);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1451386314 ^ (long)1451386176);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-2030827840 ^ (long)-2030827813);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)1336237890 ^ (long)1336237932);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-600500962 ^ (long)-600500741);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)1940401855 ^ (long)1940401881);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)241440706 ^ (long)241440626);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-746056121 ^ (long)-746056070);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)147162709 ^ (long)147162749);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1026763766 ^ (long)1026763740);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-1519899468 ^ (long)-1519899631);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-864589026 ^ (long)-864589049);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1307602476 ^ (long)1307602472);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1469338805 ^ (long)1469338843);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)946214186 ^ (long)946214192);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-1438050740 ^ (long)-1438050695);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-954025159 ^ (long)-954025075);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1667292277 ^ (long)1667292211);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-1425768341 ^ (long)-1425768276);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1514193615 ^ (long)1514193484);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-384769811 ^ (long)-384769817);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-44133503 ^ (long)-44133479);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-787033818 ^ (long)-787033655);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1295213720 ^ (long)1295213640);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)1937529899 ^ (long)1937530051);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1598793308 ^ (long)-1598793307);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)-1817654946 ^ (long)-1817654815);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1563294760 ^ (long)-1563294898);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)130534538 ^ (long)130534639);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1685401035 ^ (long)1685401063);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)-1551008989 ^ (long)-1551008960);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)1601736224 ^ (long)1601736380);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)1486263524 ^ (long)1486263429);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)276690915 ^ (long)276690863);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)118390017 ^ (long)118390186);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)2130151331 ^ (long)2130151370);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)23515719 ^ (long)23515655);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1278240606 ^ (long)-1278240620);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-158271303 ^ (long)-158271359);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)382047764 ^ (long)382047977);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)1950005136 ^ (long)1950005008);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-452724195 ^ (long)-452724165);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-230637419 ^ (long)-230637430);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)513101677 ^ (long)513101765);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1268971556 ^ (long)1268971768);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)950494868 ^ (long)950494793);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-434980608 ^ (long)-434980399);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1685197367 ^ (long)1685197457);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1768091890 ^ (long)1768091888);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-193268009 ^ (long)-193268065);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)880628327 ^ (long)880628330);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-115197374 ^ (long)-115197217);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)1057801304 ^ (long)1057801315);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1308628088 ^ (long)-1308628156);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-286482621 ^ (long)-286482476);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1643615493 ^ (long)1643615718);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)1274981462 ^ (long)1274981388);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-704266094 ^ (long)-704266000);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)969199263 ^ (long)969199133);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-2023677488 ^ (long)-2023677688);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)847710709 ^ (long)847710488);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-1616524276 ^ (long)-1616524278);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)0x2339333 ^ (long)36934522);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1870886939 ^ (long)1870887079);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-418228065 ^ (long)-418228125);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)209468266 ^ (long)209468220);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-123463708 ^ (long)-123463887);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)63894352 ^ (long)63894281);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)360687181 ^ (long)360687143);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1276448498 ^ (long)-1276448367);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-430904449 ^ (long)-430904466);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1642133162 ^ (long)1642133224);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1292771278 ^ (long)-1292771104);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)-1081783752 ^ (long)-1081783648);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)260722170 ^ (long)260722135);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1098633794 ^ (long)1098633822);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1087313379 ^ (long)1087313196);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)736830971 ^ (long)736830743);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-363650029 ^ (long)-363649814);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1581386169 ^ (long)1581386140);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)86819985 ^ (long)86819974);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)1029737985 ^ (long)1029738239);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-18623800 ^ (long)-18623991);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-280834156 ^ (long)-280834269);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1253359100 ^ (long)-1253358859);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)1599057883 ^ (long)1599057757);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)77227671 ^ (long)77227571);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-160643579 ^ (long)-160643447);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1077480227 ^ (long)-1077480273);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-275133785 ^ (long)-275133735);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-1236313153 ^ (long)-1236313222);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-1343479302 ^ (long)-1343479360);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)985431425 ^ (long)985431354);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1462033869 ^ (long)1462033851);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1431942134 ^ (long)1431942014);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-769534008 ^ (long)-769534005);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1781169870 ^ (long)1781169914);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-507382814 ^ (long)-507382890);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)2115650143 ^ (long)2115650135);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1495814114 ^ (long)1495814060);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-1325024544 ^ (long)-1325024723);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-2110467933 ^ (long)-2110467967);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)232340554 ^ (long)232340712);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)769177252 ^ (long)769177211);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-168612295 ^ (long)-168612180);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)691542518 ^ (long)691542507);
                    if (!0r.\u2004\u200d\u200d\u200d\u200f) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)2066363995 ^ (long)2066364138);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)994776337 ^ (long)994776558)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)2096531956 ^ (long)2096526859)) >>> (int)((long)1093695615 ^ (long)1093695607)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1781299064 ^ (long)1781299064);
            if (!0r.\u2004\u200d\u200d\u200d\u200f) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1758864286 ^ (long)1758864284);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-2097573662 ^ (long)-2097573663) | var5_6 << (int)((long)316612586 ^ (long)316612591)) ^ var3_4[var7_8]) & (int)((long)646311254 ^ (long)646311337);
                    if (0r.\u2004\u200d\u200d\u200d\u200f) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1042889341 ^ (long)-1042889344) | var6_7 << (int)((long)-240728067 ^ (long)-240728072)) ^ var3_4[var7_8]) & (int)((long)-506279981 ^ (long)-506280148);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0r.e[var2_3] = new String(var3_4).intern();
        }
        return 0r.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u2004\u200d\u200d\u200d\u200f;
                if (bl || bl) break block2;
                djw.a();
                if (bl || bl) break block2;
                this.0.8 = (int)((long)27040556 ^ (long)27040557);
                if (bl || bl) break block2;
                this.0.8();
                if (bl || bl) break block2;
                this.8 = (int)((long)-1069115498 ^ (long)-1069115497);
                if (!bl && !bl) break block3;
            }
            return;
        }
    }
}

