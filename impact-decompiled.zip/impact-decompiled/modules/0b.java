/* ==========================================================================
 * MODULE: New Chunks
 * CATEGORY (inferred): Render
 * DESCRIPTION: Exploit for Spigot servers that highlights newly generated chunks
 * OBFUSCATED CLASS: net.impactclient.0b
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 *  org.lwjgl.opengl.GL11
 *  pw.knx.feather.structures.Color
 *  pw.knx.feather.structures.VBO
 */
package net.impactclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.function.Predicate;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1A;
import net.impactclient.1P;
import net.impactclient.1R;
import net.impactclient.2c;
import net.impactclient.2o;
import net.impactclient.2w$6X;
import net.impactclient.34E;
import net.impactclient.34J;
import net.impactclient.34K;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.49;
import net.impactclient.9b;
import org.lwjgl.opengl.GL11;
import pw.knx.feather.structures.Color;
import pw.knx.feather.structures.VBO;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0b
extends 3X
implements 49 {
    private static final String[] d;
    private 1R 4;
    private 1A 7;
    private VBO 1;
    private 1P 9;
    public static final boolean \u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008;
    private static final String[] e;
    @EventHandler
    private final Listener<2o> 8;

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1711768909 ^ (long)-1711794770)) & (int)((long)-187044310 ^ (long)-187100715);
            if (var9_2) ** GOTO lbl-1000
            if (0b.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0b.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-2121328831 ^ (long)-2121328831)] & (int)((long)-81183597 ^ (long)-81183636)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)64846269 ^ (long)64846210);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)1706070300 ^ (long)1706070482);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)1577372963 ^ (long)1577373005);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)809403065 ^ (long)809402980);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)2096299622 ^ (long)2096299605);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)-1975413527 ^ (long)-1975413734);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1890413630 ^ (long)-1890413593);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)200171383 ^ (long)200171272);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-142037281 ^ (long)-142037352);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1747728646 ^ (long)1747728864);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1837119163 ^ (long)1837119201);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)237517883 ^ (long)237517943);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-1705622551 ^ (long)-1705622577);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-992334414 ^ (long)-992334438);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-1572259614 ^ (long)-1572259799);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)1770283661 ^ (long)1770283548);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1690606902 ^ (long)1690606866);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-1512506690 ^ (long)-1512506733);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)2120041921 ^ (long)2120041925);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-927207109 ^ (long)-927207150);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)2007779731 ^ (long)2007779816);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)304910274 ^ (long)304910249);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)424246147 ^ (long)424246271);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)758096884 ^ (long)758096854);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)960462357 ^ (long)960462447);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1000806652 ^ (long)1000806643);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1211579230 ^ (long)1211579231);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-1828582653 ^ (long)-1828582431);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1415666634 ^ (long)1415666438);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-2137492247 ^ (long)-2137492413);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1186481281 ^ (long)-1186481272);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-345127533 ^ (long)-345127538);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)-993150048 ^ (long)-993150126);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)1067865741 ^ (long)1067865652);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-1939174126 ^ (long)-1939173966);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1500933644 ^ (long)-1500933760);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)1086490251 ^ (long)1086490280);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-1090093160 ^ (long)-1090093259);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-1799756572 ^ (long)-1799756769);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-744832424 ^ (long)-744832464);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)1791578623 ^ (long)1791578468);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1795743361 ^ (long)-1795743410);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)1230868220 ^ (long)1230868086);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)609783996 ^ (long)609783979);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1210976507 ^ (long)1210976336);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)671659558 ^ (long)671659669);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1420205373 ^ (long)1420205513);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)-1557064290 ^ (long)-1557064447);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)394540131 ^ (long)394540202);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-840305771 ^ (long)-840305841);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)-774590231 ^ (long)-774590366);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1795175527 ^ (long)1795175539);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-2119821642 ^ (long)-2119821570);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1801351550 ^ (long)-1801351471);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-2054405989 ^ (long)-2054405914);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)1723615773 ^ (long)1723615904);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)867910278 ^ (long)867910359);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1841961786 ^ (long)1841961745);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1441706987 ^ (long)1441706995);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)1575957426 ^ (long)1575957412);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1740612092 ^ (long)-1740612074);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-2107872072 ^ (long)-2107872212);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-418041979 ^ (long)-418042031);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-43185444 ^ (long)-43185608);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)1638784777 ^ (long)1638784805);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)1491958825 ^ (long)1491958936);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)-1628086255 ^ (long)-1628086020);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)1993076752 ^ (long)1993076863);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1738067531 ^ (long)-1738067513);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)2139409641 ^ (long)2139409570);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-887458966 ^ (long)-887459063);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1713311341 ^ (long)1713311275);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)763394681 ^ (long)763394773);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-1566993082 ^ (long)-1566992954);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)-99134113 ^ (long)-99133975);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-504710114 ^ (long)-504710071);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1336437773 ^ (long)-1336437789);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-795861465 ^ (long)-795861497);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)-1434588481 ^ (long)-1434588427);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)1706799620 ^ (long)1706799731);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1659272301 ^ (long)-1659272303);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-632442033 ^ (long)-632441933);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)306745001 ^ (long)306744942);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)477312599 ^ (long)477312538);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-421814875 ^ (long)-421814941);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)-1317302344 ^ (long)-1317302300);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-432885368 ^ (long)-432885462);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1795241391 ^ (long)-1795241243);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-12120320 ^ (long)-12120146);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)690313042 ^ (long)690313090);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)823266984 ^ (long)823266834);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-175090880 ^ (long)-175090923);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-438103379 ^ (long)-438103449);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)1617851255 ^ (long)1617851150);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1181087759 ^ (long)-1181087820);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-2058664190 ^ (long)-2058664094);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)1088679773 ^ (long)1088679912);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)884927770 ^ (long)884927902);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1833381306 ^ (long)-1833381309);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)1651793116 ^ (long)1651793052);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)-705030665 ^ (long)-705030782);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1413678670 ^ (long)-1413678710);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-1871389748 ^ (long)-1871389867);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)50456849 ^ (long)50456952);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1483283902 ^ (long)1483283799);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)-481905485 ^ (long)-481905644);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1295955811 ^ (long)1295955956);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)983098397 ^ (long)983098563);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)598674463 ^ (long)598674663);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-1415744263 ^ (long)-1415744353);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-865135566 ^ (long)-865135462);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-1548762642 ^ (long)-1548762639);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)439329567 ^ (long)439329766);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1693490083 ^ (long)1693489967);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-721353769 ^ (long)-721353760);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-1464340142 ^ (long)-1464340113);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)167209902 ^ (long)167209904);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)410853461 ^ (long)410853384);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)265667237 ^ (long)265667263);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1444220881 ^ (long)-1444220909);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-2059612099 ^ (long)-2059611973);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)392577097 ^ (long)392577030);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1426150400 ^ (long)1426150610);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-1339722086 ^ (long)-1339722024);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-1029411013 ^ (long)-1029410901);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)245643075 ^ (long)245643259);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1253526922 ^ (long)1253526825);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)590031739 ^ (long)590031740);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)628229694 ^ (long)628229733);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1233554963 ^ (long)1233555018);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-713452694 ^ (long)-713452638);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1671713971 ^ (long)1671713870);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)903301326 ^ (long)903301179);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1224128009 ^ (long)-1224128026);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-191842493 ^ (long)-191842539);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-167917576 ^ (long)-167917714);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1921277484 ^ (long)1921277453);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1888804748 ^ (long)1888804617);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)247321981 ^ (long)247321881);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1445059202 ^ (long)1445059257);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)686148095 ^ (long)686147879);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-2140133783 ^ (long)-2140133795);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-999311823 ^ (long)-999311729);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-573089957 ^ (long)-573089889);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1301476390 ^ (long)1301476456);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1814871906 ^ (long)1814871956);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)365661802 ^ (long)365661780);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1749246706 ^ (long)1749246476);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-220270175 ^ (long)-220270104);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1334149134 ^ (long)1334149227);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)-991228422 ^ (long)-991228534);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)985256564 ^ (long)985256667);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-1432994087 ^ (long)-1432994210);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1348189974 ^ (long)-1348189997);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-404992863 ^ (long)-404992829);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)315842816 ^ (long)315842828);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)61833274 ^ (long)61833296);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)467357486 ^ (long)467357472);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)410279803 ^ (long)410279912);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)217411193 ^ (long)217411087);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)514077918 ^ (long)514077782);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-2047286781 ^ (long)-2047286570);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)1657683779 ^ (long)1657683840);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1997999579 ^ (long)-1997999597);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)1676374111 ^ (long)1676374101);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)866609425 ^ (long)866609540);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1103202216 ^ (long)-1103202172);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)257340903 ^ (long)257340811);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)1705289915 ^ (long)1705289803);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-287092324 ^ (long)-287092311);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1108732939 ^ (long)1108733043);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)28096551 ^ (long)28096686);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)-273337568 ^ (long)-273337543);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1904852309 ^ (long)-1904852411);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)1889915818 ^ (long)1889915867);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)2060426599 ^ (long)2060426715);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-1446866715 ^ (long)-1446866942);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-864469532 ^ (long)-864469699);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-1318011521 ^ (long)-1318011423);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)129912679 ^ (long)129912715);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1281153452 ^ (long)-1281153520);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-807956075 ^ (long)-807956021);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)701424646 ^ (long)701424841);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1826144781 ^ (long)-1826144990);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)800337533 ^ (long)800337566);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)1363427100 ^ (long)1363427087);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1983950503 ^ (long)-1983950502);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)749134705 ^ (long)749134740);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)427827237 ^ (long)427827354);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-1055403698 ^ (long)-1055403601);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-1639955498 ^ (long)-1639955493);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-439436505 ^ (long)-439436511);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)908556503 ^ (long)908556351);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)1346490042 ^ (long)1346489883);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-2103662977 ^ (long)-2103662998);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-2026676818 ^ (long)-2026676938);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)1201978901 ^ (long)1201979045);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)640236029 ^ (long)640235890);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)609649900 ^ (long)609649782);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1909821753 ^ (long)-1909821728);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)593577974 ^ (long)593577847);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)628675261 ^ (long)628675159);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-1608359420 ^ (long)-1608359201);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)1467175804 ^ (long)1467175831);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)49806390 ^ (long)49806340);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-1099077730 ^ (long)-1099077859);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-488672143 ^ (long)-488672080);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-97145310 ^ (long)-97145153);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1075542193 ^ (long)1075542067);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)1039767228 ^ (long)1039767295);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)2072182618 ^ (long)2072182634);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1356083466 ^ (long)-1356083617);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1788279489 ^ (long)1788279474);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)165152374 ^ (long)165152461);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1228166211 ^ (long)1228166178);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)498247203 ^ (long)498247412);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1080727027 ^ (long)1080726962);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)881335260 ^ (long)881335162);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-1438203937 ^ (long)-1438204051);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1702216175 ^ (long)-1702215972);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)595171933 ^ (long)595171979);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1377590541 ^ (long)-1377590541);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1552278854 ^ (long)1552278861);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1718451194 ^ (long)1718451038);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)524908517 ^ (long)524908395);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)1300389344 ^ (long)1300389353);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)408469841 ^ (long)408469934);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1714309882 ^ (long)1714309800);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1691830004 ^ (long)1691829992);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1233482440 ^ (long)-1233482280);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-774713277 ^ (long)-774713308);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)209027348 ^ (long)209027540);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-2141770991 ^ (long)-2141770814);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1093877719 ^ (long)-1093877562);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-1017918233 ^ (long)-1017918341);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)85409572 ^ (long)85409599);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)1071214094 ^ (long)1071214211);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1373698148 ^ (long)1373698294);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1587007889 ^ (long)-1587007827);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-307130813 ^ (long)-307130775);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1665251646 ^ (long)1665251648);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1107031471 ^ (long)-1107031445);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)1963607435 ^ (long)1963607460);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)818574535 ^ (long)818574487);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1672248286 ^ (long)1672248065);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1564921887 ^ (long)-1564921931);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)967268812 ^ (long)967268755);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-684965288 ^ (long)-684965137);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)1278557876 ^ (long)1278557765);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)987271485 ^ (long)987271443);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)1537340744 ^ (long)1537340688);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1778771095 ^ (long)1778771103);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)-116188926 ^ (long)-116188680);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)242545578 ^ (long)242545607);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1070751485 ^ (long)-1070751322);
                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-1297544024 ^ (long)-1297544083);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)-1405108875 ^ (long)-1405108854)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)1607359809 ^ (long)1607377598)) >>> (int)((long)1072717090 ^ (long)1072717098)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1561565004 ^ (long)1561565004);
            if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1515270321 ^ (long)1515270323);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)568169538 ^ (long)568169537) | var5_6 << (int)((long)-1918312384 ^ (long)-1918312379)) ^ var3_4[var7_8]) & (int)((long)-1940250502 ^ (long)-1940250491);
                    if (0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)501636109 ^ (long)501636110) | var6_7 << (int)((long)-1704914693 ^ (long)-1704914690)) ^ var3_4[var7_8]) & (int)((long)1583963955 ^ (long)1583964108);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0b.e[var2_3] = new String(var3_4).intern();
        }
        return 0b.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)902935488 ^ (long)902935499)];
            if (var7) break block23;
            var3_2 = (int)((long)1596527513 ^ (long)1596527513);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\uc7da\uefbc\ufc71\uf449\uc723\uef0e\ufcb0\uf48c\uc724\uefbd\ufc38\uf4c6\uc792\ueffc\ufc6a\uf46e\uc708\ueffa\ufcdf\uf439\uc71d\uefaa\ufc67\uf459\uc78a\uefd4\ufc8c\uf40c\uc70b\uef3c\ufc74\uf486\uc7ea\uef9b\ufc8a\uf4e5\uc724\uef2c\ufcfe\uf4bc\uc751\uefed\ufc64\uf4fe\uc70d\uef4c\ufcc6\uf422\uc706\uef0a\ufc09\uf416\uc72e\uef0e\ufc64\uf465\uc74c\uefe8\ufc31\uf4bb\uc730\uef8c\ufc0c\uf44d\uc7bc\ueffe\ufc70\uf4f3\uc73d\uef66\ufc7f\uf4cb\uc769\ueff1\ufc28\uf475\uc771\uef0d\ufcf4\uf4e0\uc7e3\uef87\ufc6b\uf45b\uc704\uefb9\ufce9\uf462\uc75a\uefd4\ufc4d\uf4ef\uc7e4\uef6e\ufc7c\uf410\uc71c\uefde\ufc64\uf41f\uc74e\uefcf\ufcba\uf43e\uc755\uefe7\ufcb5\uf449\uc783\uefc9\ufc20\uf4cc\uc7e3\uefdb\ufc57\uf4a4\uc7e7\uef66\ufcd1\uf4be\uc71e\uefc4\ufc7d\uf4bb\uc780\uefcd\ufc9c\uf4c9\uc770\uef71\ufc78\uf411\uc7eb\uefdc\ufc55\uf427\uc703\uef33\ufcd8\uf4eb\uc706\uef75\ufc7c\uf4de\uc70a\uefdd\ufc27\uf423\uc762\uef08\ufc1a\uf469\uc76b\uef24\ufcd4\uf4a4\uc742\uefb5\ufc95\uf420\uc728\uefa9\ufc12\uf425\uc764\uef8a\ufcdf\uf400\uc75c\uef08\ufc37\uf46b\uc76e\uef2c\ufc44\uf4c8\uc723\uef6c\ufce9\uf4ef\uc7ab\uefef\ufcdf\uf489\uc74a\uefcf\ufc84\uf40b\uc72f\uef37\ufc4f\uf422\uc7b1\uef76\ufc2a\uf4bd\uc70a\uef36\ufced\uf45c\uc7ac\uef7a\ufcf6\uf441\uc710\uef4b\ufcc6\uf409\uc793\uef4b\ufcbb\uf43e", 277274998);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1685121948 ^ (long)-1685121974);
            if (var7) break block23;
            var0_6 = (int)((long)2077735248 ^ (long)-2077735249);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)-1513819638 ^ (long)-1513819621);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-329990075 ^ (long)329990074);
                    if (0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u1511\u3d5f\u2e22\u266e\u1507\u3dd9\u2ecb\u267f\u15cb\u3d0f\u2eac", 363737973);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)-575021992 ^ (long)-575021987);
                            var0_6 = (int)((long)1822972056 ^ (long)-1822972057);
                            while (true) {
                                v0 = (int)((long)-18266775 ^ (long)-18266781);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1178516192 ^ (long)-1178516192);
                                if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) ** continue;
                                throw null;
                            }
                            0b.d = var5_1;
                            0b.e = new String[(int)((long)2136110450 ^ (long)2136110457)];
                            if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)0x21221313 ^ (long)0x21221313);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)1697397606 ^ (long)1697397607)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-276176109 ^ (long)-276176108)) {
                                case 0: {
                                    v15 = (int)((long)210630696 ^ (long)210630686);
                                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-399526536 ^ (long)-399526551);
                                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-181740142 ^ (long)-181740035);
                                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)-39889688 ^ (long)-39889722);
                                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)-1999966741 ^ (long)-1999966802);
                                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)1657524476 ^ (long)1657524382);
                                    if (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)1936171553 ^ (long)1936171585);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0b.\u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    public 0b() {
        boolean bl = \u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008;
        super(0b.b((int)((long)1441143453 ^ (long)1441166727), (int)((long)1807902437 ^ (long)1807882715)) /* "New Chunks" */, 0b.b((int)((long)-1620909558 ^ (long)-1620931309), (int)((long)-550798054 ^ (long)-550829016)) /* "Exploit for Spigot servers that highlights newly generated chunks" */);
        Object object = Color.fromRGB((float)1.0f, (float)0.0f, (float)0.0f);
        34J j2 = (34E)((34E)((34E)this.0().5(0b.b((int)((long)-776686380 ^ (long)-776676416), (int)((long)259787166 ^ (long)259790324)) /* "Color" */)).7(0b.b((int)((long)-1104402274 ^ (long)-1104394359), (int)((long)1982128231 ^ (long)1982110838)) /* "color" */)).1(0b.b((int)((long)1184805142 ^ (long)1184816654), (int)((long)-1391642605 ^ (long)1391636578)) /* "The new chunk outline color" */);
        ((34E)((34E)((34E)this.0().5(0b.b((int)((long)-776686380 ^ (long)-776676416), (int)((long)259787166 ^ (long)259790324)) /* "Color" */)).7(0b.b((int)((long)-1104402274 ^ (long)-1104394359), (int)((long)1982128231 ^ (long)1982110838)) /* "color" */)).1(0b.b((int)((long)1184805142 ^ (long)1184816654), (int)((long)-1391642605 ^ (long)1391636578)) /* "The new chunk outline color" */)).7 = object;
        this.4 = (1R)j2.5();
        object = Float.valueOf(1.0f);
        j2 = ((34e)((34e)((34e)this.9().5(0b.b((int)((long)762202954 ^ (long)762192991), (int)((long)-1694860520 ^ (long)-1694863329)) /* "Width" */)).7(0b.b((int)((long)-1591075617 ^ (long)-1591053373), (int)((long)-1948968672 ^ (long)1948974147)) /* "width" */)).1(0b.b((int)((long)163205306 ^ (long)163200929), (int)((long)-905211815 ^ (long)-905184693)) /* "The thickness of the outline" */)).3(Float.valueOf(0.01f)).2(Float.valueOf(3.0f));
        ((34e)((34e)((34e)this.9().5(0b.b((int)((long)762202954 ^ (long)762192991), (int)((long)-1694860520 ^ (long)-1694863329)) /* "Width" */)).7(0b.b((int)((long)-1591075617 ^ (long)-1591053373), (int)((long)-1948968672 ^ (long)1948974147)) /* "width" */)).1(0b.b((int)((long)163205306 ^ (long)163200929), (int)((long)-905211815 ^ (long)-905184693)) /* "The thickness of the outline" */)).3(Float.valueOf(0.01f)).2(Float.valueOf(3.0f)).7 = object;
        this.7 = (1A)((34e)j2).5();
        object = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(0b.b((int)((long)523913451 ^ (long)523905013), (int)((long)-1513539522 ^ (long)-1513547154)) /* "Smooth Lines" */)).7(0b.b((int)((long)-877874211 ^ (long)-877863742), (int)((long)1856902611 ^ (long)1856912439)) /* "smooth" */)).1(0b.b((int)((long)-90440462 ^ (long)-90467345), (int)((long)-1236029457 ^ (long)1236037293)) /* "Render the outline with line smoothing enabled" */);
        ((34X)((34X)((34X)this.4().5(0b.b((int)((long)523913451 ^ (long)523905013), (int)((long)-1513539522 ^ (long)-1513547154)) /* "Smooth Lines" */)).7(0b.b((int)((long)-877874211 ^ (long)-877863742), (int)((long)1856902611 ^ (long)1856912439)) /* "smooth" */)).1(0b.b((int)((long)-90440462 ^ (long)-90467345), (int)((long)-1236029457 ^ (long)1236037293)) /* "Render the outline with line smoothing enabled" */)).7 = object;
        this.9 = (1P)((34X)j2).5();
        this.8 = new Listener(set -> {
            boolean bl = \u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008;
            if (bl || bl) return;
            set = 34K.a.0();
            if (set == null) {
                if (bl || bl) return;
                return;
            }
            if (bl) return;
            9b.6((boolean)((long)-1918398240 ^ (long)-1918398239));
            if (bl || bl) return;
            2c c2 = (2c)3.ac();
            if (bl || bl) return;
            RenderSystem.pushMatrix();
            if (bl || bl) return;
            RenderSystem.translated((double)(-c2.getRenderPosX()), (double)(-c2.getRenderPosY()), (double)(-c2.getRenderPosZ()));
            if (bl || bl) return;
            if (!this.9.2) {
                if (bl || bl) return;
                GL11.glDisable((int)((int)((long)2003099511 ^ (long)2003096663)));
                if (bl) return;
            }
            if (bl) return;
            RenderSystem.lineWidth((float)this.7.9);
            if (bl || bl) return;
            RenderSystem.color4f((float)this.4.2.getRed(), (float)this.4.2.getGreen(), (float)this.4.2.getBlue(), (float)1.0f);
            if (bl || bl) return;
            set.forEach(brd2 -> {
                block3: {
                    block2: {
                        boolean bl = \u200f\u2009\u200f\u200d\u2008\u2009\u200c\u2002\u2008;
                        if (bl || bl) break block2;
                        RenderSystem.pushMatrix();
                        if (bl || bl) break block2;
                        RenderSystem.translatef((float)brd2.d(), (float)0.0f, (float)brd2.e());
                        if (bl || bl) break block2;
                        RenderSystem.scalef((float)16.0f, (float)0.0f, (float)16.0f);
                        if (bl || bl) break block2;
                        this.1.bind().draw((int)((long)1742125627 ^ (long)1742125625)).unbind();
                        if (bl || bl) break block2;
                        RenderSystem.popMatrix();
                        if (!bl && !bl) break block3;
                    }
                    return;
                }
            });
            if (bl || bl) return;
            RenderSystem.popMatrix();
            if (bl || bl) return;
            9b.6((boolean)((long)-974425568 ^ (long)-974425568));
            if (!bl && !bl) return;
        }, new Predicate[(int)((long)-1343474425 ^ (long)-1343474425)]);
        this.1 = new VBO();
        float[] fArray = new float[(int)((long)-1229091241 ^ (long)-1229091237)];
        fArray[(int)((long)-692580058 ^ (long)-692580058)] = 0.0f;
        fArray[(int)((long)316981590 ^ (long)316981591)] = 0.0f;
        fArray[(int)((long)1312185 ^ (long)1312187)] = 0.0f;
        fArray[(int)((long)-88062332 ^ (long)-88062329)] = 0.0f;
        fArray[(int)((long)1858608546 ^ (long)1858608550)] = 0.0f;
        fArray[(int)((long)1764529657 ^ (long)1764529660)] = 1.0f;
        fArray[(int)((long)-1902230792 ^ (long)-1902230786)] = 1.0f;
        fArray[(int)((long)918254388 ^ (long)918254387)] = 0.0f;
        fArray[(int)((long)1286210220 ^ (long)1286210212)] = 1.0f;
        fArray[(int)((long)-286654881 ^ (long)-286654890)] = 1.0f;
        fArray[(int)((long)371692771 ^ (long)371692777)] = 0.0f;
        fArray[(int)((long)1500284384 ^ (long)1500284395)] = 0.0f;
        this.1.compile(fArray);
    }
}

