/* ==========================================================================
 * MODULE: Auto Jump
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Automatically jump
 * OBFUSCATED CLASS: net.impactclient.0Y
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.zero.alpine.event.EventState
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import me.zero.alpine.event.EventState;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.3X;
import net.impactclient.4f;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0Y
extends 3X
implements 34B {
    private static final String[] e;
    public static final boolean \u200c\u200d\u2008\u2000;
    private static final String[] d;
    @EventHandler
    private final Listener<4f> 6;

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                var7 = 0Y.\u200c\u200d\u2008\u2000;
                if (!var7) break block15;
                break block16;
            }
            var5_1 = new String[(int)((long)1541886216 ^ (long)1541886218)];
            if (var7) break block16;
            var3_2 = (int)((long)-1654479437 ^ (long)-1654479437);
            if (var7) break block16;
            var2_3 = 2w$6X.KAOZ("\u1c11\u349b\u27d5\u2f8e\u1cfd\u3417\u2706\u2f12\u1c37\u3408\u27c6\u2f07\u1cd3\u3478\u278c\u2f87\u1c31\u342f\u271f\u2fc1\u1cde\u34f6\u27c3\u2f1c\u1ccd\u34fc\u2719\u2f7d", -2011546957);
            var4_4 = var2_3.length();
            if (var7) break block16;
            var1_5 = (int)((long)-545870930 ^ (long)-545870937);
            if (var7) break block16;
            var0_6 = (int)((long)-1207942331 ^ (long)1207942330);
            if (var7) break block16;
            block8: while (!var7) {
                v0 = ++var0_6;
                v1 = (int)((long)-1017588339 ^ (long)1017588338);
                if (0Y.\u200c\u200d\u2008\u2000) {
                    throw null;
                    while (true) {
                        var5_1[var3_2++] = new String(v2).intern();
                        if ((var0_6 += var1_5) < var4_4) {
                            var1_5 = var2_3.charAt(var0_6);
                            if (!0Y.\u200c\u200d\u2008\u2000) continue block8;
                            throw null;
                        }
                        0Y.d = var5_1;
                        0Y.e = new String[(int)((long)1048943883 ^ (long)1048943881)];
                        if (!0Y.\u200c\u200d\u2008\u2000) break block8;
                        throw null;
                    }
                }
                v3 = var2_3.substring(v0, v0 + var1_5).toCharArray();
                v4 = v3.length;
                var6_7 = (int)((long)2088219224 ^ (long)2088219224);
                v5 = (int)((long)78991487 ^ (long)78991427);
                v6 = v3;
                v7 = v4;
                if (v4 > (int)((long)1877252256 ^ (long)1877252257)) ** GOTO lbl87
                do {
                    block14: {
                        v8 = v5;
                        v6 = v6;
                        v9 = v6;
                        v10 = v5;
                        v11 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-1502180947 ^ (long)-1502180950)) {
                                case 0: {
                                    v12 = (int)((long)-40452135 ^ (long)-40452148);
                                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                                    throw null;
                                }
                                case 1: {
                                    v12 = (int)((long)-575926795 ^ (long)-575926895);
                                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                                    throw null;
                                }
                                case 2: {
                                    v12 = (int)((long)-2137054861 ^ (long)-2137054886);
                                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                                    throw null;
                                }
                                case 3: {
                                    v12 = (int)((long)516355593 ^ (long)516355654);
                                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                                    throw null;
                                }
                                case 4: {
                                    v12 = (int)((long)-77069448 ^ (long)-77069475);
                                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                                    throw null;
                                }
                                case 5: {
                                    v12 = (int)((long)1789875424 ^ (long)1789875432);
                                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                                    throw null;
                                }
                                default: {
                                    v12 = (int)((long)53949533 ^ (long)53949552);
                                }
                            }
                            v9[v11] = (char)(v9[v11] ^ (v10 ^ v12));
                            ++var6_7;
                            v5 = v8;
                            if (v8 != 0) break block14;
                            v8 = v5;
                            v6 = v6;
                            v11 = v5;
                            v9 = v6;
                            v10 = v5;
                        } while (!0Y.\u200c\u200d\u2008\u2000);
                        throw null;
                    }
                    v2 = v6;
                    v7 = v7;
                } while (v7 > var6_7);
                if (!0Y.\u200c\u200d\u2008\u2000) ** continue;
                throw null;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0Y.\u200c\u200d\u2008\u2000;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)1521924656 ^ (long)-1521911319)) & (int)((long)-827801180 ^ (long)-827834789);
            if (var9_2) ** GOTO lbl-1000
            if (0Y.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0Y.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-1952463804 ^ (long)-1952463804)] & (int)((long)1578581354 ^ (long)1578581397)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-2049033674 ^ (long)-2049033560);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-156349270 ^ (long)-156349437);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)15404168 ^ (long)15404245);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)1356478310 ^ (long)1356478227);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-398217111 ^ (long)-398217141);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1284696678 ^ (long)1284696794);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1381315252 ^ (long)1381315126);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-904809787 ^ (long)-904809887);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)898733925 ^ (long)898733921);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)1198539567 ^ (long)1198539636);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1320107334 ^ (long)-1320107421);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1554930148 ^ (long)-1554930045);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)-797725313 ^ (long)-797725305);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)708239180 ^ (long)708239140);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-544330087 ^ (long)-544330182);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-877460276 ^ (long)-877460249);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-1678414709 ^ (long)-1678414844);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)1078124913 ^ (long)1078124982);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)-1132329930 ^ (long)-1132329797);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1300936194 ^ (long)-1300936323);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)832956443 ^ (long)832956635);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)420802091 ^ (long)420802171);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)1962995225 ^ (long)1962995388);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)1060900636 ^ (long)1060900727);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)-774893931 ^ (long)-774893925);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)1500545867 ^ (long)1500545916);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)1393017677 ^ (long)1393017625);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-161201562 ^ (long)-161201428);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)1440230869 ^ (long)1440230911);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)915338076 ^ (long)915337988);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)-1798457337 ^ (long)-1798457248);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1862267585 ^ (long)1862267637);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1892935738 ^ (long)1892935683);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)-644352976 ^ (long)-644353009);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)1979512713 ^ (long)1979512699);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-2058133911 ^ (long)-2058134012);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)2011189939 ^ (long)2011189956);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)998992569 ^ (long)998992403);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-356260400 ^ (long)-356260534);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)1882911240 ^ (long)1882911352);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)313873439 ^ (long)313873637);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-504320486 ^ (long)-504320315);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)854137793 ^ (long)854137604);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)45590296 ^ (long)45590501);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1144477754 ^ (long)1144477950);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)1266496109 ^ (long)1266496141);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)328336760 ^ (long)328336676);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)143342123 ^ (long)143342208);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1011205041 ^ (long)-1011204908);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-967619194 ^ (long)-967619108);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1398617104 ^ (long)1398617170);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)-1028911651 ^ (long)-1028911758);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)2086591075 ^ (long)2086591108);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)-1736262001 ^ (long)-1736262104);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)935762320 ^ (long)935762387);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)151818930 ^ (long)151818807);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-901766076 ^ (long)-901765988);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)1320936667 ^ (long)1320936702);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)567711787 ^ (long)567711847);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-356667915 ^ (long)-356668016);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1297306299 ^ (long)1297306305);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)1838766391 ^ (long)1838766404);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-874008478 ^ (long)-874008380);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-38559636 ^ (long)-38559676);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-1264448215 ^ (long)-1264448194);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)705475146 ^ (long)705475266);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1303793747 ^ (long)1303793795);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)869142758 ^ (long)869142533);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-1620064246 ^ (long)-1620064109);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-122894885 ^ (long)-122894935);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1283394366 ^ (long)-1283394378);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)921783381 ^ (long)921783508);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-948797105 ^ (long)-948797097);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-667689422 ^ (long)-667689302);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1011736258 ^ (long)1011736285);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)1712228573 ^ (long)1712228576);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)1907337076 ^ (long)1907337145);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1881049269 ^ (long)1881049231);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1918691376 ^ (long)1918691407);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)-1235754333 ^ (long)-1235754303);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-459948806 ^ (long)-459948811);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-307895174 ^ (long)-307895185);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)88506105 ^ (long)88505893);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)-168524134 ^ (long)-168524175);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-2023147254 ^ (long)-2023147181);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)687776500 ^ (long)687776368);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-721699046 ^ (long)-721698955);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)1951521652 ^ (long)1951521652);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1669430323 ^ (long)-1669430328);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)2129764580 ^ (long)2129764358);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)1876991786 ^ (long)1876991825);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1886434873 ^ (long)-1886434821);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1748792758 ^ (long)-1748792696);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1973964131 ^ (long)-1973964254);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1645993104 ^ (long)1645993056);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)1489571890 ^ (long)1489571926);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)501709256 ^ (long)501709209);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1220372418 ^ (long)1220372411);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1933393416 ^ (long)-1933393644);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-1478133431 ^ (long)-1478133432);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)502441927 ^ (long)502441889);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1775094375 ^ (long)-1775094445);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)-317497007 ^ (long)-317497068);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-1684407203 ^ (long)-1684407068);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1757047773 ^ (long)1757047804);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)489727556 ^ (long)489727672);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-146895413 ^ (long)-146895541);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)-885347505 ^ (long)-885347555);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)-1082949773 ^ (long)-1082949813);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-289381092 ^ (long)-289381089);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-476939639 ^ (long)-476939629);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)244609346 ^ (long)244609462);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)343269901 ^ (long)343269899);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)2004877110 ^ (long)2004877131);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-255336262 ^ (long)-255336204);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)-912176503 ^ (long)-912176556);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)527065795 ^ (long)527065845);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-52549913 ^ (long)-52549974);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1292580263 ^ (long)1292580282);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)77355053 ^ (long)77355251);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)298406554 ^ (long)298406651);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)-1839607357 ^ (long)-1839607471);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)1964269011 ^ (long)1964268952);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-507942700 ^ (long)-507942830);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)-322130548 ^ (long)-322130686);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)336064459 ^ (long)336064292);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1879505554 ^ (long)1879505585);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-1914190875 ^ (long)-1914191060);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1400740109 ^ (long)1400740277);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-911317535 ^ (long)-911317567);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-773601019 ^ (long)-773600957);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1209879889 ^ (long)1209879914);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1079938962 ^ (long)-1079938886);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-361865939 ^ (long)-361865924);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-1427263567 ^ (long)-1427263638);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-1795636230 ^ (long)-1795636471);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-464886421 ^ (long)-464886505);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)-1667715266 ^ (long)-1667715256);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)1802780566 ^ (long)1802780648);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)168865946 ^ (long)168865884);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1605962146 ^ (long)-1605962071);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-726388061 ^ (long)-726388108);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1281823482 ^ (long)1281823480);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)815287923 ^ (long)815287938);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)223558042 ^ (long)223557927);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1450776580 ^ (long)1450776676);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1469676165 ^ (long)-1469676158);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)1299490024 ^ (long)1299489945);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)1378825846 ^ (long)1378825799);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)1087011392 ^ (long)1087011536);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1326918820 ^ (long)1326918892);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1190027277 ^ (long)-1190027491);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-289319487 ^ (long)-289319464);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)1947416972 ^ (long)1947416978);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)522772723 ^ (long)522772692);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1242269263 ^ (long)1242269286);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-468914964 ^ (long)-468915187);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-692312380 ^ (long)-692312532);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)1520798200 ^ (long)1520797973);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)-177546951 ^ (long)-177546797);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)-746935692 ^ (long)-746935678);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)-1790110297 ^ (long)-1790110263);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1576657441 ^ (long)-1576657515);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)1080555481 ^ (long)1080555290);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)-114632636 ^ (long)-114632499);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-1149366396 ^ (long)-1149366317);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)-1904447291 ^ (long)-1904447356);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)-736168905 ^ (long)-736168735);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)414056150 ^ (long)414056034);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-1725111289 ^ (long)-1725111275);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)1375118276 ^ (long)1375118102);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-610013380 ^ (long)-610013421);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1963775280 ^ (long)1963775268);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-720121668 ^ (long)-720121714);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-1833409357 ^ (long)-1833409306);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)1145859128 ^ (long)1145859213);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)309510021 ^ (long)309510107);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-854008908 ^ (long)-854008867);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1861757541 ^ (long)1861757507);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)914372058 ^ (long)914372079);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1190389817 ^ (long)-1190389932);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)856193209 ^ (long)856193142);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-1391713467 ^ (long)-1391713395);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)827415263 ^ (long)827415168);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1001348901 ^ (long)1001348909);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)-1002269753 ^ (long)-1002269703);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)1334508141 ^ (long)1334508039);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-1943405664 ^ (long)-1943405716);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1688837914 ^ (long)1688838022);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)988756922 ^ (long)988756763);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-71093024 ^ (long)-71093069);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)-1810781246 ^ (long)-1810781310);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-970526799 ^ (long)-970526970);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-1143015628 ^ (long)-1143015477);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)482887051 ^ (long)482887087);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)-333929395 ^ (long)-333929304);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)-927803491 ^ (long)-927803519);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1337286742 ^ (long)1337286851);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-1648613871 ^ (long)-1648613728);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1276463133 ^ (long)-1276463115);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)499108501 ^ (long)499108382);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-37353309 ^ (long)-37353456);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)918414601 ^ (long)918414770);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)199045219 ^ (long)199045258);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1132710816 ^ (long)1132710835);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)800820957 ^ (long)800820812);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-250055621 ^ (long)-250055455);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)394996386 ^ (long)394996393);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1221364056 ^ (long)1221364115);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)907797201 ^ (long)907797181);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)1226454649 ^ (long)1226454756);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1458008685 ^ (long)-1458008766);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)882800039 ^ (long)882799883);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1117904074 ^ (long)-1117904068);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)1751617679 ^ (long)1751617643);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)341892303 ^ (long)341892223);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)244273419 ^ (long)244273648);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)-1102009153 ^ (long)-1102009124);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)1490102564 ^ (long)1490102569);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)162128709 ^ (long)162128725);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)-1063881158 ^ (long)-1063881150);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1714952688 ^ (long)1714952470);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)904998042 ^ (long)904998058);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)392216363 ^ (long)392216574);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)-694788168 ^ (long)-694788275);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-476701512 ^ (long)-476701649);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)-42570629 ^ (long)-42570666);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)1767993611 ^ (long)1767993771);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1612257182 ^ (long)1612257034);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1438911549 ^ (long)-1438911637);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-89934313 ^ (long)-89934155);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-2048745522 ^ (long)-2048745728);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)262081591 ^ (long)262081561);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1999781869 ^ (long)-1999781715);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)411317471 ^ (long)411317403);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)465948590 ^ (long)465948647);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)972839339 ^ (long)972839344);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-1574909792 ^ (long)-1574909713);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-1437730074 ^ (long)-1437730070);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)88785785 ^ (long)88785749);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)-811309472 ^ (long)-811309529);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1809375147 ^ (long)-1809375150);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-48172235 ^ (long)-48172058);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)-595493530 ^ (long)-595493412);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)877477243 ^ (long)877477325);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-1435251736 ^ (long)-1435251842);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)41562361 ^ (long)41562199);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-2083365841 ^ (long)-2083365758);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-715534965 ^ (long)-715535047);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1764457769 ^ (long)1764457760);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-118650273 ^ (long)-118650210);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)875707063 ^ (long)875707105);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1534946819 ^ (long)1534946948);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-929742662 ^ (long)-929742794);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1269423864 ^ (long)-1269423626);
                    if (!0Y.\u200c\u200d\u2008\u2000) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)-926433002 ^ (long)-926432987);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1880688580 ^ (long)1880688443)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-744092143 ^ (long)-744033810)) >>> (int)((long)1415164053 ^ (long)1415164061)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)1394852038 ^ (long)1394852038);
            if (!0Y.\u200c\u200d\u2008\u2000) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)695017795 ^ (long)695017793);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)1443924033 ^ (long)1443924034) | var5_6 << (int)((long)214976221 ^ (long)214976216)) ^ var3_4[var7_8]) & (int)((long)-793829739 ^ (long)-793829782);
                    if (0Y.\u200c\u200d\u2008\u2000) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-1498316097 ^ (long)-1498316100) | var6_7 << (int)((long)396868381 ^ (long)396868376)) ^ var3_4[var7_8]) & (int)((long)1164409375 ^ (long)1164409568);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0Y.e[var2_3] = new String(var3_4).intern();
        }
        return 0Y.e[var2_3];
    }

    public 0Y() {
        boolean bl = \u200c\u200d\u2008\u2000;
        super(0Y.b((int)((long)556286140 ^ (long)-556301467), (int)((long)1799060698 ^ (long)-1799053291)) /* "Auto Jump" */, 0Y.b((int)((long)-316399622 ^ (long)316398626), (int)((long)-2051718807 ^ (long)-2051713265)) /* "Automatically jump" */);
        Predicate[] predicateArray = new Predicate[(int)((long)1746008768 ^ (long)1746008769)];
        predicateArray[(int)((long)1729920476 ^ (long)1729920476)] = f -> {
            boolean bl = \u200c\u200d\u2008\u2000;
            if (bl || bl) return true;
            if (f.8 == EventState.POST) {
                if (bl) return true;
                return (int)((long)87307730 ^ (long)87307731) != 0;
            }
            if (!bl) return (int)((long)-1290733644 ^ (long)-1290733644) != 0;
            return true;
        };
        this.6 = new Listener(f -> {
            block4: {
                block2: {
                    boolean bl;
                    block3: {
                        bl = \u200c\u200d\u2008\u2000;
                        if (bl || bl) break block2;
                        if (!0Y.3.s.ao()) break block3;
                        if (bl || bl) break block2;
                        0Y.3.s.dK();
                        if (bl) break block2;
                    }
                    if (!bl) break block4;
                }
                return;
            }
        }, predicateArray);
    }
}

