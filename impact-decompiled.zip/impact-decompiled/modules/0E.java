/* ==========================================================================
 * MODULE: Riding
 * CATEGORY (inferred): Movement
 * DESCRIPTION: Improves horses and some other rideable entities
 * OBFUSCATED CLASS: net.impactclient.0E
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqa
 *  aqm
 *  bhn
 *  javax.annotation.Nullable
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.util.function.Predicate;
import javax.annotation.Nullable;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1A;
import net.impactclient.1P;
import net.impactclient.2w$6X;
import net.impactclient.34B;
import net.impactclient.34J;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.4f;
import net.impactclient.4m;
import net.impactclient.4s;
import net.impactclient.5Q;
import net.impactclient.9N;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 0E
extends 3X
implements 34B {
    private 1A 1;
    private static final String[] d;
    private static final String[] e;
    private 1P 9;
    private 1A 8;
    public 1P 5;
    public 1P 2;
    @EventHandler
    private final Listener<4f> 4;
    public static final boolean \u2000\u200c\u2004\u200d;
    private aqa 7;
    private 1P 6;
    private 1P 0;
    private final 9N<Float> 08;

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public final void 9() {
        block3: {
            block2: {
                boolean bl = \u2000\u200c\u2004\u200d;
                if (bl || bl) break block2;
                this.0();
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void 0() {
        block3: {
            block2: {
                boolean bl = \u2000\u200c\u2004\u200d;
                if (bl || bl) break block2;
                0E.6(this.7, 1.0f);
                if (bl || bl) break block2;
                this.7 = null;
                if (!bl && !bl) break block3;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private /* synthetic */ void 5(4f var1_1) {
        block16: {
            block15: {
                var6_2 = 0E.\u2000\u200c\u2004\u200d;
                if (var6_2 || var6_2) lbl-1000:
                // 8 sources

                {
                    return;
                }
                var1_1 = 0E.3.s.cr();
                if (var6_2 || var6_2) ** GOTO lbl-1000
                if (0E.3.s.br()) break block15;
                if (var6_2 || var6_2) ** GOTO lbl-1000
                return;
            }
            if (var6_2) ** GOTO lbl-1000
            if (!this.6.2) break block16;
            if (var6_2 || var6_2) ** GOTO lbl-1000
            if (!0E.3.s.br()) ** GOTO lbl-1000
            if (var6_2) ** GOTO lbl-1000
            if (!0E.3.s.cr().aE()) ** GOTO lbl-1000
            if (var6_2) ** GOTO lbl-1000
            if (0E.3.s.cr() instanceof aqm) {
                if (!var6_2) ** break;
                ** continue;
                v0 = (int)((long)283120952 ^ (long)283120953);
                if (0E.\u2000\u200c\u2004\u200d) {
                    throw null;
                }
            } else lbl-1000:
            // 3 sources

            {
                v0 = (int)((long)-708037483 ^ (long)-708037483);
            }
            if (v0 != 0) {
                var3_3 = 0E.3.s.cr();
                var3_3.n(var3_3.cC().b, 0.2, var3_3.cC().d);
            }
        }
        var2_4 = var1_1 instanceof bhn;
        if (this.0.2 && (var1_1 instanceof aqm || var2_4)) {
            if (var1_1 instanceof aqm) {
                v1 = 4m.5(5Q.b, (aqm)var1_1, (boolean)((long)-1770990091 ^ (long)-1770990092));
                if (0E.\u2000\u200c\u2004\u200d) {
                    throw null;
                }
            } else {
                v1 = var4_5 = 4m.1(5Q.b);
            }
            if (var2_4) {
                this.08.accept(Float.valueOf(0.0f));
            }
            var3_3 = 4m.2(this.8.9);
            if (var2_4) {
                this.08.8();
            }
            var1_1.n((double)(var3_3[(int)((long)1768170601 ^ (long)1768170601)] * var4_5), var1_1.cC().c, (double)(var3_3[(int)((long)-595505412 ^ (long)-595505411)] * var4_5));
            if (var2_4) {
                var1_1.p = 0E.3.s.p;
            }
        }
        if (this.9.2) {
            var3_3 = this;
            var3_3.0();
            if (0E.3.s.br()) {
                var3_3.7 = 0E.3.s.cr();
                0E.6(var3_3.7, var3_3.1.9);
            }
            return;
        }
        this.0();
    }

    /*
     * Enabled aggressive block sorting
     */
    private static void 6(@Nullable aqa aqa2, float f) {
        block4: {
            block2: {
                boolean bl;
                block3: {
                    bl = \u2000\u200c\u2004\u200d;
                    if (bl || bl) break block2;
                    if (aqa2 == null) break block3;
                    if (bl) break block2;
                    aqa2.G = f;
                    if (bl) break block2;
                }
                if (!bl) break block4;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 0E.\u2000\u200c\u2004\u200d;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-625278400 ^ (long)625278512)) & (int)((long)-439927347 ^ (long)-439893454);
            if (var9_2) ** GOTO lbl-1000
            if (0E.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 0E.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)422661528 ^ (long)422661528)] & (int)((long)1942098018 ^ (long)1942098077)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-335345515 ^ (long)-335345646);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1181443998 ^ (long)-1181444013);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)324827020 ^ (long)324826889);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1936611985 ^ (long)-1936612082);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1786842267 ^ (long)-1786842283);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)1692638626 ^ (long)1692638567);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)1475479895 ^ (long)1475480028);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)-1634579814 ^ (long)-1634579940);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)804243665 ^ (long)804243650);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-293004707 ^ (long)-293004724);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)-1501882511 ^ (long)-1501882411);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-252553364 ^ (long)-252553301);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)1236766756 ^ (long)1236766847);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-2058723533 ^ (long)-2058723390);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)102654127 ^ (long)102654055);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)546480297 ^ (long)546480316);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)-685128411 ^ (long)-685128206);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)226216527 ^ (long)226216579);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)331810958 ^ (long)331810913);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1063731798 ^ (long)-1063731904);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-358729681 ^ (long)-358729499);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-554451766 ^ (long)-554451835);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)-634237143 ^ (long)-634237061);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-889584428 ^ (long)-889584611);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)2121012482 ^ (long)2121012621);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1125093820 ^ (long)-1125093675);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)39279917 ^ (long)39280063);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)1919832118 ^ (long)1919832084);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-1819444576 ^ (long)-1819444503);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)-1989841696 ^ (long)-1989841689);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1714500836 ^ (long)1714500704);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)1680043752 ^ (long)1680043584);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1909302376 ^ (long)1909302292);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)388860792 ^ (long)388860672);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)-840198522 ^ (long)-840198478);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-2003697983 ^ (long)-2003697950);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-754944385 ^ (long)-754944414);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)1162877369 ^ (long)1162877415);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)-282551143 ^ (long)-282551085);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-1843122612 ^ (long)-1843122484);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)-1161088487 ^ (long)-1161088387);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)1954047048 ^ (long)1954047088);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-1263111093 ^ (long)-1263111083);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)-1705074315 ^ (long)-1705074333);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)63327890 ^ (long)63327750);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1752745542 ^ (long)-1752745650);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)-1575355870 ^ (long)-1575355703);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1205951249 ^ (long)1205951367);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)370949495 ^ (long)370949595);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)1688384312 ^ (long)1688384296);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)1404331460 ^ (long)1404331273);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)1298360420 ^ (long)1298360477);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)393736184 ^ (long)393735940);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)935250233 ^ (long)935250270);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)225463854 ^ (long)225463918);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)-528814603 ^ (long)-528814840);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)-2105135701 ^ (long)-2105135660);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-1844163510 ^ (long)-1844163371);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)-943139896 ^ (long)-943139876);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-597494669 ^ (long)-597494634);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)1396689026 ^ (long)1396688953);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-1417034183 ^ (long)-1417034104);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)-1920461224 ^ (long)-1920461170);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-919804382 ^ (long)-919804375);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)-440654749 ^ (long)-440654781);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)-1232942311 ^ (long)-1232942138);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1806832520 ^ (long)1806832514);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1278105651 ^ (long)-1278105632);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)-397056068 ^ (long)-397056005);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)-1082681352 ^ (long)-1082681488);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)503980503 ^ (long)503980522);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)682325808 ^ (long)682325866);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)1816615807 ^ (long)1816615789);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-216821505 ^ (long)-216821612);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)1766952135 ^ (long)1766952075);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)-286126123 ^ (long)-286126287);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-1113312004 ^ (long)-1113312048);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)-1914841426 ^ (long)-1914841485);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1508239405 ^ (long)1508239446);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)997877748 ^ (long)997877690);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)521434361 ^ (long)521434227);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-103195361 ^ (long)-103195351);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)1600301117 ^ (long)1600301281);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)796975535 ^ (long)796975591);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)760912451 ^ (long)760912514);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1190361812 ^ (long)1190361730);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-2034215190 ^ (long)-2034215378);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)154066855 ^ (long)154066829);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)-1932861603 ^ (long)-1932861563);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)-947207148 ^ (long)-947206938);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)-1136525824 ^ (long)-1136525705);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)1233555607 ^ (long)1233555630);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)-1925434137 ^ (long)-1925434214);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)2096326542 ^ (long)2096326477);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)1764280250 ^ (long)1764280271);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)20666202 ^ (long)20666317);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)535147004 ^ (long)535146902);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)1501690697 ^ (long)1501690799);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)-1819779511 ^ (long)-1819779341);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)874759975 ^ (long)874760132);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)584106016 ^ (long)584106044);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)1223177450 ^ (long)1223177428);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1172390432 ^ (long)1172390432);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-197745832 ^ (long)-197745879);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)1809397579 ^ (long)1809397625);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1504129136 ^ (long)1504129273);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)-1451540547 ^ (long)-1451540574);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1963460659 ^ (long)1963460832);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)21143889 ^ (long)21143822);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-80022411 ^ (long)-80022354);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)-389102410 ^ (long)-389102400);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-403764241 ^ (long)-403764316);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)1244309014 ^ (long)1244309034);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)1490212174 ^ (long)1490212229);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)-13997564 ^ (long)-13997487);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1391445542 ^ (long)1391445693);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-1977913282 ^ (long)-1977913166);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)1736869770 ^ (long)1736869872);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)-1642375768 ^ (long)-1642375830);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)298935496 ^ (long)298935473);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)-1778467843 ^ (long)-1778468035);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1280951093 ^ (long)1280951091);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-99975260 ^ (long)-99975382);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)798620885 ^ (long)798620878);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)52956753 ^ (long)52956899);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)600533014 ^ (long)600533172);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)-287390269 ^ (long)-287390236);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)-772632228 ^ (long)-772632070);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)1367032277 ^ (long)1367032166);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)1390977144 ^ (long)1390977099);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)1174811930 ^ (long)1174812034);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)-319317578 ^ (long)-319317660);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)-1306775825 ^ (long)-1306775882);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)-1216521339 ^ (long)-1216521438);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-287092738 ^ (long)-287092882);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)1453350902 ^ (long)1453350881);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)1962036526 ^ (long)1962036696);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)1626776542 ^ (long)1626776403);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)825337608 ^ (long)825337790);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1855431349 ^ (long)1855431355);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1253869804 ^ (long)-1253869775);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)-1616346011 ^ (long)-1616346018);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)1784972105 ^ (long)1784972259);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)2145336633 ^ (long)2145336736);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1770250503 ^ (long)1770250644);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)1554276305 ^ (long)1554276153);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)318299339 ^ (long)318299338);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)589027429 ^ (long)589027498);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)2081517588 ^ (long)2081517774);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)-1021261854 ^ (long)-1021261993);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)912578305 ^ (long)912578516);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-1772297453 ^ (long)-1772297282);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)-942245781 ^ (long)-942245846);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-1142822 ^ (long)-1142903);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)-176010605 ^ (long)-176010746);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)1629268756 ^ (long)1629268749);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)1310258866 ^ (long)1310258911);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-1318808052 ^ (long)-1318807839);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1503402807 ^ (long)-1503402776);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)999660312 ^ (long)999660350);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)572481214 ^ (long)572481250);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)1325883513 ^ (long)1325883591);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)-1671648987 ^ (long)-1671648837);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-2095135021 ^ (long)-2095135055);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)903560477 ^ (long)903560501);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)-455495701 ^ (long)-455495708);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)1280505145 ^ (long)1280505163);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)2051849489 ^ (long)2051849711);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)2030903925 ^ (long)2030903959);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)-724067924 ^ (long)-724067971);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-501821113 ^ (long)-501821033);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)-714017201 ^ (long)-714017270);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)402381016 ^ (long)402380990);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-1786295875 ^ (long)-1786295981);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)-5047753 ^ (long)-5047761);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)697139154 ^ (long)697139069);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)1208005680 ^ (long)1208005750);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)1247982164 ^ (long)1247982085);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)1118277889 ^ (long)1118278101);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)715730426 ^ (long)715730243);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-1275103372 ^ (long)-1275103265);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-1777700429 ^ (long)-1777700381);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)58912088 ^ (long)58912171);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)1901081822 ^ (long)1901081847);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)1084403304 ^ (long)1084403401);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)272153491 ^ (long)272153596);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)-1262552960 ^ (long)-1262552905);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)1297435241 ^ (long)1297435350);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)-2100116526 ^ (long)-2100116658);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)-359032512 ^ (long)-359032385);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)1191971680 ^ (long)1191971682);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)542900806 ^ (long)542900903);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)-2023466430 ^ (long)-2023466436);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)50005981 ^ (long)50005982);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)685347322 ^ (long)685347226);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)186083761 ^ (long)186083604);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)992724533 ^ (long)992724480);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)40926271 ^ (long)40926322);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)2117540425 ^ (long)2117540496);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1627907635 ^ (long)-1627907672);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)1306477722 ^ (long)1306477595);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)569724310 ^ (long)569724287);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)-738604820 ^ (long)-738604965);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-169715564 ^ (long)-169715690);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)1350763006 ^ (long)1350762851);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)-2128655993 ^ (long)-2128655933);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)-1288961900 ^ (long)-1288962016);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-1745545051 ^ (long)-1745545143);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)-1765012773 ^ (long)-1765012987);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)-669586811 ^ (long)-669586753);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)-372563485 ^ (long)-372563648);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)1727116002 ^ (long)1727116011);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1213304643 ^ (long)1213304603);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)-1676923273 ^ (long)-1676923357);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-698554350 ^ (long)-698554346);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)-1312643230 ^ (long)-1312643295);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)1742216417 ^ (long)1742216338);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)225295745 ^ (long)0xD6DBD66);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)345112620 ^ (long)345112664);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1152563796 ^ (long)-1152563771);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1828245954 ^ (long)1828245810);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)1535473033 ^ (long)1535472935);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)893031409 ^ (long)893031282);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)1488811588 ^ (long)1488811658);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)651070394 ^ (long)651070368);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-1805767467 ^ (long)-1805767446);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1617122350 ^ (long)1617122338);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-689168707 ^ (long)-689168883);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)604522263 ^ (long)604522296);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)1898400571 ^ (long)1898400647);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-659162735 ^ (long)-659162836);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1505676048 ^ (long)-1505676076);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)1578927738 ^ (long)1578927757);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-1457171076 ^ (long)-1457171068);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)-751061684 ^ (long)-751061657);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-2071047575 ^ (long)-2071047534);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)627602574 ^ (long)627602592);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)-2084150244 ^ (long)-2084150084);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)-85758726 ^ (long)-85758910);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)-301463445 ^ (long)-301463379);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)1242898013 ^ (long)1242898164);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)708719071 ^ (long)708719063);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)210429565 ^ (long)210429472);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1513917464 ^ (long)1513917558);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)1033700326 ^ (long)1033700220);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)1277533165 ^ (long)1277532952);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)812357684 ^ (long)812357700);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-2027287546 ^ (long)-2027287300);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-1502380971 ^ (long)-1502380968);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)-714118800 ^ (long)-714118888);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)-1163645597 ^ (long)-1163645696);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)300465986 ^ (long)300465966);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)1893781122 ^ (long)1893781205);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-467289479 ^ (long)-467289476);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-1989071466 ^ (long)-1989071498);
                    if (!0E.\u2000\u200c\u2004\u200d) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)2049577112 ^ (long)2049577178);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1270926637 ^ (long)1270926802)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)-1716356691 ^ (long)-1716353454)) >>> (int)((long)230289962 ^ (long)230289954)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)-2011850717 ^ (long)-2011850717);
            if (!0E.\u2000\u200c\u2004\u200d) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)26522247 ^ (long)26522245);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)-6997762 ^ (long)-6997763) | var5_6 << (int)((long)1964496435 ^ (long)1964496438)) ^ var3_4[var7_8]) & (int)((long)521398837 ^ (long)521398986);
                    if (0E.\u2000\u200c\u2004\u200d) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)2140215517 ^ (long)2140215518) | var6_7 << (int)((long)-1699164546 ^ (long)-1699164549)) ^ var3_4[var7_8]) & (int)((long)-178858859 ^ (long)-178858902);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            0E.e[var2_3] = new String(var3_4).intern();
        }
        return 0E.e[var2_3];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block23: {
            block22: {
                var7 = 0E.\u2000\u200c\u2004\u200d;
                if (!var7) break block22;
                break block23;
            }
            var5_1 = new String[(int)((long)-499710363 ^ (long)-499710350)];
            if (var7) break block23;
            var3_2 = (int)((long)-626826951 ^ (long)-626826951);
            if (var7) break block23;
            var2_3 = 2w$6X.KAOZ("\u675e\u4ffc\u5c8d\u5491\u6726\u4f31\u5cf5\u54b9\u67fe\u4f2f\u5c78\u549a\u6792\u4fb9\u5c37\u5453\u6759\u4f53\u5ce8\u546e\u6777\u4f4f\u5ca0\u542d\u67a8\u4f9f\u5c06\u542a\u670b\u4fe1\u5c83\u54e1\u67d8\u4f87\u5c92\u54c3\u6729\u4f2f\u5cc8\u541c\u6725\u4f9e\u5c0a\u549c\u6745\u4f17\u5cc1\u54db\u67f8\u4f67\u5c9c\u54eb\u6778\u4f19\u5c61\u5492\u6794\u4ff8\u5c65\u546c\u6704\u4f60\u5c8b\u54c6\u6769\u4f44\u5c39\u548d\u6747\u4fbe\u5c80\u54da\u6756\u4f8b\u5ca3\u549e\u67e9\u4fdc\u5c6d\u54bf\u67b4\u4ff4\u5c4e\u549b\u675a\u4f55\u5c5d\u5474\u67e8\u4fef\u5c80\u5476\u672a\u4f09\u5c27\u542f\u6773\u4fe2\u5c5f\u5452\u67ef\u4fad\u5c9e\u5497\u674c\u4f9b\u5c9b\u54d8\u6771\u4f77\u5ccb\u5404\u6717\u4f39\u5c45\u543e\u6766\u4f65\u5c51\u54c6\u6710\u4f99\u5c71\u5455\u679c\u4fca\u5c83\u54f8\u6720\u4f9a\u5cd2\u54f8\u670f\u4f0b\u5c85\u54e0\u6713\u4f76\u5cf1\u544f\u6783\u4f44\u5cd8\u54ff\u675f\u4f3c\u5c8f\u5406\u6752\u4faa\u5cd9\u54d4\u6782\u4f37\u5c69\u5465\u6777\u4f0a\u5cb7\u54bb\u6715\u4f9e\u5c74\u5470\u67cd\u4f18\u5c7a\u54f6\u67d5\u4ffe\u5c3f\u548f\u6767\u4f9f\u5c40\u54d4\u67e7\u4f3e\u5c81\u548e\u67bb\u4f5c\u5c78\u5423\u671d\u4fb8\u5ca8\u5477\u67c8\u4fcb\u5c74\u548d\u6706\u4fed\u5c0b\u54b6\u676c\u4f27\u5c82\u54bc\u67cc\u4fb1\u5c8d\u54fa\u67de\u4faa\u5c4a\u549c\u67fc\u4f42\u5c30\u54e0\u67de\u4f9f\u5c7c\u54a0\u67d2\u4fb4\u5c30\u543b\u6712\u4f9c\u5c70\u5486\u67f8\u4f08\u5c89\u54a6\u6742\u4fa5\u5cfc\u54d3\u674d\u4fa2\u5c3f\u54f3\u6794\u4f3d\u5cbc\u5478\u67ec\u4fb5\u5c9f\u54f8\u6791\u4fa9\u5c2a\u5436\u67cc\u4f1d\u5cfc\u5494\u671f\u4f58\u5cc5\u5497\u67c4\u4f8a\u5c42\u5414\u67a7\u4ffe\u5c1f\u543b\u6729\u4f52\u5cee\u5422\u679e\u4fe6\u5c52\u54b7\u67ee\u4fd8\u5c89\u54f6\u6700\u4f2e\u5c02\u5496\u670f\u4faa\u5c92\u5416\u67c8\u4f96\u5cf9\u54db\u67d1\u4fbc\u5ce1\u54ee\u676f\u4f2e\u5c4a\u54ea\u6744\u4fb1\u5c82\u54d8\u676e\u4f35\u5c6c\u5404\u67f3\u4f95\u5c95\u54fe\u6717\u4f6f\u5c42\u542a\u6705\u4f26\u5c24\u5461\u67c9\u4ff3\u5c2e\u5434\u676c\u4f9c\u5ca2\u54a2\u6786\u4f8c\u5c46\u5436\u67bb\u4fbe\u5cb6\u5420\u6772\u4fdb\u5c50\u5427\u67c0\u4f79\u5cd7\u5481\u6732\u4f9b\u5c23\u5425\u6794\u4f7e\u5c25\u542f\u6769\u4fbb\u5c29\u541e\u67e4\u4fe8\u5cb6\u5476\u675f\u4faf\u5c1c\u542a\u67b9\u4f90\u5cc0\u546b\u6732\u4f6b\u5c2a\u54f6\u67fd\u4fca\u5c96\u542a\u677b", 366100786);
            var4_4 = var2_3.length();
            if (var7) break block23;
            var1_5 = (int)((long)-1501205970 ^ (long)-1501205958);
            if (var7) break block23;
            var0_6 = (int)((long)-1095196902 ^ (long)1095196901);
            if (var7) break block23;
            block11: while (!var7) {
                block20: {
                    v0 = (int)((long)1484321383 ^ (long)1484321358);
                    v1 = ++var0_6;
                    v2 = var2_3.substring(v1, v1 + var1_5);
                    v3 = (int)((long)-1881530530 ^ (long)1881530529);
                    if (0E.\u2000\u200c\u2004\u200d) {
                        throw null;
lbl24:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0E.\u2000\u200c\u2004\u200d) continue block11;
                                throw null;
                            }
                            var2_3 = 2w$6X.KAOZ("\u6cff\u44f4\u5708\u5f98\u6cd7\u4431\u5783\u5fd3\u6c8e\u4448\u576c\u5fbb\u6c45\u4443\u57e1\u5feb\u6c65\u44c7\u5782\u5f0d\u6c61\u4431\u57e2\u5f14\u6c41\u44eb\u5714\u5f2c\u6cdd\u4460\u572b\u5ffe\u6cd1\u4487\u57a2\u5fb8\u6c6e\u4420\u578c\u5f18\u6c7b\u4419\u5757\u5f7e\u6cb8\u4422\u5713\u5f13\u6c72\u4405\u57b6\u5fc9\u6c59\u4411\u579d\u5f5e\u6c2b", -1426306389);
                            var4_4 = var2_3.length();
                            var1_5 = (int)((long)577262258 ^ (long)577262263);
                            var0_6 = (int)((long)-556715235 ^ (long)556715234);
                            while (true) {
                                v0 = (int)((long)-198647064 ^ (long)-198647074);
                                v5 = ++var0_6;
                                v2 = var2_3.substring(v5, v5 + var1_5);
                                v3 = (int)((long)-1169666244 ^ (long)-1169666244);
                                if (!0E.\u2000\u200c\u2004\u200d) break block20;
                                throw null;
                            }
                            break;
                        }
lbl41:
                        // 1 sources

                        while (true) {
                            var5_1[var3_2++] = v4.intern();
                            if ((var0_6 += var1_5) < var4_4) {
                                var1_5 = var2_3.charAt(var0_6);
                                if (!0E.\u2000\u200c\u2004\u200d) ** continue;
                                throw null;
                            }
                            0E.d = var5_1;
                            0E.e = new String[(int)((long)829543989 ^ (long)829543970)];
                            if (!0E.\u2000\u200c\u2004\u200d) break block11;
                            throw null;
                        }
                    }
                }
                v6 = v2.toCharArray();
                v7 = v6.length;
                var6_7 = (int)((long)-1185435898 ^ (long)-1185435898);
                v8 = v0;
                v9 = v6;
                v10 = v7;
                if (v7 > (int)((long)542731613 ^ (long)542731612)) ** GOTO lbl107
                do {
                    block21: {
                        v11 = v8;
                        v9 = v9;
                        v12 = v9;
                        v13 = v8;
                        v14 = var6_7;
                        do {
                            switch (var6_7 % (int)((long)-753215220 ^ (long)-753215221)) {
                                case 0: {
                                    v15 = (int)((long)-302306773 ^ (long)-302306744);
                                    if (!0E.\u2000\u200c\u2004\u200d) break;
                                    throw null;
                                }
                                case 1: {
                                    v15 = (int)((long)-405883964 ^ (long)-405884029);
                                    if (!0E.\u2000\u200c\u2004\u200d) break;
                                    throw null;
                                }
                                case 2: {
                                    v15 = (int)((long)-1211134680 ^ (long)-1211134628);
                                    if (!0E.\u2000\u200c\u2004\u200d) break;
                                    throw null;
                                }
                                case 3: {
                                    v15 = (int)((long)690407918 ^ (long)690407873);
                                    if (!0E.\u2000\u200c\u2004\u200d) break;
                                    throw null;
                                }
                                case 4: {
                                    v15 = (int)((long)782435102 ^ (long)782435122);
                                    if (!0E.\u2000\u200c\u2004\u200d) break;
                                    throw null;
                                }
                                case 5: {
                                    v15 = (int)((long)-1278064444 ^ (long)-1278064481);
                                    if (!0E.\u2000\u200c\u2004\u200d) break;
                                    throw null;
                                }
                                default: {
                                    v15 = (int)((long)870917075 ^ (long)870917114);
                                }
                            }
                            v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                            ++var6_7;
                            v8 = v11;
                            if (v11 != 0) break block21;
                            v11 = v8;
                            v9 = v9;
                            v14 = v8;
                            v12 = v9;
                            v13 = v8;
                        } while (!0E.\u2000\u200c\u2004\u200d);
                        throw null;
                    }
                    v16 = v9;
                    v10 = v10;
                } while (v10 > var6_7);
                v4 = new String(v16);
                switch (v3) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl118:
                    // 1 sources

                    ** continue;
                }
            }
        }
    }

    public 0E() {
        boolean bl = \u2000\u200c\u2004\u200d;
        super(0E.b((int)((long)976928683 ^ (long)-976927786), (int)((long)444368032 ^ (long)-444380990)) /* "Riding" */, 0E.b((int)((long)-1910701349 ^ (long)1910701743), (int)((long)1493449707 ^ (long)-1493453349)) /* "Improves horses and some other rideable entities" */);
        Comparable<Boolean> comparable = Boolean.TRUE;
        34J j2 = (34X)((34X)((34X)this.4().5(0E.b((int)((long)1223671729 ^ (long)-1223670840), (int)((long)840590977 ^ (long)-840568197)) /* "Jump" */)).7(0E.b((int)((long)455343020 ^ (long)-455342113), (int)((long)-1924430464 ^ (long)1924402570)) /* "jump" */)).1(0E.b((int)((long)-1586860682 ^ (long)1586860309), (int)((long)-806123940 ^ (long)806120210)) /* "Horses always jump with maximum power" */);
        ((34X)((34X)((34X)this.4().5(0E.b((int)((long)1223671729 ^ (long)-1223670840), (int)((long)840590977 ^ (long)-840568197)) /* "Jump" */)).7(0E.b((int)((long)455343020 ^ (long)-455342113), (int)((long)-1924430464 ^ (long)1924402570)) /* "jump" */)).1(0E.b((int)((long)-1586860682 ^ (long)1586860309), (int)((long)-806123940 ^ (long)806120210)) /* "Horses always jump with maximum power" */)).7 = comparable;
        this.2 = (1P)j2.5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(0E.b((int)((long)-1372863135 ^ (long)1372862723), (int)((long)-1457259010 ^ (long)1457284745)) /* "Control" */)).7(0E.b((int)((long)-1745600084 ^ (long)1745599955), (int)((long)244811773 ^ (long)244839456)) /* "control" */)).1(0E.b((int)((long)341344980 ^ (long)-341344588), (int)((long)1801795764 ^ (long)1801783606)) /* "Control Horses, Llamas & Pigs even when you're not supposed to" */);
        ((34X)((34X)((34X)this.4().5(0E.b((int)((long)-1372863135 ^ (long)1372862723), (int)((long)-1457259010 ^ (long)1457284745)) /* "Control" */)).7(0E.b((int)((long)-1745600084 ^ (long)1745599955), (int)((long)244811773 ^ (long)244839456)) /* "control" */)).1(0E.b((int)((long)341344980 ^ (long)-341344588), (int)((long)1801795764 ^ (long)1801783606)) /* "Control Horses, Llamas & Pigs even when you're not supposed to" */)).7 = comparable;
        this.5 = (1P)j2.5();
        comparable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(0E.b((int)((long)1553239351 ^ (long)-1553239738), (int)((long)-1547822758 ^ (long)-1547811148)) /* "Swim" */)).7(0E.b((int)((long)-1081821740 ^ (long)1081821602), (int)((long)-558882737 ^ (long)-558888610)) /* "swim" */)).1(0E.b((int)((long)-760600112 ^ (long)760599990), (int)((long)-142205717 ^ (long)-142202894)) /* "Prevent being kicking off your steed while swimming" */);
        ((34X)((34X)((34X)this.4().5(0E.b((int)((long)1553239351 ^ (long)-1553239738), (int)((long)-1547822758 ^ (long)-1547811148)) /* "Swim" */)).7(0E.b((int)((long)-1081821740 ^ (long)1081821602), (int)((long)-558882737 ^ (long)-558888610)) /* "swim" */)).1(0E.b((int)((long)-760600112 ^ (long)760599990), (int)((long)-142205717 ^ (long)-142202894)) /* "Prevent being kicking off your steed while swimming" */)).7 = comparable;
        this.6 = (1P)j2.5();
        comparable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0E.b((int)((long)19098795 ^ (long)-19099437), (int)((long)302349643 ^ (long)-302327192)) /* "Entity Speed" */)).7(0E.b((int)((long)746981598 ^ (long)-746982235), (int)((long)-1724929208 ^ (long)1724908165)) /* "speed" */)).1(0E.b((int)((long)2088628896 ^ (long)-2088628514), (int)((long)1463202064 ^ (long)-1463193228)) /* "Change the speed of ridden entities" */);
        ((34X)((34X)((34X)this.4().5(0E.b((int)((long)19098795 ^ (long)-19099437), (int)((long)302349643 ^ (long)-302327192)) /* "Entity Speed" */)).7(0E.b((int)((long)746981598 ^ (long)-746982235), (int)((long)-1724929208 ^ (long)1724908165)) /* "speed" */)).1(0E.b((int)((long)2088628896 ^ (long)-2088628514), (int)((long)1463202064 ^ (long)-1463193228)) /* "Change the speed of ridden entities" */)).7 = comparable;
        this.0 = (1P)j2.5();
        comparable = Float.valueOf(1.0f);
        j2 = ((34e)((34e)((34e)this.9().5(0E.b((int)((long)1541754757 ^ (long)-1541753888), (int)((long)-1573233574 ^ (long)-1573237911)) /* "Speed" */)).7(0E.b((int)((long)979567455 ^ (long)-979566811), (int)((long)1224808676 ^ (long)-1224809510)))).1(0E.b((int)((long)362525572 ^ (long)-362524684), (int)((long)444760486 ^ (long)-444771582)) /* "The speed multiplier" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(20.0f));
        ((34e)((34e)((34e)this.9().5(0E.b((int)((long)1541754757 ^ (long)-1541753888), (int)((long)-1573233574 ^ (long)-1573237911)) /* "Speed" */)).7(0E.b((int)((long)979567455 ^ (long)-979566811), (int)((long)1224808676 ^ (long)-1224809510)))).1(0E.b((int)((long)362525572 ^ (long)-362524684), (int)((long)444760486 ^ (long)-444771582)) /* "The speed multiplier" */)).3(Float.valueOf(1.0f)).2(Float.valueOf(20.0f)).7 = comparable;
        this.8 = (1A)((34e)((34e)j2).3(this.0)).5();
        comparable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(0E.b((int)((long)1373103770 ^ (long)-1373103379), (int)((long)1865529010 ^ (long)-1865521663)) /* "Entity Step" */)).7(0E.b((int)((long)1111078181 ^ (long)-1111078567), (int)((long)624863298 ^ (long)624873595)) /* "step" */)).1(0E.b((int)((long)-813764669 ^ (long)813765558), (int)((long)-48019652 ^ (long)-48008676)) /* "Change the step height of ridden entities" */);
        ((34X)((34X)((34X)this.4().5(0E.b((int)((long)1373103770 ^ (long)-1373103379), (int)((long)1865529010 ^ (long)-1865521663)) /* "Entity Step" */)).7(0E.b((int)((long)1111078181 ^ (long)-1111078567), (int)((long)624863298 ^ (long)624873595)) /* "step" */)).1(0E.b((int)((long)-813764669 ^ (long)813765558), (int)((long)-48019652 ^ (long)-48008676)) /* "Change the step height of ridden entities" */)).7 = comparable;
        this.9 = (1P)j2.5();
        comparable = Float.valueOf(1.0f);
        j2 = ((34e)((34e)((34e)this.9().5(0E.b((int)((long)1558940525 ^ (long)-1558939873), (int)((long)1457700322 ^ (long)1457715448)) /* "Step" */)).7(0E.b((int)((long)1472819043 ^ (long)-1472818425), (int)((long)-1138091155 ^ (long)1138067594)) /* "value" */)).1(0E.b((int)((long)1188520606 ^ (long)-1188520193), (int)((long)1825144073 ^ (long)1825140964)) /* "The number of blocks to step" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(16.0f));
        ((34e)((34e)((34e)this.9().5(0E.b((int)((long)1558940525 ^ (long)-1558939873), (int)((long)1457700322 ^ (long)1457715448)) /* "Step" */)).7(0E.b((int)((long)1472819043 ^ (long)-1472818425), (int)((long)-1138091155 ^ (long)1138067594)) /* "value" */)).1(0E.b((int)((long)1188520606 ^ (long)-1188520193), (int)((long)1825144073 ^ (long)1825140964)) /* "The number of blocks to step" */)).3(Float.valueOf(0.0f)).2(Float.valueOf(16.0f)).7 = comparable;
        this.1 = (1A)((34e)((34e)j2).3(this.9)).5();
        this.08 = 4s.7();
        this.4 = new Listener(this::5, new Predicate[(int)((long)2058437987 ^ (long)2058437987)]);
    }
}

