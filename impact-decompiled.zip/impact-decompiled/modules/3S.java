/* ==========================================================================
 * MODULE: Auto Armor
 * CATEGORY (inferred): Combat
 * DESCRIPTION: Automaticaly equips armor
 * OBFUSCATED CLASS: net.impactclient.3S
 * Inline /* "..." */ comments show the runtime-decrypted string at each
 * call site (Impact encrypts all literals; decryptor is stack-sensitive).
 * ========================================================================== */
/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aqf$a
 *  bik
 *  bjy
 *  bld
 *  bmb
 *  bmd
 *  bmm
 *  bps
 *  bpu
 *  dqe
 *  me.zero.alpine.listener.EventHandler
 *  me.zero.alpine.listener.Listener
 */
package net.impactclient;

import java.lang.constant.Constable;
import java.lang.invoke.LambdaMetafactory;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.impactclient.1P;
import net.impactclient.1z;
import net.impactclient.2w;
import net.impactclient.2w$6X;
import net.impactclient.34J;
import net.impactclient.34X;
import net.impactclient.34e;
import net.impactclient.3X;
import net.impactclient.4f;
import net.impactclient.56;
import net.impactclient.5p;
import net.impactclient.5y;
import net.impactclient.5z;
import net.impactclient.8H;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class 3S
extends 3X
implements 56 {
    private 1P 4;
    private 1P 2;
    private 1P 6;
    private static final String[] e;
    private 8H 8;
    private static final String[] d;
    private 1z 1;
    public static final List<2w<bmb>> 0;
    @EventHandler
    private final Listener<4f> 5;
    private 1P 7;
    public static final boolean \u2002;

    public 3S() {
        boolean bl = \u2002;
        super(3S.b((int)((long)1054436615 ^ (long)1054423409), (int)((long)1672833135 ^ (long)1672832349)) /* "Auto Armor" */, 3S.b((int)((long)865951606 ^ (long)865929995), (int)((long)-981645570 ^ (long)-981640386)) /* "Automaticaly equips armor" */);
        Constable constable = (int)((long)1625607553 ^ (long)1625607547);
        34J j2 = ((34e)((34e)((34e)this.1().5(3S.b((int)((long)149799734 ^ (long)149788494), (int)((long)1596040691 ^ (long)-1596061173)) /* "Delay" */)).7(3S.b((int)((long)-24873406 ^ (long)-24894915), (int)((long)526685082 ^ (long)-526700544)) /* "delay" */)).1(3S.b((int)((long)-1029679890 ^ (long)-1029701477), (int)((long)1663919279 ^ (long)1663918233)) /* "Armor equip delay" */)).3((int)((long)1782475962 ^ (long)1782475962)).2((int)((long)1592268440 ^ (long)1592268144));
        ((34e)((34e)((34e)this.1().5(3S.b((int)((long)149799734 ^ (long)149788494), (int)((long)1596040691 ^ (long)-1596061173)) /* "Delay" */)).7(3S.b((int)((long)-24873406 ^ (long)-24894915), (int)((long)526685082 ^ (long)-526700544)) /* "delay" */)).1(3S.b((int)((long)-1029679890 ^ (long)-1029701477), (int)((long)1663919279 ^ (long)1663918233)) /* "Armor equip delay" */)).3((int)((long)1782475962 ^ (long)1782475962)).2((int)((long)1592268440 ^ (long)1592268144)).7 = constable;
        this.1 = (1z)j2.5();
        constable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(3S.b((int)((long)-1548466245 ^ (long)-1548479532), (int)((long)400690954 ^ (long)-400715046)) /* "Inventory Open" */)).7(3S.b((int)((long)-542740774 ^ (long)-542754138), (int)((long)2108795634 ^ (long)-2108814975)) /* "inventory" */)).1(3S.b((int)((long)1128689872 ^ (long)1128670377), (int)((long)1751487623 ^ (long)1751482771)) /* "Your inventory must be open for items to switch slots" */);
        ((34X)((34X)((34X)this.4().5(3S.b((int)((long)-1548466245 ^ (long)-1548479532), (int)((long)400690954 ^ (long)-400715046)) /* "Inventory Open" */)).7(3S.b((int)((long)-542740774 ^ (long)-542754138), (int)((long)2108795634 ^ (long)-2108814975)) /* "inventory" */)).1(3S.b((int)((long)1128689872 ^ (long)1128670377), (int)((long)1751487623 ^ (long)1751482771)) /* "Your inventory must be open for items to switch slots" */)).7 = constable;
        this.6 = (1P)((34X)j2).5();
        constable = Boolean.TRUE;
        j2 = (34X)((34X)((34X)this.4().5(3S.b((int)((long)1243534945 ^ (long)1243513363), (int)((long)165626318 ^ (long)165633881)) /* "Auto Replace" */)).7(3S.b((int)((long)-1688192123 ^ (long)-1688178702), (int)((long)1545977335 ^ (long)-1545970755)) /* "replace" */)).1(3S.b((int)((long)334568862 ^ (long)334580197), (int)((long)-264306185 ^ (long)-264276693)) /* "Replaces armor that is better" */);
        ((34X)((34X)((34X)this.4().5(3S.b((int)((long)1243534945 ^ (long)1243513363), (int)((long)165626318 ^ (long)165633881)) /* "Auto Replace" */)).7(3S.b((int)((long)-1688192123 ^ (long)-1688178702), (int)((long)1545977335 ^ (long)-1545970755)) /* "replace" */)).1(3S.b((int)((long)334568862 ^ (long)334580197), (int)((long)-264306185 ^ (long)-264276693)) /* "Replaces armor that is better" */)).7 = constable;
        this.4 = (1P)((34X)j2).5();
        constable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(3S.b((int)((long)-656144296 ^ (long)-656122837), (int)((long)-1433681427 ^ (long)-1433677133)) /* "Skulls" */)).7(3S.b((int)((long)-1318653306 ^ (long)-1318672648), (int)((long)-762701770 ^ (long)762685113)) /* "skulls" */)).1(3S.b((int)((long)-1507398577 ^ (long)-1507411909), (int)((long)1691422751 ^ (long)-1691422973)) /* "Skulls as a helmet" */);
        ((34X)((34X)((34X)this.4().5(3S.b((int)((long)-656144296 ^ (long)-656122837), (int)((long)-1433681427 ^ (long)-1433677133)) /* "Skulls" */)).7(3S.b((int)((long)-1318653306 ^ (long)-1318672648), (int)((long)-762701770 ^ (long)762685113)) /* "skulls" */)).1(3S.b((int)((long)-1507398577 ^ (long)-1507411909), (int)((long)1691422751 ^ (long)-1691422973)) /* "Skulls as a helmet" */)).7 = constable;
        this.7 = (1P)((34X)j2).5();
        constable = Boolean.FALSE;
        j2 = (34X)((34X)((34X)this.4().5(3S.b((int)((long)-1992311530 ^ (long)-1992300180), (int)((long)1953306960 ^ (long)-1953323059)) /* "Elytra" */)).7(3S.b((int)((long)-1489347161 ^ (long)-1489368617), (int)((long)-1514933945 ^ (long)1514943776)) /* "elytra" */)).1(3S.b((int)((long)989667587 ^ (long)989689202), (int)((long)1738867992 ^ (long)1738891883)) /* "Elytra as chestplate" */);
        ((34X)((34X)((34X)this.4().5(3S.b((int)((long)-1992311530 ^ (long)-1992300180), (int)((long)1953306960 ^ (long)-1953323059)) /* "Elytra" */)).7(3S.b((int)((long)-1489347161 ^ (long)-1489368617), (int)((long)-1514933945 ^ (long)1514943776)) /* "elytra" */)).1(3S.b((int)((long)989667587 ^ (long)989689202), (int)((long)1738867992 ^ (long)1738891883)) /* "Elytra as chestplate" */)).7 = constable;
        this.2 = (1P)((34X)j2).5();
        this.8 = new 8H();
        this.5 = new Listener(f -> {
            block3: {
                block2: {
                    boolean bl = \u2002;
                    if (bl || bl) break block2;
                    0.forEach(w2 -> {
                        boolean bl = \u2002;
                        if (bl || bl) return;
                        if (!this.8.8(this.1.4)) {
                            if (bl || bl) return;
                            return;
                        }
                        if (bl) return;
                        if (this.6.2) {
                            if (bl) return;
                            if (!(3S.3.y instanceof dqe)) {
                                if (bl || bl) return;
                                return;
                            }
                        }
                        if (bl) return;
                        if ((w2 = (bmb)w2.3(3S.3.s.bm.a)) == null) {
                            if (bl || bl) return;
                            return;
                        }
                        if (bl) return;
                        int n = 3S.3.s.bm.a.indexOf(w2);
                        if (n < (int)((long)-1509536894 ^ (long)-1509536885)) {
                            if (bl || bl) return;
                            n += 36;
                            if (bl) return;
                        }
                        if (bl) return;
                        int n2 = 3S.1((bmb)w2);
                        if (bl || bl) return;
                        bmb bmb2 = (bmb)3S.3.s.bm.b.get(n2);
                        if (bmb2.b() == bmd.a) {
                            if (bl || bl) return;
                            5p.4(n, bik.b);
                            if (bl || bl) return;
                            this.8.0();
                            if (bl || bl) return;
                            return;
                        }
                        if (bl) return;
                        if (this.4.2) {
                            if (bl) return;
                            if (3S.9((bmb)w2) > 3S.9(bmb2)) {
                                if (bl || bl) return;
                                5p.4(n, bik.a);
                                if (bl || bl) return;
                                5p.4((int)((long)1971274220 ^ (long)1971274223) - n2 + (int)((long)1114031487 ^ (long)1114031482), bik.a);
                                if (bl || bl) return;
                                5p.4(n, bik.a);
                                if (bl || bl) return;
                                this.8.0();
                                if (bl) return;
                            }
                        }
                        if (!bl) return;
                    });
                    if (!bl) break block3;
                }
                return;
            }
        }, new Predicate[(int)((long)441442461 ^ (long)441442461)]);
    }

    private static /* synthetic */ double 3(bmb bmb2) {
        boolean bl = \u2002;
        if (bl || bl) {
            return 0.0;
        }
        return -3S.9(bmb2);
    }

    /*
     * Unable to fully structure code
     */
    private static String b(int var0, int var1_1) {
        block265: {
            var9_2 = 3S.\u2002;
            if (var9_2) lbl-1000:
            // 5 sources

            {
                return null;
            }
            var2_3 = (var0 ^ (int)((long)-1873843613 ^ (long)-1873854948)) & (int)((long)1162922626 ^ (long)1162884477);
            if (var9_2) ** GOTO lbl-1000
            if (3S.e[var2_3] != null) break block265;
            if (var9_2) ** GOTO lbl-1000
            var3_4 = 3S.d[var2_3].toCharArray();
            if (var9_2) ** GOTO lbl-1000
            switch (var3_4[(int)((long)-321681530 ^ (long)-321681530)] & (int)((long)-974131898 ^ (long)-974131783)) {
                case 0: {
                    if (var9_2) ** continue;
                    v0 = (int)((long)-1178653978 ^ (long)-1178654119);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 1: {
                    v0 = (int)((long)-1805740357 ^ (long)-1805740428);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 2: {
                    v0 = (int)((long)922579364 ^ (long)922579432);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 3: {
                    v0 = (int)((long)-1329868375 ^ (long)-1329868451);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 4: {
                    v0 = (int)((long)-1800100346 ^ (long)-1800100207);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 5: {
                    v0 = (int)((long)576319479 ^ (long)576319429);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 6: {
                    v0 = (int)((long)-1483295930 ^ (long)-1483295912);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 7: {
                    v0 = (int)((long)1874354212 ^ (long)1874354274);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 8: {
                    v0 = (int)((long)-466305769 ^ (long)-466305648);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 9: {
                    v0 = (int)((long)-200256071 ^ (long)-200256175);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 10: {
                    v0 = (int)((long)1136083726 ^ (long)1136083928);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 11: {
                    v0 = (int)((long)-1989954967 ^ (long)-1989955020);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 12: {
                    v0 = (int)((long)658842843 ^ (long)658842745);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 13: {
                    v0 = (int)((long)-135036299 ^ (long)-135036299);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 14: {
                    v0 = (int)((long)-972049844 ^ (long)-972049822);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 15: {
                    v0 = (int)((long)-662168786 ^ (long)-662168709);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 16: {
                    v0 = (int)((long)1611610763 ^ (long)1611610680);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 17: {
                    v0 = (int)((long)-121522506 ^ (long)-121522532);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 18: {
                    v0 = (int)((long)1801645454 ^ (long)1801645458);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 19: {
                    v0 = (int)((long)-1191931883 ^ (long)-1191931660);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 20: {
                    v0 = (int)((long)-1947824170 ^ (long)-1947824179);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 21: {
                    v0 = (int)((long)-1752639450 ^ (long)-1752639471);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 22: {
                    v0 = (int)((long)697273705 ^ (long)697273787);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 23: {
                    v0 = (int)((long)-1891198166 ^ (long)-1891198191);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 24: {
                    v0 = (int)((long)1225672229 ^ (long)1225672366);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 25: {
                    v0 = (int)((long)-1622151418 ^ (long)-1622151389);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 26: {
                    v0 = (int)((long)-1863564670 ^ (long)-1863564782);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 27: {
                    v0 = (int)((long)-386975120 ^ (long)-386975067);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 28: {
                    v0 = (int)((long)-474508487 ^ (long)-474508293);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 29: {
                    v0 = (int)((long)14862264 ^ (long)14862124);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 30: {
                    v0 = (int)((long)1975659574 ^ (long)1975659667);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 31: {
                    v0 = (int)((long)-665761814 ^ (long)-665762012);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 32: {
                    v0 = (int)((long)1487215978 ^ (long)1487215932);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 33: {
                    v0 = (int)((long)53607843 ^ (long)53607805);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 34: {
                    v0 = (int)((long)915506084 ^ (long)915506117);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 35: {
                    v0 = (int)((long)-1917689633 ^ (long)-1917689810);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 36: {
                    v0 = (int)((long)-1805618919 ^ (long)-1805618944);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 37: {
                    v0 = (int)((long)-2067093419 ^ (long)-2067093471);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 38: {
                    v0 = (int)((long)1098721179 ^ (long)1098721197);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 39: {
                    v0 = (int)((long)-623143645 ^ (long)-623143432);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 40: {
                    v0 = (int)((long)694412111 ^ (long)694412226);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 41: {
                    v0 = (int)((long)-1824393626 ^ (long)-1824393713);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 42: {
                    v0 = (int)((long)-734172517 ^ (long)-734172450);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 43: {
                    v0 = (int)((long)61379098 ^ (long)61379127);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 44: {
                    v0 = (int)((long)1656352365 ^ (long)1656352504);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 45: {
                    v0 = (int)((long)-1808806819 ^ (long)-1808806739);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 46: {
                    v0 = (int)((long)1621978483 ^ (long)1621978519);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 47: {
                    v0 = (int)((long)1797875358 ^ (long)1797875289);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 48: {
                    v0 = (int)((long)-1449966761 ^ (long)-1449966618);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 49: {
                    v0 = (int)((long)-1273538157 ^ (long)-1273538075);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 50: {
                    v0 = (int)((long)343820357 ^ (long)343820298);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 51: {
                    v0 = (int)((long)731737725 ^ (long)731737621);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 52: {
                    v0 = (int)((long)-113152904 ^ (long)-113152890);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 53: {
                    v0 = (int)((long)1076790551 ^ (long)1076790697);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 54: {
                    v0 = (int)((long)-1346103336 ^ (long)-1346103458);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 55: {
                    v0 = (int)((long)926568485 ^ (long)926568677);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 56: {
                    v0 = (int)((long)1714743207 ^ (long)1714743204);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 57: {
                    v0 = (int)((long)-2016072376 ^ (long)-2016072218);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 58: {
                    v0 = (int)((long)1932639964 ^ (long)1932639792);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 59: {
                    v0 = (int)((long)-1641836162 ^ (long)-1641836242);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 60: {
                    v0 = (int)((long)-1353544131 ^ (long)-1353543948);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 61: {
                    v0 = (int)((long)-268081021 ^ (long)-268080965);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 62: {
                    v0 = (int)((long)2145704233 ^ (long)2145704401);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 63: {
                    v0 = (int)((long)-1627794982 ^ (long)-1627795200);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 64: {
                    v0 = (int)((long)482427871 ^ (long)482427771);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 65: {
                    v0 = (int)((long)882094760 ^ (long)882094728);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 66: {
                    v0 = (int)((long)1099872759 ^ (long)1099872563);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 67: {
                    v0 = (int)((long)-1923513169 ^ (long)-1923513097);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 68: {
                    v0 = (int)((long)741647432 ^ (long)741647387);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 69: {
                    v0 = (int)((long)1059633525 ^ (long)1059633449);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 70: {
                    v0 = (int)((long)-1255600169 ^ (long)-1255600251);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 71: {
                    v0 = (int)((long)1393711667 ^ (long)1393711629);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 72: {
                    v0 = (int)((long)-797940923 ^ (long)-797940915);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 73: {
                    v0 = (int)((long)-2094342416 ^ (long)-2094342499);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 74: {
                    v0 = (int)((long)287190960 ^ (long)287190897);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 75: {
                    v0 = (int)((long)793856179 ^ (long)793856172);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 76: {
                    v0 = (int)((long)-834935409 ^ (long)-834935302);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 77: {
                    v0 = (int)((long)1343080781 ^ (long)1343080953);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 78: {
                    v0 = (int)((long)1067164999 ^ (long)1067165032);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 79: {
                    v0 = (int)((long)681444316 ^ (long)681444161);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 80: {
                    v0 = (int)((long)-1532275490 ^ (long)-1532275671);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 81: {
                    v0 = (int)((long)-1426236030 ^ (long)-1426236048);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 82: {
                    v0 = (int)((long)859151813 ^ (long)859151837);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 83: {
                    v0 = (int)((long)813812942 ^ (long)813812869);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 84: {
                    v0 = (int)((long)-1748874934 ^ (long)-1748874874);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 85: {
                    v0 = (int)((long)1506177356 ^ (long)1506177346);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 86: {
                    v0 = (int)((long)-1882430073 ^ (long)-1882430118);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 87: {
                    v0 = (int)((long)-1117625707 ^ (long)-1117625666);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 88: {
                    v0 = (int)((long)180959693 ^ (long)180959670);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 89: {
                    v0 = (int)((long)61442940 ^ (long)61442936);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 90: {
                    v0 = (int)((long)2031223494 ^ (long)2031223511);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 91: {
                    v0 = (int)((long)-1518951545 ^ (long)-1518951669);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 92: {
                    v0 = (int)((long)210568893 ^ (long)210568801);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 93: {
                    v0 = (int)((long)-1992975828 ^ (long)-1992975810);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 94: {
                    v0 = (int)((long)-1751293379 ^ (long)-1751293390);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 95: {
                    v0 = (int)((long)-1530816408 ^ (long)-1530816367);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 96: {
                    v0 = (int)((long)2032705551 ^ (long)2032705594);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 97: {
                    v0 = (int)((long)-1816049674 ^ (long)-1816049732);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 98: {
                    v0 = (int)((long)1780268336 ^ (long)1780268325);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 99: {
                    v0 = (int)((long)-258714632 ^ (long)-258714625);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 100: {
                    v0 = (int)((long)1786578616 ^ (long)1786578436);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 101: {
                    v0 = (int)((long)-1637385775 ^ (long)-1637385791);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 102: {
                    v0 = (int)((long)1836690894 ^ (long)1836690752);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 103: {
                    v0 = (int)((long)-10879754 ^ (long)-10879908);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 104: {
                    v0 = (int)((long)-1173613661 ^ (long)-1173613673);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 105: {
                    v0 = (int)((long)1227936752 ^ (long)1227936586);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 106: {
                    v0 = (int)((long)1250081523 ^ (long)1250081374);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 107: {
                    v0 = (int)((long)1253790427 ^ (long)1253790324);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 108: {
                    v0 = (int)((long)1230912205 ^ (long)1230912056);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 109: {
                    v0 = (int)((long)-113668025 ^ (long)-113667890);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 110: {
                    v0 = (int)((long)204292832 ^ (long)204292734);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 111: {
                    v0 = (int)((long)-372629060 ^ (long)-372629003);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 112: {
                    v0 = (int)((long)-469598607 ^ (long)-469598579);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 113: {
                    v0 = (int)((long)2021508404 ^ (long)2021508469);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 114: {
                    v0 = (int)((long)584608573 ^ (long)584608564);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 115: {
                    v0 = (int)((long)1631806364 ^ (long)1631806297);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 116: {
                    v0 = (int)((long)-590871046 ^ (long)-590871132);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 117: {
                    v0 = (int)((long)-839433321 ^ (long)-839433285);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 118: {
                    v0 = (int)((long)1005509283 ^ (long)1005509147);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 119: {
                    v0 = (int)((long)-1438902899 ^ (long)-1438903019);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 120: {
                    v0 = (int)((long)715899453 ^ (long)715899418);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 121: {
                    v0 = (int)((long)1394818430 ^ (long)1394818320);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 122: {
                    v0 = (int)((long)-108528828 ^ (long)-108528718);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 123: {
                    v0 = (int)((long)-993086920 ^ (long)-993086959);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 124: {
                    v0 = (int)((long)1830520491 ^ (long)1830520472);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 125: {
                    v0 = (int)((long)2113657293 ^ (long)2113657264);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 126: {
                    v0 = (int)((long)1775755414 ^ (long)1775755379);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 127: {
                    v0 = (int)((long)2134549784 ^ (long)2134549856);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 128: {
                    v0 = (int)((long)-1360638870 ^ (long)-1360638790);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 129: {
                    v0 = (int)((long)-962324057 ^ (long)-962324172);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 130: {
                    v0 = (int)((long)-92117922 ^ (long)-92117833);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 131: {
                    v0 = (int)((long)1367850272 ^ (long)1367850371);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 132: {
                    v0 = (int)((long)932081162 ^ (long)932081294);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 133: {
                    v0 = (int)((long)1142265297 ^ (long)1142265206);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 134: {
                    v0 = (int)((long)-817369881 ^ (long)-817369948);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 135: {
                    v0 = (int)((long)-614440864 ^ (long)-614440955);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 136: {
                    v0 = (int)((long)-1150051283 ^ (long)-1150051219);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 137: {
                    v0 = (int)((long)874406155 ^ (long)874406392);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 138: {
                    v0 = (int)((long)-1190366473 ^ (long)-1190366576);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 139: {
                    v0 = (int)((long)1468555303 ^ (long)1468555340);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 140: {
                    v0 = (int)((long)-1922430809 ^ (long)-1922430723);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 141: {
                    v0 = (int)((long)1352219033 ^ (long)1352218904);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 142: {
                    v0 = (int)((long)-580886272 ^ (long)-580886239);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 143: {
                    v0 = (int)((long)-740921570 ^ (long)-740921554);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 144: {
                    v0 = (int)((long)1354662153 ^ (long)1354662304);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 145: {
                    v0 = (int)((long)-1399277430 ^ (long)-1399277317);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 146: {
                    v0 = (int)((long)-1001609745 ^ (long)-1001609756);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 147: {
                    v0 = (int)((long)-1006157226 ^ (long)-1006157265);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 148: {
                    v0 = (int)((long)-579084750 ^ (long)-579084646);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 149: {
                    v0 = (int)((long)463241681 ^ (long)463241532);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 150: {
                    v0 = (int)((long)1501524114 ^ (long)1501524079);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 151: {
                    v0 = (int)((long)-809776833 ^ (long)-809776666);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 152: {
                    v0 = (int)((long)833451582 ^ (long)833451623);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 153: {
                    v0 = (int)((long)-706267296 ^ (long)-706267337);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 154: {
                    v0 = (int)((long)127301422 ^ (long)127301608);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 155: {
                    v0 = (int)((long)-1115143643 ^ (long)-1115143573);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 156: {
                    v0 = (int)((long)-109753765 ^ (long)-109753630);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 157: {
                    v0 = (int)((long)-324603661 ^ (long)-324603702);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 158: {
                    v0 = (int)((long)-1082369922 ^ (long)-1082370018);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 159: {
                    v0 = (int)((long)392086387 ^ (long)392086300);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 160: {
                    v0 = (int)((long)1640517048 ^ (long)1640516994);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 161: {
                    v0 = (int)((long)248982613 ^ (long)248982551);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 162: {
                    v0 = (int)((long)954931326 ^ (long)954931410);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 163: {
                    v0 = (int)((long)-1728686294 ^ (long)-1728686266);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 164: {
                    v0 = (int)((long)679740483 ^ (long)679740440);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 165: {
                    v0 = (int)((long)493696727 ^ (long)493696676);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 166: {
                    v0 = (int)((long)759462141 ^ (long)759462029);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 167: {
                    v0 = (int)((long)1879745082 ^ (long)1879745134);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 168: {
                    v0 = (int)((long)-1627128079 ^ (long)-1627128146);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 169: {
                    v0 = (int)((long)220808954 ^ (long)220808759);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 170: {
                    v0 = (int)((long)-140656108 ^ (long)-140656106);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 171: {
                    v0 = (int)((long)1681343307 ^ (long)1681343284);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 172: {
                    v0 = (int)((long)1524986887 ^ (long)1524986954);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 173: {
                    v0 = (int)((long)-757824981 ^ (long)-757824780);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 174: {
                    v0 = (int)((long)197513430 ^ (long)197513456);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 175: {
                    v0 = (int)((long)167275438 ^ (long)167275391);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 176: {
                    v0 = (int)((long)-165449040 ^ (long)-165449205);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 177: {
                    v0 = (int)((long)-1740402499 ^ (long)-1740402500);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 178: {
                    v0 = (int)((long)-973177032 ^ (long)-973176926);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 179: {
                    v0 = (int)((long)758062259 ^ (long)758062235);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 180: {
                    v0 = (int)((long)-474426813 ^ (long)-474426741);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 181: {
                    v0 = (int)((long)-635940144 ^ (long)-635940132);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 182: {
                    v0 = (int)((long)-682305745 ^ (long)-682305689);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 183: {
                    v0 = (int)((long)-1377946747 ^ (long)-1377946770);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 184: {
                    v0 = (int)((long)-857891828 ^ (long)-857891728);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 185: {
                    v0 = (int)((long)790192955 ^ (long)790192969);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 186: {
                    v0 = (int)((long)984003254 ^ (long)984003149);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 187: {
                    v0 = (int)((long)-395445398 ^ (long)-395445364);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 188: {
                    v0 = (int)((long)1662614430 ^ (long)1662614520);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 189: {
                    v0 = (int)((long)351401495 ^ (long)351401655);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 190: {
                    v0 = (int)((long)-98833019 ^ (long)-98832901);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 191: {
                    v0 = (int)((long)1839841459 ^ (long)1839841380);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 192: {
                    v0 = (int)((long)502924964 ^ (long)502924910);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 193: {
                    v0 = (int)((long)-177671150 ^ (long)-177670931);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 194: {
                    v0 = (int)((long)-1745425735 ^ (long)-1745425798);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 195: {
                    v0 = (int)((long)2087498810 ^ (long)2087498928);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 196: {
                    v0 = (int)((long)645264266 ^ (long)645264334);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 197: {
                    v0 = (int)((long)1979117607 ^ (long)1979117712);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 198: {
                    v0 = (int)((long)-2121252357 ^ (long)-2121252561);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 199: {
                    v0 = (int)((long)-1999404450 ^ (long)-1999404317);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 200: {
                    v0 = (int)((long)-289860906 ^ (long)-289861034);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 201: {
                    v0 = (int)((long)-1040678742 ^ (long)-1040678858);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 202: {
                    v0 = (int)((long)1354161402 ^ (long)1354161407);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 203: {
                    v0 = (int)((long)-776923981 ^ (long)-776924016);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 204: {
                    v0 = (int)((long)-1624267617 ^ (long)-1624267640);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 205: {
                    v0 = (int)((long)423477571 ^ (long)423477598);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 206: {
                    v0 = (int)((long)1146224751 ^ (long)1146224789);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 207: {
                    v0 = (int)((long)-904692532 ^ (long)-904692561);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 208: {
                    v0 = (int)((long)1450227873 ^ (long)1450227777);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 209: {
                    v0 = (int)((long)671497267 ^ (long)671497381);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 210: {
                    v0 = (int)((long)281984510 ^ (long)281984504);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 211: {
                    v0 = (int)((long)-1137883097 ^ (long)-1137882940);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 212: {
                    v0 = (int)((long)1322677534 ^ (long)1322677523);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 213: {
                    v0 = (int)((long)311231623 ^ (long)311231543);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 214: {
                    v0 = (int)((long)-1997340547 ^ (long)-1997340526);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 215: {
                    v0 = (int)((long)1993402127 ^ (long)1993402155);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 216: {
                    v0 = (int)((long)-1869888542 ^ (long)-1869888545);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 217: {
                    v0 = (int)((long)96685389 ^ (long)96685509);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 218: {
                    v0 = (int)((long)-779892885 ^ (long)-779892855);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 219: {
                    v0 = (int)((long)-1658761982 ^ (long)-1658761960);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 220: {
                    v0 = (int)((long)1815979488 ^ (long)1815979484);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 221: {
                    v0 = (int)((long)-1415422510 ^ (long)-1415422627);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 222: {
                    v0 = (int)((long)1780837847 ^ (long)1780837864);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 223: {
                    v0 = (int)((long)-1964293998 ^ (long)-1964294087);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 224: {
                    v0 = (int)((long)1117874342 ^ (long)1117874396);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 225: {
                    v0 = (int)((long)-293000961 ^ (long)-293001114);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 226: {
                    v0 = (int)((long)1466218853 ^ (long)1466219006);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 227: {
                    v0 = (int)((long)-2090346934 ^ (long)-2090346760);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 228: {
                    v0 = (int)((long)1535267878 ^ (long)1535267937);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 229: {
                    v0 = (int)((long)-1969016580 ^ (long)-1969016722);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 230: {
                    v0 = (int)((long)-1541971027 ^ (long)-1541971176);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 231: {
                    v0 = (int)((long)-1416571032 ^ (long)-1416570889);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 232: {
                    v0 = (int)((long)-411447605 ^ (long)-411447784);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 233: {
                    v0 = (int)((long)-756898755 ^ (long)-756898677);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 234: {
                    v0 = (int)((long)455614901 ^ (long)455614929);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 235: {
                    v0 = (int)((long)-1108941273 ^ (long)-1108941183);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 236: {
                    v0 = (int)((long)-1713790129 ^ (long)-1713790116);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 237: {
                    v0 = (int)((long)1324946728 ^ (long)1324946809);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 238: {
                    v0 = (int)((long)591435884 ^ (long)591435854);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 239: {
                    v0 = (int)((long)228196396 ^ (long)228196527);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 240: {
                    v0 = (int)((long)790524859 ^ (long)790524881);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 241: {
                    v0 = (int)((long)-1675264680 ^ (long)-1675264692);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 242: {
                    v0 = (int)((long)-792262062 ^ (long)-792261956);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 243: {
                    v0 = (int)((long)1627705280 ^ (long)1627705302);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 244: {
                    v0 = (int)((long)-875336659 ^ (long)-875336676);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 245: {
                    v0 = (int)((long)-2084166929 ^ (long)-2084167027);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 246: {
                    v0 = (int)((long)-1936397016 ^ (long)-1936396871);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 247: {
                    v0 = (int)((long)-1561760341 ^ (long)-1561760436);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 248: {
                    v0 = (int)((long)-780144979 ^ (long)-780145105);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 249: {
                    v0 = (int)((long)1070503032 ^ (long)1070503091);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 250: {
                    v0 = (int)((long)2074474736 ^ (long)2074474631);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 251: {
                    v0 = (int)((long)1886976504 ^ (long)1886976274);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 252: {
                    v0 = (int)((long)813727046 ^ (long)813727171);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 253: {
                    v0 = (int)((long)-651481276 ^ (long)-651481188);
                    if (!3S.\u2002) break;
                    throw null;
                }
                case 254: {
                    v0 = (int)((long)-2059718092 ^ (long)-2059717995);
                    if (!3S.\u2002) break;
                    throw null;
                }
                default: {
                    v0 = (int)((long)954729258 ^ (long)954729248);
                }
            }
            if ((var5_6 = (var1_1 & (int)((long)1161991660 ^ (long)1161991443)) - (var4_5 = v0)) < 0) {
                var5_6 += 256;
            }
            if ((var6_7 = ((var1_1 & (int)((long)22872235 ^ (long)22937428)) >>> (int)((long)1104621092 ^ (long)1104621100)) - var4_5) < 0) {
                var6_7 += 256;
            }
            var7_8 = (int)((long)940351436 ^ (long)940351436);
            if (!3S.\u2002) ** GOTO lbl1055
            throw null;
lbl-1000:
            // 1 sources

            {
                var8_9 = var7_8 % (int)((long)1157290208 ^ (long)1157290210);
                v1 = var7_8;
                v2 = var3_4;
                v3 = var3_4[v1];
                if (var8_9 == 0) {
                    v2[v1] = (char)(v3 ^ var5_6);
                    var5_6 = ((var5_6 >>> (int)((long)2135127855 ^ (long)2135127852) | var5_6 << (int)((long)1239200450 ^ (long)1239200455)) ^ var3_4[var7_8]) & (int)((long)-2108429466 ^ (long)-2108429415);
                    if (3S.\u2002) {
                        throw null;
                    }
                } else {
                    v2[v1] = (char)(v3 ^ var6_7);
                    var6_7 = ((var6_7 >>> (int)((long)-2061669284 ^ (long)-2061669281) | var6_7 << (int)((long)-258214585 ^ (long)-258214590)) ^ var3_4[var7_8]) & (int)((long)-55677468 ^ (long)-55677669);
                }
                ++var7_8;
lbl1055:
                // 2 sources

                ** while (var7_8 < var3_4.length)
            }
lbl1056:
            // 1 sources

            3S.e[var2_3] = new String(var3_4).intern();
        }
        return 3S.e[var2_3];
    }

    /*
     * Enabled aggressive block sorting
     */
    private static int 1(bmb bmb2) {
        boolean bl = \u2002;
        if (bl || bl) return -13300793;
        if (5z.4().1z.7(3S.class).7.2) {
            if (bl) return -13300793;
            if (bmb2.b() instanceof bmm) {
                if (bl || bl) return -13300793;
                return (int)((long)747187127 ^ (long)747187124);
            }
        }
        if (bl) return -13300793;
        if (5z.4().1z.7(3S.class).2.2) {
            if (bl) return -13300793;
            if (bmb2.b() instanceof bld) {
                if (bl || bl) return -13300793;
                return (int)((long)-1791337415 ^ (long)-1791337413);
            }
        }
        if (bl) return -13300793;
        if (!(bmb2.b() instanceof bjy)) {
            if (bl || bl) return -13300793;
            return (int)((long)-1779091601 ^ (long)1779091600);
        }
        if (bl) return -13300793;
        if ((bmb2 = ((bjy)bmb2.b()).b()).a() != aqf.a.b) {
            if (bl || bl) return -13300793;
            return (int)((long)954736127 ^ (long)-954736128);
        }
        if (!bl) return bmb2.b();
        return -13300793;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    static {
        block26: {
            block25: {
                var10 = 3S.\u2002;
                if (!var10) break block25;
                break block26;
            }
            var5_1 = new String[(int)((long)-1329914203 ^ (long)-1329914188)];
            if (var10) break block26;
            var3_2 = (int)((long)-1311598454 ^ (long)-1311598454);
            if (var10) break block26;
            var2_3 = 2w$6X.KAOZ("\u7e71\u562c\u45c6\u4da3\u7ef4\u5659\u45dc\u4d11\u7ea5\u56a3\u458d\u4d4f\u7e43\u5619\u4504\u4d86\u7e54\u5678\u4514\u4db7\u7ed5\u560f\u45f3\u4d0c\u7efe\u568c\u4534\u4d59\u7ed1\u56c0\u45cb\u4d75\u7e60\u56bb\u4513\u4d52\u7e67\u5613\u454a\u4dfc\u7eb6\u5670\u454a\u4d82\u7eb3\u56f5\u45b7\u4d40\u7e47\u5622\u45c1\u4d94\u7efd\u56b2\u4540\u4d72\u7e07\u56c7\u45f0\u4d20\u7e8a\u569b\u453b\u4d4c\u7ec4\u5618\u4559\u4d48\u7e01\u56f3\u453e\u4d1f\u7eee\u5649\u4509\u4d3d\u7e5c\u56d7\u4545\u4dee\u7ed5\u5694\u4575\u4dec\u7e72\u566a\u4557\u4d44\u7ebb\u5693\u4502\u4d8e\u7ee8\u561b\u450a\u4d0d\u7e9c\u5652\u4566\u4dbd\u7ea3\u56ec\u4549\u4da0\u7e32\u56e5\u4506\u4d60\u7e25\u5677\u45aa\u4d53\u7e02\u56ea\u45cc\u4d13\u7e17\u562b\u4539\u4d9c\u7ee4\u56fc\u45f7\u4dc7\u7ef7\u568c\u4559\u4d6c\u7e0b\u5699\u45e0\u4d9a\u7e3a\u56b0\u4589\u4dc3\u7ea8\u5630\u45be\u4d32\u7e67\u5648\u4520\u4d2f\u7e28\u5658\u45f6\u4d61\u7ec4\u5662\u4509\u4d67\u7eeb\u5655\u45c2\u4dbf\u7e13\u56a8\u4536\u4d7f\u7e72\u5613\u45cc\u4d68\u7e4b\u56b1\u4518\u4d8a\u7e30\u56dc\u45d9\u4dce\u7e1d\u5605\u45f9\u4d85\u7eef\u5666\u4564\u4dd5\u7ecf\u56ff\u4551\u4d62\u7e9a\u56dd\u4563\u4d56\u7eb9\u5662\u4502\u4d1e\u7e7b\u5654\u45e5\u4d06\u7e1f\u5631\u4596\u4d1a\u7e06\u5659\u45a3\u4d6a\u7e6e\u56cc\u45f4\u4da2\u7e56\u567f\u459c\u4d4a\u7e47\u56ac\u4545\u4dd8\u7eb3\u56de\u4505\u4dd7\u7e3c\u564b\u455a\u4d4b\u7e89\u5617\u459b\u4dd0\u7e8d\u56ce\u4537\u4d0c\u7ef8\u56f2\u4508\u4d44\u7ecf\u5685\u4503\u4d21\u7e41\u56c0", 1744197878);
            var4_4 = var2_3.length();
            if (var10) break block26;
            var1_5 = (int)((long)2081824150 ^ (long)2081824147);
            if (var10) break block26;
            var0_6 = (int)((long)2000691968 ^ (long)-2000691969);
            if (var10) break block26;
            block11: while (!var10) {
                block23: {
                    block22: {
                        v0 = (int)((long)-2027731174 ^ (long)-2027731090);
                        v1 = ++var0_6;
                        v2 = var2_3.substring(v1, v1 + var1_5);
                        v3 = (int)((long)791029916 ^ (long)-791029917);
                        if (3S.\u2002) {
                            throw null;
lbl24:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!3S.\u2002) continue block11;
                                    throw null;
                                }
                                var2_3 = 2w$6X.KAOZ("\u6845\u407c\u5324\u5bc4\u6844\u409f\u5390\u5b22\u6805\u40df\u536c\u5b27\u6827\u4011\u5375\u5b8c\u68b4\u4033\u531c\u5b5c\u6821", -1535488469);
                                var4_4 = var2_3.length();
                                var1_5 = (int)((long)885799652 ^ (long)885799650);
                                var0_6 = (int)((long)1875322295 ^ (long)-1875322296);
                                while (true) {
                                    v0 = (int)((long)-482445180 ^ (long)-482445120);
                                    v5 = ++var0_6;
                                    v2 = var2_3.substring(v5, v5 + var1_5);
                                    v3 = (int)((long)1234838855 ^ (long)1234838855);
                                    if (!3S.\u2002) break block22;
                                    throw null;
                                }
                                break;
                            }
lbl41:
                            // 1 sources

                            while (true) {
                                var5_1[var3_2++] = v4.intern();
                                if ((var0_6 += var1_5) < var4_4) {
                                    var1_5 = var2_3.charAt(var0_6);
                                    if (!3S.\u2002) ** continue;
                                    throw null;
                                }
                                3S.d = var5_1;
                                3S.e = new String[(int)((long)191302890 ^ (long)191302907)];
                                if (3S.\u2002) {
                                    throw null;
                                }
                                break block23;
                                break;
                            }
                        }
                    }
                    v6 = v2.toCharArray();
                    v7 = v6.length;
                    var6_7 = (int)((long)2040046741 ^ (long)2040046741);
                    v8 = v0;
                    v9 = v6;
                    v10 = v7;
                    if (v7 > (int)((long)-1509298862 ^ (long)-1509298861)) ** GOTO lbl108
                    do {
                        block24: {
                            v11 = v8;
                            v9 = v9;
                            v12 = v9;
                            v13 = v8;
                            v14 = var6_7;
                            do {
                                switch (var6_7 % (int)((long)-1830125877 ^ (long)-1830125876)) {
                                    case 0: {
                                        v15 = (int)((long)227480559 ^ (long)227480464);
                                        if (!3S.\u2002) break;
                                        throw null;
                                    }
                                    case 1: {
                                        v15 = (int)((long)-1773774374 ^ (long)-1773774347);
                                        if (!3S.\u2002) break;
                                        throw null;
                                    }
                                    case 2: {
                                        v15 = (int)((long)1186780961 ^ (long)1186781008);
                                        if (!3S.\u2002) break;
                                        throw null;
                                    }
                                    case 3: {
                                        v15 = (int)((long)-1861198454 ^ (long)-1861198393);
                                        if (!3S.\u2002) break;
                                        throw null;
                                    }
                                    case 4: {
                                        v15 = (int)((long)-27354602 ^ (long)-27354556);
                                        if (!3S.\u2002) break;
                                        throw null;
                                    }
                                    case 5: {
                                        v15 = (int)((long)1660084060 ^ (long)1660084090);
                                        if (!3S.\u2002) break;
                                        throw null;
                                    }
                                    default: {
                                        v15 = (int)((long)1912179154 ^ (long)1912179122);
                                    }
                                }
                                v12[v14] = (char)(v12[v14] ^ (v13 ^ v15));
                                ++var6_7;
                                v8 = v11;
                                if (v11 != 0) break block24;
                                v11 = v8;
                                v9 = v9;
                                v14 = v8;
                                v12 = v9;
                                v13 = v8;
                            } while (!3S.\u2002);
                            throw null;
                        }
                        v16 = v9;
                        v10 = v10;
                    } while (v10 > var6_7);
                    v4 = new String(v16);
                    switch (v3) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl119:
                        // 1 sources

                        ** continue;
                    }
                }
                3S.0 = new ArrayList<2w<bmb>>();
                var7_8 = (int)((long)-11384764 ^ (long)-11384764);
                while (var7_8 < (int)((long)762012770 ^ (long)762012774)) {
                    var8_10 = var7_8++;
                    v17 = new Predicate[(int)((long)-2016383580 ^ (long)-2016383579)];
                    v17[(int)((long)-1059924812 ^ (long)-1059924812)] = (Predicate<bmb>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, 2(int bmb ), (Lbmb;)Z)((int)var8_10);
                    var9_11 /* !! */  = v17;
                    var8_9 = new 5y<T>();
                    new 5y<T>().1 = var9_11 /* !! */ ;
                    v18.4 = var9_11 /* !! */  = Comparator.comparingDouble((ToDoubleFunction<bmb>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)D, 3(bmb ), (Lbmb;)D)());
                    3S.0.add(var8_9.7());
                    if (!3S.\u2002) continue;
                    throw null;
                }
                break block11;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ boolean 2(int n, bmb bmb2) {
        boolean bl = \u2002;
        if (bl || bl) return true;
        if (3S.1(bmb2) == n) {
            if (bl) return true;
            return (int)((long)-1372175401 ^ (long)-1372175402) != 0;
        }
        if (!bl) return (int)((long)-20946794 ^ (long)-20946794) != 0;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static double 9(bmb bmb2) {
        boolean bl = \u2002;
        if (bl || bl) return 0.0;
        if (5z.4().1z.7(3S.class).7.2) {
            if (bl) return 0.0;
            if (bmb2.b() instanceof bmm) {
                if (bl || bl) return 0.0;
                return 1.0E7;
            }
        }
        if (bl) return 0.0;
        if (5z.4().1z.7(3S.class).2.2) {
            if (bl) return 0.0;
            if (bmb2.b() instanceof bld) {
                if (bl || bl) return 0.0;
                return 1.0E7;
            }
        }
        if (bl) return 0.0;
        if (!(bmb2.b() instanceof bjy)) {
            if (bl || bl) return 0.0;
            return -100.0;
        }
        if (bl) return 0.0;
        int n = bpu.a((bps)bps.c((int)((int)((long)-1361684192 ^ (long)-1361684192))), (bmb)bmb2);
        if (bl || bl) {
            return 0.0;
        }
        int n2 = ((bjy)bmb2.b()).e();
        return n2 + ((int)((long)-1137246929 ^ (long)-1137246901) - (n2 << (int)((long)1038044350 ^ (long)1038044348))) * n;
    }
}

