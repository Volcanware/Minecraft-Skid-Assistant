# Impact 4.9.1 (MC 1.16.5) — decompiled module index

Source: Impact-4.9.1-1.16.5.jar from github.com/ImpactDevelopment/ImpactReleases, decompiled with CFR 0.152.
All string literals were runtime-decrypted by executing each class's <clinit> + decryptor in a stubbed JVM (decryption is stack-sensitive; static analysis alone cannot recover them).
Every `Foo.b(x,y)` call site in the annotated sources is followed by `/* "plaintext" */`.

## Combat
- **Aimbot** (`net.impactclient.3E`) — Aims at target entities
- **Anti Aim** (`net.impactclient.0C`) — Makes your head move around
- **Anti Bot** (`net.impactclient.3f`) — Prevents bot targeting
- **Auto Armor** (`net.impactclient.3S`) — Automaticaly equips armor
- **Auto Clicker** (`net.impactclient.3D`) — Automatically Clicks
- **Auto Totem** (`net.impactclient.3Q`) — Revives you after death if you have a totem
- **Auto Weapon** (`net.impactclient.38`) — Automatically determine the best weapon to use
- **Bow Aimbot** (`net.impactclient.3w`) — Aims at a target entity with a bow
- **CopsAndCrims** (`net.impactclient.0I`) — Hack for Cops and Crims
- **Criticals** (`net.impactclient.32`) — Increases the chances of getting critical hits
- **Crystal Aura** (`net.impactclient.3c`) — Automatically destroys end crystals near the client player
- **HitBox** (`net.impactclient.3L`) — Expands entity Hitboxes
- **Hunt** (`net.impactclient.3v`) — Automatically tracks and follows target players
- **Ignite** (`net.impactclient.0k`) — Lights players around you on fire if you have flint n' steel on your hotbar
- **Kill Aura** (`net.impactclient.3H`) — Attacks other entities
- **Minestrike** (`net.impactclient.0B`) — MultiHack designed for the Minestrike Minigame
- **Murder** (`net.impactclient.0u`) — Reveals the murderer
- **PropHunt** (`net.impactclient.0y`) — Reveals the locaiton of props
- **QuakeCraft** (`net.impactclient.0g`) — Targets and fires at enemies in QuakeCraft
- **SmoothAim** (`net.impactclient.3q`) — A more legit form of aimbot
- **SneakyAssassins** (`net.impactclient.0i`) — Reveals the assassins
- **Soup** (`net.impactclient.3r`) — Swaps to a soup in your hotbar and drinks it

## Movement
- **Air Jump** (`net.impactclient.0V`) — Allows you to jump in-air
- **Anti AFK** (`net.impactclient.0c`) — Prevents you from being kicked by AFK plugins
- **Auto Jump** (`net.impactclient.0Y`) — Automatically jump
- **Auto Walk** (`net.impactclient.06`) — Automatically Walk
- **Blink** (`net.impactclient.0F`) — Lag Switch
- **BoatFly** (`net.impactclient.0O`) — Allows you to fly while in boats
- **Click TP** (`net.impactclient.0K`) — Teleport to the block you're looking at
- **Elytra+** (`net.impactclient.0A`) — Eases elytra
- **Fast Fall** (`net.impactclient.0z`) — Increases fall speed
- **Fast Interact** (`net.impactclient.7s`) — Adjust your interaction speed
- **Flight** (`net.impactclient.07`) — Allows you to fly
- **Freecam** (`net.impactclient.7k`) — Fly out of your body, like spectator mode
- **High Jump** (`net.impactclient.0m`) — Change the jump height multiplier
- **Jesus** (`net.impactclient.01`) — Allows you to walk on water, like Jesus!
- **Levitation Control** (`net.impactclient.0P`) — Eases control of shulker levitation effects
- **Long Jump** (`net.impactclient.0R`) — Jump Farther
- **No Push** (`net.impactclient.0J`) — Prevents you from getting pushed by other players
- **No Slow** (`net.impactclient.0e`) — Don't slow down when you're using an item
- **Parkour** (`net.impactclient.0X`) — Automatically jumps when you hit the edge of a block
- **Portals** (`net.impactclient.0a`) — Make modifications to Portal behavior
- **Riding** (`net.impactclient.0E`) — Improves horses and some other rideable entities
- **Safe Walk** (`net.impactclient.0f`) — Prevents you from walking off of ledges
- **Scaffold** (`net.impactclient.7y`) — Places blocks under you
- **Sneak** (`net.impactclient.7i`) — Automatically Sneaks
- **Speed** (`net.impactclient.0H`) — Go faster
- **Spider** (`net.impactclient.0S`) — Allows you to climb up walls like a spider
- **Sprint** (`net.impactclient.0D`) — Improves Sprinting
- **Step** (`net.impactclient.0Q`) — Allows you to step up full blocks
- **Terrain** (`net.impactclient.08`) — Modify movement on various terrain
- **Unpack** (`net.impactclient.0W`) — When you right click logs in your hand, they turn into planks

## Render
- **Animations** (`net.impactclient.0Z`) — Modify held-item animations
- **Anti Blind** (`net.impactclient.7Z`) — Removes Blindness and Nausea effects
- **Anti Overlay** (`net.impactclient.7C`) — Removes various overlays from your screen
- **Breadcrumbs** (`net.impactclient.70`) — Creates a trail behind you
- **Camera Clip** (`net.impactclient.7x`) — Allows your 3rd person camera to clip through blocks
- **Capes** (`net.impactclient.7j`) — Control which capes are shown.\nNOTE: Impact capes require Premium.
- **Chams** (`net.impactclient.73`) — Renders entities through walls
- **ClickGui** (`net.impactclient.7h`) — Clickable Gui, used to manage module options
- **Crosshair+** (`net.impactclient.7d`) — Customize your crosshair like in CS:GO
- **ESP** (`net.impactclient.7t`) — Reveals entity location
- **Enchant Color** (`net.impactclient.79`) — Customize the color of enchantments
- **Fancy Chat** (`net.impactclient.0d`) — Change the "font" that you send messages with
- **HUD** (`net.impactclient.7N`) — Displays an ingame overlay that shows information
- **Light** (`net.impactclient.7U`) — Change how lighting works
- **Liquid Interact** (`net.impactclient.7a`) — Enables place/break interaction with Liquids
- **Main Menu** (`net.impactclient.7M`) — Configuration options for the Main Menu
- **Nametags** (`net.impactclient.7G`) — Replaces Vanilla Nametags with more detailed ones
- **New Chunks** (`net.impactclient.0b`) — Exploit for Spigot servers that highlights newly generated chunks
- **No Render** (`net.impactclient.7n`) — Prevent item entity rendering to reduce lag
- **No SRP** (`net.impactclient.0N`) — Prevents the server from forcing a resource pack
- **Radar** (`net.impactclient.7W`) — Displays a radar that reveals the location of entities
- **Search** (`net.impactclient.7V`) — Highlights targetted blocks with a bounding box
- **Signs** (`net.impactclient.0n`) — Perform various actions on signs
- **Storage ESP** (`net.impactclient.7T`) — Draws boxes around storage containers
- **Tracers** (`net.impactclient.7Y`) — Draws a line to entities
- **Trajectories** (`net.impactclient.76`) — Displays where your items will land
- **Weather** (`net.impactclient.77`) — Control the weather
- **Wireframe** (`net.impactclient.7l`) — Turns blocks into Wireframes
- **XRay** (`net.impactclient.7O`) — Allows you to see target blocks through walls

## Player
- **Anti Desync** (`net.impactclient.00`) — Prevents desynchronization of blocks between the client and the server
- **Anti Fire** (`net.impactclient.3o`) — AntiFire, Only works on 1.8 servers
- **Anti Hunger** (`net.impactclient.3F`) — Reduces hunger loss
- **Auto Disconnect** (`net.impactclient.03`) — Automatically disconnects when your health is under an amount
- **Auto Eat** (`net.impactclient.0L`) — Automatically eat food when you reach a certain hunger amount
- **Auto Eject** (`net.impactclient.0v`) — Removes unwanted items from your inventory
- **Auto Fish** (`net.impactclient.0q`) — Automatically fishes for you, Useful when AFKing
- **Auto Mine** (`net.impactclient.0r`) — Automatically mines for you
- **Auto Reconnect** (`net.impactclient.0h`) — Automatically reconnects upon disconnect
- **Auto Tool** (`net.impactclient.0o`) — Find the best tool for the job!
- **Breaker** (`net.impactclient.05`) — Break nearby minigame respawn blocks
- **Build** (`net.impactclient.7K`) — Dab on 'em
- **Chest Stealer** (`net.impactclient.74`) — Automatically Steals items from Chests
- **Discord RPC** (`net.impactclient.0M`) — Integration with Discord's Rich Presence
- **Franky** (`net.impactclient.04`) — It does exactly what you think it does
- **GhostHand** (`net.impactclient.0s`) — Reach blocks through walls
- **Inventory** (`net.impactclient.7p`) — Make modifications to inventory behavior
- **Item Saver** (`net.impactclient.7b`) — Moves items out of your hand that have 1 durability
- **Lag** (`net.impactclient.0p`) — A collection of utilities to mess with your packets
- **Middle Click Friend** (`net.impactclient.09`) — Middle clicking players will add them as a friend.
- **No Fall** (`net.impactclient.75`) — Prevents Fall Damage
- **Randomizer** (`net.impactclient.7B`) — Randomly switch between hotbar slots
- **Respawn** (`net.impactclient.7u`) — Manage actions that occur upon death
- **Self Destruct** (`net.impactclient.0G`) — Disables all elements of the Client, doesn't unload classes
- **Timer** (`net.impactclient.7z`) — Change the Client-Sided TPS
- **Velocity** (`net.impactclient.0w`) — Adjust your Velocity
- **Yaw** (`net.impactclient.02`) — Lock your yaw

## Misc
- **Anti Hazard** (`net.impactclient.0T`) — Helps you avoid hazards
- **Anti Sound Lag** (`net.impactclient.0U`) — Prevents sound lag from offhand switching
- **Anti Vanish** (`net.impactclient.0x`) — Detects when staff members go into vanish
- **Auto Cheat** (`net.impactclient.0j`) — Automatically detects the AntiCheat being used by the current server
- **Baritone** (`net.impactclient.0l`) — Manage the Baritone settings
- **Log Position** (`net.impactclient.0t`) — Shows the positions that players in render distance logged out at
- **No Rotate** (`net.impactclient.7I`) — Discards Server Rotation Packets
- **Nuker** (`net.impactclient.7A`) — Destroys blocks around you
- **Skin Blinker** (`net.impactclient.7g`) — Causes your Jacket Layer to blink

## Anti-cheat-relevant highlights

- **Auto Cheat** (`0j`) — fingerprinting module: detects server anti-cheat from domain/plugins (contains "aac", "nocheatplus", plus probe servers `ncp.odiegaming.com`, `hypixel.net`, `badlion.net`, `mineplex.com`, `2b2t.org`). Useful reference for how cheat clients sniff AC type.
- **No Rotate** (`7I`) — silently discards server rotation (S2C look/teleport-confirm) packets; defeats rotation-based checks and flag-backs.
- **Lag** (`0p`) — packet choker ("The type of packets to choke"): delays/queues outbound packets to fake high ping; the classic Blink/desync primitive most fly/speed bypasses build on.
- **Flight** (`07`) — includes "Prevents vanilla from kicking you for flying" (messes with `allowflight`/kick logic).
- **Anti Desync** (`00`), **Blink** (`0F` "Lag Switch"), **Timer** (`7z`, client-side TPS multiplier), **Velocity** (`0w`), **Jesus** (`01`), **No Slow** (`0e`), **Speed** (`0H`), **Step** (`0Q`), **Scaffold** (`7y`) — the movement modules whose handlers are worth reading first; each annotated source lists its mode/settings strings (e.g. Kill Aura `3H` exposes Priority/Walls/RayTrace/Immune/TPS Sync options).
- Kill Aura `3H` "TPS Sync" setting synchronizes hit delay with server TPS — a common legit-timing technique worth signature-ing.
